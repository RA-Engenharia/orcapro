/* =====================================================================
 * excel.js — Exportação Excel PROFISSIONAL (workbook vivo, 13 abas)
 * Abas: Resumo · Sintética · Analítica. Tudo com FÓRMULAS (recalcula
 * ao mudar QTD, custo ou BDI) + formatação padrão de planilha
 * orçamentária (navy/aço, moeda R$, zebra, freeze, subtotais).
 * Usa ExcelJS (lazy-load CDN). `construir()` é pura/testável (Node).
 * ===================================================================== */
(function (global) {
  "use strict";

  var SH_RES = "Resumo", SH_SINT = "Sintética", SH_ANAL = "Analítica";
  var BDI_ADDR = "'" + SH_RES + "'!$B$6"; // endereço físico do parâmetro BDI (input amarelo)
  var BDI_CELL = "p_BDI"; // FASE 2: fórmulas usam o named range (legível e à prova de mover célula)
  function ref(sheet, cell) { return "'" + sheet + "'!" + cell; }

  var MOEDA = 'R$ #,##0.00', NUM = '#,##0.00', PCT = '0.00"%"';
  var navy = 'FF0F2740', aco = 'FF2E6F9E', cinza = 'FFEFF3F8', branco = 'FFFFFFFF',
      verde = 'FF16A34A', cinzaSub = 'FFE2E8F0', muted = 'FF64748B', amarelo = 'FFFFF7CC';

  function thin() { var s = { style: 'thin', color: { argb: 'FFCBD5E1' } }; return { top: s, left: s, bottom: s, right: s }; }
  function hStyle(c) { c.font = { bold: true, color: { argb: branco }, size: 10 }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: navy } }; c.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true }; c.border = thin(); }

  /* ---- Quebra MO / MAT / EQ de UM item (custo total `ct`), na ordem de confiança:
   *  1. parcelas do PRÓPRIO item (Orcamento.repartirCusto) — é o único lugar
   *     onde o modo de custo aparece ("só mão de obra" fatura só MO);
   *  2. razão da composição na base analítica, normalizada pela SOMA das três
   *     parcelas. ⚠ Nunca dividir por `custoUnitario`: no analítico da CAIXA
   *     MO+MAT+EQ difere do custo unitário por centavos (cada parcela é
   *     arredondada por fora), e dividindo pelo unitário 0,6% do custo direto
   *     ficava sem categoria — o Resumo do arquivo entregue acusava
   *     "⚠ verificar" contra si mesmo, em orçamento correto. É a mesma régua de
   *     Analitico.razoes();
   *  3. sem nada disso: material, e `fonte` diz que caiu aqui — o Resumo conta
   *     quantos itens vieram de cada fonte em vez de fingir precisão.
   * Usada pelo Resumo E pela pizza da aba Gráficos: eram duas contas, e a pizza
   * simplesmente não saía quando os itens não traziam parcelas. */
  function _repartirItem(it, ct, ana, num) {
    var rep = (global.Orcamento && Orcamento.repartirCusto) ? Orcamento.repartirCusto(it, ct) : null;
    if (rep) return { mo: num(rep.mo), mat: num(rep.mat), eq: num(rep.eq), fonte: 'item' };
    if (ana) {
      var soma = num(ana.custoMO) + num(ana.custoMAT) + num(ana.custoEQ);
      if (soma > 0) return { mo: ct * num(ana.custoMO) / soma, mat: ct * num(ana.custoMAT) / soma, eq: ct * num(ana.custoEQ) / soma, fonte: 'analitico' };
    }
    return { mo: 0, mat: ct, eq: 0, fonte: 'material' };
  }
  // Soma da quebra no orçamento inteiro. `ct` de cada item vem da FONTE ÚNICA
  // (Orcamento.calcular) — a mesma coluna H da Analítica — para MO+MAT+EQ fechar
  // com o Custo Direto por construção, e não por coincidência.
  function _quebraMoMatEq(orc, deps) {
    var num = deps.num, insMap = deps.insumosMap || null;
    var calc = (global.Orcamento && Orcamento.calcular) ? Orcamento.calcular(orc) : null, linhaDe = {};
    if (calc) calc.linhas.forEach(function (L) { linhaDe[L.etapaIdx + "|" + L.itemIdx] = L; });
    var out = { mo: 0, mat: 0, eq: 0, total: 0, nItem: 0, nAna: 0, nMat: 0, n: 0 };
    (orc.etapas || []).forEach(function (et, ei) {
      (et.itens || []).forEach(function (it, ii) {
        var L = linhaDe[ei + "|" + ii];
        var ct = L ? num(L.custoTotal) : num(it.quantidade) * num(it.custoUnitario);
        var q = _repartirItem(it, ct, insMap && insMap[String(it.codigo)], num);
        out.mo += q.mo; out.mat += q.mat; out.eq += q.eq; out.total += ct; out.n++;
        if (q.fonte === 'item') out.nItem++; else if (q.fonte === 'analitico') out.nAna++; else out.nMat++;
      });
    });
    return out;
  }

  // Cores da identidade (para os gráficos em canvas)
  var COR = { navy: '#0f2740', aco: '#2e6f9e', verde: '#16a34a', amarelo: '#f59e0b', vermelho: '#dc2626', cinza: '#e2e8f0', muted: '#64748b', texto: '#1e293b' };

  /* =====================================================================
   * GRÁFICOS EM CANVAS (SÓ NO BROWSER) — geram PNG base64 p/ embutir.
   * Rodam no wrapper gerar()/ensureExcelJS, ANTES de construir(). Node não
   * tem document/canvas → nunca são chamados lá (construir só usa deps.graficos).
   * ===================================================================== */

  // Cria um canvas offscreen com fundo branco (qualidade de impressão).
  function _canvas(w, h) {
    var cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    var ctx = cv.getContext('2d');
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, w, h);
    ctx.textBaseline = 'alphabetic';
    return { cv: cv, ctx: ctx };
  }
  function _titulo(ctx, txt, w) {
    ctx.fillStyle = COR.navy; ctx.font = 'bold 26px Arial, sans-serif';
    ctx.textAlign = 'left'; ctx.fillText(txt, 34, 44);
    ctx.strokeStyle = COR.aco; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(34, 58); ctx.lineTo(w - 34, 58); ctx.stroke();
  }
  function _corta(ctx, txt, maxW) {
    txt = String(txt == null ? '' : txt);
    if (ctx.measureText(txt).width <= maxW) return txt;
    while (txt.length > 1 && ctx.measureText(txt + '…').width > maxW) txt = txt.slice(0, -1);
    return txt + '…';
  }
  function _money(v, fmtNum) { return 'R$ ' + fmtNum(v || 0, 0); }

  // --- Curva ABC / Pareto: barras (custo desc) + linha do % acumulado + faixas A/B/C ---
  // abc = { linhas:[{codigo,descricao,custoTotal,pct,acumPct,classe}], ... } (Orcamento.curvaABC)
  function _pngABC(abc, fmtNum) {
    var linhas = (abc && abc.linhas) ? abc.linhas.slice(0, 20) : [];
    var W = 900, H = 460, o = _canvas(W, H), ctx = o.ctx;
    _titulo(ctx, 'Curva ABC — Pareto (custo por item)', W);
    var padL = 60, padR = 56, padT = 80, padB = 96;
    var plotW = W - padL - padR, plotH = H - padT - padB, x0 = padL, y0 = H - padB;
    var maxV = linhas.reduce(function (m, l) { return Math.max(m, l.custoTotal || 0); }, 0) || 1;
    var corCl = { A: COR.verde, B: COR.amarelo, C: COR.muted };
    // grade + eixo Y esquerdo (R$) e direito (%)
    ctx.textAlign = 'right'; ctx.font = '12px Arial, sans-serif';
    [0, 0.25, 0.5, 0.75, 1].forEach(function (g) {
      var yy = y0 - g * plotH;
      ctx.strokeStyle = COR.cinza; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(x0, yy); ctx.lineTo(x0 + plotW, yy); ctx.stroke();
      ctx.fillStyle = COR.muted; ctx.fillText(fmtNum(maxV * g, 0), x0 - 6, yy + 4);
      ctx.textAlign = 'left'; ctx.fillText((g * 100).toFixed(0) + '%', x0 + plotW + 6, yy + 4); ctx.textAlign = 'right';
    });
    var n = linhas.length || 1, bw = plotW / n, bar = Math.min(bw * 0.62, 46);
    // barras
    linhas.forEach(function (l, i) {
      var cx = x0 + i * bw + (bw - bar) / 2;
      var bh = (l.custoTotal || 0) / maxV * plotH;
      ctx.fillStyle = corCl[l.classe] || COR.aco;
      ctx.fillRect(cx, y0 - bh, bar, bh);
      ctx.save(); ctx.translate(cx + bar / 2, y0 + 6); ctx.rotate(Math.PI / 4);
      ctx.fillStyle = COR.muted; ctx.font = '10px Arial, sans-serif'; ctx.textAlign = 'left';
      ctx.fillText(_corta(ctx, l.codigo || l.descricao || ('#' + (i + 1)), 74), 0, 0);
      ctx.restore();
    });
    // linha % acumulado
    ctx.strokeStyle = COR.navy; ctx.lineWidth = 2.5; ctx.beginPath();
    linhas.forEach(function (l, i) {
      var cx = x0 + i * bw + bw / 2, cy = y0 - (Math.min(100, l.acumPct || 0) / 100) * plotH;
      if (i === 0) ctx.moveTo(cx, cy); else ctx.lineTo(cx, cy);
    });
    ctx.stroke();
    linhas.forEach(function (l, i) {
      var cx = x0 + i * bw + bw / 2, cy = y0 - (Math.min(100, l.acumPct || 0) / 100) * plotH;
      ctx.fillStyle = COR.navy; ctx.beginPath(); ctx.arc(cx, cy, 3.2, 0, 2 * Math.PI); ctx.fill();
    });
    // faixas A/B/C (80% / 95%)
    ctx.setLineDash([5, 4]); ctx.lineWidth = 1.2;
    [{ v: 80, c: COR.verde }, { v: 95, c: COR.amarelo }].forEach(function (f) {
      var yy = y0 - (f.v / 100) * plotH;
      ctx.strokeStyle = f.c; ctx.beginPath(); ctx.moveTo(x0, yy); ctx.lineTo(x0 + plotW, yy); ctx.stroke();
    });
    ctx.setLineDash([]);
    // legenda
    var lx = padL, ly = H - 30;
    ctx.font = '13px Arial, sans-serif'; ctx.textAlign = 'left';
    [['A', 'até 80%'], ['B', '80–95%'], ['C', '95–100%']].forEach(function (p) {
      ctx.fillStyle = corCl[p[0]]; ctx.fillRect(lx, ly - 11, 14, 14);
      ctx.fillStyle = COR.texto; ctx.fillText('Classe ' + p[0] + ' (' + p[1] + ')', lx + 20, ly);
      lx += 200;
    });
    ctx.fillStyle = COR.navy; ctx.fillText('— % acumulado', lx, ly);
    return o.cv.toDataURL('image/png');
  }

  // --- Curva S: linha do avanço físico-financeiro acumulado (%) ---
  // pts = [%acum semana 1, ...] ; rotulos p/ eixo X. (mesma lógica do _curvaS do ui.js)
  function _pngCurvaS(pts, totalTxt) {
    pts = (pts && pts.length) ? pts : [0];
    var W = 900, H = 420, o = _canvas(W, H), ctx = o.ctx;
    _titulo(ctx, 'Curva S — avanço físico-financeiro acumulado', W);
    var padL = 54, padR = 24, padT = 82, padB = 56;
    var plotW = W - padL - padR, plotH = H - padT - padB, x0 = padL, yTop = padT, yBot = H - padB;
    var nSem = pts.length;
    var X = function (i) { return x0 + (nSem <= 1 ? plotW / 2 : (i / (nSem - 1)) * plotW); };
    var Y = function (v) { return yBot - (Math.min(100, Math.max(0, v)) / 100) * plotH; };
    ctx.font = '12px Arial, sans-serif';
    [0, 25, 50, 75, 100].forEach(function (g) {
      var yy = Y(g);
      ctx.strokeStyle = COR.cinza; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x0, yy); ctx.lineTo(x0 + plotW, yy); ctx.stroke();
      ctx.fillStyle = COR.muted; ctx.textAlign = 'right'; ctx.fillText(g + '%', x0 - 8, yy + 4);
    });
    // área
    ctx.beginPath(); ctx.moveTo(X(0), yBot);
    pts.forEach(function (v, i) { ctx.lineTo(X(i), Y(v)); });
    ctx.lineTo(X(nSem - 1), yBot); ctx.closePath();
    ctx.fillStyle = 'rgba(46,111,158,0.12)'; ctx.fill();
    // linha
    ctx.strokeStyle = COR.aco; ctx.lineWidth = 3; ctx.beginPath();
    pts.forEach(function (v, i) { if (i === 0) ctx.moveTo(X(i), Y(v)); else ctx.lineTo(X(i), Y(v)); });
    ctx.stroke();
    // pontos + rótulos X
    var step = Math.max(1, Math.ceil(nSem / 12));
    ctx.textAlign = 'center';
    pts.forEach(function (v, i) {
      ctx.fillStyle = COR.navy; ctx.beginPath(); ctx.arc(X(i), Y(v), 3.4, 0, 2 * Math.PI); ctx.fill();
      if (i % step === 0 || i === nSem - 1) {
        ctx.fillStyle = COR.muted; ctx.font = '10px Arial, sans-serif';
        ctx.fillText('S' + (i + 1), X(i), yBot + 18);
      }
    });
    if (totalTxt) { ctx.fillStyle = COR.muted; ctx.font = '12px Arial, sans-serif'; ctx.textAlign = 'left'; ctx.fillText(totalTxt, x0, H - 12); }
    return o.cv.toDataURL('image/png');
  }

  // --- Composição MO/MAT/EQ: pizza + legenda ---
  // dados = [{rotulo, valor, cor}]
  function _pngPizza(dados, fmtNum) {
    var W = 900, H = 420, o = _canvas(W, H), ctx = o.ctx;
    _titulo(ctx, 'Composição de custo — MO / MAT / EQ', W);
    var tot = dados.reduce(function (s, d) { return s + (d.valor || 0); }, 0) || 1;
    var cx = 250, cy = 250, R = 140, ang = -Math.PI / 2;
    dados.forEach(function (d) {
      var frac = (d.valor || 0) / tot, a1 = ang + frac * 2 * Math.PI;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, R, ang, a1); ctx.closePath();
      ctx.fillStyle = d.cor; ctx.fill();
      ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.stroke();
      ang = a1;
    });
    // legenda
    var lx = 480, ly = 150;
    ctx.textAlign = 'left';
    dados.forEach(function (d) {
      var pct = (d.valor || 0) / tot * 100;
      ctx.fillStyle = d.cor; ctx.fillRect(lx, ly - 16, 20, 20);
      ctx.fillStyle = COR.texto; ctx.font = 'bold 18px Arial, sans-serif';
      ctx.fillText(d.rotulo + '  ' + fmtNum(pct, 1) + '%', lx + 30, ly);
      ctx.fillStyle = COR.muted; ctx.font = '14px Arial, sans-serif';
      ctx.fillText(_money(d.valor, fmtNum), lx + 30, ly + 22);
      ly += 64;
    });
    return o.cv.toDataURL('image/png');
  }

  // Monta { abc, curvaS, moMatEq } (dataURLs). SÓ chamar no browser.
  // orc: orçamento; deps: { num, fmtNum, abc?, crono?, cronoAgente? }
  function gerarGraficos(orc, deps) {
    if (typeof document === 'undefined' || !document.createElement) return null;
    var num = deps.num, fmtNum = deps.fmtNum;
    var g = {};
    try {
      // ABC
      var abc = deps.abc || (global.Orcamento && Orcamento.curvaABC ? Orcamento.curvaABC(orc) : null);
      if (abc && abc.linhas && abc.linhas.length) g.abc = _pngABC(abc, fmtNum);

      // Curva S — preferir a curva semanal do agente (mesma do _curvaS); fallback: crono mensal
      var pts = null, totalTxt = '';
      if (typeof global.Cronograma !== 'undefined' && Cronograma.estimar) {
        var r = Cronograma.estimar(orc), nSem = r.totalSemanas || 1, dpw = (r.params && r.params.diasUteisSemana) || 5;
        var custoSem = [], totalCusto = 0, w;
        for (w = 0; w < nSem; w++) custoSem[w] = 0;
        (r.etapas || []).forEach(function (e) {
          totalCusto += e.custo;
          var s0 = e.inicio / dpw, s1 = e.fim / dpw, dur = Math.max(0.01, s1 - s0);
          for (var ww = 0; ww < nSem; ww++) { var ov = Math.max(0, Math.min(ww + 1, s1) - Math.max(ww, s0)); if (ov > 0) custoSem[ww] += e.custo * (ov / dur); }
        });
        var acc = 0, totV = totalCusto || 1; pts = [];
        for (w = 0; w < nSem; w++) { acc += custoSem[w]; pts.push(acc / totV * 100); }
        totalTxt = 'Custo distribuído em ' + nSem + ' semanas do cronograma. Total: ' + _money(totalCusto, fmtNum) + '.';
      } else if (deps.crono && deps.crono.acumPct && deps.crono.acumPct.length) {
        pts = deps.crono.acumPct.slice();
        totalTxt = 'Avanço acumulado ao longo de ' + deps.crono.meses + ' meses (preço com BDI).';
      }
      if (pts && pts.length) g.curvaS = _pngCurvaS(pts, totalTxt);

      /* MO/MAT/EQ — os MESMOS números do bloco "Composição de custo" do Resumo
         (helper único _quebraMoMatEq). Somar as três parcelas cruas do item
         ignorava o modo de custo E deixava a pizza de fora sempre que os itens
         não traziam parcelas — no arquivo entregue ao cliente a aba Gráficos
         saía com dois gráficos em vez de três, sem aviso, enquanto o Resumo
         do mesmo arquivo mostrava a quebra pela base analítica. */
      var qb = _quebraMoMatEq(orc, deps);
      if (qb.mo + qb.mat + qb.eq > 0) {
        g.moMatEq = _pngPizza([
          { rotulo: 'Mão de obra', valor: qb.mo, cor: '#2563eb' },
          { rotulo: 'Material', valor: qb.mat, cor: COR.verde },
          { rotulo: 'Equipamento', valor: qb.eq, cor: COR.amarelo }
        ], fmtNum);
      }
    } catch (e) { if (global.console) console.warn('[excel graficos]', e); }
    return (g.abc || g.curvaS || g.moMatEq) ? g : null;
  }

  // ---------- Construtor PURO do workbook (testável em Node) ----------
  // deps: { num(v), fmtNum(v,casas), empresa }
  function construir(ExcelJS, orc, deps) {
    // White-label: a planilha é da EMPRESA DO CLIENTE (deps.empresa); o crédito do
    // produto (deps.credito) é opcional — "" quando o cliente desliga em ⚙ Empresa.
    var num = deps.num, fmtNum = deps.fmtNum, empresa = deps.empresa || "";
    var credito = deps.credito || "";
    var bdiPct = num(orc.bdi && orc.bdi.percentual) || 0;
    var etapas = Array.isArray(orc.etapas) ? orc.etapas : [];

    /* ---- Política de ARREDONDAMENTO (Passo 2 do assistente) ----
     * A planilha é VIVA (fórmulas). Se as fórmulas não seguirem o mesmo
     * critério do app, o cliente abre o xlsx e vê um total diferente do
     * orçamento — em licitação isso vira impugnação. Então cada fórmula sai
     * embrulhada em TRUNC()/ROUND() conforme o modo, e a incidência do BDI
     * (unitário × final) muda de onde o BDI entra. */
    var _A = global.Arred || (function () {
      if (typeof require !== "function") return null;
      try { return require("./arredondamento.js"); } catch (e) { return null; }
    })();
    var cfgArr = (global.Orcamento && Orcamento.garantirConfig)
      ? Orcamento.garantirConfig(orc)
      : { arredondamento: "truncar2", bdiIncidencia: "unitario" };
    var modoArr = cfgArr.arredondamento, incBdi = cfgArr.bdiIncidencia;
    var aVal = function (v) { return _A ? _A.valor(v, modoArr) : num(v); };
    var aUni = function (v) { return _A ? _A.unitario(v, modoArr) : num(v); };
    // Valores por item vêm da FONTE ÚNICA do app (Orcamento.calcular) — o xlsx
    // não recalcula nada por conta própria, senão volta a divergir da tela.
    var _calc = (global.Orcamento && Orcamento.calcular) ? Orcamento.calcular(orc) : null;
    /* Unidade formatada UMA vez para o arquivo inteiro. A Analítica normalizava e
       a Curva ABC, a Memória de Cálculo e a aba Dados IA saíam CRUAS — duas
       grafias da mesma unidade dentro do MESMO .xlsx entregue ao cliente. */
    var _un = function (u) {
      return (typeof Util !== 'undefined' && Util.unidadeDe) ? (Util.unidadeDe(u, orc) || 'un') : (u || 'un');
    };
    var _linhaDe = {};
    if (_calc) _calc.linhas.forEach(function (L) { _linhaDe[L.etapaIdx + "|" + L.itemIdx] = L; });
    function fWrap(expr, ehUnitario) {
      if (modoArr === "nenhum") return expr;
      var trunca = (modoArr === "truncar2") || (ehUnitario && modoArr === "arred2truncpu");
      return (trunca ? "TRUNC(" : "ROUND(") + expr + ",2)";
    }
    var fV = function (e) { return fWrap(e, false); };  // valores/totais
    var fU = function (e) { return fWrap(e, true); };   // preço unitário
    var bdiNoPU = (incBdi !== "final");
    var cronoTotRef = null, resumoChecksRow = 0; // refs p/ os checks de sanidade (FASE 2)

    var wb = new ExcelJS.Workbook();
    wb.creator = deps.creator || empresa || "Orçamento"; wb.created = orc.criadoEm ? new Date(orc.criadoEm) : undefined;
    // FASE 2: recalcular tudo ao abrir — sem isso, LibreOffice (e Excel em
    // alguns fluxos) exibe os valores congelados da emissão após o cliente editar.
    wb.calcProperties = { fullCalcOnLoad: true };
    wb.definedNames.add(BDI_ADDR, BDI_CELL); // p_BDI -> Resumo!$B$6

    // abas na ORDEM de exibição pedida: Resumo, Sintética, Analítica
    var wr  = wb.addWorksheet(SH_RES,  { properties: { tabColor: { argb: verde } } });
    var wsi = wb.addWorksheet(SH_SINT, { properties: { tabColor: { argb: aco } },  views: [{ state: 'frozen', ySplit: 6 }] });
    var wa  = wb.addWorksheet(SH_ANAL, { properties: { tabColor: { argb: navy } }, views: [{ state: 'frozen', ySplit: 6 }] });
    var abc = deps.abc, crono = deps.crono, insMap = deps.insumosMap; // opcionais
    // FASE 2 lote 6: aba Parâmetros (matriz de desembolso) — criada aqui p/ ficar
    // logo após a Analítica na ordem das abas; preenchida mais abaixo.
    var wpar = crono ? wb.addWorksheet('Parâmetros', { properties: { tabColor: { argb: 'FFF59E0B' } }, views: [{ state: 'frozen', ySplit: 5 }] }) : null;
    var wins = insMap ? wb.addWorksheet("Insumos", { properties: { tabColor: { argb: 'FF0EA5E9' } }, views: [{ state: 'frozen', ySplit: 5 }] }) : null;
    var wabc = abc   ? wb.addWorksheet("Curva ABC",  { properties: { tabColor: { argb: 'FFF59E0B' } }, views: [{ state: 'frozen', ySplit: 7 }] }) : null;
    var wcr  = crono ? wb.addWorksheet("Cronograma", { properties: { tabColor: { argb: 'FF8B5CF6' } }, views: [{ state: 'frozen', ySplit: 4 }] }) : null;

    /* ===== v1.1.225 — destino do memorial (Parâmetros do orçamento) =====
       A aba "Memória de Cálculo" existe desde a 1.1.217 e SEMPRE saiu quando
       havia memória. A partir daqui ela passa a obedecer a um parâmetro — e é
       aí que mora a armadilha, que quase foi para a frota.

       Não basta ler `excel !== false`. A 1.1.224 GRAVOU `excel:false` no dado
       do cliente, explícito, em dois pontos: ao criar orçamento
       (orcwizard.js `_criar`) e a CADA Salvar em Parâmetros
       (orcwizard.js `_salvarParametros`) — inclusive de orçamento antigo em que
       o usuário só foi mexer no BDI. Naquela versão nada lia o campo, então
       ninguém escolheu aquele `false`: ele é entulho de um default meu.

       Ler o `false` como escolha arrancaria a aba de quem já tinha — a aba de
       justificativa de quantitativos (art. 23 da Lei 14.133) sumindo calada do
       xlsx entregue. Por isso a escolha é VERSIONADA: só vale como escolha do
       usuário o que foi gravado pela 1.1.225 em diante (`v >= 2`). O que veio
       sem carimbo é entulho e cai no comportamento de sempre — a aba sai. */
    var _cfgMemX = (orc.config && orc.config.memorial) || null;
    var _escolhaMemVale = !!(_cfgMemX && Number(_cfgMemX.v) >= 2);
    var _memNoExcel = !_escolhaMemVale || _cfgMemX.excel !== false;

    // ===================== ANALÍTICA (preenche 1º p/ saber as linhas) =====================
    wa.columns = [{ width: 6 }, { width: 12 }, { width: 11 }, { width: 50 }, { width: 7 }, { width: 10 }, { width: 14 }, { width: 15 }, { width: 14 }, { width: 16 }];
    wa.mergeCells('A1:J1'); wa.getCell('A1').value = empresa; wa.getCell('A1').font = { bold: true, size: 14, color: { argb: navy } };
    wa.mergeCells('A2:J2'); wa.getCell('A2').value = 'PLANILHA ORÇAMENTÁRIA ANALÍTICA — ' + (orc.numero || '') + (orc.nome ? ' · ' + orc.nome : ''); wa.getCell('A2').font = { bold: true, size: 11 };
    wa.mergeCells('A3:J3'); wa.getCell('A3').value = 'Cliente: ' + ((orc.cliente && orc.cliente.nome) || '-') + '   |   Obra: ' + ((orc.obra && orc.obra.nome) || '-') + (orc.obra && orc.obra.local ? ' (' + orc.obra.local + ')' : ''); wa.getCell('A3').font = { size: 9, color: { argb: muted } };
    /* ⚠ a ressalva de base velha vai NO DOCUMENTO, nao so na tela de tabelas:
       quem orca e entrega estava assinando preco de anos atras sem saber. */
    var _ressalva = (Orcamento.ressalvaBasesTexto ? Orcamento.ressalvaBasesTexto(orc) : '');
    wa.mergeCells('A4:J4'); wa.getCell('A4').value = Orcamento.basesUsadasTexto(orc) + '   |   BDI ' + fmtNum(bdiPct, 2) + '%   |   ' + (orc.desonerado ? 'Desonerado' : 'Não desonerado'); wa.getCell('A4').font = { italic: true, size: 9, color: { argb: 'FF94A3B8' } };
    if (_ressalva) {
      wa.mergeCells('A5:J5'); wa.getCell('A5').value = _ressalva;
      wa.getCell('A5').font = { italic: true, bold: true, size: 9, color: { argb: 'FFB45309' } };
    }

    var hr = 6, colsA = ['Item', 'Código', 'Fonte', 'Descrição', 'Und', 'Qtd', 'Custo Unit', 'Custo Total',
      bdiNoPU ? 'Preço Unit c/BDI' : 'Preço Unit (BDI no final)', bdiNoPU ? 'Preço Total c/BDI' : 'Preço Total (BDI no final)'];
    colsA.forEach(function (h, i) { hStyle(wa.getRow(hr).getCell(i + 1)); wa.getRow(hr).getCell(i + 1).value = h; });
    // FASE 2: coluna K oculta com a etapa de cada linha de item — âncora dos
    // SUMIFS da Sintética (fim das referências fixas tipo 'Analítica'!H16).
    wa.getRow(hr).getCell(11).value = 'Etapa';
    wa.getColumn(11).width = 14; wa.getColumn(11).hidden = true;
    /* v1.1.225 — a COLUNA do memorial, ao lado do item que ela justifica.
       Vai em L, DEPOIS da última coluna usada, nunca no meio: a Sintética, a
       Curva ABC e a aba Dados IA referenciam a Analítica por LETRA de coluna
       ('Analítica'!F, !H, !J). Inserir no meio deslocaria tudo e quebraria as
       fórmulas em silêncio — o mesmo motivo que já manteve a justificativa de
       preço fora daqui. Em L, nada se desloca.
       A aba "Memória de Cálculo" continua existindo: lá cabe o texto longo e a
       justificativa dos coeficientes; aqui é a leitura de quem confere linha a
       linha sem trocar de aba. */
    if (_memNoExcel) {
      wa.getRow(hr).getCell(12).value = 'Memória de cálculo';
      hStyle(wa.getRow(hr).getCell(12));
      wa.getColumn(12).width = 60;
    }

    var r = hr + 1, n = 0, subCustoCells = [], subVendaCells = [], etInfo = [], grandCusto = 0, grandVenda = 0;
    // quebra MO/MAT/EQ do orçamento inteiro (Resumo + nota de procedência)
    var _qb = _quebraMoMatEq(orc, { num: num, insumosMap: insMap });
    var grandMO = _qb.mo, grandMAT = _qb.mat, grandEQ = _qb.eq;
    var itensFlat = []; // FASE 4 (AI-ready): 1 registro por item p/ a Table tblItens da aba "Dados IA"
    etapas.forEach(function (et, etIdx) {
      // Chave da etapa para os SUMIFS: precisa ser UNICA. Duas etapas com o mesmo
      // nome (ou sem codigo) casavam no mesmo SUMIFS e DOBRAVAM o valor da etapa.
      var etKey = (etIdx + 1) + '|' + (et.codigo || et.nome || 'Etapa');
      wa.mergeCells('A' + r + ':J' + r);
      var bc = wa.getCell('A' + r); bc.value = (etIdx + 1) + '  ' + (et.nome || 'Etapa'); bc.font = { bold: true, color: { argb: branco } }; bc.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: aco } }; bc.border = thin();
      r++;
      var first = r, etCusto = 0, etVenda = 0, _subAtual = null;
      // mapa id→nome das sub etapas desta etapa (o banner precisa do nome)
      var _subNome = {};
      (Array.isArray(et.subetapas) ? et.subetapas : []).forEach(function (sx) { _subNome[sx.id] = sx.nome || 'Sub etapa'; });
      (Array.isArray(et.itens) ? et.itens : []).forEach(function (it, itIdx) {
        var _L0 = _linhaDe[etIdx + "|" + itIdx];
        var _sid = (it.subEtapaId && _subNome[it.subEtapaId]) ? it.subEtapaId : "";
        /* BANNER DA SUB ETAPA — emitido varrendo et.itens NA ORDEM, nunca por uma
         * lista própria: o round-trip (Roundtrip._flatten) casa Excel × snapshot
         * pela ordem de et.itens, e duas ordens diferentes viram
         * "estrutura-alterada" no Excel→app. A coluna K fica VAZIA de propósito:
         * é ela que marca linha de item para os SUMIFS e para o round-trip. */
        if (_sid !== _subAtual) {
          _subAtual = _sid;
          if (_sid) {
            var sb = wa.getRow(r);
            wa.mergeCells('A' + r + ':J' + r);
            var sc = wa.getCell('A' + r);
            sc.value = '     ' + ((_L0 && _L0.subNumero) || '') + '  ' + _subNome[_sid];
            sc.font = { bold: true, italic: true, size: 10, color: { argb: navy } };
            /* cor PRÓPRIA do banner de sub etapa, derivada da faixa da etapa (aco) 30% rumo
           ao branco. Antes usava cinzaSub, que também é o preenchimento do SUBTOTAL da
           etapa — a mesma cor fazendo dois papéis no documento que o cliente assina.
           Texto navy (5,05:1); branco sobre este tom dá 3,00:1 e reprovaria. */
        sc.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF6D9ABB' } };
            sc.border = thin(); sc.alignment = { indent: 1 };
            r++;
          }
        }
        n++; var row = wa.getRow(r);
        var qt = num(it.quantidade), cu = num(it.custoUnitario);
        // valores idênticos aos da tela (fonte única); fallback só se o motor faltar
        var _L = _linhaDe[etIdx + "|" + itIdx];
        var ct = _L ? _L.custoTotal : aVal(qt * aUni(cu));
        var pu = _L ? _L.precoUnit : (bdiNoPU ? aUni(cu * (1 + bdiPct / 100)) : aUni(cu));
        var pt = _L ? _L.precoTotal : aVal(qt * pu);
        etCusto += ct; etVenda += pt;
        // (a quebra MO/MAT/EQ do orçamento sai de _quebraMoMatEq, depois do loop —
        // helper único com a pizza da aba Gráficos; ver o comentário lá em cima)
        // número da FONTE ÚNICA (1.1 ou 1.1.1 quando há sub etapa). Reimplementar
        // aqui era o ponto onde a tela e o xlsx entregue divergiam calados.
        row.getCell(1).value = (_L && _L.numero) ? _L.numero : ((etIdx + 1) + '.' + (itIdx + 1));
        row.getCell(2).value = it.codigo || '';
        // FASE 2: fonte honesta no xlsx — SEINFRA/SETOP/etc. não são "Própria"
        var fonteIt = it.baseFonte || it.origem || '';
        row.getCell(3).value = (!fonteIt || fonteIt === 'PROPRIO') ? 'Própria' : (fonteIt === 'OUTRA' ? 'Outra' : fonteIt);
        row.getCell(4).value = it.descricao || '';
        row.getCell(5).value = _un(it.unidade);
        row.getCell(6).value = qt;
        row.getCell(7).value = cu;
        row.getCell(8).value  = { formula: fV('F' + r + '*' + fU('G' + r)), result: ct };
        row.getCell(9).value  = { formula: bdiNoPU ? fU('G' + r + '*(1+' + BDI_CELL + '/100)') : fU('G' + r), result: pu };
        row.getCell(10).value = { formula: fV('F' + r + '*I' + r), result: pt };
        row.getCell(11).value = etKey; // âncora SUMIFS (coluna oculta; vazia em banner/subtotal)
        if (_memNoExcel && it.memoriaCalculo) {
          row.getCell(12).value = String(it.memoriaCalculo);
          row.getCell(12).alignment = { wrapText: true, vertical: 'top' };
          row.getCell(12).font = { size: 9, color: { argb: muted } };
          row.getCell(12).border = thin();
        }
        itensFlat.push({ r: r, etapa: etKey, n: n, num: (_L && _L.numero) || ((etIdx + 1) + '.' + (itIdx + 1)), qt: qt, cu: cu, ct: ct, pu: pu, pt: pt, it: it });
        row.getCell(6).numFmt = NUM;
        [7, 8, 9, 10].forEach(function (k) { row.getCell(k).numFmt = MOEDA; });
        row.getCell(3).alignment = { horizontal: 'center' };
        for (var k = 1; k <= 10; k++) { row.getCell(k).border = thin(); if (n % 2 === 0) row.getCell(k).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinza } }; }
        // FASE 2: Qtd e Custo Unit editáveis (amarelo claro) — o resto é fórmula travada
        [6, 7].forEach(function (k2) {
          row.getCell(k2).protection = { locked: false };
          row.getCell(k2).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFF9E0' } };
          // validação: número ≥ 0. Texto numa amarela vira #VALUE! em cascata
          // (Custo Total → Sintética → Resumo → ABC) e o cliente vê a planilha
          // inteira "quebrada" sem saber que foi uma vírgula no lugar errado.
          row.getCell(k2).dataValidation = { type: 'decimal', operator: 'greaterThanOrEqual', formulae: [0], showErrorMessage: true, errorTitle: k2 === 6 ? 'Quantidade' : 'Custo unitário', error: 'Informe um número maior ou igual a zero (use vírgula como decimal).' };
        });
        /* PREÇO ALTERADO PELO USUÁRIO: âmbar na célula do Custo Unit + observação
           com o valor da base. Marca NA CÉLULA e não em coluna nova de propósito —
           a Sintética, a Curva ABC e a aba Dados IA referenciam a Analítica por
           LETRA de coluna ('Analítica'!F, !H, !J); inserir uma coluna aqui
           deslocaria tudo e quebraria as fórmulas em silêncio. */
        if (typeof Ajustes !== "undefined" && Ajustes.delta) {
          var _dA = Ajustes.delta(it, "custoUnitario", cu);
          var _coefA = Ajustes.campos(it).filter(function (c) { return c.indexOf("coef:") === 0; });
          if (_dA || _coefA.length) {
            var cCU = row.getCell(7);
            cCU.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFDE8C8' } };
            var nota = [];
            if (_dA) {
              nota.push("Preço alterado por você.");
              nota.push("Na base: " + (_dA.semBase ? "sem preço coletado" : Ajustes.fmtN(_dA.base, 2) +
                (_dA.fonte ? " (" + _dA.fonte + (_dA.competencia ? " " + _dA.competencia : "") + ")" : "")));
              nota.push("Adotado: " + Ajustes.fmtN(_dA.atual, 2));
              if (!_dA.semBase) nota.push("Variação: " + Ajustes.fmtPct(_dA.pct));
              if (_dA.motivo) nota.push("Justificativa: " + _dA.motivo);
              else if (_dA.dif > 0) nota.push("Justificativa: (a registrar)");
            }
            if (_coefA.length) nota.push(_coefA.length + " coeficiente(s) da composição ajustado(s).");
            cCU.note = nota.join("\n");
          }
        }
        r++;
      });
      var last = r - 1, sr = wa.getRow(r);
      sr.getCell(4).value = 'Subtotal — ' + (et.nome || 'Etapa'); sr.getCell(4).font = { bold: true };
      if (last >= first) {
        sr.getCell(8).value = { formula: 'SUM(H' + first + ':H' + last + ')', result: etCusto };
        sr.getCell(10).value = { formula: 'SUM(J' + first + ':J' + last + ')', result: etVenda };
      } else { sr.getCell(8).value = 0; sr.getCell(10).value = 0; }
      [8, 10].forEach(function (k) { sr.getCell(k).numFmt = MOEDA; sr.getCell(k).font = { bold: true }; sr.getCell(k).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinzaSub } }; });
      subCustoCells.push('H' + r); subVendaCells.push('J' + r);
      etInfo.push({ nome: et.nome || 'Etapa', codigo: et.codigo || '', key: etKey, subRow: r, custo: etCusto, venda: etVenda });
      grandCusto += etCusto; grandVenda += etVenda;
      r++;
    });
    grandCusto = aVal(grandCusto);
    // incidência "final": o BDI só entra no fim (não está nos preços unitários)
    grandVenda = bdiNoPU ? aVal(grandVenda) : aVal(grandCusto * (1 + bdiPct / 100));
    r++;
    var gCustoRow = r;
    wa.getCell('D' + r).value = 'CUSTO DIRETO (sem BDI)'; wa.getCell('D' + r).font = { bold: true };
    wa.getCell('H' + r).value = { formula: subCustoCells.join('+') || '0', result: grandCusto }; wa.getCell('H' + r).numFmt = MOEDA; wa.getCell('H' + r).font = { bold: true };
    r++; var gBdiRow = r, gVendaRow = r + 1;
    wa.getCell('D' + r).value = 'BDI (' + fmtNum(bdiPct, 2) + '%)' + (bdiNoPU ? ' — já embutido nos preços unitários' : ' — sobre o preço final');
    wa.getCell('D' + r).font = { bold: true };
    // BDI em R$ = venda − custo (nunca recalculado por fora: com truncamento o
    // "custo × BDI%" solto dá diferença de centavos contra a soma dos itens)
    wa.getCell('H' + r).value = { formula: 'H' + gVendaRow + '-H' + gCustoRow, result: Math.round((grandVenda - grandCusto) * 100) / 100 }; wa.getCell('H' + r).numFmt = MOEDA;
    r++;
    wa.getCell('D' + r).value = 'PREÇO DE VENDA (com BDI)'; wa.getCell('D' + r).font = { bold: true, size: 12, color: { argb: branco } }; wa.getCell('D' + r).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: navy } };
    wa.getCell('H' + r).value = {
      formula: bdiNoPU ? (subVendaCells.join('+') || '0') : fV('H' + gCustoRow + '*(1+' + BDI_CELL + '/100)'),
      result: grandVenda
    };
    wa.getCell('H' + r).numFmt = MOEDA; wa.getCell('H' + r).font = { bold: true, size: 12, color: { argb: branco } }; wa.getCell('H' + r).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: navy } };

    // Última linha coberta pelos SUMIFS que leem a Analítica — a real + folga de 500
    // linhas para o cliente inserir itens no xlsx sem perder valor do total.
    var _fimAnal = Math.max(r + 500, 1006);

    // ===================== SINTÉTICA =====================
    wsi.columns = [{ width: 10 }, { width: 46 }, { width: 16 }, { width: 9 }, { width: 15 }, { width: 17 }, { width: 10 }];
    wsi.mergeCells('A1:G1'); wsi.getCell('A1').value = empresa; wsi.getCell('A1').font = { bold: true, size: 14, color: { argb: navy } };
    wsi.mergeCells('A2:G2'); wsi.getCell('A2').value = 'PLANILHA SINTÉTICA (por etapa) — ' + (orc.numero || ''); wsi.getCell('A2').font = { bold: true, size: 11 };
    wsi.mergeCells('A3:G3'); wsi.getCell('A3').value = 'Cliente: ' + ((orc.cliente && orc.cliente.nome) || '-') + '   |   ' + ((orc.obra && orc.obra.nome) || '-'); wsi.getCell('A3').font = { size: 9, color: { argb: muted } };
    var colsS = ['Item', 'Etapa', 'Custo Direto', 'BDI %', 'BDI (R$)', 'Preço de Venda', 'Peso %'];
    colsS.forEach(function (h, i) { hStyle(wsi.getRow(6).getCell(i + 1)); wsi.getRow(6).getCell(i + 1).value = h; });
    var s0 = 7, sr = s0, totVenda = grandVenda;
    var _sintApp = (global.Orcamento && Orcamento.sintetico) ? Orcamento.sintetico(orc) : null;
    var _totRow = s0 + etInfo.length;          // linha do TOTAL (conhecida de antemão)
    // Com o BDI apartado ("no preço final"), a venda de cada etapa é o custo da
    // etapa + BDI proporcional, e a soma pode ficar 1 centavo longe do total.
    // O resíduo cai na MAIOR etapa — e por FÓRMULA (total − soma das outras),
    // para continuar fechando depois que o cliente editar quantidades no xlsx.
    // A etapa que recebe o resíduo tem que ser a MESMA que o app escolhe em
    // Orcamento.sintetico (maior preço de venda, primeiro máximo) — senão o valor
    // gravado na célula e o valor que a fórmula recalcula ficam 1 centavo distantes.
    var _refMaior = _sintApp || etInfo, _maiorIdx = 0;
    for (var _mi = 1; _mi < _refMaior.length; _mi++) {
      var _a = _sintApp ? _refMaior[_mi].precoVenda : _refMaior[_mi].venda;
      var _b = _sintApp ? _refMaior[_maiorIdx].precoVenda : _refMaior[_maiorIdx].venda;
      if (_a > _b) _maiorIdx = _mi;
    }
    function _somaOutras(idx) {
      var m = s0 + idx, partes = [];
      if (m > s0) partes.push('SUM(F' + s0 + ':F' + (m - 1) + ')');
      if (m < _totRow - 1) partes.push('SUM(F' + (m + 1) + ':F' + (_totRow - 1) + ')');
      // PARÊNTESES obrigatórios: sem eles "F10-SUM(a)+SUM(b)" vira F10−a+b (Excel
      // avalia da esquerda pra direita) e a etapa do meio explodiria ao recalcular.
      return partes.length ? '(' + partes.join('+') + ')' : '0';
    }
    etInfo.forEach(function (et, i) {
      if (_sintApp && _sintApp[i]) { et.custo = _sintApp[i].custoDireto; et.venda = _sintApp[i].precoVenda; }
      else if (!bdiNoPU) { et.venda = aVal(et.custo * (1 + bdiPct / 100)); }
      var row = wsi.getRow(sr);
      row.getCell(1).value = et.codigo || ((i + 1) + '.0');
      row.getCell(2).value = et.nome;
      // FASE 2: SUMIFS pela coluna-âncora K (linhas de item têm a etapa; subtotais
      // ficam vazios) — robusto a inserção/remoção de linhas. A faixa acompanha o
      // tamanho REAL da Analítica (com folga): a faixa fixa até a linha 1006 cortava
      // orçamento grande e a Sintética saía menor que a própria Analítica.
      var kSeg = "'" + SH_ANAL + "'!$K$7:$K$" + _fimAnal, hSeg = "'" + SH_ANAL + "'!$H$7:$H$" + _fimAnal,
          jSeg = "'" + SH_ANAL + "'!$J$7:$J$" + _fimAnal, chave = '"' + String(et.key).replace(/"/g, '""') + '"';
      row.getCell(3).value = { formula: 'SUMIFS(' + hSeg + ',' + kSeg + ',' + chave + ')', result: et.custo };
      row.getCell(4).value = { formula: BDI_CELL, result: bdiPct };
      // venda vem da SOMA dos itens (já arredondados) — não de custo×BDI%
      var fVenda;
      if (bdiNoPU) fVenda = 'SUMIFS(' + jSeg + ',' + kSeg + ',' + chave + ')';
      else if (i === _maiorIdx && etInfo.length > 1) fVenda = 'F' + _totRow + '-' + _somaOutras(i);
      else fVenda = fV('C' + sr + '*(1+' + BDI_CELL + '/100)');
      row.getCell(6).value = { formula: fVenda, result: et.venda };
      row.getCell(5).value = { formula: 'F' + sr + '-C' + sr, result: Math.round((et.venda - et.custo) * 100) / 100 };
      row.getCell(3).numFmt = MOEDA; row.getCell(4).numFmt = PCT; row.getCell(5).numFmt = MOEDA; row.getCell(6).numFmt = MOEDA;
      for (var k = 1; k <= 7; k++) { row.getCell(k).border = thin(); if (i % 2 === 1) row.getCell(k).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinza } }; }
      sr++;
    });
    var sintTot = sr, tr = wsi.getRow(sr);
    tr.getCell(2).value = 'TOTAL';
    tr.getCell(3).value = { formula: 'SUM(C' + s0 + ':C' + (sr - 1) + ')', result: grandCusto };
    tr.getCell(6).value = {
      formula: bdiNoPU ? ('SUM(F' + s0 + ':F' + (sr - 1) + ')') : fV('C' + sr + '*(1+' + BDI_CELL + '/100)'),
      result: totVenda
    };
    tr.getCell(5).value = { formula: 'F' + sr + '-C' + sr, result: Math.round((totVenda - grandCusto) * 100) / 100 };
    [2, 3, 5, 6].forEach(function (k) { tr.getCell(k).font = { bold: true, color: { argb: branco } }; tr.getCell(k).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: navy } }; });
    [3, 5, 6].forEach(function (k) { tr.getCell(k).numFmt = MOEDA; });
    // peso % (precisa do total) — FASE 2: percentual REAL (fração + formato 0.0%),
    // não mais número ×100 com sufixo de texto
    for (var i = 0; i < etInfo.length; i++) {
      var rr = s0 + i, cell = wsi.getCell('G' + rr);
      cell.value = { formula: 'F' + rr + '/$F$' + sintTot, result: totVenda ? (etInfo[i].venda / totVenda) : 0 };
      cell.numFmt = '0.0%';
    }
    // barra de dados no Peso %: o leitor vê de relance qual etapa pesa —
    // segue o valor vivo (recalcula com Qtd/Custo/BDI), ao contrário da pizza
    // da aba Gráficos, que é foto da emissão.
    if (etInfo.length) wsi.addConditionalFormatting({ ref: 'G' + s0 + ':G' + (sintTot - 1), rules: [
      { type: 'dataBar', priority: 1, cfvo: [{ type: 'min' }, { type: 'max' }], color: { argb: aco }, gradient: true, showValue: true, minLength: 0, maxLength: 100 }
    ] });

    // ===================== RESUMO (B6 = BDI parâmetro) =====================
    /* Coluna B larga + quebra de linha: "Bases de preços" e "Licitação" são
       frases inteiras e saíam cortadas na largura 34 — o leitor via "SINAPI
       06/2026 MG · SETOP 0" e tinha que clicar na célula para ler o resto. */
    wr.columns = [{ width: 30 }, { width: 58 }];
    wr.mergeCells('A1:B1'); wr.getCell('A1').value = empresa; wr.getCell('A1').font = { bold: true, size: 16, color: { argb: navy } };
    wr.mergeCells('A2:B2'); wr.getCell('A2').value = 'RESUMO DO ORÇAMENTO — ' + (orc.numero || '') + (orc.nome ? ' · ' + orc.nome : ''); wr.getCell('A2').font = { bold: true, size: 11, color: { argb: muted } };
    var _dtEmis = orc.atualizadoEm ? new Date(orc.atualizadoEm) : new Date();
    wr.mergeCells('A3:B3');
    wr.getCell('A3').value = 'Emissão ' + _dtEmis.toLocaleDateString('pt-BR') + (orc.competenciaSinapi ? '   ·   Competência SINAPI ' + String(orc.competenciaSinapi).replace(/^(\d{4})-(\d{2})$/, '$2/$1') : '') + (orc.uf ? ' · ' + orc.uf : '') + '   ·   ' + (orc.desonerado ? 'Desonerado' : 'Não desonerado');
    wr.getCell('A3').font = { italic: true, size: 9, color: { argb: 'FF94A3B8' } };
    function lin(rw, lab, val, fmt, opt) {
      opt = opt || {};
      var a = wr.getCell('A' + rw), b = wr.getCell('B' + rw);
      a.value = lab; a.font = { bold: true, color: { argb: opt.head ? branco : navy } };
      a.alignment = { vertical: 'top' };
      b.value = val; if (fmt) b.numFmt = fmt;
      b.font = { bold: !!opt.bold || !!opt.head, size: opt.size || 11, color: { argb: opt.head ? branco : 'FF1E293B' } };
      b.alignment = { wrapText: typeof val === 'string', vertical: 'top' };
      if (opt.head) { a.fill = b.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: navy } }; }
      a.border = b.border = thin();
    }
    lin(4, 'Cliente', (orc.cliente && orc.cliente.nome) || '-');
    lin(5, 'Obra / Local', ((orc.obra && orc.obra.nome) || '-') + (orc.obra && orc.obra.local ? ' — ' + orc.obra.local : ''));
    lin(6, 'BDI (%)  ⟵ edite aqui', bdiPct, '0.00');
    wr.getCell('B6').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: amarelo } }; wr.getCell('B6').font = { bold: true };
    wr.getCell('B6').protection = { locked: false }; // FASE 2: input liberado sob proteção
    wr.getCell('B6').dataValidation = { type: 'decimal', operator: 'between', formulae: [0, 100], showErrorMessage: true, errorTitle: 'BDI (%)', error: 'BDI em porcentagem, entre 0 e 100 (ex.: 24,5).' };
    lin(7, 'Bases de preços', Orcamento.basesUsadasTexto(orc));
    lin(8, 'Nº de etapas / itens', etapas.length + ' / ' + n);
    // Parametrização (assistente): categoria/prazo e, quando for o caso, o bloco de licitação
    var _lic = cfgArr.licitacao || {};
    function _dtBr(s) {
      var m = String(s || "").match(/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/);
      return m ? (m[3] + "/" + m[2] + "/" + m[1] + (m[4] ? " " + m[4] + ":" + m[5] : "")) : "";
    }
    if (_lic.ativo) {
      lin(9, 'Licitação', [_lic.tipo || 'Modalidade não informada',
        _lic.processo ? 'Processo ' + _lic.processo : '',
        _dtBr(_lic.abertura) ? 'Abertura ' + _dtBr(_lic.abertura) : '',
        cfgArr.categoria ? 'Categoria: ' + cfgArr.categoria : ''].filter(Boolean).join('  ·  '));
    } else {
      /* Prazo: a data de entrega parametrizada manda; sem ela, o prazo ESTIMADO
         pelo cronograma (mesmo motor da aba Gantt). Antes a linha 9 ficava
         vazia em todo orçamento sem parametrização — e o prazo é a segunda
         pergunta do cliente, depois do preço. */
      var _cAg = deps.cronoAgente, _fD = function (d) { return (d && d.toLocaleDateString) ? d.toLocaleDateString('pt-BR') : ''; };
      var _prazoTxt = _dtBr(cfgArr.prazoEntrega) ? 'entrega ' + _dtBr(cfgArr.prazoEntrega)
        : ((_cAg && _cAg.etapas && _cAg.etapas.length) ? 'prazo estimado ' + _cAg.totalDias + ' dias úteis (~' + _cAg.totalSemanas + ' semanas) · ' + _fD(_cAg.dataInicio) + ' → ' + _fD(_cAg.dataFim) + ' (aba Gantt)' : '');
      if (cfgArr.categoria || _prazoTxt) lin(9, 'Categoria / prazo', [cfgArr.categoria || '—', _prazoTxt].filter(Boolean).join('  ·  '));
    }
    lin(10, 'Custo Direto (sem BDI)', { formula: ref(SH_SINT, 'C' + sintTot), result: grandCusto }, MOEDA, { bold: true });
    // BDI em R$ = venda − custo (com truncamento, "custo × BDI%" não fecha com a soma dos itens)
    lin(11, 'BDI (R$)', { formula: 'B12-B10', result: Math.round((totVenda - grandCusto) * 100) / 100 }, MOEDA, { bold: true });
    lin(12, 'PREÇO DE VENDA', { formula: ref(SH_SINT, 'F' + sintTot), result: totVenda }, MOEDA, { head: true, bold: true, size: 13 });
    lin(13, 'Critério de arredondamento', (_A ? _A.rotulo(modoArr) : modoArr) + (_A && _A.ehPadraoTcu(modoArr) ? '  (Padrão do TCU)' : '')
      + ' · BDI ' + (bdiNoPU ? 'no preço unitário' : 'no preço final'));
    wr.getCell('A14').value = 'Dica: as células AMARELAS são editáveis (BDI aqui · Qtd e Custo na Analítica · % em Parâmetros · Dias, Início e regime na aba Gantt) — tudo recalcula sozinho. A planilha é protegida só contra edição acidental (senha: raeng). Detalhes na aba Leia-me.';
    wr.mergeCells('A14:B15'); wr.getCell('A14').font = { italic: true, size: 9, color: { argb: 'FF94A3B8' } }; wr.getCell('A14').alignment = { wrapText: true, vertical: 'top' };

    // Composição de custo MO/MAT/EQ (parcelas do item ou base analítica — _quebraMoMatEq)
    if (insMap) {
      var gCat = (grandMO + grandMAT + grandEQ) || 1;
      wr.mergeCells('A17:B17'); wr.getCell('A17').value = 'COMPOSIÇÃO DE CUSTO (MO / MAT / EQ)'; wr.getCell('A17').font = { bold: true, color: { argb: navy } };
      lin(18, 'Mão de obra — ' + fmtNum(grandMO / gCat * 100, 1) + '%', grandMO, MOEDA);
      lin(19, 'Material — ' + fmtNum(grandMAT / gCat * 100, 1) + '%', grandMAT, MOEDA);
      lin(20, 'Equipamento — ' + fmtNum(grandEQ / gCat * 100, 1) + '%', grandEQ, MOEDA);
      /* Procedência HONESTA da quebra, em números: quantos itens vieram das
         parcelas do próprio item, quantos da razão da base analítica e
         quantos não têm composição nenhuma (entram como material). O texto
         fixo "itens sem código SINAPI entram como material" não dizia QUANTOS —
         e num orçamento em que metade dos itens caísse aí, o gráfico de pizza
         estaria contando uma história que ninguém tinha como conferir. */
      var _proc = [];
      if (_qb.nItem) _proc.push(_qb.nItem + ' pelas parcelas do item');
      if (_qb.nAna) _proc.push(_qb.nAna + ' pela base analítica' + (deps.analiticoComp ? ' (' + deps.analiticoComp + ')' : ''));
      if (_qb.nMat) _proc.push(_qb.nMat + ' sem composição (→ material)');
      wr.getCell('A21').value = 'Procedência da quebra (' + _qb.n + ' itens): ' + (_proc.join(' · ') || '—') + '. Valores da emissão.';
      wr.mergeCells('A21:B21'); wr.getCell('A21').font = { italic: true, size: 8, color: { argb: 'FF94A3B8' } }; wr.getCell('A21').alignment = { wrapText: true, vertical: 'top' };
    }

    // ===================== QUADRO BDI — Acórdão TCU 2.622/2013 (FASE 2) =====================
    // Usa os parâmetros REAIS do orçamento (orc.bdi.params). Sem parcelas
    // detalhadas -> [PREENCHER]; NUNCA decompor um % seco em números fictícios.
    var bp = (orc.bdi && orc.bdi.params) || {};
    var parcelas = [
      ['AC — Administração Central', bp.AC], ['S — Seguros', bp.S], ['R — Riscos', bp.R],
      ['G — Garantias', bp.G], ['DF — Despesas Financeiras', bp.DF], ['L — Lucro', bp.L],
      ['I — Impostos (PIS/COFINS/ISS/CPRB)', bp.I]
    ];
    var temParcelas = parcelas.some(function (pp) { return num(pp[1]) > 0; });
    var rb = insMap ? 23 : 17;
    wr.mergeCells('A' + rb + ':B' + rb);
    wr.getCell('A' + rb).value = 'COMPOSIÇÃO DO BDI — Acórdão TCU 2.622/2013';
    wr.getCell('A' + rb).font = { bold: true, color: { argb: navy } };
    var r0 = rb + 1;
    parcelas.forEach(function (pp, i) {
      lin(r0 + i, pp[0], temParcelas ? num(pp[1]) / 100 : '[PREENCHER]', temParcelas ? '0.00%' : null);
      if (temParcelas) { // parcela editável: o check TCU abaixo recalcula ao vivo
        var cc = wr.getCell('B' + (r0 + i));
        cc.protection = { locked: false };
        cc.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFF9E0' } };
      }
    });
    var rF = r0 + parcelas.length;
    if (temParcelas) {
      var cAC = 'B' + r0, cS = 'B' + (r0 + 1), cR = 'B' + (r0 + 2), cG = 'B' + (r0 + 3),
          cDF = 'B' + (r0 + 4), cL = 'B' + (r0 + 5), cI = 'B' + (r0 + 6);
      var fTcu = '(1+' + cAC + '+' + cS + '+' + cR + '+' + cG + ')*(1+' + cDF + ')*(1+' + cL + ')/(1-' + cI + ')-1';
      var vTcu = (1 + (num(bp.AC) + num(bp.S) + num(bp.R) + num(bp.G)) / 100) * (1 + num(bp.DF) / 100) * (1 + num(bp.L) / 100) / (1 - num(bp.I) / 100) - 1;
      lin(rF, 'BDI pela fórmula TCU', { formula: fTcu, result: vTcu }, '0.00%', { bold: true });
      lin(rF + 1, 'BDI aplicado (B6)', { formula: '$B$6/100', result: bdiPct / 100 }, '0.00%', { bold: true });
      if (Math.abs(vTcu * 100 - bdiPct) > 0.05) {
        wr.mergeCells('A' + (rF + 2) + ':B' + (rF + 2));
        wr.getCell('A' + (rF + 2)).value = '⚠ BDI aplicado difere da fórmula TCU com estas parcelas — revise antes de licitar.';
        wr.getCell('A' + (rF + 2)).font = { italic: true, size: 8, color: { argb: 'FFDC2626' } };
      }
    } else {
      wr.mergeCells('A' + rF + ':B' + rF);
      wr.getCell('A' + rF).value = 'Modelo de BDI sem parcelas detalhadas — preencha conforme o Acórdão TCU 2.622/2013.';
      wr.getCell('A' + rF).font = { italic: true, size: 8, color: { argb: 'FF94A3B8' } };
    }
    resumoChecksRow = rF + (temParcelas ? 4 : 2); // 1ª linha livre p/ o bloco de verificações

    // ===================== CURVA ABC =====================
    if (wabc) {
      var corCl = { A: 'FF16A34A', B: 'FFF59E0B', C: 'FF94A3B8' };
      wabc.columns = [{ width: 8 }, { width: 12 }, { width: 48 }, { width: 7 }, { width: 10 }, { width: 15 }, { width: 9 }, { width: 10 }];
      wabc.mergeCells('A1:H1'); wabc.getCell('A1').value = empresa; wabc.getCell('A1').font = { bold: true, size: 14, color: { argb: navy } };
      wabc.mergeCells('A2:H2'); wabc.getCell('A2').value = 'CURVA ABC — ' + (orc.numero || ''); wabc.getCell('A2').font = { bold: true, size: 11 };
      ['Classe', 'Itens', 'Valor', '% do total'].forEach(function (h, i) { var c = wabc.getRow(4).getCell(i + 1); c.value = h; c.font = { bold: true, color: { argb: muted } }; });
      // resumo por classe via COUNTIF/SUMIFS sobre a lista (recalcula junto)
      var abcN = (abc.linhas || []).length, abcIni = 9, abcFim = 8 + abcN;
      var rngCl = '$A$' + abcIni + ':$A$' + abcFim, rngVal = '$F$' + abcIni + ':$F$' + abcFim;
      ['A', 'B', 'C'].forEach(function (cl, i) {
        var rr = 5 + i, rs = (abc.resumo && abc.resumo[cl]) || { qtd: 0, valor: 0, pct: 0 };
        wabc.getCell('A' + rr).value = 'Classe ' + cl; wabc.getCell('A' + rr).font = { bold: true, color: { argb: corCl[cl] } };
        wabc.getCell('B' + rr).value = { formula: 'COUNTIF(' + rngCl + ',"' + cl + '")', result: rs.qtd };
        wabc.getCell('C' + rr).value = { formula: 'SUMIFS(' + rngVal + ',' + rngCl + ',"' + cl + '")', result: num(rs.valor) }; wabc.getCell('C' + rr).numFmt = MOEDA;
        wabc.getCell('D' + rr).value = { formula: 'C' + rr + '/SUM(' + rngVal + ')', result: num(rs.pct) / 100 }; wabc.getCell('D' + rr).numFmt = '0.0%';
      });
      var hh = 8, colsABC = ['Classe', 'Código', 'Descrição', 'Und', 'Qtd', 'Custo Total', '%', '% Acum.'];
      colsABC.forEach(function (h, i) { hStyle(wabc.getRow(hh).getCell(i + 1)); wabc.getRow(hh).getCell(i + 1).value = h; });
      // FASE 2: ABC recalculável — custo puxado da Analítica (SUMIFS por código
      // quando o código é único), % / % acum. / classe por fórmula. A ORDEM das
      // linhas é a da emissão; valores e classes recalculam ao editar a Analítica.
      var abcLinhas = abc.linhas || [], abcLast = hh + abcLinhas.length;
      // Unicidade pela RÉGUA DO EXCEL: o SUMIFS é case-insensitive ("abc1" e "ABC1"
      // casam na mesma soma) e trata * ? ~ como curinga — código com esses
      // caracteres nunca pode virar fórmula viva, senão a linha soma o que não é dela.
      var contaCod = {};
      abcLinhas.forEach(function (l) { var cd = String(l.codigo || '').toLowerCase(); contaCod[cd] = (contaCod[cd] || 0) + 1; });
      var somaAbc = 'SUM($F$' + (hh + 1) + ':$F$' + abcLast + ')';
      var ar = hh + 1;
      abcLinhas.forEach(function (l, idx) {
        var row = wabc.getRow(ar);
        var cd = String(l.codigo || '');
        var vivo = cd && cd !== '—' && cd !== '-' && contaCod[cd.toLowerCase()] === 1 && !/[*?~]/.test(cd);
        var fAcum = (ar === hh + 1) ? 'G' + ar : 'H' + (ar - 1) + '+G' + ar;
        row.getCell(1).value = { formula: 'IF(H' + ar + '<=0.8,"A",IF(H' + ar + '<=0.95,"B","C"))', result: l.classe };
        row.getCell(1).alignment = { horizontal: 'center' }; row.getCell(1).font = { bold: true, color: { argb: corCl[l.classe] || navy } };
        row.getCell(2).value = l.codigo || ''; row.getCell(3).value = l.descricao || ''; row.getCell(4).value = _un(l.unidade) || '';
        row.getCell(5).value = num(l.quantidade); row.getCell(5).numFmt = NUM;
        row.getCell(6).value = vivo
          ? { formula: "SUMIFS('" + SH_ANAL + "'!$H$7:$H$" + _fimAnal + ",'" + SH_ANAL + "'!$B$7:$B$" + _fimAnal + ",B" + ar + ')', result: num(l.custoTotal) }
          : num(l.custoTotal);
        row.getCell(6).numFmt = MOEDA;
        row.getCell(7).value = { formula: 'F' + ar + '/' + somaAbc, result: num(l.pct) / 100 }; row.getCell(7).numFmt = '0.0%';
        row.getCell(8).value = { formula: fAcum, result: num(l.acumPct) / 100 }; row.getCell(8).numFmt = '0.0%';
        for (var k = 1; k <= 8; k++) { row.getCell(k).border = thin(); if (idx % 2 === 1) row.getCell(k).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinza } }; }
        ar++;
      });
      if (abcLinhas.length) {
        // filtro no header + barra de dados no % de cada item: a lista ABC é a
        // que o cliente mais ordena/filtra ("só a classe A", "só esta etapa").
        // protOpts libera autoFilter/sort mesmo com a aba protegida.
        wabc.autoFilter = 'A' + hh + ':H' + abcLast;
        wabc.addConditionalFormatting({ ref: 'G' + (hh + 1) + ':G' + abcLast, rules: [
          { type: 'dataBar', priority: 1, cfvo: [{ type: 'min' }, { type: 'max' }], color: { argb: 'FFF59E0B' }, gradient: true, showValue: true, minLength: 0, maxLength: 100 }
        ] });
      }
      var abcNota = wabc.getCell('A' + (abcLast + 2));
      abcNota.value = 'Ordem das linhas = emissão. Valores, %, classes e o resumo acima recalculam ao editar Qtd/Custo na Analítica. Use o filtro do cabeçalho para ver só uma classe.';
      wabc.mergeCells('A' + (abcLast + 2) + ':H' + (abcLast + 2));
      abcNota.font = { italic: true, size: 8, color: { argb: 'FF94A3B8' } };
    }

    // ===================== PARÂMETROS: matriz de desembolso etapa×mês =====================
    // % editáveis (amarelas) que DIRIGEM o Cronograma por fórmula. Cada linha
    // precisa somar 100% — a coluna Check acusa ao vivo.
    if (wpar) {
      var Mp = crono.meses || 0, etsP = crono.etapas || [];
      var wcolsP = [{ width: 34 }];
      for (var mp = 0; mp < Mp; mp++) wcolsP.push({ width: 9 });
      wcolsP.push({ width: 10 }, { width: 12 });
      wpar.columns = wcolsP;
      wpar.mergeCells(1, 1, 1, Mp + 3); wpar.getCell('A1').value = empresa; wpar.getCell('A1').font = { bold: true, size: 14, color: { argb: navy } };
      wpar.mergeCells(2, 1, 2, Mp + 3); wpar.getCell('A2').value = 'PARÂMETROS — MATRIZ DE DESEMBOLSO (' + Mp + ' meses) — ' + (orc.numero || ''); wpar.getCell('A2').font = { bold: true, size: 11 };
      wpar.mergeCells(3, 1, 3, Mp + 3); wpar.getCell('A3').value = 'Edite os % (células amarelas): o Cronograma e a Curva S recalculam sozinhos. Cada linha deve somar 100% — a coluna Check avisa.'; wpar.getCell('A3').font = { italic: true, size: 9, color: { argb: 'FF94A3B8' } };
      /* rótulo de mês/ano de verdade quando a distribuição segue o Gantt: a
         coluna É um mês do calendário, e "Mês 1" obrigava o cliente a contar
         nos dedos a partir do início da obra. */
      var rotM = crono.rotulos || null;
      var hp = ['Etapa']; for (var mp2 = 0; mp2 < Mp; mp2++) hp.push(rotM && rotM[mp2] ? rotM[mp2] : 'Mês ' + (mp2 + 1)); hp.push('Soma', 'Check');
      hp.forEach(function (h, i) { hStyle(wpar.getRow(5).getCell(i + 1)); wpar.getRow(5).getCell(i + 1).value = h; });
      etsP.forEach(function (et, i) {
        var pr = 6 + i, rowP = wpar.getRow(pr), tot = num(et.total);
        rowP.getCell(1).value = (et.codigo ? et.codigo + ' ' : '') + (et.nome || 'Etapa'); rowP.getCell(1).border = thin();
        var somaFrac = 0;
        for (var m3 = 0; m3 < Mp; m3++) {
          var frac = tot > 0 ? num(et.meses[m3]) / tot : 0;
          somaFrac += frac;
          var cP = rowP.getCell(2 + m3);
          cP.value = frac; cP.numFmt = '0.0%'; cP.border = thin();
          cP.protection = { locked: false };
          cP.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFF9E0' } };
          // 0..1 (a célula mostra %): "30" no lugar de "30%" faria a etapa
          // desembolsar 3.000% num mês e o Check acusaria sem dizer o motivo.
          cP.dataValidation = { type: 'decimal', operator: 'between', formulae: [0, 1], showErrorMessage: true, errorTitle: 'Percentual do mês', error: 'Digite a fração do mês em % (ex.: 30%) — entre 0% e 100%.' };
        }
        var colSoma = wpar.getColumn(Mp + 2).letter, colFirstP = wpar.getColumn(2).letter, colLastP = wpar.getColumn(Mp + 1).letter;
        rowP.getCell(Mp + 2).value = { formula: 'SUM(' + colFirstP + pr + ':' + colLastP + pr + ')', result: somaFrac };
        rowP.getCell(Mp + 2).numFmt = '0.0%'; rowP.getCell(Mp + 2).font = { bold: true }; rowP.getCell(Mp + 2).border = thin();
        var okSoma = Math.abs(somaFrac - 1) <= 0.001;
        rowP.getCell(Mp + 3).value = { formula: 'IF(ABS(' + colSoma + pr + '-1)>0.001,"⚠ ≠100%","OK")', result: okSoma ? 'OK' : '⚠ ≠100%' };
        rowP.getCell(Mp + 3).font = { bold: true, color: { argb: okSoma ? verde : 'FFDC2626' } }; rowP.getCell(Mp + 3).border = thin();
      });
    }

    // ===================== CRONOGRAMA FÍSICO-FINANCEIRO =====================
    if (wcr) {
      var M = crono.meses || 0, totalIdx = M + 2;
      var ws2 = [{ width: 34 }]; for (var m = 0; m < M; m++) ws2.push({ width: 13 }); ws2.push({ width: 15 });
      wcr.columns = ws2;
      var colFirst = wcr.getColumn(2).letter, colLast = wcr.getColumn(M + 1).letter;
      wcr.mergeCells(1, 1, 1, totalIdx); wcr.getCell('A1').value = empresa; wcr.getCell('A1').font = { bold: true, size: 14, color: { argb: navy } };
      wcr.mergeCells(2, 1, 2, totalIdx); wcr.getCell('A2').value = 'CRONOGRAMA FÍSICO-FINANCEIRO (' + M + ' meses, com BDI) — ' + (orc.numero || ''); wcr.getCell('A2').font = { bold: true, size: 11 };
      var rotC = crono.rotulos || null;
      var ch = 4, chdr = ['Etapa']; for (var m = 0; m < M; m++) chdr.push(rotC && rotC[m] ? rotC[m] : 'Mês ' + (m + 1)); chdr.push('Total');
      chdr.forEach(function (h, i) { hStyle(wcr.getRow(ch).getCell(i + 1)); wcr.getRow(ch).getCell(i + 1).value = h; });
      var cr = ch + 1, firstData = cr;
      // FASE 2 lote 6: mês = preço da etapa (Sintética) × % da matriz de Parâmetros.
      // Só liga a fórmula se as etapas do crono alinham 1:1 com a Sintética.
      var etsOk = wpar && (crono.etapas || []).length === etInfo.length &&
        (crono.etapas || []).every(function (e, i) { return String(e.codigo || '') === String(etInfo[i].codigo || ''); });
      (crono.etapas || []).forEach(function (et, idx) {
        var row = wcr.getRow(cr);
        row.getCell(1).value = (et.codigo ? et.codigo + ' ' : '') + (et.nome || 'Etapa');
        for (var m = 0; m < M; m++) {
          var c = row.getCell(2 + m);
          c.value = etsOk
            ? { formula: "'" + SH_SINT + "'!$F$" + (s0 + idx) + "*'Parâmetros'!" + wpar.getColumn(2 + m).letter + (6 + idx), result: num(et.meses[m]) }
            : num(et.meses[m]);
          c.numFmt = MOEDA; c.border = thin();
        }
        row.getCell(totalIdx).value = { formula: 'SUM(' + colFirst + cr + ':' + colLast + cr + ')', result: num(et.total) };
        row.getCell(totalIdx).numFmt = MOEDA; row.getCell(totalIdx).font = { bold: true };
        row.getCell(1).border = thin(); row.getCell(totalIdx).border = thin();
        if (idx % 2 === 1) for (var k = 1; k <= totalIdx; k++) if (!row.getCell(k).fill) row.getCell(k).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinza } };
        cr++;
      });
      var lastData = cr - 1, tot = wcr.getRow(cr);
      tot.getCell(1).value = 'TOTAL / MÊS'; tot.getCell(1).font = { bold: true, color: { argb: branco } }; tot.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: navy } };
      for (var m = 0; m < M; m++) {
        var L = wcr.getColumn(2 + m).letter, c = tot.getCell(2 + m);
        c.value = { formula: 'SUM(' + L + firstData + ':' + L + lastData + ')', result: num(crono.totaisMes[m]) };
        c.numFmt = MOEDA; c.font = { bold: true, color: { argb: branco } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: navy } };
      }
      tot.getCell(totalIdx).value = { formula: 'SUM(' + colFirst + cr + ':' + colLast + cr + ')', result: num(crono.total) };
      tot.getCell(totalIdx).numFmt = MOEDA; tot.getCell(totalIdx).font = { bold: true, color: { argb: branco } }; tot.getCell(totalIdx).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: navy } };
      var totColL = wcr.getColumn(totalIdx).letter;
      cronoTotRef = "'Cronograma'!$" + totColL + '$' + cr; // p/ check de sanidade no Resumo
      // FASE 2: % acumulado por FÓRMULA (curva S viva) — Σ dos meses até m / total
      var acc = wcr.getRow(cr + 1);
      acc.getCell(1).value = '% acumulado'; acc.getCell(1).font = { bold: true, color: { argb: muted } };
      for (var m = 0; m < M; m++) {
        var L2 = wcr.getColumn(2 + m).letter, c2 = acc.getCell(2 + m);
        c2.value = { formula: 'SUM($' + colFirst + '$' + cr + ':' + L2 + cr + ')/$' + totColL + '$' + cr, result: num(crono.acumPct[m]) / 100 };
        c2.numFmt = '0.0%'; c2.font = { color: { argb: muted } };
      }
    }

    // ===================== INSUMOS (composições explodidas) =====================
    if (wins) {
      var catNome = { MO: 'Mão de obra', MAT: 'Material', EQ: 'Equipamento' };
      wins.columns = [{ width: 10 }, { width: 11 }, { width: 11 }, { width: 46 }, { width: 6 }, { width: 11 }, { width: 13 }, { width: 13 }, { width: 13 }];
      wins.mergeCells('A1:I1'); wins.getCell('A1').value = empresa; wins.getCell('A1').font = { bold: true, size: 14, color: { argb: navy } };
      wins.mergeCells('A2:I2'); wins.getCell('A2').value = 'DETALHAMENTO DE COMPOSIÇÕES (INSUMOS) — ' + (orc.numero || ''); wins.getCell('A2').font = { bold: true, size: 11 };
      wins.mergeCells('A3:I3'); wins.getCell('A3').value = 'Cada composição (SINAPI e próprias) explodida nos seus insumos (referência analítica ' + (deps.analiticoComp || '') + '). MO = mão de obra · MAT = material · EQ = equipamento.'; wins.getCell('A3').font = { italic: true, size: 9, color: { argb: 'FF94A3B8' } };
      var hi = ['Composição', 'Cód. Item', 'Tipo', 'Insumo', 'Und', 'Coef.', 'Custo Unit', 'Custo Total', 'Categoria'];
      hi.forEach(function (h, i) { hStyle(wins.getRow(5).getCell(i + 1)); wins.getRow(5).getCell(i + 1).value = h; });
      var ir = 6, vistos = {};
      (etapas).forEach(function (et) {
        (Array.isArray(et.itens) ? et.itens : []).forEach(function (it) {
          // v1.1.123 — composições PRÓPRIAS também saem explodidas (o montarMapa
          // já as coloca no insMap com a mesma estrutura)
          if (it.origem !== 'SINAPI' && it.origem !== 'PROPRIA') return;
          var a = insMap[String(it.codigo)];
          if (!a || vistos[it.codigo]) return;
          vistos[it.codigo] = 1;
          wins.mergeCells('A' + ir + ':I' + ir);
          var bc = wins.getCell('A' + ir); bc.value = it.codigo + '  ' + (a.descricao || it.descricao || ''); bc.font = { bold: true, color: { argb: branco } }; bc.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: aco } }; bc.border = thin();
          ir++;
          var insFirst = ir, somaComp = 0;
          (Array.isArray(a.insumos) ? a.insumos : []).forEach(function (ins, idx) {
            var row = wins.getRow(ir);
            row.getCell(1).value = it.codigo;
            row.getCell(2).value = ins.codigo;
            row.getCell(3).value = (ins.tipo === 'COMPOSICAO') ? 'Sub-comp.' : 'Insumo';
            row.getCell(4).value = ins.descricao;
            row.getCell(5).value = _un(ins.unidade);
            row.getCell(6).value = num(ins.coeficiente); row.getCell(6).numFmt = '#,##0.0000';
            row.getCell(7).value = num(ins.custoUnitario); row.getCell(7).numFmt = MOEDA;
            // FASE 2: custo total do insumo por fórmula (coef × custo unit)
            row.getCell(8).value = { formula: 'F' + ir + '*G' + ir, result: num(ins.custoTotal) }; row.getCell(8).numFmt = MOEDA;
            somaComp += num(ins.custoTotal);
            row.getCell(9).value = catNome[ins.categoria] || ins.categoria;
            for (var k = 1; k <= 9; k++) { row.getCell(k).border = thin(); if (idx % 2 === 1) row.getCell(k).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinza } }; }
            ir++;
          });
          var sr = wins.getRow(ir);
          sr.getCell(4).value = 'Σ  MO ' + fmtNum(a.custoMO, 2) + '  |  MAT ' + fmtNum(a.custoMAT, 2) + '  |  EQ ' + fmtNum(a.custoEQ, 2);
          sr.getCell(4).font = { bold: true, italic: true, color: { argb: muted } };
          sr.getCell(8).value = (ir > insFirst)
            ? { formula: 'SUM(H' + insFirst + ':H' + (ir - 1) + ')', result: somaComp }
            : num(a.custoUnitario);
          sr.getCell(8).numFmt = MOEDA; sr.getCell(8).font = { bold: true }; sr.getCell(8).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinzaSub } };
          ir++;
        });
      });
      // filtro no header: "só Material" vira a lista de compras da obra; "só a
      // composição 89464" isola um serviço. As faixas mescladas (título de cada
      // composição) somem ao filtrar por categoria — é o esperado, não defeito.
      if (ir > 6) wins.autoFilter = 'A5:I' + (ir - 1);
    }

    // ===================== GANTT (agente de cronograma) =====================
    /* GANTT VIVO. Até a 1.2.30 a aba era uma FOTO: barras pintadas na emissão,
     * datas em texto. O cliente mudava "Dias" e nada acompanhava — pior que
     * não ter a coluna, porque parecia editável. Agora é o CPM do app
     * (Cronograma.estimar) reescrito em fórmula, célula a célula:
     *   E início  = MAX(0, fim de cada predecessora + deslocamento do elo)
     *   F fim     = E + C (dias)
     *   G folga   = MAX(0, MIN(prazo total, início tardio de cada sucessora) − F)
     *   H/I datas = WORKDAY (5 dias/semana) · WORKDAY.INTL(…,11) (6) · soma
     *               simples (7) — os mesmos três regimes de addDiasUteis()
     *   J crítico = folga zero
     *   barras    = formatação condicional por expressão sobre E/F — nada de
     *               preenchimento estático; a barra anda quando o número anda.
     * Os `result` gravados em cada fórmula são os do motor, então o arquivo
     * abre idêntico ao app e a suíte confere fórmula × motor um a um.
     * ⚠ Rede com CICLO não vira fórmula: referência circular trava o Excel
     * inteiro em aviso. Nesse caso (raro; a tela já avisa) saem os valores
     * fixos da emissão, e a linha 3 diz isso. */
    var cronoAg = deps.cronoAgente, wg = null, wfer = null;
    if (cronoAg && cronoAg.etapas && cronoAg.etapas.length) {
      var fmtData = function (d) { return (d && d.toLocaleDateString) ? d.toLocaleDateString('pt-BR') : ''; };
      // data "pura" em UTC: o ExcelJS grava serial pela hora UTC; meia-noite
      // local (UTC−3) viraria 0,125 de fração e WORKDAY trunca — o dia fica
      // certo, mas B4+E (regime de 7 dias) arrastaria a fração para as datas.
      var dUTC = function (d) { return new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())); };
      var nSem = cronoAg.totalSemanas || 1, dpw = (cronoAg.params && cronoAg.params.diasUteisSemana) || 5;
      var parAg = (cronoAg.params && cronoAg.params.paralelismo != null) ? num(cronoAg.params.paralelismo) : 0.15;
      var vivo = !cronoAg.temCiclo;
      // 4 semanas de folga nas colunas: o cliente alonga uma etapa no Excel e a
      // barra ainda tem onde aparecer (a suíte confere que o total cabe).
      var nSemCols = nSem + 4, C0 = 11, gLast = 6 + cronoAg.etapas.length; // K = 1ª semana; linha 6 = header
      /* ⚠ FERIADO TAMBÉM NO EXCEL. A aba abre com as mesmas datas do app; se as
       * fórmulas não conhecessem os feriados, bastava o cliente encostar num
       * "Dias" para o Excel recalcular TUDO sem eles e devolver uma entrega
       * mais cedo que a do PDF — duas datas para a mesma obra, e a otimista na
       * mão de quem cobra. O range aponta para a aba Feriados (editável: quem
       * tem feriado municipal acrescenta lá e o Gantt inteiro acompanha).
       * O regime de 7 dias usa a máscara "0000000" (nenhum dia de descanso
       * semanal), que é o WORKDAY.INTL parando SÓ em feriado — a soma simples
       * `$B$4+dias` de antes não tinha como descontar nada. */
      var ferLista = ((cronoAg.feriados && cronoAg.feriados.lista) || []);
      var FERR = ferLista.length ? ",Feriados!$A$3:$A$" + (2 + Math.max(60, ferLista.length + 20)) : "";
      var fData = ferLista.length
        ? function (refDias) {
          return 'IF($D$4>=7,_xlfn.WORKDAY.INTL($B$4,' + refDias + ',"0000000"' + FERR + '),' +
            'IF($D$4=6,_xlfn.WORKDAY.INTL($B$4,' + refDias + ',11' + FERR + '),WORKDAY($B$4,' + refDias + FERR + ')))';
        }
        : function (refDias) { return 'IF($D$4>=7,$B$4+' + refDias + ',IF($D$4=6,_xlfn.WORKDAY.INTL($B$4,' + refDias + ',11),WORKDAY($B$4,' + refDias + ')))'; };
      var _amar = function (c) { c.protection = { locked: false }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: amarelo } }; c.font = { bold: true }; c.border = thin(); };
      wg = wb.addWorksheet("Gantt", { properties: { tabColor: { argb: 'FF0EA5E9' } }, views: [{ state: 'frozen', xSplit: 3, ySplit: 6, showGridLines: false }] });
      /* aba FERIADOS: o range que as fórmulas de data consultam. Fica editável
         (linhas desbloqueadas) porque feriado municipal o app não adivinha —
         quem sabe onde a obra fica escreve a data aqui e o Gantt inteiro anda. */
      if (ferLista.length) {
        wfer = wb.addWorksheet("Feriados", { properties: { tabColor: { argb: 'FF94A3B8' } }, views: [{ state: 'frozen', ySplit: 2, showGridLines: false }] });
        wfer.columns = [{ width: 14 }, { width: 42 }, { width: 20 }];
        wfer.mergeCells('A1:C1');
        wfer.getCell('A1').value = 'FERIADOS DESCONTADOS DO PRAZO — acrescente aqui os feriados da sua cidade (o Gantt recalcula sozinho)';
        wfer.getCell('A1').font = { bold: true, size: 10, color: { argb: navy } };
        ['Data', 'Feriado', 'Tipo'].forEach(function (h, i) { hStyle(wfer.getRow(2).getCell(i + 1)); wfer.getRow(2).getCell(i + 1).value = h; });
        var ferLim = 2 + Math.max(60, ferLista.length + 20);
        for (var fi = 3; fi <= ferLim; fi++) {
          var f = ferLista[fi - 3], rf = wfer.getRow(fi);
          if (f) {
            rf.getCell(1).value = new Date(Date.UTC(+f.data.slice(0, 4), +f.data.slice(5, 7) - 1, +f.data.slice(8, 10)));
            rf.getCell(2).value = f.nome;
            rf.getCell(3).value = f.tipo === 'facultativo' ? 'ponto facultativo' : (f.tipo === 'local' ? 'local (informado)' : 'nacional');
          }
          rf.getCell(1).numFmt = 'dd/mm/yyyy';
          // toda a área é editável: as linhas vazias são o espaço para acrescentar
          [1, 2, 3].forEach(function (cn) { rf.getCell(cn).protection = { locked: false }; rf.getCell(cn).border = thin(); });
          if (!f) rf.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: amarelo } };
        }
        wfer.getCell('A' + (ferLim + 2)).value = 'Carnaval e Corpus Christi são ponto facultativo, não feriado nacional — entram porque a obra para. Apague a linha se a sua equipe trabalha nesses dias.';
        wfer.getCell('A' + (ferLim + 2)).font = { italic: true, size: 8, color: { argb: muted } };
        wfer.mergeCells('A' + (ferLim + 2) + ':C' + (ferLim + 2));
      }
      // C e E com 10: os rótulos dos parâmetros (linha 4/5) moram nelas — a 7/8
      // a foto do Excel real mostrou "s/semana" e "m previsto" cortados.
      var gcols = [{ width: 34 }, { width: 15 }, { width: 10 }, { width: 14 }, { width: 10 }, { width: 8 }, { width: 8 }, { width: 11 }, { width: 11 }, { width: 8 }];
      for (var gs = 0; gs < nSemCols; gs++) gcols.push({ width: 3.4 });
      wg.columns = gcols;
      var gLastCol = C0 + nSemCols - 1, gLastL = wg.getColumn(gLastCol).letter, kL = wg.getColumn(C0).letter;
      wg.mergeCells(1, 1, 1, gLastCol); wg.getCell('A1').value = empresa; wg.getCell('A1').font = { bold: true, size: 14, color: { argb: navy } };
      wg.mergeCells(2, 1, 2, gLastCol); wg.getCell('A2').value = 'CRONOGRAMA FÍSICO / GANTT (CPM) — ' + (orc.numero || '') + (orc.nome ? ' · ' + orc.nome : ''); wg.getCell('A2').font = { bold: true, size: 11 };
      wg.mergeCells(3, 1, 3, gLastCol);
      wg.getCell('A3').value = vivo
        ? 'Cronograma VIVO: edite Dias (coluna C, amarela), a data de início (B4), os dias úteis por semana (D4) e o paralelismo (F4) — início, fim, folga, datas, caminho crítico e barras recalculam. "Depende de" (#nº da etapa, +/−dias de defasagem) é a rede de precedência definida no app (informativa aqui). Emissão: ' + cronoAg.totalDias + ' dias úteis (~' + nSem + ' semanas), ' + fmtData(cronoAg.dataInicio) + ' → ' + fmtData(cronoAg.dataFim) + '.'
        : '⚠ A rede de precedência deste orçamento tem dependência CIRCULAR — os valores abaixo são os da emissão (fixos). Corrija a rede no app (aba Cronograma) e exporte de novo para obter o Gantt recalculável.';
      wg.getCell('A3').font = { italic: true, size: 9, color: { argb: vivo ? muted : 'FFB45309' } }; wg.getCell('A3').alignment = { wrapText: true, vertical: 'top' };
      wg.getRow(3).height = 30;
      // ---- linha 4: PARÂMETROS (amarelos) · linha 5: TOTAIS (fórmula) ----
      var lab = function (addr, txt) { var c = wg.getCell(addr); c.value = txt; c.font = { bold: true, size: 9, color: { argb: navy } }; c.alignment = { horizontal: 'right', vertical: 'middle', wrapText: true }; };
      lab('A4', 'Início da obra'); lab('C4', 'Dias úteis por semana'); lab('E4', 'Paralelismo');
      wg.getRow(4).height = 28;
      var cB4 = wg.getCell('B4'); cB4.value = dUTC(cronoAg.dataInicio); cB4.numFmt = 'dd/mm/yyyy'; _amar(cB4);
      cB4.dataValidation = { type: 'date', operator: 'greaterThan', formulae: [new Date(Date.UTC(2000, 0, 1))], showErrorMessage: true, errorTitle: 'Data de início', error: 'Informe uma data (dd/mm/aaaa).' };
      var cD4 = wg.getCell('D4'); cD4.value = dpw; _amar(cD4); cD4.alignment = { horizontal: 'center' };
      cD4.dataValidation = { type: 'list', allowBlank: false, formulae: ['"5,6,7"'], showErrorMessage: true, errorTitle: 'Dias úteis por semana', error: 'Use 5 (seg–sex), 6 (seg–sáb) ou 7 (corrido).' };
      var cF4 = wg.getCell('F4'); cF4.value = parAg; cF4.numFmt = '0%'; _amar(cF4); cF4.alignment = { horizontal: 'center' };
      cF4.dataValidation = { type: 'decimal', operator: 'between', formulae: [0, 0.9], showErrorMessage: true, errorTitle: 'Paralelismo', error: 'Fração da etapa anterior que a seguinte já começa sobreposta: entre 0% e 90%.' };
      wg.mergeCells('G4:J4'); wg.getCell('G4').value = 'Amarelo = editável. 5 = seg–sex · 6 = seg–sáb · 7 = corrido.'; wg.getCell('G4').font = { italic: true, size: 8, color: { argb: 'FF94A3B8' } }; wg.getCell('G4').alignment = { vertical: 'middle' };
      lab('A5', 'Prazo total (dias úteis)'); lab('C5', 'Semanas'); lab('E5', 'Fim previsto'); lab('H5', 'Etapas críticas');
      var tot5 = function (addr, formula, result, fmt) { var c = wg.getCell(addr); c.value = vivo ? { formula: formula, result: result } : result; if (fmt) c.numFmt = fmt; c.font = { bold: true, color: { argb: navy } }; c.alignment = { horizontal: 'center', vertical: 'middle' }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinza } }; c.border = thin(); };
      tot5('B5', 'MAX(F7:F' + gLast + ')', cronoAg.totalDias, '0');
      tot5('D5', 'ROUNDUP(B5/$D$4,0)', nSem, '0');
      tot5('F5', fData('B5'), dUTC(cronoAg.dataFim), 'dd/mm/yyyy');
      wg.mergeCells('F5:G5');
      tot5('I5', 'COUNTIF(J7:J' + gLast + ',"SIM")', (cronoAg.caminhoCritico || []).length, '0');
      wg.getRow(5).height = 40;
      // ---- header (linha 6) + calendário das semanas (linha 5, girado) ----
      ['Etapa', 'Categoria', 'Dias', 'Depende de', 'Início (d)', 'Fim (d)', 'Folga (d)', 'Data início', 'Data fim', 'Crítico'].forEach(function (h, i) { hStyle(wg.getRow(6).getCell(i + 1)); wg.getRow(6).getCell(i + 1).value = h; });
      wg.getRow(6).height = 30;
      for (var gh = 0; gh < nSemCols; gh++) {
        var hc = wg.getRow(6).getCell(C0 + gh); hStyle(hc);
        // número da semana como NÚMERO (formato "S"0): é a âncora da formatação condicional
        hc.value = gh + 1; hc.numFmt = '"S"0'; hc.alignment = { horizontal: 'center', vertical: 'middle' };
        hc.font = { bold: true, color: { argb: branco }, size: 7 };
        var dc = wg.getRow(5).getCell(C0 + gh), hcL = wg.getColumn(C0 + gh).letter;
        dc.value = vivo ? { formula: '$B$4+7*(' + hcL + '$6-1)', result: new Date(dUTC(cronoAg.dataInicio).getTime() + gh * 7 * 86400000) } : new Date(dUTC(cronoAg.dataInicio).getTime() + gh * 7 * 86400000);
        dc.numFmt = 'dd/mm'; dc.font = { size: 7, color: { argb: muted } }; dc.alignment = { textRotation: 90, horizontal: 'center', vertical: 'bottom' };
      }
      // ---- linhas das etapas ----
      var rowDe = {}, porIdAg = {}, succAg = {};
      cronoAg.etapas.forEach(function (e, i) { rowDe[e.id] = 7 + i; porIdAg[e.id] = e; succAg[e.id] = []; });
      cronoAg.etapas.forEach(function (e) { (e.preds || []).forEach(function (pid) { if (succAg[pid]) succAg[pid].push(e.id); }); });
      var catsVistas = [], catPorNome = {};
      cronoAg.etapas.forEach(function (e, i) {
        var rr = 7 + i, row = wg.getRow(rr);
        var argbCor = 'FF' + String(e.cor || '#0EA5E9').replace('#', '').toUpperCase();
        var catNomeG = e.marco ? '◆ Marco' : (e.categoriaNome || e.categoria || '');
        if (!e.marco && !catPorNome[catNomeG]) { catPorNome[catNomeG] = argbCor; catsVistas.push(catNomeG); }
        row.getCell(1).value = (e.codigo ? e.codigo + ' ' : '') + e.nome;
        row.getCell(2).value = catNomeG;
        var cDias = row.getCell(3); cDias.value = num(e.duracao); cDias.numFmt = '0';
        _amar(cDias); cDias.alignment = { horizontal: 'center' };
        cDias.dataValidation = { type: 'whole', operator: 'greaterThanOrEqual', formulae: [0], showErrorMessage: true, errorTitle: 'Duração', error: 'Dias úteis, inteiro ≥ 0 (0 = marco).' };
        // "Depende de": nº da etapa predecessora + lag explícito (+7 / −3 dias).
        // O "#" não é enfeite: "2" sozinho é texto que parece número, e o Excel
        // marca a célula com o triângulo verde de "número armazenado como texto".
        row.getCell(4).value = (e.preds || []).map(function (pid) {
          var l = e.predLag && e.predLag[pid];
          return '#' + String(rowDe[pid] - 6) + (l != null ? (l >= 0 ? '+' : '') + l + 'd' : '');
        }).join(', ') || (e.preds && e.preds.length === 0 && e.predsExplicito ? '— (dia 0)' : '');
        row.getCell(4).font = { size: 9, color: { argb: muted } }; row.getCell(4).alignment = { horizontal: 'center' };
        // E início
        var fIni = null;
        if (vivo && e.preds && e.preds.length) {
          fIni = 'MAX(0,' + e.preds.map(function (pid) {
            var pr = rowDe[pid], d = e.predDesloc ? e.predDesloc[pid] : 0, lagExp = e.predLag && e.predLag[pid] != null;
            return lagExp ? ('F' + pr + (d >= 0 ? '+' : '-') + Math.abs(d)) : ('F' + pr + '-INT($F$4*C' + pr + ')');
          }).join(',') + ')';
        }
        row.getCell(5).value = fIni ? { formula: fIni, result: e.inicio } : e.inicio;
        // F fim
        row.getCell(6).value = vivo ? { formula: 'E' + rr + '+C' + rr, result: e.fim } : e.fim;
        // G folga: MIN(prazo total, início tardio de cada sucessora − deslocamento do elo) − fim
        var fFolga = null;
        if (vivo) {
          var partesS = succAg[e.id].map(function (sid) {
            var s = porIdAg[sid], sr2 = rowDe[sid], d = s.predDesloc ? s.predDesloc[e.id] : 0, lagExp = s.predLag && s.predLag[e.id] != null;
            return 'E' + sr2 + '+G' + sr2 + (lagExp ? ((d >= 0 ? '-' : '+') + Math.abs(d)) : ('+INT($F$4*C' + rr + ')'));
          });
          fFolga = 'MAX(0,MIN($B$5' + (partesS.length ? ',' + partesS.join(',') : '') + ')-F' + rr + ')';
        }
        row.getCell(7).value = fFolga ? { formula: fFolga, result: num(e.folga) } : num(e.folga);
        // H/I datas · J crítico
        row.getCell(8).value = vivo ? { formula: fData('E' + rr), result: dUTC(e.dataInicio) } : dUTC(e.dataInicio);
        row.getCell(9).value = vivo ? { formula: fData('F' + rr), result: dUTC(e.dataFim) } : dUTC(e.dataFim);
        row.getCell(8).numFmt = row.getCell(9).numFmt = 'dd/mm/yyyy';
        row.getCell(10).value = vivo ? { formula: 'IF(G' + rr + '=0,"SIM","")', result: e.critico ? 'SIM' : '' } : (e.critico ? 'SIM' : '');
        row.getCell(10).font = { bold: true, color: { argb: 'FFDC2626' } };
        [5, 6, 7, 10].forEach(function (k) { row.getCell(k).alignment = { horizontal: 'center' }; row.getCell(k).numFmt = row.getCell(k).numFmt || '0'; });
        for (var k = 1; k <= 10; k++) { row.getCell(k).border = thin(); if (i % 2 === 1 && k !== 3) row.getCell(k).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinza } }; }
        // semanas: célula vazia com borda fina; a barra é FORMATAÇÃO CONDICIONAL
        var s0 = Math.floor(e.inicio / dpw), s1 = Math.max(s0 + 1, Math.ceil(e.fim / dpw));
        for (var gw = 0; gw < nSemCols; gw++) {
          var cc = row.getCell(C0 + gw); cc.border = thin();
          // sem fórmula (ciclo) a barra da emissão vai pintada, como sempre foi
          if (!vivo && gw >= s0 && gw < s1) cc.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: argbCor } };
        }
        if (vivo) {
          /* semana w (1-based, no header K$6) está na barra se
             w > INT(início/dpw) e w <= MAX(INT(início/dpw)+1, ROUNDUP(fim/dpw,0))
             — exatamente a régua do preenchimento estático antigo e do _gantt da
             tela. Crítico (J="SIM") ganha prioridade e sai em vermelho. */
          var refSem = kL + rr + ':' + gLastL + rr;
          var naBarra = 'AND(' + kL + '$6>INT($E' + rr + '/$D$4),' + kL + '$6<=MAX(INT($E' + rr + '/$D$4)+1,ROUNDUP($F' + rr + '/$D$4,0)))';
          wg.addConditionalFormatting({ ref: refSem, rules: [
            { type: 'expression', priority: 2 * i + 1, formulae: ['AND(' + naBarra + ',$J' + rr + '="SIM")'], style: { fill: { type: 'pattern', pattern: 'solid', bgColor: { argb: 'FFDC2626' } } } },
            { type: 'expression', priority: 2 * i + 2, formulae: [naBarra], style: { fill: { type: 'pattern', pattern: 'solid', bgColor: { argb: argbCor } } } }
          ] });
        }
      });
      // ---- legenda + notas ----
      var lg = gLast + 2;
      wg.getCell('A' + lg).value = 'LEGENDA'; wg.getCell('A' + lg).font = { bold: true, color: { argb: navy } };
      catsVistas.forEach(function (nm) {
        lg++; var c = wg.getCell('A' + lg); c.value = nm; c.font = { bold: true, color: { argb: branco }, size: 9 };
        c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: catPorNome[nm] } }; c.alignment = { indent: 1 };
      });
      lg++; var cCrit = wg.getCell('A' + lg); cCrit.value = 'Caminho crítico (folga zero)'; cCrit.font = { bold: true, color: { argb: branco }, size: 9 };
      cCrit.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFDC2626' } }; cCrit.alignment = { indent: 1 };
      lg++; wg.getCell('A' + lg).value = '◆ Marco = etapa de duração zero (entrega, vistoria, liberação): ocupa uma célula na semana em que cai.'; wg.getCell('A' + lg).font = { italic: true, size: 8, color: { argb: 'FF94A3B8' } };
      lg++; wg.mergeCells('A' + lg + ':' + gLastL + lg);
      wg.getCell('A' + lg).value = 'Início/Fim/Folga em dias úteis contados a partir de B4 (dia 0). Folga = quanto a etapa pode atrasar sem mudar o fim da obra. As barras têm ' + nSemCols + ' semanas de largura (' + nSem + ' da emissão + 4 de reserva); se o prazo passar disso, aumente a área ou reexporte do app. A curva S da aba Gráficos e a matriz de desembolso (Parâmetros/Cronograma) são da emissão e não seguem esta aba.';
      wg.getCell('A' + lg).font = { italic: true, size: 8, color: { argb: 'FF94A3B8' } }; wg.getCell('A' + lg).alignment = { wrapText: true, vertical: 'top' };
      wg.getRow(lg).height = 36;
    }

    // ===================== GRÁFICOS (imagens PNG geradas no browser) =====================
    // Só embute se deps.graficos existir (browser). Em Node (testes) é undefined → aba não é criada.
    var G = deps.graficos;
    if (G && (G.abc || G.curvaS || G.moMatEq)) {
      var wg2 = wb.addWorksheet("Gráficos", { properties: { tabColor: { argb: 'FFEC4899' } } });
      wg2.columns = [{ width: 3 }, { width: 130 }];
      wg2.mergeCells('A1:B1'); wg2.getCell('A1').value = empresa; wg2.getCell('A1').font = { bold: true, size: 16, color: { argb: navy } };
      wg2.mergeCells('A2:B2'); wg2.getCell('A2').value = 'GRÁFICOS DO ORÇAMENTO — ' + (orc.numero || '') + (orc.nome ? ' · ' + orc.nome : ''); wg2.getCell('A2').font = { bold: true, size: 11, color: { argb: muted } };

      // largura das imagens no canvas (900px). Altura por gráfico difere.
      var IMG_W = 900, linhaTop = 4; // linha (1-based) onde começa a próxima imagem
      function b64(dataUrl) { return String(dataUrl).replace(/^data:image\/png;base64,/, ''); }
      function embutir(titulo, dataUrl, hPx) {
        if (!dataUrl) return;
        var tCell = wg2.getCell('B' + linhaTop);
        tCell.value = titulo; tCell.font = { bold: true, size: 12, color: { argb: navy } };
        linhaTop += 1;
        var imgId = wb.addImage({ base64: b64(dataUrl), extension: 'png' });
        // tl usa índices 0-based (col 1 = coluna B); ~15px por linha p/ reservar espaço vertical.
        wg2.addImage(imgId, { tl: { col: 1, row: linhaTop - 1 }, ext: { width: IMG_W, height: hPx } });
        linhaTop += Math.ceil(hPx / 15) + 2;
      }
      embutir('Curva ABC (Pareto)', G.abc, 460);
      embutir('Curva S — avanço físico-financeiro', G.curvaS, 420);
      embutir('Composição de custo (MO / MAT / EQ)', G.moMatEq, 420);
    }

    // ===================== FASE 3: data-base em todas as abas =====================
    // Exigência formal de licitação: data-base/competência visível em cada quadro.
    var dtEmissao = orc.atualizadoEm ? new Date(orc.atualizadoEm) : new Date();
    var txtBase = 'Bases de preços: ' + Orcamento.basesUsadasTexto(orc) + ' — ' +
      (orc.desonerado ? 'desonerado' : 'não desonerado') + '   ·   Emissão: ' + dtEmissao.toLocaleDateString('pt-BR');
    function linhaBase(ws, rr, lastCol) {
      if (!ws) return;
      var c = ws.getCell('A' + rr);
      if (c.value) return; // linha já ocupada — não sobrescreve
      try { ws.mergeCells('A' + rr + ':' + lastCol + rr); } catch (e) {}
      c.value = txtBase; c.font = { italic: true, size: 8, color: { argb: 'FF94A3B8' } };
    }
    linhaBase(wsi, 4, 'G'); linhaBase(wabc, 3, 'H'); linhaBase(wins, 4, 'I');
    if (wcr) linhaBase(wcr, 3, wcr.getColumn((crono.meses || 0) + 2).letter);

    // ===================== FASE 3: memória de cálculo (Lei 14.133) =====================
    // Só entra se algum item tiver o campo memoriaCalculo preenchido no app.
    // (_memNoExcel foi resolvido lá em cima, antes da Analítica — a coluna L usa o mesmo parâmetro)
    var wmem = null, comMem = _memNoExcel ? itensFlat.filter(function (x) { return x.it && x.it.memoriaCalculo; }) : [];
    /* JUSTIFICATIVA DOS COEFICIENTES (v1.1.225): a composição própria passou a
       guardar o "por quê" de cada coeficiente. Ele defende o preço tanto quanto
       a memória de quantidade — e quem confere a planilha não tem o app aberto
       do lado para clicar no detalhamento. */
    var coefMem = [];
    if (_memNoExcel) {
      try {
        var vistosCM = {};
        itensFlat.forEach(function (x) {
          var it = x.it || {};
          if (String(it.baseFonte || it.origem || "").toUpperCase().indexOf("PROPRI") !== 0) return;
          if (vistosCM[it.codigo]) return;
          vistosCM[it.codigo] = 1;
          var comp = (typeof Bases !== "undefined" && Bases.obter) ? Bases.obter("PROPRIA", it.codigo) : null;
          ((comp && comp.insumos) || []).forEach(function (i) {
            if (!i || !i.memoria) return;
            coefMem.push({ comp: it.codigo, compDesc: it.descricao || "", ins: i.codigo || "",
                           insDesc: i.descricao || "", coef: Number(i.coeficiente) || 0, memoria: String(i.memoria) });
          });
        });
      } catch (eCM) { coefMem = []; }
    }
    if (comMem.length || coefMem.length) {
      wmem = wb.addWorksheet('Memória de Cálculo', { properties: { tabColor: { argb: 'FF8B5CF6' } } });
      wmem.columns = [{ width: 6 }, { width: 12 }, { width: 44 }, { width: 6 }, { width: 10 }, { width: 70 }];
      wmem.mergeCells('A1:F1'); wmem.getCell('A1').value = empresa; wmem.getCell('A1').font = { bold: true, size: 14, color: { argb: navy } };
      wmem.mergeCells('A2:F2'); wmem.getCell('A2').value = 'MEMÓRIA DE CÁLCULO DE QUANTITATIVOS — ' + (orc.numero || ''); wmem.getCell('A2').font = { bold: true, size: 11 };
      linhaBase(wmem, 3, 'F');
      ['Item', 'Código', 'Descrição', 'Und', 'Qtd', 'Memória de cálculo'].forEach(function (h, i) { hStyle(wmem.getRow(5).getCell(i + 1)); wmem.getRow(5).getCell(i + 1).value = h; });
      var mr = 6;
      comMem.forEach(function (x, idx) {
        var row = wmem.getRow(mr);
        row.getCell(1).value = x.num || x.n; row.getCell(2).value = x.it.codigo || '';
        row.getCell(3).value = x.it.descricao || ''; row.getCell(4).value = _un(x.it.unidade);
        row.getCell(5).value = { formula: "'" + SH_ANAL + "'!F" + x.r, result: x.qt }; row.getCell(5).numFmt = NUM;
        row.getCell(6).value = String(x.it.memoriaCalculo);
        row.getCell(6).alignment = { wrapText: true, vertical: 'top' };
        for (var k = 1; k <= 6; k++) { row.getCell(k).border = thin(); if (idx % 2 === 1) row.getCell(k).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinza } }; }
        mr++;
      });
      /* segundo bloco: o "por quê" de cada coeficiente das composições
         próprias. Separado do de quantidade de propósito — são perguntas
         diferentes: um justifica QUANTO, o outro justifica COMO se compõe. */
      if (coefMem.length) {
        mr++;
        wmem.mergeCells('A' + mr + ':F' + mr);
        wmem.getCell('A' + mr).value = 'JUSTIFICATIVA DOS COEFICIENTES — composições próprias';
        wmem.getCell('A' + mr).font = { bold: true, size: 11, color: { argb: navy } };
        mr += 2;
        ['Composição', 'Serviço', 'Insumo', 'Descrição do insumo', 'Coef.', 'Como se chegou nele'].forEach(function (h, i) {
          hStyle(wmem.getRow(mr).getCell(i + 1)); wmem.getRow(mr).getCell(i + 1).value = h;
        });
        mr++;
        coefMem.forEach(function (c, idx2) {
          var row = wmem.getRow(mr);
          row.getCell(1).value = c.comp; row.getCell(2).value = String(c.compDesc).slice(0, 60);
          row.getCell(3).value = c.ins; row.getCell(4).value = String(c.insDesc).slice(0, 60);
          row.getCell(5).value = c.coef; row.getCell(5).numFmt = '0.0000';
          row.getCell(6).value = c.memoria;
          row.getCell(6).alignment = { wrapText: true, vertical: 'top' };
          for (var k2 = 1; k2 <= 6; k2++) { row.getCell(k2).border = thin(); if (idx2 % 2 === 1) row.getCell(k2).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinza } }; }
          mr++;
        });
      }
    }

    // ============ JUSTIFICATIVA DE PREÇOS (Lei 14.133/2021) ============
    // Aba própria, não coluna: quem analisa quer a lista curta do que difere da
    // referência oficial com o motivo ao lado — e a Analítica não pode ganhar
    // coluna sem quebrar as fórmulas das outras abas (ver nota lá em cima).
    var wajs = null;
    var _resAj = (typeof Ajustes !== "undefined" && Ajustes.resumo) ? Ajustes.resumo(orc) : { n: 0, itens: [] };
    if (_resAj.n) {
      /* o número do item vem do itensFlat — MESMA fonte da Analítica, senão o
         quadro e a planilha numerariam o mesmo item de formas diferentes */
      var numPorId = {};
      itensFlat.forEach(function (x) { if (x.it && x.it.id) numPorId[x.it.id] = { num: x.num, r: x.r }; });

      wajs = wb.addWorksheet('Justificativa de Preços', { properties: { tabColor: { argb: 'FFF59E0B' } }, views: [{ state: 'frozen', ySplit: 5 }] });
      wajs.columns = [{ width: 8 }, { width: 12 }, { width: 44 }, { width: 6 }, { width: 11 },
        { width: 14 }, { width: 14 }, { width: 9 }, { width: 15 }, { width: 52 }];
      wajs.mergeCells('A1:J1'); wajs.getCell('A1').value = empresa;
      wajs.getCell('A1').font = { bold: true, size: 14, color: { argb: navy } };
      wajs.mergeCells('A2:J2');
      wajs.getCell('A2').value = 'QUADRO DE JUSTIFICATIVA DE PREÇOS — ' + (orc.numero || '');
      wajs.getCell('A2').font = { bold: true, size: 11 };
      wajs.mergeCells('A3:J3');
      wajs.getCell('A3').value = _resAj.n + ' item(ns) com preço diferente do da base de referência' +
        (_resAj.nCoeficientes ? ' e ' + _resAj.nCoeficientes + ' coeficiente(s) de composição ajustado(s)' : '') +
        '. Os demais seguem integralmente o preço da base. Ordenado pelo impacto em reais.';
      wajs.getCell('A3').font = { size: 9, italic: true, color: { argb: 'FF64748B' } };
      wajs.getRow(3).height = 26; wajs.getCell('A3').alignment = { wrapText: true, vertical: 'top' };

      ['Item', 'Código', 'Descrição', 'Und', 'Qtd', 'Preço da base', 'Preço adotado', 'Var. %', 'Impacto (R$)', 'Justificativa']
        .forEach(function (h, i) { hStyle(wajs.getRow(5).getCell(i + 1)); wajs.getRow(5).getCell(i + 1).value = h; });

      var ar = 6;
      _resAj.itens.forEach(function (i2, idx) {
        var d = i2.preco, ref = numPorId[i2.itemId] || {}, row2 = wajs.getRow(ar);
        var coefs = i2.deltas.filter(function (x) { return x.coeficiente; });
        row2.getCell(1).value = ref.num || '';
        row2.getCell(2).value = i2.codigo || '';
        row2.getCell(3).value = i2.descricao + (coefs.length
          ? '\n(' + coefs.length + ' coef.: ' + coefs.map(function (c) {
              return String(c.campo).slice(5) + ' ' + Ajustes.fmtN(c.base, 4) + '→' + Ajustes.fmtN(c.atual, 4);
            }).join(' · ') + ')' : '');
        row2.getCell(3).alignment = { wrapText: true, vertical: 'top' };
        row2.getCell(4).value = _un(i2.unidade);
        /* Qtd por fórmula amarrada à Analítica: mexeu lá, o quadro acompanha —
           quadro com quantidade congelada vira documento que contradiz a
           planilha do mesmo arquivo */
        row2.getCell(5).value = ref.r ? { formula: "'" + SH_ANAL + "'!F" + ref.r, result: i2.quantidade } : i2.quantidade;
        row2.getCell(5).numFmt = NUM;
        if (d) {
          row2.getCell(6).value = d.semBase ? 'sem preço na base' : d.base;
          if (!d.semBase) row2.getCell(6).numFmt = MOEDA;
          row2.getCell(7).value = ref.r ? { formula: "'" + SH_ANAL + "'!G" + ref.r, result: d.atual } : d.atual;
          row2.getCell(7).numFmt = MOEDA;
          row2.getCell(8).value = d.semBase ? '—' : d.pct / 100;
          if (!d.semBase) row2.getCell(8).numFmt = '+0.0%;-0.0%';
          row2.getCell(9).value = i2.impacto; row2.getCell(9).numFmt = MOEDA;
          if (d.dif > 0) row2.getCell(9).font = { color: { argb: 'FFB45309' }, bold: true };
        } else {
          [6, 7, 8, 9].forEach(function (k) { row2.getCell(k).value = '—'; });
        }
        var just = (d && d.motivo) || (i2.deltas[0] && i2.deltas[0].motivo) || '';
        row2.getCell(10).value = just || (d && d.dif > 0 ? '(a justificar)' : '—');
        row2.getCell(10).alignment = { wrapText: true, vertical: 'top' };
        if (!just && d && d.dif > 0) row2.getCell(10).font = { italic: true, color: { argb: 'FFB45309' } };
        for (var k3 = 1; k3 <= 10; k3++) {
          row2.getCell(k3).border = thin();
          if (idx % 2 === 1) row2.getCell(k3).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinza } };
        }
        ar++;
      });

      var rt = wajs.getRow(ar);
      rt.getCell(1).value = 'Efeito líquido das alterações sobre o custo direto';
      wajs.mergeCells('A' + ar + ':H' + ar);
      rt.getCell(1).font = { bold: true };
      rt.getCell(9).value = { formula: 'SUM(I6:I' + (ar - 1) + ')', result: _resAj.impacto };
      rt.getCell(9).numFmt = MOEDA; rt.getCell(9).font = { bold: true };
      [1, 9, 10].forEach(function (k) {
        rt.getCell(k).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: cinzaSub } };
        rt.getCell(k).border = thin();
      });
    }

    // ===================== DADOS IA (Excel Table viva p/ Copilot) =====================
    // Tabela plana tblItens: 1 linha por item, TODA por fórmula referenciando a
    // Analítica — editou lá, aqui acompanha. É a superfície que IA/Copilot lê bem
    // (Table nomeada, cabeçalho único, zero merge). Analítica não vira Table
    // porque os banners mesclados de etapa são proibidos dentro de Tables.
    var wdad = null;
    if (itensFlat.length) {
      wdad = wb.addWorksheet('Dados IA', { properties: { tabColor: { argb: 'FF64748B' } } });
      wdad.getCell('A1').value = 'BASE DE DADOS DO ORÇAMENTO (para análise e IA/Copilot) — espelho vivo da aba Analítica';
      wdad.getCell('A1').font = { bold: true, size: 11, color: { argb: navy } };
      var refA = function (col, rr, res) { return { formula: "'" + SH_ANAL + "'!" + col + rr, result: res }; };
      wdad.addTable({
        name: 'tblItens', ref: 'A2', headerRow: true,
        style: { theme: 'TableStyleMedium2', showRowStripes: true },
        columns: [{ name: 'Etapa' }, { name: 'Item' }, { name: 'Codigo' }, { name: 'Fonte' }, { name: 'Descricao' },
                  { name: 'Und' }, { name: 'Qtd' }, { name: 'CustoUnit' }, { name: 'CustoTotal' },
                  // com o BDI apartado, essas colunas NÃO carregam BDI — o nome tem que dizer isso
                  { name: bdiNoPU ? 'PrecoUnitBDI' : 'PrecoUnitCusto' },
                  { name: bdiNoPU ? 'PrecoTotalBDI' : 'PrecoTotalCusto' }],
        rows: itensFlat.map(function (x) {
          return [x.etapa, x.n,
            refA('B', x.r, x.it.codigo || ''), refA('C', x.r, ''), refA('D', x.r, x.it.descricao || ''),
            refA('E', x.r, _un(x.it.unidade)), refA('F', x.r, x.qt), refA('G', x.r, x.cu),
            refA('H', x.r, x.ct), refA('I', x.r, x.pu), refA('J', x.r, x.pt)];
        })
      });
      wdad.columns = [{ width: 12 }, { width: 6 }, { width: 11 }, { width: 10 }, { width: 50 }, { width: 6 },
                      { width: 10 }, { width: 13 }, { width: 13 }, { width: 13 }, { width: 14 }];
      for (var di = 3; di <= 2 + itensFlat.length; di++) {
        wdad.getCell('G' + di).numFmt = NUM;
        ['H', 'I', 'J', 'K'].forEach(function (cl) { wdad.getCell(cl + di).numFmt = MOEDA; });
      }
    }

    // ===================== LEIA-ME =====================
    var wleia = wb.addWorksheet('Leia-me', { properties: { tabColor: { argb: 'FF16A34A' } } });
    wleia.columns = [{ width: 110 }];
    var leiaLinhas = [
      [(empresa ? empresa.toUpperCase() + ' — ' : '') + 'COMO USAR ESTA PLANILHA', { bold: true, size: 14, cor: navy }],
      [(orc.numero || '') + (orc.nome ? ' · ' + orc.nome : '') + '   |   ' + Orcamento.basesUsadasTexto(orc) + '   |   ' + (orc.desonerado ? 'Desonerado' : 'Não desonerado'), { size: 9, cor: 'FF64748B' }],
      [''],
      ['✏️  O QUE VOCÊ PODE EDITAR (células AMARELAS):', { bold: true }],
      ['     • Resumo!B6 — o BDI aplicado (%). Tudo recalcula: preços unitários, totais, curva ABC, cronograma.'],
      ['     • Analítica, colunas Qtd e Custo Unit — simule quantidades e preços negociados.'],
      ['     • Resumo, parcelas do quadro BDI — a linha "BDI pela fórmula TCU" confere na hora.'],
      ['     • Parâmetros — matriz de desembolso (% de cada etapa por mês): o Cronograma e a Curva S seguem.'],
      wg ? ['     • Gantt — Dias de cada etapa (coluna C), data de início (B4), dias úteis/semana (D4) e paralelismo (F4):'] : null,
      wg ? ['       início, fim, folga, datas, caminho crítico e as barras recalculam (CPM por fórmula). "Depende de" é informativo.'] : null,
      wfer ? ['     • Feriados — a lista que as datas do Gantt consultam. Acrescente o feriado da sua cidade e o cronograma inteiro anda.'] : null,
      [''],
      ['🔒  PROTEÇÃO: as demais células têm fórmula e estão travadas só contra edição acidental.'],
      ['     Senha para desproteger (Revisão → Desproteger Planilha): raeng'],
      ['     Filtrar e ordenar continuam liberados (cabeçalhos da Curva ABC, Insumos e Dados IA).'],
      [''],
      ['✅  VERIFICAÇÕES AUTOMÁTICAS: o fim da aba Resumo confere se os totais seguem consistentes'],
      ['     após suas edições ("OK" verde · "⚠ verificar" vermelho).'],
      [''],
      ['📷  A aba Gráficos contém IMAGENS da emissão (não recalculam). Os dados vivos estão nas abas —'],
      ['     as barras do Gantt e do Peso % (Sintética, Curva ABC) são formatação condicional e seguem os números.'],
      [''],
      ['🤖  DICA (Excel 365/Copilot): a aba "Dados IA" tem a tabela tblItens pronta para análise.'],
      ['     Experimente perguntar: "quais os 5 itens de maior impacto no custo?" ou'],
      ['     "faça um gráfico de custo por etapa usando tblItens".'],
      [''],
    ];
    // Bloco de contato: SEMPRE da empresa do CLIENTE (⚙ Empresa) — nunca do fabricante.
    var rt = deps.responsavel || {};
    if (rt.nome || empresa) {
      leiaLinhas.push(['📞  ' + (rt.nome || empresa) + (rt.cnpj ? ' — CNPJ ' + rt.cnpj : '') + (rt.cidade ? ' · ' + rt.cidade : '')]);
      if (rt.responsavel) leiaLinhas.push(['     ' + (rt.titulo ? rt.titulo + ' ' : '') + rt.responsavel + (rt.crea ? ' · ' + rt.crea : '') + (rt.contato ? ' · ' + rt.contato : '')]);
    }
    if (credito) leiaLinhas.push(['     ' + credito + ' — orçamento de obras com bases oficiais e IA.']);
    leiaLinhas = leiaLinhas.filter(function (ln) { return ln !== null; }); // bullets condicionais (Gantt) sem deixar linha vazia
    leiaLinhas.forEach(function (ln, i) {
      var c = wleia.getCell('A' + (i + 1));
      c.value = ln[0];
      var o = ln[1] || {};
      c.font = { bold: !!o.bold, size: o.size || 10, color: { argb: o.cor || 'FF1E293B' } };
      c.alignment = { wrapText: false, vertical: 'top' };
    });

    // Notas nas células-chave (documentação p/ humano e p/ IA)
    wr.getCell('B6').note = 'BDI em % aplicado sobre o custo direto. Edite aqui: preços unitários, totais, ABC e cronograma recalculam. Named range: p_BDI. Referência: Acórdão TCU 2.622/2013 (quadro abaixo).';
    if (itensFlat.length) {
      wa.getCell('F' + itensFlat[0].r).note = 'Qtd editável (amarelo). Custo Total, Preço c/ BDI, subtotais, Sintética, Resumo, ABC e cronograma recalculam em cadeia.';
    }

    // ===================== _META (round-trip xlsx → app) =====================
    // Aba veryHidden com o JSON do orçamento fatiado (≤30k chars por célula —
    // limite do Excel é 32.767). Habilita a reimportação com diff no app
    // (FASE 4; o import é a etapa seguinte). Invisível p/ usuário e impressão.
    var wmeta = wb.addWorksheet('_meta');
    wmeta.state = 'veryHidden';
    /* ⚠ O DESFAZER E O HISTÓRICO DA IA NÃO VÃO NA PLANILHA. Esta planilha vai
       ao CLIENTE ("Abrir a planilha desta proposta"), e `iaHistorico[].pedido`
       é a instrução interna do orçamentista, `por` é o e-mail de quem pediu e
       `iaEdicao.inversos` guarda textos e quantidades de ANTES. Pior: reimportar
       ou restaurar por este arquivo traria de volta um desfazer velho, que
       reverteria o orçamento para um retrato de semanas atrás. Cópia rasa sem
       as duas chaves (a ordem das outras chaves não muda — o round-trip lê o
       mesmo JSON de sempre). A lista mora em Orcamento.CAMPOS_IA_LOCAIS. */
    var foraMeta = (global.Orcamento && Orcamento.CAMPOS_IA_LOCAIS) || ['iaEdicao', 'iaHistorico'];
    var orcMeta = {};
    for (var mk in orc) {
      if (Object.prototype.hasOwnProperty.call(orc, mk) && foraMeta.indexOf(mk) < 0) orcMeta[mk] = orc[mk];
    }
    var metaJson = JSON.stringify(orcMeta);
    var FATIA = 30000, metaPartes = Math.max(1, Math.ceil(metaJson.length / FATIA));

    /* ===== AS COMPOSIÇÕES PRÓPRIAS VÃO JUNTO (v1.1.211) =====
     * O item lançado é um snapshot: leva o CUSTO da composição própria, nunca a
     * estrutura dela. Enquanto o orçamento existe no app isso basta — a base
     * PRÓPRIA está do lado. Mas quando a planilha é a única cópia que sobrou
     * (cliente apagou o orçamento e voltou pelo Excel), o PROP-0016 renascia
     * como item de preço fixo: sem insumo, sem coeficiente, impossível de
     * reprecificar. O orçamento voltava; a autoria dele, não.
     *
     * Vai em COLUNA SEPARADA de propósito: quem lê só a coluna A (versão
     * anterior do app) continua lendo o orçamento igual, sem enxergar isto.
     * Compatibilidade para trás sem campo novo dentro do orçamento. */
    var propriasJson = '', propriasPartes = 0, propriasQtd = 0;
    try {
      if (typeof Bases !== 'undefined' && Bases.obter) {
        var vistos = {}, pilha = [], lista = [];
        (orc.etapas || []).forEach(function (e) {
          (e.itens || []).forEach(function (it) {
            var f = String(it.baseFonte || it.origem || '').toUpperCase();
            if ((f === 'PROPRIA' || f === 'PROPRIO') && it.codigo) pilha.push(String(it.codigo));
          });
        });
        // transitivo: composição própria pode usar OUTRO item próprio como insumo
        while (pilha.length) {
          var cod = pilha.shift(), k = String(cod).toLowerCase();
          if (vistos[k]) continue;
          vistos[k] = 1;
          var reg = Bases.obter('PROPRIA', cod);
          if (!reg) continue;
          lista.push(reg);
          (reg.insumos || []).forEach(function (i) {
            if (String(i.fonte || '').toUpperCase() === 'PROPRIA' && i.codigo) pilha.push(String(i.codigo));
          });
        }
        if (lista.length) {
          propriasJson = JSON.stringify({ v: 1, itens: lista });
          propriasPartes = Math.max(1, Math.ceil(propriasJson.length / FATIA));
          propriasQtd = lista.length;
        }
      }
    } catch (ePr) { propriasJson = ''; propriasPartes = 0; propriasQtd = 0; }

    wmeta.getCell('A1').value = JSON.stringify({
      v: 1, tipo: 'orcapro-meta', partes: metaPartes,
      schemaVersao: orc.schemaVersao || null, id: orc.id || '', numero: orc.numero || '',
      geradoEm: dtEmissao.toISOString(),
      propriasPartes: propriasPartes, propriasQtd: propriasQtd
    });
    /* v1.1.232 — FRONTEIRA SEGURA. O slice cego em i*FATIA podia cair no MEIO
       de um par substituto (um emoji na descrição de um item basta): cada
       metade vira U+FFFD ao gravar, e o orçamento RESTAURADO do Excel volta
       com o texto corrompido — em silêncio, provado com o ExcelJS real. Se o
       corte cai num high surrogate, recua 1 (a fatia fica com FATIA−1 chars,
       ainda longe do limite de 32.767 do Excel). */
    var fatiar = function (str, total) {
      var out = [], ini = 0;
      for (var fi = 0; fi < total; fi++) {
        var fim = Math.min(ini + FATIA, str.length);
        var cc = str.charCodeAt(fim - 1);
        if (fim < str.length && cc >= 0xD800 && cc <= 0xDBFF) fim--;
        out.push(str.slice(ini, fim)); ini = fim;
      }
      if (ini < str.length) out[out.length - 1] += str.slice(ini); // os recuos somam menos que uma fatia
      return out;
    };
    var fatiasMeta = fatiar(metaJson, metaPartes);
    for (var mi = 0; mi < metaPartes; mi++) wmeta.getCell('A' + (mi + 2)).value = fatiasMeta[mi] || '';
    var fatiasProp = fatiar(propriasJson, propriasPartes);
    for (var pi = 0; pi < propriasPartes; pi++) wmeta.getCell('B' + (pi + 2)).value = fatiasProp[pi] || '';

    // ===================== FASE 2: verificações automáticas (Resumo) =====================
    // Sanidade viva: se o usuário editar algo e um total desalinhar, o Resumo
    // acusa na hora — nada de número silenciosamente errado.
    var rc = resumoChecksRow || 23, checks = [];
    /* O check "Soma MO+MAT+EQ = Custo Direto" saiu daqui. Com a quebra vindo de
       _quebraMoMatEq (razão normalizada pela soma das parcelas), MO+MAT+EQ fecha
       com o Custo Direto POR CONSTRUÇÃO — um check que não pode reprovar é
       decoração. E a versão anterior reprovava por motivo errado: dividia pela
       razão do custo unitário do analítico, que difere da soma das parcelas em
       centavos, e o arquivo entregue ao cliente saía com "⚠ verificar" num
       orçamento correto. A procedência da quebra está na nota sob o bloco
       COMPOSIÇÃO DE CUSTO, em números. */
    if (cronoTotRef) {
      checks.push(['Cronograma fecha com o Preço de Venda', 'IF(ABS(' + cronoTotRef + '-B12)<=0.05,"OK","⚠ verificar")',
        Math.abs(num(crono && crono.total) - totVenda) <= 0.05 ? 'OK' : '⚠ verificar']);
    }
    if (wabc) {
      // resultado CALCULADO (nunca fixo em "OK": um check que sempre diz OK não é check)
      var difAbc = Math.abs(num(abc && abc.total) - grandCusto);
      checks.push(['Curva ABC soma = Custo Direto', "IF(ABS(SUM('Curva ABC'!$F$9:$F$" + abcFim + ')-B10)<=0.05,"OK","⚠ verificar")',
        difAbc <= 0.05 ? 'OK' : '⚠ verificar']);
    }
    if (checks.length) {
      wr.mergeCells('A' + rc + ':B' + rc);
      wr.getCell('A' + rc).value = 'VERIFICAÇÕES AUTOMÁTICAS';
      wr.getCell('A' + rc).font = { bold: true, color: { argb: navy } };
      checks.forEach(function (ck, i) {
        var rr = rc + 1 + i;
        wr.getCell('A' + rr).value = ck[0]; wr.getCell('A' + rr).font = { size: 9 };
        // check sem fórmula = verificação da emissão (valor estático, honesto)
        wr.getCell('B' + rr).value = ck[1] ? { formula: ck[1], result: ck[2] } : ck[2];
        wr.getCell('B' + rr).font = { bold: true, color: { argb: ck[2] === 'OK' ? verde : 'FFDC2626' } };
        wr.getCell('A' + rr).border = wr.getCell('B' + rr).border = thin();
      });
    }

    // ===================== FASE 3: responsável técnico + ART (Súmula TCU 260) =====================
    // Sempre presente — sem dado, sai placeholder explícito ([...]), nunca vazio.
    var resp = deps.responsavel || {};
    var ri = rc + checks.length + 2;
    wr.mergeCells('A' + ri + ':B' + ri);
    wr.getCell('A' + ri).value = 'RESPONSÁVEL TÉCNICO PELO ORÇAMENTO';
    wr.getCell('A' + ri).font = { bold: true, color: { argb: navy } };
    lin(ri + 1, 'Nome', resp.responsavel || '[RESPONSÁVEL TÉCNICO]');
    lin(ri + 2, 'Título / Registro', (resp.titulo || 'Engenheiro Civil') + ' · ' + (resp.crea || '[CREA/CAU]'));
    lin(ri + 3, 'ART/RRT', orc.art || '[nº da ART/RRT — informar]');
    lin(ri + 4, 'Empresa', (resp.nome || empresa || '') + (resp.cnpj ? ' · CNPJ ' + resp.cnpj : ''));
    wr.getCell('A' + (ri + 6)).value = '___________________________________';
    wr.getCell('A' + (ri + 7)).value = (resp.responsavel || '[nome]') + ' — ' + (resp.crea || '[CREA/CAU]');
    wr.getCell('A' + (ri + 7)).font = { size: 9, color: { argb: muted } };

    // ===================== FASE 2: impressão + proteção =====================
    // Impressão pronta p/ PDF/licitação: A4, ajusta à largura, cabeçalho repetido
    // e rodapé com nº do orçamento + página.
    function pset(ws, orient, titles, area) {
      if (!ws) return;
      ws.pageSetup = {
        paperSize: 9, orientation: orient, fitToPage: true, fitToWidth: 1, fitToHeight: 0,
        margins: { left: 0.4, right: 0.4, top: 0.55, bottom: 0.55, header: 0.2, footer: 0.25 },
        printTitlesRow: titles
      };
      /* v1.1.225 — área de impressão explícita. A coluna L (memória) tem 60 de
         largura; com fitToWidth:1 ela espremeria a planilha impressa inteira e
         o PDF de licitação sairia menor do que sempre saiu. Fixando A:K, o que
         se imprime continua idêntico e a memória fica só na tela (e na aba
         "Memória de Cálculo", que é a que se imprime para isso). */
      if (area) ws.pageSetup.printArea = area;
      ws.headerFooter.oddFooter = '&L&8' + (credito ? 'OrçaPRO — ' : '') + (orc.numero || '') + '&C&8' + (empresa || '') + '&R&8Pág. &P de &N';
    }
    pset(wr, 'portrait'); pset(wsi, 'portrait', '1:6');
    pset(wa, 'landscape', '1:6', _memNoExcel ? ('A1:K' + (r > 7 ? r : 7)) : null);
    pset(wins, 'landscape', '1:5'); pset(wabc, 'portrait', '1:8'); pset(wcr, 'landscape', '1:4');
    pset(wdad, 'landscape', '2:2'); pset(wleia, 'portrait'); pset(wmem, 'landscape', '1:5'); pset(wpar, 'landscape', '1:5');
    // Gantt, Gráficos e Justificativa saíam sem pageSetup: imprimir dava retrato
    // com o Gantt cortado na semana 12 e sem rodapé de nº/página.
    pset(wg, 'landscape', '1:6'); pset(wg2, 'portrait'); pset(wajs, 'landscape', '1:5');

    // Sem linhas de grade em NENHUMA aba: as tabelas já têm borda própria e a
    // grade cinza por trás de faixa colorida é o que separa "planilha comum" de
    // documento. Abas que já tinham views (congelamento) recebem só o flag.
    wb.eachSheet(function (ws) {
      if (ws.state === 'veryHidden') return;
      if (!ws.views || !ws.views.length) ws.views = [{ showGridLines: false }];
      else ws.views.forEach(function (v) { v.showGridLines = false; });
    });

    // Proteção anti-edição acidental: só as células amarelas editam (B6, parcelas
    // do BDI, Qtd/Custo da Analítica, parâmetros e Dias do Gantt). Senha
    // documentada no Resumo: 'raeng'.
    // ws.protect é assíncrono no ExcelJS -> construir passa a devolver Promise<wb>.
    // Dados IA fica SEM proteção: Table protegida bloqueia ordenar/filtrar no Excel.
    var protOpts = { selectLockedCells: true, selectUnlockedCells: true, autoFilter: true, sort: true };
    return Promise.all([wr, wsi, wa, wins, wabc, wcr, wleia, wmem, wpar, wg, wfer].filter(Boolean).map(function (ws) {
      return ws.protect('raeng', protOpts);
    })).then(function () { return wb; });
  }

  // ---------- Camada browser ----------
  var ExcelOrc = {
    construir: construir,

    /* ExcelJS — VENDORIZADO, offline (js/vendor/exceljs.min.js, 4.4.0).
     *
     * Vinha do cdnjs até a v1.1.141: era a ÚNICA biblioteca de fora e, além de
     * exigir internet na primeira exportação da sessão, punha a Cloudflare na
     * lista de terceiros que recebem o IP do cliente — coisa que a Política de
     * Privacidade tem de declarar. Embarcado, sai da lista e a exportação passa a
     * funcionar 100% offline, como o resto do produto.
     *
     * Continua LAZY: 947 KB só entram na memória de quem exporta planilha.
     * O id da tag segue "exceljs-cdn" de propósito — instalação antiga que já
     * tenha a tag na página não pode ganhar uma segunda. */
    ensureExcelJS: function (cb) {
      if (global.ExcelJS) { cb(); return; }
      var avisarFalha = function () { if (global.UI) UI.toast("Não foi possível carregar o gerador de Excel (arquivo js/vendor/exceljs.min.js).", "erro"); };
      if (document.getElementById("exceljs-cdn")) {
        var t = setInterval(function () { if (global.ExcelJS) { clearInterval(t); cb(); } }, 120);
        setTimeout(function () { clearInterval(t); if (!global.ExcelJS) avisarFalha(); }, 15000); return;
      }
      var s = document.createElement("script"); s.id = "exceljs-cdn";
      s.src = "js/vendor/exceljs.min.js";
      s.onload = function () { cb(); };
      s.onerror = function () { var el = document.getElementById("exceljs-cdn"); if (el) el.remove(); avisarFalha(); }; // remove a tag morta p/ permitir nova tentativa
      document.head.appendChild(s);
    },

    // SheetJS (vendorizado, OFFLINE) — só p/ LER .xls antigo (BIFF), que o ExcelJS não abre.
    // Lazy: injeta o script só quando um .xls é importado (não pesa o load de quem não usa).
    ensureSheetJS: function (cb) {
      if (global.XLSX) { cb(); return; }
      var avisarFalha = function () { if (global.UI) UI.toast("Não foi possível carregar o leitor de .xls.", "erro"); };
      if (document.getElementById("sheetjs-vendor")) {
        var t = setInterval(function () { if (global.XLSX) { clearInterval(t); cb(); } }, 120);
        setTimeout(function () { clearInterval(t); if (!global.XLSX) avisarFalha(); }, 15000); return;
      }
      var s = document.createElement("script"); s.id = "sheetjs-vendor";
      s.src = "js/vendor/xlsx.full.min.js";
      s.onload = function () { cb(); };
      s.onerror = function () { var el = document.getElementById("sheetjs-vendor"); if (el) el.remove(); avisarFalha(); };
      document.head.appendChild(s);
    },

    gerar: function (orc) {
      this.ensureExcelJS(function () {
        var finalizar = function (insumosMap) {
          try {
            var deps = {
              num: Util.num,
              fmtNum: Util.fmtNum,
              empresa: ((typeof Empresa !== "undefined" && Empresa.nomeDoc) ? Empresa.nomeDoc() : "") || ((Auth.usuario && Auth.usuario()) ? Auth.usuario().empresa : "") || "",
              credito: (typeof Empresa !== "undefined" && Empresa.creditoTexto) ? Empresa.creditoTexto() : "",
              creator: (typeof Empresa !== "undefined" && Empresa.excelCreator) ? Empresa.excelCreator() : "",
              abc: (typeof Orcamento.curvaABC === "function") ? Orcamento.curvaABC(orc) : null,
              /* ⚠ SEM o 2º argumento: ele trava o nº de colunas e acumula na
                 última tudo que passar. `orc.cronogramaMeses` é campo DERIVADO
                 e regravado a cada abertura — forçá-lo aqui fazia a planilha
                 divergir da tela, com meses de desembolso empilhados numa
                 coluna só. A trava manual da pessoa continua valendo lá dentro
                 (`cronogramaMesesManual`). Ver o ⚠ de js/proposta.js. */
              crono: (typeof Orcamento.cronograma === "function") ? Orcamento.cronograma(orc) : null,
              cronoAgente: (typeof Cronograma !== "undefined") ? Cronograma.estimar(orc) : null,
              insumosMap: insumosMap,
              analiticoComp: (typeof Analitico !== "undefined" && Analitico.carregado) ? (Analitico.competencia + "/" + Analitico.uf) : "",
              responsavel: (typeof Empresa !== "undefined" && Empresa.dados) ? Empresa.dados() : null
            };
            // Gera os PNGs dos gráficos NO BROWSER (canvas). Node nunca passa por aqui.
            try { deps.graficos = gerarGraficos(orc, deps); } catch (eg) { console.warn('[excel graficos]', eg); deps.graficos = null; }
            // construir devolve Promise (proteção de abas é assíncrona no ExcelJS)
            Promise.resolve(construir(global.ExcelJS, orc, deps)).then(function (wb) {
              return wb.xlsx.writeBuffer();
            }).then(function (buf) {
              var blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
              var a = document.createElement('a'); a.href = URL.createObjectURL(blob);
              a.download = (orc.numero || 'orcamento') + '_PRO.xlsx';
              document.body.appendChild(a); a.click(); document.body.removeChild(a);
              setTimeout(function () { URL.revokeObjectURL(a.href); }, 5000);
              if (global.UI) UI.toast(insumosMap ? "Excel gerado (com aba Insumos)!" : "Excel gerado (com fórmulas)!", "ok");
            }).catch(function (e) { console.error('[excel write]', e); if (global.UI) UI.toast("Falha ao escrever Excel: " + e.message, "erro"); });
          } catch (e) { console.error('[excel]', e); if (global.UI) UI.toast("Falha ao gerar Excel: " + e.message, "erro"); }
        };
        // tenta incluir a aba "Insumos" (carrega a base analítica sob demanda)
        var montarMapa = function () {
          var m = {};
          (orc.etapas || []).forEach(function (et) {
            (et.itens || []).forEach(function (it) {
              if (Orcamento.ehSinapi(it.origem)) { var a = Analitico.obter(it.codigo); if (a) m[String(it.codigo)] = a; }
              // v1.1.123 — composição PRÓPRIA: a estrutura salva na base do
              // cliente sai na aba de insumos igual à SINAPI (entregável coerente
              // com o detalhamento da tela)
              else if (it.origem === "PROPRIA" && typeof Bases !== "undefined" && Bases.obter) {
                var bp = Bases.obter("PROPRIA", String(it.codigo));
                if (bp && bp.insumos && bp.insumos.length) {
                  var catP = (typeof ComposicaoPropria !== "undefined" && ComposicaoPropria.catDe)
                    ? ComposicaoPropria.catDe
                    : function (x) { return String(x || "MAT").toUpperCase(); };
                  m[String(it.codigo)] = {
                    codigo: bp.codigo, descricao: bp.descricao, unidade: bp.unidade,
                    custoUnitario: Number(bp.custoUnitario) || 0,
                    custoMO: Number(bp.custoMO) || 0, custoMAT: Number(bp.custoMAT) || 0, custoEQ: Number(bp.custoEQ) || 0,
                    insumos: bp.insumos.map(function (ip) {
                      var co = Number(ip.coeficiente) || 0, cu = Number(ip.custoUnitario) || 0;
                      return { tipo: "INSUMO", codigo: ip.codigo, descricao: ip.descricao, unidade: ip.unidade,
                        coeficiente: co, custoUnitario: cu, custoTotal: co * cu, categoria: catP(ip.categoria) };
                    })
                  };
                }
              }
            });
          });
          return m;
        };
        if (typeof Analitico === "undefined") { finalizar(null); return; }
        // O App (exportarExcel) carrega o analítico DO ORÇAMENTO (orc.uf /
        // orc.competenciaSinapi) antes de gerar. Se estiver carregado, usa; se
        // não (raro/offline), gera SEM a aba — nunca com o MG errado.
        /* ⚠ Guarda de UF (v1.2.31). Um ORC de MG saiu com "06/2026/PA" na aba
           Insumos: o app estava com o ambiente em PA e a exportação usava o
           analítico que estivesse na memória, sem conferir de quem era. Os
           insumos e a quebra MO/MAT/EQ eram de outro estado — número errado
           entregue ao cliente com cara de certo. A aba Insumos só sai se a base
           carregada for a do orçamento; senão sai a planilha sem ela e o toast
           diz o motivo. */
        var ufOrc = String(orc.uf || "").toUpperCase(), ufAna = String(Analitico.uf || "").toUpperCase();
        if (Analitico.carregado && ufOrc && ufAna && ufAna !== ufOrc) {
          if (global.UI) UI.toast("Aba Insumos omitida: a base analítica carregada é de " + ufAna + " e o orçamento é de " + ufOrc + ". Abra o orçamento de novo e exporte outra vez.", "aviso");
          finalizar(null); return;
        }
        finalizar(Analitico.carregado ? montarMapa() : null);
      });
    }
  };

  if (global) global.ExcelOrc = ExcelOrc;
  if (typeof module !== "undefined" && module.exports) module.exports = ExcelOrc;
})(typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this));
