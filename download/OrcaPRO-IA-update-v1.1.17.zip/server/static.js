/* =====================================================================
 * static.js — Servidor estático do OrçaPRO (sem dependências)
 * Serve a pasta do app em http://localhost:8754 com no-cache (sempre a
 * versão mais nova). Só precisa do Node.js. Porta via env PORT_APP.
 * ===================================================================== */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT_APP || 8754;
const ROOT = path.join(__dirname, '..'); // a raiz do OrçaPRO (onde está o index.html)

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', '.woff2': 'font/woff2',
  '.webmanifest': 'application/manifest+json; charset=utf-8'
};

http.createServer((req, res) => {
  try {
    let rel = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    if (rel === '/' || rel === '') rel = '/index.html';
    // impede sair da raiz (path traversal)
    const full = path.normalize(path.join(ROOT, rel));
    if (!full.startsWith(ROOT)) { res.writeHead(403); res.end('forbidden'); return; }
    fs.readFile(full, (err, data) => {
      if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('404 — ' + rel); return; }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-store' });
      res.end(data);
    });
  } catch (e) { res.writeHead(500); res.end('erro'); }
}).listen(PORT, () => console.log('[orcapro] App em http://localhost:' + PORT));
