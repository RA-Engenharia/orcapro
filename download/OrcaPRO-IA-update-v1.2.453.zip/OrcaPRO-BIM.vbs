' =====================================================================
'  OrcaPRO-BIM.vbs - abre o PROGRAMA OrcaPRO BIM (14/11/2026)
'
'  POR QUE ISTO EXISTE
'  O BIM rodava na mesma aba do sistema inteiro (orcamento, gestao, painel,
'  nuvem). O 3D e o modelador disputavam memoria e processador com o resto
'  e travavam. Este atalho abre o MESMO sistema numa janela propria do
'  navegador (modo aplicativo, sem barra de enderecos), que o Edge/Chrome
'  roda em OUTRO PROCESSO, direto no BIM em tela inteira (?app=bim no
'  js/app.js). Os dados sao os mesmos: mesmo endereco, mesmo armazenamento.
'
'  NAO usar perfil separado (--user-data-dir): o perfil separado tem outro
'  armazenamento e o BIM abriria vazio, sem as obras e os projetos.
'
'  Endereco:
'   - url-bim.txt ao lado deste arquivo manda (ex.: a versao da nuvem);
'   - senao, o servidor local na porta do porta.txt (padrao 8754), que
'     este atalho sobe sozinho, sem janela, se estiver desligado.
' =====================================================================
Option Explicit

Dim sh, fso, pasta, porta, url, base, f
Set sh  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
pasta = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = pasta

Function LerLinha(caminho)
  LerLinha = ""
  If fso.FileExists(caminho) Then
    On Error Resume Next
    Set f = fso.OpenTextFile(caminho, 1)
    If Not f.AtEndOfStream Then LerLinha = Trim(f.ReadLine)
    f.Close
    On Error GoTo 0
  End If
End Function

Function Responde(endereco)
  Dim x
  Responde = False
  On Error Resume Next
  Set x = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  x.setTimeouts 1500, 1500, 1500, 1500
  x.Open "GET", endereco, False
  x.Send
  If Err.Number = 0 Then
    If x.Status = 200 Then Responde = True
  End If
  On Error GoTo 0
End Function

porta = LerLinha(pasta & "\porta.txt")
If porta = "" Or Not IsNumeric(porta) Then porta = "8754"

url = LerLinha(pasta & "\url-bim.txt")
If url = "" Then
  base = "http://localhost:" & porta & "/"
  If Not Responde(base & "manifest.webmanifest") Then
    ' servidor desligado: sobe o mesmo do Iniciar-OrcaPRO.bat, sem console
    Dim node, servidor, i
    node = "node"
    If fso.FileExists(pasta & "\runtime\node.exe") Then node = """" & pasta & "\runtime\node.exe"""
    servidor = "server\static.js"
    If fso.FileExists(pasta & "\server\vida.js") Then servidor = "server\vida.js"
    sh.Environment("PROCESS")("PORT_APP") = porta
    sh.Run node & " " & servidor, 0, False
    For i = 1 To 40
      WScript.Sleep 500
      If Responde(base & "manifest.webmanifest") Then Exit For
    Next
  End If
  url = base & "index.html?app=bim"
  ' DUPLO CLIQUE NUM ARQUIVO DO ORCAPRO (21/11/2026): o instalador associa
  ' .opbim/.optpl/.opfam a este atalho com "%1". O caminho vai ao servidor
  ' local por POST e volta um codigo de uso unico; o app troca o codigo pelos
  ' bytes (server/static.js, /__projetos/abrir-externo). O caminho nunca vai
  ' na URL: a pagina nao pode pedir arquivo qualquer do disco.
  If WScript.Arguments.Count > 0 Then
    Dim arq, xr, corpo, tok
    arq = WScript.Arguments(0)
    corpo = "{""caminho"":""" & Replace(Replace(arq, "\", "\\"), """", "\""") & """}"
    tok = ""
    On Error Resume Next
    Set xr = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    xr.setTimeouts 3000, 3000, 5000, 5000
    xr.Open "POST", base & "__projetos/abrir-externo", False
    xr.setRequestHeader "Content-Type", "application/json; charset=utf-8"
    xr.Send corpo
    If Err.Number = 0 Then
      If xr.Status = 200 Then
        Dim p1
        p1 = InStr(xr.responseText, """token"":""")
        If p1 > 0 Then tok = Mid(xr.responseText, p1 + 9, 32)
      End If
    End If
    On Error GoTo 0
    If tok <> "" Then
      url = url & "&arquivo=" & tok
    Else
      MsgBox "O OrcaPRO nao conseguiu abrir este arquivo:" & vbCrLf & arq & vbCrLf & vbCrLf & _
             "Abra o OrcaPRO BIM e use Abrir projeto > Do computador.", vbExclamation, "OrcaPRO BIM"
    End If
  End If
Else
  If InStr(url, "app=bim") = 0 Then
    If InStr(url, "?") > 0 Then
      url = url & "&app=bim"
    Else
      url = url & "?app=bim"
    End If
  End If
End If

' navegador em modo aplicativo: Edge (vem no Windows 11), senao Chrome
Dim candidatos, c, nav
nav = ""
candidatos = Array( _
  sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Microsoft\Edge\Application\msedge.exe", _
  sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Microsoft\Edge\Application\msedge.exe", _
  sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Google\Chrome\Application\chrome.exe", _
  sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Google\Chrome\Application\chrome.exe", _
  sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Google\Chrome\Application\chrome.exe")
For Each c In candidatos
  If nav = "" Then
    If fso.FileExists(c) Then nav = c
  End If
Next

If nav <> "" Then
  sh.Run """" & nav & """ --app=""" & url & """ --start-maximized", 1, False
Else
  sh.Run """" & url & """", 1, False
End If
WScript.Quit 0
