/* =====================================================================
 * orcapro-ia.js — Servidor de IA do OrçaPRO (independente, para venda)
 * Backend mínimo que alimenta os recursos de IA do OrçaPRO:
 *   GET  /health
 *   POST /ia/orcamento   {descricao}                 -> estrutura a EAP
 *   POST /ia/casar       {itens:[{descricao,unidade,candidatos}]}
 *   POST /ia/cronograma  {etapas:[...], equipes}     -> refina durações
 *
 * A chave da IA fica AQUI (backend), nunca no navegador. Cada comprador
 * usa a PRÓPRIA chave (Groq grátis ou Anthropic). Configure em ia-config.json
 * (copie de ia-config.example.json). Porta padrão 3041 (env PORT_IA).
 * ===================================================================== */
'use strict';
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT_IA || 3041;

function lerConfig() {
  if (process.env.GROQ_API_KEY) return { apiKey: process.env.GROQ_API_KEY, model: process.env.GROQ_MODEL || 'llama-3.1-8b-instant', provider: 'groq' };
  if (process.env.ANTHROPIC_API_KEY) return { apiKey: process.env.ANTHROPIC_API_KEY, model: process.env.ANTHROPIC_MODEL || 'claude-3-5-haiku-latest', provider: 'anthropic' };
  try {
    const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'ia-config.json'), 'utf8'));
    const provider = cfg.provider || 'groq';
    return { apiKey: cfg.apiKey || null, model: cfg.model || (provider === 'anthropic' ? 'claude-3-5-haiku-latest' : 'llama-3.1-8b-instant'), provider: provider };
  } catch (e) { return { apiKey: null, model: null, provider: 'groq' }; }
}

function groqChat(apiKey, payload) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(payload);
    const req = https.request({ method: 'POST', hostname: 'api.groq.com', path: '/openai/v1/chat/completions', headers: { 'content-type': 'application/json', 'authorization': 'Bearer ' + apiKey, 'content-length': Buffer.byteLength(data) } },
      r => { let b = ''; r.on('data', c => b += c); r.on('end', () => { if (r.statusCode >= 400) return reject(new Error('Groq HTTP ' + r.statusCode + ': ' + b.slice(0, 300))); try { resolve(JSON.parse(b)); } catch (e) { reject(e); } }); });
    req.on('error', reject); req.write(data); req.end();
  });
}
function anthropicMessages(apiKey, payload) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(payload);
    const req = https.request({ method: 'POST', hostname: 'api.anthropic.com', path: '/v1/messages', headers: { 'content-type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'content-length': Buffer.byteLength(data) } },
      r => { let b = ''; r.on('data', c => b += c); r.on('end', () => { if (r.statusCode >= 400) return reject(new Error('Anthropic HTTP ' + r.statusCode + ': ' + b.slice(0, 300))); try { resolve(JSON.parse(b)); } catch (e) { reject(e); } }); });
    req.on('error', reject); req.write(data); req.end();
  });
}

// chama a IA (groq json_object ou anthropic) e devolve o objeto JSON parseado
async function chamarIA(sys, user, maxTokens, temp) {
  const { apiKey, model, provider } = lerConfig();
  if (!apiKey) throw { code: 400, msg: 'IA não configurada. Copie ia-config.example.json para ia-config.json e coloque a sua apiKey.' };
  if (provider === 'anthropic') {
    const resp = await anthropicMessages(apiKey, { model, max_tokens: maxTokens, system: sys, messages: [{ role: 'user', content: user }] });
    const t = (resp.content || []).map(b => b.text || '').join(''); const a = t.indexOf('{'), z = t.lastIndexOf('}');
    return { obj: JSON.parse(t.slice(a, z + 1)), provider, model };
  }
  const resp = await groqChat(apiKey, { model: model || 'llama-3.1-8b-instant', temperature: temp, max_tokens: maxTokens, response_format: { type: 'json_object' }, messages: [{ role: 'system', content: sys }, { role: 'user', content: user }] });
  const content = (resp.choices && resp.choices[0] && resp.choices[0].message && resp.choices[0].message.content) || '';
  return { obj: JSON.parse(content), provider, model };
}

const SYS_ORC = 'Você é um orçamentista de obras brasileiro. Quebre a obra em SERVIÇOS INDIVIDUAIS e granulares: UM serviço por item, NUNCA agrupe. Cada "descricao" CURTA e específica no jargão SINAPI (ex.: "alvenaria de vedação bloco cerâmico", "chapisco", "emboço", "reboco", "contrapiso", "piso porcelanato", "revestimento cerâmico parede", "forro de gesso", "pintura látex acrílica", "concreto fck 25 mpa", "aço ca-50", "forma de madeira", "laje pré-moldada", "telha cerâmica", "porta de madeira", "janela de alumínio", "impermeabilização", "escavação", "calha", "rufo"). Repita o nome da etapa em cada serviço dela. Gere de 20 a 40 itens. NUNCA invente códigos nem preços. Quantidades ESTIMADAS (unidade m2, m3, un, m, kg ou vb). Responda APENAS JSON: {"etapas":[{"etapa":"","descricao":"","unidade":"","quantidade":0,"observacao":""}],"premissas":[""]}. quantidade número (>0).';
const SYS_CASAR = 'Você é um engenheiro orçamentista sênior. Para CADA serviço, escolha entre os CANDIDATOS o código que representa EXATAMENTE aquele serviço (mesmo significado E mesma unidade). Se NENHUM servir, retorne codigo "". NUNCA escolha fora da lista. Evite erros grosseiros: telha NÃO é tesoura; impermeabilização NÃO é contrapiso; concreto NÃO é demolição; chapisco, emboço e reboco são DIFERENTES. Responda APENAS JSON: {"escolhas":[{"i":0,"codigo":""}]} uma entrada por serviço.';

function send(res, code, obj) { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); }
function body(req) { return new Promise(r => { const c = []; req.on('data', x => c.push(x)); req.on('end', () => { try { r(JSON.parse(Buffer.concat(c).toString() || '{}')); } catch (e) { r({}); } }); }); }

http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
  const route = new URL(req.url, 'http://localhost').pathname;
  try {
    if (route === '/health') { const c = lerConfig(); return send(res, 200, { ok: true, service: 'orcapro-ia', provider: c.provider, configurado: !!c.apiKey }); }

    if (req.method === 'POST' && route === '/ia/orcamento') {
      const b = await body(req); const desc = String(b.descricao || '').trim();
      if (!desc) return send(res, 400, { error: 'descricao obrigatória' });
      const { obj, provider, model } = await chamarIA(SYS_ORC, 'Descrição da obra:\n' + desc + '\n\nGere o JSON do orçamento.', 3500, 0.3);
      if (!obj || !obj.etapas) return send(res, 502, { error: 'IA não retornou estrutura válida' });
      return send(res, 200, { ok: true, provider, model, resultado: obj });
    }

    if (req.method === 'POST' && route === '/ia/casar') {
      const b = await body(req); const itens = Array.isArray(b.itens) ? b.itens : [];
      if (!itens.length) return send(res, 400, { error: 'itens vazios' });
      let lista = '';
      itens.forEach((it, i) => { lista += '\n#' + i + ' SERVICO: ' + String(it.descricao || '') + ' (unidade ' + String(it.unidade || '?') + ')\n'; (it.candidatos || []).forEach(c => { lista += '   [' + c.codigo + '] ' + String(c.descricao || '') + ' | un ' + String(c.unidade || '?') + ' | R$ ' + (c.custo || 0) + '\n'; }); });
      const { obj, provider } = await chamarIA(SYS_CASAR, 'Serviços e candidatos:\n' + lista, 2000, 0.1);
      if (!obj || !obj.escolhas) return send(res, 502, { error: 'IA não retornou escolhas' });
      return send(res, 200, { ok: true, provider, escolhas: obj.escolhas });
    }

    if (req.method === 'POST' && route === '/ia/cronograma') {
      const b = await body(req); const etapas = Array.isArray(b.etapas) ? b.etapas : [];
      if (!etapas.length) return send(res, 400, { error: 'etapas vazias' });
      const equipes = Number(b.equipes) || 1;
      let lista = '';
      etapas.forEach((e, i) => { lista += '\n#' + i + ' ETAPA: ' + String(e.nome || '') + ' (categoria: ' + String(e.categoria || '') + '; estimativa atual: ' + (e.duracaoAtual || '?') + ' dias úteis)\n'; (e.itens || []).slice(0, 15).forEach(it => { lista += '   - ' + String(it.descricao || '').slice(0, 80) + ' | ' + (it.quantidade || 0) + ' ' + String(it.unidade || '') + '\n'; }); });
      const sys = 'Você é um engenheiro planejador sênior. Para CADA etapa estime a DURAÇÃO em DIAS ÚTEIS pelos serviços/quantidades e produtividade real, com ' + equipes + ' equipe(s). Seja realista. Responda APENAS JSON: {"etapas":[{"i":0,"dias":N,"motivo":"curto"}]} dias inteiro >=1, motivo até 8 palavras.';
      const { obj, provider } = await chamarIA(sys, 'Etapas e serviços:\n' + lista, 2000, 0.2);
      if (!obj || !obj.etapas) return send(res, 502, { error: 'IA não retornou etapas' });
      return send(res, 200, { ok: true, provider, etapas: obj.etapas });
    }

    send(res, 404, { error: 'rota não encontrada' });
  } catch (err) {
    if (err && err.code === 400) return send(res, 400, { error: err.msg });
    send(res, 500, { error: String(err && err.message || err) });
  }
}).listen(PORT, () => console.log('[orcapro-ia] IA do OrçaPRO ouvindo em http://localhost:' + PORT + '  (provider: ' + lerConfig().provider + ', configurado: ' + !!lerConfig().apiKey + ')'));
