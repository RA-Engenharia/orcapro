@echo off
chcp 65001 >nul
title OrcaPRO IA
cd /d "%~dp0"

REM --- Node: usa o runtime embutido/baixado; senao o do sistema; senao baixa ---
if exist "%~dp0runtime\node.exe" set "PATH=%~dp0runtime;%PATH%"
where node >nul 2>nul
if errorlevel 1 (
  echo Preparando o Node.js ^(so na 1a vez, precisa de internet^)...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalador\baixar-node.ps1"
  if exist "%~dp0runtime\node.exe" set "PATH=%~dp0runtime;%PATH%"
)
where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js indisponivel. Rode Instalar-OrcaPRO.bat com a internet ligada.
  pause
  exit /b 1
)

echo [OK] Subindo o OrcaPRO IA ^(app porta 8754 + IA porta 3041^)...
start "OrcaPRO App" /min cmd /c "node server\static.js"
start "OrcaPRO IA"  /min cmd /c "node server\orcapro-ia.js"
ping 127.0.0.1 -n 3 >nul
start "" "http://localhost:8754/index.html?v=%RANDOM%%RANDOM%"
echo.
echo OrcaPRO IA aberto no navegador. Pode fechar esta janela.
echo (As duas janelas minimizadas precisam ficar abertas enquanto usa o app.)
timeout /t 5 >nul
