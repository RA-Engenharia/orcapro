/* =====================================================================
 * bim.js — Visualizador BIM in-app (módulo ES). window.BIM.
 * Adapta a lógica provada do bim/bim.html (viewer autônomo da NF8n, 33d47fb):
 * web-ifc StreamAllMeshes → BufferGeometry Three (glue própria), voo+órbita,
 * pick por duplo-clique. Aqui vira um módulo montável na aba BIM da Gestão,
 * com camada 4D (recolore/oculta por estado — dirigido por BIM4D via gestao.js).
 *
 * Contrato consumido por gestao.js (aba BIM):
 *   BIM.montar(host, { onLoaded(elementos:[{id,tipo,nome}]), onPick(info) })
 *   BIM.abrirArquivo(File)  ·  BIM.carregarExemplo()
 *   BIM.aplicarEstado({construidos,emAndamento,futuros})  ·  BIM.mostrarTudo()
 * ===================================================================== */
import * as THREE from 'three';
import { OrbitControls } from '../bim/vendor/OrbitControls.js';
import { Sky } from '../bim/vendor/Sky.js';
import { criarCristal } from '../bim/cristal.js';
import { IfcAPI } from 'web-ifc';

var S = null; // estado do viewer montado

/* =====================================================================
 * B0 — IDENTIDADE DURAVEL DO ELEMENTO (motor em js/bimid.js)
 *
 * `uid` (mid + ':' + expressID) NAO sobrevive: `mid` e a ordem de abertura
 * naquela sessao, e `expressID` e o numero da linha no IFC, que muda em toda
 * reexportacao. Quem GRAVA vinculo passa a gravar `chave`.
 *
 * A obra corrente vive AQUI, fora do `S`: o viewer e remontado ao trocar de
 * aba e ao perder o contexto WebGL, e a obra nao muda por causa disso.
 *
 * ⚠ E a obra entra na ancora porque o vinculo e GRAVADO por obra
 * (`Store.obter(eid(), 'bim_edicoes', obraId)`). Ancora dizendo obra A dentro
 * do registro da obra B nao casa na proxima abertura: vinculo orfao, calado.
 * ===================================================================== */
var OBRA_ID = '';

/* =====================================================================
 * B1 — CACHE DO MODELO (js/bimcache.js) E FEDERACAO DA OBRA (js/bimfed.js)
 *
 * FED e o mapa que a casca entrega: "nesta obra, o arquivo de conteudo X (ou
 * de nome Y) e o modelo Z". Ele existe para o viewer NAO precisar do Store —
 * a fronteira do produto diz que quem fala com o Store e a casca.
 *
 * ⚠ E e ele que fecha o buraco declarado no B0: sem federacao, o modeloId era
 * derivado do nome, e renomear o arquivo orfanava todo vinculo salvo. Com o
 * mapa, o casamento e por CONTEUDO primeiro.
 * ===================================================================== */
var FED = null;

/* ⚠ TETO DA COLETA PARA O CACHE. Guardar a geometria crua custa memoria
 * DURANTE a abertura, alem do que a cena ja ocupa. Num modelo em que quase
 * nada se repete isso quase dobra o pico — e o produto ja carrega o IFC
 * inteiro na memoria (D6). Passando do teto, o modelo abre normalmente e
 * simplesmente NAO e guardado: perder o cache e lentidao na proxima abertura,
 * estourar a memoria e o Revit do usuario travando junto com a aba. */
var TETO_COLETA = 200 * 1024 * 1024;
var cacheSeq = 0;

/* ⚠ A GUARDA UNICA. Um modelo restaurado do cache NAO existe no WASM, e o
 * `mid` dele e string. Se qualquer caminho de leitura IFC escapar desta
 * guarda, `GetLine(mid, …)` recebe uma string que o embind converte para 0 —
 * e le a linha do PRIMEIRO IFC de verdade que estiver aberto. O usuario
 * clicaria numa peca e veria, sem erro nenhum, as propriedades de outra peca,
 * de outro arquivo. E o mesmo motivo pelo qual `removerModelo` so chama
 * `CloseModel` quando o mid e numero. */
function semWasm(mo) { return !!(mo && (mo.sintetico || mo.doCache)); }

function idModelo(nome, arquivoId, abertos) {
  if (typeof window === 'undefined') return '';
  /* a federacao manda; o derivado do B0 e o ultimo recurso (obra sem registro
     ainda, ou arquivo que a obra nunca viu) */
  if (FED && window.BimFed) return window.BimFed.resolver(FED, nome, arquivoId, abertos);
  return window.BimId ? window.BimId.modeloId(OBRA_ID, nome) : '';
}

/* ⚠ O NOME QUE SERVE DE IDENTIDADE NAO E SEMPRE O NOME QUE APARECE. O modelo
 * do editor se chama "Criados no OrcaPRO (3)" — a contagem esta DENTRO do
 * nome, entao criar a quarta parede mudava o nome, mudava o modeloId e mudava
 * a chave de todas as pecas que ja existiam. Identidade que muda quando o
 * usuario trabalha e o oposto do que o B0 existe para dar. */
function nomeDeIdentidade(mo) {
  if (mo && mo.editor) return 'Criados no OrcaPRO';
  return mo ? mo.nome : '';
}

/* as vagas que os OUTROS modelos abertos ocupam, com o conteudo de cada uma —
 * e o que impede o segundo "ESTRUTURA.ifc" de herdar a ancora do primeiro */
function vagasOcupadas(exceto) {
  var out = {};
  if (!S || !S.modelos) return out;
  for (var i = 0; i < S.modelos.length; i++) {
    var m = S.modelos[i];
    if (m === exceto || !m.modeloId) continue;
    out[m.modeloId] = m.versaoId || '';
  }
  return out;
}
function idElemento(modeloId, el) {
  if (typeof window === 'undefined' || !window.BimId) return { chave: '', globalId: '', instavel: true };
  return window.BimId.doElemento(modeloId, el);
}
/* GlobalId, nome e tag da linha IFC, numa leitura so. flatten=false de
   proposito: sao atributos diretos de IfcRoot/IfcElement, e resolver
   referencias recursivamente aqui — uma vez por elemento, dentro do stream —
   custaria o carregamento inteiro.

   ⚠ O `Name` entra porque e o nome do Revit ("Parede basica:ALV 14
   CHAPISCO:987654"), aquele pelo qual o engenheiro acha a peca e conversa com
   o projetista. Sem guarda-lo, o modelo restaurado do cache passava a chamar
   TODAS as paredes de "Parede" — a peca continuava certa e o unico jeito de
   identifica-la sumia. E a leitura ja estava paga. */
function lerIdentidadeIfc(api, mid, expressID) {
  try {
    var ln = api.GetLine(mid, expressID, false);
    return {
      globalId: (ln && ln.GlobalId && ln.GlobalId.value) || '',
      nomeIfc: (ln && ln.Name && ln.Name.value) || '',
      /* ⚠ O `Description` e o NOME DE MERCADO, e ele estava sendo jogado fora.
         O projetista batiza a familia pela convencao do escritorio
         ("AF_Soldavel_Tubo") e a biblioteca do fabricante ja vem com o nome
         comercial no campo Descricao ("Tubo PVC soldavel agua fria DN 25mm").
         O banco de insumos fala a segunda lingua, nao a primeira — entao para
         casar peca com preco esta e a melhor evidencia que o arquivo tem.
         A leitura ja estava paga: e o mesmo GetLine do GlobalId/Name/Tag. */
      descricao: (ln && ln.Description && ln.Description.value) || '',
      tag: (ln && ln.Tag && ln.Tag.value) || ''
    };
  } catch (_) { return { globalId: '', nomeIfc: '', descricao: '', tag: '' }; }
}
/* ⚠ UMA funcao carimba, e os tres caminhos de carga a chamam. Se cada um
   carimbasse do seu jeito, o vinculo do IFC e o do editor divergiriam — e o
   caminho menos usado seria o que ninguem veria quebrar. E ela tambem roda na
   troca de obra: recarimbar e re-derivar do zero, nao remendar. */
function recarimbarIdentidade() {
  if (!S || !S.modelos) return;
  var B = (typeof window !== 'undefined') ? window.BimId : null;
  /* ⚠ DOIS PASSOS, DE PROPOSITO. Calcular e atribuir no mesmo laco faria o
     segundo modelo enxergar a vaga do primeiro JA trocada, e a resolucao
     dependeria da ordem da lista — a mesma cena daria ancoras diferentes
     conforme a ordem de abertura. */
  var novos = S.modelos.map(function (mo) { return idModelo(nomeDeIdentidade(mo), mo.versaoId, vagasOcupadas(mo)); });
  S.modelos.forEach(function (mo, i) {
    mo.modeloId = novos[i];
    if (mo.sintetico && !mo.versaoId) mo.versaoId = 'sintetico';
    (mo.elementos || []).forEach(function (e) {
      /* o que nasce no OrcaPRO nao veio de IFC: GlobalId proprio, com prefixo,
         para nunca herdar o vinculo de uma peca do projetista */
      if (!e.globalId && mo.sintetico && B) e.globalId = B.sintetico((mo.editor ? 'edit' : 'p3d') + '_' + e.id);
      var r = idElemento(mo.modeloId, e);
      e.chave = r.chave; e.chaveInstavel = r.instavel;
    });
  });
}

// 🧱 Blocok — allowlist de e-mails com acesso (feito p/ um cliente primeiro; fácil de estender).
// No escopo do MÓDULO (não dentro de montar) p/ já estar definido quando a toolbar é construída.
// rogeriosouza... = o dono (RA Engenharia) — sempre liberado pra testar.
/* ⚠ AQUI HAVIA DOIS E-MAILS EM TEXTO PURO — UM DELES DE CLIENTE.
 *
 * `js/` é copiado INTEIRO para os 38 pacotes e para a página pública: o
 * endereço do cliente estava legível em
 * https://ra-engenharia.github.io/orcapro/app/js/bim.js, para qualquer um com
 * o link, em toda release desde que a lista existe.
 *
 * A guarda é legítima — é portão de recurso de cliente pagante, e removê-la
 * trancaria o acesso dele. O que não pode é a guarda SER o endereço da pessoa.
 * Agora são hashes salgados do mesmo endereço: exatamente as mesmas pessoas
 * passam, e ninguém fica publicado.
 *
 * ⚠ Isto NÃO é proteção de segredo — hash de e-mail conhecido é quebrável por
 * tentativa. É proteção de DADO PESSOAL: o endereço deixa de ser legível e de
 * ser indexável. Para quem tenta burlar o portão, a barreira continua sendo a
 * mesma de antes (o login), nem mais nem menos.
 *
 * Mesma família do id de base que carregava o nome de uma pessoa (v1.2.17):
 * guarda que protege pelo NOME de alguém publica esse alguém.
 *
 * ⚠ E O NOME DO CLIENTE TAMBÉM É DADO DELE. Até 31/08/2026 este bloco dizia
 * "feito p/ a <nome da empresa>" em três lugares de `js/`, que viaja para os
 * 38 pacotes e para a página pública: o e-mail virou hash e a razão social
 * ficou legivel do lado. Quem escreve a guarda é quem mais lembra do cliente
 * — e é exatamente aí que o nome escapa.
 *
 * Para liberar mais um e-mail: `node -e` com o `Util.sha256hex` de js/util.js
 * sobre BLOCOK_SAL + e-mail em minúsculas, e acrescentar o hash aqui. */
var BLOCOK_SAL = 'orcapro:blocok:v1:';
var BLOCOK_HASHES = [
  '0414090e312090f655c6feac87873e7addd3767dd8cb37c87134a54a3b3059ef',
  '606cee692085607e07856ca12ec08f9525167d82a21fc48e1f67366ba5607e7e'
];
function blocokEmailLiberado(email) {
  var e = String(email || '').trim().toLowerCase();
  if (!e) return false;
  var U = (typeof window !== 'undefined' && window.Util) ? window.Util : (typeof Util !== 'undefined' ? Util : null);
  /* sem o hasher não dá para decidir — e decidir errado aqui tranca cliente
     pagante fora do que ele comprou. Recusa e deixa a trava da máquina
     (`orcapro:blocok:owner`) responder, que é o caminho do instalador. */
  if (!U || !U.sha256hex) return false;
  try { return BLOCOK_HASHES.indexOf(U.sha256hex(BLOCOK_SAL + e)) >= 0; } catch (_) { return false; }
}

function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

var TIPOS = {
  IFCWALL: 'Parede', IFCWALLSTANDARDCASE: 'Parede', IFCSLAB: 'Laje', IFCBEAM: 'Viga', IFCCOLUMN: 'Pilar',
  IFCDOOR: 'Porta', IFCWINDOW: 'Janela', IFCROOF: 'Cobertura', IFCSTAIR: 'Escada', IFCSTAIRFLIGHT: 'Lance de escada',
  IFCRAILING: 'Guarda-corpo', IFCFURNISHINGELEMENT: 'Mobiliário', IFCPLATE: 'Chapa', IFCMEMBER: 'Perfil/Montante',
  IFCFLOWTERMINAL: 'Louça/terminal', IFCFLOWSEGMENT: 'Tubo/duto', IFCFLOWFITTING: 'Conexão', IFCBUILDINGELEMENTPROXY: 'Elemento genérico',
  IFCCOVERING: 'Revestimento', IFCSPACE: 'Ambiente', IFCFOOTING: 'Fundação', IFCPILE: 'Estaca', IFCCURTAINWALL: 'Fachada cortina'
};

// Códigos de tipo IFC p/ ler os carimbos do exportador pyRevit (OrcaPRO_Etapa/OrcaPRO_CodOrc)
// via relacionamento de property set. web-ifc 0.0.44 NÃO exporta essas constantes → hardcode
// dos códigos de tipo (estáveis no schema). Traversal: IfcRelDefinesByProperties → IfcPropertySet
// (HasProperties) → IfcPropertySingleValue(Name='OrcaPRO_Etapa').
var IFC_RELDEFINESBYPROPERTIES = 4186316022, IFC_PROPERTYSINGLEVALUE = 3650150729;
// IfcSIUnit — p/ normalizar BaseQuantities (que vêm na unidade do arquivo, ex.: mm) em metros.
var IFC_SIUNIT = 448429030;
// IfcBuildingStorey + IfcRelContainedInSpatialStructure — p/ a ferramenta 🏢 Pavimentos
// (códigos conferidos no vendor bim/vendor/web-ifc-api.js, estáveis no schema)
var IFC_BUILDINGSTOREY = 3124254112, IFC_RELCONTAINEDINSPATIALSTRUCTURE = 3242617779;
// v1.1.82 — família/tipo (IfcRelDefinesByType) + propriedades completas (todos os psets):
// códigos conferidos no vendor (web-ifc-api.js): RELDEFINESBYTYPE 10025, PROPERTYSET 10063,
// ELEMENTQUANTITY 10091, ENUMERATED/LIST/BOUNDED/COMPLEX p/ o painel não descartar nada.
var IFC_RELDEFINESBYTYPE = 781010003, IFC_PROPERTYSET = 1451395588, IFC_ELEMENTQUANTITY = 1883228015;
var IFC_RELASSIGNSTOGROUP = 1307041759, IFC_SYSTEM = 2254336722, IFC_DISTRIBUTIONSYSTEM = 3205830791; // v1.1.98 — SISTEMA do IFC (Esgoto/Água…) p/ colorir por sistema
var IFC_PROP_ENUM = 4166981789, IFC_PROP_LIST = 2752243245, IFC_PROP_BOUNDED = 871118103, IFC_PROP_COMPLEX = 2542286263;
/* TOPOLOGIA DA REDE — porta a porta. É o que permite dizer qual conexão entra
 * em cada extremidade de cada tubo, e encadear os trechos na ordem em que a
 * rede corre. Valores lidos do `var IFC... = <numero>` do vendor.
 * ⚠ NÃO copiar os números citados na prosa do comentário acima: "RELDEFINESBYTYPE
 *   10025" é NÚMERO DE LINHA do vendor, não código de tipo. Quem seguir aquilo
 *   ao pé da letra hardcoda 10025 e o traversal devolve zero, em silêncio. */
var IFC_DISTRIBUTIONPORT = 3041715199, IFC_RELCONNECTSPORTTOELEMENT = 4201705270, IFC_RELCONNECTSPORTS = 3190031847;
/* MATERIAL da peça (IfcRelAssociatesMaterial) — é dele que sai o PESO quando o
 * IFC não traz a massa (volume × peso específico, js/bimpeso.js). Códigos lidos
 * do `var IFC... = <numero>` do vendor (ver o ⚠ acima: número de LINHA não serve). */
var IFC_RELASSOCIATESMATERIAL = 2655215786, IFC_MATERIAL = 1838606355, IFC_MATERIALLIST = 2199411900;
var IFC_MATERIALLAYERSETUSAGE = 1303795690, IFC_MATERIALLAYERSET = 3303938423;
var IFC_MATERIALPROFILESETUSAGE = 3079605661, IFC_MATERIALPROFILESET = 164193824;
var IFC_MATERIALCONSTITUENTSET = 2852063980, IFC_MATERIALPROPERTIES = 3265635763;

function montar(host, opts) {
  opts = opts || {};
  // RE-HOME: se já existe um viewer vivo, NÃO cria outro (senão vaza WebGLRenderer + loop RAF +
  // listeners a cada App.render() → "Too many active WebGL contexts"). Reaproveita a MESMA
  // instância, só re-parenta o DOM no novo host e preserva o modelo/estado 4D já carregado.
  if (S && S.alive) {
    S.opts = opts;
    host.innerHTML = '';
    host.style.position = 'relative';
    host.style.background = 'radial-gradient(120% 120% at 50% 0%, #16324f 0%, #0b1a2b 70%)';
    /* ⚠ QUEM NASCE PENDURADO NO HOST TEM DE ENTRAR AQUI. Já aconteceu duas vezes:
     * sisPanel e blocokPanel ficavam presos no host morto e sumiam de vez ao sair
     * e voltar para a aba BIM. Na v1.2.2 quase aconteceu de novo com as três peças
     * novas da mira — guiaH, guiaV e a lupa: o recurso funcionava na primeira
     * visita e sumia calado a partir da segunda, que é o pior jeito de falhar.
     * Os traços dos notáveis não entram na lista porque nascem sob demanda; eles
     * se re-penduram sozinhos em `posicionarNotaveis`. */
    [(S.xr && S.xr.video), S.bar, S.barToggle, S.hud, S.over, S.loading, S.renderer.domElement, S.vcubeEl, S.hint, S.cortePanel, S.corteLPanel, S.snapPanel, S.snapMarca, S.travaChip, S.eixoBar, S.marcasSvg, S.guiaH, S.guiaV, S.lupaEl, S.ctecCfg, S.ctecModal, S.plantaCfg, S.pavPanel, S.visPanel, S.sisPanel, S.blocokPanel, S.p3dPanel, S.editPanel, S.editDist, S.xrPanel, S.xrHud, S.reqPanel].forEach(function (el) { if (el) host.appendChild(el); });
    if (S._onDragOver) { host.addEventListener('dragover', S._onDragOver); host.addEventListener('drop', S._onDrop); } // re-registra drop no host novo
    S.host = host;
    // painel flutuante volta ABERTO com a barra recolhida = caixa presa sem fechador
    // (o usuário voltava ao BIM e "não conseguia mais fechar"). Entra sempre limpo.
    try { if (S._fecharPaineis && S.bar && S.bar.style.display === 'none') S._fecharPaineis(null); } catch (eP) {}
    setTimeout(function () { if (S && S._resize) S._resize(); if (S && S._ajustarTop) S._ajustarTop(); if (S && S._aplicarTema) S._aplicarTema(); try { if (window.BimMesa) window.BimMesa.aoMontar(); } catch (eM) {} }, 0);   /* a barra do modo mesa morava no host antigo */ // tema re-aplicado (o fundo acima é só o default até aqui)
    return;
  }
  // CONTEXTO PERDIDO: o viewer antigo morreu (S.alive=false) mas os listeners globais e o
  // renderer continuavam pendurados — cada remount vazava keydown/keyup/mousemove/resize
  // (teclado disparando em dobro) + um WebGLRenderer morto. Desmonta ANTES de criar o novo.
  if (S && !S.alive) desmontarMorto();
  host.innerHTML = '';
  host.style.position = 'relative';
  host.style.background = 'radial-gradient(120% 120% at 50% 0%, #16324f 0%, #0b1a2b 70%)';

  // v1.1.82 — ícones SVG line-art (estilo Revit) no lugar dos emojis: stroke currentColor,
  // 14px, herdam a cor do tema. ico(nome) devolve a tag inline.
  function ico(n) {
    /* ⚠ NOME QUE NAO EXISTE AQUI DESENHA UM SVG VAZIO, em silêncio: `P[n]`
       vira '' e sai um botão sem símbolo. Achado OLHANDO a foto do painel em
       09/09/2026 — o botão de fechar era uma caixa branca vazia, e no fundo
       navy antigo ninguém notava. Faltavam quatro: `fechar`, `camadas` (o
       botão Iguais), `relatorios` (o Planilha) e `requisicoes` (o próprio
       Requisitar). É o mesmo defeito do catálogo `Icones`, que já ganhou
       assert em tools/test-suprimentos-editar.js. */
    var P = {
      fechar: '<path d="M4 4l8 8M12 4l-8 8"/>',
      camadas: '<path d="M8 2l6 3-6 3-6-3z"/><path d="M2 8l6 3 6-3"/><path d="M2 11l6 3 6-3"/>',
      relatorios: '<path d="M4 2h5l3 3v9H4z"/><path d="M6 7.5h4M6 10h4M6 12.5h2"/>',
      requisicoes: '<path d="M3 4h10v10H3z"/><path d="M6 2h4v3H6z"/><path d="M5.5 8.5h5M5.5 11h3"/>',
      abrir: '<path d="M2 5h4l2 2h6v6H2z"/><path d="M2 5V3h5"/>',
      lixo: '<path d="M4 5h8M6 5V3h4v2M5 5l1 8h4l1-8"/>',
      ultra: '<path d="M8 2l1.6 4.2L14 8l-4.4 1.8L8 14l-1.6-4.2L2 8l4.4-1.8z"/>',
      orbita: '<circle cx="8" cy="8" r="3.4"/><path d="M2.2 10.5C1 8 4 4 8 3.4M13.8 5.5C15 8 12 12 8 12.6"/>',
      voo: '<path d="M2 9l12-5-4 6 4 4-6-2-3 3z"/>',
      medir: '<path d="M2 12L12 2l2 2L4 14z"/><path d="M5 11l1 1M7 9l1 1M9 7l1 1M11 5l1 1"/>',
      area: '<path d="M3 4l10-1 -1 9-9 1z"/><path d="M3 4l9 8"/>',
      angulo: '<path d="M3 13L13 3M3 13h10"/><path d="M7 13a5 5 0 0 0-1.5-3.5"/>',
      snap: '<path d="M4 2v6a4 4 0 0 0 8 0V2"/><path d="M4 2h2M10 2h2"/>',
      cotas: '<path d="M2 8h12M2 6v4M14 6v4M6 8l-2-1.5M6 8l-2 1.5M10 8l2-1.5M10 8l2 1.5"/>',
      planta: '<rect x="3" y="3" width="10" height="10"/><path d="M3 8h5v5"/>',
      corte: '<path d="M2 10L14 4"/><circle cx="4" cy="12" r="1.6"/><circle cx="8" cy="11" r="1.6"/><path d="M9 9l5 3"/>',
      p3d: '<path d="M8 2l5 3v6l-5 3-5-3V5z"/><path d="M8 8l5-3M8 8L3 5M8 8v6"/>',
      editar: '<path d="M3 13l1-3 7-7 2 2-7 7z"/><path d="M10 4l2 2"/>',
      pav: '<path d="M2 12h12M2 9h12M2 6h12"/><path d="M4 12V4h8v8"/>',
      ver: '<path d="M2 8s2.5-4 6-4 6 4 6 4-2.5 4-6 4-6-4-6-4z"/><circle cx="8" cy="8" r="1.8"/>',
      foto: '<rect x="2" y="4" width="12" height="9" rx="1.5"/><circle cx="8" cy="8.5" r="2.6"/><path d="M5 4l1-1.5h4L11 4"/>',
      fit: '<path d="M2 5V2h3M11 2h3v3M14 11v3h-3M5 14H2v-3"/>',
      tema: '<circle cx="8" cy="8" r="5.6"/><path d="M8 2.4v11.2M8 8l4-4M8 8l4 4"/>',
      parede: '<path d="M2 12V6h12v6z"/><path d="M6 6v3M10 9v3M2 9h12"/>',
      laje: '<path d="M2 9l6-3 6 3-6 3z"/><path d="M2 9v2l6 3 6-3V9"/>',
      pilar: '<rect x="6" y="3" width="4" height="10"/><path d="M4 3h8M4 13h8"/>',
      mover: '<path d="M8 2v12M2 8h12M8 2l-2 2M8 2l2 2M8 14l-2-2M8 14l2-2M2 8l2-2M2 8l2 2M14 8l-2-2M14 8l-2 2"/>',
      nota: '<path d="M8 14V7"/><circle cx="8" cy="4.6" r="2.6"/>',
      xr: '<path d="M2 6.5A1.5 1.5 0 0 1 3.5 5h9A1.5 1.5 0 0 1 14 6.5v3A1.5 1.5 0 0 1 12.5 11h-2.2L8 9 5.7 11H3.5A1.5 1.5 0 0 1 2 9.5z"/><circle cx="5" cy="8" r="0.7"/><circle cx="11" cy="8" r="0.7"/>',
      grafico: '<path d="M2 2v11a1 1 0 0 0 1 1h11"/><path d="M6 11V7M9 11V4M12 11V6"/>',
      sistemas: '<path d="M8 2s4 4.6 4 7.4A4 4 0 0 1 4 9.4C4 6.6 8 2 8 2z"/><path d="M6.4 9.6a1.7 1.7 0 0 0 1.7 1.7"/>'
    };
    return '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px;margin-right:3px">' + (P[n] || '') + '</svg>';
  }

  /* ⚠ `accept=".ifc"` IMPEDE ABRIR IFC NO CELULAR — o contrário do que promete.
   *
   * O atributo `accept` só sabe filtrar por dois caminhos: tipo MIME registrado
   * ou extensão. No computador o navegador entende a extensão e o diálogo abre
   * normal. No Android o Chrome traduz `accept` para tipos MIME antes de chamar
   * o seletor do sistema — e `.ifc` não tem MIME registrado em lugar nenhum.
   * Resultado: o seletor abre com TUDO em cinza, ou não abre. No iOS o app
   * Arquivos faz o mesmo. Para quem está com o celular na mão, isso é
   * exatamente "toco em + IFC e não acontece nada".
   *
   * Mesma história do `.dxf` do 2D→3D — as duas únicas entradas do app cuja
   * extensão o sistema operacional não conhece. `.xlsx`, `.csv`, `.json` e
   * `image/*` têm MIME e por isso nunca deram problema.
   *
   * Então: no toque, o seletor abre SEM filtro (mostra tudo, e o cliente
   * encontra o arquivo dele) e a validação passa a ser NOSSA, na hora em que o
   * arquivo chega — que é onde ela devia estar desde sempre. Ver o `change`
   * mais abaixo: ele aceitava qualquer arquivo escolhido e mandava direto para
   * o interpretador de IFC, sem olhar o nome; só o arrastar-e-soltar filtrava. */
  function ehToque() {
    try { return !(window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches); }
    catch (e) { return false; }
  }
  /* ⚠ `.skp` ENTRA NO FILTRO DO SELETOR, MAS NUNCA NO INTERPRETADOR.
   * O SketchUp grava num formato fechado (Trimble) que nenhum navegador lê — o
   * que o OrçaPRO abre é o IFC que o próprio SketchUp Pro exporta. Antes, o
   * cliente com um .skp na mão abria o seletor, não via o arquivo dele (o
   * filtro só mostrava .ifc) e concluía que "o BIM não abre SketchUp"; se
   * trocava para "Todos os arquivos", ganhava o toast genérico de "não é IFC"
   * e desistia do mesmo jeito. Com o .skp visível, ele escolhe o arquivo e
   * recebe o passo a passo da exportação (ver orientarSketchUp) em vez de um
   * beco. Quem decide o destino de cada arquivo é classificarEntradaBim — uma
   * função só, usada pelo seletor E pelo arrastar-e-soltar, para os dois
   * caminhos não divergirem de novo (o drop descartava em silêncio o que o
   * seletor avisava). Ela é pura de propósito: tools/test-bim-skp.js a extrai
   * do fonte e a roda em Node. */
  function aceitaIFC() { return ehToque() ? '' : ' accept=".ifc,.skp,.zip"'; }
  /* .zip = o ARQUIVO DA OBRA (pacote + modelo, js/pacoteobra.js): quem o
     recebe no grupo solta ele aqui como soltaria um .ifc — e quem abre é a
     tela (opts.onArquivoObra), que confere e importa tudo */
  function classificarEntradaBim(itens) {
    var r = { ifc: [], skp: [], zip: [], outros: [] };
    (itens || []).forEach(function (it) {
      var nome = String(typeof it === 'string' ? it : ((it && it.name) || ''));
      if (/\.ifc$/i.test(nome)) r.ifc.push(it);
      else if (/\.skp$/i.test(nome)) r.skp.push(it);
      else if (/\.zip$/i.test(nome)) r.zip.push(it);
      else r.outros.push(it);
    });
    return r;
  }

  // toolbar compacta
  var bar = document.createElement('div');
  /* ⚠ z-index 4, NÃO 3 — o dock mora aqui dentro e empatava com o HUD.
   * O HUD ("Elementos · Triângulos", canto inferior direito) também era 3 e é
   * criado DEPOIS da fita: empate em z-index se resolve por ordem no DOM, e
   * quem vem depois pinta por cima. Como o dock é filho da fita, o `z-index:6`
   * dele só vale entre os filhos DELA — perdia junto. Numa janela baixa, onde
   * a fila do dock alcança a altura do HUD, a última aba parava de receber
   * toque e o cliente relatava "clico e não abre".
   * 4 é o mínimo que resolve: tudo o que precisa continuar por cima da fita
   * (rótulos de medida, controles de planta e corte, botão de recolher) já é
   * 4 ou 5 e é criado depois, então segue ganhando o empate como sempre. */
  bar.style.cssText = 'position:absolute;left:0;right:0;top:0;z-index:4;display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:8px 10px;background:linear-gradient(180deg,rgba(15,39,64,.9),rgba(15,39,64,0))';
  /* ⚠ A MARCA É O QUE A CASCA USA PARA TIRAR A BARRA DE CIMA DO 3D. No
     computador, com a fita no topo, cada botão daqui tem comando na fita
     (BIM.botao aciona o daqui mesmo, escondido) — a barra continua no DOM
     porque o estado de cada ferramenta e o despacho do clique moram nela.
     No celular e no modo foco ela volta a aparecer (css/bim-revit.css). */
  bar.setAttribute('data-bim-barra', '1');
  bar.innerHTML =
    '<button class="btn sm primary" data-b="abrir">' + ico('abrir') + '+ IFC</button>' +
    '<button class="btn sm" data-b="exemplo">Exemplo</button>' +
    '<button class="btn sm" data-b="limpar" title="Remove todos os modelos carregados">' + ico('lixo') + '</button>' +
    '<span style="flex:1"></span>' +
    '<button class="btn sm" data-b="ultra" title="Qualidade ultra: nitidez máxima (usa mais GPU)">' + ico('ultra') + 'Ultra</button>' +
    '<button class="btn sm on" data-b="orbita" style="background:#16a34a;color:#fff">' + ico('orbita') + 'Órbita</button>' +
    '<button class="btn sm" data-b="voo">' + ico('voo') + 'Voo</button>' +
    '<button class="btn sm" data-b="medir" title="Trena: clique em 2 pontos do modelo pra medir a distância">' + ico('medir') + 'Medir</button>' +
    '<button class="btn sm" data-b="area" title="Área e perímetro: clique os cantos (3+) e feche clicando de novo no 1º ponto">' + ico('area') + 'Área</button>' +
    '<button class="btn sm" data-b="angulo" title="Ângulo entre 3 pontos: 1º ponto, vértice, 2º ponto">' + ico('angulo') + 'Ângulo</button>' +
    '<button class="btn sm" data-b="snap" title="Snap das medições: agarrar em vértice, meio de aresta ou aresta">' + ico('snap') + '</button>' +
    '<button class="btn sm" data-b="limpar-medidas" title="Apagar todas as cotas medidas" style="display:none">' + ico('cotas') + 'Cotas</button>' +
    /* Cotar rede: o comprimento JÁ VEM no IFC (BaseQuantities). Estes quatro
       botões só mostram o que o projetista publicou — nenhum deles calcula. */
    '<button class="btn sm" data-b="cota" title="Cotar rede: toque num tubo e o comprimento dele aparece em cima da peça — o número vem do IFC, não é medido na tela">' + ico('cotas') + 'Cotar</button>' +
    '<button class="btn sm" data-b="cota-iguais" title="Cotar todos os trechos iguais ao último tocado (mesma família, ou mesmo tipo quando o IFC não trouxer família)">' + ico('camadas') + 'Iguais</button>' +
    '<button class="btn sm" data-b="cota-todas" title="Cotar a rede inteira que estiver à vista">' + ico('sistemas') + 'Toda a rede</button>' +
    '<button class="btn sm" data-b="cota-numerar" title="Numera os tubos seguindo o encadeamento da rede (R01-T001, R01-T002...) e mostra o numero em cima de cada peca">' + ico('cotas') + 'Numerar</button>' +
    '<button class="btn sm" data-b="cota-planilha" title="Baixa a relacao dos tubos por ramal: numero, comprimento e a conexao de cada extremidade">' + ico('relatorios') + 'Planilha</button>' +
    '<button class="btn sm" data-b="req-bim" title="Levanta as pecas do modelo por familia, casa com o banco de insumos e monta a requisicao de material">' + ico('requisicoes') + 'Requisitar</button>' +
    '<button class="btn sm" data-b="cota-limpar" title="Apagar as cotas da rede">' + ico('lixo') + 'Limpar cotas</button>' +
    '<button class="btn sm" data-b="planta" title="Planta baixa: corta o modelo numa altura e vê de cima">' + ico('planta') + 'Planta</button>' +
    '<button class="btn sm" data-b="corte" title="Corte livre: plano de corte horizontal, vertical ou em qualquer ângulo">' + ico('corte') + 'Corte</button>' +
    '<button class="btn sm" data-b="p3d" title="Reconstruir 3D a partir da planta baixa em DXF (assistido: o sistema propõe as paredes, você confirma)">' + ico('p3d') + '2D→3D</button>' +
    '<button class="btn sm" data-b="editar" title="Editor: criar paredes, lajes e pilares SINTÉTICOS, mover, apagar e anotar — salvo com a obra">' + ico('editar') + 'Editar</button>' +
    '<button class="btn sm" data-b="pav" title="Pavimentos declarados no IFC: isolar um andar ou gerar a planta dele">' + ico('pav') + 'Pav.</button>' +
    '<button class="btn sm" data-b="vis" title="Visibilidade: isolar ou ocultar o elemento selecionado (duplo-clique seleciona)">' + ico('ver') + 'Ver</button>' +
    '<button class="btn sm" data-b="xr" title="Realidade Mista/Virtual: andar dentro do modelo em escala real (1:1) ou escolhida, medir, ver por disciplina e gerar QR para o celular">' + ico('xr') + 'RA/RV</button>' +
    '<button class="btn sm" data-b="sistema" title="Colorir a tubulação por sistema hidrossanitário (água fria, água quente, esgoto, pluvial, gás, incêndio, ventilação) com cores editáveis — vale na Planta baixa e no RA/RV">' + ico('sistemas') + 'Sistemas</button>' +
    (blocokLiberado() ? '<button class="btn sm" data-b="blocok" title="Plantas Executivas Blocok: lê as paredes do IFC e gera a prancha de cada parede com as placas 90×90 numeradas e paginadas + tabela de material (placas + insumos calculados) + carga na fundação">' + ico('parede') + 'Blocok</button>' : '') +
    '<button class="btn sm" data-b="foto" title="Salvar foto PNG do modelo com carimbo de data">' + ico('foto') + 'Foto</button>' +
    '<button class="btn sm" data-b="fit">' + ico('fit') + 'Enquadrar</button>' +
    '<button class="btn sm" data-b="tema" title="Cor da interface do BIM: OrçaPRO → Revit → Claro">' + ico('tema') + '</button>' +
    /* ⚠ SEM `accept` NO CELULAR — ver aceitaIFC() logo abaixo. */
    '<input type="file" data-b="file"' + aceitaIFC() + ' multiple style="display:none">';
  host.appendChild(bar);

  // v1.1.121 — DOCK LATERAL: as ferramentas saem da fita corrida (lista solta que
  // tampava a vista) e viram GRUPOS por categoria numa aba vertical à esquerda.
  // Passar o mouse (ou tocar) num grupo expande o leque com as ferramentas dele.
  // O dock é filho do BAR em position:absolute — não entra no bar.offsetHeight
  // (o _ajustarTop segue medindo só a fita do topo) e os botões continuam
  // descendentes do bar (dispatch de clique e querySelector de estado intactos).
  function icoG(n) { return ico(n).replace('width="13" height="13"', 'width="17" height="17"').replace('margin-right:3px', 'margin-right:0'); }
  var dock = document.createElement('div');
  // overflow-y:auto: em viewport baixa (celular deitado) o dock ROLA em vez de ser
  // clipado pelo overflow:hidden do card — os leques abrem em position:fixed (fora
  // do clip), então a rolagem não os corta. maxHeight dinâmico no aplicarEstiloToggle.
  dock.style.cssText = 'position:absolute;left:10px;top:calc(100% + 2px);display:flex;flex-direction:column;gap:6px;z-index:6;pointer-events:auto;overflow-y:auto;overflow-x:hidden;padding-right:2px';
  var GRUPOS_DOCK = [
    { rot: 'Medição', ic: 'medir', bs: ['medir', 'area', 'angulo', 'snap', 'limpar-medidas'] },
    /* grupo PRÓPRIO, não um apêndice de Medição: cotar rede não mede nada —
       lê o que o projeto já traz. Misturar os dois faria o encanador achar
       que o número saiu de um clique dele. */
    { rot: 'Cotar rede', ic: 'cotas', bs: ['cota', 'cota-iguais', 'cota-todas', 'cota-numerar', 'cota-planilha', 'cota-limpar'] },
    { rot: 'Requisitar', ic: 'requisicoes', bs: ['req-bim'] },
    { rot: 'Cortes & Plantas', ic: 'planta', bs: ['planta', 'corte', 'pav'] },
    { rot: 'Visibilidade', ic: 'ver', bs: ['vis', 'sistema', 'foto'] },
    { rot: 'Edição & 2D→3D', ic: 'editar', bs: ['editar', 'p3d', 'blocok'] },
    { rot: 'Imersivo RA/RV', ic: 'xr', bs: ['xr'] }
  ];
  // Análise & Orçamento: painéis da página (quantitativo, clash, 4D…) abrem por AQUI,
  // sem rolar a página — a Gestão injeta o abridor via opts.onPainel.
  var PAINEIS_DOCK = [['modelos', 'Modelos carregados'], ['4d', 'Simulação 4D'], ['clash', 'Compatibilização (clash)'], ['qto', 'Quantitativos'], ['familias', 'Banco de famílias'], ['6d', '6D/7D Ciclo de vida']];
  // Ambiente com mouse de verdade? (touch NÃO deve ganhar hover: o tap emite
  // mouseenter sintético ANTES do click e o leque abria-e-fechava no mesmo toque)
  var dockHover = !!(window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches);
  var flyTimer = null;
  /* ⚠ "DENTRO DA JANELA" NÃO BASTA — E O CULPADO NÃO É QUEM EU PENSEI.
   *
   * O leque é `position:fixed`, o que o faz escapar do `overflow:hidden` do
   * card. Só que `position:fixed` NÃO tira ninguém do contexto de
   * empilhamento: o cabeçalho do app tem `z-index:20` num ramo acima, e
   * quando o leque abre por cima dele é o CABEÇALHO que pinta na frente —
   * `z-index:60` no leque não vale nada de dentro do card. O toque vai parar
   * no cabeçalho e o botão do leque não recebe nada.
   *
   * Cheguei a escrever esta função procurando um cabeçalho `position:fixed`
   * para descontar. Não existe: ele é `relative`, no topo do documento. O que
   * descreve a área utilizável não é a janela nem o cabeçalho — é o PRÓPRIO
   * VISUALIZADOR, que já nasce abaixo de tudo isso. Prender leque e dock à
   * interseção do host com a janela resolve os dois casos sem adivinhar quem
   * está por cima.
   *
   * Vale para o dock e para o leque, e por isso é uma conta só. */
  /* Dois fundos, de propósito:
   *   `fundoHost` — onde o DOCK tem de parar: ele é filho do card e o
   *     `overflow:hidden` do card o corta no fim do visualizador.
   *   `fundo` — até onde o LEQUE pode ir: ele é `position:fixed`, não sofre
   *     esse corte, e o que existe abaixo do visualizador é conteúdo de página
   *     sem `z-index`, que não pinta por cima dele. Limitá-lo ao fim do
   *     visualizador era mais apertado que o necessário e escondia botões
   *     atrás de rolagem à toa — no celular deitado, 91 px a mais de espaço. */
  function faixaVisivel() {
    var alturaJ = window.innerHeight || document.documentElement.clientHeight || 800;
    var r;
    try { r = ((S && S.host) || host).getBoundingClientRect(); } catch (_) { r = null; }
    if (!r || !r.height) return { topo: 0, fundo: alturaJ, fundoHost: alturaJ };
    return { topo: Math.max(0, r.top), fundo: alturaJ, fundoHost: Math.min(alturaJ, r.bottom) };
  }
  function fecharFlys() { if (flyTimer) { clearTimeout(flyTimer); flyTimer = null; } dock.querySelectorAll('.bim-fly').forEach(function (f) { f.style.display = 'none'; }); }
  function agendarFechar() { if (flyTimer) clearTimeout(flyTimer); flyTimer = setTimeout(fecharFlys, 320); } // delay cobre o vão head→leque (fix do gate: mouseleave fechava no caminho)
  function abrirFly(head, fly) {
    fecharFlys();
    // position:fixed = escapa do overflow do card/dock; ancorado no head na hora de abrir
    var r = head.getBoundingClientRect();
    fly.style.display = 'flex';
    var fx = faixaVisivel();
    var larguraJ = window.innerWidth || 400;
    /* leque mais alto que a faixa visível ROLA dentro dela — em vez de vazar
       por cima do cabeçalho ou por baixo da dobra */
    fly.style.maxHeight = Math.max(120, Math.floor(fx.fundo - fx.topo - 16)) + 'px';
    var h = Math.min(fly.offsetHeight || 200, fx.fundo - fx.topo - 16);
    /* ⚠ COM O DOCK DEITADO O LEQUE NÃO PODE ABRIR AO LADO. Ao lado de uma aba
       da fila fica em cima da aba seguinte, e a última abriria fora da tela.
       Deitado ele desce (ou sobe, se não houver espaço embaixo) e se alinha
       pela esquerda da aba, preso dentro da janela. */
    if (dock.getAttribute('data-dir') === 'row') {
      var w = fly.offsetWidth || 172;
      fly.style.left = Math.round(Math.max(8, Math.min(r.left, larguraJ - w - 8))) + 'px';
      var abaixo = r.bottom + 4;
      var cabeAbaixo = abaixo + h + 8 <= fx.fundo;
      fly.style.top = Math.round(cabeAbaixo ? abaixo : Math.max(fx.topo + 8, r.top - h - 4)) + 'px';
      return;
    }
    fly.style.left = (r.right + 4) + 'px';
    fly.style.top = Math.round(Math.max(fx.topo + 8, Math.min(r.top, fx.fundo - h - 8))) + 'px';
  }
  function montarGrupo(g) {
    var wrap = document.createElement('div');
    wrap.style.cssText = 'position:relative;flex:0 0 auto';
    var head = document.createElement('button');
    head.className = 'btn sm';
    head.setAttribute('data-grp', g.rot);
    head.title = g.rot;
    head.style.cssText = 'width:42px;height:42px;display:flex;align-items:center;justify-content:center;border-radius:11px;padding:0;box-shadow:0 2px 10px rgba(0,0,0,.35)';
    head.innerHTML = icoG(g.ic);
    var fly = document.createElement('div');
    fly.className = 'bim-fly';
    fly.style.cssText = 'position:fixed;display:none;flex-direction:column;gap:4px;padding:8px;border-radius:11px;min-width:172px;max-height:70vh;overflow-y:auto;box-shadow:0 10px 30px rgba(0,0,0,.45);z-index:60';
    fly.innerHTML = '<div class="bim-fly-tit" style="font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;opacity:.75;padding:0 4px 2px">' + g.rot + '</div>';
    if (g.bs) g.bs.forEach(function (k) {
      var b = bar.querySelector('[data-b="' + k + '"]');
      if (!b) return; // ex.: blocok não liberado
      b.style.width = '100%';
      b.style.justifyContent = 'flex-start';
      fly.appendChild(b);
    });
    if (g.pp) g.pp.forEach(function (par) {
      var pb = document.createElement('button');
      pb.className = 'btn sm';
      pb.setAttribute('data-pp', par[0]);
      pb.style.cssText = 'width:100%;justify-content:flex-start';
      pb.innerHTML = ico('grafico') + par[1];
      fly.appendChild(pb);
    });
    wrap.appendChild(head); wrap.appendChild(fly);
    if (dockHover) {
      // Desktop: hover abre; sair agenda fechar com DELAY (320ms cobre o vão até o
      // leque — achado do gate: fechava no meio do caminho); entrar de novo cancela.
      wrap.addEventListener('mouseenter', function () { abrirFly(head, fly); });
      wrap.addEventListener('mouseleave', agendarFechar);
      // clique no head NUNCA fecha em desktop (hover já abriu; fechar aqui parecia
      // botão quebrado — achado do gate). Ele só garante aberto.
      head.addEventListener('click', function (ev) { ev.stopPropagation(); abrirFly(head, fly); });
    } else {
      // Touch: o TOQUE é o único alternador (sem hover sintético no meio)
      head.addEventListener('click', function (ev) {
        ev.stopPropagation();
        var aberto = fly.style.display === 'flex';
        if (aberto) fecharFlys(); else abrirFly(head, fly);
      });
    }
    dock.appendChild(wrap);
  }
  GRUPOS_DOCK.forEach(montarGrupo);
  if (opts && opts.onPainel) montarGrupo({ rot: 'Análise & Orçamento', ic: 'grafico', pp: PAINEIS_DOCK });
  bar.appendChild(dock);
  // ferramenta clicada OU painel pedido → fecha o leque (a ação já está em curso)
  // (usa S.opts quando existir: o re-home troca os callbacks sem reconstruir o dock)
  dock.addEventListener('click', function (e) {
    var pb = e.target.closest('[data-pp]');
    var oAtual = (S && S.opts) || opts;
    if (pb && oAtual && oAtual.onPainel) { fecharFlys(); oAtual.onPainel(pb.getAttribute('data-pp')); return; }
    if (e.target.closest('[data-b]')) { if (flyTimer) clearTimeout(flyTimer); flyTimer = setTimeout(fecharFlys, 60); }
  });
  // toque fora do dock fecha o leque aberto (no touch não há mouseleave);
  // guardado em S e removido no desmonte (senão acumula 1 listener por remount)
  var dockDocClick = function (e) { if (!dock.contains(e.target)) fecharFlys(); };
  document.addEventListener('click', dockDocClick, true);
  function dockRepintar(T) {
    dock.querySelectorAll('.bim-fly').forEach(function (f) { f.style.background = T.painel; f.style.border = '1px solid ' + T.borda; f.style.color = T.texto; });
  }

  // v1.1.86 — RECOLHER a barra de ferramentas: ela cresceu (quebra em 2+ linhas) e tampava a
  // vista. Um botão discreto no canto esconde/mostra todos os botões; o estado fica salvo.
  var barToggle = document.createElement('button');
  barToggle.className = 'btn sm';
  barToggle.setAttribute('data-bim-barra-toggle', '1');
  barToggle.title = 'Mostrar ou esconder a barra de ferramentas (deixa a vista limpa)';
  // v1.1.114 — CELULAR: o toggle era pequeno e ficava no TOPO do viewer; rolando a página
  // pra ver o 3D ele saía da tela e o cliente "perdia" as ferramentas (relato real).
  // Em tela pequena vira um FAB verde GRANDE e fixo no pé do viewer (sempre à vista),
  // e a barra aberta ganha rolagem própria (não tampa mais metade da vista).
  // DINÂMICO (gate v1.1.114): recalculado no resize — celular aberto em landscape (>640px)
  // ou janela de PC estreitada trocam de modo na hora, sem reabrir a aba BIM.
  var ehTelaPequena = (host.clientWidth || window.innerWidth || 1024) <= 640;
  var barraAberta = !ehTelaPequena;
  try { var _pref = localStorage.getItem('orcapro:bim:barra'); if (_pref) barraAberta = _pref !== 'recolhida'; } catch (_) {}
  /* ⚠ MODO VISITANTE (o link da RA/RV aberto no celular de quem não tem o
     OrçaPRO). A barra do computador inteira aparecia para o cliente: "+ IFC",
     "Exemplo" (que abria o modelo de outra obra), a LIXEIRA que remove os
     modelos e o lápis do editor — e o botão Reunião do visor cobria o
     "+ IFC". O visitante tem a barra própria (js/rvvisor.js), que só chama a
     API pública; aqui a barra e o botão "Ferramentas" nem aparecem. */
  var visitante = !!opts.visitante;
  if (visitante) barraAberta = false;
  function aplicarEstiloToggle() {
    ehTelaPequena = (host.clientWidth || window.innerWidth || 1024) <= 640;
    if (ehTelaPequena) {
      // FIXED (viewport): o viewer costuma ser mais alto que a tela do celular — ancorado no
      // host, o botão sumia ao rolar (relato real do cliente). Fixo, está SEMPRE à mão enquanto
      // a aba BIM existir (é filho do host: sai junto quando troca de módulo). O toast
      // ⚠ O balão "Instalar como app" (#opr-install) MORAVA neste canto e o FAB subia
      // pra cima dele. Ele deixou de existir: virou botão fixo na barra de cima
      // (js/ui.js), porque flutuando não aparecia no iOS e podia ser dispensado para
      // sempre. A leitura abaixo fica de propósito — devolve 14 (o lugar natural do
      // FAB) quando não acha nada, e volta a ceder espaço se algum dia outro balão
      // usar esse id.
      // z-index 40: acima de tudo do viewer (z≤7) e ABAIXO de modal (z-50), busca (z-70) e
      // toasts (z-100) — o FAB nunca cobre a UI do app (achado do gate).
      var inst = document.getElementById('opr-install');
      var bb = (inst && inst.offsetHeight) ? (inst.offsetHeight + 26) : 14;
      barToggle.style.cssText = 'position:fixed;right:12px;bottom:' + bb + 'px;z-index:40;padding:12px 18px;font-size:14.5px;font-weight:800;border:0;border-radius:999px;background:#16a34a;color:#fff;box-shadow:0 6px 22px rgba(0,0,0,.5);cursor:pointer';
      // v1.1.121: SEM overflow/maxHeight aqui — o overflow:auto CLIPAVA o dock lateral
      // (filho absoluto abaixo da caixa do bar). A fita agora tem só ~9 botões (2 linhas);
      // quem organiza o resto é o dock por grupos.
      bar.style.maxHeight = ''; bar.style.overflowY = ''; bar.style.paddingBottom = '';
    } else {
      barToggle.style.cssText = 'position:absolute;right:10px;top:8px;z-index:5;padding:5px 9px;font-size:12px;opacity:.94;box-shadow:0 2px 8px rgba(0,0,0,.35)';
      bar.style.maxHeight = ''; bar.style.overflowY = ''; bar.style.paddingBottom = '';
    }
    // Viewport baixa (celular deitado/janela curta): o dock ROLA dentro do canvas em
    // vez de ser clipado pelo overflow:hidden do card (achado do gate — os últimos
    // grupos, incluindo Análise & Orçamento, ficavam inclicáveis).
    /* ⚠ A CONTA TINHA DE SER SOBRE A PARTE VISÍVEL, NÃO SOBRE O CANVAS INTEIRO.
     *
     * Medido no celular deitado (812×375): o visualizador fica com 173 px de
     * altura e COMEÇA em y = −35, porque a página está rolada; e o cabeçalho
     * fixo do app ocupa os primeiros ~48 px da tela. A conta antiga usava
     * `clientHeight` do canvas — 173 px, como se todos eles estivessem à vista
     * — e ainda tinha um piso de 120 px que ignorava o que sobrava de fato.
     * Resultado: das seis abas do dock, DUAS ficavam sob o cabeçalho fixo e
     * três abaixo da dobra. Quem toca onde vê a aba acerta outro elemento —
     * é o "clico na aba e não abre" relatado no celular.
     *
     * Agora a faixa é a interseção do canvas com o que realmente aparece:
     * abaixo do cabeçalho fixo e acima do fim da janela. O dock é empurrado
     * para dentro dela e rola ali dentro, com todas as abas alcançáveis. */
    try {
      var rH = ((S && S.host) || host).getBoundingClientRect();
      var rB = bar.getBoundingClientRect();
      /* mesma conta do leque — `faixaVisivel` mede o cabeçalho FIXO em vez de
         cravar 48 px, porque ele muda de altura entre celular, tablete e o
         modo foco, que o esconde por inteiro */
      var fxD = faixaVisivel();
      var visTopo = Math.max(rH.top, fxD.topo);
      var visFundo = Math.min(rH.bottom, fxD.fundoHost);
      var abaixoDaBarra = Math.max(visTopo, rB.bottom + 2);
      var disponivel = Math.floor(visFundo - abaixoDaBarra - 8);
      /* empurra o dock para dentro da faixa visível (o `top` é relativo à
         barra, que é o offsetParent) */
      dock.style.top = Math.round(abaixoDaBarra - rB.top) + 'px';
      /* SEM piso artificial: 120 px onde só cabem 60 devolve o mesmo defeito
         que esta correção fecha. Abaixo de 44 px não cabe nem uma aba — aí o
         dock some, e o cliente usa a fita do topo, que continua inteira. */
      /* ⚠ COLUNA QUE ROLA NÃO RESOLVE NO CELULAR DEITADO — só troca o defeito.
       * Com a faixa visível corrigida, o toque passou a acertar o alvo certo;
       * mas em 812×375 sobram 115 px de altura para SEIS abas de 48 px. Ficavam
       * duas à vista e quatro atrás de uma rolagem sem barra nem seta: para
       * quem está com o celular na mão, "não consigo abrir" continua valendo.
       *
       * Deitado sobra o que falta em pé: LARGURA. Seis abas em fila dão 288 px
       * num visualizador de 800 — cabem todas, sem rolagem nenhuma. Então
       * quando a altura não comporta a coluna e a largura comporta a fila, o
       * dock deita. O leque acompanha (ver abrirFly). */
      var nGrupos = dock.children.length || 6;
      var precisaAltura = nGrupos * 48;
      var precisaLargura = nGrupos * 48 + 20;
      /* ⚠ O DOCK NUNCA PODE SUMIR. Escrevi antes um `display:none` para quando
       * não coubesse, com a nota "o cliente usa a fita do topo". Está errado:
       * `montarGrupo` MOVE os botões da fita para dentro dos leques
       * (`fly.appendChild(b)`) — some o dock, somem as 14 ferramentas, sem
       * outro caminho. Medido numa janela de 1000×439: o dock desaparecia por
       * inteiro. Um dock apertado é ruim; um dock ausente é a ferramenta
       * inalcançável, que é justamente o defeito relatado.
       * Sem piso de altura na decisão: a fila precisa de 46 px, e quando nem
       * isso cabe ela ainda é a menos ruim das opções. */
      var deitar = disponivel < precisaAltura && (rH.width || 0) >= precisaLargura;
      dock.setAttribute('data-dir', deitar ? 'row' : 'col');
      if (deitar) {
        dock.style.display = 'flex';
        dock.style.flexDirection = 'row';
        dock.style.maxHeight = '';
        dock.style.height = '46px';
        dock.style.overflowY = 'hidden';
        dock.style.overflowX = 'auto';
        /* ⚠ LARGURA POR CONTEÚDO, NÃO ESTICADA ATÉ A DIREITA.
         * A primeira versão fazia `right:10px` para a fila ocupar a largura
         * toda, e com isso ela alcançava o HUD do canto inferior direito.
         * Seis abas ocupam 288 px — num visualizador de 800 não há motivo
         * para atravessá-lo. O `maxWidth` é o que permite a fila ROLAR de
         * lado num aparelho estreito, sem esbarrar em quem mora à direita. */
        dock.style.right = '';
        dock.style.maxWidth = Math.max(96, Math.floor((rH.width || 0) - 20)) + 'px';
      } else {
        dock.style.flexDirection = 'column';
        dock.style.height = '';
        dock.style.overflowY = 'auto';
        dock.style.overflowX = 'hidden';
        dock.style.right = '';
        dock.style.maxWidth = '';   // some com o teto da fila ao voltar para a coluna
        dock.style.display = 'flex';
        dock.style.maxHeight = Math.max(44, disponivel) + 'px';   // ao menos uma aba, sempre
      }
    } catch (eD) {}
    barToggle.innerHTML = barraAberta ? (ehTelaPequena ? '' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + ' Fechar ferramentas' : '⤢ Esconder') : '' + (typeof Icones !== 'undefined' ? Icones.get('ajustes', 15) : '') + ' Ferramentas';
    if (visitante) barToggle.style.display = 'none';
  }
  function setBarra(aberta) {
    if (visitante) aberta = false;
    barraAberta = !!aberta;
    bar.style.display = aberta ? 'flex' : 'none';
    barToggle.innerHTML = aberta ? (ehTelaPequena ? '' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + ' Fechar ferramentas' : '⤢ Esconder') : '' + (typeof Icones !== 'undefined' ? Icones.get('ajustes', 15) : '') + ' Ferramentas';
    try { localStorage.setItem('orcapro:bim:barra', aberta ? 'aberta' : 'recolhida'); } catch (_) {}
    // página rolada longe do viewer: abrir a barra sem trazê-la à vista parecia "não fez nada"
    if (aberta && ehTelaPequena && host.scrollIntoView) { try { host.scrollIntoView({ block: 'start', behavior: 'smooth' }); } catch (_) {} }
    if (S && S._ajustarTop) S._ajustarTop();
  }
  var fabObs = null;
  try {
    // reposiciona quando o toast #opr-install entra/sai; guardado em S e DESCONECTADO no
    // desmonte (senão acumulava 1 observer por ctx-lost — achado do gate)
    fabObs = new MutationObserver(aplicarEstiloToggle);
    fabObs.observe(document.body, { childList: true });
  } catch (eF) {}
  barToggle.addEventListener('click', function () { setBarra(!barraAberta); });
  host.appendChild(barToggle);
  aplicarEstiloToggle();
  window.addEventListener('resize', aplicarEstiloToggle);
  /* ⚠ E TAMBÉM AO ROLAR. Desde que a faixa do dock passou a ser a parte
     VISÍVEL do visualizador, ela muda quando a página rola — o cabeçalho fixo
     cobre mais ou menos do canvas conforme a rolagem. Só no `resize`, o dock
     ficaria calculado para a posição de antes e as abas voltariam a cair fora.
     Em rAF porque scroll dispara a cada quadro no toque. */
  var dockRaf = 0;
  function aoRolar() {
    if (dockRaf) return;
    dockRaf = requestAnimationFrame(function () { dockRaf = 0; aplicarEstiloToggle(); });
  }
  /* ⚠ guardado em `S` lá embaixo, junto de `_fabEstilo` — AQUI o `S` ainda é
     null (só é preenchido depois, na montagem da cena) e `S._dockRolar = …`
     estourava "Cannot set properties of null", derrubando o viewer inteiro. */
  window.addEventListener('scroll', aoRolar, true);
  setBarra(barraAberta); // aplica o estado salvo (S._ajustarTop roda depois no setup)

  // v1.1.82 — TEMA de cores da interface do BIM (escolha do usuário; 'revit' = o look do Revit)
  var TEMAS = {
    orcapro: { nome: 'OrçaPRO', ativo: '#16a34a', bar: 'linear-gradient(180deg,rgba(15,39,64,.9),rgba(15,39,64,0))', painel: 'rgba(15,39,64,.97)', borda: '#24435f', texto: '#dbe8f5', fundo: 'radial-gradient(120% 120% at 50% 0%, #16324f 0%, #0b1a2b 70%)' },
    revit: { nome: 'Revit', ativo: '#1858A8', bar: 'linear-gradient(180deg,rgba(59,68,75,.96),rgba(59,68,75,0))', painel: 'rgba(42,49,56,.97)', borda: '#565f66', texto: '#e8eaec', fundo: 'radial-gradient(120% 120% at 50% 0%, #4a5158 0%, #2e343a 70%)' },
    claro: { nome: 'Claro', ativo: '#0e7490', bar: 'linear-gradient(180deg,rgba(235,241,247,.95),rgba(235,241,247,0))', painel: 'rgba(248,250,252,.98)', borda: '#c4d0dc', texto: '#1a2b3c', fundo: 'radial-gradient(120% 120% at 50% 0%, #e6edf4 0%, #c9d6e3 70%)' }
  };
  var temaId = 'orcapro';
  try { var t0 = localStorage.getItem('orcapro:bim:tema'); if (t0 && TEMAS[t0]) temaId = t0; } catch (_) {}
  function corAtiva() { return TEMAS[temaId].ativo; }
  function aplicarTema() {
    var T = TEMAS[temaId];
    var h2 = (S && S.host) || host; // re-home troca o host — o closure original aponta pro morto
    h2.style.background = (S && S._estiloOn && S._estiloOn()) ? '#fff' : T.fundo; // estilo desenho segura o branco
    bar.style.background = T.bar;
    bar.style.color = T.texto;
    [S.editPanel, S.snapPanel, S.pavPanel, S.visPanel, S.editDist, S.p3dPanel].forEach(function (pn) {
      if (!pn) return;
      /* ⚠ AS JANELAS NÃO SEGUEM MAIS O TEMA DA CENA — e é de propósito.
         O tema pinta o AMBIENTE 3D (fundo, barra, dock); as janelas de
         trabalho ficam claras sempre, que é o pedido de 09/09/2026: "esse azul
         deixa só para as outras coisas; sempre que for janela pode ficar com
         fundo branco". Repintar aqui com `T.painel` devolvia o navy assim que
         a pessoa trocasse de tema — o branco duraria até o primeiro clique na
         paleta, e o defeito pareceria intermitente. */
      // re-pinta os toggles ativos DOS PAINÉIS também (chain/orto/ângulo/sub-ferramenta)
      pn.querySelectorAll && pn.querySelectorAll('button').forEach(function (b3) { if (b3.style.background && b3.style.background !== '') b3.style.background = corAtiva(); });
    });
    // re-pinta os botões da toolbar que estavam com a cor ativa antiga (estado ligado sobrevive à troca)
    bar.querySelectorAll('button').forEach(function (b2) { if (b2.style.background && b2.style.background !== '') b2.style.background = corAtiva(); });
    dockRepintar(T); // leques do dock lateral acompanham o tema
    try { localStorage.setItem('orcapro:bim:tema', temaId); } catch (_) {}
  }
  function trocarTema() {
    temaId = temaId === 'orcapro' ? 'revit' : (temaId === 'revit' ? 'claro' : 'orcapro');
    aplicarTema();
    if (S && S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('paleta', 15) : '') + ' Tema: ' + TEMAS[temaId].nome);
  }
  /* v1.1.127 — a casca (bimshell) precisa MANDAR o tema, não só ciclar: quando o
   * ambiente está no claro do Revit, a cena tem de acompanhar, senão fica uma
   * janela navy no meio de uma interface clara. */
  function definirTema(id) {
    if (!TEMAS[id]) return false;
    temaId = id;
    try { localStorage.setItem('orcapro:bim:tema', id); } catch (_) {}
    aplicarTema();
    return true;
  }
  /* a exposição em S fica LOGO DEPOIS da criação do S (mais abaixo): aqui em
   * cima S ainda vai ser reatribuído, e a referência se perderia. */

  // v1.1.96 — COLORIR POR SISTEMA HIDROSSANITÁRIO (padrão brasileiro, editável pelo usuário).
  // Vale no 3D, na Planta baixa e no imersivo RA/RV de uma vez só, porque o hook está no
  // matBase() — a "aparência-base" única de toda malha; quando o modo está ligado, matBase
  // devolve o material da COR DO SISTEMA no lugar do material original do IFC.
  var SIS_ORDEM = ['agua_fria', 'agua_quente', 'esgoto', 'pluvial', 'gas', 'incendio', 'ventilacao', 'outros'];
  var SIS_PADRAO = {
    agua_fria:   { nome: 'Água fria',        cor: '#2563eb' },
    agua_quente: { nome: 'Água quente',      cor: '#f97316' },
    esgoto:      { nome: 'Esgoto / sanitário', cor: '#7c4a12' },
    pluvial:     { nome: 'Águas pluviais',   cor: '#16a34a' },
    gas:         { nome: 'Gás',              cor: '#eab308' },
    incendio:    { nome: 'Incêndio (PPCI)',  cor: '#dc2626' },
    ventilacao:  { nome: 'Ventilação',       cor: '#7c3aed' },
    outros:      { nome: 'Outros / não classificado', cor: '#6b7a8a' }
  };
  var sisCores = {}; SIS_ORDEM.forEach(function (k) { sisCores[k] = SIS_PADRAO[k].cor; });
  try { var _sc0 = JSON.parse(localStorage.getItem('orcapro:bim:sistemas') || '{}'); SIS_ORDEM.forEach(function (k) { if (_sc0[k] && /^#[0-9a-f]{6}$/i.test(_sc0[k])) sisCores[k] = _sc0[k]; }); } catch (_) {}
  function salvarSisCores() { try { localStorage.setItem('orcapro:bim:sistemas', JSON.stringify(sisCores)); } catch (_) {} }
  var sisColor = { on: false };
  var sisMatCache = {};
  // classifica um elemento por nome/família/tipo/tag num sistema hidrossanitário.
  // Ordem = prioridade: incêndio/gás/exaustão (HVAC) primeiro; "ventilação" simples cai em
  // esgoto (coluna de ventilação sanitária, uso dominante num app hidrossanitário); "água
  // quente" antes de "água fria" (ambas contêm "água"); resto vira "outros".
  function classificaSistemaTxt(s) {
    // "hidrossanitário" é rótulo GUARDA-CHUVA (cobre água fria + esgoto + pluvial…); sem neutralizar,
    // o "sanit" dentro dele cairia em esgoto (marrom). Tira o termo antes de classificar o resto.
    s = String(s || '').toLowerCase().replace(/hidr[oa]ss?anit\w*/g, ' ');
    if (/inc[eê]ndio|hidrante|sprinkler|combate a inc|\bppci\b|\bspk\b/.test(s)) return 'incendio';
    if (/\bg[aá]s\b|\bglp\b|\bgnv\b|g[aá]s natural|combust[ií]v/.test(s)) return 'gas';
    if (/exaust|\bduto\b|\bduct\b|\bhvac\b|\bavac\b|climatiz|ar[ -]?condic/.test(s)) return 'ventilacao';
    if (/pluvial|[aá]guas? ?pluvia|rainwater|\bstorm\b|calha/.test(s)) return 'pluvial';
    if (/esgoto|\besg\b|sanit[aá]ri|sewage|\bwaste\b|\bfoul\b|ventila[çc]/.test(s)) return 'esgoto';
    if (/[aá]gua ?quente|\baq\b|hot ?water|domestichotwater|\bquente\b/.test(s)) return 'agua_quente';
    if (/[aá]gua ?fria|\baf\b|cold ?water|domesticcoldwater|[aá]gua ?pot[aá]vel|[aá]gua|\bwater\b/.test(s)) return 'agua_fria';
    return 'outros';
  }
  function sisTxtEl(e) { return (e.nome || '') + ' ' + (e.familia || '') + ' ' + (e.tipo || '') + ' ' + (e.tag || ''); }
  // v1.1.98 — classifica um elemento pelo SISTEMA do IFC (Esgoto/Água…, sinal correto) e, só se não
  // houver sistema reconhecido, cai no NOME do elemento (que costuma ser genérico "Tubo/duto").
  function classificaEl(e) {
    var k = classificaSistemaTxt(e.sistemaIfc || '');
    if (k === 'outros') k = classificaSistemaTxt(sisTxtEl(e));
    return k;
  }
  // material da cor do sistema, respeitando a transparência do modelo; "outros" fica cinza
  // translúcido pra a tubulação colorida SALTAR na vista (destaque estilo MEP).
  function sisMat(chave, alpha) {
    var cor = sisCores[chave] || sisCores.outros;
    var op = (chave === 'outros' ? 0.30 : 1) * (alpha == null ? 1 : Math.max(0.05, Math.min(1, alpha)));
    op = Math.round(op / 0.05) * 0.05; // quantiza a opacidade: o slider de transparência não cria um material novo por passo (limita o cache a ~8 sistemas × ~20 níveis)
    var transp = op < 0.985;
    var key = chave + '@' + op.toFixed(2) + '@' + cor;
    if (!sisMatCache[key]) sisMatCache[key] = new THREE.MeshStandardMaterial({ color: new THREE.Color(cor), roughness: 0.55, metalness: 0.05, transparent: transp, opacity: op, depthWrite: !transp, side: THREE.DoubleSide });
    return sisMatCache[key];
  }
  function limparSisMatCache() { Object.keys(sisMatCache).forEach(function (k) { try { sisMatCache[k].dispose(); } catch (_) {} }); sisMatCache = {}; }
  // roda a classificação uma vez e grava no elemento (e.sistema) e no mesh (userData._sisK,
  // lido rápido pelo matBase a cada repintura).
  function construirSisIdx() {
    (S.elementos || []).forEach(function (e) {
      var k = classificaEl(e);
      e.sistema = k;
      var m = S.meshPorUid[e.uid]; if (m) m.userData._sisK = k;
    });
  }
  /* =====================================================================
   * B3 — OS DOIS CAMPOS QUE A REGRA PRECISA E QUE NAO EXISTIAM
   *
   * ⚠ `pavimento` NUNCA foi campo de elemento. O dado mora no MODELO
   * (`mo.pavimentos[].eids`), e o unico resolvedor era privado, com um
   * consumidor so. Uma regra "do Terreo" devolveria zero — falso vazio, sem
   * erro, e o coordenador concluiria que a obra nao tem nada naquele andar.
   *
   * ⚠ E `sistema` so nascia quando o usuario ligava "Cores por sistema" uma
   * vez: a classificacao rodava dentro de `construirSisIdx`, que so roda
   * naquele modo. Mesmo falso vazio.
   *
   * Aqui os dois sao carimbados na carga, de uma vez. `sistema` continua sendo
   * a CHAVE (e o que `matBase` e a paleta usam); `sistemaNome` e o rotulo
   * legivel, que e o que uma regra escrita por gente compara.
   * ===================================================================== */
  function carimbarConsulta() {
    if (!S || !S.modelos) return 0;
    var porUid = {}, n = 0;
    try {
      pavLista().forEach(function (p) {
        for (var u in p.uids) { if (Object.prototype.hasOwnProperty.call(p.uids, u)) porUid[u] = p.nome; }
      });
    } catch (_) {}
    S.modelos.forEach(function (mo) {
      (mo.elementos || []).forEach(function (e) {
        e.pavimento = porUid[e.uid] || '';
        var k = classificaEl(e);
        e.sistema = k;
        e.sistemaNome = (SIS_PADRAO[k] && SIS_PADRAO[k].nome) || '';
        n++;
      });
    });
    return n;
  }
  /* os valores que EXISTEM no modelo para um campo — o editor de regra oferece
     em vez de exigir que o usuario adivinhe a grafia do projetista */
  function valoresDe(campo) {
    var c = String(campo || ''), cnt = {};
    (S.elementos || []).forEach(function (e) {
      var v = c.indexOf('.') < 0 ? e[c] : ((e[c.split('.')[0]] || {})[c.split('.')[1]]);
      if (v == null || String(v).trim() === '') return;
      var s = String(v);
      cnt[s] = (cnt[s] || 0) + 1;
    });
    return Object.keys(cnt).sort().map(function (v) { return { valor: v, n: cnt[v] }; });
  }

  function sistemasPresentes() {
    var cnt = {};
    (S.elementos || []).forEach(function (e) { var k = e.sistema || classificaEl(e); cnt[k] = (cnt[k] || 0) + 1; });
    return cnt;
  }

  // aplica DEPOIS que S e todos os painéis nasceram (este bloco roda antes da criação do S)
  setTimeout(function () { if (S && S.alive) { S._aplicarTema = aplicarTema; aplicarTema(); } }, 0);

  var hud = document.createElement('div');
  hud.style.cssText = 'position:absolute;right:10px;bottom:10px;z-index:3;background:rgba(15,39,64,.85);border:1px solid #24435f;border-radius:8px;padding:6px 10px;font-size:12px;color:#bcd0e4';
  hud.innerHTML = 'Elementos: <b data-h="el">0</b> · Triângulos: <b data-h="tri">0</b>';
  /* contagem de elementos e triângulos é informação de engenheiro; no link
     do cliente ela só ocupava o meio da tela (medido a 390 px) */
  if (visitante) hud.style.display = 'none';
  host.appendChild(hud);

  var over = document.createElement('div');
  over.style.cssText = 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;z-index:2;pointer-events:none';
  over.innerHTML = '<div style="pointer-events:auto;text-align:center;background:rgba(15,39,64,.82);border:2px dashed #2e6f9e;border-radius:16px;padding:28px 34px;max-width:420px;color:#dbe8f5"><div style="font-size:34px">' + (typeof Icones !== 'undefined' ? Icones.get('obra', 15) : '') + '</div><h3 style="margin:8px 0 6px">Arraste um <b>.IFC</b> aqui</h3><p style="color:#a9c1d8;font-size:13px;margin:4px 0">Exporte do Revit/pyRevit e solte — abre em 3D, offline. Recebeu o <b>arquivo da obra (.zip)</b> no grupo? Solte ele aqui, ou use <b>Arquivo da obra</b> no alto.</p></div>';
  host.appendChild(over);

  var loading = document.createElement('div');
  loading.style.cssText = 'position:absolute;inset:0;background:rgba(11,26,43,.86);display:none;align-items:center;justify-content:center;flex-direction:column;gap:12px;z-index:5;color:#1a2b3c';
  loading.innerHTML = '<div style="width:40px;height:40px;border:4px solid #d3dce6;border-top-color:#16a34a;border-radius:50%;animation:bimsp 1s linear infinite"></div><div data-l="txt">Lendo o IFC…</div>';
  host.appendChild(loading);
  if (!document.getElementById('bim-spin-style')) { var st = document.createElement('style'); st.id = 'bim-spin-style'; st.textContent = '@keyframes bimsp{to{transform:rotate(360deg)}}'; document.head.appendChild(st); }

  // ---- Three ----
  var scene = new THREE.Scene(); scene.background = null;
  var camera = new THREE.PerspectiveCamera(60, 1, 0.1, 5000); camera.position.set(20, 18, 22);
  var renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  // qualidade de cor "de render": sRGB + tone mapping cinematográfico por padrão
  try { renderer.outputColorSpace = THREE.SRGBColorSpace; } catch (_) {}
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.12;
  // sombras suaves (qualidade de render + imersão RA/RV) e WebXR habilitado no renderer
  try { renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; } catch (_) {}
  try { renderer.xr.enabled = true; } catch (_) {}
  renderer.domElement.style.cssText = 'display:block;width:100%;height:100%;outline:none';
  host.appendChild(renderer.domElement);
  renderer.domElement.addEventListener('webglcontextlost', function (e) { e.preventDefault(); if (S) { S.alive = false; if (S.raf) cancelAnimationFrame(S.raf); } try { over.style.display = 'flex'; over.querySelector('div').innerHTML = '<div style="font-size:30px">🧊</div><h3 style="margin:8px 0">O 3D ficou pesado demais</h3><p style="color:#a9c1d8;font-size:13px">A memória de vídeo esgotou (modelos grandes / Ultra). Recarregue a aba BIM com menos modelos, ou desligue o ' + (typeof Icones !== 'undefined' ? Icones.get('escopo', 15) : '') + ' Ultra.</p>'; } catch (_) {} }, false);
  var hemi = new THREE.HemisphereLight(0xffffff, 0x223344, 0.55); scene.add(hemi); // reduzido: o ambiente PMREM abaixo faz o preenchimento
  var dir = new THREE.DirectionalLight(0xffffff, 1.0); dir.position.set(30, 50, 20); scene.add(dir);
  // v1.1.89 — ILUMINAÇÃO BASEADA EM IMAGEM (PMREM): reflexos suaves + shading premium em TODO
  // MeshStandardMaterial (o "look de render" dos melhores visualizadores). Custo ~zero por frame
  // (a env é pré-computada 1×). Os desenhos técnicos (corte/planta) usam material UNLIT (MeshBasic)
  // e NÃO são afetados. Um estúdio procedural (sala + luzes-área) vira a environment map.
  try {
    var _pmrem = new THREE.PMREMGenerator(renderer);
    var _envScn = new THREE.Scene();
    var _room = new THREE.Mesh(new THREE.BoxGeometry(24, 18, 24), new THREE.MeshStandardMaterial({ side: THREE.BackSide, roughness: 1, metalness: 0, color: 0x9fb0c4 }));
    _envScn.add(_room);
    var _areaLuz = function (cor, w, h, d, x, y, z, ganho) { var m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshBasicMaterial()); m.material.color.setHex(cor).multiplyScalar(ganho); m.position.set(x, y, z); return m; };
    _envScn.add(_areaLuz(0xffffff, 16, 1, 16, 0, 8.5, 0, 3.0));    // teto claro (luz principal difusa)
    _envScn.add(_areaLuz(0xdfeaf7, 1, 10, 12, -11.5, 2, -3, 1.6)); // parede fria à esquerda
    _envScn.add(_areaLuz(0xfff0dc, 1, 10, 12, 11.5, 2, 4, 1.3));   // parede quente à direita
    _envScn.add(_areaLuz(0xc4d0dd, 16, 1, 16, 0, -8.5, 0, 0.6));   // piso claro (bounce de baixo)
    var _envRT = _pmrem.fromScene(_envScn, 0.04);
    scene.environment = _envRT.texture;
    _room.geometry.dispose(); _envScn.traverse(function (o) { if (o.material && o.material.dispose) o.material.dispose(); if (o.geometry && o.geometry.dispose) o.geometry.dispose(); });
    _pmrem.dispose();
  } catch (eEnv) { /* sem env: cai no shading direto — nunca impede o viewer */ }
  // sombra da luz principal (ligada só quando o usuário entra no imersivo — custa GPU no modelo grande)
  try { dir.shadow.mapSize.set(2048, 2048); dir.shadow.camera.near = 1; dir.shadow.camera.far = 400; dir.shadow.bias = -0.0005; var _ds = dir.shadow.camera; _ds.left = -80; _ds.right = 80; _ds.top = 80; _ds.bottom = -80; _ds.updateProjectionMatrix(); } catch (_) {}
  var fill = new THREE.DirectionalLight(0xbfd8ee, 0.35); fill.position.set(-40, 25, -30); scene.add(fill); // luz de preenchimento (sombra menos chapada)
  var grid = new THREE.GridHelper(200, 40, 0x2e6f9e, 0x1c3a58); grid.material.opacity = .5; grid.material.transparent = true; scene.add(grid);
  // ---- sombra de contato (blob radial macio sob o modelo — "assenta" o prédio no chão, barato p/ mobile) ----
  var _chaoTex = (function () {
    var c = document.createElement('canvas'); c.width = c.height = 256; var g = c.getContext('2d');
    var rg = g.createRadialGradient(128, 128, 8, 128, 128, 126);
    rg.addColorStop(0, 'rgba(0,0,0,.42)'); rg.addColorStop(.55, 'rgba(0,0,0,.20)'); rg.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = rg; g.fillRect(0, 0, 256, 256);
    var t = new THREE.CanvasTexture(c); return t;
  })();
  var _chao = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: _chaoTex, transparent: true, depthWrite: false, opacity: .9 }));
  _chao.rotation.x = -Math.PI / 2; _chao.renderOrder = -1; _chao.raycast = function () {}; scene.add(_chao);
  var orbit = new OrbitControls(camera, renderer.domElement); orbit.enableDamping = true; orbit.dampingFactor = .08;
  // web-ifc já entrega a geometria em Y-up (converte o Z-up do IFC) → NÃO rotacionar (rotacionar tombava o modelo)
  var modelRoot = new THREE.Group(); modelRoot.rotation.x = 0; scene.add(modelRoot);

  var matAndamento = new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0x7a4a06, transparent: true, opacity: .9, metalness: .05, roughness: .8, side: THREE.DoubleSide });
  var selMat = new THREE.MeshStandardMaterial({ color: 0x16a34a, emissive: 0x0a5a2a, metalness: .1, roughness: .7 });
  var clashMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, emissive: 0x5a0a0a, metalness: .1, roughness: .6 });

  S = { host: host, opts: opts, scene: scene, camera: camera, renderer: renderer, orbit: orbit, modelRoot: modelRoot,
        _definirTema: definirTema,   /* a casca manda o tema da cena (v1.1.127) */
        bar: bar, hud: hud, over: over, loading: loading,
        api: new IfcAPI(), apiReady: false, modelID: -1, meshPorId: {}, elementos: [],
        modelos: [], meshPorUid: {}, ultra: false, _tickExtra: [], _tickPos: [],
        fly: { on: false, keys: {}, speed: 14, yaw: 0, pitch: 0 }, selected: null, prevMat: null,
        matAndamento: matAndamento, selMat: selMat, clashMat: clashMat, _clashSel: [], matCache: {}, raf: 0, alive: true };
  var Sm = S; // instância DESTE mount — guard de identidade p/ closures assíncronas (FileReader/fetch em voo de um viewer morto não podem poluir o viewer novo)
  S.barToggle = barToggle; S._setBarra = setBarra; // recolher/expandir a barra (entra no re-home)
  S._fabObserver = fabObs; S._fabEstilo = aplicarEstiloToggle; S._dockRolar = aoRolar; // FAB mobile: desconectados no desmonte (gate v1.1.114)
  S._dockDocClick = dockDocClick; // fechar-leque-no-toque-fora: removido no desmonte (senão acumula por remount)

  /* ⚠ `S.host`, NÃO o `host` do fecho. Esta função nasce na PRIMEIRA `montar` e
   * fica presa ao host daquela vez. Quando o app re-renderiza a aba BIM (todo
   * `App.render()` refaz o HTML), o viewer é re-parentado num host NOVO e
   * `S.host` é atualizado — mas este fecho continuava medindo o host velho, já
   * fora do documento, cujo clientWidth é 0. Com o `if (w && h)` isso virava um
   * no-op SILENCIOSO: da segunda visita em diante, redimensionar a janela (e o
   * botão novo de esconder a lateral) não mexia mais no canvas, e o modelo
   * ficava esticado. Defeito antigo que o botão novo só tornou visível. */
  function resize() {
    var alvo = (S && S.host) || host;
    var w = alvo.clientWidth, h = alvo.clientHeight;
    if (w && h) { renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); }
  }
  S._resize = resize; window.addEventListener('resize', resize); resize();

  // ---- voo ----
  var canvasEl = renderer.domElement, fly = S.fly, _fwd = new THREE.Vector3(), _right = new THREE.Vector3(), _up = new THREE.Vector3(0, 1, 0);
  /* =====================================================================
   * ⚠ A TRAVA DA CÂMERA (modo mesa, 30/09/2026): «o botão de trava na mesa,
   * para que na hora que estiver passando a mão não dê zoom etc. — só se
   * tiver destravado». Tablet deitado na mesa, várias mãos apontando: a mão
   * que encosta girava ou dava zoom no modelo de todo mundo.
   *
   * Travada, a câmera só muda por AÇÃO DELIBERADA (botão Enquadrar, vista,
   * ViewCube). Dedo, mouse e roda não giram nem dão zoom, e selecionar uma
   * peça não voa até ela. As ferramentas (trena, corte, isolar) continuam: o
   * toque delas é outro caminho, que a órbita nunca viu.
   *
   * ⚠ TODA TRAVA TEM PORTA: travada, aparece no canto um aviso que também é
   * o botão de destravar, e quem tenta arrastar recebe o recado do porquê.
   * Os lugares que devolvem a órbita (voo, lupa, saída da RA) respeitam a
   * trava — sem isso, fechar a lupa destravava a câmera sem ninguém pedir.
   * ===================================================================== */
  var trava = { on: false, avisoT: 0 };
  S.trava = trava;
  var travaChip = document.createElement('button');
  travaChip.type = 'button'; travaChip.setAttribute('data-bim', 'trava');
  travaChip.style.cssText = 'position:absolute;left:10px;top:' + ((opts.topoReservado || 0) + 10) + 'px;z-index:21;display:none;border:0;border-radius:16px;padding:6px 12px;font:700 12px Inter,system-ui,sans-serif;color:#fff;background:#15803d;box-shadow:0 2px 10px rgba(0,0,0,.3);cursor:pointer;touch-action:manipulation';
  host.appendChild(travaChip); S.travaChip = travaChip;   /* ⚠ e entra na lista do RE-HOME, lá em cima */
  travaChip.addEventListener('click', function (e) { e.stopPropagation(); setTrava(false); });
  function orbitaPode() { return !trava.on && !fly.on && !(S.lupa && S.lupa.on) && !(S.xr && S.xr.on); }
  /* ⚠ TRAVAR PARA NA HORA. A órbita tem inércia (amortecimento): um arrasto
     feito antes de travar deixava um EMBALO que seguia girando a câmera por
     vários quadros — medido na e2e de 01/10/2026: 6 cm de altura durante um
     giro e 7,6 cm durante o corte, com a câmera "travada". O embalo é zerado
     sem pulo: aplica, devolve a câmera para onde estava, aplica de novo. */
  function pararInercia() {
    if (!orbit) return;
    var p0 = camera.position.clone(), t0 = orbit.target.clone(), amort = orbit.enableDamping;
    orbit.enableDamping = false; orbit.update();
    camera.position.copy(p0); orbit.target.copy(t0); orbit.update();
    orbit.enableDamping = amort;
  }
  S._pararInercia = pararInercia;
  function setTrava(on) {
    trava.on = !!on;
    if (trava.on) pararInercia();
    if (orbit) orbit.enabled = orbitaPode();
    travaChip.innerHTML = (typeof Icones !== 'undefined' ? Icones.get('cadeado', 14) : '') + ' Câmera travada · toque para destravar';
    travaChip.style.display = trava.on ? 'block' : 'none';
    if (S._ajustarTop) S._ajustarTop();   /* a dica desce/sobe junto */
    return trava.on;
  }
  S._setTrava = setTrava; S._visitante = visitante;
  function avisarTrava() {
    var agora = performance.now(); if (agora - trava.avisoT < 2500) return; trava.avisoT = agora;
    S._hint((typeof Icones !== 'undefined' ? Icones.get('cadeado', 15) : '') + ' Câmera travada: encostar a mão não gira nem dá zoom. Toque em "Câmera travada" para destravar.');
    travaChip.animate && travaChip.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.12)' }, { transform: 'scale(1)' }], { duration: 380 });
  }
  canvasEl.addEventListener('wheel', function () { if (trava.on) avisarTrava(); }, { passive: true });
  function arrasteTravado(e) { if (trava.on && e.buttons && !ferramentaClique()) avisarTrava(); }
  canvasEl.addEventListener('pointermove', arrasteTravado);
  /* o modo mesa (js/bimmesa.js) volta sozinho quando o viewer remonta */
  setTimeout(function () { try { if (window.BimMesa && S && S.alive) window.BimMesa.aoMontar(); } catch (_) {} }, 0);
  function setMode(voo) {
    if (S._cancelTween) S._cancelTween(); // qualquer troca de modo (Voo/Órbita e — via setMode(false) — Planta/Corte/Caminhar) cancela o voo cinematográfico pendente
    fly.on = voo; orbit.enabled = !voo && !trava.on;
    bar.querySelector('[data-b="voo"]').classList.toggle('on', voo);
    bar.querySelector('[data-b="voo"]').style.background = voo ? corAtiva() : '';
    bar.querySelector('[data-b="voo"]').style.color = voo ? '#fff' : '';
    bar.querySelector('[data-b="orbita"]').style.background = voo ? '' : corAtiva();
    bar.querySelector('[data-b="orbita"]').style.color = voo ? '' : '#fff';
    if (!voo && document.pointerLockElement) document.exitPointerLock();
  }
  S._setMode = setMode;
  canvasEl.addEventListener('click', function () { if (fly.on && !document.pointerLockElement) canvasEl.requestPointerLock(); });
  S._onKeyDown = function (e) { fly.keys[e.code] = true; if (e.code === 'Escape') { if (S._lupaFechar && S.lupa && S.lupa.on) { S._lupaFechar(); return; } /* 🔍 a lupa sai PRIMEIRO: ela desliga a órbita, e sair da ferramenta antes deixaria a câmera travada */ if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) { if (S && S.host && S.host.contains(e.target)) e.target.blur(); return; } if (S.ctecModal && S.ctecModal.style.display === 'flex' && S._fecharCtecModal) { S._fecharCtecModal(); return; } if (S.plantaCfg && S.plantaCfg.style.display !== 'none') { S.plantaCfg.style.display = 'none'; return; } /* painel flutuante só é fechado pelo Esc quando NENHUMA ferramenta está em uso —
   senão o Esc de sair da trena/voo era gasto fechando um painel que o usuário nem olhava */
if (S._fecharPaineis && !(fly.on || (S.medir && S.medir.on) || (S.area && S.area.on) || (S.ang && S.ang.on) || (S.planta && S.planta.on) || (S.corteL && S.corteL.on) || (S.edit && S.edit.on)) && [S.visPanel, S.pavPanel, S.snapPanel, S.xrPanel].some(function (p) { return p && p.style.display === 'flex'; })) { S._fecharPaineis(null); return; } if (S.xr && S.xr.on && S._sairImersivo) { S._sairImersivo(); return; } if (S._ctecCancelar && S._ctecCancelar(true)) return; if (fly.on) setMode(false); if (S.medir && S.medir.on) S._setMedir(false); if (S.area && S.area.on && S._setArea) S._setArea(false); if (S.ang && S.ang.on && S._setAng) S._setAng(false); if (S.planta && S.planta.on) S._setPlanta(false); if (S.corteL && S.corteL.on && S._setCorteL) S._setCorteL(false); if (S.edit && S.edit.on) { if (S.edit.p1 && S._editFimCadeia) { S._editFimCadeia(); return; } if (S._setEdit) S._setEdit(false); } } };
  S._onKeyUp = function (e) { fly.keys[e.code] = false; };
  S._onMouseMove = function (e) { if (!fly.on || !document.pointerLockElement) return; fly.yaw -= e.movementX * 0.0022; fly.pitch -= e.movementY * 0.0022; fly.pitch = Math.max(-1.5, Math.min(1.5, fly.pitch)); };
  window.addEventListener('keydown', S._onKeyDown); window.addEventListener('keyup', S._onKeyUp); document.addEventListener('mousemove', S._onMouseMove);
  function flyStep(dt) {
    var e = new THREE.Euler(fly.pitch, fly.yaw, 0, 'YXZ'); camera.quaternion.setFromEuler(e);
    camera.getWorldDirection(_fwd); _right.crossVectors(_fwd, _up).normalize();
    var s = fly.speed * (fly.keys['ShiftLeft'] || fly.keys['ShiftRight'] ? 3 : 1) * dt;
    if (fly.keys['KeyW']) camera.position.addScaledVector(_fwd, s);
    if (fly.keys['KeyS']) camera.position.addScaledVector(_fwd, -s);
    if (fly.keys['KeyD']) camera.position.addScaledVector(_right, s);
    if (fly.keys['KeyA']) camera.position.addScaledVector(_right, -s);
    if (fly.keys['KeyE']) camera.position.addScaledVector(_up, s);
    if (fly.keys['KeyQ']) camera.position.addScaledVector(_up, -s);
  }

  var clock = new THREE.Clock();
  // corpo de 1 quadro: reusado pelo rAF normal E pelo setAnimationLoop do WebXR (sessão VR/AR)
  function renderFrame(dt) {
    if (S._xrWalk) S._xrWalk(dt);          // locomoção do imersivo (andar) — tem prioridade
    else if (fly.on) flyStep(dt); else orbit.update();
    for (var tx = 0; tx < S._tickExtra.length; tx++) { try { S._tickExtra[tx](dt); } catch (_) {} }
    /* ⚠ a vista principal ESCONDIDA (outra aba de vista na frente) não desenha:
       seria o dobro de GPU para um canvas que ninguém vê */
    if (!S._principalOculta) {
      renderer.render(scene, camera);
      if (S._cxMain) S._cxMain.desenhar(renderer, camera);
    }
    if (S._renderVistas) S._renderVistas(dt);
    /* ⚠ GANCHO DEPOIS DO RENDER, e a ordem é o que faz ele existir.
     * Quem precisa COPIAR o quadro desenhado (a lupa do toque) tem de rodar
     * com o buffer ainda válido. O renderer é criado sem `preserveDrawingBuffer`
     * (ligá-lo custa desempenho em toda a frota), então o conteúdo do canvas só
     * pode ser lido DENTRO da mesma tarefa do render — é a mesma restrição que
     * a Foto da vista já contorna. Um `_tickExtra` (que roda ANTES) copiaria o
     * quadro anterior, e a lupa mostraria a cena com um quadro de atraso: no
     * arraste do dedo, justamente o que se está mirando sai defasado. */
    for (var tp = 0; tp < S._tickPos.length; tp++) { try { S._tickPos[tp](dt); } catch (_) {} }
  }
  function tick() { if (!S || !S.alive) return; if (S._xrActive) { S.raf = 0; return; } var dt = Math.min(clock.getDelta(), 0.1); renderFrame(dt); S.raf = requestAnimationFrame(tick); }
  S._renderFrame = renderFrame; S._retomarTick = function () { if (S && S.alive && !S._xrActive && !S.raf) tick(); };
  tick();

  // ---- pick ----
  var ray = new THREE.Raycaster(), mouse = new THREE.Vector2();
  // O Raycaster do three NÃO testa object.visible (só layers): sem filtro, o raio acerta elemento
  // OCULTO (modelo desligado no painel, 4D com "futuros" escondidos) na frente do visível — cota da
  // trena e seleção silenciosamente ERRADAS. Na planta, o clipping é só GPU: o raycast CPU ainda
  // acerta o telhado acima do corte. Este filtro resolve as duas famílias.
  function cadeiaVisivel(o) { for (var n = o; n; n = n.parent) { if (n.visible === false) return false; if (n === modelRoot) break; } return true; }
  // três clipa fragmentos onde plane.distanceToPoint(p) < 0 — o mesmo teste aqui mantém CPU==GPU
  // p/ QUALQUER plano ativo (planta baixa OU corte livre), não só o horizontal.
  function foraDoClip(p) {
    var pls = renderer.clippingPlanes || [];
    for (var i = 0; i < pls.length; i++) if (pls[i].distanceToPoint(p) < -1e-6) return true;
    return false;
  }
  function primeiroHit(hits) {
    for (var i = 0; i < hits.length; i++) {
      if (!cadeiaVisivel(hits[i].object)) continue;
      if (foraDoClip(hits[i].point)) continue; // clipado é só GPU; o raycast CPU ainda o acerta
      return hits[i];
    }
    return null;
  }
  canvasEl.addEventListener('dblclick', function (e) {
    if (!S || !S.alive) return;
    if (fly.on) return;
    if (S.edit && S.edit.on && S.edit.sub) return; // desenhando: duplo-clique não seleciona nem abre painel
    if (ctec.ativo) return; // riscando a linha de corte, clique é ponto — não seleção (ANTES de area/ang: mesma ordem do pointerup)
    if (S.medir && S.medir.on) return; // no modo trena o duplo-clique é medição, não seleção
    if (area.on) { if (area.pts.length >= 3) fecharArea(); return; } // no modo área o duplo-clique FECHA o polígono
    if (ang.on) return; // no modo ângulo o clique é ponto — não seleção
    if (S._aoClicarPeca) return; // coletando peças (peso/içamento): o clique simples já juntou — ver `cliqueColetor`
    if (S._aoMarcarPonto) return; // marcando a posição do equipamento: o clique simples é o ponto
    selecionarEm(e.clientX, e.clientY);
  });
  /* a seleção de uma peça no ponto da tela — a do duplo-clique e, no modo
     visitante, a do TOQUE simples (no celular o duplo-toque é zoom do
     sistema e a seleção nunca acontecia) */
  function selecionarEm(cx, cy) {
    if (S._limparRaioX) S._limparRaioX(); // nova seleção reseta o raio-X (senão o ghostMat vaza pro prevMat)
    var r = canvasEl.getBoundingClientRect();
    mouse.x = ((cx - r.left) / r.width) * 2 - 1; mouse.y = -((cy - r.top) / r.height) * 2 + 1;
    ray.setFromCamera(mouse, camera);
    var hit = primeiroHit(ray.intersectObjects(modelRoot.children, true));
    if (S.selected) { S.selected.material = S.prevMat; S.selected = null; }
    if (hit && hit.object.userData && hit.object.userData.expressID != null) {
      S.selected = hit.object; S.prevMat = S.selected.material; S.selected.material = selMat;
      contornoSelecao(hit.object); // v1.1.89 — contorno nítido na seleção
      if (!fly.on && !xr.on && !planta.on && !corteL.on && !visitante && !trava.on) enquadrarObj(new THREE.Box3().setFromObject(hit.object), 2.6); // foco cinematográfico — NÃO na planta/corte (quebraria a moldura travada); nem no visitante, que toca para LER a peça, não para voar até ela
      if (opts.onPick) opts.onPick(propsDe(hit.object.userData.mid != null ? hit.object.userData.mid : S.modelID, hit.object.userData.expressID, hit.object.userData.tipo));
    } else if (opts.onPick) { contornoSelecao(null); opts.onPick(null); }
  }
  S._selecionarEm = selecionarEm;

  // ---- navegação cinematográfica: tween suave de câmera (fly-to / enquadrar) ----
  var _cvT = null; // tween ativo
  function cancelTween() { _cvT = null; } // trocar de modo (voo/planta/corte/caminhar/enquadrar) cancela o voo pendente — senão o tween sobrescreve a câmera do modo novo por ~0,55s (gate v1.1.89)
  S._cancelTween = cancelTween;
  function voarCam(destPos, destTgt, dur) {
    if (!destPos) return;
    _cvT = { p0: camera.position.clone(), p1: destPos.clone(), t0: orbit.target.clone(), t1: (destTgt || orbit.target).clone(), dur: Math.max(0.15, dur || 0.6), e: 0 };
  }
  S._tickExtra.push(function (dt) {
    if (!_cvT) return;
    _cvT.e += dt; var k = Math.min(1, _cvT.e / _cvT.dur);
    var s = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2; // easeInOutQuad
    camera.position.lerpVectors(_cvT.p0, _cvT.p1, s);
    orbit.target.lerpVectors(_cvT.t0, _cvT.t1, s);
    if (k >= 1) _cvT = null;
  });
  // enquadra um box (elemento ou modelo) com voo suave, mantendo a direção de visão atual
  function enquadrarObj(box, fator) {
    if (!box || box.isEmpty()) return;
    var c = box.getCenter(new THREE.Vector3()), sz = box.getSize(new THREE.Vector3());
    var raio = Math.max(sz.x, sz.y, sz.z, 0.5) * 0.5;
    var dist = (raio / Math.tan((camera.fov * Math.PI / 180) / 2)) * (fator || 1.6);
    var dir = camera.position.clone().sub(orbit.target); if (dir.lengthSq() < 1e-6) dir.set(0.7, 0.55, 0.8); dir.normalize();
    // afrouxa o near ao aproximar de elemento pequeno em modelo grande (near travado em maxDim/1000 cortaria a frente) — só DIMINUI, nunca aumenta (não some o resto do modelo)
    var near = Math.max(0.01, (dist - raio) * 0.5); if (near < camera.near) { camera.near = near; camera.updateProjectionMatrix(); }
    voarCam(c.clone().add(dir.multiplyScalar(dist)), c, 0.55);
  }
  S._enquadrarObj = enquadrarObj; S._voarCam = voarCam;

  // ---- contorno nítido na seleção (lê claro em qualquer fundo, estilo visualizador pro) ----
  var _selLn = null, _selLnMat = null;
  function contornoSelecao(mesh) {
    if (_selLn) { scene.remove(_selLn); if (_selLn.geometry) _selLn.geometry.dispose(); _selLn = null; }
    if (!mesh || !mesh.geometry) return;
    if (mesh.geometry.attributes && mesh.geometry.attributes.position && mesh.geometry.attributes.position.count > 60000) return; // malha densa: sem contorno (EdgesGeometry travaria)
    var arr = arestasDe(mesh.geometry); if (!arr.length) return;
    if (!_selLnMat) _selLnMat = new THREE.LineBasicMaterial({ color: 0x2effa0, depthTest: false, transparent: true, opacity: 0.95 });
    var bg = new THREE.BufferGeometry(); bg.setAttribute('position', new THREE.BufferAttribute(arr, 3));
    var ln = new THREE.LineSegments(bg, _selLnMat);
    ln.matrixAutoUpdate = false; ln.matrix.copy(mesh.matrixWorld); ln.renderOrder = 1000; ln.raycast = function () {};
    scene.add(ln); _selLn = ln;
  }
  S._contornoSelecao = contornoSelecao;

  /* =====================================================================
   * AMBIENTE TIPO REVIT NO 3D (30/09/2026) — pedido do Rogério: "entenda
   * como é a interface do Revit e faça no nosso sistema; a maioria dos
   * usuários já é acostumada com o Revit". Aqui moram as peças que vivem
   * DENTRO do visualizador:
   *   • ViewCube (canto superior direito de cada vista): clicar numa face,
   *     aresta ou canto orienta a câmera; arrastar gira; a casinha volta ao
   *     início; o botão direito abre o menu do Revit (início, salvar vista,
   *     perspectiva/ortogonal, definir início, orientar para vista…);
   *   • Ortogonal: câmera com abertura mínima e recuada na mesma proporção —
   *     o enquadramento não pula e todo o resto (seleção, trena, foto) segue
   *     igual, porque a câmera continua a mesma;
   *   • Caixa de corte com as setas azuis nas seis faces (puxar e empurrar),
   *     como no Revit;
   *   • Vistas extras: outra câmera sobre a MESMA cena — abas, lado a lado e
   *     outra janela. A peça selecionada numa aparece selecionada em todas
   *     (o material de seleção é da cena, não da vista).
   * ===================================================================== */
  var _V3 = function (x, y, z) { return new THREE.Vector3(x, y, z); };
  /* cada face do cubo: normal (direção DE ONDE se olha), eixo "direita" e
     eixo "cima" na tela — cena = IFC (X, Z, −Y): frente = sul = +Z */
  var VC_FACES = {
    frontal:   { rot: 'FRONTAL',   n: _V3(0, 0, 1),  u: _V3(1, 0, 0),  v: _V3(0, 1, 0) },
    direita:   { rot: 'DIREITA',   n: _V3(1, 0, 0),  u: _V3(0, 0, -1), v: _V3(0, 1, 0) },
    posterior: { rot: 'POSTERIOR', n: _V3(0, 0, -1), u: _V3(-1, 0, 0), v: _V3(0, 1, 0) },
    esquerda:  { rot: 'ESQUERDA',  n: _V3(-1, 0, 0), u: _V3(0, 0, 1),  v: _V3(0, 1, 0) },
    superior:  { rot: 'SUPERIOR',  n: _V3(0, 1, 0),  u: _V3(1, 0, 0),  v: _V3(0, 0, -1) },
    inferior:  { rot: 'INFERIOR',  n: _V3(0, -1, 0), u: _V3(1, 0, 0),  v: _V3(0, 0, 1) }
  };
  function vcCss(w) { return [w.x, -w.y, w.z]; }
  function vcMatFace(f, meio) {
    var X = vcCss(f.u), Y = vcCss(f.v.clone().negate()), Z = vcCss(f.n), T = vcCss(f.n.clone().multiplyScalar(meio));
    return 'matrix3d(' + [X[0], X[1], X[2], 0, Y[0], Y[1], Y[2], 0, Z[0], Z[1], Z[2], 0, T[0], T[1], T[2], 1].join(',') + ')';
  }
  /* PRÉVIA do Cristal OrçaPRO e do cubo novo (ESPEC-BIM-CUBO-LOGO): `CONFIG.bimRecursos.cristal` (a frota, por versão) com a
     chave local por cima (`orcapro:tela:bim-cristal:v1`, gravada pelo App._previaDaUrl quando o app abre com `?previa=cristal`;
     `?previa=cristal-desligar` apaga). Desligado: o BIM vazio e o cubo de antes. Lida UMA vez por montagem do visualizador.
     ⚠ Sem esta chave, o cristal iria para a frota inteira na próxima publicação do master — e o Rogério pediu prévia por instalação. */
  function cristalLigado() {
    var on = false;
    try { on = !!(typeof window !== 'undefined' && window.CONFIG && window.CONFIG.bimRecursos && window.CONFIG.bimRecursos.cristal === true); } catch (_) {}
    try { var raw = localStorage.getItem('orcapro:tela:bim-cristal:v1'); if (raw) { var o = JSON.parse(raw); if (o && typeof o.cristal === 'boolean') on = o.cristal; } } catch (_) {}
    return on;
  }
  /* um plano qualquer no espaço do cubo (u = direita, v = cima da figura, n = normal), deslocado `d` ao longo de n */
  function vcMatPlano(u, v, n, d) {
    var X = vcCss(u), Y = vcCss(v.clone().negate()), Z = vcCss(n), T = vcCss(n.clone().multiplyScalar(d));
    return 'matrix3d(' + [X[0], X[1], X[2], 0, Y[0], Y[1], Y[2], 0, Z[0], Z[1], Z[2], 0, T[0], T[1], T[2], 1].join(',') + ')';
  }
  function vcEstilo() {
    if (document.getElementById('bim-vcube-estilo')) return;
    var st = document.createElement('style'); st.id = 'bim-vcube-estilo';
    st.textContent =
      '.bim-vcube{position:absolute;top:10px;right:12px;width:104px;height:112px;z-index:5;user-select:none;font-family:"Segoe UI",system-ui,sans-serif}' +
      '.bim-vcube-casa{position:absolute;left:0;top:0;width:20px;height:20px;padding:0;border:0;background:transparent;color:#5b6573;cursor:pointer;display:flex;align-items:center;justify-content:center;opacity:.8}' +
      '.bim-vcube-casa:hover{opacity:1;color:#1a6cb5}' +
      '.bim-vcube-cena{position:absolute;left:17px;top:14px;width:70px;height:70px}' +
      '.bim-vcube-cubo{position:absolute;left:35px;top:35px;width:0;height:0;transform-style:preserve-3d}' +
      '.bim-vcube-face{position:absolute;left:-35px;top:-35px;width:70px;height:70px;box-sizing:border-box;border:1px solid #9aa5b1;background:rgba(236,240,244,.94);display:grid;grid-template-columns:22% 56% 22%;grid-template-rows:22% 56% 22%;backface-visibility:hidden}' +
      '.bim-vcube-face>span{display:block}' +
      '.bim-vcube-face>span:hover{background:rgba(26,108,181,.35)}' +
      '.bim-vcube-face>b{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:600;letter-spacing:.2px;color:#44505c;pointer-events:none}' +
      '.bim-vcube-anel{position:absolute;left:4px;top:60px;width:96px;height:44px;border-radius:50%;border:5px solid rgba(160,170,182,.55);box-sizing:border-box;pointer-events:none}' +
      /* CUBO DE CRISTAL (02/10/2026, ESPEC-BIM-CUBO-LOGO.md) — PRÉVIA (`.cristal`, ver cristalLigado): menor que o de cima
         (104×112), faces de vidro verde por cima do cristal desenhado em WebGL (bim/cristal.js), nomes com brilho, bússola no
         plano do chão, controles só no hover/toque. Sem a prévia, o cubo é exatamente o de antes.
         ⚠ As classes e as zonas (span[data-i][data-j]) são as MESMAS nos dois: é nelas que as e2e e o clique agem. */
      '.bim-vcube.cristal{width:96px;height:104px}' +
      '.bim-vcube.cristal .bim-vcube-cena{left:18px;top:16px;width:60px;height:60px}' +
      '.bim-vcube.cristal .bim-vcube-cubo{left:30px;top:30px}' +
      '.bim-vcube.cristal .bim-vcube-face{left:-30px;top:-30px;width:60px;height:60px;border:1px solid rgba(120,255,180,.6);background:rgba(28,112,72,.66);box-shadow:inset 0 0 12px rgba(90,255,170,.22)}' +
      /* com o cristal desenhado atrás (só a vista principal), a face vira vidro quase transparente */
      '.bim-vcube.cristal.com-cristal .bim-vcube-face{background:rgba(40,170,100,.10)}' +
      '.bim-vcube.cristal .bim-vcube-face>span:hover{background:rgba(60,207,115,.42);box-shadow:0 0 8px rgba(110,255,170,.6)}' +
      '.bim-vcube.cristal .bim-vcube-face>b{font-size:8.5px;font-weight:700;letter-spacing:.5px;color:#f0fff6;text-shadow:0 0 4px #3ccf73,0 0 2px #0b2a18,0 0 1px #000}' +
      '.bim-vcube.cristal .bim-vcube-anel{display:none}' +
      /* ⚠ a caixa da bússola (quadrado girado em 3D) entra na conta de sobreposição da barra da mesa (bimmesa.js, top 140):
         132 px com as letras DENTRO dela — com 150 px a caixa passava da barra (e2e-bim-mesa, 02/10/2026) */
      '.bim-vcube-bussola{position:absolute;left:-66px;top:-66px;width:132px;height:132px;pointer-events:none}' +
      '.bim-vcube-ctl{position:absolute;inset:0;opacity:0;pointer-events:none;transition:opacity .15s}' +
      /* ⚠ a camada dos controles cobre o cubo inteiro: ela mesma NUNCA pega clique (senão as faces deixam de responder);
         só os botões, quando visíveis */
      '.bim-vcube:hover .bim-vcube-ctl,.bim-vcube.sobre .bim-vcube-ctl,.bim-vcube.toque .bim-vcube-ctl{opacity:1}' +
      '.bim-vcube:hover .bim-vcube-ctl>*,.bim-vcube.sobre .bim-vcube-ctl>*,.bim-vcube.toque .bim-vcube-ctl>*{pointer-events:auto}' +
      '.bim-vcube-ctl button{position:absolute;width:20px;height:20px;padding:0;border:0;border-radius:6px;background:rgba(15,39,64,.72);color:#bfffd6;cursor:pointer;display:flex;align-items:center;justify-content:center}' +
      '.bim-vcube-ctl button:hover{background:#1f9d55;color:#fff}' +
      '.bim-vcube-ctl select{position:absolute;left:0;top:83px;width:36px;height:18px;font-size:10px;border-radius:5px;border:1px solid #2e6f9e;background:rgba(15,39,64,.85);color:#dbe8f5;padding:0 2px}' +
      '.bim-vcube-angulo{position:absolute;right:100px;top:0;display:none;pointer-events:auto;background:rgba(15,39,64,.95);border:1px solid #2e6f9e;border-radius:8px;padding:6px 8px;color:#dbe8f5;font-size:11px;white-space:nowrap;z-index:6}' +
      '.bim-vcube-angulo.aberto{display:block}' +
      '.bim-vcube-angulo input{width:44px;font-size:11px;margin:0 4px 0 2px;background:#0f2740;color:#fff;border:1px solid #2e6f9e;border-radius:4px}' +
      '.bim-vcube-menu{position:fixed;z-index:80;min-width:230px;background:#fff;color:#1a1a1a;border:1px solid #b4b4b4;box-shadow:0 6px 18px rgba(0,0,0,.22);padding:4px 0;font:12px "Segoe UI",system-ui,sans-serif}' +
      '.bim-vcube-menu div{padding:5px 14px 5px 26px;cursor:pointer;white-space:nowrap;position:relative}' +
      '.bim-vcube-menu div:hover{background:#d8e6f2}' +
      '.bim-vcube-menu div[data-marca]:before{content:"\\2713";position:absolute;left:9px}' +
      '.bim-vcube-menu hr{border:0;border-top:1px solid #d4d4d4;margin:4px 0}' +
      '.bim-vcube-menu .sub{padding-left:40px}';
    document.head.appendChild(st);
  }
  /* cria o ViewCube de UMA vista. ctx = { cam(), orbit(), voar(pos,tgt), home(), menu(acao) } */
  function criarViewCube(cont, ctx) {
    vcEstilo();
    var cristal = !!(ctx && ctx.cristal);
    var w = document.createElement('div'); w.className = 'bim-vcube' + (cristal ? ' cristal' : '');
    w.innerHTML = '<button type="button" class="bim-vcube-casa" title="Ir para o início (Início)">' +
      '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/></svg></button>' +
      '<div class="bim-vcube-anel"></div><div class="bim-vcube-cena"><div class="bim-vcube-cubo"></div></div>';
    var cubo = w.querySelector('.bim-vcube-cubo');
    Object.keys(VC_FACES).forEach(function (k) {
      var f = VC_FACES[k], fe = document.createElement('div');
      fe.className = 'bim-vcube-face'; fe.setAttribute('data-face', k); fe.style.transform = vcMatFace(f, cristal ? 30 : 35);
      /* 3×3: canto, aresta, face — a direção é a soma das normais tocadas */
      [1, 0, -1].forEach(function (j) { [-1, 0, 1].forEach(function (i) { var z = document.createElement('span'); z.setAttribute('data-i', i); z.setAttribute('data-j', j); fe.appendChild(z); }); });
      var b = document.createElement('b'); b.textContent = f.rot; fe.appendChild(b);
      cubo.appendChild(fe);
    });
    if (cristal) {
    /* BÚSSOLA no plano do chão, logo abaixo do cubo: N verde, S, L, O e as diagonais; marcas a cada 15°.
       O plano gira com a vista como as faces (norte = −Z da cena = +Y do IFC, ver ESPEC-BIM-CUBO-LOGO §1). */
    var bus = document.createElement('div'); bus.className = 'bim-vcube-bussola';
    var marcas = '';
    for (var gm = 0; gm < 360; gm += 15) { var ra = gm * Math.PI / 180, r1 = gm % 45 === 0 ? 40 : 43; marcas += '<line x1="' + (66 + Math.sin(ra) * r1).toFixed(1) + '" y1="' + (66 - Math.cos(ra) * r1).toFixed(1) + '" x2="' + (66 + Math.sin(ra) * 47).toFixed(1) + '" y2="' + (66 - Math.cos(ra) * 47).toFixed(1) + '"/>'; }
    /* ⚠ estilo por ATRIBUTO, nunca <style> dentro do SVG: o <style> de um SVG embutido vale para o documento inteiro */
    var BUS_EST = { bn: 'font-size="15" font-weight="800" fill="#3ccf73"', bp: 'font-size="12" font-weight="700" fill="#f2fff7"', bd: 'font-size="8" font-weight="700" fill="#cdf5dc"' };
    function rotBus(t, gr, rr, cls) { var a = gr * Math.PI / 180; return '<text x="' + (66 + Math.sin(a) * rr).toFixed(1) + '" y="' + (66 - Math.cos(a) * rr + 4.5).toFixed(1) + '" text-anchor="middle" font-family="Segoe UI,sans-serif" stroke="#0b2a18" stroke-width=".6" paint-order="stroke" ' + BUS_EST[cls] + ' data-rosa="' + t + '">' + t + '</text>'; }
    bus.innerHTML = '<svg viewBox="0 0 132 132" width="132" height="132"><circle cx="66" cy="66" r="45" fill="none" stroke="rgba(150,255,195,.7)" stroke-width="3"/>' +
      '<g stroke="rgba(190,255,215,.7)" stroke-width="1">' + marcas + '</g>' +
      rotBus('N', 0, 56, 'bn') + rotBus('L', 90, 56, 'bp') + rotBus('S', 180, 56, 'bp') + rotBus('O', 270, 56, 'bp') +
      rotBus('NE', 45, 55, 'bd') + rotBus('SE', 135, 55, 'bd') + rotBus('SO', 225, 55, 'bd') + rotBus('NO', 315, 55, 'bd') + '</svg>';
    /* plano horizontal (normal +Y), leste para a direita, norte para cima da figura, 34 px abaixo do centro */
    bus.style.transform = vcMatPlano(_V3(1, 0, 0), _V3(0, 0, -1), _V3(0, 1, 0), -30);
    cubo.appendChild(bus);
    /* CONTROLES (só no hover ou no toque): setas giram a vista pelo passo; ângulo exato; menu */
    var seta = function (d) { return '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.6"><path d="' + d + '"/></svg>'; };
    var ctl = document.createElement('div'); ctl.className = 'bim-vcube-ctl';
    ctl.innerHTML = '<button type="button" data-vc="cima" title="Girar para cima" style="left:38px;top:0">' + seta('M6 15l6-6 6 6') + '</button>' +
      '<button type="button" data-vc="baixo" title="Girar para baixo" style="left:38px;top:82px">' + seta('M6 9l6 6 6-6') + '</button>' +
      '<button type="button" data-vc="esquerda" title="Girar para a esquerda" style="left:0;top:36px">' + seta('M15 6l-6 6 6 6') + '</button>' +
      '<button type="button" data-vc="direita" title="Girar para a direita" style="left:76px;top:36px">' + seta('M9 6l6 6-6 6') + '</button>' +
      '<button type="button" data-vc="angulo" title="Ângulo exato (azimute e elevação)" style="left:76px;top:82px">' + seta('M4 20h16M4 20L16 6') + '</button>' +
      '<button type="button" data-vc="menu" title="Menu da vista" style="left:76px;top:0">' + seta('M5 7h14M5 12h14M5 17h14') + '</button>' +
      '<select data-vc="passo" title="Passo do giro">' + [15, 30, 45, 90].map(function (g) { return '<option value="' + g + '"' + (g === 45 ? ' selected' : '') + '>' + g + '°</option>'; }).join('') + '</select>' +
      '<div class="bim-vcube-angulo">azimute<input type="text" inputmode="decimal" data-vc="az" value="0">elevação<input type="text" inputmode="decimal" data-vc="el" value="30"><button type="button" data-vc="ir" style="position:static;display:inline-flex;width:auto;padding:0 6px">Ir</button></div>';
    w.appendChild(ctl);
    function vcBA() { return (typeof window !== 'undefined') ? window.BimAbertura : null; }
    function vcIrAngulo(az, el) {
      var BAv = vcBA(); if (!BAv) return;
      var cam = ctx.cam(), orb = ctx.orbit(), dist = cam.position.distanceTo(orb.target);
      var p = BAv.posicaoDaCamera(orb.target, dist, az, Math.max(-89, Math.min(89, el)));
      ctx.voar(new THREE.Vector3(p.x, p.y, p.z), orb.target.clone());
    }
    function vcAngAtual() { var BAv = vcBA(), cam = ctx.cam(), orb = ctx.orbit(); if (!BAv) return null; var d = orb.target.clone().sub(cam.position); return BAv.anguloDaCamera(d.x, d.y, d.z); }
    ctl.addEventListener('pointerdown', function (e) { e.stopPropagation(); });
    ctl.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-vc]') : null; if (!b) return;
      e.stopPropagation();
      var acao = b.getAttribute('data-vc'), BAv = vcBA();
      if (acao === 'menu') { var rcm = b.getBoundingClientRect(); abrirMenuCubo(rcm.left, rcm.bottom, ctx); return; }
      if (acao === 'angulo') { var pa = ctl.querySelector('.bim-vcube-angulo'), at = vcAngAtual(); if (at) { ctl.querySelector('[data-vc="az"]').value = Math.round(at.az); ctl.querySelector('[data-vc="el"]').value = Math.round(at.el); } pa.classList.toggle('aberto'); return; }
      if (acao === 'ir') { vcIrAngulo(+String(ctl.querySelector('[data-vc="az"]').value).replace(',', '.') || 0, +String(ctl.querySelector('[data-vc="el"]').value).replace(',', '.') || 0); return; }
      if (!BAv || ['cima', 'baixo', 'esquerda', 'direita'].indexOf(acao) < 0) return;
      var a0 = vcAngAtual(), n = BAv.girar(a0.az, a0.el, acao, +ctl.querySelector('[data-vc="passo"]').value || 45);
      vcIrAngulo(n.az, n.el);
    });
    w.addEventListener('pointerenter', function (e) { if (e.pointerType !== 'touch') w.classList.add('sobre'); });
    w.addEventListener('pointerleave', function () { w.classList.remove('sobre'); });
    /* no toque, os controles ficam visíveis por 3 s */
    w.addEventListener('pointerdown', function (e) { if (e.pointerType !== 'touch') return; w.classList.add('toque'); clearTimeout(w._toqueT); w._toqueT = setTimeout(function () { w.classList.remove('toque'); }, 3000); }, true);
    } /* fim do cubo de cristal (prévia) */
    cont.appendChild(w);
    var arrastou = false, p0 = null, zonaDown = null;
    w.querySelector('.bim-vcube-casa').onclick = function (e) { e.stopPropagation(); ctx.home(); };
    /* ⚠ a zona é guardada no APERTAR: com a captura do ponteiro no cubo, o
       alvo do SOLTAR passa a ser o próprio cubo, e a face clicada se perdia */
    cubo.addEventListener('pointerdown', function (e) { if (e.button !== 0) return; p0 = { x: e.clientX, y: e.clientY }; arrastou = false; zonaDown = e.target && e.target.closest ? e.target.closest('.bim-vcube-face > span') : null; try { cubo.setPointerCapture(e.pointerId); } catch (_) {} e.stopPropagation(); });
    cubo.addEventListener('pointermove', function (e) {
      if (!p0) return;
      var dx = e.clientX - p0.x, dy = e.clientY - p0.y;
      if (!arrastou && Math.abs(dx) + Math.abs(dy) < 4) return;
      arrastou = true; p0 = { x: e.clientX, y: e.clientY };
      /* arrastar o cubo GIRA a vista em volta do alvo (como no Revit) */
      var cam = ctx.cam(), orb = ctx.orbit(), off = cam.position.clone().sub(orb.target);
      var sph = new THREE.Spherical().setFromVector3(off);
      sph.theta -= dx * 0.012; sph.phi = Math.max(0.02, Math.min(Math.PI - 0.02, sph.phi - dy * 0.012));
      off.setFromSpherical(sph); cam.position.copy(orb.target).add(off); cam.lookAt(orb.target);
    });
    cubo.addEventListener('pointerup', function (e) {
      var eraClique = p0 && !arrastou; p0 = null;
      if (!eraClique) return;
      var z = zonaDown; zonaDown = null; if (!z) return;
      var f = VC_FACES[z.parentNode.getAttribute('data-face')], i = +z.getAttribute('data-i'), j = +z.getAttribute('data-j');
      orientarPara(ctx, f.n.clone().add(f.u.clone().multiplyScalar(i)).add(f.v.clone().multiplyScalar(j)));
    });
    w.addEventListener('contextmenu', function (e) { e.preventDefault(); e.stopPropagation(); abrirMenuCubo(e.clientX, e.clientY, ctx); });
    var ultimo = '';
    return {
      el: w,
      atualizar: function () {
        var cam = ctx.cam(); if (!cam) return;
        cam.updateMatrixWorld();
        var e = cam.matrixWorldInverse.elements;
        var m = [e[0], -e[1], e[2], 0, -e[4], e[5], -e[6], 0, e[8], -e[9], e[10], 0, 0, 0, 0, 1];
        var s = 'matrix3d(' + m.map(function (x) { return Math.abs(x) < 1e-7 ? 0 : +x.toFixed(6); }).join(',') + ')';
        if (s !== ultimo) { cubo.style.transform = s; ultimo = s; }
      },
      remover: function () { if (w.parentNode) w.parentNode.removeChild(w); }
    };
  }
  /* olhar DE uma direção, mantendo o alvo e a distância */
  function orientarPara(ctx, dir) {
    var cam = ctx.cam(), orb = ctx.orbit();
    dir = dir.clone(); if (dir.lengthSq() < 1e-9) return; dir.normalize();
    /* de cima (ou de baixo) exato a órbita perde o "norte": um fio para o sul mantém a frente embaixo */
    if (Math.abs(dir.y) > 0.999) dir.z += 0.0015 * (dir.y > 0 ? 1 : -1);
    var d = cam.position.distanceTo(orb.target);
    ctx.voar(orb.target.clone().add(dir.normalize().multiplyScalar(d)), orb.target.clone());
  }
  var _menuCubo = null;
  function fecharMenuCubo() { if (_menuCubo && _menuCubo.parentNode) _menuCubo.parentNode.removeChild(_menuCubo); _menuCubo = null; }
  function abrirMenuCubo(x, y, ctx) {
    fecharMenuCubo();
    var orto = !!ctx.orto(), m = document.createElement('div'); m.className = 'bim-vcube-menu';
    var itens = [['inicio', 'Ir para o início'], ['salvar', 'Salvar vista'], null, ['persp', 'Perspectiva', !orto], ['orto', 'Ortogonal', orto], null,
      ['definir-inicio', 'Definir vista atual como a principal'], ['reinicio', 'Reinicializar o início'], null,
      ['o-frontal', 'Orientar: Frontal', false, 1], ['o-posterior', 'Orientar: Posterior', false, 1], ['o-esquerda', 'Orientar: Esquerda', false, 1], ['o-direita', 'Orientar: Direita', false, 1],
      ['o-superior', 'Orientar: Superior', false, 1], ['o-inferior', 'Orientar: Inferior', false, 1], ['o-iso', 'Orientar: Isométrica', false, 1], null, ['enquadrar', 'Enquadrar tudo']];
    itens.forEach(function (it) {
      if (!it) { m.appendChild(document.createElement('hr')); return; }
      var d = document.createElement('div'); d.textContent = it[1]; d.setAttribute('data-a', it[0]);
      if (it[2]) d.setAttribute('data-marca', '1');
      if (it[3]) d.className = 'sub';
      m.appendChild(d);
    });
    m.addEventListener('click', function (e) {
      var a = e.target.getAttribute && e.target.getAttribute('data-a'); if (!a) return;
      fecharMenuCubo();
      if (a.indexOf('o-') === 0) {
        var k = a.slice(2);
        if (k === 'iso') orientarPara(ctx, _V3(1, 0.85, 1)); else orientarPara(ctx, VC_FACES[k].n.clone());
        return;
      }
      ctx.menu(a);
    });
    m.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    document.body.appendChild(m);
    var r = m.getBoundingClientRect();
    m.style.left = Math.max(4, Math.min(x, (window.innerWidth || 800) - r.width - 6)) + 'px';
    m.style.top = Math.max(4, Math.min(y, (window.innerHeight || 600) - r.height - 6)) + 'px';
    _menuCubo = m;
    setTimeout(function () { document.addEventListener('pointerdown', function fora(ev) { if (_menuCubo && !_menuCubo.contains(ev.target)) { fecharMenuCubo(); document.removeEventListener('pointerdown', fora, true); } }, true); }, 0);
  }

  /* ---------- ortogonal: abertura mínima, câmera recuada na mesma proporção ---------- */
  var ORTO_FOV = 1.2;
  function raioModelo() { var b = new THREE.Box3().setFromObject(modelRoot); if (b.isEmpty()) return 20; return Math.max(1, b.getSize(new THREE.Vector3()).length() / 2); }
  function aplicarOrto(cam, orb, on, estado) {
    if (!!estado.on === !!on) return;
    var d = cam.position.distanceTo(orb.target), dir = cam.position.clone().sub(orb.target).normalize();
    var fov0 = on ? cam.fov : estado.fovPersp || 60, fov1 = on ? ORTO_FOV : (estado.fovPersp || 60);
    var h = 2 * d * Math.tan(fov0 * Math.PI / 360);
    var d1 = h / (2 * Math.tan(fov1 * Math.PI / 360));
    /* ⚠ near/far da perspectiva são GUARDADOS ao ligar e DEVOLVIDOS ao
       desligar. A primeira versão, com a ortogonal desligada, empurrava a
       câmera a cada quadro para near <= 0,1 e far >= 5000 — passando por cima
       do enquadramento (near = maior dimensão/1000): num modelo grande o near
       caía e a profundidade perdia precisão (faces cintilando). */
    if (on) { estado.fovPersp = cam.fov; estado.near0 = cam.near; estado.far0 = cam.far; }
    estado.on = !!on;
    cam.fov = fov1; cam.position.copy(orb.target).add(dir.multiplyScalar(d1));
    if (!on && estado.near0) { cam.near = estado.near0; cam.far = estado.far0; }
    cam.updateProjectionMatrix();
    ajustarPlanosOrto(cam, orb, estado);
  }
  function ajustarPlanosOrto(cam, orb, estado) {
    if (!estado.on) return;
    var dd = cam.position.distanceTo(orb.target), R = estado.raio || (estado.raio = raioModelo());
    var nn = Math.max(0.1, dd - R * 2.2), ff = dd + R * 4;
    if (Math.abs(nn - cam.near) > 0.5 || Math.abs(ff - cam.far) > 1) { cam.near = nn; cam.far = ff; cam.updateProjectionMatrix(); }
  }

  /* ---------- CAIXA DE CORTE, com as setas azuis nas seis faces ----------
   * Os seis planos entram no `clippingPlanes` DO RENDERER da vista (cada vista
   * tem a sua caixa); a caixa e as setas são desenhadas numa cena à parte,
   * depois, sem corte — senão o próprio corte apagaria a caixa. */
  function criarCaixaCorte(ctx) {
    var cx = { on: false, box: new THREE.Box3(), planos: [], cena: new THREE.Scene(), setas: [], arr: null };
    for (var i = 0; i < 6; i++) cx.planos.push(new THREE.Plane(_V3(1, 0, 0), 0));
    var linMat = new THREE.LineBasicMaterial({ color: 0x1a6cb5, depthTest: false, transparent: true, opacity: 0.95 });
    var setaMat = new THREE.MeshBasicMaterial({ color: 0x1f6fd1, depthTest: false, transparent: true, opacity: 0.95 });
    var setaMatHover = new THREE.MeshBasicMaterial({ color: 0xf59e0b, depthTest: false, transparent: true, opacity: 1 });
    var linhas = new THREE.LineSegments(new THREE.BufferGeometry(), linMat); linhas.renderOrder = 999; cx.cena.add(linhas);
    var FACES = [['x', -1], ['x', 1], ['y', -1], ['y', 1], ['z', -1], ['z', 1]];
    var coneGeo = new THREE.ConeGeometry(0.35, 1, 14);
    FACES.forEach(function (f, k) {
      var g = new THREE.Group(), cone = new THREE.Mesh(coneGeo, setaMat), cone2 = new THREE.Mesh(coneGeo, setaMat);
      cone.position.y = 0.55; cone2.position.y = -0.55; cone2.rotation.z = Math.PI;
      g.add(cone); g.add(cone2); g.userData.face = k; cone.userData.face = k; cone2.userData.face = k;
      /* o grupo aponta o eixo Y local para a normal da face */
      var n = _V3(f[0] === 'x' ? f[1] : 0, f[0] === 'y' ? f[1] : 0, f[0] === 'z' ? f[1] : 0);
      g.quaternion.setFromUnitVectors(_V3(0, 1, 0), n);
      cx.cena.add(g); cx.setas.push(g);
    });
    function atualizar() {
      var b = cx.box, mn = b.min, mx = b.max;
      cx.planos[0].set(_V3(1, 0, 0), -mn.x); cx.planos[1].set(_V3(-1, 0, 0), mx.x);
      cx.planos[2].set(_V3(0, 1, 0), -mn.y); cx.planos[3].set(_V3(0, -1, 0), mx.y);
      cx.planos[4].set(_V3(0, 0, 1), -mn.z); cx.planos[5].set(_V3(0, 0, -1), mx.z);
      var c = [[mn.x, mn.y, mn.z], [mx.x, mn.y, mn.z], [mx.x, mx.y, mn.z], [mn.x, mx.y, mn.z], [mn.x, mn.y, mx.z], [mx.x, mn.y, mx.z], [mx.x, mx.y, mx.z], [mn.x, mx.y, mx.z]];
      var ar = [0, 1, 1, 2, 2, 3, 3, 0, 4, 5, 5, 6, 6, 7, 7, 4, 0, 4, 1, 5, 2, 6, 3, 7], pos = [];
      ar.forEach(function (ix) { pos.push(c[ix][0], c[ix][1], c[ix][2]); });
      linhas.geometry.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); linhas.geometry.computeBoundingSphere();
      var ctr = b.getCenter(new THREE.Vector3());
      FACES.forEach(function (f, k) {
        var p = ctr.clone(); p[f[0]] = f[1] < 0 ? mn[f[0]] : mx[f[0]];
        cx.setas[k].position.copy(p);
      });
    }
    cx.ligar = function (on, box) {
      cx.on = !!on;
      var rr = ctx.renderer();
      if (cx.on) {
        var b = box || new THREE.Box3().setFromObject(modelRoot);
        if (b.isEmpty()) { cx.on = false; return false; }
        var sz = b.getSize(new THREE.Vector3()), fol = Math.max(0.05, sz.length() * 0.01);
        cx.box.copy(b).expandByScalar(fol);
        atualizar();
        rr.clippingPlanes = cx.planos.slice(); rr.localClippingEnabled = false;
      } else {
        if (rr.clippingPlanes && rr.clippingPlanes.length === 6 && rr.clippingPlanes[0] === cx.planos[0]) rr.clippingPlanes = [];
      }
      return cx.on;
    };
    /* as setas ficam do mesmo tamanho na tela, perto ou longe */
    cx.desenhar = function (rr, cam) {
      if (!cx.on) return;
      var ctr = cx.box.getCenter(new THREE.Vector3());
      var esc = Math.max(0.05, cam.position.distanceTo(ctr) * Math.tan((cam.fov || 60) * Math.PI / 360) * 0.045);
      cx.setas.forEach(function (g) { g.scale.setScalar(esc); });
      var ac = rr.autoClear, cp = rr.clippingPlanes;
      rr.autoClear = false; rr.clippingPlanes = [];
      try { rr.render(cx.cena, cam); } catch (_) {}
      rr.clippingPlanes = cp; rr.autoClear = ac;
    };
    /* ⚠ PEGA A SETA ANTES DA ÓRBITA: o ouvinte é de CAPTURA no canvas, e no
       alvo a captura roda antes do ouvinte comum do OrbitControls — o
       `stopImmediatePropagation` impede a vista de girar enquanto se puxa a
       face. Soltou, a órbita volta. */
    var ray = new THREE.Raycaster(), ms = new THREE.Vector2(), arr = null, hover = null;
    function setaSob(e) {
      if (!cx.on) return null;
      var cv = ctx.canvas(), r = cv.getBoundingClientRect();
      ms.x = ((e.clientX - r.left) / r.width) * 2 - 1; ms.y = -((e.clientY - r.top) / r.height) * 2 + 1;
      ray.setFromCamera(ms, ctx.cam());
      var h = ray.intersectObjects(cx.setas, true);
      return h.length ? h[0].object.userData.face : null;
    }
    function pintarHover(f) { if (hover === f) return; hover = f; cx.setas.forEach(function (g, k) { g.children.forEach(function (c) { c.material = k === f ? setaMatHover : setaMat; }); }); ctx.canvas().style.cursor = f == null ? '' : 'move'; }
    cx.onDown = function (e) {
      if (!cx.on || e.button !== 0) return;
      var f = setaSob(e); if (f == null) return;
      e.stopImmediatePropagation(); e.preventDefault();
      var eixo = FACES[f][0], lado = FACES[f][1], cam = ctx.cam();
      var ctr = cx.box.getCenter(new THREE.Vector3()); ctr[eixo] = lado < 0 ? cx.box.min[eixo] : cx.box.max[eixo];
      var um = _V3(0, 0, 0); um[eixo] = 1;
      var cv = ctx.canvas(), r = cv.getBoundingClientRect();
      var a = ctr.clone().project(cam), b = ctr.clone().add(um).project(cam);
      var px = { x: (b.x - a.x) * r.width / 2, y: -(b.y - a.y) * r.height / 2 };
      var l2 = px.x * px.x + px.y * px.y;
      arr = { f: f, eixo: eixo, lado: lado, x0: e.clientX, y0: e.clientY, v0: lado < 0 ? cx.box.min[eixo] : cx.box.max[eixo], px: px, l2: Math.max(l2, 1e-6) };
      var orb = ctx.orbit(); if (orb) orb.enabled = false;
      try { cv.setPointerCapture(e.pointerId); } catch (_) {}
    };
    cx.onMove = function (e) {
      if (!cx.on) return;
      if (!arr) { pintarHover(setaSob(e)); return; }
      e.stopImmediatePropagation();
      var dx = e.clientX - arr.x0, dy = e.clientY - arr.y0;
      var dm = (dx * arr.px.x + dy * arr.px.y) / arr.l2;
      var v = arr.v0 + dm, lim = 0.02;
      if (arr.lado < 0) cx.box.min[arr.eixo] = Math.min(v, cx.box.max[arr.eixo] - lim);
      else cx.box.max[arr.eixo] = Math.max(v, cx.box.min[arr.eixo] + lim);
      atualizar();
    };
    cx.onUp = function (e) {
      if (!arr) return;
      arr = null; e.stopImmediatePropagation();
      var orb = ctx.orbit(); if (orb) orb.enabled = ctx.orbitLivre ? ctx.orbitLivre() : true;
      try { ctx.canvas().releasePointerCapture(e.pointerId); } catch (_) {}
    };
    cx.ligarEventos = function (cv) {
      cv.addEventListener('pointerdown', cx.onDown, true);
      cv.addEventListener('pointermove', cx.onMove, true);
      cv.addEventListener('pointerup', cx.onUp, true);
    };
    cx.estado = function () { return { on: cx.on, min: cx.box.min.toArray(), max: cx.box.max.toArray() }; };
    return cx;
  }

  /* ---------- a vista PRINCIPAL ganha ViewCube, ortogonal e caixa de corte ---------- */
  var ortoMain = { on: false, fovPersp: 60, raio: 0 };
  var inicioChave = function () { return 'orcapro:bim:inicio:' + (OBRA_ID || '-'); };
  function irInicio(cam, orb, voar) {
    var sv = null; try { sv = JSON.parse(localStorage.getItem(inicioChave()) || 'null'); } catch (_) {}
    if (sv && sv.p && sv.t) { voar(_V3(sv.p[0], sv.p[1], sv.p[2]), _V3(sv.t[0], sv.t[1], sv.t[2])); return; }
    var b = new THREE.Box3().setFromObject(modelRoot);
    if (b.isEmpty()) return;
    var c = b.getCenter(new THREE.Vector3()), raio = Math.max(b.getSize(new THREE.Vector3()).length() / 2, 0.5);
    var dist = raio / Math.tan((cam.fov * Math.PI / 180) / 2) * 1.15;
    voar(c.clone().add(_V3(1, 0.85, 1).normalize().multiplyScalar(dist)), c);
  }
  function menuDaVista(a, cam, orb, voar, estOrto) {
    if (a === 'inicio') irInicio(cam, orb, voar);
    else if (a === 'enquadrar') { if (cam === camera) S._fit(); else irInicio(cam, orb, voar); }
    else if (a === 'persp' || a === 'orto') { aplicarOrto(cam, orb, a === 'orto', estOrto); if (S.opts && S.opts.onOrto) try { S.opts.onOrto(estOrto.on); } catch (_) {} }
    else if (a === 'definir-inicio') { try { localStorage.setItem(inicioChave(), JSON.stringify({ p: cam.position.toArray(), t: orb.target.toArray() })); } catch (_) {} if (S._hint) S._hint('Vista atual definida como o início desta obra.'); }
    else if (a === 'reinicio') { try { localStorage.removeItem(inicioChave()); } catch (_) {} irInicio(cam, orb, voar); }
    else if (a === 'salvar') { var o = (S && S.opts) || opts; if (o && o.onSalvarVista) o.onSalvarVista(); }
  }
  var _cristalOn = !visitante && cristalLigado();
  var vcMain = criarViewCube(host, {
    cristal: _cristalOn,
    cam: function () { return camera; }, orbit: function () { return orbit; },
    voar: function (p, t) { voarCam(p, t, 0.55); }, orto: function () { return ortoMain.on; },
    home: function () { irInicio(camera, orbit, function (p, t) { voarCam(p, t, 0.6); }); },
    menu: function (a) { menuDaVista(a, camera, orbit, function (p, t) { voarCam(p, t, 0.6); }, ortoMain); }
  });
  S.vcubeEl = vcMain.el;
  if (visitante) vcMain.el.style.display = 'none';
  S._tickPos.push(function () { vcMain.atualizar(); ajustarPlanosOrto(camera, orbit, ortoMain); });

  /* =====================================================================
   * O CRISTAL ORÇAPRO (bim/cristal.js + js/bimabertura.js) — ESPEC-BIM-CUBO-LOGO.md
   * centro (sem modelo) → carregando → abrindo ("caixa de presente") → cubo (o cristal pequeno no canto).
   * ⚠ A ESCALA DO MODELO NA ABERTURA VALE SÓ NO DESENHO: aplicada num _tickExtra (depois do agregado) e
   *   desfeita no _tickPos. Caixa das peças, compatibilização, cache e clique veem o modelo do tamanho real.
   * ⚠ "Reduzir movimento" (preferência do sistema — e o Chrome sem tela das e2e): sem animação, direto ao fim.
   * ⚠ Visitante (link da RA/RV): sem cristal.
   * ===================================================================== */
  var cris = { hist: ['centro'], congelado: null, obj: null, estado: 'centro', t0: 0, tCarga: 0, curta: null, mo: null, c: null, escalado: null, ultimo: performance.now(), abriuEm: performance.now(), arr: null, semMov: false };
  try { cris.semMov = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (_) {}
  function crisBA() { return (typeof window !== 'undefined') ? window.BimAbertura : null; }
  function crisSet(e) { if (e === cris.estado) return; cris.estado = e; cris.hist.push(e); if (cris.hist.length > 40) cris.hist.shift(); }
  /* o relógio da abertura (o teste congela num instante para fotografar e para provar o Esc) */
  function crisT(t0) { return cris.congelado != null ? cris.congelado : performance.now() - t0; }
  function cristalDom() {
    if (S.vcubeEl) { S.vcubeEl.style.visibility = (!cris.obj || cris.estado === 'cubo') ? '' : 'hidden'; S.vcubeEl.classList.toggle('com-cristal', !!cris.obj); }
    if (cris.obj) {
      over.style.alignItems = 'flex-end'; over.style.paddingBottom = '3vh';
      var cxo = over.firstElementChild; if (cxo && !cxo._compacto) { cxo._compacto = 1; cxo.style.padding = '10px 22px'; cxo.style.maxWidth = '560px'; cxo.style.background = 'rgba(15,39,64,.72)'; if (cxo.firstElementChild) cxo.firstElementChild.style.display = 'none'; }
      loading.style.background = 'rgba(11,26,43,.12)'; loading.style.justifyContent = 'flex-end'; loading.style.paddingBottom = '8vh';
    }
  }
  function cristalCentroDe(mo) {
    var b = new THREE.Box3(), t = new THREE.Box3();
    (mo.grupo.children || []).forEach(function (m) { if (!m.geometry) return; if (!m.geometry.boundingBox) m.geometry.computeBoundingBox(); m.updateMatrix(); t.copy(m.geometry.boundingBox).applyMatrix4(m.matrix); b.union(t); });
    return b.isEmpty() ? new THREE.Vector3() : b.getCenter(new THREE.Vector3());
  }
  function cristalEvento(ev) {
    var BA = crisBA(); if (!BA) return;
    if (ev === 'carregar' && cris.estado === 'centro') cris.tCarga = performance.now();
    crisSet(BA.proximo(cris.estado, ev)); cristalDom();
  }
  function cristalModeloPronto(mo) {
    var BA = crisBA(); if (!BA) return;
    cris.menorEscala = null;
    if (!cris.obj || cris.semMov) { crisSet('cubo'); cris.mo = null; cristalDom(); return; }
    if (cris.estado === 'cubo') { cris.curta = { t0: performance.now(), mo: mo, c: cristalCentroDe(mo) }; return; }
    crisSet(BA.proximo(cris.estado === 'centro' ? 'carregando' : cris.estado, 'pronto'));
    cris.t0 = performance.now(); cris.mo = mo; cris.c = cristalCentroDe(mo); cris.abriuEm = cris.t0; cristalDom();
  }
  function cristalFechouTudo() { if (!S.modelos.length) { crisSet('centro'); cris.mo = null; cris.curta = null; cristalDom(); } }
  S._cristalEvento = cristalEvento; S._cristalModeloPronto = cristalModeloPronto; S._cristalFechouTudo = cristalFechouTudo;
  S._cristalEstado = function () { return cris.obj ? cris.estado : 'sem-cristal'; };
  /* hook de teste: a menor escala que a abertura APLICOU no desenho (prova que o modelo sai pequeno da caixa) */
  /* hook de teste: onde o cristal do canto cai na tela (barras projetadas pela câmera do canto, em px da página) */
  S._cristalCanto = function () {
    var o = cris.obj, r2 = cristalRetCanto(); if (!o || !r2) return null;
    var cv = renderer.domElement.getBoundingClientRect();
    return { ret: r2, barras: o.barras.map(function (b) { var p = new THREE.Vector3(); b.getWorldPosition(p); p.project(o.camCanto); return [Math.round(cv.left + r2.x + (p.x + 1) / 2 * r2.w), Math.round(cv.bottom - r2.y - (p.y + 1) / 2 * r2.h), +p.z.toFixed(3)]; }), vis: o.barras.map(function (b) { var v = true; b.traverseAncestors(function (a) { if (!a.visible) v = false; }); return v && b.visible; }) };
  };
  S._cristalCongelar = function (ms) { cris.congelado = ms == null ? null : +ms; };
  S._cristalDiag = function () { return { hist: cris.hist.slice(), estado: S._cristalEstado(), semMov: cris.semMov, menorEscala: cris.menorEscala == null ? null : cris.menorEscala, curta: !!cris.curta, escalaFora: S.modelos.map(function (m) { return +m.grupo.scale.x.toFixed(4); }) }; };
  S._cristalPular = function () { var BA = crisBA(); if (BA && cris.estado === 'abrindo') { crisSet(BA.proximo('abrindo', 'pular')); cris.mo = null; cristalDom(); } };
  if (_cristalOn) {
    fetch('bim/cristal-textos.json').then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; }).then(function (tx) {
      if (S !== Sm || !S.alive || !crisBA()) return;
      try { cris.obj = criarCristal({ renderer: renderer, transmissao: !cris.semMov, textos: tx }); } catch (eC) { cris.obj = null; }
      if (S.modelos.length) crisSet('cubo');
      cristalDom();
    });
  }
  /* o modelo encolhido (só durante o desenho) */
  function cristalEscala(mo, c, s, vis) {
    cris.escalado = { mo: mo, vis: mo.grupo.visible, pos: mo.grupo.position.clone(), esc: mo.grupo.scale.clone() };
    cris.menorEscala = Math.min(cris.menorEscala == null ? 9 : cris.menorEscala, s);
    mo.grupo.scale.setScalar(s); mo.grupo.position.set(c.x * (1 - s), c.y * (1 - s), c.z * (1 - s)); mo.grupo.visible = vis && cris.escalado.vis;
    var ag = mo._agreg && mo._agreg.grupo;
    if (ag) {
      modelRoot.updateMatrix();
      var M = new THREE.Matrix4().copy(modelRoot.matrix).multiply(new THREE.Matrix4().makeTranslation(c.x, c.y, c.z)).multiply(new THREE.Matrix4().makeScale(s, s, s)).multiply(new THREE.Matrix4().makeTranslation(-c.x, -c.y, -c.z));
      M.decompose(ag.position, ag.quaternion, ag.scale); ag.visible = ag.visible && vis;
    }
  }
  function cristalRestaura() {
    var e = cris.escalado; if (!e) return; cris.escalado = null;
    e.mo.grupo.scale.copy(e.esc); e.mo.grupo.position.copy(e.pos); e.mo.grupo.visible = e.vis; e.mo.grupo.updateMatrixWorld(true);
  }
  /* ⚠ registrado no _tickExtra DEPOIS do sincronizarAgregado (lá embaixo): o espelho copia a posição/escala do
     modelRoot a cada quadro e apagaria a escala da abertura se rodasse depois dela */
  S._cristalTickEscala = function () {
    var BA = crisBA(); if (!BA || !cris.obj) return;
    var agora = performance.now();
    if (cris.estado === 'abrindo' && cris.mo) { var q = BA.quadro(crisT(cris.t0), { semMovimento: cris.semMov }); cristalEscala(cris.mo, cris.c, q.modeloEscala, q.modeloVisivel); }
    else if (cris.curta) { var qc = BA.quadroCurto(agora - cris.curta.t0, { semMovimento: cris.semMov }); cristalEscala(cris.curta.mo, cris.curta.c, qc.modeloEscala, true); }
  };
  /* o retângulo do cristal do canto: 2× o lado do cubo HTML, no mesmo centro (o cubo girado passa do quadrado) */
  function cristalRetCanto() {
    var ce = S.vcubeEl && S.vcubeEl.querySelector('.bim-vcube-cena'); if (!ce) return null;
    /* ⚠ px CSS (ver o desenhar do bim/cristal.js): o three multiplica pelo pixelRatio */
    var a = ce.getBoundingClientRect(), b = renderer.domElement.getBoundingClientRect();
    if (!a.width || !b.width) return null;
    var cx = a.left + a.width / 2 - b.left, cy = b.bottom - (a.top + a.height / 2), lado = a.width * 2;
    return { x: Math.round(cx - lado / 2), y: Math.round(cy - lado / 2), w: Math.round(lado), h: Math.round(lado), ladoCubo: a.width };
  }
  function lerpN(a, b, k) { return a + (b - a) * k; }
  S._tickPos.push(function () {
    var agora = performance.now(), dt = Math.min(0.1, (agora - cris.ultimo) / 1000); cris.ultimo = agora;
    cristalRestaura();
    var BA = crisBA(), o = cris.obj; if (!BA || !o) return;
    var tS = agora / 1000, tamR = renderer.getSize(new THREE.Vector2()), W = tamR.x, H = tamR.y;
    if (cris.estado === 'centro' || cris.estado === 'carregando') {
      o.aplicarAbertura(null, false);
      o.aplicarBarras(cris.estado === 'carregando' ? BA.barras(Math.min(0.92, (agora - cris.tCarga) / 4000)) : null);
      o.aplicarEstrela(cris.semMov ? BA.estrela(0, 'acesa') : BA.estrela(tS, 'forte'));
      o.animarCentro(dt, tS, cris.semMov);
      o.camCentro.position.set(0, 0.12, 6.2); o.camCentro.lookAt(0, -0.3, 0); o.camCentro.aspect = W / Math.max(1, H); o.camCentro.updateProjectionMatrix();
      o.desenhar({ x: 0, y: 0, w: W, h: H }, o.camCentro);
      return;
    }
    if (cris.estado === 'abrindo') {
      var q = BA.quadro(crisT(cris.t0), { semMovimento: cris.semMov }), rc = cristalRetCanto() || { x: W - 200, y: H - 200, w: 160, h: 160 }, k = q.paraOCanto;
      o.aplicarAbertura(q, false); o.aplicarBarras(null); o.aplicarEstrela(BA.estrela(tS, 'forte'));
      o.animarCentro(dt, tS, cris.semMov);
      var rect = { x: Math.round(lerpN(0, rc.x, k)), y: Math.round(lerpN(0, rc.y, k)), w: Math.max(2, Math.round(lerpN(W, rc.w, k))), h: Math.max(2, Math.round(lerpN(H, rc.h, k))) };
      o.camCentro.position.set(0, 0.12, 6.2 - q.zoom * 1.8 - k * 1.6); o.camCentro.lookAt(0, -0.3 * (1 - k), 0); o.camCentro.aspect = rect.w / rect.h; o.camCentro.updateProjectionMatrix();
      o.desenhar(rect, o.camCentro);
      if (q.fim) { crisSet(BA.proximo('abrindo', 'fim')); cris.mo = null; cristalDom(); }
      return;
    }
    if (cris.estado === 'cubo' && S.vcubeEl && S.vcubeEl.style.display !== 'none') {
      var r2 = cristalRetCanto(); if (!r2) return;
      var pc = cris.curta ? BA.quadroCurto(agora - cris.curta.t0, { semMovimento: cris.semMov }) : null;
      o.aplicarAbertura(pc ? { t: 0, respira: pc.pisca * 0.12, luz: pc.pisca, tampaGraus: 0, ladosGraus: 0, explosao: pc.feixe * 0.6, cristalOpac: 1, paraOCanto: 1 } : null, true);
      o.aplicarBarras(null);
      o.aplicarEstrela(cris.semMov ? BA.estrela(0, 'acesa') : (agora - cris.abriuEm < 3000 ? BA.estrela(tS, 'forte') : BA.estrela(tS, 'suave')));
      o.prepararCanto(camera.quaternion, r2, r2.ladoCubo);
      o.desenhar(r2, o.camCanto);
      if (pc && pc.fim) cris.curta = null;
    }
  });
  /* centro: inclinar para o cursor, arrastar gira, clique dá um pulo; na abertura, clique pula.
     ⚠ FUNÇÕES COM NOME, não ouvinte anônimo de parâmetro "e": o test-bim-mira acha os ouvintes da mira/lupa pelo PRIMEIRO
     ouvinte anônimo de pointermove/pointerdown do canvas no arquivo — anônimos aqui, acima deles, roubavam a busca (02/10). */
  function cristalMover(ev) {
    if (!cris.obj || cris.estado !== 'centro') return;
    var r = canvasEl.getBoundingClientRect();
    cris.obj.inclinar(((ev.clientX - r.left) / r.width - 0.5) * 2, ((ev.clientY - r.top) / r.height - 0.5) * 2);
    if (cris.arr) { cris.obj.arrastar(ev.clientX - cris.arr.x, ev.clientY - cris.arr.y); cris.arr.x = ev.clientX; cris.arr.y = ev.clientY; cris.arr.moveu = true; }
  }
  function cristalApertar(ev) {
    if (!cris.obj) return;
    if (cris.estado === 'abrindo') { S._cristalPular(); return; }
    if (cris.estado === 'centro') cris.arr = { x: ev.clientX, y: ev.clientY, moveu: false };
  }
  function cristalSoltar() { if (cris.arr && !cris.arr.moveu && cris.obj) cris.obj.pular(); cris.arr = null; }
  canvasEl.addEventListener('pointermove', cristalMover);
  canvasEl.addEventListener('pointerdown', cristalApertar);
  canvasEl.addEventListener('pointerup', cristalSoltar);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && S === Sm && S.alive && cris.estado === 'abrindo') S._cristalPular(); });

  var cxMain = criarCaixaCorte({ renderer: function () { return renderer; }, cam: function () { return camera; }, orbit: function () { return orbit; }, canvas: function () { return renderer.domElement; }, orbitLivre: function () { return !fly.on; } });
  cxMain.ligarEventos(renderer.domElement);
  S._cxMain = cxMain;
  /* a caixa disputa o clippingPlanes com a planta e o corte livre: uma de cada vez */
  S._cxDesligar = function () { if (cxMain.on) { cxMain.ligar(false); if (S.opts && S.opts.onCaixaCorte) try { S.opts.onCaixaCorte(false); } catch (_) {} } };
  function caixaCorteMain(on) {
    if (on) { if (planta.on) setPlanta(false); if (corteL.on) setCorteL(false); }
    var r = cxMain.ligar(on);
    if (S.opts && S.opts.onCaixaCorte) try { S.opts.onCaixaCorte(r); } catch (_) {}
    return r;
  }
  S._caixaCorte = caixaCorteMain;
  S._ortoMain = function (on) { aplicarOrto(camera, orbit, on, ortoMain); return ortoMain.on; };
  S._ortoEstado = function () { return ortoMain.on; };
  S._camPlanos = function () { return { near: camera.near, far: camera.far, fov: camera.fov }; };
  S._irInicio = function () { irInicio(camera, orbit, function (p, t) { voarCam(p, t, 0.6); }); };

  /* ---------- VISTAS EXTRAS: outra câmera sobre a mesma cena ----------
   * Cada vista tem o SEU renderer (o seu canvas), câmera, órbita, ViewCube e
   * caixa de corte. A cena, os materiais e a seleção são os mesmos: clicou
   * numa, a peça fica verde em todas. O ambiente (reflexos) é refeito por
   * renderer — a textura do principal não vale num contexto WebGL de outro. */
  function envPara(rr) {
    try {
      var pm = new THREE.PMREMGenerator(rr), sc = new THREE.Scene();
      sc.add(new THREE.Mesh(new THREE.BoxGeometry(24, 18, 24), new THREE.MeshStandardMaterial({ side: THREE.BackSide, roughness: 1, metalness: 0, color: 0x9fb0c4 })));
      var luz = function (cor, w, h, d, x, y, z, g) { var m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshBasicMaterial()); m.material.color.setHex(cor).multiplyScalar(g); m.position.set(x, y, z); return m; };
      sc.add(luz(0xffffff, 16, 1, 16, 0, 8.5, 0, 3.0)); sc.add(luz(0xdfeaf7, 1, 10, 12, -11.5, 2, -3, 1.6)); sc.add(luz(0xfff0dc, 1, 10, 12, 11.5, 2, 4, 1.3)); sc.add(luz(0xc4d0dd, 16, 1, 16, 0, -8.5, 0, 0.6));
      var rt = pm.fromScene(sc, 0.04);
      sc.traverse(function (o) { if (o.material && o.material.dispose) o.material.dispose(); if (o.geometry && o.geometry.dispose) o.geometry.dispose(); });
      pm.dispose();
      return rt.texture;
    } catch (e) { return null; }
  }
  S.vistas = {}; var _vSeq = 0;
  function montarVista(v, cont) {
    var rr = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    rr.setPixelRatio(Math.min((cont.ownerDocument.defaultView || window).devicePixelRatio || 1, 2));
    try { rr.outputColorSpace = THREE.SRGBColorSpace; } catch (_) {}
    rr.toneMapping = renderer.toneMapping; rr.toneMappingExposure = renderer.toneMappingExposure;
    rr.domElement.style.cssText = 'display:block;width:100%;height:100%;outline:none';
    cont.style.position = cont.style.position || 'relative';
    cont.appendChild(rr.domElement);
    var orb = new OrbitControls(v.camera, rr.domElement); orb.enableDamping = true; orb.dampingFactor = .08; orb.target.copy(v.alvo);
    v.renderer = rr; v.orbit = orb; v.cont = cont; v.env = envPara(rr);
    var cxAnt = v.cx && v.cx.on ? v.cx.box.clone() : null;
    v.cx = criarCaixaCorte({ renderer: function () { return v.renderer; }, cam: function () { return v.camera; }, orbit: function () { return v.orbit; }, canvas: function () { return v.renderer.domElement; } });
    v.cx.ligarEventos(rr.domElement);
    if (cxAnt) { v.cx.ligar(true, cxAnt); v.cx.box.copy(cxAnt); }
    v.cubo = criarViewCube(cont, { cristal: _cristalOn,
      cam: function () { return v.camera; }, orbit: function () { return v.orbit; },
      voar: function (p, t) { v.tween = { p0: v.camera.position.clone(), p1: p, t0: v.orbit.target.clone(), t1: t, e: 0, dur: 0.55 }; },
      orto: function () { return v.orto.on; },
      home: function () { irInicio(v.camera, v.orbit, function (p, t) { v.tween = { p0: v.camera.position.clone(), p1: p, t0: v.orbit.target.clone(), t1: t, e: 0, dur: 0.6 }; }); },
      menu: function (a) { menuDaVista(a, v.camera, v.orbit, function (p, t) { v.tween = { p0: v.camera.position.clone(), p1: p, t0: v.orbit.target.clone(), t1: t, e: 0, dur: 0.6 }; }, v.orto); }
    });
    /* duplo clique seleciona NESTA vista — e a seleção aparece em todas */
    rr.domElement.addEventListener('dblclick', function (e) { selecionarNaVista(v, e.clientX, e.clientY); });
    redimVista(v);
  }
  function desmontarVista(v) {
    try { if (v.cubo) v.cubo.remover(); } catch (_) {}
    try { if (v.orbit) v.orbit.dispose(); } catch (_) {}
    try { if (v.env) v.env.dispose(); } catch (_) {}
    try { if (v.renderer) { var el = v.renderer.domElement; v.renderer.dispose(); if (v.renderer.forceContextLoss) v.renderer.forceContextLoss(); if (el.parentNode) el.parentNode.removeChild(el); } } catch (_) {}
    v.renderer = null; v.orbit = null; v.cubo = null;
  }
  function redimVista(v) {
    if (!v || !v.renderer || !v.cont) return;
    var w = v.cont.clientWidth, h = v.cont.clientHeight;
    if (w && h) { v.renderer.setSize(w, h, false); v.camera.aspect = w / h; v.camera.updateProjectionMatrix(); }
  }
  function selecionarNaVista(v, cx0, cy0) {
    if (S._limparRaioX) S._limparRaioX();
    var cv = v.renderer.domElement, r = cv.getBoundingClientRect(), rr = new THREE.Raycaster(), m = new THREE.Vector2();
    m.x = ((cx0 - r.left) / r.width) * 2 - 1; m.y = -((cy0 - r.top) / r.height) * 2 + 1;
    /* ⚠ A MESMA CAMADA DO RAIO DA PRINCIPAL: com a malha mesclada (AGREG) a
       tela desenha a malha única e as PEÇAS clicáveis moram na camada 1 — um
       raio na camada 0 atravessava o modelo sem achar nada (medido: 0 acertos
       no centro da vista 2 com o modelo inteiro na frente) */
    rr.layers.mask = ray.layers.mask;
    rr.setFromCamera(m, v.camera);
    var hits = rr.intersectObjects(modelRoot.children, true), hit = null, pls = v.renderer.clippingPlanes || [];
    for (var i = 0; i < hits.length && !hit; i++) {
      var ob = hits[i].object;
      if (v.est ? !(ob.userData && ob.userData.expressID != null && existeNaVista(ob, v.est) && (!ob.parent || ob.parent.visible !== false)) : !cadeiaVisivel(ob)) continue;
      var fora = false; for (var k = 0; k < pls.length; k++) if (pls[k].distanceToPoint(hits[i].point) < -1e-6) fora = true;
      if (!fora) hit = hits[i];
    }
    if (S.selected) { S.selected.material = S.prevMat; S.selected = null; }
    var o = (S && S.opts) || opts;
    if (hit && hit.object.userData && hit.object.userData.expressID != null) {
      S.selected = hit.object; S.prevMat = S.selected.material; S.selected.material = selMat;
      contornoSelecao(hit.object);
      if (o.onPick) o.onPick(propsDe(hit.object.userData.mid != null ? hit.object.userData.mid : S.modelID, hit.object.userData.expressID, hit.object.userData.tipo));
    } else { contornoSelecao(null); if (o.onPick) o.onPick(null); }
  }
  /* hook de teste: seleciona a peça sem clique — o mesmo que o duplo clique faz */
  S._selecionarUid = function (uid) {
    var m = S.meshPorUid && S.meshPorUid[uid]; if (!m) return false;
    if (S.selected) { S.selected.material = S.prevMat; S.selected = null; }
    S.selected = m; S.prevMat = m.material; m.material = selMat; contornoSelecao(m);
    var o = (S && S.opts) || opts;
    if (o.onPick) o.onPick(propsDe(m.userData.mid != null ? m.userData.mid : S.modelID, m.userData.expressID, m.userData.tipo));
    return true;
  };
  function novaVista(cont, nome) {
    var id = 'v' + (++_vSeq);
    var v = { id: id, nome: nome || ('{3D} ' + (_vSeq + 1)), camera: camera.clone(), alvo: orbit.target.clone(), orto: { on: ortoMain.on, fovPersp: ortoMain.fovPersp }, visivel: true };
    S.vistas[id] = v;
    montarVista(v, cont);
    return id;
  }
  function renderVistas(dt) {
    var ks = Object.keys(S.vistas);
    for (var i = 0; i < ks.length; i++) {
      var v = S.vistas[ks[i]];
      if (!v.renderer || !v.visivel || !v.cont || !v.cont.isConnected) continue;
      if (v.tween) {
        v.tween.e += dt; var kk = Math.min(1, v.tween.e / v.tween.dur), s = kk < 0.5 ? 2 * kk * kk : 1 - Math.pow(-2 * kk + 2, 2) / 2;
        v.camera.position.lerpVectors(v.tween.p0, v.tween.p1, s); v.orbit.target.lerpVectors(v.tween.t0, v.tween.t1, s);
        if (kk >= 1) v.tween = null;
      }
      v.orbit.update();
      ajustarPlanosOrto(v.camera, v.orbit, v.orto);
      var envP = scene.environment; scene.environment = v.env;
      var tr = null;
      try { if (v.est) tr = trocasDaVista(v); v.renderer.render(scene, v.camera); v.cx.desenhar(v.renderer, v.camera); } catch (_) {}
      finally { if (tr) desfazerTrocas(tr); }
      scene.environment = envP;
      v.cubo.atualizar();
    }
  }
  S._renderVistas = renderVistas;
  S._novaVista = novaVista;
  S._fecharVista = function (id) { var v = S.vistas[id]; if (!v) return false; limparEstadoVista(v); desmontarVista(v); delete S.vistas[id]; return true; };

  /* =====================================================================
   * VISTA COM ESTADO PRÓPRIO — o ponto de vista aberto NUMA ABA NOVA
   * (Rogério, 30/09/2026: "abrir um ponto de vista muda todas as janelas
   * abertas… quero que abra uma nova e ela mantenha como foi criada; só a
   * seleção aparece nas outras, se o elemento estiver visível").
   *
   * A visibilidade da cena é UMA (mesh.visible) e o modelo mesclado (AGREG)
   * desenha por UM índice e UM buffer de cor. A vista com estado próprio
   * guarda, por parte mesclada, o SEU índice, as SUAS cores e o SEU material
   * (transparência do raio-X), e o renderVistas troca os ponteiros só
   * durante o desenho dela (try/finally). Custo por quadro: trocar ponteiro;
   * cada contexto WebGL sobe o buffer dele uma vez (refeito só quando o
   * estado da vista ou a assinatura do mesclado muda).
   * Por vista: câmera, peças visíveis (isolar/ocultar), cores, raio-X e cotas.
   * Continua da cena inteira (global): cortes, estilo desenho, modelos
   * ligados e as cotas da rede — o ponto de vista que usa isso é avisado.
   * A seleção é uma só: aparece na vista onde a peça está visível.
   * ===================================================================== */
  var _parteSeq = 0, _estSeq = 0, _matCorVista = {};
  function uidDe(m) { return m.userData.mid + ':' + m.userData.expressID; }
  function existeNaVista(m, est) {
    if (ehFuturo4d(m) || ehRemovidoEd(m)) return false;   /* peça que ainda não existe (4D) ou foi apagada no editor */
    var u = uidDe(m);
    if (est.isolados) return !!est.isolados[u];
    if (est.ocultos) return !est.ocultos[u];
    return true;
  }
  function corNaVista(m, est) {
    var u = uidDe(m), c = est.cores[u] || _corDoMaterial(m.userData.matOrig || m.material);
    var a = c[3] == null ? 1 : c[3];
    if (est.rx && !est.rx[u]) a = 0.1;   /* raio-X: o resto vira fantasma (o 0,1 do ghostMat) */
    return [c[0], c[1], c[2], a];
  }
  function limparEstadoVista(v) {
    if (v.cotas) {
      (v.cotasObjs || []).forEach(function (o) { try { v.cotas.remove(o); if (o.geometry) o.geometry.dispose(); if (o.material) { if (o.material.map) o.material.map.dispose(); o.material.dispose(); } } catch (_) {} });
      scene.remove(v.cotas);
    }
    Object.keys(v.cache || {}).forEach(function (k) { var c = v.cache[k]; if (c && c.mat) { try { c.mat.dispose(); } catch (_) {} } });
    v.cotas = null; v.cotasObjs = []; v.cotasRegs = []; v.cache = {}; v.est = null; v.pv = null;
  }
  /* os buffers da vista, por parte mesclada — refeitos só quando mudou algo */
  function prepararVista(v) {
    var est = v.est;
    S.modelos.forEach(function (mo) {
      var ag = mo._agreg; if (!ag) return;
      ag.partes.forEach(function (parte) {
        if (!parte._id) parte._id = ++_parteSeq;
        var c = v.cache[parte._id];
        if (c && c.ver === est.ver && c.sig === ag.assinatura) return;
        var fx = parte.faixas, ocultos = {}, algumT = false, nPecas = 0;
        var cores = (c && c.cores && c.cores.length === parte.cores.length) ? c.cores : new Float32Array(parte.cores.length);
        for (var f = 0; f < fx.length; f++) {
          var faixa = fx[f], ref = faixa.ref;
          if (!ref) { ocultos[faixa.e] = 1; continue; }
          /* a peça em destaque (seleção, 4D, conflito) é desenhada por ela
             mesma — fora do índice da vista, como no da principal */
          if (!existeNaVista(ref, est) || _ehRealce(ref.material)) { ocultos[faixa.e] = 1; continue; }
          var cor = corNaVista(ref, est); nPecas++;
          if (cor[3] < 1) algumT = true;
          var ini = faixa.iniVert * 4, fim = ini + faixa.nVert * 4;
          for (var q = ini; q < fim; q += 4) { cores[q] = cor[0]; cores[q + 1] = cor[1]; cores[q + 2] = cor[2]; cores[q + 3] = cor[3]; }
        }
        var r = BimAgreg.indicesVisiveis(fx, parte.idxCheio, ocultos, c && c.idx);
        var idxAttr = (c && c.idxAttr && c.idxAttr.array === r.idx) ? c.idxAttr : new THREE.BufferAttribute(r.idx, 1);
        idxAttr.needsUpdate = true;
        var corAttr = (c && c.corAttr && c.corAttr.array === cores) ? c.corAttr : new THREE.BufferAttribute(cores, 4);
        corAttr.needsUpdate = true;
        /* material PRÓPRIO: a transparência do raio-X desta vista não pode
           mexer no material que a principal usa */
        var mat = c && c.mat;
        if (!mat) mat = parte.malha.material.clone();
        if (mat.transparent !== algumT) { mat.transparent = algumT; mat.depthWrite = !algumT; mat.needsUpdate = true; }
        v.cache[parte._id] = { ver: est.ver, sig: ag.assinatura, idx: r.idx, n: r.nIdx, idxAttr: idxAttr, cores: cores, corAttr: corAttr, mat: mat, nPecas: nPecas };
      });
    });
  }
  function matCorVista(cor) {
    var k = cor.join(',');
    if (!_matCorVista[k]) _matCorVista[k] = new THREE.MeshStandardMaterial({ color: new THREE.Color(cor[0], cor[1], cor[2]), transparent: cor[3] < 1, opacity: cor[3], depthWrite: cor[3] >= 1, metalness: .05, roughness: .85, side: THREE.DoubleSide });
    return _matCorVista[k];
  }
  /* troca, para o desenho DESTA vista, o que ela mostra diferente da cena */
  function trocasDaVista(v) {
    prepararVista(v);
    var est = v.est, t = { partes: [], vis: [], mats: [], lay: [], cotas: null };
    S.modelos.forEach(function (mo) {
      var ag = mo._agreg;
      if (ag) {
        ag.partes.forEach(function (parte) {
          var c = v.cache[parte._id]; if (!c) return;
          var g = parte.malha.geometry;
          t.partes.push([parte, g.index, g.attributes.color, g.drawRange.start, g.drawRange.count, parte.malha.material]);
          g.index = c.idxAttr; g.attributes.color = c.corAttr; g.drawRange.start = 0; g.drawRange.count = c.n;
          parte.malha.material = c.mat;
        });
        /* as peças em destaque (seleção, 4D, conflito) desenham por si e seguem
           a visibilidade DESTA vista: somem onde ela não as mostra e APARECEM
           onde ela mostra — ⚠ inclusive a peça que a {3D} esconde: o duplo
           clique numa aba de ponto de vista selecionava a peça e ela sumia da
           aba (o realce fica fora do índice e seguia a visibilidade da {3D}) */
        mo.grupo.children.forEach(function (m) {
          if (!m.isMesh || m.userData.expressID == null || !_ehRealce(m.material)) return;
          var q = existeNaVista(m, est), agora = m.visible !== false && m.layers.isEnabled(0);
          if (q && !agora) { t.lay.push([m, m.layers.mask, m.visible]); m.visible = true; m.layers.enable(0); }
          else if (!q && agora) { t.vis.push([m, true]); m.visible = false; }
        });
        return;
      }
      /* modelo fora da mescla (mescla desligada, ou suspensa pelo raio-X da
         principal): peça a peça — visibilidade e cor desta vista */
      mo.grupo.children.forEach(function (m) {
        if (!m.isMesh || m.userData.expressID == null) return;
        var q = existeNaVista(m, est);
        if (q !== (m.visible !== false)) { t.vis.push([m, m.visible]); m.visible = q; }
        if (q && !_ehRealce(m.material)) {
          var u = uidDe(m);
          if (est.cores[u] || est.rx) { t.mats.push([m, m.material]); m.material = matCorVista(corNaVista(m, est)); }
        }
      });
    });
    /* o contorno da seleção segue o que ESTA vista mostra */
    if (_selLn && S.selected && S.selected.userData && S.selected.userData.expressID != null) {
      var qs = existeNaVista(S.selected, est);
      if (qs !== (_selLn.visible !== false)) { t.vis.push([_selLn, _selLn.visible]); _selLn.visible = qs; }
    }
    /* as cotas: as da principal saem, as desta vista entram (no tamanho desta câmera) */
    medir.objs.forEach(function (o) { if (o.visible !== false) { t.vis.push([o, true]); o.visible = false; } });
    if (v.cotas) { v.cotas.visible = true; t.cotas = v.cotas; (v.cotasObjs || []).forEach(function (o) { rescaleObj(o, v.camera); }); }
    return t;
  }
  function desfazerTrocas(t) {
    t.partes.forEach(function (x) { var g = x[0].malha.geometry; g.index = x[1]; g.attributes.color = x[2]; g.drawRange.start = x[3]; g.drawRange.count = x[4]; x[0].malha.material = x[5]; });
    t.vis.forEach(function (x) { x[0].visible = x[1]; });
    t.mats.forEach(function (x) { x[0].material = x[1]; });
    t.lay.forEach(function (x) { x[0].layers.mask = x[1]; x[0].visible = x[2]; });
    if (t.cotas) t.cotas.visible = false;
  }
  /* aplica um ponto de vista NA vista `v` (e só nela) */
  function aplicarVistaNa(v, pv) {
    var BV = (typeof window !== 'undefined') ? window.BimVista : null;
    var r = BV ? BV.resolver(pv, S.elementos || []) : null;
    var res = { ok: true, naoLocalizadas: r ? r.naoLocalizadas : [], completa: pv.completa === true, globais: [] };
    limparEstadoVista(v);
    var est = { isolados: null, ocultos: null, cores: {}, rx: null, ver: ++_estSeq };
    if (r) {
      if (r.isolados.length) { est.isolados = {}; uidsDeChaves(r.isolados).forEach(function (u) { est.isolados[u] = 1; }); }
      else if (r.ocultos.length) { est.ocultos = {}; uidsDeChaves(r.ocultos).forEach(function (u) { est.ocultos[u] = 1; }); }
      (r.aparencias || []).forEach(function (a) {
        var cor = [+a.cor[0], +a.cor[1], +a.cor[2], a.alpha != null ? +a.alpha : 1];
        uidsDeChaves([a.chave]).forEach(function (u) { est.cores[u] = cor; });
      });
      if (pv.visibilidade && pv.visibilidade.raioX && r.raioXAlvo.length) { est.rx = {}; uidsDeChaves(r.raioXAlvo).forEach(function (u) { est.rx[u] = 1; }); }
    }
    var cs = pv.cortes || {};
    if ((cs.planta && cs.planta.on) || (cs.livre && cs.livre.on)) res.globais.push('corte');
    if (pv.estilo && pv.estilo.desenho) res.globais.push('estilo desenho');
    if (pv.cotaRede && pv.cotaRede.on) res.globais.push('cotas da rede');
    v.est = est; v.cache = {}; v.pv = pv;
    /* cotas: desenhadas no grupo DESTA vista (a principal fica com as dela) */
    v.cotas = new THREE.Group(); v.cotas.visible = false; scene.add(v.cotas);
    var g0 = medir.objs, r0 = medir.regs;
    medir.objs = []; medir.regs = []; S._medAlvo = v.cotas;
    try {
      (pv.medidas || []).forEach(function (m) {
        var P = (m.pts || []).map(function (p) { return new THREE.Vector3(+p[0], +p[1], +p[2]); });
        if (m.tipo === 'dist' && P.length === 2) desenharMedida(P[0], P[1], !!m.horizontal, m.eixo || '');
        else if (m.tipo === 'area' && P.length >= 3) desenharArea(P, !!m.horizontal);
        else if (m.tipo === 'ang' && P.length === 3) desenharAngulo(P[0], P[1], P[2]);
      });
    } finally {
      v.cotasObjs = medir.objs; v.cotasRegs = medir.regs;
      medir.objs = g0; medir.regs = r0; S._medAlvo = null;
      try { btnCotas(); } catch (_) {}
    }
    /* câmera desta vista */
    var c = pv.camera; v.tween = null;
    if (c && c.pos) {
      v.camera.position.set(c.pos[0], c.pos[1], c.pos[2]);
      if (c.up) v.camera.up.set(c.up[0], c.up[1], c.up[2]);
      if (c.fov && !v.orto.on) v.camera.fov = c.fov;
      v.camera.updateProjectionMatrix();
      if (c.alvo) { v.orbit.target.set(c.alvo[0], c.alvo[1], c.alvo[2]); v.camera.lookAt(c.alvo[0], c.alvo[1], c.alvo[2]); }
      v.orbit.update();
    }
    return res;
  }
  S._aplicarVistaNa = function (id, pv) { var v = S.vistas[id]; if (!v || !pv) return { ok: false, erro: 'vista não encontrada' }; try { return aplicarVistaNa(v, pv); } catch (e) { return { ok: false, erro: String(e && e.message || e) }; } };
  S._vistaTemEstado = function (id) { var v = S.vistas[id]; return !!(v && v.est); };
  /* só leitura (prova): o que a vista com estado próprio DESENHA — peças no índice dela */
  S._vistaInfo = function (id) {
    var v = S.vistas[id]; if (!v) return null;
    var n = 0, tri = 0; Object.keys(v.cache || {}).forEach(function (k) { var c = v.cache[k]; n += c.nPecas || 0; tri += (c.n || 0) / 3; });
    var realce = 0;
    if (v.est) S.modelos.forEach(function (mo) { mo.grupo.children.forEach(function (m) { if (m.isMesh && m.userData.expressID != null && _ehRealce(m.material) && existeNaVista(m, v.est)) realce++; }); });
    n += realce;
    return { estado: !!v.est, pecas: n, triangulos: tri, desenhados: v.renderer ? v.renderer.info.render.triangles : 0, cores: v.est ? Object.keys(v.est.cores).length : 0, raioX: !!(v.est && v.est.rx), cotas: (v.cotasObjs || []).length,
      camera: [v.camera.position.x, v.camera.position.y, v.camera.position.z] };
  };
  /* o que a vista MOSTRA, para gravar como ponto de vista ("Salvar esta vista"
     com ela ativa): o ponto de vista dela com a câmera de agora; vista sem
     estado próprio = o estado da cena com a câmera dela */
  S._estadoDaVista = function (id) {
    var v = S.vistas[id]; if (!v) return null;
    var base = v.pv ? JSON.parse(JSON.stringify(v.pv)) : estadoVista();
    if (!base) return null;
    delete base.id; delete base.nome; delete base.pasta; delete base.comentario; delete base.autor; delete base.thumb;
    base.camera = { pos: [v.camera.position.x, v.camera.position.y, v.camera.position.z], alvo: [v.orbit.target.x, v.orbit.target.y, v.orbit.target.z], up: [v.camera.up.x, v.camera.up.y, v.camera.up.z], fov: v.camera.fov, orto: false };
    if (v.pv) base.medidas = (v.cotasRegs || []).slice();
    return base;
  };
  /* a visibilidade GLOBAL (da cena) mudou — a tela decide se leva a pessoa à
     aba {3D}: quem está olhando uma vista congelada não veria o efeito */
  var _visSigGlobal = null, _visTick = 0;
  S._tickExtra.push(function () {
    if (++_visTick % 12) return;
    var sig = 0;
    S.modelos.forEach(function (mo) { sig = (sig * 31 + (mo.grupo.visible === false ? 1 : 2)) | 0; mo.grupo.children.forEach(function (m) { sig = (sig * 33 + (m.visible === false ? 1 : 2)) | 0; }); });
    if (_visSigGlobal !== null && sig !== _visSigGlobal) { var o = (S && S.opts) || opts; if (o.onVisibilidadeGlobal) { try { o.onVisibilidadeGlobal(); } catch (_) {} } }
    _visSigGlobal = sig;
  });
  /* leva a vista para outro lugar (outra janela, outra casa depois de re-render):
     o renderer é refeito no container novo — nada de adotar canvas WebGL
     entre documentos; câmera, alvo, ortogonal e caixa de corte vão junto */
  S._moverVista = function (id, cont) {
    var v = S.vistas[id]; if (!v || !cont) return false;
    v.alvo = v.orbit ? v.orbit.target.clone() : v.alvo;
    desmontarVista(v);
    montarVista(v, cont);
    return true;
  };
  S._redimVistas = function () { Object.keys(S.vistas).forEach(function (k) { redimVista(S.vistas[k]); }); };
  /* sonda para as e2e: quantas peças o raio da vista acerta num ponto da tela */
  S._raioVista = function (id, x, y) {
    var v = S.vistas[id]; if (!v || !v.renderer) return null;
    var cv = v.renderer.domElement, r = cv.getBoundingClientRect(), rc = new THREE.Raycaster(), m = new THREE.Vector2();
    m.x = ((x - r.left) / r.width) * 2 - 1; m.y = -((y - r.top) / r.height) * 2 + 1;
    v.camera.updateMatrixWorld();
    rc.layers.mask = ray.layers.mask;
    rc.setFromCamera(m, v.camera);
    var h = rc.intersectObjects(modelRoot.children, true);
    return { n: h.length, r: [r.left, r.top, r.width, r.height], cam: v.camera.position.toArray(), m: [m.x, m.y], fov: v.camera.fov, asp: v.camera.aspect };
  };
  S._ortoVista = function (id, on) { var v = S.vistas[id]; if (!v || !v.orbit) return false; aplicarOrto(v.camera, v.orbit, !!on, v.orto); return v.orto.on; };


  /* =================================================================
   * VER A PEÇA NO MODELO — a desambiguação que o modelo já tem.
   *
   * ⚠ POR QUE ISTO EXISTE (pedido de 09/09/2026): quando o casador fica em
   *   dúvida entre dois insumos, quem tira a dúvida é a OBRA. "Vincular o
   *   insumo à volumetria pra identificar na dúvida — aí não tem erro."
   *   A lista dizia "56 pç · DN 50" e não havia como saber QUAIS 56 peças
   *   eram; a resposta estava na tela ao lado, no 3D, sem caminho até ela.
   *
   * ⚠ O AABB É LOCAL AO `modelRoot`, NÃO DO MUNDO. No modo imersivo o
   *   `modelRoot` ganha posição e escala (ele reposiciona o modelo na sala),
   *   então enquadrar a caixa crua levaria a câmera para o lugar errado — e o
   *   erro só apareceria em imersivo, que é onde ninguém testa. Por isso a
   *   matriz entra na conta.
   * ================================================================= */
  var _lupa3d = null;
  function limparLupa3d() {
    if (!_lupa3d) return;
    scene.remove(_lupa3d);
    _lupa3d.traverse(function (o) { if (o.geometry && o.geometry.dispose) o.geometry.dispose(); });
    _lupa3d = null;
  }
  S._limparLupa3d = limparLupa3d;
  function verNo3D(uids) {
    limparLupa3d();
    if (!uids || !uids.length) return 0;
    var porUid = {};
    (S.elementos || []).forEach(function (e) { porUid[e.uid] = e; });
    modelRoot.updateMatrixWorld(true);
    var uniao = new THREE.Box3(), n = 0, grupo = new THREE.Group();
    for (var i = 0; i < uids.length; i++) {
      var e2 = porUid[uids[i]];
      if (!e2 || !e2.aabb) continue;
      var b = new THREE.Box3(
        new THREE.Vector3(e2.aabb.min[0], e2.aabb.min[1], e2.aabb.min[2]),
        new THREE.Vector3(e2.aabb.max[0], e2.aabb.max[1], e2.aabb.max[2]));
      b.applyMatrix4(modelRoot.matrixWorld);
      if (b.isEmpty()) continue;
      uniao.union(b); n++;
      /* ⚠ TETO DE 80 CONTORNOS. Uma família de tubo tem 400 peças e desenhar
         todas custa um engasgo visível sem dizer mais nada: a moldura da união
         já mostra ONDE a peça mora, e o número está escrito na linha. */
      if (grupo.children.length < 80) {
        var hl = new THREE.Box3Helper(b, 0x16a34a);
        if (hl.material) { hl.material.depthTest = false; hl.material.transparent = true; hl.material.opacity = .95; }
        hl.renderOrder = 1001; hl.raycast = function () {};
        grupo.add(hl);
      }
    }
    if (!n) return 0;
    grupo.raycast = function () {};
    scene.add(grupo); _lupa3d = grupo;
    if (S._enquadrarObj && !fly.on && !xr.on) S._enquadrarObj(uniao, 2.4);
    return n;
  }
  S._verNo3D = verNo3D;
  // o contorno é um overlay independente na cena (depthTest:false): compõe a visibilidade do elemento
  // selecionado a cada frame (some quando ele fica invisível no 4D, no toggle de modelo, isolar etc.) — regra de ouro
  S._tickExtra.push(function () { if (_selLn) _selLn.visible = !!(S.selected && cadeiaVisivel(S.selected)); });

  // ---- toolbar ----
  bar.addEventListener('click', function (e) {
    var b = e.target.closest('[data-b]'); if (!b) return; var k = b.getAttribute('data-b');
    if (k === 'abrir') bar.querySelector('[data-b="file"]').click();
    else if (k === 'exemplo') carregarExemplo();
    else if (k === 'limpar') limparTudo();
    else if (k === 'tema') trocarTema();
    else if (k === 'ultra') setUltra(!S.ultra);
    // Órbita/Voo SEMPRE encerram as ferramentas (exclusividade nos 2 sentidos); Medir pode
    // coexistir com Planta/Corte (medir na planta e na face do corte é o uso pedido)
    else if (k === 'orbita') { sairFerramentas(); setMode(false); }
    else if (k === 'voo') { sairFerramentas(); setMode(true); }
    else if (k === 'medir') setMedir(!medir.on);
    else if (k === 'area') setArea(!area.on);
    else if (k === 'angulo') setAng(!ang.on);
    else if (k === 'snap') toggleSnapPanel();
    else if (k === 'planta') setPlanta(!planta.on);
    else if (k === 'corte') setCorteL(!corteL.on);
    else if (k === 'p3d') toggleP3dPanel();
    else if (k === 'editar') setEdit(!edit.on);
    else if (k === 'pav') togglePavPanel();
    else if (k === 'vis') toggleVisPanel();
    else if (k === 'xr') toggleXRPanel();
    else if (k === 'sistema') { if (sisColor.on && sisPanel.style.display === 'none') { pintarSisPanel(); sisPanel.style.display = 'flex'; fecharPaineis(sisPanel); } else setSisColor(!sisColor.on); } // modo ligado + legenda fechada por outro painel → reabre a legenda (não desliga as cores)
    else if (k === 'blocok') toggleBlocokPanel();
    else if (k === 'foto') tirarFoto();
    else if (k === 'limpar-medidas') { if (S._limparMedidas) S._limparMedidas(); }
    else if (k === 'req-bim') { if (S._reqAbrir) S._reqAbrir(); }
    else if (k === 'cota') { setCota(!cota.on, 'clicado'); }
    else if (k === 'cota-iguais') {
      if (!cota.chave) { UI0('Toque primeiro num tubo — aí eu cotô todos os iguais a ele.', 'info'); }
      else setCota(true, 'iguais');
    }
    else if (k === 'cota-todas') { setCota(true, 'todas'); }
    else if (k === 'cota-numerar') {
      var pacN = numerarRede();
      if (pacN) {
        var r = pacN.resumo;
        cota.indice = null;                         // o rotulo tem de renascer com o numero
        setCota(true, 'todas');
        UI0(r.numerados + ' tubos numerados em ' + r.ramais + ' ramal(is) · ' + fmtDist(r.metrosNumerados) +
            (r.avulsos ? ' · ' + r.avulsos + ' avulso(s) sem ligacao no IFC' : ''), 'ok');
      }
    }
    else if (k === 'cota-planilha') {
      var pacP = (S._numeracao && S._numeracao()) || numerarRede();
      if (pacP) {
        /* ⚠ A ABA "Compra (agrupado)" SAI DO MESMO MOTOR DA TELA. `reqLevantar`
           é o que a requisição usa: ele já filtra fase (não se compra material
           para o que vai ser demolido), já lê a bitola da geometria e já
           propaga a bitola do tubo para a conexão pela rede. Recalcular aqui
           daria duas contas para a mesma pergunta, e elas divergiriam sem
           avisar. Se falhar, a aba sai vazia dizendo o que fazer — a planilha
           dos tubos não pode deixar de sair por causa dela. */
        try {
          var levC = reqLevantar();
          if (levC) { pacP.compra = levC.pecas; pacP.compraResumo = levC.resumo; }
        } catch (eC) { pacP.compra = null; }
        if (typeof BimTuboXLS === 'undefined') UI0('Gerador de planilha nao carregado.', 'erro');
        else BimTuboXLS.gerar(pacP, {
          nome: 'Tubos por ramal',
          ok: function () { UI0('Planilha gerada: ' + pacP.linhas.length + ' tubos.', 'ok'); },
          erro: function (e) { UI0('Nao consegui gerar a planilha: ' + (e && e.message || e), 'erro'); }
        });
      }
    }
    else if (k === 'cota-limpar') { cota.fixados = {}; cota.chave = null; cotaLimpar(); setCota(false); }
    else if (k === 'fit') { if (planta.on) enquadrarTopo(); else if (S._enquadrarObj && !fly.on && !xr.on) S._enquadrarObj(new THREE.Box3().setFromObject(modelRoot), 1.5); else enquadrar(); } // na planta re-centra a vista de topo (não sai); no 3D enquadra suave (cinematográfico)
  });

  /* ------------------------------------------------------------------
   * PONTES PARA A FITA.
   * A ribbon chama estas quatro por nome (js/gestao.js, _bimCascaAcoes).
   * Elas existiam aqui dentro há versões, mas NÃO estavam na API pública:
   * o registro devolvia false e o botão respondia "ainda não está
   * disponível nesta versão" — Voo, Enquadrar tudo, Visibilidade e
   * Pavimentos, todos mudos na fita, todos funcionando no viewer.
   * ------------------------------------------------------------------ */
  S._setVoo = function (on) { sairFerramentas(); setMode(on == null ? !fly.on : !!on); };
  S._fit = function () {
    if (planta.on) enquadrarTopo();
    else if (S._enquadrarObj && !fly.on && !xr.on) S._enquadrarObj(new THREE.Box3().setFromObject(modelRoot), 1.5);
    else enquadrar();
  };
  S._togglePav = togglePavPanel;
  S._toggleVis = toggleVisPanel;
  // MATRIZ MODOS×SAÍDAS (manter em dia ao criar modo novo — regra aprendida no gate v1.1.64):
  //                    medir/area/ang  planta  corteL  ctec(desenho)  isolamento(pav/vis)
  // botão Órbita/Voo    sai            sai     sai     cancela        fica (só visibilidade)
  // Esc                 sai            sai     sai     cancela 1º     fica
  // focarClash          sai            sai     sai     cancela        clash força visible=true nos dele
  // carregarIFC         —              sai     sai     —              restaura (modelo novo nasce visível)
  // removerModelo       limpa          re-ancora re-ancora cancela    restaura se isolado
  // limparTudo          limpa          sai     sai     cancela        restaura
  // fit (Enquadrar)     —              sai     —       —              fica
  // entrar em planta    —              ·       sai     —              fica (planta do pavimento USA isolamento)
  // entrar em corteL    —              sai     ·       cancela-se-via-planta  fica
  // medir/area/ang      exclusivos ENTRE SI    —       —              coexistem com planta/corte
  // aplicarEstado(4D)/mostrarTudo (externos)                          limpam o marcador de isolamento
  // Órbita/Voo SEMPRE encerram o editor INTEIRO (setEdit(false) já limpa a cadeia via editTirarProv);
  // o "Esc encerra só o traço" vive APENAS no handler de Escape — aqui um return deixaria o editor
  // armado com o voo ligado (clique em pointerlock criaria parede acidental persistida)
  function sairFerramentas() { if (S._fecharCtecModal && ctecModal.style.display === 'flex') S._fecharCtecModal(); ctecCancelar(); if (medir.on) setMedir(false); if (area.on) setArea(false); if (ang.on) setAng(false); if (planta.on) setPlanta(false); if (corteL.on) setCorteL(false); if (S.edit && S.edit.on && S._setEdit) S._setEdit(false); if (cota.on) setCota(false); if (S.xr && S.xr.on && S._sairImersivo) S._sairImersivo(); } // fecha o modal do resultado + cobre o estágio "config aberta"
  bar.querySelector('[data-b="file"]').addEventListener('change', function (e) {
    var fs2 = Array.prototype.slice.call(e.target.files || []);
    /* ⚠ A VALIDAÇÃO VIVE AQUI, não no `accept`. Com o filtro do seletor
       desligado no celular (ver aceitaIFC), é este teste que impede mandar uma
       foto para o interpretador de IFC. E ele fazia falta mesmo antes: o
       arrastar-e-soltar filtrava por `.ifc`, o seletor não filtrava nada —
       bastava o cliente trocar o filtro para "Todos os arquivos", coisa que
       todo diálogo do Windows oferece. */
    receberArquivos(fs2);
    e.target.value = '';
  });
  /* ⚠ O .skp NÃO É ARQUIVO ERRADO, É PEDIDO DE ORIENTAÇÃO. O formato do
     SketchUp é fechado e nenhum navegador lê; mandá-lo ao web-ifc daria um
     erro de parser incompreensível, e o toast "não é IFC" fazia o cliente
     desistir achando que o BIM não trabalha com SketchUp — quando o SketchUp
     Pro exporta IFC nativamente (IFC 4 por padrão; IFC 2x3 só no Windows). O
     que ele precisa é do caminho, na cara, com botão para voltar ao seletor.
     Clique programático em input[type=file] só vale dentro de um gesto do
     usuário: o clique no botão do modal é um, por isso o `.click()` fica no
     onClick e não num setTimeout. */
  function orientarSketchUp(nomes) {
    nomes = nomes || [];
    var nm = nomes.slice(0, 3).map(function (n) { return '“' + n + '”'; }).join(', ') + (nomes.length > 3 ? '…' : '');
    var titulo = 'Arquivo do SketchUp (.skp)';
    var aviso = (nomes.length === 1 ? 'O arquivo ' + nm + ' é' : 'Os arquivos ' + nm + ' são') +
      ' do SketchUp. O formato .skp é fechado e nenhum navegador consegue lê-lo; o OrçaPRO abre o IFC que o próprio SketchUp exporta — com a geometria e o tipo de cada elemento.';
    var passos = [
      'Abra o modelo no SketchUp Pro (ou Studio).',
      'Menu Arquivo → Exportar → Modelo 3D…',
      'Em “Salvar como tipo”, escolha IFC (*.ifc). O IFC 4 é o padrão; no Windows também existe o IFC 2x3 — os dois abrem aqui.',
      'Volte ao OrçaPRO e abra o .ifc exportado: botão Abrir IFC, ou arraste para o visualizador.'
    ];
    var dica = 'Dica: classifique os componentes com tipos IFC no SketchUp (painel Classificações → “Tipo” em Informações da entidade) antes de exportar; sem isso parede, laje e pilar podem chegar como elementos genéricos e o QTO não sabe separá-los. Se a sua versão do SketchUp não exportar IFC, peça o .ifc a quem fez o projeto.';
    if (typeof UI === 'undefined' || !UI.modal) {
      try { alert(titulo + '\n\n' + aviso + '\n\n' + passos.map(function (p, i) { return (i + 1) + '. ' + p; }).join('\n') + '\n\n' + dica); } catch (_) {}
      return;
    }
    var corpo = '<p style="margin:0 0 10px">' + esc(aviso) + '</p>' +
      '<ol style="margin:0 0 10px 18px;padding:0;line-height:1.5">' + passos.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('') + '</ol>' +
      '<p class="muted" style="margin:0;font-size:12px">' + esc(dica) + '</p>';
    UI.modal(titulo, corpo, [
      { texto: 'Escolher o IFC exportado', classe: 'primary', onClick: function () { UI.fecharModal(); try { bar.querySelector('[data-b="file"]').click(); } catch (_) {} } },
      { texto: 'Fechar', classe: 'ghost', onClick: function () { UI.fecharModal(); } }
    ]);
  }
  /* funil ÚNICO do seletor e do arrastar-e-soltar (ver classificarEntradaBim) */
  function receberArquivos(lista) {
    var cls = classificarEntradaBim(lista);
    cls.ifc.forEach(function (f) { abrirArquivo(f); });
    if (cls.skp.length) orientarSketchUp(cls.skp.map(function (f) { return f.name; }));
    /* um arquivo da obra por vez: dois .zip seriam dois modelos e dois resumos
       empilhados; o segundo é dito, não engolido */
    if (cls.zip.length) {
      var oZ = (S && S.opts) || opts;
      if (oZ && typeof oZ.onArquivoObra === 'function') {
        oZ.onArquivoObra(cls.zip[0]);
        if (cls.zip.length > 1) { try { UI.toast('Abri só o primeiro .zip (' + cls.zip[0].name + '). Mande um arquivo da obra por vez.', 'aviso'); } catch (_) {} }
      } else cls.outros = cls.outros.concat(cls.zip);
    }
    var maus = cls.outros;
    if (maus.length) {
      /* diz o nome do arquivo: "não é IFC" sem dizer qual, com vários
         selecionados, não ajuda ninguém a achar o errado */
      var nm = maus.map(function (f) { return f.name; }).slice(0, 3).join(', ');
      var msg = maus.length === 1
        ? 'O arquivo “' + nm + '” não é um modelo IFC. O BIM abre arquivos terminados em .ifc.'
        : maus.length + ' arquivos não são IFC (' + nm + (maus.length > 3 ? '…' : '') + '). O BIM abre arquivos terminados em .ifc.';
      try { if (typeof UI !== 'undefined' && UI.toast) UI.toast(msg, 'erro'); else alert(msg); } catch (_) {}
    }
  }
  function onDragOver(e) { e.preventDefault(); }
  /* ⚠ o drop passa pelo MESMO funil do seletor. Ele descartava em silêncio o
     que não fosse .ifc — soltar um .skp "não fazia nada", que é o pior recado. */
  function onDrop(e) { e.preventDefault(); receberArquivos(Array.prototype.slice.call(e.dataTransfer.files || [])); }
  host.addEventListener('dragover', onDragOver); host.addEventListener('drop', onDrop);
  S._onDragOver = onDragOver; S._onDrop = onDrop; // guardados p/ re-registrar no host novo (re-home)
  function setUltra(on) {
    S.ultra = !!on;
    renderer.setPixelRatio(S.ultra ? Math.min(window.devicePixelRatio || 1, 2.5) : Math.min(window.devicePixelRatio || 1, 2));
    renderer.toneMappingExposure = S.ultra ? 1.22 : 1.12;
    dir.intensity = S.ultra ? 1.25 : 1.1; fill.intensity = S.ultra ? 0.5 : 0.35;
    var bu = bar.querySelector('[data-b="ultra"]'); if (bu) { bu.style.background = S.ultra ? '#7c3aed' : ''; bu.style.color = S.ultra ? '#fff' : ''; }
    resize();
  }
  S._setUltra = setUltra;

  function propsDe(mid, expressID, tipoCache) {
    var moS = modeloDe(mid);
    /* ⚠ B1: modelo restaurado do cache tambem nao existe no wasm. Ele NAO cai
       no ramo sintetico (nao foi criado aqui: veio de IFC e tem GlobalId de
       verdade), e nao pode cair no ramo do wasm. Tudo que a tela mostra ja
       esta no cache — o unico que falta e a lista completa de propriedades,
       que o `propsCompletas` trata a parte e declara. */
    if (moS && moS.doCache) {
      var elC = null;
      for (var q4 = 0; q4 < moS.elementos.length; q4++) if (moS.elementos[q4].id === expressID) { elC = moS.elementos[q4]; break; }
      var cbC = (moS.carimbos && moS.carimbos[expressID]) || {};
      var qC = (moS.qto && moS.qto[expressID]) || null;
      var famC = (moS.familias && moS.familias[expressID]) || null;
      return { id: expressID, mid: mid, uid: mid + ':' + expressID,
        /* o nome do Revit primeiro; o rotulo da disciplina so se ele faltar */
        nome: (elC && (elC.nomeIfc || elC.nome)) || '—', tipo: (elC && elC.tipo) || tipoCache || '',
        globalId: (elC && elC.globalId) || '', tag: (elC && elC.tag) || '',
        familia: famC ? famC.familia : ((elC && elC.familia) || ''),
        etapa: cbC.etapa || (elC && elC.etapa) || '', codOrc: cbC.codOrc || (elC && elC.codOrc) || '', tarefa: cbC.tarefa || (elC && elC.tarefa) || '',
        fase: cbC.fase || (elC && elC.fase) || '', qto: qC,
        area: qC && qC.area, comprimento: qC && qC.comprimento };
    }
    if (moS && moS.sintetico) { // sintético não existe no wasm (GetLine com mid string sondaria o modelo 0 REAL)
      var elS = null; for (var q3 = 0; q3 < moS.elementos.length; q3++) if (moS.elementos[q3].id === expressID) { elS = moS.elementos[q3]; break; }
      var qS = (moS.qto && moS.qto[expressID]) || {};
      // v1.1.82: mesmo CONTRATO do ramo IFC (uid/mid/tipo real/qto) — Propriedades/Salvar família
      // funcionam também pro que foi criado no OrçaPRO (editor ✏️ e 2D→3D)
      return { id: expressID, mid: mid, uid: mid + ':' + expressID, nome: (elS && elS.nome) || 'Parede',
        tipo: (elS && elS.tipo) || 'IFCWALL', globalId: moS.editor ? 'criado no OrçaPRO' : '2D→3D', tag: '',
        familia: (elS && elS.nome) || '', etapa: '', codOrc: '', fase: '',
        qto: qS, area: qS.area, comprimento: qS.comprimento };
    }
    try {
      var line = S.api.GetLine(mid, expressID, true);
      var nome = (line.Name && line.Name.value) || '—';
      var tipo = tipoCache || nomeTipo(S.api.GetLineType(mid, expressID));
      var gid = (line.GlobalId && line.GlobalId.value) || '—';
      var moP = modeloDe(mid);
      var cb = (moP && moP.carimbos && moP.carimbos[expressID]) || {};
      var famP = (moP && moP.familias && moP.familias[expressID]) || null;
      var qtoP = (moP && moP.qto && moP.qto[expressID]) || null;
      return { id: expressID, mid: mid, uid: mid + ':' + expressID, nome: nome, tipo: tipo, globalId: gid, tag: (line.Tag && line.Tag.value) || '',
        familia: famP ? famP.familia : ((line.ObjectType && line.ObjectType.value) || ''),
        etapa: cb.etapa || '', codOrc: cb.codOrc || '', fase: cb.fase || '', tarefa: cb.tarefa || '', qto: qtoP };
    } catch (e) { return { id: expressID, mid: mid, uid: mid + ':' + expressID, nome: '—', tipo: tipoCache || '', globalId: '', familia: '', etapa: '', codOrc: '', fase: '', qto: null }; }
  }
  function nomeTipo(num) { var raw = ''; try { if (S.api.GetNameFromTypeCode) raw = S.api.GetNameFromTypeCode(num); } catch (_) {} return raw || ('IFC#' + num); }

  // grid + sombra de contato acompanham a pegada atual de modelRoot (chamado por enquadrar E por removerModelo, sem mexer na câmera)
  function reposicionarChao() {
    var box = new THREE.Box3().setFromObject(modelRoot); if (box.isEmpty()) return;
    var size = box.getSize(new THREE.Vector3()), center = box.getCenter(new THREE.Vector3());
    grid.position.y = box.min.y;
    var fp = Math.max(size.x, size.z) * 1.3 || 20; // folga de 30% na pegada
    _chao.scale.set(fp, fp, 1); _chao.position.set(center.x, box.min.y + 0.01, center.z);
  }
  S._reposicionarChao = reposicionarChao;
  function enquadrar() {
    if (S._cancelTween) S._cancelTween(); // fit instantâneo cancela voo pendente (senão o tween sobrescreve)
    var box = new THREE.Box3().setFromObject(modelRoot); if (box.isEmpty()) return;
    var size = box.getSize(new THREE.Vector3()), center = box.getCenter(new THREE.Vector3());
    var maxDim = Math.max(size.x, size.y, size.z) || 10, dist = maxDim * 1.6;
    camera.position.set(center.x + dist * .7, center.y + dist * .6, center.z + dist * .7);
    camera.near = maxDim / 1000; camera.far = maxDim * 100; camera.updateProjectionMatrix();
    orbit.target.copy(center); orbit.update();
    fly.yaw = Math.atan2(camera.position.x - center.x, camera.position.z - center.z); fly.pitch = -0.35;
    reposicionarChao();
  }
  S._enquadrar = enquadrar;

  // ============================================================
  // Dica flutuante (usada pela trena e pela planta baixa)
  // ============================================================
  var hint = document.createElement('div');
  hint.setAttribute('data-bim', 'hint'); // âncora estável p/ testes/depuração
  /* ⚠ width:max-content: com left:50% e sem largura, o encolher-para-caber
     do navegador limita a caixa à METADE da tela. No celular (390 px) a dica
     da trena saía com 195 px e quatro linhas no meio do modelo. */
  hint.style.cssText = 'position:absolute;left:50%;top:52px;transform:translateX(-50%);z-index:4;display:none;pointer-events:none;background:rgba(34,197,94,.94);color:#04240f;font-weight:600;font-size:12.5px;padding:7px 15px;border-radius:20px;box-shadow:0 6px 16px rgba(0,0,0,.35);width:max-content;max-width:90%;box-sizing:border-box;text-align:center';
  host.appendChild(hint);
  S.hint = hint; // guardado p/ re-parentar no re-home (senão some ao revisitar a aba)
  /* ⚠ O BALÃO MOSTRAVA O CÓDIGO DO ÍCONE, NÃO O ÍCONE.
   * As mensagens são montadas com `Icones.get(...)`, que devolve MARCAÇÃO SVG
   * como texto. Com `textContent` o navegador escapa tudo, e o usuário lia
   * `<svg class="ic-svg" data-ic="medir" viewBox="0 0 24 24" ...` na frente da
   * dica — em toda ferramenta de medição.
   * O conserto NÃO é trocar por `innerHTML` e pronto: parte do texto que passa
   * por aqui vem de nome de elemento do IFC, que é conteúdo do ARQUIVO do
   * cliente. Injetar isso como HTML seria abrir a tela para o que vier no
   * modelo. Então: o SVG do começo (que é nosso, do `Icones`) entra como
   * marcação; TODO o resto entra como texto, escapado. */
  /* O balão de dica recebe texto COM ícone do próprio app no meio (`Icones.get`
   * devolve um <svg>). Jogar tudo por `innerHTML` seria abrir a tarja para
   * qualquer coisa que um dia chegue aqui vinda de um modelo; jogar tudo por
   * `textContent` é o que fazia o cliente ver `<svg viewBox=...>` escrito na
   * tela — foi o print que abriu esta versão.
   *
   * ⚠ E O CONSERTO PRECISA VALER PARA TODOS OS ÍCONES, não só o primeiro. A
   *   primeira tentativa ancorava em `^` e só desescapava o ícone do começo:
   *   passou no teste (que usava uma mensagem de um ícone só) e deixou o defeito
   *   de pé nas dezenas de mensagens reais que têm ícone NO MEIO da frase —
   *   "Elemento oculto. <svg…> Restaurar tudo…". Meio conserto num defeito
   *   visível é pior que nenhum: dá o assunto por encerrado.
   *
   * A varredura abaixo alterna: texto vira nó de texto, cada <svg>…</svg> vira
   * marcação, quantos forem, em qualquer posição. */
  S._hint = function (msg) {
    if (!msg) { hint.style.display = 'none'; return; }
    while (hint.firstChild) hint.removeChild(hint.firstChild);
    var s = String(msg), ini = 0, m;
    /* ⚠ REGENERA O ÍCONE PELO NOME, NUNCA RECOLA O TRECHO CASADO.
     * A regex é a mesma de `UI._rotuloHtml` (js/ui.js), de propósito: casar o
     * ícone e devolver `m[0]` por innerHTML seria o buraco que aquele arquivo
     * já descreve — basta o nome do pavimento trazer `<svg class="ic-svg">
     * <animate onbegin="…">` e o script roda na origem do app, com acesso a
     * todo o `raerp:*`. Aqui o pior que pode acontecer é sair um ícone da
     * nossa própria biblioteca. */
    var re = /<svg class="ic-svg" data-ic="([A-Za-z0-9_-]+)"[^>]*width="(\d+)"[^>]*>[\s\S]*?<\/svg>/g;
    while ((m = re.exec(s))) {
      if (m.index > ini) hint.appendChild(document.createTextNode(s.slice(ini, m.index)));
      if (typeof Icones !== 'undefined' && Icones.tem && Icones.tem(m[1])) {
        var sp = document.createElement('span');
        sp.style.cssText = 'display:inline-flex;vertical-align:-2px;margin:0 4px 0 0';
        sp.innerHTML = Icones.get(m[1], Number(m[2]) || 15);   // gerado por nós, agora
        hint.appendChild(sp);
      }
      ini = m.index + m[0].length;
    }
    if (ini < s.length) hint.appendChild(document.createTextNode(s.slice(ini)));
    hint.style.display = 'block';
  };

  // ============================================================
  // TRENA (medição) — clique em 2 pontos do modelo e mede a distância real
  // ============================================================
  /* `regs` é o que o ponto de vista guarda das cotas: uma linha por medida
     PRONTA, com os pontos (não o número — ver `BimVista.medida`). `objs` são
     os desenhos; `regs` é o que dá para redesenhar noutra hora. */
  var medir = { on: false, pts: [], objs: [], down: null, prov: null, regs: [], pilha: [] };
  S.medir = medir;
  /* ⚠ FRASE DE DEDO NO DEDO. As dicas da trena diziam "clique" e "Esc sai"
     também no celular do link — onde não há clique nem Esc, e a pessoa
     ficava sem saber como sair. O tipo vem do último toque no 3D; antes do
     primeiro, o visitante (link no celular) e a tela de toque falam "toque". */
  var _ptrTipo = '';
  function ehToque() {
    if (_ptrTipo) return _ptrTipo === 'touch';
    return visitante || !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches);
  }
  function trenaTxt(k) {
    var d = ehToque(), ic = (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '');
    if (k === 'on') return ic + (d ? ' Trena: toque em 2 pontos do modelo. Segure o dedo para mirar com a lupa.' : ' Trena: clique em 2 pontos do modelo pra medir. Esc sai.');
    if (k === 'planta') return ic + (d ? ' Trena na planta: toque em 2 pontos — a cota é a distância horizontal.' : ' Trena na planta: clique em 2 pontos — a cota é a distância horizontal.');
    if (k === '2o') return ic + (d ? ' Agora toque no 2º ponto (segure o dedo para a lupa).' : ' Agora clique no 2º ponto.');
    if (k === 'ok') return ic + (d ? ' Medido! Toque 2 pontos para medir de novo.' : ' Medido! Clique 2 pontos pra medir de novo, ou Esc pra sair.');
    if (k === 'perto') return ic + (d ? ' Pontos muito próximos — toque 2 pontos distintos.' : ' Pontos muito próximos — clique 2 pontos distintos.');
    return '';
  }

  // A geometria do web-ifc já vem NORMALIZADA em METROS (o próprio web-ifc aplica o fator da
  // unidade do arquivo). Logo, a distância entre 2 pontos do mundo JÁ é em metros — NÃO se aplica
  // o fator de unidade aqui (isso é só p/ os BaseQuantities do QTO, que vêm em unidade nativa).
  function fmtDist(m) { return m >= 1 ? m.toFixed(2).replace('.', ',') + ' m' : Math.round(m * 100) + ' cm'; }
  function labelSprite(txt, borda) {
    var cv = document.createElement('canvas'), fs = 46, pad = 14;
    var g = cv.getContext('2d'); g.font = 'bold ' + fs + 'px Arial';
    cv.width = Math.ceil(g.measureText(txt).width) + pad * 2; cv.height = fs + pad * 2;
    g = cv.getContext('2d'); g.font = 'bold ' + fs + 'px Arial';
    g.fillStyle = 'rgba(11,26,43,.94)'; g.fillRect(0, 0, cv.width, cv.height);
    g.strokeStyle = borda || '#22c55e'; g.lineWidth = borda ? 7 : 4; g.strokeRect(3, 3, cv.width - 6, cv.height - 6);
    g.fillStyle = '#c7f9d8'; g.textBaseline = 'middle'; g.textAlign = 'left'; g.fillText(txt, pad, cv.height / 2 + 2);
    var tex = new THREE.CanvasTexture(cv); tex.minFilter = THREE.LinearFilter;
    var sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true }));
    sp.userData._ratio = cv.width / cv.height; sp.userData._sc = 0.028; sp.renderOrder = 999; return sp;
  }
  function pontoMarca(p) {
    var s = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 16), new THREE.MeshBasicMaterial({ color: 0x22c55e, depthTest: false }));
    s.position.copy(p); s.userData._sc = 0.006; s.renderOrder = 998; return s;
  }
  // marcas e etiquetas ficam do MESMO tamanho na tela em qualquer zoom/escala de modelo:
  // reescala por distância da câmera a cada frame (vãos pequenos — porta, parede — continuam legíveis)
  function rescaleObj(o, cam) {
    var sc = o.userData && o.userData._sc; if (!sc) return;
    var d = (cam || camera).position.distanceTo(o.position) * sc;
    if (o.userData._ratio) o.scale.set(d * o.userData._ratio, d, 1); else o.scale.setScalar(d);
  }
  S._tickExtra.push(function () { for (var i = 0; i < medir.objs.length; i++) rescaleObj(medir.objs[i]); });

  /* =====================================================================
   * COTAR REDE — o comprimento que o IFC já traz, em cima da peça.
   *
   * PEDIDO: no canteiro, abrir o projeto e saber o comprimento de cada
   * trecho SEM levantar cota na mão com a trena.
   *
   * ⚠ ESTE CÓDIGO NÃO MEDE NADA. Ele lê `qto.comprimento`, que
   *   `lerQuantitativos` extraiu das BaseQuantities do arquivo e converteu
   *   para metros pela unidade declarada no próprio IFC. Se o projeto não
   *   publicou a quantidade, aqui não sai número — sai o aviso de que não
   *   sai. Um comprimento estimado pela caixa do elemento seria a DIAGONAL
   *   num ramal com caimento: plausível, errado, e em cima da peça que
   *   alguém vai serrar.
   *
   * ⚠ E RECUSA O COMPRIMENTO ANÔNIMO. `compFonte === 'anonima'` é uma
   *   quantidade de comprimento que ninguém batizou — serve para somar num
   *   quantitativo que o engenheiro confere, não para carimbar sobre o tubo,
   *   onde não há contexto para desconfiar.
   *
   * ⚠ SEM `setInterval`. Não existe um único no arquivo, e `desmontarMorto`
   *   não tem linha para timer: um relógio de 6 Hz com closure sobre `S`
   *   sobreviveria ao `S = null` e seguraria cena, renderer e geometrias do
   *   viewer morto para sempre. O ritmo vem do próprio quadro, acumulando
   *   `dt` — que é como o resto do arquivo já faz.
   * ===================================================================== */
  var cota = {
    on: false, modo: 'clicado',      // clicado | iguais | todas
    fixados: {},                     // uid -> 1 (modo clicado)
    chave: null,                     // critério do modo "iguais"
    objs: [],                        // sprites vivos
    porUid: {},                      // uid -> sprite
    indice: null, indiceMarca: -1,
    acum: 0, ultimoCusto: 0, periodo: 0.18,
    semQto: 0, cortadas: 0
  };
  /* teto: sprite é draw call + textura. 1.500 tubos ingênuos ≈ 87 MB de VRAM.
     No dedo o teto é menor porque a tela também é. */
  function cotaTeto() { return ehTelaPequena ? 22 : 48; }
  var COTA_MAX_INDICE = 1500;

  function cotaEhRede(e) {
    var t = String(e.tipo || '').toUpperCase();
    return t === 'IFCFLOWSEGMENT' || t === 'IFCFLOWFITTING' || t === 'IFCFLOWTERMINAL' ||
      t === 'IFCPIPESEGMENT' || t === 'IFCDUCTSEGMENT';
  }
  function cotaComprimento(e) {
    var q = e && e.qto;
    if (!q || !(q.comprimento > 0)) return 0;
    if (q.compFonte === 'anonima') return 0;   // ver o cartão acima
    return q.comprimento;
  }
  /* índice frio: só quem TEM número e âncora. Refeito quando entra/sai modelo. */
  /* ⚠ A MARCA DO CACHE TEM DE COBRIR O QUE MUDA A LISTA, NAO SO O NUMERO DE
   * MODELOS. A primeira versao invalidava por `S.modelos.length`: o editor
   * criando peca, o 4D removendo (`_remEd`) e o proprio carregamento
   * terminando depois do primeiro calculo NAO mexem nesse numero, e o indice
   * ficava congelado. Pego no navegador: cinco tubos entraram na lista e o
   * modo continuou dizendo 'nao achei tubulacao'. */
  function cotaMarca() {
    var nEl = (S.elementos && S.elementos.length) || 0;
    var nRem = S._remEd ? Object.keys(S._remEd).length : 0;
    return S.modelos.length + ':' + nEl + ':' + nRem;
  }
  function cotaIndice() {
    if (cota.indice && cota.indiceMarca === cotaMarca()) return cota.indice;
    var lista = [], sem = 0;
    elementosVivos().forEach(function (e) {
      if (!cotaEhRede(e)) return;
      if (!e.aabb) return;
      var L = cotaComprimento(e);
      if (!L) { sem++; return; }
      if (L < 0.3) return;                     // conexão curta: rótulo maior que a peça
      var a = e.aabb;
      lista.push({
        uid: e.uid, L: L,
        /* âncora pelo aabb JÁ CALCULADO no carregamento (bim.js, load) — refazer
           a união das malhas por elemento seria varrer o modelo inteiro por
           elemento, quadrático, no instante do toque. */
        x: (a.min[0] + a.max[0]) / 2, y: a.max[1], z: (a.min[2] + a.max[2]) / 2,
        chave: (e.familia && String(e.familia).trim()) || String(e.tipo || ''),
        temFamilia: !!(e.familia && String(e.familia).trim())
      });
    });
    cota.semQto = sem; cota.indice = lista; cota.indiceMarca = cotaMarca();
    return lista;
  }
  function cotaLimpar() {
    cota.objs.forEach(function (sp) {
      scene.remove(sp);
      /* ⚠ NÃO usar `limparMarca`: ele dá dispose na geometry, e a de Sprite é
         COMPARTILHADA pelo three — some a de todo mundo. */
      try { if (sp.material) { if (sp.material.map) sp.material.map.dispose(); sp.material.dispose(); } } catch (_) {}
    });
    cota.objs = []; cota.porUid = {}; cota.cortadas = 0;
  }
  function cotaAlvos() {
    var ix = cotaIndice();
    if (cota.modo === 'todas') return ix;
    if (cota.modo === 'iguais' && cota.chave != null) {
      return ix.filter(function (r) { return r.chave === cota.chave; });
    }
    return ix.filter(function (r) { return cota.fixados[r.uid]; });
  }
  /* uma passada: escolhe QUEM aparece e mantém os sprites em dia. */
  function cotaPassada() {
    if (!cota.on || !S || !S.alive) return;
    var alvos = cotaAlvos(), teto = cotaTeto();
    var vis = [], v = new THREE.Vector3();
    for (var i = 0; i < alvos.length; i++) {
      var r = alvos[i];
      /* respeita o que está desligado: modelo fora, pavimento isolado, 4D,
         plano de corte. Sem isto o botão cota tubo que a tela não mostra. */
      var m = S.meshPorUid && S.meshPorUid[r.uid];
      if (m && (m.visible === false || !cadeiaVisivel(m))) continue;
      v.set(r.x, r.y, r.z);
      if (foraDoClip(v)) continue;
      v.project(camera);
      if (v.z > 1 || v.x < -1.15 || v.x > 1.15 || v.y < -1.15 || v.y > 1.15) continue;  // fora da tela
      vis.push({ r: r, sx: v.x, sy: v.y, d: v.z, fixo: !!cota.fixados[r.uid] });
    }
    /* fixado primeiro, depois o mais perto da câmera — se sobrar espaço */
    vis.sort(function (a, b) { return (b.fixo - a.fixo) || (a.d - b.d); });
    /* grade: duas cotas nunca ocupam a mesma casa. É o que impede a sopa de
       números quando a rede inteira está ligada. */
    var grade = {}, escolhidos = [];
    for (var k = 0; k < vis.length && escolhidos.length < teto; k++) {
      var c = vis[k];
      /* ⚠ grade AFROUXADA de 9 para 6 colunas: com o numero na frente o
         rotulo ficou ~60% mais largo, e a grade antiga deixava dois se
         encavalarem. O corte maior aparece em cota.cortadas, que o
         resumo declara. */
      var gx = Math.round(c.sx * 6), gy = Math.round(c.sy * 14), gk = gx + '|' + gy;
      if (grade[gk] && !c.fixo) continue;
      grade[gk] = 1; escolhidos.push(c);
    }
    cota.cortadas = alvos.length - escolhidos.length;
    /* sincroniza os sprites com o conjunto escolhido */
    var querer = {};
    escolhidos.forEach(function (c) { querer[c.r.uid] = c.r; });
    Object.keys(cota.porUid).forEach(function (uid) {
      if (querer[uid]) return;
      var sp = cota.porUid[uid];
      scene.remove(sp);
      try { if (sp.material) { if (sp.material.map) sp.material.map.dispose(); sp.material.dispose(); } } catch (_) {}
      var ix2 = cota.objs.indexOf(sp); if (ix2 >= 0) cota.objs.splice(ix2, 1);
      delete cota.porUid[uid];
    });
    Object.keys(querer).forEach(function (uid) {
      var jaTem = cota.porUid[uid];
      if (jaTem) {
        /* mesmo uid, texto novo (renumerou) -> refaz; senao fica o antigo */
        var esperado = (numeroDe(uid) ? numeroDe(uid) + ' · ' : '') + fmtDist(querer[uid].L);
        if (jaTem.userData && jaTem.userData._txt === esperado) return;
        scene.remove(jaTem);
        try { if (jaTem.material) { if (jaTem.material.map) jaTem.material.map.dispose(); jaTem.material.dispose(); } } catch (_) {}
        var ixv = cota.objs.indexOf(jaTem); if (ixv >= 0) cota.objs.splice(ixv, 1);
        delete cota.porUid[uid];
      }
      var r2 = querer[uid];
      /* ⚠ o rotulo guarda o TEXTO que desenhou. O laco decide por uid, e sem
         isto renumerar a rede deixaria o numero velho na tela: mesmo uid,
         sprite reaproveitado, texto congelado. */
      var txt = (numeroDe(uid) ? numeroDe(uid) + ' · ' : '') + fmtDist(r2.L);
      var sp = labelSprite(txt);
      sp.userData._txt = txt;
      /* com muitas cotas, `depthTest:false` (o padrão de labelSprite, certo
         para UMA cota da trena) faz todas atravessarem a parede e virarem
         sopa. Só a fixada pelo toque continua sempre visível. */
      if (!cota.fixados[uid] && sp.material) { sp.material.depthTest = true; sp.renderOrder = 0; }
      sp.position.set(r2.x, r2.y + 0.06, r2.z);
      scene.add(sp); rescaleObj(sp);
      cota.objs.push(sp); cota.porUid[uid] = sp;
    });
  }
  /* =====================================================================
   * NUMERAR A REDE — R01-T001, seguindo o encadeamento.
   *
   * ⚠ A FONTE É `elementosVivos()`, NUNCA `cota.indice`.
   *   Aquele índice descarta tubo abaixo de 30 cm porque o rótulo ficaria
   *   maior que a peça — estética de sprite. Medido no projeto real: 732 dos
   *   1.725 tubos, 42,4%. Usá-lo aqui entregaria uma folha com 993 tubos e
   *   1.580,55 m sob um cabeçalho dizendo 1.725 e 1.667,20 m, e quebraria o
   *   encadeamento: R01-T013 seguido de R01-T015 com uma peça de 17 cm entre
   *   os dois na parede. Filtro de tela não decide papel de obra.
   * ===================================================================== */
  var num = { pacote: null, marca: null, porUid: {} };
  /* fator de comprimento do arquivo, memoizado: a bitola sai em unidade do
     projeto, igual as quantidades */
  var _fLen = {};
  function fatorLen(mid) {
    if (_fLen[mid] != null) return _fLen[mid];
    /* ⚠ B1: o fator de unidade do arquivo vem do cache; sondar o WASM com mid
       string devolveria a unidade de outro arquivo, e a bitola sairia em
       milimetro onde era metro */
    var moF = modeloDe(mid);
    if (semWasm(moF)) { _fLen[mid] = +(moF.fatorLenCache) || 1; return _fLen[mid]; }
    var b = 1;
    try { var x = unidadePrefixoBase(mid, 'LENGTHUNIT'); if (x != null) b = x; } catch (_) {}
    _fLen[mid] = b; return b;
  }
  function numerarRede() {
    if (!S || !S.alive) return null;
    if (typeof BimTubo === 'undefined') { UI0('Motor de numeração não carregado.', 'erro'); return null; }
    var pecas = {}, mids = {};
    elementosVivos().forEach(function (e) {
      if (!e || !e.uid) return;
      mids[e.mid] = 1;
      var Le = cotaComprimento(e);
      pecas[e.uid] = {
        id: e.id, uid: e.uid, tipo: e.tipo, nome: e.nome, familia: e.familia,
        sistema: e.sistema || '', pavimento: e.pavimento || '',
        L: Le, compFonte: (e.qto && e.qto.compFonte) || '',
        /* so para TUBO com medida: a bitola custa 4 GetLine por peca, e nao
           faz falta em conexao — o que vai para a lista de corte e o tubo */
        dnMm: (Le > 0 && BimTubo.ehTubo(e) && e.mid != null) ? lerBitolaMm(e.mid, e.id, fatorLen(e.mid)) : 0
      };
    });
    /* topologia de TODOS os modelos abertos, unida — a rede pode vir federada */
    var topo = { portaDe: {}, ligacao: {}, portasDe: {}, dirPorta: {}, nPortas: 0, nLigacoes: 0 };
    Object.keys(mids).forEach(function (mid) {
      var t;
      try { t = lerTopologiaRede(isNaN(+mid) ? mid : +mid); } catch (_) { return; }
      if (!t) return;
      Object.keys(t.portaDe).forEach(function (p) { topo.portaDe[p] = t.portaDe[p]; });
      Object.keys(t.ligacao).forEach(function (p) { topo.ligacao[p] = t.ligacao[p]; });
      Object.keys(t.portasDe).forEach(function (u) { topo.portasDe[u] = (topo.portasDe[u] || []).concat(t.portasDe[u]); });
      Object.keys(t.dirPorta).forEach(function (p) { topo.dirPorta[p] = t.dirPorta[p]; });
      topo.nPortas += t.nPortas; topo.nLigacoes += t.nLigacoes;
    });
    if (!topo.nLigacoes) {
      UI0('Este IFC não publica a ligação entre as peças. Dá para listar os tubos, não para encadeá-los.', 'erro');
      return null;
    }
    var pac = BimTubo.numerar(pecas, topo);
    pac.topo = { portas: topo.nPortas, ligacoes: topo.nLigacoes };
    num.pacote = pac; num.marca = cotaMarca(); num.porUid = {};
    pac.linhas.forEach(function (l) { num.porUid[l.uid] = l.n; });
    return pac;
  }
  function numeroDe(uid) { return (num.marca === cotaMarca()) ? (num.porUid[uid] || '') : ''; }
  S._numerarRede = numerarRede;
  S._numeracao = function () { return (num.marca === cotaMarca()) ? num.pacote : null; };

  /* aviso curto; cai no toast da Gestão quando existir, senão fica só no viewer */
  function UI0(msg, tipo) {
    try { if (typeof UI !== 'undefined' && UI.toast) { UI.toast(msg, tipo || 'info'); return; } } catch (_) {}
    try { if (S && S._hint) S._hint(msg); } catch (_) {}
  }
  function cotaResumo() {
    var alvos = cotaAlvos(), soma = 0;
    alvos.forEach(function (r) { soma += r.L; });
    var t = alvos.length + ' trecho(s) · ' + fmtDist(soma);
    if (cota.cortadas > 0) t += ' · mostrando as ' + (alvos.length - cota.cortadas) + ' mais legíveis';
    if (cota.semQto > 0) t += ' · ' + cota.semQto + ' sem comprimento no IFC';
    return t;
  }
  function setCota(on, modo) {
    if (!S) return;
    if (on && (fly.on || xr.on)) { UI0('Saia do modo Voo/RA-RV para cotar a rede.', 'erro'); return; }
    if (on) { sairFerramentasMenosCota(); }
    cota.on = !!on;
    if (modo) cota.modo = modo;
    if (!cota.on) { cotaLimpar(); }
    else {
      var ix = cotaIndice();
      if (!ix.length) {
        cota.on = false;
        UI0(cota.semQto > 0
          ? 'Este IFC não traz o comprimento das peças (' + cota.semQto + ' sem quantidade). Quem exportou precisa marcar "exportar quantidades base".'
          : 'Não achei tubulação neste modelo.', 'erro');
      } else if (cota.modo === 'todas' && ix.length > COTA_MAX_INDICE) {
        cota.on = false;
        UI0('São ' + ix.length + ' trechos — demais para mostrar de uma vez. Isole um pavimento ou um sistema e tente de novo.', 'erro');
      } else {
        cota.acum = cota.periodo;   // primeira passada no próximo quadro
        UI0(cotaResumo() + ' · comprimento do trecho como foi modelado', 'ok');
      }
    }
    var b = bar.querySelector('[data-b="cota"]');
    if (b) { b.classList.toggle('on', cota.on); b.style.background = cota.on ? '#16a34a' : ''; b.style.color = cota.on ? '#fff' : ''; }
    if (!cota.on) cotaLimpar();
    atualizarCursor();
  }
  /* desliga as OUTRAS ferramentas sem chamar sairFerramentas (que desligaria a
     cota que estamos ligando — laço) */
  function sairFerramentasMenosCota() {
    if (medir.on) setMedir(false);
    if (area.on) setArea(false);
    if (ang.on) setAng(false);
    if (S.edit && S.edit.on && S._setEdit) S._setEdit(false);
  }
  S._setCota = setCota;
  S._cotaIndice = function () { var ix = cotaIndice(); return { total: ix.length, semQto: cota.semQto, amostra: ix.slice(0, 3) }; };
  S._cotaEstado = function () { return { on: cota.on, modo: cota.modo, n: cota.objs.length, cortadas: cota.cortadas, semQto: cota.semQto, fixados: Object.keys(cota.fixados).length, chave: cota.chave, periodo: cota.periodo, custo: cota.ultimoCusto }; };

  S._tickExtra.push(function (dt) {
    if (!cota.on) return;
    for (var i = 0; i < cota.objs.length; i++) rescaleObj(cota.objs[i]);
    cota.acum += (dt || 0.016);
    if (cota.acum < cota.periodo) return;
    cota.acum = 0;
    var t0 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : 0;
    cotaPassada();
    if (t0) {
      cota.ultimoCusto = performance.now() - t0;
      /* auto-freio: a passada custou caro (modelo grande, aparelho fraco)?
         espaça em vez de engasgar o quadro — mesma lição do snap. */
      cota.periodo = cota.ultimoCusto > 8 ? 0.5 : 0.18;
    }
  });
  function btnCotas() { var b = bar.querySelector('[data-b="limpar-medidas"]'); if (b) b.style.display = medir.objs.length ? '' : 'none'; if (S && S._ajustarTop) S._ajustarTop(); } // botão entra/sai -> a barra (flex-wrap) pode mudar de altura
  /* S._medAlvo: durante o "abrir ponto de vista NUMA vista", as cotas vão para o grupo DELA */
  function addMed(o) { (S._medAlvo || scene).add(o); medir.objs.push(o); rescaleObj(o); }
  function pxyz(v) { return [v.x, v.y, v.z]; }
  // `horiz` só vem de quem REDESENHA uma cota gravada (ponto de vista): a cota
  // feita na planta continua horizontal mesmo que a vista reabra sem a planta.
  function desenharMedida(a, b, horiz, eixoRot) {
    // na PLANTA mede-se a distância HORIZONTAL (projeção XZ) — é o que a planta representa;
    // em 3D livre, a distância real. A ETIQUETA declara "(horizontal)" pra não haver
    // diferença semântica silenciosa entre os dois modos.
    var dxz = Math.sqrt((a.x - b.x) * (a.x - b.x) + (a.z - b.z) * (a.z - b.z));
    var horizontal = (horiz == null) ? !!planta.on : !!horiz, d = horizontal ? dxz : a.distanceTo(b);
    if (d < 2e-3) return false; // pontos coincidentes (duplo-clique/acidente) -> ignora
    var line = new THREE.Line(new THREE.BufferGeometry().setFromPoints([a, b]), new THREE.LineBasicMaterial({ color: 0x22c55e, depthTest: false })); line.renderOrder = 997;
    var lab = labelSprite(fmtDist(d) + (eixoRot ? ' (' + eixoRot + ')' : horizontal ? ' (horizontal)' : '')); lab.position.copy(a.clone().add(b).multiplyScalar(0.5));
    var mA = pontoMarca(a), mB = pontoMarca(b);
    addMed(mA); addMed(mB); addMed(line); addMed(lab); btnCotas();
    medir.ultima = { valor: d, horizontal: horizontal, eixo: eixoRot || '' }; // introspecção (UI futura + testes)
    var reg = { tipo: 'dist', pts: [pxyz(a), pxyz(b)], horizontal: horizontal, eixo: eixoRot || '' };
    medir.regs.push(reg);
    medir.pilha.push({ objs: [mA, mB, line, lab], reg: reg, ultima: medir.ultima });
    return true;
  }
  function limparMarca(o) { scene.remove(o); if (o.geometry) o.geometry.dispose(); if (o.material) { if (o.material.map) o.material.map.dispose(); o.material.dispose(); } }
  function tirarProv() { if (!medir.prov) return; var i = medir.objs.indexOf(medir.prov); if (i >= 0) { limparMarca(medir.prov); medir.objs.splice(i, 1); } medir.prov = null; }
  function limparMedidas() { medir.prov = null; area.pts = []; area.tmp = []; ang.pts = []; ang.tmp = []; medir.objs.forEach(limparMarca); medir.objs = []; medir.pts = []; medir.regs = []; medir.pilha = []; medir.ultima = null; atualizarElastico(null); btnCotas(); }
  S._limparMedidas = limparMedidas;
  /* DESFAZER da trena (o visor do link tem o botão): com o 1º ponto marcado,
     desfaz o PONTO; senão, tira a última medida inteira (as 2 marcas, a linha
     e a etiqueta, e o registro que o ponto de vista guardaria).
     ⚠ Confere que a medida ainda é desta cena: o "abrir ponto de vista numa
     vista" troca medir.regs/objs por um tempo, e a pilha pode ter entrada de
     lá — essa é pulada, nunca apaga desenho de outra vista. */
  function desfazerMedida() {
    if (medir.pts.length) { medir.pts = []; medir.dirAresta = null; tirarProv(); atualizarElastico(null); if (medir.on) S._hint(trenaTxt('on')); return 'ponto'; }
    while (medir.pilha.length) {
      var u = medir.pilha.pop(), ri = medir.regs.indexOf(u.reg);
      if (ri < 0) continue;
      medir.regs.splice(ri, 1);
      u.objs.forEach(function (o) { var i = medir.objs.indexOf(o); if (i >= 0) { limparMarca(o); medir.objs.splice(i, 1); } });
      var ant = medir.pilha[medir.pilha.length - 1];
      medir.ultima = ant ? ant.ultima : null;
      btnCotas();
      return 'medida';
    }
    return null;
  }
  S._desfazerMedida = desfazerMedida;
  // cursor único p/ as 3 ferramentas de medição (trena/área/ângulo)
  function atualizarCursor() { canvasEl.style.cursor = (medir.on || area.on || ang.on) ? 'crosshair' : ''; }
  function setMedir(on) {
    medir.on = !!on;
    if (on) { setMode(false); if (area.on) setArea(false); if (ang.on) setAng(false); if (edit && edit.on) setEdit(false); } // pode coexistir com Planta/Corte; exclusivo entre medições e editor
    else { medir.pts = []; tirarProv(); btnCotas(); esconderSnapMarca(); } // sai: descarta 1º ponto pendente
    if (S._pintarEixo) S._pintarEixo();
    var bm = bar.querySelector('[data-b="medir"]'); if (bm) { bm.style.background = on ? corAtiva() : ''; bm.style.color = on ? '#fff' : ''; }
    atualizarCursor();
    S._hint(on ? trenaTxt(planta.on ? 'planta' : 'on') : (planta.on ? '' + (typeof Icones !== 'undefined' ? Icones.get('regua', 15) : '') + ' Planta baixa. Ajuste a altura do corte no painel.' : ''));
  }
  S._setMedir = setMedir;
  // captura por CLIQUE-SEM-ARRASTE (não atrapalha a órbita: se arrastou, é rotação).
  // O MESMO caminho serve a trena e o desenho da linha do corte técnico — ambos com snap.
  var _ultimosHits = []; // objetos DISTINTOS visíveis/não-clipados do último raio (o snap de ✚ interseção usa até 2)
  function raycastEm(clientX, clientY) {
    var rc = canvasEl.getBoundingClientRect();
    mouse.x = ((clientX - rc.left) / rc.width) * 2 - 1; mouse.y = -((clientY - rc.top) / rc.height) * 2 + 1;
    ray.setFromCamera(mouse, camera);
    var hits = ray.intersectObjects(modelRoot.children, true);
    _ultimosHits = [];
    /* ⚠ ATÉ TRÊS, não dois. O ponto que o projetista quer costuma ser onde
       TRÊS coisas se encontram — tubo entrando na parede junto da laje, viga
       apoiada no pilar contra a alvenaria. Com o teto em 2, o terceiro
       elemento ficava fora da varredura e o canto que estava na tela
       simplesmente não existia como candidato. */
    for (var hh = 0; hh < hits.length && _ultimosHits.length < 3; hh++) {
      if (!cadeiaVisivel(hits[hh].object) || foraDoClip(hits[hh].point)) continue;
      var repetido = false;
      for (var uh = 0; uh < _ultimosHits.length; uh++) if (_ultimosHits[uh].object === hits[hh].object) { repetido = true; break; }
      if (repetido) continue; // OBJETOS distintos (canto parede×viga×laje)
      _ultimosHits.push(hits[hh]);
    }
    return _ultimosHits[0] || null;
  }
  S._raycastEm = raycastEm; S._aplicarSnapRef = function (h, r) { return aplicarSnap(h, r); }; S._foraDoClipRef = foraDoClip; // hooks p/ E2E

  /* =====================================================================
   * API DO VISITANTE (js/rvvisor.js) — o link da RA/RV no celular.
   * O ponto sai nas coordenadas do MODELO (relativas ao modelRoot): é a
   * mesma geometria no computador, então o apontamento feito no celular
   * cai no mesmo lugar quando vira ponto de vista da obra.
   * ===================================================================== */
  function pontoNaTela(cx, cy) {
    var h = raycastEm(cx, cy); if (!h) return null;
    modelRoot.updateMatrixWorld(true);
    var pl = h.point.clone().applyMatrix4(new THREE.Matrix4().copy(modelRoot.matrixWorld).invert());
    var ud = h.object.userData || {}, uid = ud.expressID != null ? ((ud.mid != null ? ud.mid : S.modelID) + ':' + ud.expressID) : '';
    var el = null, els = S.elementos || [];
    for (var i = 0; uid && i < els.length; i++) if (els[i].uid === uid) { el = els[i]; break; }
    return { p: [pl.x, pl.y, pl.z], uid: uid, chave: el ? (el.chave || '') : '', nome: el ? (el.familia || el.nome || el.tipo || '') : '', tipo: ud.tipo || '' };
  }
  S._pontoNaTela = pontoNaTela;
  /* COLETOR DE CLIQUES — "vou clicando nas peças e o sistema vai juntando"
   * (relatório de peso, e depois o içamento). Diferente do `_aoTocar`, que é
   * de UM toque: o coletor fica ligado até quem ligou desligar.
   * ⚠ O DUPLO-CLIQUE DE HÁBITO: quem passa a vida no Revit clica duas vezes.
   *   Os dois cliques chegavam aqui e a peça entrava e saía na mesma hora — na
   *   tela, "não aconteceu nada". O segundo clique na MESMA peça em menos de
   *   400 ms é o duplo-clique da primeira, e é ignorado; e o `dblclick` não
   *   seleciona enquanto o coletor está ligado (ver o ouvinte dele). */
  /* ⚠ e o tempo é o do RELÓGIO DO CLIQUE (timeStamp do evento), não a hora em
     que o código rodou — a mesma lição do toque do visitante, acima: com o 3D
     pesado cada quadro leva centenas de ms, os dois cliques do duplo clique
     eram tratados 500 ms um do outro e a guarda deixava a peça entrar e sair
     (medido na e2e-bim-peso, 01/10/2026: passava numa rodada e não na outra). */
  var _ultColeta = null;
  function cliqueColetor(e) {
    var p = pontoNaTela(e.clientX, e.clientY);
    var agora = (e && e.timeStamp > 0) ? e.timeStamp : performance.now();
    if (p && p.uid && _ultColeta && _ultColeta.uid === p.uid && agora - _ultColeta.t < 400) return;
    _ultColeta = p && p.uid ? { uid: p.uid, t: agora } : null;
    try { S._aoClicarPeca(p); } catch (_) {}
  }
  S._cliqueColetor = cliqueColetor;

  /* VOLUME PELA MALHA — para a peça cujo IFC não publica volume (porta,
   * janela e louça costumam vir assim). Volume assinado dos tetraedros contra
   * um ponto (teorema da divergência), na matriz da PRÓPRIA peça: independe de
   * onde o modelo está na cena (imersivo, mesa, reposicionamento).
   * ⚠ SÓ É CERTO EM MALHA FECHADA. Casca aberta dá um número que depende da
   *   origem — por isso a origem é o centro da caixa da peça (o erro fica do
   *   tamanho da peça, não da distância até a origem do projeto) e o resultado
   *   é RECUSADO quando passa do volume da caixa envolvente. Quem consome
   *   chama de "estimado pela malha", nunca de medido. */
  /* o memo e o índice moram NO MODELO: tirar o modelo leva os dois junto, e
     um IFC aberto depois com o mesmo `mid` não herda volume de outro arquivo */
  function modeloDaPeca(uid) {
    var s = String(uid || ''), i = s.lastIndexOf(':'); if (i < 0) return null;
    var mid = s.slice(0, i);
    return modeloDe(mid !== '' && !isNaN(+mid) ? +mid : mid) || modeloDe(mid);
  }
  function malhasDaPeca(uid) {
    var mo = modeloDaPeca(uid), eid = +String(uid).slice(String(uid).lastIndexOf(':') + 1);
    if (!mo || !mo.grupo) return [];
    if (!mo._malhasPorId) {
      mo._malhasPorId = {};
      mo.grupo.children.forEach(function (m) {
        var id = m.userData && m.userData.expressID; if (id == null || !m.isMesh) return;
        (mo._malhasPorId[id] = mo._malhasPorId[id] || []).push(m);
      });
    }
    return mo._malhasPorId[eid] || [];
  }
  function volumeMalha(uid) {
    var mo = modeloDaPeca(uid); if (!mo) return null;
    var memo = mo._volMalha || (mo._volMalha = {});
    if (Object.prototype.hasOwnProperty.call(memo, uid)) return memo[uid];
    var ms = malhasDaPeca(uid), caixa = new THREE.Box3(), tmp = new THREE.Box3();
    if (!ms.length) return null;
    ms.forEach(function (m) {
      if (!m.geometry) return; m.updateMatrix();
      if (!m.geometry.boundingBox) m.geometry.computeBoundingBox();
      tmp.copy(m.geometry.boundingBox).applyMatrix4(m.matrix); caixa.union(tmp);
    });
    if (caixa.isEmpty()) { memo[uid] = null; return null; }
    var c = caixa.getCenter(new THREE.Vector3()), sz = caixa.getSize(new THREE.Vector3()), vCaixa = sz.x * sz.y * sz.z;
    var total = 0;
    ms.forEach(function (m) {
      var g = m.geometry, pa = g && g.attributes && g.attributes.position, ix = g && g.index; if (!pa || !ix) return;
      var e = m.matrix.elements, p = pa.array, id = ix.array, s = 0;
      function X(k) { return e[0] * p[k] + e[4] * p[k + 1] + e[8] * p[k + 2] + e[12] - c.x; }
      function Y(k) { return e[1] * p[k] + e[5] * p[k + 1] + e[9] * p[k + 2] + e[13] - c.y; }
      function Z(k) { return e[2] * p[k] + e[6] * p[k + 1] + e[10] * p[k + 2] + e[14] - c.z; }
      for (var t = 0; t + 2 < id.length; t += 3) {
        var a = id[t] * 3, b = id[t + 1] * 3, d = id[t + 2] * 3;
        var ax = X(a), ay = Y(a), az = Z(a), bx = X(b), by = Y(b), bz = Z(b), dx = X(d), dy = Y(d), dz = Z(d);
        s += ax * (by * dz - bz * dy) - ay * (bx * dz - bz * dx) + az * (bx * dy - by * dx);
      }
      total += Math.abs(s / 6); // matriz espelhada inverte o sinal da peça inteira, não o volume
    });
    var r = (total > 0 && total <= vCaixa * 1.001) ? { volume: total, caixa: vCaixa } : null;
    memo[uid] = r;
    return r;
  }
  S._volumeMalha = volumeMalha;
  /* ⚠ OS PINOS MORAM NA CENA, NÃO NO modelRoot. Filhos do modelo, eles
     seriam acertados pelo raio do toque (e a peça atrás deles nunca seria
     selecionada), entrariam no todasMalhas como se fossem modelo e iriam
     parar no arquivo da RA do iPhone. A posição acompanha a matriz do modelo
     a cada quadro — no imersivo o modelo anda e escala. */
  var pinGrupo = new THREE.Group(); pinGrupo.name = 'pinos-visitante'; scene.add(pinGrupo);
  var _pinWp = new THREE.Vector3();
  function pinos(lista) {
    while (pinGrupo.children.length) {
      var o = pinGrupo.children.pop();
      try { if (o.material && o.material.map) o.material.map.dispose(); if (o.material) o.material.dispose(); if (o.geometry) o.geometry.dispose(); } catch (_) {}
    }
    (lista || []).forEach(function (pn) {
      if (!pn || !pn.p || pn.p.length !== 3) return;
      var pl = new THREE.Vector3(pn.p[0], pn.p[1], pn.p[2]);
      var sp = labelSprite(String(pn.rotulo || '•').slice(0, 24));
      sp.userData.pl = pl.clone().add(new THREE.Vector3(0, 0.35, 0)); sp.userData.pinoId = pn.id;
      var bola = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 12), new THREE.MeshBasicMaterial({ color: pn.cor || 0xf59e0b, depthTest: false }));
      bola.userData = { pl: pl, _sc: 0.008, pinoId: pn.id }; bola.renderOrder = 998;
      pinGrupo.add(sp); pinGrupo.add(bola);
    });
  }
  S._pinos = pinos;
  S._tickExtra.push(function () {
    if (!pinGrupo.children.length) return;
    modelRoot.updateMatrixWorld();
    for (var i = 0; i < pinGrupo.children.length; i++) {
      var o = pinGrupo.children[i];
      o.position.copy(o.userData.pl).applyMatrix4(modelRoot.matrixWorld);
      var sc = o.userData._sc; if (!sc) continue;
      var d = camera.position.distanceTo(o.getWorldPosition(_pinWp)) * sc;
      if (o.userData._ratio) o.scale.set(d * o.userData._ratio, d, 1); else o.scale.setScalar(d);
    }
  });
  /* leva a câmera para olhar um ponto do modelo, mantendo a direção atual */
  function olharPara(p, dist) {
    if (!p || p.length !== 3) return;
    modelRoot.updateMatrixWorld(true);
    var alvo = new THREE.Vector3(p[0], p[1], p[2]).applyMatrix4(modelRoot.matrixWorld);
    var dir = camera.position.clone().sub(orbit.target); if (dir.lengthSq() < 1e-6) dir.set(0.7, 0.55, 0.8); dir.normalize();
    voarCam(alvo.clone().add(dir.multiplyScalar(dist || 6)), alvo, 0.6);
  }
  S._olharPara = olharPara;

  /* =====================================================================
   * IÇAMENTO NA CENA — o equipamento modelado, o raio, as lingas e a
   * simulação do plano (motor: js/icarplano.js; casca: gestao.js _icar*).
   *
   * ⚠ MORA NA CENA, NÃO NO modelRoot (o mesmo motivo dos pinos): filho do
   *   modelo, o caminhão seria acertado pelo raio do clique, entraria no
   *   todasMalhas, na exportação e no arquivo da RA. O grupo copia a matriz do
   *   modelo a cada quadro, então tudo dentro dele é desenhado em coordenadas
   *   do modelo — no imersivo e na mesa o caminhão anda junto.
   * ⚠ COORDENADAS DO MOTOR: metros, z para cima (o IFC). A cena é Y-up:
   *   motor (x, y, z) = local (x, z, −y). Toda troca com a casca é no motor.
   * ⚠ A PEÇA-FANTASMA DA SIMULAÇÃO USA A GEOMETRIA DO MODELO (clone com outro
   *   material): na limpeza ela NÃO pode ser descartada — `geoCompartilhada`.
   *   Descartar ali apagava a peça de verdade da cena.
   * ⚠ O CAMINHÃO É ILUSTRATIVO no desenho: o que vem do fabricante (patolas,
   *   alcance, comprimento) sai do catálogo; o resto é volume de referência.
   * ===================================================================== */
  var icar = { grupo: new THREE.Group(), equip: null, sim: null, rotulos: [], vivos: {}, giro: null };
  icar.grupo.name = 'icamento'; icar.grupo.matrixAutoUpdate = false; scene.add(icar.grupo);
  var _icWp = new THREE.Vector3();
  function icL(p) { return new THREE.Vector3(+p.x || 0, +p.z || 0, -(+p.y || 0)); }
  function icM(v) { return { x: v.x, y: -v.z, z: v.y }; }
  function icMat(cor, op) { return new THREE.MeshStandardMaterial({ color: cor, metalness: .15, roughness: .65, transparent: op != null && op < 1, opacity: op == null ? 1 : op, side: THREE.DoubleSide }); }
  function icDescartar(o) {
    o.traverse(function (x) {
      try {
        /* ⚠ material em LISTA (telhado + fachada do prédio do entorno): .dispose() na lista lançava e a geometria ficava sem
           liberar; e a textura da fachada é COMPARTILHADA (texCompartilhada) — destruí-la a cada redesenho reenviaria à GPU */
        if (x.material && !x.userData.geoCompartilhada) (Array.isArray(x.material) ? x.material : [x.material]).forEach(function (m) { if (m.map && !(m.userData && m.userData.texCompartilhada)) m.map.dispose(); m.dispose(); });
        if (x.geometry && !x.userData.geoCompartilhada) x.geometry.dispose();
      } catch (_) {}
    });
  }
  function icLimparSim() {
    var s = icar.sim; if (!s) return;
    icar.sim = null;
    if (s.fantasma) { icar.grupo.remove(s.fantasma); icDescartar(s.fantasma); }
    if (s.escondeu) { try { limpar4DTarefas(); } catch (_) {} }
  }
  function icLimpar() {
    icLimparSim();
    while (icar.grupo.children.length) { var o = icar.grupo.children.pop(); icDescartar(o); }
    icar.equip = null; icar.rotulos = []; icar.vivos = {}; icar.giro = null; icar.tandem = null;
  }
  /* TANDEM: a lança, o cabo e a linga do 2º equipamento seguem o gancho dele (g) e o ponto P2 (pt), em coordenadas locais */
  function icTandemPose(g, pt) {
    var td = icar.tandem; if (!td) return;
    var ponta = g.clone().setY(g.y + 3), d = ponta.clone().sub(td.pe), L = Math.max(d.length(), 1e-3);
    td.lanca.position.copy(td.pe).add(ponta).multiplyScalar(0.5);
    td.lanca.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), d.normalize()); td.lanca.scale.set(1, 1, L);
    function mover(l, a, b) { if (!l) return; var at = l.geometry.attributes.position; at.setXYZ(0, a.x, a.y, a.z); at.setXYZ(1, b.x, b.y, b.z); at.needsUpdate = true; l.geometry.computeBoundingSphere(); }
    mover(td.cabo, g, ponta); if (pt) mover(td.linga, g, pt);
    td.gAgora = g.clone();
  }
  /* barra (caixa) de a até b, larg × alt de seção */
  function icBarra(a, b, larg, alt, mat) {
    var d = b.clone().sub(a), len = Math.max(d.length(), 1e-3);
    var m = new THREE.Mesh(new THREE.BoxGeometry(larg, alt, len), mat);
    m.position.copy(a).add(b).multiplyScalar(0.5);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), d.normalize());
    return m;
  }
  function icLinha(pts, cor, tracejada, larg) {
    var g = new THREE.BufferGeometry().setFromPoints(pts);
    var mat = tracejada ? new THREE.LineDashedMaterial({ color: cor, dashSize: tracejada, gapSize: tracejada * 0.6, depthTest: false, transparent: true })
      : new THREE.LineBasicMaterial({ color: cor, depthTest: false, transparent: true, linewidth: larg || 1 });
    var l = new THREE.Line(g, mat); if (tracejada) l.computeLineDistances(); l.renderOrder = 996; return l;
  }
  function icCirculo(c, r, y, cor, tr) {
    var pts = [];
    for (var k = 0; k <= 96; k++) { var t = k / 96 * Math.PI * 2; pts.push(new THREE.Vector3(c.x + r * Math.cos(t), y, c.z + r * Math.sin(t))); }
    return icLinha(pts, cor, tr);
  }
  function icRotulo(txt, p) {
    var sp = labelSprite(String(txt).slice(0, 40)); sp.position.copy(p); icar.grupo.add(sp); icar.rotulos.push(sp); return sp;
  }
  /* a caixa e o CG de cada peça, no MOTOR. CG pelo volume da malha (tetraedros,
     como o volumeMalha); malha aberta ou estranha → centro da caixa, e diz. */
  function icGeometria(uids) {
    var out = {}; if (!S) return out;
    modelRoot.updateMatrixWorld(true);
    var inv = new THREE.Matrix4().copy(modelRoot.matrixWorld).invert(), mm = new THREE.Matrix4(), tmp = new THREE.Box3();
    (uids || []).forEach(function (uid) {
      var ms = malhasDaPeca(uid); if (!ms.length) return;
      var caixa = new THREE.Box3(), sv = 0, cx = 0, cy = 0, cz = 0;
      ms.forEach(function (m) {
        if (!m.geometry) return;
        m.updateMatrixWorld(true); mm.multiplyMatrices(inv, m.matrixWorld);
        if (!m.geometry.boundingBox) m.geometry.computeBoundingBox();
        tmp.copy(m.geometry.boundingBox).applyMatrix4(mm); caixa.union(tmp);
      });
      if (caixa.isEmpty()) return;
      var o = caixa.getCenter(new THREE.Vector3());
      ms.forEach(function (m) {
        var g = m.geometry, pa = g && g.attributes && g.attributes.position, ix = g && g.index; if (!pa || !ix) return;
        mm.multiplyMatrices(inv, m.matrixWorld);
        var e = mm.elements, p = pa.array, id = ix.array;
        function X(k) { return e[0] * p[k] + e[4] * p[k + 1] + e[8] * p[k + 2] + e[12] - o.x; }
        function Y(k) { return e[1] * p[k] + e[5] * p[k + 1] + e[9] * p[k + 2] + e[13] - o.y; }
        function Z(k) { return e[2] * p[k] + e[6] * p[k + 1] + e[10] * p[k + 2] + e[14] - o.z; }
        for (var t = 0; t + 2 < id.length; t += 3) {
          var a = id[t] * 3, b = id[t + 1] * 3, d = id[t + 2] * 3;
          var ax = X(a), ay = Y(a), az = Z(a), bx = X(b), by = Y(b), bz = Z(b), dx = X(d), dy = Y(d), dz = Z(d);
          var v = (ax * (by * dz - bz * dy) - ay * (bx * dz - bz * dx) + az * (bx * dy - by * dx)) / 6;
          sv += v; cx += v * (ax + bx + dx) / 4; cy += v * (ay + by + dy) / 4; cz += v * (az + bz + dz) / 4;
        }
      });
      var sz = caixa.getSize(new THREE.Vector3()), vCaixa = sz.x * sz.y * sz.z;
      var cgOk = Math.abs(sv) > 1e-9 && Math.abs(sv) <= vCaixa * 1.001;
      var cgL = cgOk ? new THREE.Vector3(o.x + cx / sv, o.y + cy / sv, o.z + cz / sv) : o.clone();
      if (cgOk && !caixa.containsPoint(cgL)) { cgL = o.clone(); cgOk = false; }
      var a1 = icM(caixa.min), a2 = icM(caixa.max);
      out[uid] = { min: { x: Math.min(a1.x, a2.x), y: Math.min(a1.y, a2.y), z: Math.min(a1.z, a2.z) },
        max: { x: Math.max(a1.x, a2.x), y: Math.max(a1.y, a2.y), z: Math.max(a1.z, a2.z) }, cg: icM(cgL), cgPelaMalha: cgOk };
    });
    return out;
  }
  /* cota do chão do modelo (motor z) — o fundo da caixa do modelo inteiro */
  function icChao() {
    var box = new THREE.Box3();
    modelRoot.updateMatrixWorld(true);
    var inv = new THREE.Matrix4().copy(modelRoot.matrixWorld).invert(), tmp = new THREE.Box3();
    cadaMalha(function (m) { if (!m.geometry || !m.visible) return; if (!m.geometry.boundingBox) m.geometry.computeBoundingBox(); m.updateMatrixWorld(true); tmp.copy(m.geometry.boundingBox).applyMatrix4(m.matrixWorld).applyMatrix4(inv); box.union(tmp); });
    return box.isEmpty() ? 0 : box.min.y;
  }
  /* o ponto no chão sob o cursor. opts = { modo: 'pavimento'|'manual'|'superficie', cota (motor z) }.
     ⚠ O DEFEITO DA PRÉVIA 1.2.114 (Rogério, 01/10/2026): o caminhão nascia ABAIXO DO PISO. O clique que não
       acertava peça caía no plano do FUNDO do modelo (`icChao()`), e num modelo com fundação o fundo é a ponta
       da estaca (−6 m no fixture). Agora: pavimento/manual = o raio é projetado no plano da COTA DO APOIO (a
       peça acertada não conta — clicar no telhado põe o caminhão no térreo, sob o cursor); superfície = a peça
       acertada (terreno, laje), e o vazio cai no plano da cota do apoio. O fundo do modelo nunca mais é chão. */
  function icPontoNoChao(cx, cy, opts) {
    modelRoot.updateMatrixWorld(true);
    var inv = new THREE.Matrix4().copy(modelRoot.matrixWorld).invert();
    if (!opts || opts.modo === 'superficie') {
      var h = raycastEm(cx, cy);
      if (h) { var pl = h.point.clone().applyMatrix4(inv), ud = h.object.userData || {}; var r = icM(pl); r.uid = ud.expressID != null ? ((ud.mid != null ? ud.mid : S.modelID) + ':' + ud.expressID) : ''; r.noModelo = true; return r; }
    }
    var rc = canvasEl.getBoundingClientRect();
    mouse.x = ((cx - rc.left) / rc.width) * 2 - 1; mouse.y = -((cy - rc.top) / rc.height) * 2 + 1;
    ray.setFromCamera(mouse, camera);
    var yCh = (opts && opts.cota != null) ? icL({ x: 0, y: 0, z: +opts.cota }).y : icChao();
    var p0 = new THREE.Vector3(0, yCh, 0).applyMatrix4(modelRoot.matrixWorld), p1 = new THREE.Vector3(0, yCh + 1, 0).applyMatrix4(modelRoot.matrixWorld);
    var n = p1.clone().sub(p0).normalize(), plano = new THREE.Plane().setFromNormalAndCoplanarPoint(n, p0), hit = new THREE.Vector3();
    if (!ray.ray.intersectPlane(plano, hit)) return null;
    var r2 = icM(hit.applyMatrix4(inv)); r2.uid = ''; r2.noModelo = false; return r2;
  }
  /* a superfície sob cada ponto (motor): raio de cima para baixo começando 3 m acima do ponto — telhado mais alto
     que isso não conta como chão. Devolve [{x, y, z, sup|null}] — sup = cota da primeira peça abaixo do início. */
  var _icRaioSonda = new THREE.Raycaster();
  function icSondar(pts) {
    modelRoot.updateMatrixWorld(true);
    var alvos = []; cadaMalha(function (m) { if (m.visible && m.isMesh) alvos.push(m); });
    var baixo = new THREE.Vector3(0, -1, 0).transformDirection(modelRoot.matrixWorld), inv = new THREE.Matrix4().copy(modelRoot.matrixWorld).invert();
    return (pts || []).map(function (p) {
      var o = icL({ x: p.x, y: p.y, z: (+p.z || 0) + 3 }).applyMatrix4(modelRoot.matrixWorld);
      _icRaioSonda.set(o, baixo); _icRaioSonda.far = 1e4; _icRaioSonda.layers.mask = ray.layers.mask; // a camada do clique (o agregado põe as peças na 1)
      var hs = _icRaioSonda.intersectObjects(alvos, false), sup = null;
      for (var i = 0; i < hs.length; i++) { if (!cadeiaVisivel(hs[i].object)) continue; sup = icM(hs[i].point.clone().applyMatrix4(inv)).z; break; }
      return { x: p.x, y: p.y, z: p.z, sup: sup };
    });
  }
  /* o equipamento na cena. c = { tipo, pos (centro de giro, motor), rumo_graus (eixo do caminhão),
       patolas:[long, lat], comp, larg, gancho (motor), pontos:[motor], cg, raio, alcanceMax, isolamento,
       alturaPe, pontaGancho, rotulo, rotulos:[{p, txt}] } */
  function icDesenhar(c) {
    icLimpar();
    if (!S || !c || !c.pos) return { ok: false, erro: 'sem posição' };
    var pos = icL(c.pos), rumo = (+c.rumo_graus || 0) * Math.PI / 180;
    var ax = new THREE.Vector3(Math.cos(rumo), 0, -Math.sin(rumo)), lat = new THREE.Vector3(Math.sin(rumo), 0, Math.cos(rumo));
    var y0 = pos.y;
    function P(al, sd, up) { return pos.clone().add(ax.clone().multiplyScalar(al)).add(lat.clone().multiplyScalar(sd)).setY(y0 + up); }
    var mAm = icMat(0xf59e0b), mCab = icMat(0x1d4ed8), mChassi = icMat(0x475569), mPat = icMat(0xfacc15), mSap = icMat(0x7c2d12), mPreto = icMat(0x111827);
    /* com a FORMA da ficha (js/icarficha.js): o equipamento articulado; sem ela, o desenho de referência abaixo */
    var ge = (c.forma && window.IcarCinematica) ? icGerar(c, pos, rumo, y0) : null;
    function caixa(al, sd, up, Lx, Wl, Hz, mat) {
      var m = new THREE.Mesh(new THREE.BoxGeometry(Lx, Hz, Wl), mat);
      m.position.copy(P(al, sd, up + Hz / 2)); m.rotation.y = rumo; icar.grupo.add(m); return m;
    }
    var ehMunck = c.tipo === 'munck', comp = +c.comp || (ehMunck ? 8.5 : 12), larg = +c.larg || 2.5;
    var pat = c.patolas || [], pLat = Math.max(+pat[pat.length - 1] || larg + 2, larg), pLong = ehMunck ? null : (+pat[0] || comp * 0.55);
    var rodas = function (als) { als.forEach(function (al) { [-1, 1].forEach(function (s) { var r = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.35, 18), mPreto); r.position.copy(P(al, s * (larg / 2 - 0.15), 0.5)); r.rotation.set(Math.PI / 2, 0, 0); r.rotateOnWorldAxis(new THREE.Vector3(0, 1, 0), rumo); icar.grupo.add(r); }); }); };
    var sapatas = [];
    if (ge) { /* o gerador já desenhou caminhão, patolas e sapatas */ }
    else if (ehMunck) {
      /* munck: o giro fica logo atrás da cabine; patolas no giro e na traseira */
      caixa(-comp / 2 + 2.6, 0, 0.75, comp, larg * 0.9, 0.45, mChassi);
      caixa(-comp / 2 + 2.6 - 0.6, 0, 1.2, comp - 3.6, larg, 0.25, icMat(0x64748b));
      caixa(1.75, 0, 0.8, 2.1, larg, 2.0, mCab);
      rodas([1.6, -comp + 3.4, -comp + 4.6]);
      [0.15, -comp + 2.9].forEach(function (al) { sapatas.push(P(al, -pLat / 2, 0), P(al, pLat / 2, 0)); });
    } else {
      /* guindaste: o centro de giro no meio da base das patolas */
      caixa(0, 0, 0.9, comp, larg, 0.9, mChassi);
      caixa(comp / 2 - 1.2, 0, 1.0, 2.2, larg * 0.95, 1.9, mCab);
      rodas([comp / 2 - 2.6, comp / 2 - 4.3, -comp / 2 + 2.4, -comp / 2 + 4.0].slice(0, Math.max(2, Math.min(4, +c.eixos || 3))));
      [-pLong / 2, pLong / 2].forEach(function (al) { sapatas.push(P(al, -pLat / 2, 0), P(al, pLat / 2, 0)); });
    }
    sapatas.forEach(function (s) {
      var noCh = s.clone().setY(y0 + 0.9), borda = s.clone().sub(lat.clone().multiplyScalar(Math.sign(s.clone().sub(pos).dot(lat)) * (pLat / 2 - larg / 2))).setY(y0 + 0.9);
      icar.grupo.add(icBarra(borda, noCh, 0.28, 0.28, mPat));
      icar.grupo.add(icBarra(noCh, s.clone().setY(y0 + 0.12), 0.2, 0.2, mPat));
      var sp = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.08, 0.7), mSap); sp.position.copy(s).setY(y0 + 0.04); icar.grupo.add(sp);
    });
    /* chão: raio de trabalho, alcance máximo, área isolada */
    var yC = y0 + 0.03;
    /* REDE ELÉTRICA: o vão (linha preta) e os cilindros da NR-10 — zona controlada (Rc, laranja) e zona de risco (Rr, vermelho) */
    (c.redes || []).forEach(function (rd) {
      var z = window.IcarColisao ? IcarColisao.zonaNR10(rd.kV) : null, A = icL({ x: rd.a[0], y: rd.a[1], z: rd.a[2] }), B = icL({ x: rd.b[0], y: rd.b[1], z: rd.b[2] });
      var ln = icLinha([A, B], 0x111827); ln.name = 'rede-eletrica'; icar.grupo.add(ln);
      if (!z) return;
      [[z.Rc, 0xf97316, 0.16], [z.Rr, 0xdc2626, 0.3]].forEach(function (zr) {
        var cil = icCilindroL(icar.grupo, A, B, zr[0], new THREE.MeshBasicMaterial({ color: zr[1], transparent: true, opacity: zr[2], depthWrite: false, side: THREE.DoubleSide }), 24); cil.name = 'rede-zona';
      });
      icRotulo((rd.nome || 'rede') + ' · ' + String(rd.kV).replace('.', ',') + ' kV · Rc ' + String(z.Rc).replace('.', ',') + ' m', A.clone().lerp(B, 0.5).setY(A.y + z.Rc + 0.6));
    });
    /* áreas onde não se pode apoiar: vermelho translúcido + contorno (a que está sendo marcada, só o contorno tracejado) */
    (c.proibidoApoiar || []).forEach(function (ar) {
      var pts = (ar.poligono || []).map(function (q) { return icL({ x: q[0], y: q[1], z: 0 }).setY(yC + 0.01); });
      if (pts.length >= 2) { var ln = icLinha(ar.aberta ? pts : pts.concat([pts[0]]), 0xdc2626, ar.aberta ? 0.3 : 0); ln.name = 'area-proibida'; icar.grupo.add(ln); }
      if (pts.length >= 3 && !ar.aberta) {
        var sh = new THREE.Shape(pts.map(function (v) { return new THREE.Vector2(v.x, -v.z); }));
        var mF = new THREE.Mesh(new THREE.ShapeGeometry(sh), new THREE.MeshBasicMaterial({ color: 0xdc2626, transparent: true, opacity: 0.28, side: THREE.DoubleSide, depthWrite: false }));
        mF.rotation.x = -Math.PI / 2; mF.position.y = yC + 0.008; mF.name = 'area-proibida'; icar.grupo.add(mF);
        var cx = 0, cz = 0; pts.forEach(function (v) { cx += v.x; cz += v.z; });
        icRotulo('não apoiar: ' + (ar.motivo || 'área'), new THREE.Vector3(cx / pts.length, yC + 0.5, cz / pts.length));
      }
    });
    /* VISÃO DO OPERADOR: a linha do olho ao ponto de assentamento — verde livre, vermelha tapada (NR-18 18.10.1.30) */
    if (c.visada && c.visada.olho && c.visada.alvo) {
      var lnV = icLinha([icL(c.visada.olho), icL(c.visada.alvo)], c.visada.livre === false ? 0xdc2626 : 0x16a34a, 0.25); lnV.name = 'visada'; lnV.userData.foraDaFoto = true; icar.grupo.add(lnV);
    }
    if (c.raio > 0) icar.grupo.add(icCirculo(pos, c.raio, yC, 0xf97316, 0.5));
    if (c.alcanceMax > 0) { var cAlc = icCirculo(pos, c.alcanceMax, yC, 0x94a3b8, 0.35); cAlc.userData.foraDaFoto = true; icar.grupo.add(cAlc); } // o alcance máximo não manda no enquadramento da foto
    if (c.isolamento > 0) icar.grupo.add(icCirculo(pos, c.isolamento, yC, 0xef4444, 0.8));
    var lanca = new THREE.Group(); lanca.name = 'lanca'; icar.grupo.add(lanca);
    icar.equip = { c: c, pos: pos, ax: ax, lat: lat, y0: y0, ehMunck: ehMunck, lanca: lanca, mAm: mAm, mPreto: mPreto, ge: ge, k: c.k != null ? +c.k : null };
    icAtualizarLanca(c.gancho ? icL(c.gancho) : P(0, 0, 6), (c.pontos || []).map(icL));
    if (c.cg && c.raio > 0) {
      var cg0 = icL(c.cg).setY(yC);
      icar.grupo.add(icLinha([pos.clone().setY(yC), cg0], 0xf97316));
      icRotulo('R = ' + (Math.round(c.raio * 100) / 100).toString().replace('.', ',') + ' m', pos.clone().lerp(cg0, 0.5).setY(yC + 0.4));
    }
    /* TANDEM: o 2º equipamento em desenho de REFERÊNCIA (base, lança até o gancho dele, linga na vertical do P2, raio) —
       a física/forma articulada é só do 1º */
    if (c.tandem && c.tandem.pos && c.tandem.gancho) {
      var t2 = c.tandem, p2 = icL(t2.pos), g2 = icL(t2.gancho), y2 = p2.y, m2 = icMat(0x0ea5e9);
      var d2 = g2.clone().setY(y2).sub(p2); if (d2.length() > 1e-6) d2.normalize(); else d2.set(1, 0, 0);
      /* o caminhão do 2º em REFERÊNCIA (as medidas não vêm da ficha): chassi, cabine, giro e rodas, de lado para a carga */
      var b2 = new THREE.Group(); b2.name = 'tandem-equip'; b2.position.copy(p2).setY(y2); b2.rotation.y = Math.atan2(-d2.z, d2.x) + Math.PI / 2; icar.grupo.add(b2);
      var ch2 = new THREE.Mesh(new THREE.BoxGeometry(8, 0.9, 2.5), icMat(0x475569)); ch2.position.set(0, 1.35, 0); b2.add(ch2);
      var cb2c = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.9, 2.4), icMat(0x0369a1)); cb2c.position.set(3.0, 2.3, 0); b2.add(cb2c);
      var gi2 = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 0.5, 24), m2); gi2.position.set(0, 2.05, 0); b2.add(gi2);
      [-2.8, -1.4, 1.6, 2.9].forEach(function (u) { [-1, 1].forEach(function (s) { var rd = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.35, 18), icMat(0x111827)); rd.rotation.x = Math.PI / 2; rd.position.set(u, 0.5, s * 1.1); b2.add(rd); }); });
      /* lança, cabo e linga criados UMA vez e reposicionados por icTandemPose — a simulação chama a cada quadro, e recriar
         malha por quadro descartaria o material compartilhado */
      var l2 = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.7, 1), m2); l2.name = 'tandem-lanca'; icar.grupo.add(l2);
      var cb2 = icLinha([g2, g2.clone().setY(g2.y + 3)], 0x111827); icar.grupo.add(cb2);
      var lg2 = t2.ponto ? icLinha([g2, icL(t2.ponto)], 0x16a34a) : null; if (lg2) { lg2.name = 'tandem-linga'; icar.grupo.add(lg2); }
      icar.tandem = { pe: p2.clone().setY(y2 + 2.5), lanca: l2, cabo: cb2, linga: lg2, g: g2.clone(), pt: t2.ponto ? icL(t2.ponto) : null, gAgora: null };
      icTandemPose(g2, icar.tandem.pt);
      if (t2.raio > 0) icar.grupo.add(icCirculo(p2, t2.raio, yC, 0x0ea5e9, 0.5));
      if (t2.rotulo) icRotulo(t2.rotulo, p2.clone().setY(y2 + 4.4));
    }
    (c.rotulos || []).forEach(function (r) { if (r && r.p) icRotulo(r.txt, icL(r.p)); });
    /* com o equipamento articulado o nome sobe acima da superestrutura (embaixo encavalava com a margem e as patolas) */
    if (c.rotulo) icRotulo(c.rotulo, pos.clone().setY(y0 + (ge ? (ehMunck ? 6.2 : 7.2) : (ehMunck ? 4.6 : 4.2))));
    icSincronizar();
    return { ok: true, objetos: icar.grupo.children.length };
  }
  /* =====================================================================
   * EQUIPAMENTO ARTICULADO — fatia 1 do içamento (ESPEC-ICAMENTO-CENARIO.md §II.3.2 e §II.4.7).
   * A FORMA vem da ficha (js/icarficha.js → forma), a POSE da cinemática (js/icarcinematica.js) e as CORES e os
   * VALORES da física (js/icarfisica.js). Cada peça tem o seu pivô: a superestrutura gira (θ) no eixo de giro, a lança
   * levanta (α) no pé, os braços do munck dobram pela cinemática inversa.
   * ⚠ REFERENCIAL DO GRUPO: u (chassi, + para a cabine) = +X local, v (+ esquerda) = −Z local, w = +Y. O grupo fica no
   *   centro de giro marcado e gira pelo rumo — o mesmo P(al, sd, up) do desenho antigo, que segue de reserva para
   *   equipamento sem ficha (tabela da placa, "Outro equipamento").
   * ⚠ A FÍSICA repinta no máximo a cada 120 ms enquanto a lança gira (simulação ou "girar a lança"), não a cada quadro.
   * ⚠ Peça marcada "estimado" na forma (proporção genérica, sem número da ficha) ganha contorno tracejado quando
   *   c.mostrarEstimado — e NENHUMA conta da física usa essas medidas.
   * ===================================================================== */
  var IC_FAB = { liebherr: 0xf5c400, masal: 0xc8102e, palfinger: 0xd4001a, madal: 0xd4001a, xcmg: 0xf2b705, sany: 0xd71920, tka: 0x1f4e9a, argos: 0x0b5fa5, imap: 0xd71920 };
  function icCorFab(nome) { var n = String(nome || '').toLowerCase(); for (var k in IC_FAB) if (n.indexOf(k) >= 0) return IC_FAB[k]; return 0xf59e0b; }
  function icCaixaL(pai, x0, x1, y0, y1, z0, z1, mat, nome) {
    var m = new THREE.Mesh(new THREE.BoxGeometry(Math.max(1e-3, x1 - x0), Math.max(1e-3, y1 - y0), Math.max(1e-3, z1 - z0)), mat);
    m.position.set((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2); if (nome) m.name = nome; pai.add(m); return m;
  }
  function icCilindroL(pai, a, b, r, mat, seg) {
    var d = b.clone().sub(a), L = Math.max(d.length(), 1e-3);
    var m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, L, seg || 14), mat);
    m.position.copy(a).add(b).multiplyScalar(0.5); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); pai.add(m); return m;
  }
  function icTracejar(m) {
    var e = new THREE.LineSegments(new THREE.EdgesGeometry(m.geometry), new THREE.LineDashedMaterial({ color: 0x334155, dashSize: 0.18, gapSize: 0.12 }));
    e.computeLineDistances(); e.position.copy(m.position); e.quaternion.copy(m.quaternion); e.scale.copy(m.scale); m.parent.add(e); return e;
  }
  /* rótulo VIVO: um sprite por componente; o texto só redesenha quando muda (a física repinta várias vezes por segundo) */
  function icRotuloVivo(id, txt, p, cor) {
    var v = icar.vivos[id];
    if (!txt) { if (v) v.visible = false; return null; }
    if (!v || v.userData._txt !== txt || v.userData._cor !== cor) {
      if (v) { icar.grupo.remove(v); icDescartar(v); var ix = icar.rotulos.indexOf(v); if (ix >= 0) icar.rotulos.splice(ix, 1); }
      v = labelSprite(String(txt).slice(0, 60), cor); v.userData._txt = txt; v.userData._cor = cor; icar.grupo.add(v); icar.rotulos.push(v); icar.vivos[id] = v;
    }
    v.visible = true; v.position.copy(p); return v;
  }
  function icGerar(c, pos, rumo, y0) {
    var fo = c.forma, est = fo.estimado || {}, munck = fo.tipo === 'munck';
    var eqG = new THREE.Group(); eqG.name = 'equipamento-articulado'; eqG.position.copy(pos).setY(y0); eqG.rotation.y = rumo; icar.grupo.add(eqG);
    var fab = icCorFab(c.rotulo), mFab = icMat(fab), mChassi = icMat(0x3f4652), mPreto = icMat(0x15181d), mAro = icMat(0xb8bec7);
    var mVidro = new THREE.MeshStandardMaterial({ color: 0x8fb6d9, metalness: 0.1, roughness: 0.05, transparent: true, opacity: 0.55 });
    var mCil = new THREE.MeshStandardMaterial({ color: 0xd9dde3, metalness: 0.9, roughness: 0.2 });
    var ge = { eqG: eqG, munck: munck, fo: fo, patolas: [], tracejar: [], mats: {} };
    function marca(m, campo) { if (est[campo]) ge.tracejar.push(m); return m; }
    function roda(u, z, r, larg) {
      var w = new THREE.Group(); w.position.set(u, r, z); eqG.add(w);
      var pneu = new THREE.Mesh(new THREE.CylinderGeometry(r, r, larg, 22), mPreto); pneu.rotation.x = Math.PI / 2; w.add(pneu);
      var aro = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.55, r * 0.55, larg + 0.02, 16), mAro); aro.rotation.x = Math.PI / 2; w.add(aro);
    }
    var gU = fo.giroU || 0, a = fo.patolaA, b = fo.patolaB;
    /* as 4 patolas (DE, DD, TE, TD): centro do retângulo em u = −giroU (o grupo nasce no centro de giro) */
    var pos4 = [[a / 2, b / 2], [a / 2, -b / 2], [-a / 2, b / 2], [-a / 2, -b / 2]];
    if (!munck) {
      var ch = fo.chassi, L = ch.comprimento, W = ch.largura, xc = -gU, hRod = ch.rodaD / 2;
      marca(icCaixaL(eqG, xc - L / 2, xc + L / 2, hRod * 0.9, hRod * 0.9 + ch.altura, -W / 2, W / 2, mFab, 'chassi'), 'comprimento');
      ch.eixos.forEach(function (u) { [-1, 1].forEach(function (s) { roda(xc + u, s * (W / 2 - 0.2), hRod, 0.45); }); });
      var cb = fo.cabineMotorista, xf = xc + L / 2;
      var cab = icCaixaL(eqG, xf - cb.comprimento, xf, hRod * 0.9 + ch.altura, hRod * 0.9 + ch.altura + cb.altura, -W / 2, W / 2 - 0.9, mFab, 'cabine'); marca(cab, 'cabineMotorista');
      icCaixaL(eqG, xf - 0.02, xf + 0.01, hRod * 0.9 + ch.altura + 0.6, hRod * 0.9 + ch.altura + cb.altura - 0.15, -W / 2 + 0.1, W / 2 - 1.0, mVidro);
      ge.topoChassi = hRod * 0.9 + ch.altura;
    } else {
      var cm = fo.caminhao, Lc = cm.comprimento, Wc = cm.largura, x1 = 2.8, x0 = x1 - Lc, hR = cm.rodaD / 2, xcen = (x0 + x1) / 2;
      marca(icCaixaL(eqG, x0, x1, hR * 0.8, hR * 0.8 + 0.35, -Wc * 0.42, Wc * 0.42, mChassi, 'chassi'), 'comprimento');
      var cabM = icCaixaL(eqG, x1 - cm.cabine.comprimento, x1, hR * 0.8 + 0.35, hR * 0.8 + 0.35 + cm.cabine.altura, -Wc / 2, Wc / 2, icMat(0xe5e7eb), 'cabine'); marca(cabM, 'caminhaoDetalhe');
      icCaixaL(eqG, x1 - 0.02, x1 + 0.01, hR * 0.8 + 1.2, hR * 0.8 + 0.35 + cm.cabine.altura - 0.15, -Wc / 2 + 0.12, Wc / 2 - 0.12, mVidro);
      var car = icCaixaL(eqG, x0 + 0.1, -0.7, hR * 0.8 + 0.35, hR * 0.8 + 0.45, -Wc / 2, Wc / 2, icMat(0x6b7280), 'carroceria'); marca(car, 'caminhaoDetalhe');
      [-1, 1].forEach(function (s) { icCaixaL(eqG, x0 + 0.1, -0.7, hR * 0.8 + 0.45, hR * 0.8 + 0.85, s * Wc / 2 - 0.04, s * Wc / 2 + 0.04, icMat(0x9ca3af)); });
      cm.eixos.forEach(function (u) { [-1, 1].forEach(function (s) { roda(xcen + u, s * (Wc / 2 - 0.25), hR, 0.38); }); });
      icCaixaL(eqG, -0.65, 0.65, hR * 0.8 + 0.35, 1.3, -0.65, 0.65, mFab, 'base do guindaste');
      ge.topoChassi = 1.3;
    }
    /* patolas: viga do chassi até a sapata, cilindro vertical, sapata (cor da patola) e o chão sob ela (cor do solo) */
    var lado = fo.sapataLado || 0.6, hViga = munck ? 0.95 : (ge.topoChassi - 0.35), largCh = munck ? fo.caminhao.largura : fo.chassi.largura;
    pos4.forEach(function (p, k) {
      var u = p[0] - gU, z = -p[1], zIn = (z > 0 ? 1 : -1) * largCh * 0.42;
      var viga = icCilindroL(eqG, new THREE.Vector3(u, hViga, zIn), new THREE.Vector3(u, hViga, z), 0.13, mFab); viga.userData.parte = 'viga';
      var cil = icCilindroL(eqG, new THREE.Vector3(u, hViga, z), new THREE.Vector3(u, 0.16, z), 0.09, mCil);
      var mS = icMat(0x9ca3af), sap = icCaixaL(eqG, u - lado / 2, u + lado / 2, 0.03, 0.12, z - lado / 2, z + lado / 2, mS, 'sapata-' + k); marca(sap, 'sapataLado_m');
      var mC = new THREE.MeshBasicMaterial({ color: 0x9ca3af, transparent: true, opacity: 0.55, depthWrite: false, side: THREE.DoubleSide });
      var chao = new THREE.Mesh(new THREE.PlaneGeometry(lado * 1.9, lado * 1.9), mC); chao.rotation.x = -Math.PI / 2; chao.position.set(u, 0.012, z); chao.renderOrder = 2; eqG.add(chao);
      if (est.patolaA || est.patolaB) ge.tracejar.push(viga);
      ge.patolas.push({ sapata: sap, chao: chao, mS: mS, mC: mC, u: u, z: z });
    });
    /* escoras sob as patolas (patola sobre laje escorada): postes de 2,8 m ABAIXO do apoio, espalhados sob a sapata; a cor
       vem da física (escora-n). Ilustrativo na posição — a carga é a da patola dividida entre as escoras dela. */
    ge.escoras = [];
    var escs = (c.fisica && c.fisica.escoras) || [];
    escs.forEach(function (es, n) {
      var k = +es.patola, pa = ge.patolas[k]; if (!pa) return;
      var mesmas = escs.filter(function (x) { return +x.patola === k; }), j = mesmas.indexOf(es), nn = mesmas.length;
      var ang = nn > 1 ? j / nn * Math.PI * 2 : 0, rr = nn > 1 ? lado * 0.45 : 0;
      var mE = icMat(0x9ca3af), x0 = pa.u + rr * Math.cos(ang), z0 = pa.z + rr * Math.sin(ang);
      var poste = icCilindroL(eqG, new THREE.Vector3(x0, -2.8, z0), new THREE.Vector3(x0, -0.05, z0), 0.06, mE); poste.name = 'escora-' + (n + 1);
      icCaixaL(eqG, x0 - 0.15, x0 + 0.15, -0.12, -0.05, z0 - 0.15, z0 + 0.15, mE);
      ge.escoras.push({ m: mE, idx: n, x: x0, z: z0 });
    });
    /* superestrutura (gira θ em torno do eixo de giro) */
    var sup = new THREE.Group(); sup.name = 'superestrutura'; sup.position.set(0, ge.topoChassi, 0); eqG.add(sup); ge.sup = sup;
    if (!munck) {
      var pl = fo.plataforma, se = fo.superestrutura, cpf = fo.contrapeso;
      marca(icCilindroL(sup, new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, pl.altura, 0), pl.raio, mChassi, 28), 'plataforma');
      var supC = icCaixaL(sup, -se.comprimento * 0.62, se.comprimento * 0.38, pl.altura, pl.altura + se.altura, -se.largura / 2, se.largura / 2 - 0.85, mFab, 'superestrutura'); marca(supC, 'superestrutura');
      /* cabine do operador do lado esquerdo (v > 0 → −Z), com vidro */
      var cabO = icCaixaL(sup, se.comprimento * 0.05, se.comprimento * 0.38 + 0.5, pl.altura, pl.altura + 1.7, se.largura / 2 - 0.8, se.largura / 2, mFab, 'cabine do operador');
      cabO.position.z = -cabO.position.z; marca(cabO, 'superestrutura');
      icCaixaL(sup, se.comprimento * 0.38 + 0.49, se.comprimento * 0.38 + 0.52, pl.altura + 0.5, pl.altura + 1.6, -(se.largura / 2 - 0.05), -(se.largura / 2 - 0.75), mVidro);
      /* contrapeso escalonado ATRÁS do giro (oposto à lança) */
      var mCp = icMat(0x2b2f36), rc = cpf.raio;
      var cp1 = icCaixaL(sup, -rc - cpf.comprimento / 2, -rc + cpf.comprimento / 2, pl.altura, pl.altura + cpf.altura * 0.55, -cpf.largura / 2, cpf.largura / 2, mCp, 'contrapeso'); marca(cp1, 'contrapesoRaio');
      marca(icCaixaL(sup, -rc - cpf.comprimento * 0.4, -rc + cpf.comprimento * 0.4, pl.altura + cpf.altura * 0.55, pl.altura + cpf.altura, -cpf.largura * 0.4, cpf.largura * 0.4, mCp), 'contrapesoRaio');
      /* pé da lança: pivô que levanta α (rotação em Z local: +X sobe para +Y) */
      var pe = new THREE.Group(); pe.name = 'pe-da-lanca'; pe.position.set(fo.peU, fo.peW - ge.topoChassi, 0); sup.add(pe); ge.pe = pe;
      ge.secoes = [];
      for (var i = 0; i < fo.secoes; i++) {
        var hh = 0.95 - 0.13 * i, ww = 0.72 - 0.1 * i, mSec = icMat(fab);
        var s = new THREE.Mesh(new THREE.BoxGeometry(1, hh, ww), mSec); s.name = 'secao-' + i; pe.add(s); ge.secoes.push({ m: s, mat: mSec });
        if (est.Lmin || est.secoes) ge.tracejar.push(s);
      }
      var cabeca = new THREE.Group(); cabeca.name = 'cabeca'; pe.add(cabeca); ge.cabeca = cabeca;
      icCaixaL(cabeca, -0.25, 0.35, -0.45, 0.35, -0.3, 0.3, mFab);
      [-0.12, 0.12].forEach(function (zz) { var pol = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.08, 20), mAro); pol.rotation.x = Math.PI / 2; pol.position.set(0.3, -0.05, zz); cabeca.add(pol); });
      ge.cilElev = null; ge.mCil = mCil;
    } else {
      var mFabM = mFab;
      ge.coluna = icCaixaL(sup, -0.35, 0.35, 0, fo.colunaW - ge.topoChassi, -0.35, 0.35, mFabM, 'coluna'); marca(ge.coluna, 'colunaW');
      ge.braco1 = new THREE.Mesh(new THREE.BoxGeometry(1, 0.42, 0.42), mFabM); ge.braco1.name = 'braco-1'; sup.add(ge.braco1);
      ge.braco2 = new THREE.Mesh(new THREE.BoxGeometry(1, 0.34, 0.34), mFabM); ge.braco2.name = 'braco-2'; sup.add(ge.braco2);
      ge.ext = new THREE.Mesh(new THREE.BoxGeometry(1, 0.24, 0.24), mFabM); ge.ext.name = 'extensao'; sup.add(ge.ext);
      if (est.L1) ge.tracejar.push(ge.braco1); if (est.L2) ge.tracejar.push(ge.braco2); if (est.extMax) ge.tracejar.push(ge.ext);
      ge.mCil = mCil; ge.mBracos = mFabM;
    }
    /* cabo (N pernas), moitão, e as lingas — redesenhados na pose */
    ge.cabos = new THREE.Group(); ge.cabos.name = 'cabo'; eqG.add(ge.cabos);
    ge.mCabo = new THREE.LineBasicMaterial({ color: 0x111827 });
    ge.moitao = new THREE.Group(); ge.moitao.name = 'moitao'; eqG.add(ge.moitao);
    ge.mMoitao = icMat(munck ? 0x111827 : 0xf5c400);
    icCaixaL(ge.moitao, -0.22, 0.22, 0.2, 0.75, -0.18, 0.18, ge.mMoitao);
    var gch = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.035, 8, 16, Math.PI * 1.4), mAro); gch.position.set(0, 0.08, 0); gch.rotation.z = Math.PI * 0.8; ge.moitao.add(gch);
    if (c.mostrarEstimado) ge.tracejar.forEach(function (m) { try { icTracejar(m); } catch (_) {} });
    ge.nEstimadas = ge.tracejar.length;
    return ge;
  }
  /* a pose: do gancho (cena) para θ, R e a cinemática; depois a física com θ e R, e as cores/valores */
  function icPoseGerada(gancho, pontos) {
    var q = icar.equip, ge = q.ge, fo = ge.fo, C = window.IcarCinematica;
    q._pontosUlt = (pontos || []).map(function (p) { return p.clone(); });
    /* gancho no referencial do grupo — mas o grupo vive dentro do icar.grupo (que copia o modelRoot): os pontos chegam no
       referencial do icar.grupo, então a conta é com a matriz LOCAL do grupo */
    var Mloc = new THREE.Matrix4().compose(ge.eqG.position, ge.eqG.quaternion, ge.eqG.scale), invL = Mloc.clone().invert();
    var gl = gancho.clone().applyMatrix4(invL), plL = (pontos || []).map(function (p) { return p.clone().applyMatrix4(invL); });
    var R = Math.hypot(gl.x, gl.z), th = Math.atan2(-gl.z, gl.x);
    ge.sup.rotation.y = th;
    q.theta = th; q.R = R; q.ganchoL = gl;
    var pontaL = null, wTopo = ge.topoChassi;
    if (!ge.munck) {
      var L = +q.c.lanca || fo.Lmin || 10;
      var k = C ? C.telescopica({ L: L, peU: fo.peU, peW: fo.peW, Lmin: Math.min(fo.Lmin || L, L), secoes: fo.secoes, dPonta: fo.dPonta, alfaMax: fo.alfaMax }, { R: R, H: gl.y }) : null;
      if (!k || !k.ok) {
        /* raio fora do alcance desta lança: deita a lança na direção do gancho (o aviso é do plano) */
        k = { ok: false, alfa: Math.atan2(Math.max(0.2, gl.y - fo.peW), Math.max(0.5, R - fo.peU)), secoes: [{ de: 0, ate: L }], ponta: null };
        k.ponta = { r: fo.peU + L * Math.cos(k.alfa), w: fo.peW + L * Math.sin(k.alfa) };
      }
      ge.pe.rotation.z = k.alfa;
      ge.secoes.forEach(function (s, i) { var sc = k.secoes[Math.min(i, k.secoes.length - 1)], len = Math.max(0.3, sc.ate - sc.de); s.m.scale.x = len; s.m.position.set(sc.de + len / 2, 0, 0); s.m.visible = i < k.secoes.length; });
      ge.cabeca.position.set(L, 0, 0);
      /* cilindro de elevação: da superestrutura até 45 % da seção base */
      if (ge.cilElev) { ge.sup.remove(ge.cilElev); icDescartar(ge.cilElev); }
      var baseC = new THREE.Vector3(fo.peU + 1.4, fo.plataforma.altura + 0.1, 0), pBoom = new THREE.Vector3(fo.peU + 0.45 * (fo.Lmin || L) * Math.cos(k.alfa), (fo.peW - ge.topoChassi) + 0.45 * (fo.Lmin || L) * Math.sin(k.alfa) - 0.35, 0);
      ge.cilElev = icCilindroL(ge.sup, baseC, pBoom, 0.16, ge.mCil);
      q.alfa = k.alfa; q.alfaGraus = k.alfa * 180 / Math.PI; q.kin = k;
      pontaL = new THREE.Vector3(k.ponta.r * Math.cos(th), k.ponta.w, -k.ponta.r * Math.sin(th));
    } else {
      var Cm = { r: 0, w: fo.colunaW }, P = { r: R, w: gl.y + 1.2 };
      var km = C ? C.munck({ C: Cm, L1: fo.L1, L2: fo.L2, extMin: 0, extMax: fo.extMax }, P) : null;
      function noSup(pt) { return new THREE.Vector3(pt.r, pt.w - wTopo, 0); }
      function barra(m, a2, b2) { var d = b2.clone().sub(a2), len = Math.max(d.length(), 1e-3); m.scale.x = len; m.position.copy(a2).add(b2).multiplyScalar(0.5); m.rotation.set(0, 0, Math.atan2(d.y, d.x)); }
      if (km && km.ok) {
        var c0 = noSup(Cm), cot = noSup(km.cotovelo), pt = noSup(km.ponta), dir2 = pt.clone().sub(cot).normalize();
        var fim2 = cot.clone().add(dir2.clone().multiplyScalar(fo.L2));
        barra(ge.braco1, c0, cot); barra(ge.braco2, cot, fim2.distanceTo(cot) < pt.distanceTo(cot) ? fim2 : pt); ge.ext.visible = km.ext > 0.01;
        if (ge.ext.visible) barra(ge.ext, fim2.clone().sub(dir2.clone().multiplyScalar(0.4)), pt);
        q.kin = km; pontaL = new THREE.Vector3(km.ponta.r * Math.cos(th), km.ponta.w, -km.ponta.r * Math.sin(th));
      } else {
        var c1 = noSup(Cm), p1 = noSup(P); barra(ge.braco1, c1, c1.clone().lerp(p1, 0.5)); barra(ge.braco2, c1.clone().lerp(p1, 0.5), p1); ge.ext.visible = false;
        q.kin = km || { ok: false }; pontaL = new THREE.Vector3(P.r * Math.cos(th), P.w, -P.r * Math.sin(th));
      }
    }
    q.pontaL = pontaL;
    /* cabo: N pernas verticais da ponta ao moitão */
    while (ge.cabos.children.length) { var o0 = ge.cabos.children.pop(); if (o0.geometry) o0.geometry.dispose(); }
    var n = Math.max(1, Math.min(8, +q.c.pernasCabo || (ge.munck ? 1 : 2)));
    for (var j = 0; j < n; j++) {
      var dz = (j - (n - 1) / 2) * 0.07;
      var gl2 = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(pontaL.x, pontaL.y - 0.1, pontaL.z + dz), new THREE.Vector3(gl.x, gl.y + 0.75, gl.z + dz)]);
      ge.cabos.add(new THREE.Line(gl2, ge.mCabo));
    }
    ge.moitao.position.copy(gl).setY(gl.y);
    /* lingas: do gancho às pernas (no referencial do grupo) */
    if (ge.lingas) { ge.eqG.remove(ge.lingas); icDescartar(ge.lingas); }
    ge.lingas = new THREE.Group(); ge.lingas.name = 'lingas'; ge.eqG.add(ge.lingas); ge.mLingas = [];
    plL.forEach(function (p, i) {
      var mL = new THREE.LineBasicMaterial({ color: 0x16a34a, depthTest: false, transparent: true });
      var ln = new THREE.Line(new THREE.BufferGeometry().setFromPoints([gl, p]), mL); ln.renderOrder = 996; ge.lingas.add(ln); ge.mLingas.push(mL);
      var bo = new THREE.Mesh(new THREE.SphereGeometry(0.07, 12, 12), new THREE.MeshBasicMaterial({ color: 0x16a34a, depthTest: false })); bo.position.copy(p); bo.renderOrder = 997; ge.lingas.add(bo);
    });
    q.gancho = gancho.clone();
    icFisicaAgora(false);
  }
  /* a física com o θ e o R de agora → cores e valores (no máximo a cada 120 ms, salvo forçar) */
  function icFisicaAgora(forcar) {
    var q = icar.equip; if (!q || !q.ge || !q.c.fisica || !window.IcarFisica) return null;
    var agora = performance.now();
    if (!forcar && q._fisT && agora - q._fisT < 120) { q._fisPend = true; return q.fis; }
    q._fisT = agora; q._fisPend = false;
    var e = {}, base = q.c.fisica; for (var kk in base) e[kk] = base[kk];
    e.theta = q.theta; e.R = q.R; if (q.k != null) e.k = q.k;
    var r = IcarFisica.componentes(e);
    q.fis = r; icPintar(r);
    return r;
  }
  function icPintar(r) {
    var q = icar.equip, ge = q.ge, c = q.c, valores = c.valores !== false, soCrit = !!c.soCritico, falha = !!c.modoFalha;
    var porId = {}; r.componentes.forEach(function (x) { porId[x.id] = x; });
    q.pulsa = [];
    function cor(x) { return new THREE.Color((x && x.u && x.u.faixa && x.u.faixa.cor) || '#9ca3af'); }
    function critico(x) { return x && x.u && ((x.u.uTrab != null && x.u.uTrab >= 0.8) || (x.u.uRup != null && x.u.uRup >= 1) || x.descola); }
    function pinta(mat, x, op) {
      if (!mat) return;
      mat.color.copy(cor(x));
      if (mat.emissive) mat.emissive.set(0x000000);
      var esmaece = falha && !critico(x);
      if (mat.opacity != null) { mat.transparent = esmaece || mat.transparent; mat.opacity = esmaece ? 0.18 : (op != null ? op : mat.opacity); }
      if (x && x.u && x.u.faixa.pulsa && mat.emissive) q.pulsa.push(mat);
    }
    function br(v, d) { return v == null || !isFinite(v) ? '—' : (Math.round(v * Math.pow(10, d)) / Math.pow(10, d)).toFixed(d).replace('.', ','); }
    function pct(x) { return x && x.u && x.u.uTrab != null ? br(x.u.uTrab * 100, 0) + ' %' : 'sem dado'; }
    var SIG = ['DE', 'DD', 'TE', 'TD'];
    ge.patolas.forEach(function (pa, k) {
      var xp = porId['patola-' + SIG[k]], xs = porId['solo-' + SIG[k]];
      pinta(pa.mS, xp, 1); pinta(pa.mC, xs, 0.55);
      var t = !valores || (soCrit && !critico(xp) && !critico(xs)) ? null
        : SIG[k] + ' · ' + (xp && xp.esforco != null ? 'R = ' + br(xp.esforco, 0) + ' kN' + (xp.descola ? ' (descola)' : '') : 'R: sem dado') + (xs && xs.esforco != null ? ' · ' + br(xs.esforco, 0) + ' kPa' : '');
      var wp = new THREE.Vector3(pa.u, 1.0, pa.z).applyMatrix4(new THREE.Matrix4().compose(ge.eqG.position, ge.eqG.quaternion, ge.eqG.scale));
      icRotuloVivo('patola-' + k, t, wp, xp && xp.u ? xp.u.faixa.cor : null);
    });
    (ge.escoras || []).forEach(function (es) {
      var xe = porId['escora-' + (es.idx + 1)]; pinta(es.m, xe, 1);
      var wpE = new THREE.Vector3(es.x, -1.4, es.z).applyMatrix4(new THREE.Matrix4().compose(ge.eqG.position, ge.eqG.quaternion, ge.eqG.scale));
      icRotuloVivo('escora-' + es.idx, valores && xe && (!soCrit || critico(xe)) ? 'escora ' + (es.idx + 1) + ': ' + (xe.esforco != null ? br(xe.esforco, 0) + ' kN (' + pct(xe) + ')' : 'sem dado') : null, wpE, xe && xe.u ? xe.u.faixa.cor : null);
    });
    var tb = porId.tabela;
    if (ge.secoes) ge.secoes.forEach(function (s) { pinta(s.mat, tb, 1); });
    if (ge.munck) { pinta(ge.mBracos, tb, 1); }
    var cb = porId.cabo; if (cb && cb.u.uTrab != null) ge.mCabo.color.copy(cor(cb)); else ge.mCabo.color.set(0x111827);
    var mo = porId.moitao; if (mo && mo.u.uTrab != null) pinta(ge.mMoitao, mo, 1);
    (ge.mLingas || []).forEach(function (m, i) { var x = porId['linga-' + (i + 1)]; m.color.copy(cor(x)); if (x && x.u.faixa.pulsa) q.pulsa.push(m); });
    var Mg = new THREE.Matrix4().compose(ge.eqG.position, ge.eqG.quaternion, ge.eqG.scale);
    var gW = q.ganchoL.clone().applyMatrix4(Mg), pW = q.pontaL.clone().applyMatrix4(Mg);
    icRotuloVivo('gancho', valores && !soCrit ? 'Q = ' + br(c.carga_kg, 0) + ' kg' : null, gW.clone().setY(gW.y + 1.3), null);
    icRotuloVivo('tabela', valores && (!soCrit || critico(tb)) ? 'tabela ' + pct(tb) : null, pW.clone().setY(pW.y + 0.9), tb && tb.u ? tb.u.faixa.cor : null);
    var tom = porId.tombamento;
    icRotuloVivo('giro', valores && !soCrit && r.reacoes.ok ? 'margem ' + br(r.reacoes.margem_m, 2) + ' m' + (r.reacoes.MeMt ? ' · Me/Mt ' + br(r.reacoes.MeMt, 1) : '') : null,
      new THREE.Vector3(0, ge.topoChassi + 2.4, 0).applyMatrix4(Mg), tom && tom.u ? tom.u.faixa.cor : null);
    var pts = ge.lingas ? ge.lingas.children.filter(function (o) { return o.isLine; }) : [];
    pts.forEach(function (ln, i) {
      var x = porId['linga-' + (i + 1)], a2 = ln.geometry.attributes.position;
      var mid = new THREE.Vector3((a2.getX(0) + a2.getX(1)) / 2, (a2.getY(0) + a2.getY(1)) / 2, (a2.getZ(0) + a2.getZ(1)) / 2).applyMatrix4(Mg);
      icRotuloVivo('linga-' + i, valores && x && (!soCrit || critico(x)) ? br(x.esforco, 0) + ' kgf (' + pct(x) + ')' : null, mid, x && x.u ? x.u.faixa.cor : null);
    });
  }

  /* lança + cabo + gancho + lingas até o gancho dado (redesenhado a cada quadro da simulação) */
  function icAtualizarLanca(gancho, pontos) {
    var q = icar.equip; if (!q) return;
    if (q.ge) { icPoseGerada(gancho, pontos); return; }
    while (q.lanca.children.length) { var o = q.lanca.children.pop(); icDescartar(o); }
    var pos = q.pos, y0 = q.y0, c = q.c;
    var ponta = gancho.clone().setY(gancho.y + (q.ehMunck ? 1.2 : (+c.pontaGancho || 3)));
    /* guindaste: a lança tem o comprimento da coluna da tabela — a ponta sobe pela geometria (pé + √(L² − raio²))
       e o cabo desce até o gancho; na simulação o raio muda e a lança só levanta ou abaixa */
    if (!q.ehMunck && +c.lanca > 0) {
      var dHz = Math.hypot(gancho.x - pos.x, gancho.z - pos.z), Lb = +c.lanca, yPe = y0 + (+c.alturaPe || 2.5);
      if (Lb > dHz + 0.05) ponta.setY(Math.max(yPe + Math.sqrt(Lb * Lb - dHz * dHz), gancho.y + 0.6));
    }
    var dirH = ponta.clone().setY(pos.y).sub(pos); var dist = dirH.length(); if (dist > 1e-6) dirH.normalize(); else dirH.set(1, 0, 0);
    if (q.ehMunck) {
      var col0 = pos.clone().setY(y0 + 1.3), col1 = pos.clone().setY(y0 + 3.4);
      q.lanca.add(icBarra(col0, col1, 0.55, 0.55, q.mAm));
      var joelho = pos.clone().add(dirH.clone().multiplyScalar(dist * 0.38)).setY(Math.max(col1.y, ponta.y) + 1.4);
      q.lanca.add(icBarra(col1, joelho, 0.42, 0.42, q.mAm));
      q.lanca.add(icBarra(joelho, ponta, 0.3, 0.3, q.mAm));
    } else {
      var giro = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 0.5, 24), icMat(0xd97706)); giro.position.copy(pos).setY(y0 + 1.95); q.lanca.add(giro);
      var cp = pos.clone().sub(dirH.clone().multiplyScalar(1.6)).setY(y0 + 2.6);
      var cpM = icBarra(cp.clone().sub(dirH.clone().multiplyScalar(0.6)), cp.clone().add(dirH.clone().multiplyScalar(0.6)), 2.2, 1.1, icMat(0x334155)); q.lanca.add(cpM);
      var pe = pos.clone().setY(y0 + (+c.alturaPe || 2.5));
      var meio = pe.clone().lerp(ponta, 0.55);
      q.lanca.add(icBarra(pe, meio, 0.75, 0.85, q.mAm));
      q.lanca.add(icBarra(meio, ponta, 0.5, 0.6, q.mAm));
    }
    q.lanca.add(icLinha([ponta, gancho], 0x111827)); q.gancho = gancho.clone();
    var bl = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.45, 0.32), q.mPreto); bl.position.copy(gancho).setY(gancho.y + 0.22); q.lanca.add(bl);
    (pontos || []).forEach(function (p) {
      q.lanca.add(icLinha([gancho, p], 0x16a34a));
      var b = new THREE.Mesh(new THREE.SphereGeometry(0.07, 12, 12), new THREE.MeshBasicMaterial({ color: 0x16a34a, depthTest: false })); b.position.copy(p); b.renderOrder = 997; q.lanca.add(b);
    });
  }
  /* a simulação: a peça-fantasma sai da coleta, sobe, gira com a lança e assenta.
     s = { uids, pivo (motor), cg, gancho, pontos (destino, motor), fundo (z do fundo no destino),
           coleta (motor, opcional), folga, duracao_s, aoFim } */
  function icSimular(s) {
    if (!S || !icar.equip) return { ok: false, erro: 'desenhe o equipamento antes' };
    icLimparSim();
    modelRoot.updateMatrixWorld(true);
    var inv = new THREE.Matrix4().copy(modelRoot.matrixWorld).invert();
    var fant = new THREE.Group(); fant.matrixAutoUpdate = false; fant.name = 'icamento-fantasma';
    var matF = new THREE.MeshStandardMaterial({ color: 0xf97316, emissive: 0x7c2d12, transparent: true, opacity: 0.88, side: THREE.DoubleSide });
    var n = 0;
    (s.uids || []).forEach(function (u) {
      malhasDaPeca(u).forEach(function (m) {
        if (!m.geometry) return;
        m.updateMatrixWorld(true);
        var k = new THREE.Mesh(m.geometry, matF); k.userData.geoCompartilhada = true;
        k.matrixAutoUpdate = false; k.matrix.multiplyMatrices(inv, m.matrixWorld); fant.add(k); n++;
      });
    });
    var mt = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.01, 0.01), matF); mt.visible = false; fant.add(mt); // dono do material (descartado uma vez)
    if (!n) return { ok: false, erro: 'peças sem malha na cena' };
    icar.grupo.add(fant);
    var piv = icL(s.pivo), Cd = icL(s.cg), fundoY = +s.fundo || 0;
    var phD = Math.atan2(Cd.z - piv.z, Cd.x - piv.x), rD = Math.hypot(Cd.x - piv.x, Cd.z - piv.z);
    var phC, rC, dh0;
    if (s.coleta) { var Cc = icL(s.coleta); phC = Math.atan2(Cc.z - piv.z, Cc.x - piv.x); rC = Math.hypot(Cc.x - piv.x, Cc.z - piv.z); dh0 = (+s.coleta.z || 0) - fundoY; }
    else { phC = phD + Math.PI / 2; rC = Math.max(rD * 0.6, 2.5); dh0 = icar.equip.y0 - icL({ x: 0, y: 0, z: fundoY }).y; }
    var dhT = Math.max(dh0, 0) + (s.folga > 0 ? +s.folga : 1);
    var dPh = phD - phC; while (dPh > Math.PI) dPh -= 2 * Math.PI; while (dPh < -Math.PI) dPh += 2 * Math.PI; phC = phD - dPh; // o caminho curto
    var gD = icL(s.gancho), pD = (s.pontos || []).map(icL);
    /* TANDEM: dois ganchos — a peça não gira em torno do centro de giro de um; sobe, ANDA em linha reta da coleta MARCADA ao destino
       (sem coleta: sobe do chão no próprio lugar) e assenta, e a lança de cada equipamento segue o seu ponto */
    var tdS = s.tandem && s.tandem.gancho && icar.tandem ? { g: icL(s.tandem.gancho), pt: s.tandem.ponto ? icL(s.tandem.ponto) : null } : null;
    var Cc0 = tdS && s.coleta ? icL(s.coleta) : Cd.clone(), dhA = tdS && s.coleta ? (+s.coleta.z || 0) - fundoY : dh0;
    var dhTT = Math.max(dhA, 0) + (s.folga > 0 ? +s.folga : 1);
    function estadoTandem(t) {
      var x, z, dh;
      if (t < 0.22) { var a = t / 0.22; x = Cc0.x; z = Cc0.z; dh = dhA + (dhTT - dhA) * a; }
      else if (t < 0.74) { var b = (t - 0.22) / 0.52, e = b * b * (3 - 2 * b); x = Cc0.x + (Cd.x - Cc0.x) * e; z = Cc0.z + (Cd.z - Cc0.z) * e; dh = dhTT; }
      else { var d = Math.min(1, (t - 0.74) / 0.26); x = Cd.x; z = Cd.z; dh = dhTT * (1 - d); }
      return new THREE.Matrix4().makeTranslation(x - Cd.x, dh, z - Cd.z);
    }
    var estado = tdS ? estadoTandem : estadoGiro;
    function estadoGiro(t) {
      var ph, r, dh;
      if (t < 0.22) { var a = t / 0.22; ph = phC; r = rC; dh = dh0 + (dhT - dh0) * a; }
      else if (t < 0.74) { var b = (t - 0.22) / 0.52, e = b * b * (3 - 2 * b); ph = phC + (phD - phC) * e; r = rC + (rD - rC) * e; dh = dhT; }
      else { var d = Math.min(1, (t - 0.74) / 0.26); ph = phD; r = rD; dh = dhT * (1 - d); }
      var M = new THREE.Matrix4().makeTranslation(piv.x + r * Math.cos(ph), Cd.y + dh, piv.z + r * Math.sin(ph))
        .multiply(new THREE.Matrix4().makeRotationY(phD - ph)).multiply(new THREE.Matrix4().makeTranslation(-Cd.x, -Cd.y, -Cd.z));
      return M;
    }
    /* a linha de içamento: o caminho do CG, inteiro, antes de começar */
    var trilha = [];
    for (var k2 = 0; k2 <= 60; k2++) trilha.push(Cd.clone().applyMatrix4(estado(k2 / 60)));
    var ln = icLinha(trilha, 0x7c3aed, 0.25); ln.name = 'linha-icamento'; icar.grupo.add(ln);
    var esc = false; try { aplicar4DSim({ ocultos: s.uids || [] }); esc = true; } catch (_) {}
    icar.sim = { t: 0, dur: Math.max(2, +s.duracao_s || 9), fantasma: fant, estado: estado, gD: gD, pD: pD, escondeu: esc, aoFim: s.aoFim, parado: !!s.pausado, tandem: tdS };
    function passo() {
      var si = icar.sim; if (!si) return;
      var M = si.estado(Math.min(1, si.t));
      si.fantasma.matrix.copy(M); si.fantasma.matrixWorldNeedsUpdate = true;
      icAtualizarLanca(si.gD.clone().applyMatrix4(M), si.pD.map(function (p) { return p.clone().applyMatrix4(M); }));
      if (si.tandem) icTandemPose(si.tandem.g.clone().applyMatrix4(M), si.tandem.pt ? si.tandem.pt.clone().applyMatrix4(M) : null);
    }
    icar.sim.passo = passo; passo();
    return { ok: true, malhas: n, trilha: trilha.length };
  }
  /* =====================================================================
   * CHOQUES E FOLGAS NO CAMINHO (ESPEC-ICAMENTO §D e §II.5) — motor: js/icarcolisao.js.
   * Em cada um dos 61 instantes da simulação o equipamento articulado é POSADO de verdade (a mesma icPoseGerada do quadro) e
   * daí saem, em coordenadas do motor: lança (cápsula), cabo e lingas (segmentos), carga e contrapeso (caixas orientadas).
   * Obstáculos: as peças VISÍVEIS do modelo, menos as içadas, filtradas antes pela caixa do caminho inteiro.
   * ⚠ Contato da CARGA e das LINGAS no primeiro e no último instante é esperado (a peça sai do chão/carreta e assenta no
   *   apoio) e é ignorado só para elas; lança e contrapeso encostando em t = 0 é problema de verdade e aparece.
   * ⚠ O teste só existe com o equipamento articulado (ficha) — sem ele não há lança nem contrapeso para testar.
   * ===================================================================== */
  function icMotorArr(v) { return [v.x, -v.z, v.y]; }
  function icObbDeMalha(m, invG) {
    if (!m.geometry) return null;
    if (!m.geometry.boundingBox) m.geometry.computeBoundingBox();
    m.updateMatrixWorld(true);
    var bb = m.geometry.boundingBox, M = new THREE.Matrix4().multiplyMatrices(invG, m.matrixWorld);
    var c = bb.getCenter(new THREE.Vector3()).applyMatrix4(M), ex = new THREE.Vector3(), ey = new THREE.Vector3(), ez = new THREE.Vector3();
    M.extractBasis(ex, ey, ez);
    var sx = ex.length(), sy = ey.length(), sz = ez.length(), sz3 = bb.getSize(new THREE.Vector3());
    ex.normalize(); ey.normalize(); ez.normalize();
    return { c: icMotorArr(c), e: [icMotorArr(ex), icMotorArr(ey), icMotorArr(ez)], h: [sz3.x * sx / 2, sz3.y * sy / 2, sz3.z * sz / 2] };
  }
  function icPontoMotor(obj, x, invG) { obj.updateMatrixWorld(true); return icMotorArr(new THREE.Vector3(x, 0, 0).applyMatrix4(obj.matrixWorld).applyMatrix4(invG)); }
  /* as partes do equipamento NA POSE ATUAL (depois de icPoseGerada) */
  function icPartesAgora(invG) {
    var q = icar.equip, ge = q.ge, out = [], Mg = new THREE.Matrix4().compose(ge.eqG.position, ge.eqG.quaternion, ge.eqG.scale);
    /* ⚠ ÁRVORE INTEIRA A PARTIR DA RAIZ: aqui a pose muda 61 vezes sem quadro no meio, e o updateMatrixWorld de uma peça usa a
       matriz do PAI como está — a lança saía medida na pose do instante anterior (apontando para o norte com o gancho a leste,
       medido em 02/10/2026) e o contrapeso nunca chegava ao muro */
    icSincronizar(); ge.eqG.updateMatrixWorld(true);
    function loc(v) { return icMotorArr(v.clone().applyMatrix4(Mg)); }
    var gch = loc(q.ganchoL.clone().setY(q.ganchoL.y + 0.75)), ponta = loc(q.pontaL);
    if (!ge.munck) {
      out.push({ quem: 'lança', tipo: 'capsula', a: icPontoMotor(ge.pe, 0, invG), b: icPontoMotor(ge.cabeca, 0, invG), raio: 0.48 });
      ge.sup.traverse(function (o) { if (o.isMesh && o.name === 'contrapeso') { var ob = icObbDeMalha(o, invG); if (ob) out.push({ quem: 'contrapeso', tipo: 'obb', obb: ob }); } });
    } else {
      out.push({ quem: 'braço 1', tipo: 'capsula', a: icPontoMotor(ge.braco1, -0.5, invG), b: icPontoMotor(ge.braco1, 0.5, invG), raio: 0.21 });
      out.push({ quem: 'braço 2', tipo: 'capsula', a: icPontoMotor(ge.braco2, -0.5, invG), b: icPontoMotor(ge.braco2, 0.5, invG), raio: 0.17 });
      if (ge.ext.visible) out.push({ quem: 'extensão', tipo: 'capsula', a: icPontoMotor(ge.ext, -0.5, invG), b: icPontoMotor(ge.ext, 0.5, invG), raio: 0.12 });
    }
    out.push({ quem: 'cabo', tipo: 'segmento', a: ponta, b: gch, raio: 0.03 });
    (ge.lingas ? ge.lingas.children.filter(function (o) { return o.isLine; }) : []).forEach(function (ln, i) {
      var a2 = ln.geometry.attributes.position;
      out.push({ quem: 'linga ' + (i + 1), tipo: 'segmento', a: loc(new THREE.Vector3(a2.getX(0), a2.getY(0), a2.getZ(0))), b: loc(new THREE.Vector3(a2.getX(1), a2.getY(1), a2.getZ(1))), raio: 0.02 });
    });
    /* a carga: a caixa da peça-fantasma (no referencial da peça no destino) levada pela matriz do instante */
    var si = icar.sim;
    if (si && si.fantasma) {
      var bxF = new THREE.Box3(), tmp = new THREE.Box3();
      si.fantasma.children.forEach(function (k) { if (!k.geometry || k.visible === false) return; if (!k.geometry.boundingBox) k.geometry.computeBoundingBox(); tmp.copy(k.geometry.boundingBox).applyMatrix4(k.matrix); if (!tmp.isEmpty()) bxF.union(tmp); });
      if (!bxF.isEmpty()) {
        var M = si.fantasma.matrix, c = bxF.getCenter(new THREE.Vector3()).applyMatrix4(M), sz = bxF.getSize(new THREE.Vector3()), ex = new THREE.Vector3(), ey = new THREE.Vector3(), ez = new THREE.Vector3();
        M.extractBasis(ex, ey, ez); ex.normalize(); ey.normalize(); ez.normalize();
        out.push({ quem: 'carga', tipo: 'obb', obb: { c: icMotorArr(c), e: [icMotorArr(ex), icMotorArr(ey), icMotorArr(ez)], h: [sz.x / 2, sz.y / 2, sz.z / 2] } });
      }
    }
    return out;
  }
  /* os obstáculos: peças visíveis do modelo (menos as içadas), cuja caixa cruza a caixa do caminho; triângulos no motor */
  /* AGENTE DO EQUIPAMENTO (js/icaragente.js): a caixa de cada peça VISÍVEL (motor), sem as de `fora`, só as que tocam a
     região em planta {min:[x,y], max:[x,y]}. Barato de propósito: o agente confere milhares de posições contra elas — a
     malha triangulada fica para o "Verificar o caminho" (icColisoes). tipo/nome vão junto para a tela tirar o terreno. */
  function icCaixas(fora, regiao) {
    var foraSet = {}; (fora || []).forEach(function (u) { foraSet[u] = 1; });
    modelRoot.updateMatrixWorld(true);
    var invRoot = new THREE.Matrix4().copy(modelRoot.matrixWorld).invert(), out = [], b3 = new THREE.Box3(), tmp = new THREE.Box3();
    (S.elementos || []).forEach(function (el) {
      if (foraSet[el.uid]) return;
      var ms = malhasDaPeca(el.uid).filter(function (m) { return m.isMesh && m.visible && cadeiaVisivel(m) && m.geometry; });
      if (!ms.length) return;
      b3.makeEmpty();
      ms.forEach(function (m) { m.updateMatrixWorld(true); if (!m.geometry.boundingBox) m.geometry.computeBoundingBox(); tmp.copy(m.geometry.boundingBox).applyMatrix4(new THREE.Matrix4().multiplyMatrices(invRoot, m.matrixWorld)); b3.union(tmp); });
      var mn = icMotorArr(b3.min), mx = icMotorArr(b3.max), a = [Math.min(mn[0], mx[0]), Math.min(mn[1], mx[1]), Math.min(mn[2], mx[2])], b = [Math.max(mn[0], mx[0]), Math.max(mn[1], mx[1]), Math.max(mn[2], mx[2])];
      if (regiao && (a[0] > regiao.max[0] || b[0] < regiao.min[0] || a[1] > regiao.max[1] || b[1] < regiao.min[1])) return;
      out.push({ id: el.uid, nome: el.nomeIfc || el.nome || el.familia || el.uid, tipo: el.tipo || '', min: a, max: b });
    });
    (icar.entorno || []).forEach(function (e) {
      var a = e.aabb.min, b = e.aabb.max; if (foraSet[e.id]) return;
      if (regiao && (a[0] > regiao.max[0] || b[0] < regiao.min[0] || a[1] > regiao.max[1] || b[1] < regiao.min[1])) return;
      out.push({ id: e.id, nome: e.nome, tipo: 'ENTORNO', min: a.slice(), max: b.slice() });
    });
    return out;
  }
  function icObstaculos(fora, caixaCaminho, invRoot) {
    var foraSet = {}; (fora || []).forEach(function (u) { foraSet[u] = 1; });
    var out = [], v = new THREE.Vector3(), b3 = new THREE.Box3(), tmp = new THREE.Box3();
    (S.elementos || []).forEach(function (el) {
      if (foraSet[el.uid]) return;
      var ms = malhasDaPeca(el.uid).filter(function (m) { return m.isMesh && m.visible && cadeiaVisivel(m) && m.geometry; });
      if (!ms.length) return;
      b3.makeEmpty();
      ms.forEach(function (m) { m.updateMatrixWorld(true); if (!m.geometry.boundingBox) m.geometry.computeBoundingBox(); tmp.copy(m.geometry.boundingBox).applyMatrix4(new THREE.Matrix4().multiplyMatrices(invRoot, m.matrixWorld)); b3.union(tmp); });
      var mn = icMotorArr(b3.min), mx = icMotorArr(b3.max), aabb = { min: [Math.min(mn[0], mx[0]), Math.min(mn[1], mx[1]), Math.min(mn[2], mx[2])], max: [Math.max(mn[0], mx[0]), Math.max(mn[1], mx[1]), Math.max(mn[2], mx[2])] };
      if (caixaCaminho && !(aabb.min[0] <= caixaCaminho.max[0] && aabb.max[0] >= caixaCaminho.min[0] && aabb.min[1] <= caixaCaminho.max[1] && aabb.max[1] >= caixaCaminho.min[1] && aabb.min[2] <= caixaCaminho.max[2] && aabb.max[2] >= caixaCaminho.min[2])) return;
      var tris = [];
      ms.forEach(function (m) {
        var g = m.geometry, pos = g.attributes.position, idx = g.index, M = new THREE.Matrix4().multiplyMatrices(invRoot, m.matrixWorld), n = idx ? idx.count : pos.count;
        for (var i = 0; i < n; i++) { v.fromBufferAttribute(pos, idx ? idx.getX(i) : i).applyMatrix4(M); tris.push(v.x, -v.z, v.y); }
      });
      out.push({ id: el.uid, nome: el.nomeIfc || el.nome || el.familia || el.uid, aabb: aabb, tris: tris });
    });
    return out;
  }
  /* VISÃO DO OPERADOR (js/icarcolisao.js visada): as peças perto da linha olho → alvo (menos as içadas) + o entorno aceito */
  function icVisada(o) {
    if (!window.IcarColisao || !IcarColisao.visada) return { ok: false, erro: 'motor de colisões não carregado' };
    if (!o || !o.olho || !o.alvo) return { ok: false, erro: 'sem o olho ou o alvo' };
    modelRoot.updateMatrixWorld(true);
    var invRoot = new THREE.Matrix4().copy(modelRoot.matrixWorld).invert(), a = [+o.olho.x, +o.olho.y, +o.olho.z], b = [+o.alvo.x, +o.alvo.y, +o.alvo.z];
    var cx = { min: [Math.min(a[0], b[0]) - 0.5, Math.min(a[1], b[1]) - 0.5, Math.min(a[2], b[2]) - 0.5], max: [Math.max(a[0], b[0]) + 0.5, Math.max(a[1], b[1]) + 0.5, Math.max(a[2], b[2]) + 0.5] };
    var obst = icObstaculos(o.uids || [], cx, invRoot);
    (icar.entorno || []).forEach(function (e) { var q = e.aabb; if (q.min[0] <= cx.max[0] && q.max[0] >= cx.min[0] && q.min[1] <= cx.max[1] && q.max[1] >= cx.min[1] && q.min[2] <= cx.max[2] && q.max[2] >= cx.min[2]) obst.push(e); });
    var r = IcarColisao.visada(a, b, obst, { folgaAlvo: o.folgaAlvo });
    r.ok = true; r.olho = { x: a[0], y: a[1], z: a[2] }; r.alvo = { x: b[0], y: b[1], z: b[2] }; r.obstaculos = obst.length;
    return r;
  }
  function icColisoes(opts) {
    opts = opts || {};
    var q = icar.equip, si = icar.sim;
    if (!q || !q.ge || !si || !window.IcarColisao) return { ok: false, erro: !q || !q.ge ? 'equipamento articulado não desenhado' : !si ? 'sem a simulação' : 'motor de colisões não carregado' };
    icSincronizar();
    var invG = new THREE.Matrix4().copy(icar.grupo.matrixWorld).invert(), invRoot = new THREE.Matrix4().copy(modelRoot.matrixWorld).invert();
    var N = Math.max(6, Math.min(120, +opts.amostras || 60)), amostras = [], t0 = performance.now(), tVolta = si.t;
    for (var k = 0; k <= N; k++) {
      var t = k / N, M = si.estado(t);
      si.fantasma.matrix.copy(M); si.fantasma.matrixWorldNeedsUpdate = true;
      icPoseGerada(si.gD.clone().applyMatrix4(M), si.pD.map(function (p) { return p.clone().applyMatrix4(M); }));
      amostras.push({ t: t, partes: icPartesAgora(invG) });
    }
    /* a caixa do caminho inteiro (todas as partes, todos os instantes) + folga */
    var folga = +opts.folga >= 0 ? +opts.folga : 0.5, cx = { min: [Infinity, Infinity, Infinity], max: [-Infinity, -Infinity, -Infinity] };
    amostras.forEach(function (am) { am.partes.forEach(function (pt) { var b = IcarColisao.aabbParte(pt, folga); for (var i = 0; i < 3; i++) { cx.min[i] = Math.min(cx.min[i], b.min[i]); cx.max[i] = Math.max(cx.max[i], b.max[i]); } }); });
    var obst = icObstaculos(opts.uids || [], cx, invRoot);
    /* o entorno aceito da planta (prédios e muros do vizinho) também é obstáculo do caminho */
    (icar.entorno || []).forEach(function (e) {
      var a = e.aabb; if (a.min[0] <= cx.max[0] && a.max[0] >= cx.min[0] && a.min[1] <= cx.max[1] && a.max[1] >= cx.min[1] && a.min[2] <= cx.max[2] && a.max[2] >= cx.min[2]) obst.push(e);
    });
    /* contato esperado: o que a CARGA e as LINGAS tocam no primeiro e no último instante */
    var ignorar = {};
    [amostras[0], amostras[amostras.length - 1]].forEach(function (am) {
      var r0 = IcarColisao.verificar([{ t: am.t, partes: am.partes.filter(function (pt) { return pt.quem === 'carga' || /^linga/.test(pt.quem); }) }], obst, [], { folga: 0.02 });
      r0.eventos.forEach(function (ev) { (ignorar[ev.quem] = ignorar[ev.quem] || []).indexOf(ev.id) < 0 && ignorar[ev.quem].push(ev.id); });
    });
    var res = IcarColisao.verificar(amostras, obst, opts.redes || [], { folga: folga, ignorar: ignorar });
    res.ok = true; res.amostras = amostras.length; res.obstaculos = obst.length; res.ms = Math.round(performance.now() - t0); res.ignorados = ignorar;
    /* para o teste e para conferir à mão: o que entrou como obstáculo e as partes no último instante */
    if (opts.debug) res.debug = { obst: obst.map(function (o) { return { nome: o.nome, id: o.id, aabb: o.aabb, ntri: o.tris.length / 9 }; }), caixa: cx, ultimo: amostras[amostras.length - 1].partes.map(function (pt) { return { quem: pt.quem, obb: pt.obb || null, a: pt.a || null, b: pt.b || null }; }),
      elementos: (S.elementos || []).filter(function (e) { return /^p3d/.test(e.uid); }).map(function (e) { return { uid: e.uid, malhas: malhasDaPeca(e.uid).length, vis: malhasDaPeca(e.uid).map(function (m) { return m.visible && cadeiaVisivel(m); }) }; }) };
    /* volta a pose ao instante em que a simulação estava */
    si.t = tVolta; si.passo();
    icar.colisao = res;
    return res;
  }

  /* o grupo segue o modelo — a cada quadro e logo depois de desenhar (a foto do plano sai antes do próximo quadro) */
  function icSincronizar() { modelRoot.updateMatrixWorld(); icar.grupo.matrix.copy(modelRoot.matrixWorld); icar.grupo.matrixWorldNeedsUpdate = true; icar.grupo.updateMatrixWorld(true); }
  /* MAPA DO AGENTE (js/icaragente.js): um quadrado por ponto da grade — verde = o equipamento sugerido atende TODOS os
     içamentos dali e cabe; âmbar = cabe mas atende só parte; cinza = a tabela atende mas o caminhão não cabe.
     ⚠ GRUPO PRÓPRIO, fora do icar.grupo: o icLimpar (a cada redesenho do equipamento) não o apaga, a foto do plano não o
       enquadra nem o fotografa, e ele aparece ANTES de haver posição marcada (é ele que ajuda a escolher a posição). */
  var icMapaG = new THREE.Group(); icMapaG.name = 'agente-mapa-g'; icMapaG.matrixAutoUpdate = false; scene.add(icMapaG);
  S._tickExtra.push(function () { if (!icMapaG.children.length) return; modelRoot.updateMatrixWorld(); icMapaG.matrix.copy(modelRoot.matrixWorld); icMapaG.matrixWorldNeedsUpdate = true; });
  function icMapa(mp) {
    while (icMapaG.children.length) { var o = icMapaG.children.pop(); icDescartar(o); }
    if (!mp || !mp.pontos || !mp.pontos.length) return { ok: true, n: 0 };
    var lado = Math.max(0.2, (+mp.passo || 1) * 0.9), nM = mp.pontos.length, yM = icL({ x: 0, y: 0, z: +mp.z || 0 }).y + 0.035;
    var gM = new THREE.PlaneGeometry(lado, lado); gM.rotateX(-Math.PI / 2);
    var imM = new THREE.InstancedMesh(gM, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.42, depthWrite: false, side: THREE.DoubleSide }), nM);
    var mtx = new THREE.Matrix4(), corM = new THREE.Color(), contM = { verde: 0, ambar: 0, cinza: 0 };
    mp.pontos.forEach(function (q, i) {
      var v = icL({ x: q.x, y: q.y, z: 0 }); mtx.makeTranslation(v.x, yM, v.z); imM.setMatrixAt(i, mtx);
      var k = !q.cabe ? 'cinza' : q.n >= mp.total ? 'verde' : 'ambar'; contM[k]++;
      corM.setHex(k === 'verde' ? 0x16a34a : k === 'ambar' ? 0xeab308 : 0x9ca3af); imM.setColorAt(i, corM);
    });
    imM.instanceMatrix.needsUpdate = true; if (imM.instanceColor) imM.instanceColor.needsUpdate = true;
    imM.name = 'agente-mapa'; imM.userData.contagem = contM; imM.renderOrder = 990; icMapaG.add(imM);
    modelRoot.updateMatrixWorld(); icMapaG.matrix.copy(modelRoot.matrixWorld); icMapaG.matrixWorldNeedsUpdate = true;
    return { ok: true, n: nM, contagem: contM };
  }
  /* PLANTA DO PROJETO (PDF/DXF) e ENTORNO (volumes aceitos do agente da volumetria) — ESPEC §II.6; js/icarplanta.js.
     Grupo próprio, como o mapa: o redesenho do equipamento não apaga, e a planta aparece antes de haver equipamento.
     ⚠ A planta vai a 5 mm acima da cota, com polygonOffset puxando para a câmera: o terreno no mesmo nível não a esconde, e o que
       SOBE do nível (pilar, parede, laje de cima) fica por cima — só o piso no próprio nível recebe a transparência.
     ⚠ Os volumes ACEITOS entram como obstáculo: no "Verificar o caminho" (triângulos) e no agente do equipamento (caixas). As
       PROPOSTAS (laranja) não — ainda não são do plano. */
  var icPlantaG = new THREE.Group(); icPlantaG.name = 'planta-g'; icPlantaG.matrixAutoUpdate = false; scene.add(icPlantaG);
  S._tickExtra.push(function () { if (!icPlantaG.children.length) return; modelRoot.updateMatrixWorld(); icPlantaG.matrix.copy(modelRoot.matrixWorld); icPlantaG.matrixWorldNeedsUpdate = true; });
  /* planta (px, py, pz) → cena local: motor = s·R(r)·p + t; local = (x, cota + pz, −y). Rotação própria (det = s² > 0), sem espelho */
  function icMatPlanta(cal, cota) {
    var c = Math.cos(cal.r), sn = Math.sin(cal.r), s = cal.s;
    return new THREE.Matrix4().set(s * c, -s * sn, 0, cal.t.x, 0, 0, 1, cota, -s * sn, -s * c, 0, -cal.t.y, 0, 0, 0, 1);
  }
  var IC_M_MOTOR = new THREE.Matrix4().set(1, 0, 0, 0, 0, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 1);   // motor (x, y, z) → local (x, z, −y)
  /* a textura da fachada: 1 quadro = 3 m × 3 m (um pavimento), reboco claro e uma janela de 1,2 × 1,4 m com peitoril a 1 m */
  /* MATERIAIS DO CENÁRIO SEM ARQUIVO (como a fachada): asfalto e grama com grão, semente fixa. A UV do ShapeGeometry é em METROS,
     então a textura repete a cada `passo` m. ⚠ Compartilhadas (texCompartilhada): o descarte do redesenho não as destrói. */
  var icTexs = {};
  function icTexGrao(nome, base, cores, passo) {
    if (!icTexs[nome]) {
      var cv = document.createElement('canvas'); cv.width = 128; cv.height = 128;
      var x = cv.getContext('2d'), s = 7;
      function rnd() { s = (s * 16807) % 2147483647; return s / 2147483647; }
      x.fillStyle = base; x.fillRect(0, 0, 128, 128);
      for (var i = 0; i < 2600; i++) { x.globalAlpha = 0.3 + 0.45 * rnd(); x.fillStyle = cores[Math.floor(rnd() * cores.length)]; x.fillRect(Math.floor(rnd() * 128), Math.floor(rnd() * 128), 1 + Math.floor(rnd() * 2), 1 + Math.floor(rnd() * 2)); }
      x.globalAlpha = 1;
      var t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(1 / passo, 1 / passo);
      icTexs[nome] = t;
    }
    return icTexs[nome];
  }
  function icMatGrao(nome, base, cores, passo, extra) {
    var o = { map: icTexGrao(nome, base, cores, passo), roughness: 0.95, metalness: 0 };
    for (var k in extra || {}) o[k] = extra[k];
    var m = new THREE.MeshStandardMaterial(o); m.userData.texCompartilhada = true; m.userData.grao = nome; return m;
  }
  var icTexFachada = null;
  function icFachada() {
    if (!icTexFachada) {
      var cv = document.createElement('canvas'); cv.width = 128; cv.height = 128;
      var x = cv.getContext('2d'); x.fillStyle = '#e7e2d6'; x.fillRect(0, 0, 128, 128);
      var k = 128 / 3; x.fillStyle = '#5b6b7a'; x.fillRect(0.9 * k, 128 - 2.4 * k, 1.2 * k, 1.4 * k);
      x.fillStyle = '#cfd8e3'; x.fillRect(0.9 * k + 2, 128 - 2.4 * k + 2, 1.2 * k - 4, 3);
      icTexFachada = new THREE.CanvasTexture(cv); icTexFachada.wrapS = icTexFachada.wrapT = THREE.RepeatWrapping; icTexFachada.repeat.set(1 / 3, 1 / 3);
    }
    var m = new THREE.MeshStandardMaterial({ map: icTexFachada, roughness: 0.85, metalness: 0, side: THREE.DoubleSide });
    m.userData.fachada = true; m.userData.texCompartilhada = true; return m;
  }
  icar.entorno = [];
  function icPlanta(cfg) {
    while (icPlantaG.children.length) { var o = icPlantaG.children.pop(); icDescartar(o); }
    icar.entorno = [];
    var out = { ok: true, plano: false, linhas: 0, volumes: 0, propostas: 0, agua: 0 };
    if (!cfg) return out;
    var op = cfg.opacidade == null ? 0.6 : Math.max(0, Math.min(1, +cfg.opacidade));
    if (cfg.cal && (cfg.imagem || (cfg.segmentos && cfg.segmentos.length))) {
      if (cfg.imagem && cfg.largura > 0 && cfg.altura > 0) {
        var tx = cfg.imagem.getContext ? new THREE.CanvasTexture(cfg.imagem) : new THREE.Texture(cfg.imagem); tx.needsUpdate = true;
        var gP = new THREE.PlaneGeometry(+cfg.largura, +cfg.altura); gP.translate(+cfg.largura / 2, +cfg.altura / 2, 0);
        var mP = new THREE.Mesh(gP, new THREE.MeshBasicMaterial({ map: tx, transparent: true, opacity: op, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -4 }));
        mP.matrixAutoUpdate = false; mP.matrix.copy(icMatPlanta(cfg.cal, (+cfg.cota || 0) + 0.005)); mP.name = 'planta-imagem'; mP.renderOrder = 1; icPlantaG.add(mP); out.plano = true;
      }
      if (cfg.segmentos && cfg.segmentos.length && !cfg.imagem) {
        var sg = cfg.segmentos, arr = new Float32Array(sg.length * 6);
        sg.forEach(function (s, i) { arr[i * 6] = s.x1; arr[i * 6 + 1] = s.y1; arr[i * 6 + 2] = 0; arr[i * 6 + 3] = s.x2; arr[i * 6 + 4] = s.y2; arr[i * 6 + 5] = 0; });
        var gL = new THREE.BufferGeometry(); gL.setAttribute('position', new THREE.BufferAttribute(arr, 3));
        var lL = new THREE.LineSegments(gL, new THREE.LineBasicMaterial({ color: 0x334155, transparent: true, opacity: Math.max(0.35, op), depthWrite: false }));
        lL.matrixAutoUpdate = false; lL.matrix.copy(icMatPlanta(cfg.cal, (+cfg.cota || 0) + 0.01)); lL.name = 'planta-linhas'; lL.renderOrder = 1; icPlantaG.add(lL); out.linhas = sg.length;
      }
    }
    (cfg.volumes || []).forEach(function (v, i) {
      var pts = v.poligono; if (!pts || pts.length < 3) return;
      var agua = v.tipo === 'agua', alt = agua ? 0.05 : Math.max(0.05, +v.altura || 0), base = +v.base || 0;
      var gV = new THREE.ExtrudeGeometry(new THREE.Shape(pts.map(function (q) { return new THREE.Vector2(+q[0], +q[1]); })), { depth: alt, bevelEnabled: false });
      gV.translate(0, 0, base);
      /* prédio ACEITO: fachada com janelas por pavimento (3 m) nas paredes e telhado à parte — o ExtrudeGeometry põe as tampas no
         grupo 0 e as paredes no grupo 1, com UV em METROS nas paredes (a textura repete a cada 3 m) */
      var mat = v.proposta ? new THREE.MeshBasicMaterial({ color: 0xf97316, transparent: true, opacity: 0.35, depthWrite: false, side: THREE.DoubleSide })
        : agua ? new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.55, depthWrite: false, side: THREE.DoubleSide })
        : v.tipo === 'edificacao' ? [icMat(0x9ca3af, 0.95), icFachada()] : v.tipo === 'muro' ? icMat(0xa8a29e, 0.95) : icMat(0xcbd5e1, 0.92);
      var mV = new THREE.Mesh(gV, mat); mV.matrixAutoUpdate = false; mV.matrix.copy(IC_M_MOTOR); mV.name = v.proposta ? 'planta-proposta' : agua ? 'entorno-agua' : 'entorno'; mV.userData.idx = i; icPlantaG.add(mV);
      var eV = new THREE.LineSegments(new THREE.EdgesGeometry(gV), new THREE.LineBasicMaterial({ color: v.proposta ? 0xc2410c : agua ? 0x0284c7 : 0x64748b }));
      eV.matrixAutoUpdate = false; eV.matrix.copy(IC_M_MOTOR); icPlantaG.add(eV);
      if (v.proposta) { out.propostas++; return; }
      if (agua) { out.agua++; return; }
      out.volumes++;
      /* o volume aceito vira obstáculo: triângulos e caixa no referencial do MOTOR (a geometria já está nele) */
      var pa = gV.attributes.position, tris = [], mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity], idx = gV.index, nT = idx ? idx.count : pa.count;
      for (var k = 0; k < nT; k++) { var j = idx ? idx.getX(k) : k, x = pa.getX(j), y = pa.getY(j), z = pa.getZ(j); tris.push(x, y, z); if (x < mn[0]) mn[0] = x; if (y < mn[1]) mn[1] = y; if (z < mn[2]) mn[2] = z; if (x > mx[0]) mx[0] = x; if (y > mx[1]) mx[1] = y; if (z > mx[2]) mx[2] = z; }
      icar.entorno.push({ id: 'entorno:' + (v.id || i), nome: v.nome || ('Entorno ' + (i + 1)), aabb: { min: mn, max: mx }, tris: tris });
    });
    /* o LIMITE do terreno/acesso do agente do equipamento (verde tracejado; aberto enquanto se marca) */
    if (cfg.limite && cfg.limite.length >= 2) {
      var yLi = icL({ x: 0, y: 0, z: +cfg.cotaLimite || 0 }).y + 0.04, ptsLi = cfg.limite.map(function (q) { return icL({ x: +q[0], y: +q[1], z: 0 }).setY(yLi); });
      var lnLi = icLinha(cfg.limiteAberto ? ptsLi : ptsLi.concat([ptsLi[0]]), 0x16a34a, 0.4); lnLi.name = 'agente-limite'; icPlantaG.add(lnLi); out.limite = cfg.limite.length;
    }
    modelRoot.updateMatrixWorld(); icPlantaG.matrix.copy(modelRoot.matrixWorld); icPlantaG.matrixWorldNeedsUpdate = true;
    return out;
  }
  /* o ponto da planta (unidades dela) onde a MALHA desenhada o põe, no motor — gancho de teste: prova que o desenho segue a calibração */
  function icPlantaPonto(px, py) {
    var m = icPlantaG.getObjectByName('planta-imagem') || icPlantaG.getObjectByName('planta-linhas'); if (!m) return null;
    var v = new THREE.Vector3(px, py, 0).applyMatrix4(m.matrix); return icM(v);
  }
  /* LOCAL DA OBRA — ESPEC §II.10.8 (js/icargeo.js, js/icarentorno.js, js/icarclima.js). Dois grupos próprios, como a planta:
     icLocalG (no referencial do modelo) com o relevo, as ruas, as áreas verdes, os postes e as redes SUGERIDAS pelo mapa; e
     icLocalMundo (na cena) com a chuva e a seta do vento. Mais o SOL da hora escolhida e a NEBLINA.
     ⚠ Nada daqui é obstáculo nem entra no "Verificar o caminho": o que conta é o que a pessoa ACEITA (p.entorno e p.redes,
       desenhados pelo icPlanta e pelo icDesenhar). A rede sugerida vai no chão, tracejada: a altura dos cabos o mapa não tem.
     ⚠ O sol MOVE a direcional principal e a devolve ao lugar quando sai (sol: null); a neblina guarda e devolve o scene.fog.
       Sem a devolução, a cena ficava escura depois de simular o fim da tarde e nunca mais voltava. */
  var icLocalG = new THREE.Group(); icLocalG.name = 'local-g'; icLocalG.matrixAutoUpdate = false; scene.add(icLocalG);
  var icLocalMundo = new THREE.Group(); icLocalMundo.name = 'local-mundo'; scene.add(icLocalMundo);
  var icLocalEst = { chuva: null, nevoa: undefined, nevoaVis: 0, sol: null };
  function icLocalCaixa() {
    var b = new THREE.Box3(); modelRoot.updateMatrixWorld(); try { b.setFromObject(modelRoot); } catch (_) {}
    if (b.isEmpty()) b.set(new THREE.Vector3(-10, 0, -10), new THREE.Vector3(10, 10, 10));
    return b;
  }
  /* direção no motor (x, y, z) → direção no mundo (o modelo pode estar girado na cena) */
  function icMotorDirMundo(mx, my, mz) { modelRoot.updateMatrixWorld(); return icL({ x: mx, y: my, z: mz }).transformDirection(modelRoot.matrixWorld); }
  /* leste/norte (ENU) → motor, girando pelo norte do modelo (o mesmo de IcarGeo.paraMotor) */
  function icEnuMotor(e, n, norte) { var t = (+norte || 0) * Math.PI / 180; return { x: e * Math.cos(t) - n * Math.sin(t), y: e * Math.sin(t) + n * Math.cos(t) }; }
  function icLocal(cfg) {
    while (icLocalG.children.length) icDescartar(icLocalG.children.pop());
    while (icLocalMundo.children.length) icDescartar(icLocalMundo.children.pop());
    icLocalEst.chuva = null;
    cfg = cfg || {};
    var out = { ok: true, imagem: false, relevo: 0, ruas: 0, verdes: 0, postes: 0, redes: 0, sol: false, neblina: false, chuva: 0, vento: false };
    /* satélite no chão: quadrilátero pelos 4 cantos do mosaico (NO, NE, SE, SO) já no motor — js/icarentorno.js cantosImagem */
    var im = cfg.imagem;
    if (im && im.canvas && im.cantos && im.cantos.length === 4) {
      var zI = (+im.z || 0) + 0.004, c4 = im.cantos, gI = new THREE.BufferGeometry();
      gI.setAttribute('position', new THREE.Float32BufferAttribute([+c4[0][0], +c4[0][1], zI, +c4[1][0], +c4[1][1], zI, +c4[2][0], +c4[2][1], zI, +c4[3][0], +c4[3][1], zI], 3));
      gI.setAttribute('uv', new THREE.Float32BufferAttribute([0, 1, 1, 1, 1, 0, 0, 0], 2)); gI.setIndex([0, 3, 2, 0, 2, 1]);
      var tI = new THREE.CanvasTexture(im.canvas); tI.needsUpdate = true;
      var mI = new THREE.Mesh(gI, new THREE.MeshBasicMaterial({ map: tI, transparent: true, opacity: im.opacidade == null ? 0.9 : +im.opacidade, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 2 }));
      mI.matrixAutoUpdate = false; mI.matrix.copy(IC_M_MOTOR); mI.name = 'local-imagem'; mI.renderOrder = 0; icLocalG.add(mI); out.imagem = true;
    }
    /* o LEVANTAMENTO da obra (js/icarrelevo.js): o chão que vale no lote — mais opaco que o relevo de satélite, e as curvas de nível */
    var lv = cfg.levantamento;
    if (lv && lv.pos && lv.idx && lv.pos.length >= 9) {
      var gL2 = new THREE.BufferGeometry(); gL2.setAttribute('position', new THREE.Float32BufferAttribute(lv.pos, 3)); gL2.setIndex(lv.idx); gL2.computeVertexNormals();
      var mL2 = new THREE.Mesh(gL2, new THREE.MeshStandardMaterial({ color: 0xb59466, roughness: 0.95, metalness: 0, transparent: true, opacity: 0.72, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 2 }));
      mL2.matrixAutoUpdate = false; mL2.matrix.copy(IC_M_MOTOR); mL2.name = 'local-levantamento'; icLocalG.add(mL2); out.levantamento = lv.pos.length / 3;
    }
    if (cfg.curvas && cfg.curvas.length) {
      var arrC = new Float32Array(cfg.curvas.length * 6);
      cfg.curvas.forEach(function (s, i) { arrC[i * 6] = s[0]; arrC[i * 6 + 1] = s[1]; arrC[i * 6 + 2] = s[4] + 0.02; arrC[i * 6 + 3] = s[2]; arrC[i * 6 + 4] = s[3]; arrC[i * 6 + 5] = s[4] + 0.02; });
      var gC2 = new THREE.BufferGeometry(); gC2.setAttribute('position', new THREE.BufferAttribute(arrC, 3));
      var lC2 = new THREE.LineSegments(gC2, new THREE.LineBasicMaterial({ color: 0x6b4f2a, transparent: true, opacity: 0.85, depthWrite: false }));
      lC2.matrixAutoUpdate = false; lC2.matrix.copy(IC_M_MOTOR); lC2.name = 'local-curvas'; lC2.renderOrder = 2; icLocalG.add(lC2); out.curvas = cfg.curvas.length;
    }
    var rl = cfg.relevo;
    if (rl && rl.pos && rl.idx && rl.pos.length >= 9) {
      var gR = new THREE.BufferGeometry(); gR.setAttribute('position', new THREE.Float32BufferAttribute(rl.pos, 3)); gR.setIndex(rl.idx); gR.computeVertexNormals();
      var mR = new THREE.Mesh(gR, new THREE.MeshStandardMaterial({ color: 0x9ca38f, roughness: 0.95, metalness: 0, transparent: true, opacity: 0.5, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: 2, polygonOffsetUnits: 4 }));
      mR.matrixAutoUpdate = false; mR.matrix.copy(IC_M_MOTOR); mR.name = 'local-relevo'; icLocalG.add(mR);
      var wR = new THREE.LineSegments(new THREE.WireframeGeometry(gR), new THREE.LineBasicMaterial({ color: 0x6b7280, transparent: true, opacity: 0.16, depthWrite: false }));
      wR.matrixAutoUpdate = false; wR.matrix.copy(IC_M_MOTOR); icLocalG.add(wR);
      out.relevo = rl.pos.length / 3;
    }
    function polilinha(pts, cor, nome, fechar, trac) {
      var v = pts.map(function (q) { return icL({ x: +q[0], y: +q[1], z: (q[2] != null ? +q[2] : 0) + 0.03 }); }); if (v.length < 2) return null;
      if (fechar) v.push(v[0].clone());
      var l = icLinha(v, cor, trac || null); l.material.depthTest = true; l.renderOrder = 1; l.name = nome; icLocalG.add(l); return l;
    }
    (cfg.ruas || []).forEach(function (r) {
      /* a faixa de asfalto na largura da via (a do mapa, ou a da classe — premissa) por baixo do eixo */
      if (r.faixa && r.faixa.length >= 4) {
        var gF = new THREE.ShapeGeometry(new THREE.Shape(r.faixa.map(function (q) { return new THREE.Vector2(+q[0], +q[1]); })));
        gF.translate(0, 0, (+r.z || 0) + 0.015);
        var mF = new THREE.Mesh(gF, icMatGrao('asfalto', '#2e3236', ['#1d2024', '#3c4045', '#282b2f', '#4a4e53'], 4, { roughness: 0.92, transparent: true, opacity: 0.92, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -2 }));
        mF.matrixAutoUpdate = false; mF.matrix.copy(IC_M_MOTOR); mF.name = 'local-rua-faixa'; icLocalG.add(mF); out.faixas = (out.faixas || 0) + 1;
      }
      if (polilinha(r.pontos || [], r.faixa ? 0xe5e7eb : 0x475569, 'local-rua', false, r.faixa ? 1.5 : 0)) out.ruas++;
    });
    /* árvores DECORATIVAS nas praças e gramados (js/icarentorno.js arvores): instanciadas — 300 árvores = 2 desenhos */
    var arv = cfg.arvores || [];
    if (arv.length) {
      var gT = new THREE.CylinderGeometry(0.12, 0.16, 2.2, 6); gT.translate(0, 1.1, 0);
      var gCp = new THREE.SphereGeometry(1.6, 8, 6); gCp.translate(0, 3.4, 0);
      var iT = new THREE.InstancedMesh(gT, new THREE.MeshStandardMaterial({ color: 0x6b4423, roughness: 1 }), arv.length), iC = new THREE.InstancedMesh(gCp, new THREE.MeshStandardMaterial({ color: 0x4d7c3a, roughness: 1 }), arv.length);
      var mm = new THREE.Matrix4(), qq = new THREE.Quaternion(), ss = new THREE.Vector3();
      arv.forEach(function (a, i) { var pz = icL({ x: +a.x, y: +a.y, z: +a.z || 0 }), e = +a.escala || 1; ss.set(e, e, e); mm.compose(pz, qq, ss); iT.setMatrixAt(i, mm); iC.setMatrixAt(i, mm); });
      iT.name = 'local-arvores'; iC.name = 'local-arvores-copa'; icLocalG.add(iT); icLocalG.add(iC); out.arvores = arv.length;
    }
    (cfg.verdes || []).forEach(function (r) {
      /* o gramado preenchido (grão de grama a cada 3 m) por baixo do contorno — na cota média do polígono */
      var pg = r.poligono || [];
      if (pg.length >= 3) {
        var zg = 0; pg.forEach(function (q) { zg += q[2] != null ? +q[2] : 0; });
        var gG = new THREE.ShapeGeometry(new THREE.Shape(pg.map(function (q) { return new THREE.Vector2(+q[0], +q[1]); })));
        gG.translate(0, 0, zg / pg.length + 0.012);
        var mG = new THREE.Mesh(gG, icMatGrao('grama', '#5e8a3a', ['#4a7330', '#6f9c45', '#3f6428', '#83ad52'], 3, { transparent: true, opacity: 0.92, side: THREE.DoubleSide, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 }));
        mG.matrixAutoUpdate = false; mG.matrix.copy(IC_M_MOTOR); mG.name = 'local-gramado'; icLocalG.add(mG); out.gramados = (out.gramados || 0) + 1;
      }
      if (polilinha(pg, 0x16a34a, 'local-verde', true)) out.verdes++;
    });
    (cfg.redes || []).forEach(function (r) { if (r.a && r.b && polilinha([r.a, r.b], 0xeab308, 'local-rede', false, 0.6)) out.redes++; });
    (cfg.postes || []).forEach(function (p) {
      /* marcador, não o poste: a altura dele o mapa não tem */
      var gP = new THREE.CylinderGeometry(0.12, 0.12, 1.5, 8); gP.translate(0, 0.75, 0);
      var mP = new THREE.Mesh(gP, icMat(0xca8a04)); mP.position.copy(icL({ x: +p.x, y: +p.y, z: +p.z || 0 })); mP.name = 'local-poste'; icLocalG.add(mP); out.postes++;
    });
    var sol = cfg.sol;
    if (sol && isFinite(+sol.elevacao) && isFinite(+sol.azimute)) {
      if (!icLocalEst.sol) icLocalEst.sol = { pos: dir.position.clone(), int: dir.intensity, hemi: hemi.intensity };
      var el = +sol.elevacao * Math.PI / 180, az = +sol.azimute * Math.PI / 180, q = icEnuMotor(Math.cos(el) * Math.sin(az), Math.cos(el) * Math.cos(az), sol.norte);
      var dS = icMotorDirMundo(q.x, q.y, Math.sin(el)).normalize();
      dir.position.copy(dir.target.position).addScaledVector(dS, 100);
      /* abaixo do horizonte: a luz cai para o resto da noite — e o hemisfério também, para a cena não ficar com cara de meio-dia */
      dir.intensity = el > 0 ? 0.3 + 0.8 * Math.min(1, Math.sin(el) * 2.5) : 0.05;
      hemi.intensity = el > 0 ? icLocalEst.sol.hemi : icLocalEst.sol.hemi * 0.45;
      out.sol = true; out.solDir = { x: dS.x, y: dS.y, z: dS.z };
    } else if (icLocalEst.sol) { dir.position.copy(icLocalEst.sol.pos); dir.intensity = icLocalEst.sol.int; hemi.intensity = icLocalEst.sol.hemi; icLocalEst.sol = null; }
    var cl = cfg.clima;
    if (cl && +cl.neblina >= 20) {
      if (icLocalEst.nevoa === undefined) icLocalEst.nevoa = scene.fog;
      icLocalEst.nevoaVis = +cl.neblina >= 80 ? 40 : +cl.neblina >= 50 ? 120 : 400;
      scene.fog = new THREE.Fog(0xd7dde3, 1, 1000); out.neblina = true;
    } else if (icLocalEst.nevoa !== undefined) { scene.fog = icLocalEst.nevoa; icLocalEst.nevoa = undefined; icLocalEst.nevoaVis = 0; }
    if (cl && +cl.chuva > 0.1) {
      var bx = icLocalCaixa(), c = bx.getCenter(new THREE.Vector3()), sz = bx.getSize(new THREE.Vector3()), R = Math.max(sz.x, sz.z) * 0.7 + 6, H = sz.y + 18;
      var nP = Math.min(6000, Math.round(500 + +cl.chuva * 500)), arr = new Float32Array(nP * 3);
      for (var k = 0; k < nP; k++) { arr[k * 3] = c.x + (Math.random() * 2 - 1) * R; arr[k * 3 + 1] = bx.min.y + Math.random() * H; arr[k * 3 + 2] = c.z + (Math.random() * 2 - 1) * R; }
      var gC = new THREE.BufferGeometry(); gC.setAttribute('position', new THREE.BufferAttribute(arr, 3));
      var pC = new THREE.Points(gC, new THREE.PointsMaterial({ color: 0x60a5fa, size: 2, sizeAttenuation: false, transparent: true, opacity: 0.75, depthWrite: false }));
      pC.name = 'local-chuva'; pC.userData = { y0: bx.min.y, y1: bx.min.y + H, v: 8 }; icLocalMundo.add(pC); icLocalEst.chuva = pC; out.chuva = nP;
    }
    if (cl && isFinite(+cl.ventoMs) && cl.ventoDir != null && isFinite(+cl.ventoDir)) {
      /* a seta aponta para ONDE o vento vai (a previsão diz de onde ele vem: + 180°), em cima do modelo */
      var bv = icLocalCaixa(), topo = new THREE.Vector3((bv.min.x + bv.max.x) / 2, bv.max.y + 3, (bv.min.z + bv.max.z) / 2), pr = (+cl.ventoDir + 180) * Math.PI / 180;
      var qv = icEnuMotor(Math.sin(pr), Math.cos(pr), cl.norte), dV = icMotorDirMundo(qv.x, qv.y, 0).normalize(), L = 3 + Math.min(20, +cl.ventoMs);
      var o0 = topo.clone().addScaledVector(dV, -L / 2), corV = cl.estado === 'bloqueado' ? 0xdc2626 : cl.estado === 'atencao' ? 0xd97706 : 0x0284c7;
      var aV = new THREE.ArrowHelper(dV, o0, L, corV, L * 0.25, L * 0.12); aV.name = 'local-vento'; icLocalMundo.add(aV);
      var sV = labelSprite('vento ' + Math.round(+cl.ventoMs) + ' m/s'); sV.position.copy(o0); icLocalMundo.add(sV); out.vento = true;
    }
    /* CÉU FÍSICO (Preetham — bim/vendor/Sky.js) com o sol da hora: só quando há sol calculado. Acompanha a câmera de CADA vista
       (onBeforeRender) e fica atrás de tudo; turvo com chuva ou neblina. ⚠ As fotos do plano (fundo branco) o escondem. */
    if (out.sol) {
      var ceu = new Sky(); ceu.name = 'local-ceu'; ceu.userData.foraDaFoto = true; ceu.frustumCulled = false; ceu.renderOrder = -10;
      var un = ceu.material.uniforms, turvo = !!(cl && (+cl.chuva > 0.1 || +cl.neblina >= 20));
      un.turbidity.value = turvo ? 14 : 4; un.rayleigh.value = turvo ? 0.6 : 1.6; un.mieCoefficient.value = 0.005; un.mieDirectionalG.value = 0.8;
      un.sunPosition.value.copy(dS);
      /* ⚠ PARADO NA ORIGEM e enorme (como o exemplo do three): o shader mede a direção a partir da ORIGEM (cameraPos = 0) e
         desenha no plano do fundo (z = w), sem corte pelo `far`. Seguir a câmera mostrava as quinas da caixa (medido na foto). */
      ceu.scale.setScalar(450000);
      icLocalMundo.add(ceu); out.ceu = true;
    }
    modelRoot.updateMatrixWorld(); icLocalG.matrix.copy(modelRoot.matrixWorld); icLocalG.matrixWorldNeedsUpdate = true;
    return out;
  }
  S._tickExtra.push(function (dt) {
    if (icLocalG.children.length) { modelRoot.updateMatrixWorld(); icLocalG.matrix.copy(modelRoot.matrixWorld); icLocalG.matrixWorldNeedsUpdate = true; }
    var ch = icLocalEst.chuva;
    if (ch) {
      var pa = ch.geometry.attributes.position, u = ch.userData, s = dt > 0 && dt < 0.25 ? dt : 0.016;
      for (var k = 0; k < pa.count; k++) { var y = pa.getY(k) - u.v * s; pa.setY(k, y < u.y0 ? u.y1 : y); }
      pa.needsUpdate = true;
    }
    /* a neblina acompanha a câmera: perto fica nítido, o que passa da visibilidade some (a distância da órbita muda com o zoom) */
    if (icLocalEst.nevoaVis && scene.fog) { var D = camera.position.distanceTo(orbit.target); scene.fog.near = D * 0.6; scene.fog.far = D + icLocalEst.nevoaVis; }
  });
  /* =====================================================================
   * 3D FOTORREALISTA DO GOOGLE (ESPEC §II.9.2) — Map Tiles API pelo 3d-tiles-renderer 0.3.40 (bim/vendor/3dtiles, Apache-2.0),
   * carregado por IMPORT DINÂMICO: quem não liga não baixa nada. A chave vem do servidor da RA (só para licença ativa) e vai em
   * cada pedido ao Google — é chave de navegador, restrita à Map Tiles API e com teto diário no console (quem paga é a RA).
   * ⚠ TERMOS (developers.google.com/maps/documentation/tile/policies, conferidos em 03/10/2026): o LOGO do Google Maps e os
   *   créditos dos blocos visíveis ficam SEMPRE na tela enquanto o 3D está ligado (o selo no canto); nada guardado para usar sem
   *   rede; o modelo pode ficar por cima, nada copiado dos blocos. O 3D do Google SAI das fotos do plano e do modo foto: os termos
   *   não dão permissão escrita para imagem estática impressa.
   * ⚠ POSIÇÃO: ECEF → motor por IcarGeo.matrizEcefMotor (a MESMA conta do mapa 2D, < 2 cm em 100 m) e a altura achada no chão do
   *   Google num anel em volta do modelo (quartil de baixo: telhado e árvore não puxam para cima), posta na cota do chão do modelo.
   * ⚠ RECORTE: a área do modelo (+3 m) sai do 3D do Google — senão a casa que existe hoje no lote atravessa o projeto.
   * ===================================================================== */
  var IC_G3_VENDOR = new URL('../bim/vendor/', import.meta.url).href, IC_G3_LOGO = new URL('../img/terceiros/GoogleMaps_Logo_WithDarkOutline.svg', import.meta.url).href;
  var icG3 = { on: false, mod: null, tiles: null, draco: null, cfg: null, zDesloc: 0, hChao: null, buscas: 0, ultBusca: 0, selo: null, erro: null, carregados: 0, planos: null, clipAntes: null, versao: 0, quadros: 0 };
  var icG3G = new THREE.Group(); icG3G.name = 'google-3d'; icG3G.matrixAutoUpdate = false; scene.add(icG3G);
  var icG3Ray = new THREE.Raycaster();
  function icG3Carregar() {
    if (icG3.mod) return Promise.resolve(icG3.mod);
    return Promise.all([import('../bim/vendor/3dtiles/three/TilesRenderer.js'), import('../bim/vendor/3dtiles/three/plugins/GoogleCloudAuthPlugin.js'),
      import('three/examples/jsm/loaders/GLTFLoader.js'), import('three/examples/jsm/loaders/DRACOLoader.js')])
      .then(function (m) { icG3.mod = { TilesRenderer: m[0].TilesRenderer, Auth: m[1].GoogleCloudAuthPlugin, GLTFLoader: m[2].GLTFLoader, DRACOLoader: m[3].DRACOLoader }; return icG3.mod; });
  }
  function icG3Matriz() {
    var c = icG3.cfg; if (!c || !window.IcarGeo) return;
    var M = new THREE.Matrix4().fromArray(IcarGeo.matrizEcefMotor({ lat: +c.lat, lon: +c.lon, x0: +c.x0 || 0, y0: +c.y0 || 0, norte: +c.norte || 0 }, icG3.zDesloc + (+c.ajuste || 0)));
    modelRoot.updateMatrixWorld();
    icG3G.matrix.copy(modelRoot.matrixWorld).multiply(IC_M_MOTOR).multiply(M); icG3G.matrixWorldNeedsUpdate = true; icG3G.updateMatrixWorld(true);
  }
  /* o recorte: 4 planos verticais em volta da caixa do modelo (+3 m) com clipIntersection — some só o que está DENTRO dos quatro */
  function icG3Planos() {
    var b = icLocalCaixa(), mg = 3;
    return [new THREE.Plane(new THREE.Vector3(1, 0, 0), -(b.max.x + mg)), new THREE.Plane(new THREE.Vector3(-1, 0, 0), b.min.x - mg),
      new THREE.Plane(new THREE.Vector3(0, 0, 1), -(b.max.z + mg)), new THREE.Plane(new THREE.Vector3(0, 0, -1), b.min.z - mg)];
  }
  function icG3RecorteEm(obj) {
    var pl = icG3.cfg && icG3.cfg.recortar !== false ? icG3.planos : null;
    obj.traverse(function (o) { if (!o.material) return; (Array.isArray(o.material) ? o.material : [o.material]).forEach(function (m) { m.clippingPlanes = pl; m.clipIntersection = true; m.needsUpdate = true; }); });
  }
  function icG3AplicarRecorte() { icG3.planos = icG3Planos(); if (icG3.tiles) icG3RecorteEm(icG3.tiles.group); }
  /* o chão do Google: 36 raios verticais em 3 anéis em volta do modelo; vale o 20º percentil (telhado e árvore não puxam para cima).
     ⚠ SÓ BLOCO FINO conta (erro geométrico até IC_G3_ERRO_MAX m): os primeiros blocos do Google são a Terra em poucos triângulos e o
       "chão" neles sai quilômetros fora — medido em 03/10/2026 com o Google de verdade: 2.020 m e depois 997 m, e deslocar o 3D
       por isso afastava a câmera da superfície e os blocos nunca refinavam. A 1ª altura vem da altitude do relevo (cfg.altitude). */
  var IC_G3_ERRO_MAX = 15;
  function icG3AcharChao() {
    var c = icG3.cfg, t = icG3.tiles; if (!c || !t) return false;
    var porCena = new Map(); if (t.visibleTiles) t.visibleTiles.forEach(function (tl) { if (tl && tl.cached && tl.cached.scene) porCena.set(tl.cached.scene, +tl.geometricError || 0); });
    function erroDo(o) { for (var q = o; q; q = q.parent) { if (porCena.has(q)) return porCena.get(q); } return Infinity; }
    var b = icLocalCaixa(), inv = new THREE.Matrix4().copy(modelRoot.matrixWorld).invert();
    var ctrM = icM(b.getCenter(new THREE.Vector3()).applyMatrix4(inv)), R = Math.max(10, b.getSize(new THREE.Vector3()).setY(0).length() / 2 + 5), zs = [];
    /* 3 anéis × 12 raios (R, 1,6R, 2,4R): no centro da cidade o anel de dentro pode cair todo em telhado — a rua aparece nos de fora */
    for (var k = 0; k < 36; k++) {
      var a = (k % 12) / 12 * Math.PI * 2 + Math.floor(k / 12) * 0.26, Rk = R * [1, 1.6, 2.4][Math.floor(k / 12)], px = ctrM.x + Rk * Math.cos(a), py = ctrM.y + Rk * Math.sin(a);
      var topo = icL({ x: px, y: py, z: (+c.zChao || 0) + 3000 }).applyMatrix4(modelRoot.matrixWorld), fundo = icL({ x: px, y: py, z: (+c.zChao || 0) - 3000 }).applyMatrix4(modelRoot.matrixWorld);
      icG3Ray.set(topo, fundo.clone().sub(topo).normalize()); icG3Ray.far = 6000;
      var hs = []; try { hs = icG3Ray.intersectObject(t.group, true); } catch (_) {}
      hs = hs.filter(function (h) { return erroDo(h.object) <= IC_G3_ERRO_MAX; });
      if (hs.length) { hs.sort(function (p, q) { return p.distance - q.distance; }); zs.push(icM(hs[0].point.clone().applyMatrix4(inv)).z); }
    }
    if (zs.length < 3) return false;
    zs.sort(function (p, q) { return p - q; });
    var zAchado = zs[Math.floor(zs.length * 0.2)], u = zAchado - (icG3.zDesloc + (+c.ajuste || 0));
    icG3.hChao = Math.round(u * 100) / 100; icG3.zDesloc = (+c.zChao || 0) - u; icG3.buscas++;
    return true;
  }
  function icG3Selo() {
    var el = icG3.selo;
    if (!el) {
      el = document.createElement('div'); el.setAttribute('data-google-selo', '1');
      el.style.cssText = 'position:absolute;left:8px;bottom:8px;z-index:6;display:none;align-items:center;gap:6px;padding:3px 8px;border-radius:6px;background:rgba(15,23,42,.6);color:#fff;font:11px/1.3 system-ui,sans-serif;pointer-events:none;max-width:72%';
      el.innerHTML = '<img alt="Google Maps" style="height:16px;width:auto;display:block" src="' + IC_G3_LOGO + '"><span data-g3-cred></span>';
      var pai = renderer.domElement.parentElement || document.body; if (pai !== document.body && getComputedStyle(pai).position === 'static') pai.style.position = 'relative';
      pai.appendChild(el); icG3.selo = el;
    }
    var at = []; try { if (icG3.tiles) icG3.tiles.getAttributions(at); } catch (_) {}
    var txt = at.filter(function (a) { return a.type === 'string' && a.value; }).map(function (a) { return a.value; }).join('; ');
    el.querySelector('[data-g3-cred]').textContent = txt;
    el.style.display = icG3.on ? 'flex' : 'none';   // ⚠ termos: o logo fica na tela enquanto o 3D do Google está ligado
  }
  function icG3Desligar() {
    icG3.versao++;
    if (icG3.tiles) { try { icG3G.remove(icG3.tiles.group); icG3.tiles.dispose(); } catch (_) {} icG3.tiles = null; }
    if (icG3.draco) { try { icG3.draco.dispose(); } catch (_) {} icG3.draco = null; }
    icG3.on = false; icG3.cfg = null; icG3.carregados = 0; icG3.hChao = null; icG3.buscas = 0;
    if (icG3.selo) icG3.selo.style.display = 'none';
    if (icG3.clipAntes != null) { renderer.localClippingEnabled = icG3.clipAntes; icG3.clipAntes = null; }
  }
  /* cfg = { chave, lat, lon, norte, x0, y0, zChao, altitude?, ajuste?, recortar? } — null ou { ligar: false } desliga */
  function icGoogle3d(cfg) {
    if (!cfg || cfg.ligar === false) { icG3Desligar(); return Promise.resolve({ ok: true, ligado: false }); }
    if (!cfg.chave) return Promise.resolve({ ok: false, erro: 'sem a chave do Google' });
    if (!(isFinite(+cfg.lat) && isFinite(+cfg.lon))) return Promise.resolve({ ok: false, erro: 'a obra ainda não foi localizada' });
    if (icG3.on && icG3.cfg && icG3.cfg.chave === cfg.chave && +icG3.cfg.lat === +cfg.lat && +icG3.cfg.lon === +cfg.lon) {
      /* mesma obra: só ajustes (altura, recorte, origem, norte) — sem pedir outra sessão ao Google (cada sessão é cobrada) */
      var recAntes = icG3.cfg.recortar !== false; icG3.cfg = cfg;
      if (recAntes !== (cfg.recortar !== false)) icG3AplicarRecorte();
      if (cfg.reajustar) { icG3.buscas = 0; icG3.ultBusca = 0; }
      return Promise.resolve({ ok: true, ligado: true, mesmaSessao: true });
    }
    icG3Desligar();
    icG3.cfg = cfg; icG3.on = true; icG3.erro = null;
    icG3.zDesloc = (+cfg.zChao || 0) - (isFinite(+cfg.altitude) ? +cfg.altitude : 0);
    if (icG3.clipAntes == null) icG3.clipAntes = renderer.localClippingEnabled;
    icG3Selo();
    var ver = ++icG3.versao;
    return icG3Carregar().then(function (M) {
      if (ver !== icG3.versao || !icG3.on) return { ok: false, erro: 'desligado antes de carregar' };
      var t = new M.TilesRenderer(cfg.url || undefined), au = new M.Auth({ apiToken: String(cfg.chave), autoRefreshToken: true });
      /* chave recusada / sem cota: o pedido da raiz volta 4xx — a tela diz, em vez de ficar "carregando" para sempre */
      var f0 = au.fetchData.bind(au);
      /* ⚠ com a renovação de sessão ligada, o 4xx da raiz volta como EXCEÇÃO (a biblioteca tenta renovar e a resposta não tem sessão) */
      au.fetchData = function (u, o) { var raiz = /root\.json/.test(String(u)); return f0(u, o).then(function (r) { if (r && !r.ok && raiz) icG3.erro = 'o Google recusou o pedido (HTTP ' + r.status + ') — confira a chave e a cota no console do Google Cloud'; return r; }, function (err) { if (raiz) icG3.erro = 'o Google recusou o pedido — confira a chave e a cota no console do Google Cloud'; throw err; }); };
      t.registerPlugin(au);
      var dr = new M.DRACOLoader(); dr.setDecoderPath(IC_G3_VENDOR + 'jsm/libs/draco/gltf/');
      var gl = new M.GLTFLoader(t.manager); gl.setDRACOLoader(dr); t.manager.addHandler(/\.(gltf|glb)$/, gl);   // sem /g: o LoadingManager testa a regex várias vezes (lastIndex)
      t.addEventListener('load-model', function (e) { icG3.carregados++; if (e && e.scene) icG3RecorteEm(e.scene); });
      icG3.tiles = t; icG3.draco = dr; icG3G.add(t.group);
      icG3AplicarRecorte(); icG3Matriz();
      return { ok: true, ligado: true };
    }).catch(function (e) { icG3.erro = 'não consegui carregar o módulo do 3D: ' + String((e && e.message) || e).slice(0, 160); icG3Desligar(); return { ok: false, erro: icG3.erro }; });
  }
  S._tickExtra.push(function () {
    if (!icG3.on || !icG3.tiles) return;
    var t = icG3.tiles;
    icG3Matriz();
    if (icG3.cfg && icG3.cfg.recortar !== false) renderer.localClippingEnabled = true;
    t.setCamera(camera); t.setResolutionFromRenderer(camera, renderer); camera.updateMatrixWorld(); t.update();
    icG3.quadros++;
    /* a altura: até 6 vezes no começo (os blocos finos chegam depois dos grossos) — com a fila vazia a cada 1,5 s e, com blocos
       ainda chegando, a cada 4 s. ⚠ Com o Google de verdade a fila NÃO esvazia enquanto a câmera anda (medido em 03/10/2026:
       154 blocos e nenhuma busca em 2 min) — esperar só a fila vazia deixava o 3D na altura do elipsoide */
    var agora = Date.now(), ocioso = t.stats && !t.stats.downloading && !t.stats.parsing;
    if (t.visibleTiles && t.visibleTiles.size && icG3.buscas < 6 && agora - icG3.ultBusca > (ocioso ? 1500 : 4000)) { icG3.ultBusca = agora; icG3AcharChao(); }
    if (icG3.quadros % 20 === 0) icG3Selo();
  });
  /* gancho de teste e de conferência: a cota (motor) do primeiro bloco do Google na vertical de (x, y) do motor */
  function icG3Sondar(x, y) {
    var t = icG3.tiles; if (!t) return null;
    var inv = new THREE.Matrix4().copy(modelRoot.matrixWorld).invert();
    var topo = icL({ x: +x, y: +y, z: 3000 }).applyMatrix4(modelRoot.matrixWorld), fundo = icL({ x: +x, y: +y, z: -3000 }).applyMatrix4(modelRoot.matrixWorld);
    icG3Ray.set(topo, fundo.clone().sub(topo).normalize()); icG3Ray.far = 6000;
    var hs = []; try { hs = icG3Ray.intersectObject(t.group, true); } catch (_) {}
    if (!hs.length) return null; hs.sort(function (p, q) { return p.distance - q.distance; });
    return Math.round(icM(hs[0].point.clone().applyMatrix4(inv)).z * 1000) / 1000;
  }
  function icG3Estado() {
    var t = icG3.tiles, nPl = 0;
    if (t) t.group.traverse(function (o) { if (o.material && !Array.isArray(o.material) && o.material.clippingPlanes && o.material.clippingPlanes.length === 4 && o.material.clipIntersection) nPl++; });
    return { on: icG3.on, modulo: !!icG3.mod, raiz: !!(t && t.rootTileSet), visiveis: t && t.visibleTiles ? t.visibleTiles.size : 0, carregados: icG3.carregados, hChao: icG3.hChao, zDesloc: Math.round(icG3.zDesloc * 1000) / 1000,
      fila: t && t.stats ? { baixando: t.stats.downloading, processando: t.stats.parsing, falhas: t.stats.failed } : null,
      erroMin: (function () { var m = Infinity; if (t && t.visibleTiles) t.visibleTiles.forEach(function (tl) { m = Math.min(m, +tl.geometricError || 0); }); return isFinite(m) ? Math.round(m * 10) / 10 : null; })(),
      buscas: icG3.buscas, erro: icG3.erro, recorte: !!(icG3.cfg && icG3.cfg.recortar !== false && icG3.planos), clipLocal: renderer.localClippingEnabled, planosNosBlocos: nPl, filhos: icG3G.children.length,
      selo: icG3.selo && icG3.selo.style.display !== 'none' ? (icG3.selo.textContent || '') : null, logo: !!(icG3.selo && icG3.selo.querySelector('img[alt="Google Maps"]')), visivel: icG3G.visible };
  }
  /* GEORREFERÊNCIA QUE O PRÓPRIO IFC TRAZ: IfcMapConversion (+ IfcProjectedCRS com o EPSG) vale mais; senão IfcSite
     (RefLatitude/RefLongitude no ponto de inserção do terreno) com o TrueNorth do contexto do modelo.
     ⚠ O motor trabalha nas coordenadas do IFC (o modelo abre sem COORDINATE_TO_ORIGIN): a origem do site, em unidade do
       arquivo, vira metro pelo LENGTHUNIT. Revit exporta RefLatitude da "Localização" do projeto — que pode ser só a CIDADE:
       a tela mostra o ponto no mapa para a pessoa conferir antes de usar. */
  var IFC_MAPCONVERSION = 3057273783, IFC_PROJECTEDCRS = 3843373140, IFC_GEOMREPCONTEXT = 3448662350, IFC_SITE_T = 4097777520;
  function icGeoIfc() {
    var G = window.IcarGeo; if (!G) return { ok: false, motivo: 'falta js/icargeo.js' };
    if (!S.api || S.modelID == null) return { ok: false, motivo: 'abra o modelo IFC primeiro' };
    var api = S.api, mid = S.modelID;
    function val(x) { return x && typeof x === 'object' && x.value !== undefined ? x.value : x; }
    function lin(id) { try { return api.GetLine(mid, val(id), false); } catch (_) { return null; } }
    function ids(t) { var o = []; try { var r = api.GetLineIDsWithType(mid, t); for (var i = 0; i < r.size(); i++) o.push(r.get(i)); } catch (_) {} return o; }
    var fLen = unidadePrefixoBase(mid, 'LENGTHUNIT'); if (fLen == null) fLen = 1;
    var mcs = ids(IFC_MAPCONVERSION);
    for (var a = 0; a < mcs.length; a++) {
      var mc = lin(mcs[a]), crs = mc && lin(mc.TargetCRS), nome = crs ? String(val(crs.Name) || '') : '', ep = /(\d{4,5})\s*$/.exec(nome) || /EPSG\D*(\d{4,5})/i.exec(nome);
      if (!mc || !ep) continue;
      /* Eastings/Northings na unidade do mapa — que o Revit às vezes deixa em mm: fica o fator que cai dentro de uma zona UTM */
      var E0 = +val(mc.Eastings), N0 = +val(mc.Northings), fat = [1, fLen, 0.001].filter(function (f) { var e = E0 * f, n = N0 * f; return e > 100000 && e < 900000 && n > 0 && n < 10000000; })[0];
      if (!fat) continue;
      var sc = +val(mc.Scale) || 1; if (fLen !== 1 && Math.abs(sc - fLen) < 1e-9) sc = 1;   // Scale = conversão mm → m, não fator de escala da projeção
      var g = G.geoDoMapConversion({ Eastings: E0 * fat, Northings: N0 * fat, XAxisAbscissa: val(mc.XAxisAbscissa), XAxisOrdinate: val(mc.XAxisOrdinate), Scale: sc }, +ep[1]);
      if (g) { g.ok = true; return g; }
    }
    var st = ids(IFC_SITE_T), site = st.length ? lin(st[0]) : null;
    if (!site) return { ok: false, motivo: 'o IFC não tem IfcSite' };
    function arr(v) { v = val(v); return v && v.length ? Array.prototype.map.call(v, function (x) { return +val(x); }) : null; }
    var la = G.anguloIfc(arr(site.RefLatitude)), lo = G.anguloIfc(arr(site.RefLongitude));
    if (la == null || lo == null || (Math.abs(la) < 1e-9 && Math.abs(lo) < 1e-9)) return { ok: false, motivo: 'o IFC não traz latitude e longitude do terreno (IfcSite)' };
    var x0 = 0, y0 = 0;
    try { var pl = lin(site.ObjectPlacement), rp = pl && lin(pl.RelativePlacement), lc = rp && lin(rp.Location), cs = lc && arr(lc.Coordinates); if (cs) { x0 = (cs[0] || 0) * fLen; y0 = (cs[1] || 0) * fLen; } } catch (_) {}
    var norte = 0, temNorte = false, cxs = ids(IFC_GEOMREPCONTEXT);
    for (var c = 0; c < cxs.length && !temNorte; c++) {
      var cx = lin(cxs[c]); if (!cx || !cx.TrueNorth) continue;
      var tn = lin(cx.TrueNorth), dr = tn && arr(tn.DirectionRatios); if (!dr || dr.length < 2) continue;
      norte = G.norteDeTrueNorth(dr[0], dr[1]); temNorte = true;
    }
    return { ok: true, lat: la, lon: lo, x0: Math.round(x0 * 1000) / 1000, y0: Math.round(y0 * 1000) / 1000, norte: Math.round(norte * 1e4) / 1e4, semNorte: !temNorte,
      fonte: 'IfcSite (latitude/longitude do terreno)' + (temNorte ? ' + norte do projeto' : ' — sem norte no arquivo (norte = +Y)') };
  }
  S._tickExtra.push(function (dt) {
    if (!icar.grupo.children.length) return;
    icSincronizar();
    var si = icar.sim;
    if (si && !si.parado) {
      si.t += (dt > 0 && dt < 0.25 ? dt : 0.016) / si.dur;
      si.passo();
      if (si.t >= 1.12) { si.parado = true; var fim = si.aoFim; icLimparSim(); try { if (fim) fim(); } catch (_) {} }
    }
    var qe = icar.equip;
    if (qe && qe.ge) {
      if (icar.giro) {
        var gr = icar.giro; gr.t += (dt > 0 && dt < 0.25 ? dt : 0.016) / gr.dur;
        var ang = gr.th0 + Math.PI * 2 * Math.min(1, gr.t), Mg0 = new THREE.Matrix4().compose(qe.ge.eqG.position, qe.ge.eqG.quaternion, qe.ge.eqG.scale);
        var gL = new THREE.Vector3(gr.R * Math.cos(ang), gr.y, -gr.R * Math.sin(ang)).applyMatrix4(Mg0);
        var rot = new THREE.Matrix4().makeRotationY(ang - gr.th0), pts = gr.pL.map(function (p) { return p.clone().applyMatrix4(rot).applyMatrix4(Mg0); });
        icPoseGerada(gL, pts);
        if (gr.t >= 1) { icar.giro = null; icPoseGerada(gr.g0, gr.p0); icFisicaAgora(true); }
      } else if (qe._fisPend) icFisicaAgora(true);
      if (qe.pulsa && qe.pulsa.length) {
        var pz = 0.5 + 0.5 * Math.sin(performance.now() / 1000 * 8);
        qe.pulsa.forEach(function (m) { if (m.emissive) m.emissive.setRGB(0.85 * pz, 0, 0); else if (m.opacity != null) { m.transparent = true; m.opacity = 0.35 + 0.65 * pz; } });
      }
    }
    for (var i = 0; i < icar.rotulos.length; i++) {
      var o = icar.rotulos[i], d = camera.position.distanceTo(o.getWorldPosition(_icWp)) * (o.userData._sc || 0.028);
      if (o.userData._ratio) o.scale.set(d * o.userData._ratio, d, 1); else o.scale.setScalar(d);
    }
    icEmpilharRotulos();
  });
  /* RÓTULOS QUE NÃO SE SOBREPÕEM (ESPEC-ICAMENTO §II.4.7: "empilham por distância à câmera"): o mais perto da câmera fica no
     lugar; cada um dos outros sobe, de uma altura de rótulo em uma, até achar um vão livre na TELA. Sobe pelo `center` do
     sprite (deslocamento em tela, sem mexer na posição 3D — o rótulo continua preso à peça). Máximo de 8 alturas.
     ⚠ Medido na tela a cada quadro: girar a câmera desempilha sozinho o que deixou de encavalar. */
  function icEmpilharRotulos() {
    var lista = icar.rotulos.filter(function (o) { return o.visible && o.parent; });
    if (lista.length < 2) { lista.forEach(function (o) { o.center.set(0.5, 0.5); }); return; }
    var tam = renderer.getSize(new THREE.Vector2()), W = tam.x, H = tam.y, tanF = Math.tan((camera.fov || 50) * Math.PI / 360);
    var itens = lista.map(function (o) {
      o.getWorldPosition(_icWp);
      var dist = camera.position.distanceTo(_icWp), p = _icWp.clone().project(camera);
      var hPx = camera.isPerspectiveCamera ? o.scale.y / (2 * dist * tanF) * H : o.scale.y * camera.zoom / ((camera.top - camera.bottom) || 1) * H;
      return { o: o, dist: dist, x: (p.x + 1) / 2 * W, y: (1 - p.y) / 2 * H, h: hPx, w: hPx * (o.userData._ratio || 1), atras: p.z > 1 };
    }).sort(function (a, b) { return a.dist - b.dist; });
    var postos = [];
    function bate(r) { for (var j = 0; j < postos.length; j++) { var q = postos[j]; if (r.x0 < q.x1 && r.x1 > q.x0 && r.y0 < q.y1 && r.y1 > q.y0) return true; } return false; }
    itens.forEach(function (it) {
      if (it.atras) { it.o.center.set(0.5, 0.5); return; }
      var n = 0, r;
      for (; n <= 8; n++) {
        var cy = it.y - n * it.h * 1.08;
        r = { x0: it.x - it.w / 2, x1: it.x + it.w / 2, y0: cy - it.h / 2, y1: cy + it.h / 2 };
        if (!bate(r)) break;
      }
      if (n > 8) n = 8;
      it.o.center.set(0.5, 0.5 - n * 1.08); it.o.userData._degraus = n;
      it.o.userData._tela = r;
      postos.push(r);
    });
  }
  /* a foto do plano: planta, elevação (perpendicular ao raio) ou perspectiva, em
     fundo branco, sem mexer na câmera de quem está olhando */
  function icCaptura(vista) {
    if (!S || !icar.grupo.children.length) return null;
    icSincronizar();
    var box = icCaixaFoco(); if (box.isEmpty()) return null;
    var c = box.getCenter(new THREE.Vector3()), sz = box.getSize(new THREE.Vector3()), raio = Math.max(sz.x, sz.y, sz.z) * 0.62;
    var bk = { p: camera.position.clone(), up: camera.up.clone(), fov: camera.fov, near: camera.near, far: camera.far, bg: scene.background };
    var vLn = _selLn ? _selLn.visible : null, url = null;
    try {
      camera.fov = 14; var dist = raio / Math.tan(camera.fov * Math.PI / 360) * 1.08;
      var q = icar.equip, dir;
      if (vista === 'planta') { dir = new THREE.Vector3(0, 1, 0); camera.up.set(0, 0, -1).transformDirection(modelRoot.matrixWorld); }
      else if (vista === 'elevacao' && q && q.c.cg) {
        var pv = q.pos.clone().applyMatrix4(icar.grupo.matrix), cg = icL(q.c.cg).applyMatrix4(icar.grupo.matrix);
        var rd = cg.sub(pv).setY(0); if (rd.lengthSq() < 1e-6) rd.set(1, 0, 0); rd.normalize();
        dir = new THREE.Vector3(-rd.z, 0, rd.x); camera.up.set(0, 1, 0);
      } else { dir = new THREE.Vector3(0.75, 0.62, 0.9).normalize(); camera.up.set(0, 1, 0); }
      camera.position.copy(c).add(dir.multiplyScalar(dist));
      icMapaG.visible = false;   // o mapa do agente ajuda a escolher, não vai para a foto do plano
      var ceuC = icLocalMundo.getObjectByName('local-ceu'); if (ceuC) ceuC.visible = false;   // foto do plano é técnica, fundo branco
      var g3C = icG3G.visible; icG3G.visible = false;   // ⚠ 3D do Google fora da foto impressa (termos: ver o 3D DO GOOGLE)
      camera.near = Math.max(0.05, dist - raio * 3); camera.far = dist + raio * 4;
      camera.lookAt(c); camera.updateProjectionMatrix();
      scene.background = new THREE.Color(0xffffff);
      if (_selLn) _selLn.visible = false;
      renderer.render(scene, camera);
      url = renderer.domElement.toDataURL('image/png');
    } catch (_) { url = null; } finally {
      camera.position.copy(bk.p); camera.up.copy(bk.up); camera.fov = bk.fov; camera.near = bk.near; camera.far = bk.far; scene.background = bk.bg;
      icMapaG.visible = true;
      var ceuV = icLocalMundo.getObjectByName('local-ceu'); if (ceuV) ceuV.visible = true;
      icG3G.visible = g3C !== false;
      if (_selLn && vLn !== null) _selLn.visible = vLn;
      camera.lookAt(orbit.target); camera.updateProjectionMatrix();
    }
    return url;
  }
  /* MODO FOTO (ESPEC §II.9.2): a câmera de quem está olhando, numa imagem grande — desenhada no DOBRO do tamanho e reduzida
     (anti-serrilhado de verdade), com SOMBRA ligada no modelo, no equipamento e no cenário e o mapa de sombra (4096) apertado na
     cena. ⚠ Tudo volta como estava (tamanho do canvas, sombras, luz), também se der erro no meio. ⚠ Não é traçado de raios: é o
     mesmo motor do 3D com o melhor dele ligado — e o carimbo diz "ilustrativo". */
  function icRaizesSombra() {
    var r = [modelRoot];
    (S.modelos || []).forEach(function (mo) { if (mo._agreg && mo._agreg.grupo) r.push(mo._agreg.grupo); });
    return r.concat([icar.grupo, icPlantaG, icLocalG, icLocalMundo]);
  }
  function icFotoHD(o) {
    o = o || {};
    if (!S) return { ok: false, erro: 'visualizador não montado' };
    var W = Math.max(320, Math.min(3840, Math.round(+o.largura || 1920))), H = Math.max(240, Math.min(2160, Math.round(+o.altura || 1080)));
    var maxRB = (renderer.capabilities && renderer.capabilities.maxRenderbufferSize) || 4096, ss = Math.max(1, Math.min(2, Math.floor(Math.min(maxRB / W, maxRB / H))));
    var cv = renderer.domElement, tam = new THREE.Vector2(); renderer.getSize(tam);
    var sc = dir.shadow.camera, bk = { w: cv.width, h: cv.height, pr: renderer.getPixelRatio(), asp: camera.aspect, cast: dir.castShadow, map: dir.shadow.mapSize.clone(),
      cam: [sc.left, sc.right, sc.top, sc.bottom, sc.near, sc.far], pos: dir.position.clone(), tgt: dir.target.position.clone() };
    var g3F = icG3G.visible; icG3G.visible = false;   // ⚠ o 3D do Google não vai para o PNG (termos: ver o 3D DO GOOGLE)
    var marcadas = [], envs = [], trocas = [], luzes = { d: dir.intensity, h: hemi.intensity, f: fill.intensity, g: grid.visible }, out = null;
    try {
      /* LUZ DE FOTO: o 3D de todo dia é claro por igual (ambiente + hemisfério + preenchimento) e a sombra some nele — medido: 1.445
         pixels mais escuros numa foto de 518 mil. Na foto o sol manda: sol × 1,7, hemisfério × 0,55, preenchimento × 0,4 e o
         reflexo do ambiente × 0,5; a grade técnica do chão sai. Tudo volta no finally. */
      dir.intensity = luzes.d * 1.7; hemi.intensity = luzes.h * 0.55; fill.intensity = luzes.f * 0.4; grid.visible = false;
      /* o SATÉLITE no chão é material sem luz (MeshBasic): a sombra do modelo não caía nele. Na foto ele vira material com luz
         (o mesmo mapa) e recebe sombra — nas duas fotos (com e sem sombra), para a comparação medir só a sombra */
      icLocalG.children.forEach(function (m) {
        if (m.name !== 'local-imagem' || !m.material || !m.material.isMeshBasicMaterial) return;
        var b = m.material;
        trocas.push([m, b, m.receiveShadow]);
        m.material = new THREE.MeshStandardMaterial({ map: b.map, transparent: b.transparent, opacity: b.opacity, depthWrite: false, side: b.side, polygonOffset: b.polygonOffset,
          polygonOffsetFactor: b.polygonOffsetFactor, polygonOffsetUnits: b.polygonOffsetUnits, roughness: 1, metalness: 0 });
        m.receiveShadow = true;
      });
      icRaizesSombra().forEach(function (g) {
        g.traverse(function (m) {
          if (!m.isMesh || !m.material) return;
          (Array.isArray(m.material) ? m.material : [m.material]).forEach(function (mt) {
            if (mt.envMapIntensity == null || mt.userData.__envFoto) return;
            mt.userData.__envFoto = true; envs.push([mt, mt.envMapIntensity]); mt.envMapIntensity = mt.envMapIntensity * 0.5;
          });
        });
      });
      /* ⚠ O MODELO NA TELA É A MALHA MESCLADA (mo._agreg, pendurada no scene, camada 0): as peças do modelRoot estão na camada 1
         só para o clique e NÃO são desenhadas — ligar sombra só nelas dava uma foto sem sombra nenhuma (medido: 0 pixel de
         diferença com e sem sombra). Entram as duas, mais o entorno aceito (icPlantaG). */
      /* o.semSombra: a mesma foto sem sombra — só para medir que a sombra APARECE (a comparação pixel a pixel da e2e) */
      if (!o.semSombra) icRaizesSombra().forEach(function (g) {
        g.traverse(function (m) {
          if (!m.isMesh || !m.geometry || m.name === 'local-ceu') return;
          marcadas.push([m, m.castShadow, m.receiveShadow]);
          var chao = /^local-(relevo|levantamento|imagem|rua-faixa|gramado)$/.test(m.name), fino = m.material && m.material.transparent && m.material.opacity < 0.5;
          m.castShadow = !chao && !fino; m.receiveShadow = true;
        });
      });
      /* a área da sombra: modelo + equipamento + o ENTORNO aceito (o prédio do vizinho faz sombra no chão da obra) — até 150 m de
         raio, para o mapa de 4096 não passar de ~7 cm por texel */
      var box = icLocalCaixa(); if (icar.grupo.children.length) { var bF = icCaixaFoco(); if (!bF.isEmpty()) box.union(bF); }
      icPlantaG.children.forEach(function (e) { if (e.name === 'entorno') { var bE = new THREE.Box3().setFromObject(e); if (!bE.isEmpty()) box.union(bE); } });
      var ctr = box.getCenter(new THREE.Vector3()), R = Math.min(150, box.getSize(new THREE.Vector3()).length() / 2 + 2);
      var dSol = dir.position.clone().sub(dir.target.position); if (dSol.lengthSq() < 1e-9) dSol.set(0.4, 1, 0.3); dSol.normalize();
      dir.target.position.copy(ctr); dir.target.updateMatrixWorld(); dir.position.copy(ctr).addScaledVector(dSol, R * 2);
      sc.left = -R; sc.right = R; sc.top = R; sc.bottom = -R; sc.near = 0.5; sc.far = R * 4; sc.updateProjectionMatrix();
      dir.shadow.mapSize.set(4096, 4096); if (dir.shadow.map) { dir.shadow.map.dispose(); dir.shadow.map = null; }
      dir.castShadow = !o.semSombra;
      renderer.setPixelRatio(1); renderer.setSize(W * ss, H * ss, false);
      camera.aspect = W / H; camera.updateProjectionMatrix();
      renderer.setScissorTest(false); renderer.setViewport(0, 0, W * ss, H * ss);
      var g3NaFoto = icG3G.visible && icG3G.children.length > 0;
      renderer.render(scene, camera);
      var mapaOk = !!(dir.shadow.map && dir.shadow.map.texture);
      var c2 = document.createElement('canvas'); c2.width = W; c2.height = H;
      var x2 = c2.getContext('2d'); x2.fillStyle = '#eef2f6'; x2.fillRect(0, 0, W, H);   // sem céu, o fundo do 3D é transparente
      x2.imageSmoothingEnabled = true; x2.imageSmoothingQuality = 'high';
      x2.drawImage(cv, 0, 0, W * ss, H * ss, 0, 0, W, H);
      var txt = String(o.carimbo || 'OrçaPRO · modo foto · imagem ilustrativa').slice(0, 90), fs = Math.round(H / 54);
      x2.font = '600 ' + fs + 'px system-ui, sans-serif'; var tw = x2.measureText(txt).width;
      x2.fillStyle = 'rgba(15,23,42,.55)'; x2.fillRect(W - tw - fs * 1.6, H - fs * 2.2, tw + fs * 1.2, fs * 1.7);
      x2.fillStyle = '#fff'; x2.fillText(txt, W - tw - fs, H - fs * 0.95);
      out = { ok: true, url: c2.toDataURL('image/png'), largura: W, altura: H, superamostra: ss, sombras: marcadas.filter(function (x) { return x[0].castShadow; }).length,
        mescladas: marcadas.filter(function (x) { return x[0].userData.agregado; }).length, satelite: trocas.length, google3dNaFoto: g3NaFoto,
        ceu: !!icLocalMundo.getObjectByName('local-ceu'), mapaSombra: dir.shadow.mapSize.x, mapaGerado: mapaOk, recebem: marcadas.length, luz: Math.round(dir.intensity * 100) / 100 };
    } catch (e) { out = { ok: false, erro: String((e && e.message) || e) }; }
    finally {
      marcadas.forEach(function (x) { x[0].castShadow = x[1]; x[0].receiveShadow = x[2]; });
      envs.forEach(function (x) { x[0].envMapIntensity = x[1]; delete x[0].userData.__envFoto; });
      trocas.forEach(function (x) { var t = x[0].material; x[0].material = x[1]; x[0].receiveShadow = x[2]; try { t.dispose(); } catch (_) {} });   // o mapa (satélite) é do original: não descartar
      dir.intensity = luzes.d; hemi.intensity = luzes.h; fill.intensity = luzes.f; grid.visible = luzes.g;
      dir.castShadow = bk.cast; dir.shadow.mapSize.copy(bk.map); if (dir.shadow.map) { dir.shadow.map.dispose(); dir.shadow.map = null; }
      sc.left = bk.cam[0]; sc.right = bk.cam[1]; sc.top = bk.cam[2]; sc.bottom = bk.cam[3]; sc.near = bk.cam[4]; sc.far = bk.cam[5]; sc.updateProjectionMatrix();
      dir.position.copy(bk.pos); dir.target.position.copy(bk.tgt); dir.target.updateMatrixWorld();
      renderer.setPixelRatio(bk.pr); renderer.setSize(tam.x, tam.y, false); camera.aspect = bk.asp; camera.updateProjectionMatrix();
      icG3G.visible = g3F;
      if (out) out.restaurado = cv.width === bk.w && cv.height === bk.h && dir.castShadow === bk.cast && dir.intensity === luzes.d && hemi.intensity === luzes.h && grid.visible === luzes.g;
    }
    return out;
  }
  /* o que importa na foto e no enquadramento: equipamento, carga, raio e área isolada — sem o círculo do
     alcance máximo (o de um guindaste de 40 m afastava a câmera até o caminhão virar um ponto) nem os rótulos */
  function icCaixaFoco() {
    var box = new THREE.Box3();
    icar.grupo.children.forEach(function (o) { if (!o.userData.foraDaFoto && !o.isSprite) box.expandByObject(o); });
    return box;
  }
  function icEnquadrar() {
    icSincronizar();
    var box = icCaixaFoco(); if (box.isEmpty()) return false;
    if (S._enquadrarObj) S._enquadrarObj(box, 1.25); return true;
  }
  S._icar = { geometria: icGeometria, chao: function () { return icM(new THREE.Vector3(0, icChao(), 0)).z; }, pontoNoChao: icPontoNoChao, sondar: icSondar, desenhar: icDesenhar, limpar: icLimpar,
    simular: icSimular, simulando: function () { return !!icar.sim; }, parar: function () { icLimparSim(); return true; },
    colisoes: icColisoes, caixas: icCaixas, fotoHD: icFotoHD, google3d: icGoogle3d, google3dEstado: icG3Estado, google3dSondar: icG3Sondar, mapa: icMapa, planta: icPlanta, plantaPonto: icPlantaPonto, visada: icVisada, local: icLocal, geoIfc: icGeoIfc,
    localEstado: function () {
      var c = { gramados: 0, ceu: !!icLocalMundo.getObjectByName('local-ceu'), faixas: 0, arvores: 0, levantamento: 0, curvas: 0, imagem: 0, relevo: 0, ruas: 0, verdes: 0, postes: 0, redes: 0, chuva: 0, vento: 0, neblina: !!(icLocalEst.nevoaVis && scene.fog), sol: !!icLocalEst.sol, luz: { x: dir.position.x, y: dir.position.y, z: dir.position.z, i: dir.intensity } };
      c.graos = []; icLocalG.children.forEach(function (o) { var gr = (o.name === 'local-gramado' || o.name === 'local-rua-faixa') && o.material && o.material.userData.grao; if (gr && c.graos.indexOf(gr) < 0) c.graos.push(gr); });
      c.sombrasLigadas = 0; icRaizesSombra().slice(0, -4).forEach(function (g) { g.traverse(function (m) { if (m.isMesh && m.castShadow) c.sombrasLigadas++; }); });   // o modo foto devolve como estava (modelo e malha mesclada)
      icLocalG.children.forEach(function (o) { if (o.name === 'local-gramado') c.gramados++; else if (o.name === 'local-rua-faixa') c.faixas++; else if (o.name === 'local-arvores') c.arvores = o.count; else if (o.name === 'local-levantamento') c.levantamento++; else if (o.name === 'local-curvas') c.curvas = o.geometry.attributes.position.count / 2; else if (o.name === 'local-imagem') c.imagem++; else if (o.name === 'local-relevo') c.relevo++; else if (o.name === 'local-rua') c.ruas++; else if (o.name === 'local-verde') c.verdes++; else if (o.name === 'local-poste') c.postes++; else if (o.name === 'local-rede') c.redes++; });
      icLocalMundo.children.forEach(function (o) { if (o.name === 'local-chuva') c.chuva = o.geometry.attributes.position.count; else if (o.name === 'local-vento') c.vento++; });
      return c;
    },
    plantaEstado: function () {
      var c = { plano: 0, linhas: 0, propostas: 0, entorno: 0, agua: 0, opacidade: null };
      icPlantaG.children.forEach(function (o) { if (o.name === 'entorno' && Array.isArray(o.material) && o.material[1] && o.material[1].userData.fachada) c.fachadas = (c.fachadas || 0) + 1; });
      icPlantaG.children.forEach(function (o) { if (o.name === 'planta-imagem') { c.plano++; c.opacidade = o.material.opacity; } else if (o.name === 'planta-linhas') c.linhas++; else if (o.name === 'planta-proposta') c.propostas++; else if (o.name === 'entorno') c.entorno++; else if (o.name === 'entorno-agua') c.agua++; else if (o.name === 'agente-limite') c.limite = (c.limite || 0) + 1; });
      c.obstaculos = (icar.entorno || []).length; return c;
    },
    mapaEstado: function () { var m = icMapaG.getObjectByName('agente-mapa'); return m ? { n: m.count, contagem: m.userData.contagem, visivel: icMapaG.visible } : null; },
    /* leva a simulação a um instante (0–1) e PAUSA ali — é o clique na marca de choque da linha do tempo */
    simIr: function (t) { var si = icar.sim; if (!si) return false; si.t = Math.max(0, Math.min(1, +t || 0)); si.parado = true; si.passo(); icFisicaAgora(true); return true; },
    simPausado: function () { return !!(icar.sim && icar.sim.parado); },
    captura: icCaptura, enquadrar: icEnquadrar,
    /* "▶ girar a lança": uma volta completa no raio de agora (as cores das patolas mudam com θ) */
    girar: function (on, dur) {
      var q = icar.equip; if (!q || !q.ge || !q.ganchoL) return false;
      if (!on) { if (icar.giro) { var g0 = icar.giro; icar.giro = null; icPoseGerada(g0.g0, g0.p0); } return true; }
      var Mi = new THREE.Matrix4().compose(q.ge.eqG.position, q.ge.eqG.quaternion, q.ge.eqG.scale).invert();
      var pL = (q._pontosUlt || []).map(function (p) { return p.clone().applyMatrix4(Mi); });
      icar.giro = { t: 0, dur: Math.max(2, +dur || 8), th0: q.theta, R: q.R, y: q.ganchoL.y, pL: pL, g0: q.gancho.clone(), p0: (q._pontosUlt || []).map(function (p) { return p.clone(); }) };
      return true;
    },
    girando: function () { return !!icar.giro; },
    /* θ fixo (graus, a partir da dianteira) — para a tela e para o teste */
    theta: function (graus) {
      var q = icar.equip; if (!q || !q.ge || !q.ganchoL) return null;
      var a = (+graus || 0) * Math.PI / 180, Mg = new THREE.Matrix4().compose(q.ge.eqG.position, q.ge.eqG.quaternion, q.ge.eqG.scale);
      var rot = new THREE.Matrix4().makeRotationY(a - q.theta), Mi = Mg.clone().invert();
      var pts = (q._pontosUlt || []).map(function (p) { return p.clone().applyMatrix4(Mi).applyMatrix4(rot).applyMatrix4(Mg); });
      icPoseGerada(new THREE.Vector3(q.R * Math.cos(a), q.ganchoL.y, -q.R * Math.sin(a)).applyMatrix4(Mg), pts);
      icFisicaAgora(true); return q.theta;
    },
    sobrecarga: function (k) { var q = icar.equip; if (!q) return null; q.k = k == null ? null : +k; return icFisicaAgora(true); },
    opcoes: function (o) { var q = icar.equip; if (!q) return false; for (var k in o) q.c[k] = o[k]; icFisicaAgora(true); return true; },
    equipEstado: function () {
      var q = icar.equip; if (!q || !q.ge) return null;
      var ge = q.ge, Mg = new THREE.Matrix4().compose(ge.eqG.position, ge.eqG.quaternion, ge.eqG.scale);
      function hex(m) { return m && m.color ? '#' + m.color.getHexString() : null; }
      var rot = {}; Object.keys(icar.vivos).forEach(function (k) { var v = icar.vivos[k]; if (v.visible) rot[k] = v.userData._txt; });
      /* a ponta e o cotovelo pela MALHA desenhada (não pela conta): é o que prova que o desenho segue a cinemática */
      icSincronizar();
      var invG = new THREE.Matrix4().copy(icar.grupo.matrixWorld).invert();
      function daMalha(m, x) { if (!m) return null; m.updateMatrixWorld(true); return icM(new THREE.Vector3(x, 0, 0).applyMatrix4(m.matrixWorld).applyMatrix4(invG)); }
      var pontaMalha = ge.munck ? daMalha(ge.ext && ge.ext.visible ? ge.ext : ge.braco2, 0.5) : daMalha(ge.cabeca, 0), cotMalha = ge.munck ? daMalha(ge.braco1, 0.5) : null;
      var colMalha = ge.munck ? daMalha(ge.braco1, -0.5) : null;
      return { tipo: ge.munck ? 'munck' : 'guindaste', theta: q.theta * 180 / Math.PI, R: q.R, alfa: q.alfaGraus != null ? q.alfaGraus : null, kinOk: !!(q.kin && q.kin.ok),
        ponta: q.pontaL ? icM(q.pontaL.clone().applyMatrix4(Mg)) : null, gancho: q.gancho ? icM(q.gancho) : null, centro: icM(new THREE.Vector3(0, 0, 0).applyMatrix4(Mg)),
        cores: { escoras: (ge.escoras || []).map(function (e) { return hex(e.m); }), patolas: ge.patolas.map(function (p) { return hex(p.mS); }), solo: ge.patolas.map(function (p) { return hex(p.mC); }), lanca: ge.secoes ? hex(ge.secoes[0].mat) : hex(ge.mBracos), cabo: hex(ge.mCabo), lingas: (ge.mLingas || []).map(hex) },
        /* onde cada rótulo visível caiu na TELA depois do empilhamento (px) — para provar que nenhum encavala */
        /* ⚠ medido do ZERO (projeção + o `center` atual do sprite), sem ler o que o empilhamento gravou — senão, sem empilhar,
           a lista viria vazia e "nenhum encavala" passaria por omissão */
        rotulosTela: (function () {
          var tam = renderer.getSize(new THREE.Vector2()), W = tam.x, H = tam.y, tanF = Math.tan((camera.fov || 50) * Math.PI / 360), wp = new THREE.Vector3();
          return icar.rotulos.filter(function (o) { return o.visible && o.parent; }).map(function (o) {
            o.getWorldPosition(wp); var dist = camera.position.distanceTo(wp), p = wp.clone().project(camera);
            var h = o.scale.y / (2 * dist * tanF) * H, w = h * (o.userData._ratio || 1), x = (p.x + 1) / 2 * W, y = (1 - p.y) / 2 * H - (0.5 - o.center.y) * h;
            return { txt: o.userData._txt || '', x0: Math.round(x - w / 2), x1: Math.round(x + w / 2), y0: Math.round(y - h / 2), y1: Math.round(y + h / 2), degraus: o.userData._degraus || 0 };
          });
        })(),
        pontaMalha: pontaMalha, cotoveloMalha: cotMalha, colunaMalha: colMalha, kin: q.kin ? { ok: !!q.kin.ok, modo: q.kin.modo || null, ext: q.kin.ext != null ? q.kin.ext : null } : null,
        rotulos: rot, nEstimadas: ge.nEstimadas, pulsando: (q.pulsa || []).length, fis: q.fis ? q.fis.componentes.map(function (x) { return { id: x.id, esforco: x.esforco, uTrab: x.u.uTrab, uRup: x.u.uRup, faixa: x.u.faixa.chave }; }) : null, k: q.k };
    },
    estado: function (uids) {
      var vis = 0; (uids || []).forEach(function (u) { malhasDaPeca(u).forEach(function (m) { if (m.visible) vis++; }); });
      var lc = icar.equip && icar.equip.gancho ? [icar.equip.gancho.x, icar.equip.gancho.y, icar.equip.gancho.z] : null; // onde o gancho está agora
      return { objetos: icar.grupo.children.length, equip: !!icar.equip, equipPos: icar.equip ? icM(icar.equip.pos) : null, sim: icar.sim ? { t: icar.sim.t, malhas: icar.sim.fantasma.children.length - 1 } : null, rotulos: icar.rotulos.length,
        malhasVisiveis: vis, lanca: lc, linhaIcamento: !!icar.grupo.getObjectByName('linha-icamento'),
        tandem: ['tandem-equip', 'tandem-lanca', 'tandem-linga'].filter(function (n) { return !!icar.grupo.getObjectByName(n); }).length,
        tandemGancho: icar.tandem && icar.tandem.gAgora ? icM(icar.tandem.gAgora) : null };
    } };
  /* corte de altura do visitante ("ver por dentro"), fora do imersivo — no
     modo visitante não há planta nem corte livre disputando o plano */
  var _tetoV = new THREE.Plane(new THREE.Vector3(0, -1, 0), 0);
  function tetoVisitante(frac) {
    var box = new THREE.Box3().setFromObject(modelRoot); if (box.isEmpty()) return null;
    if (frac == null || frac >= 0.999) { renderer.clippingPlanes = []; renderer.localClippingEnabled = false; return { inteiro: true }; }
    var y = box.min.y + (box.max.y - box.min.y) * Math.max(0, frac);
    _tetoV.constant = y; renderer.localClippingEnabled = true; renderer.clippingPlanes = [_tetoV];
    return { inteiro: false, alturaM: y - box.min.y };
  }
  S._tetoVisitante = tetoVisitante;

  /* =====================================================================
   * B2 — AGREGACAO DE GEOMETRIA (motor puro em js/bimagreg.js)
   *
   * MEDIDO no modelo real da RA antes de existir esta funcao: 950 draw calls
   * para 452 pecas, com mediana de 12 triangulos por chamada. A placa de video
   * nao faz nada; e tudo custo de chamada.
   *
   * ⚠ E O DESENHO QUE EVITA REESCREVER O PRODUTO INTEIRO. Uma malha por peca e
   * invariante da qual dependem ~140 pontos deste arquivo: clique, trena,
   * encaixe, isolar, raio-X, cor por disciplina e por sistema, 4D, conflito.
   * Reescrever os 140 e o caminho que a tabela de riscos marca com
   * probabilidade ALTA de quebrar justamente a trena e o corte tecnico.
   *
   * Em vez disso, as malhas por peca CONTINUAM existindo e continuam sendo a
   * verdade — elas so param de ser DESENHADAS. Isso e feito por CAMADA, nao por
   * `visible`, e a diferenca importa:
   *
   *   peca (proxy) ....... layers.set(1)  -> a camera (layer 0) nao desenha
   *   malha mesclada ..... layers.set(0)  -> e o que aparece na tela
   *   raycaster .......... layers.set(1)  -> o clique so ve as pecas
   *
   * Conferido no three r150 vendorizado, nao suposto: a camera ignora a camada
   * 1; `Box3.setFromObject` NAO olha camada (entao enquadrar, corte e planta
   * seguem iguais); e o `.visible` de cada peca continua sendo do produto, o
   * que mantem `cadeiaVisivel` funcionando sem uma linha de mudanca.
   *
   * Sobra espelhar duas coisas na malha mesclada: quem esta oculto e de que cor
   * cada peca esta. Isso e feito uma vez por quadro, por ASSINATURA — e nao
   * tocando nos 48 pontos que escrevem `.visible` e nos 19 que trocam
   * `.material`. Um ponto esquecido ali seria uma peca que some da tela sem
   * motivo, e o esquecimento nao teria como ser notado.
   * ===================================================================== */
  /* ⚠ LIGADA POR PADRAO, E DESLIGAVEL DE UM JEITO QUE SOBREVIVE AO RELOAD.
   * A tabela de riscos manda manter o caminho antigo alcancavel, e uma bandeira
   * so em memoria nao serve de rollback: se a agregacao estragasse a cena, o
   * primeiro reflexo do usuario e recarregar a pagina — e ela voltaria ligada.
   * Gravada em preferencia, `BIM.agregacao(false)` resolve de vez, e a linha
   * cabe num recado de suporte. */
  var AGREG = { on: true };
  try { AGREG.on = localStorage.getItem('orcapro:bim:agregar') !== '0'; } catch (_) {}
  /* o clique passa a olhar so a camada das pecas desde a montagem — sem isto,
     abrir um modelo com a bandeira ja ligada deixaria o raio sem alvo */
  if (AGREG.on) ray.layers.set(1);

  function _corDoMaterial(mat) {
    if (!mat) return [1, 1, 1, 1];
    var c = mat.color || { r: 1, g: 1, b: 1 };
    var a = (mat.transparent && typeof mat.opacity === 'number') ? mat.opacity : 1;
    return [c.r, c.g, c.b, a];
  }

  function agregarModelo(mo) {
    if (!AGREG.on || !mo || mo._agreg || typeof window === 'undefined' || !window.BimAgreg) return false;
    var geos = {}, insts = [];
    for (var i = 0; i < mo.grupo.children.length; i++) {
      var m = mo.grupo.children[i];
      if (!m.isMesh || m.userData.expressID == null || !m.geometry || !m.geometry.index) continue;
      var pa = m.geometry.attributes.position, na = m.geometry.attributes.normal;
      if (!pa || !na) continue;
      var k = m.uuid;
      geos[k] = { pos: pa.array, nor: na.array, idx: m.geometry.index.array };
      /* a matriz do OBJETO (o grupo do modelo e identidade): a mesma que a
         abertura aplicou com applyMatrix4 */
      insts.push({ e: m.userData.expressID, g: k, m: m.matrix.elements, cor: _corDoMaterial(m.userData.matOrig || m.material), ref: m });
    }
    if (!insts.length) return false;

    var plano = BimAgreg.planejar({ instancias: insts, geometrias: geos });
    /* ⚠ TODOS OS MODELOS DA OBRA USAM A MESMA ORIGEM. Origens diferentes por
       modelo desalinhariam a federacao — que e o D7 acontecendo por dentro. */
    if (!S._origemAgreg) S._origemAgreg = BimAgreg.origemDe(plano);
    var origem = S._origemAgreg;

    var grupo = new THREE.Group();
    grupo.userData.agregadoDe = mo.mid;
    var partes = [];
    for (var b = 0; b < plano.buckets.length; b++) {
      var bucket = plano.buckets[b];
      var built = BimAgreg.construir(bucket, geos, origem);
      var bg = new THREE.BufferGeometry();
      bg.setAttribute('position', new THREE.BufferAttribute(built.pos, 3));
      bg.setAttribute('normal', new THREE.BufferAttribute(built.nor, 3));
      /* RGBA: o alfa por vertice e o que deixa raio-X e transparencia por peca
         continuarem funcionando sem material por peca */
      var cores = new Float32Array(built.pos.length / 3 * 4);
      bg.setAttribute('color', new THREE.BufferAttribute(cores, 4));
      bg.setIndex(new THREE.BufferAttribute(built.idx, 1));
      var mat = new THREE.MeshStandardMaterial({ vertexColors: true, transparent: true, metalness: .05, roughness: .85, side: THREE.DoubleSide, depthWrite: true });
      var malha = new THREE.Mesh(bg, mat);
      malha.position.set(origem[0], origem[1], origem[2]);
      malha.layers.set(0);
      malha.userData.agregado = true;
      malha.frustumCulled = false;   /* a caixa cobre o modelo inteiro; culling aqui so custa */
      grupo.add(malha);
      partes.push({ malha: malha, faixas: built.faixas, idxCheio: built.idx, cores: cores, bucket: bucket });
    }
    /* ⚠ FORA DO modelRoot, DE PROPOSITO — e isto foi aprendido quebrando.
       Onze lugares deste arquivo varrem `modelRoot.children` e tratam os filhos
       de cada grupo como PECAS: isolar pavimento, contar visiveis, raio-X. Com
       o grupo mesclado ali dentro, `todasMalhas` apagava as malhas mescladas
       junto (elas nao tem expressID, entao a conta dava "nao pertence") e
       isolar um pavimento escondia o modelo inteiro. Medido: 2 triangulos na
       tela onde o caminho antigo mostrava 394.
       Pendurar no `scene` e espelhar a transformacao do modelRoot resolve os
       onze de uma vez, e o proximo varredor que alguem escrever ja nasce
       imune. */
    scene.add(grupo);
    mo._agreg = { grupo: grupo, partes: partes, origem: origem, assinatura: null };

    /* as pecas saem da camera, mas continuam no raio e no bbox */
    for (var q = 0; q < mo.grupo.children.length; q++) if (mo.grupo.children[q].isMesh) mo.grupo.children[q].layers.set(1);
    _reaplicarAparencia(mo._agreg);   /* pinta ja: chamar o sync daqui recursaria */
    return true;
  }

  function desagregarModelo(mo) {
    if (!mo || !mo._agreg) return;
    try {
      mo._agreg.partes.forEach(function (p) {
        if (p.malha.geometry) p.malha.geometry.dispose();
        if (p.malha.material) p.malha.material.dispose();
      });
      scene.remove(mo._agreg.grupo);
    } catch (_) {}
    mo._agreg = null;
    for (var q = 0; q < mo.grupo.children.length; q++) if (mo.grupo.children[q].isMesh) mo.grupo.children[q].layers.set(0);
  }

  /* ⚠ ESPELHAMENTO POR ASSINATURA, uma vez por quadro. A alternativa era marcar
     "sujo" nos 48 + 19 pontos que mexem em visibilidade e material — e o ponto
     esquecido seria uma peca que some ou fica da cor errada, sem erro nenhum.
     A assinatura le dois campos por peca; num modelo de 40 mil pecas isso e
     algumas decimas de milissegundo, pago uma vez por quadro. */
  /* ⚠ MISTURA DE OPACO COM TRANSPARENTE NO MESMO MATERIAL — o limite honesto
   * da agregacao, e ele foi MEDIDO, nao previsto. O raio-X deixa a peca alvo
   * OPACA e o resto FANTASMA. Numa malha mesclada ha um material so: ligar
   * `transparent` nele tira o depth-write de todo o conjunto, inclusive da peca
   * em destaque, e o resultado sai diferente — 4,18% dos pixels, medido no
   * modelo real da RA contra o caminho antigo.
   *
   * Transparencia UNIFORME (o controle do painel de modelos) nao tem esse
   * problema: todo mundo transparente ordena igual. O que quebra e a MISTURA.
   *
   * Entao, enquanto ela existir, aquele modelo volta a desenhar peca a peca —
   * que e o rollback que a tabela de riscos prescreve, aplicado sozinho e so
   * onde faz falta. O raio-X e modo de inspecao: paga as chamadas enquanto
   * esta ligado e devolve o ganho ao sair. */
  function _lerEstadoDoModelo(mo) {
    var filhos = mo.grupo.children, sig = 0, porMat = {}, misto = false;
    for (var k = 0; k < filhos.length; k++) {
      var m = filhos[k];
      if (!m.isMesh) continue;
      sig = (sig * 33 + (m.visible === false ? 1 : 2)) | 0;
      sig = (sig * 33 + (m.material ? m.material.id : 0)) | 0;
      if (m.visible === false || misto) continue;
      /* ⚠ A MISTURA QUE IMPORTA E DENTRO DE UM MESMO MATERIAL, nao no modelo.
         Quase todo IFC tem vidro junto com concreto — isso e NORMAL e cada um
         vira um bucket proprio, uniforme. O que a malha mesclada nao consegue
         representar e o mesmo material com umas pecas opacas e outras
         fantasma, que e exatamente o que o raio-X faz. A primeira versao desta
         regra olhava o modelo inteiro e suspendia a agregacao em qualquer
         arquivo com vidro — quer dizer, quase sempre. */
      var base = m.userData.matOrig ? m.userData.matOrig.id : 0;
      var op = (m.material && m.material.transparent) ? m.material.opacity : 1;
      if (porMat[base] === undefined) porMat[base] = op;
      else if (Math.abs(porMat[base] - op) > 0.001) misto = true;
    }
    return { sig: sig, misto: misto };
  }

  function sincronizarAgregado() {
    if (!AGREG.on || !S || !S.modelos) return;
    for (var i = 0; i < S.modelos.length; i++) {
      var mo = S.modelos[i];
      var est = _lerEstadoDoModelo(mo);

      if (est.misto) {
        /* suspende: enquanto durar a mistura, este modelo desenha peca a peca */
        if (mo._agreg) { desagregarModelo(mo); mo._agregSuspenso = 1; }
        continue;
      }
      if (mo._agregSuspenso) { mo._agregSuspenso = 0; agregarModelo(mo); }

      var ag = mo._agreg;
      if (!ag) continue;
      /* segue o modelRoot: o imersivo o move e escala, e o corte tecnico
         depende de a malha estar onde a peca esta */
      ag.grupo.position.copy(modelRoot.position);
      ag.grupo.quaternion.copy(modelRoot.quaternion);
      ag.grupo.scale.copy(modelRoot.scale);
      ag.grupo.visible = modelRoot.visible !== false && mo.grupo.visible !== false;
      if (est.sig === ag.assinatura) continue;
      ag.assinatura = est.sig;
      _reaplicarAparencia(ag);
    }
  }

  /* ⚠ A PECA EM DESTAQUE E DESENHADA POR ELA MESMA. Os materiais de realce do
   * produto (selecao, 4D em andamento, conflito) tem `emissive` — eles BRILHAM.
   * Cor por vertice nao expressa emissao, e aproximar somando a cor deixaria o
   * destaque mais apagado do que o usuario conhece: medido, 0,74% dos pixels de
   * diferenca, todos em cima da peca selecionada.
   * Em vez de aproximar, a peca volta para a camada da camera e desenha com o
   * material de verdade, e o mesclado a omite. Custa uma chamada por peca em
   * destaque — normalmente uma — e o realce sai exato. */
  function _ehRealce(mat) {
    return !!(mat && mat.emissive && (mat.emissive.r > 0.002 || mat.emissive.g > 0.002 || mat.emissive.b > 0.002));
  }

  function _reaplicarAparencia(ag) {
    for (var p = 0; p < ag.partes.length; p++) {
      var parte = ag.partes[p], fx = parte.faixas, ocultos = {};
      var algumTransp = false;
      for (var f = 0; f < fx.length; f++) {
        var faixa = fx[f], ref = faixa.ref;
        if (!ref) continue;
        if (_ehRealce(ref.material)) {
          /* sai do mesclado e volta a ser desenhada por si */
          ocultos[faixa.e] = 1;
          /* ⚠ AS DUAS CAMADAS, não só a 0: a 0 é a que a câmera desenha, a 1 é
             a que o raio do clique olha. Só na 0, a peça SELECIONADA (ou em
             andamento no 4D, ou em conflito) sumia para o clique e para a trena:
             o toque seguinte atravessava e pegava o que estava atrás (e2e-bim-trena [5]). */
          ref.layers.set(1); if (ref.visible !== false) ref.layers.enable(0);
          continue;
        }
        ref.layers.set(1);
        var oculta = ref.visible === false;
        if (oculta) ocultos[faixa.e] = 1;
        var c = _corDoMaterial(ref.material);
        if (!oculta && c[3] < 1) algumTransp = true;
        /* ⚠ a cor é escrita também na peça OCULTA: uma vista com estado próprio
           (ponto de vista aberto numa aba) mostra peça que a principal esconde,
           e o buffer dela nasce destas cores — sem isto saía com alfa 0 */
        var ini = faixa.iniVert * 4, fim = ini + faixa.nVert * 4;
        for (var v = ini; v < fim; v += 4) { parte.cores[v] = c[0]; parte.cores[v + 1] = c[1]; parte.cores[v + 2] = c[2]; parte.cores[v + 3] = c[3]; }
      }
      parte.malha.geometry.attributes.color.needsUpdate = true;
      /* ⚠ so transparente quando ha o que ser transparente: material com
         transparent ligado sempre paga ordenacao e perde depth-write */
      if (parte.malha.material.transparent !== algumTransp) {
        parte.malha.material.transparent = algumTransp;
        parte.malha.material.depthWrite = !algumTransp;
        parte.malha.material.needsUpdate = true;
      }
      var r = BimAgreg.indicesVisiveis(fx, parte.idxCheio, ocultos, parte.idxVis);
      parte.idxVis = r.idx;
      var attr = parte.malha.geometry.index;
      if (attr.array !== r.idx) parte.malha.geometry.setIndex(new THREE.BufferAttribute(r.idx, 1));
      parte.malha.geometry.index.needsUpdate = true;
      parte.malha.geometry.setDrawRange(0, r.nIdx);
    }
  }

  function ligarAgregacao(on) {
    var novo = !!on;
    if (novo === AGREG.on) return AGREG.on;
    AGREG.on = novo;
    try { localStorage.setItem('orcapro:bim:agregar', novo ? '1' : '0'); } catch (_) {}
    if (novo) {
      /* o clique passa a olhar SO a camada das pecas */
      ray.layers.set(1);
      S.modelos.forEach(function (mo) { agregarModelo(mo); });
    } else {
      ray.layers.set(0); ray.layers.enable(1);
      S._origemAgreg = null;
      S.modelos.forEach(function (mo) { desagregarModelo(mo); });
    }
    return AGREG.on;
  }
  S._agregar = agregarModelo; S._desagregar = desagregarModelo; S._ligarAgregacao = ligarAgregacao;
  S._agregEstado = function () {
    if (!AGREG.on) return { on: false };
    var malhas = 0, tri = 0;
    S.modelos.forEach(function (mo) {
      if (!mo._agreg) return;
      mo._agreg.partes.forEach(function (p) { malhas++; tri += p.idxCheio.length / 3; });
    });
    return { on: true, malhasMescladas: malhas, triangulos: tri, origem: S._origemAgreg };
  };
  /* o espelhamento anda com o quadro — e o mesmo gancho que a lupa e as cotas usam */
  S._tickExtra.push(function () { sincronizarAgregado(); });
  S._tickExtra.push(function () { if (S._cristalTickEscala) S._cristalTickEscala(); });
  /* ⚠ `cota.on` PRECISA estar aqui. O `pointerup` sai cedo quando nenhuma
     ferramenta consome clique (a porteira logo abaixo), e sem esta linha o
     botao Cotar ficaria MUDO: sem raycast, sem erro, sem log. */
  function ferramentaClique() { return medir.on || area.on || ang.on || ctec.ativo || cota.on || (S.edit && S.edit.on); } // quem consome clique-sem-arraste (editor SEM sub-ferramenta = clique mostra parâmetros)
  // GUARD ÚNICO anti-ponto-fantasma (gate v1.1.69): quando um clique FECHA uma medição/linha
  // (área, ângulo, trena, corte técnico), o pointerup IRMÃO do duplo-clique chegaria <400ms
  // depois NO MESMO LUGAR e plantaria o 1º ponto da próxima medição — silenciosamente errada.
  // Temporal+ESPACIAL (<20px): não pune usuário rápido clicando em outro canto.
  var toolFechou = null, _upAtual = null;
  function marcarFechamento() { toolFechou = _upAtual ? { x: _upAtual.x, y: _upAtual.y, t: performance.now() } : { x: -1e9, y: -1e9, t: performance.now() }; }
  /* toque simples do visitante (seleção ou o ponto do "Apontar"): um dedo,
     sem arrastar mais de 10 px, em menos de meio segundo. Segundo dedo na
     tela = pinça de zoom, e cancela o toque. */
  var _toque = null, _dedos = 0;
  canvasEl.addEventListener('pointerdown', function (e) {
    if (!S || !S.alive) return;
    _dedos++;
    if (e.pointerType) _ptrTipo = e.pointerType;
    _toque = (_dedos === 1 && e.button === 0) ? { x: e.clientX, y: e.clientY, t: performance.now(), ts: e.timeStamp || 0, id: e.pointerId } : null;
    if (ferramentaClique()) medir.down = (e.button === 0) ? { x: e.clientX, y: e.clientY } : null;
    /* 🔍 toque-e-segure abre a lupa (só no DEDO, só com ferramenta de ponto
       ativa). No mouse não faz falta: lá o cursor não tapa o alvo e o
       marcador de snap já segue o `pointermove`. */
    if (e.pointerType === 'touch' && ferramentaClique() && medir.down && S._lupaAgendar) S._lupaAgendar(e);
    /* ⚠ SEGUNDO DEDO = "quero navegar", não "quero mirar". Encostar o outro dedo
       com a lupa aberta é pinça de zoom: fecha a mira e devolve a órbita na
       hora, em vez de deixar a câmera travada esperando um `pointerup` que pode
       nunca vir no ponteiro certo. */
    if (S.lupa && S.lupa.on && S.lupa.id != null && e.pointerId !== S.lupa.id && S._lupaFechar) S._lupaFechar();
  });
  /* ⚠ SAÍDA DE EMERGÊNCIA. A lupa desliga a órbita enquanto mira. Se o sistema
   * cancelar o toque no meio (ligação chegando, notificação, gesto do sistema
   * na borda), não vem `pointerup` — e a câmera ficaria TRAVADA, com uma lupa
   * pendurada na tela e nenhum jeito de sair a não ser recarregar. Cancelar
   * fecha e devolve a órbita. */
  canvasEl.addEventListener('pointercancel', function (e) {
    if (!S || !S.alive) return;
    _dedos = Math.max(0, _dedos - 1); _toque = null;
    medir.down = null;
    if (S._lupaSoltar) S._lupaSoltar(e);
  });
  canvasEl.addEventListener('pointerup', function (e) {
    if (!S || !S.alive) return;
    /* ⚠ A LUPA SOLTA ANTES DA PORTEIRA, e isto não é estilo: é o conserto de uma
     * TRAVA PERMANENTE. A lupa desliga a órbita enquanto mira. Com a soltura
     * depois do `return` de cima, bastava um SEGUNDO DEDO na tela: o
     * `pointerdown` dele sobrescrevia `medir.down`, o dedo dono da lupa
     * levantava e zerava `medir.down`, e quando o segundo levantava a porteira
     * `!medir.down` barrava — `_lupaSoltar` nunca rodava. Resultado: lupa
     * pendurada na tela e câmera 3D travada PARA SEMPRE, sem jeito de sair a
     * não ser recarregar a página. E `pointercancel` não salva: o OrbitControls
     * põe `touchAction:'none'` no canvas, então a pinça não é cancelada pelo
     * navegador — ela chega como dois ponteiros normais. */
    var alvoLupa = S._lupaSoltar ? S._lupaSoltar(e) : null;
    _dedos = Math.max(0, _dedos - 1);
    var tq = _toque; _toque = null;
    if (tq && tq.id === e.pointerId && !ferramentaClique() && !fly.on && !xr.on && (visitante || S._aoTocar || S._aoClicarPeca || S._aoMarcarPonto)) {
      var tdx = e.clientX - tq.x, tdy = e.clientY - tq.y;
      /* ⚠ DURAÇÃO PELO RELÓGIO DO DEDO (timeStamp do evento), não pela hora em
         que o código rodou. Com o 3D na tela inteira, cada quadro de um modelo
         pesado num celular fraco pode levar meio segundo: o `pointerup` era
         tratado 1,1 s depois do `pointerdown` (medido na e2e de 29/09) e o
         toque de 80 ms virava "segurou o dedo" — a ficha da peça não abria. */
      var durou = (tq.ts > 0 && e.timeStamp > 0) ? e.timeStamp - tq.ts : performance.now() - tq.t;
      if (tdx * tdx + tdy * tdy <= 100 && durou < 500) {
        if (S._aoMarcarPonto) { var fm = S._aoMarcarPonto, om = S._aoMarcarOpts; S._aoMarcarPonto = null; S._aoMarcarOpts = null; try { fm(S._icar.pontoNoChao(e.clientX, e.clientY, om)); } catch (eM) {} } // içamento: um clique = um ponto no chão
        else if (S._aoTocar) { var fn = S._aoTocar; S._aoTocar = null; try { fn(pontoNaTela(e.clientX, e.clientY)); } catch (eT) {} }
        else if (S._aoClicarPeca) cliqueColetor(e);
        else selecionarEm(e.clientX, e.clientY);
        return;
      }
    }
    if (!ferramentaClique() || e.button !== 0) { medir.down = null; return; } // só botão esquerdo/toque
    if (!alvoLupa && !medir.down) return;
    /* 🔍 LUPA: se ela estava aberta, o ponto é o da MIRA, não o do dedo — e o
       arraste que a mira fez NÃO pode ser lido como órbita (é o teste logo
       abaixo, que descartaria o ponto justamente de quem mirou com cuidado). */
    var dx = 0, dy = 0;
    if (medir.down) { dx = e.clientX - medir.down.x; dy = e.clientY - medir.down.y; }
    medir.down = null;
    if (!alvoLupa && dx * dx + dy * dy > 100) return; // arrastou (>10px) -> era órbita; tolerância p/ toque (tablet)
    if (alvoLupa) { e = { clientX: alvoLupa.x, clientY: alvoLupa.y, button: 0, detail: 1, pointerType: 'touch' }; }
    if (toolFechou && performance.now() - toolFechou.t < 400) {
      var fdx = e.clientX - toolFechou.x, fdy = e.clientY - toolFechou.y;
      // irmão do duplo-clique: o navegador marca com detail>=2 (contagem de cliques); o critério
      // espacial <6px cobre double-tap de toque. Clique intencional (outra posição/1º clique) passa.
      if (e.detail >= 2 || fdx * fdx + fdy * fdy < 36) return;
    }
    _upAtual = { x: e.clientX, y: e.clientY };
    var hit = raycastEm(e.clientX, e.clientY);
    if (S.edit && S.edit.on && S.edit.sub) { editClique(e, hit); return; } // editor: aceita hit OU plano do chão
    if (S.edit && S.edit.on && !S.edit.sub) { // editor SEM ferramenta: clique simples mostra os parâmetros (estilo Revit)
      if (hit && _ultimosHits[0]) {
        var udP = _ultimosHits[0].object.userData;
        if (opts.onPick) opts.onPick(propsDe(udP.mid !== undefined ? udP.mid : S.modelID, udP.expressID, udP.tipo));
      }
      return;
    }
    /* COTAR REDE — antes do snap de propósito: aqui não se marca ponto, se
       escolhe uma PEÇA. Passar pelo snap acenderia a marca verde de vértice,
       que promete uma medição que este modo não faz. */
    if (cota.on) {
      if (!hit) { S._hint('Toque em cima de um tubo para ver o comprimento dele.'); return; }
      var udC = hit.object.userData || {};
      if (udC.expressID == null) { S._hint('Isso não é uma peça do modelo.'); return; }
      var uidC = (udC.mid != null ? udC.mid : S.modelID) + ':' + udC.expressID;
      var reg = null, ixC = cotaIndice();
      for (var ic = 0; ic < ixC.length; ic++) if (ixC[ic].uid === uidC) { reg = ixC[ic]; break; }
      if (!reg) {
        /* ⚠ NÃO INVENTAR. Sem quantidade no IFC, o modo diz isso e oferece a
           trena — nunca estima pela caixa do elemento, que num ramal com
           caimento devolve a DIAGONAL. */
        var elC = null;
        elementosVivos().forEach(function (x) { if (x.uid === uidC) elC = x; });
        S._hint(elC && !cotaEhRede(elC)
          ? 'Essa peça não é tubulação — o modo Cotar rede vale para tubo, duto e conexão.'
          : 'Este tubo não tem comprimento publicado no IFC. Use a trena para medir.');
        marcarFechamento(); return;
      }
      /* segundo toque no mesmo tubo tira a cota — é como o cliente desfaz */
      if (cota.fixados[uidC]) delete cota.fixados[uidC]; else cota.fixados[uidC] = 1;
      cota.chave = reg.chave;          // alimenta o modo "Iguais"
      if (cota.modo !== 'clicado') cota.modo = 'clicado';
      cota.acum = cota.periodo;        // redesenha no próximo quadro
      S._hint(fmtDist(reg.L) + ' · ' + (reg.temFamilia ? reg.chave : 'sem família no IFC — “Iguais” usa o tipo'));
      marcarFechamento(); return;
    }
    /* `mirarEm`, não o `hit` cru: com o cursor na borda (ou fora) da peça o
       canto dela ainda vale — é o mesmo cálculo que o marcador mostrou */
    var sn = mirarParaClique(e.clientX, e.clientY, raioToque(e));
    if (!sn || !sn.p) { S._hint((ctec.ativo ? '📝' : area.on ? '▱' : ang.on ? '∠' : '📏') + (ehToque() ? ' Toque em cima de uma superfície do modelo.' : ' Clique em cima de uma superfície do modelo.')); return; }
    mostrarSnapMarca(sn, e.clientX, e.clientY);
    if (ctec.ativo) { ctecClique(sn.p.clone()); return; } // linha do corte técnico tem prioridade
    if (area.on) { areaClique(sn.p.clone()); return; }
    if (ang.on) { angClique(sn.p.clone()); return; }
    medir.pts.push({ p: sn.p.clone() });
    if (medir.pts.length === 1) medir.dirAresta = dirDaAresta(sn);
    if (medir.pts.length === 2) {
      tirarProv(); // a marca definitiva do 1º ponto é desenhada por desenharMedida (evita marca dupla)
      _shift = !!e.shiftKey;
      var rr = restringir(medir.pts[0].p, medir.pts[1].p);
      var ok = desenharMedida(medir.pts[0].p, rr.p, rr.rot ? false : null, rr.rot); medir.pts = []; atualizarElastico(null);
      marcarFechamento(); // duplo-clique no 2º ponto não planta o 1º ponto da próxima cota
      S._hint(trenaTxt(ok ? 'ok' : 'perto'));
    } else {
      var m0 = pontoMarca(medir.pts[0].p); addMed(m0); medir.prov = m0;
      /* "ao longo da aresta" sem aresta no 1º ponto: diz, e mede livre — não inventa direção */
      if (medir.eixo === 'aresta' && !medir.dirAresta) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '') + ' Para medir ao longo de uma aresta, comece o 1º ponto EM CIMA da aresta. Esta medida vai livre.');
      else S._hint(trenaTxt('2o'));
    }
  });
  // hover do snap: feedback ao vivo de onde a trena vai "agarrar" (throttle p/ não pesar o raycast)
  var _snapHoverT = 0;
  canvasEl.addEventListener('pointermove', function (e) {
    if (!S || !S.alive) return;
    /* 🔍 com a lupa aberta o dedo move a MIRA, e mais nada acontece neste
       handler: nem preview de parede, nem o hover normal do snap. */
    if (S._lupaMover && S._lupaMover(e)) return;
    // v1.1.82 — preview vivo da parede (rubber-band + cota junto ao cursor, estilo Revit)
    if (S.edit && S.edit.on && S.edit.sub === 'parede' && S.edit.p1 && S._editPreviewMove) {
      S._editPreviewMove(e);
    }
    if (!ferramentaClique() || !snap.on) return;
    var t = performance.now(); if (t - _snapHoverT < 60) return; _snapHoverT = t;
    _shift = !!e.shiftKey;
    var sn = mirarEm(e.clientX, e.clientY, raioToque(e));
    if (!sn || !sn.p) { esconderSnapMarca(); return; }
    mostrarSnapMarca(sn, e.clientX, e.clientY);
  });

  // ============================================================
  // ▱ ÁREA (polígono) e ∠ ÂNGULO — mesmas garantias da trena: todo ponto
  // produzido passa pelo raycast filtrado (visível + fora do clip) e pelo snap.
  // ÁREA na planta = projeção HORIZONTAL (XZ, o que a planta representa);
  // em 3D = plano médio do polígono (vetor-área de Newell) — se os pontos
  // fugirem do plano, o rótulo declara "≈ plano médio" (nunca número mudo).
  // ============================================================
  var area = { on: false, pts: [], tmp: [] };
  var ang = { on: false, pts: [], tmp: [] };
  S.area = area; S.ang = ang;
  // remove SÓ os provisórios (marcas/segmentos do polígono em andamento) sem tocar nas medidas prontas
  function limparTmp(t) { t.forEach(function (o) { var i = medir.objs.indexOf(o); if (i >= 0) medir.objs.splice(i, 1); limparMarca(o); }); t.length = 0; }
  function fmtArea(a) { return (a >= 1 ? a.toFixed(2) : a.toFixed(3)).replace('.', ',') + ' m²'; }
  // área+perímetro do polígono. horizontal=true -> projeção XZ (shoelace). Senão, vetor-área de
  // Newell: |Σ cross|/2 é a área da projeção no plano médio — exata p/ polígono plano, aproximação
  // declarada p/ não-plano (aprox=true quando o desvio ao plano passa de 2% do lado típico).
  function areaCalc(pts, horiz) {
    var n = pts.length, i, p, q;
    if (horiz == null ? planta.on : horiz) {
      var a2 = 0, perH = 0;
      for (i = 0; i < n; i++) {
        p = pts[i]; q = pts[(i + 1) % n];
        a2 += p.x * q.z - q.x * p.z;
        perH += Math.sqrt((q.x - p.x) * (q.x - p.x) + (q.z - p.z) * (q.z - p.z));
      }
      return { area: Math.abs(a2) / 2, per: perH, aprox: false, horizontal: true, normal: new THREE.Vector3(0, 1, 0) };
    }
    var nx = 0, ny = 0, nz = 0, per = 0, cx = 0, cy = 0, cz = 0;
    for (i = 0; i < n; i++) {
      p = pts[i]; q = pts[(i + 1) % n];
      nx += (p.y - q.y) * (p.z + q.z); ny += (p.z - q.z) * (p.x + q.x); nz += (p.x - q.x) * (p.y + q.y);
      per += p.distanceTo(q); cx += p.x; cy += p.y; cz += p.z;
    }
    var nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
    if (nl < 1e-9) return null; // colinear/degenerado
    cx /= n; cy /= n; cz /= n;
    var desv = 0;
    for (i = 0; i < n; i++) { var dv = Math.abs(((pts[i].x - cx) * nx + (pts[i].y - cy) * ny + (pts[i].z - cz) * nz) / nl); if (dv > desv) desv = dv; }
    var areaV = nl / 2;
    return { area: areaV, per: per, aprox: desv > Math.max(0.01, Math.sqrt(areaV) * 0.02), horizontal: false, normal: new THREE.Vector3(nx / nl, ny / nl, nz / nl) };
  }
  S._areaCalc = areaCalc; // hook de teste (oráculo Node/E2E)
  // preenchimento translúcido: triangula no plano do polígono (base ortonormal da normal)
  function preencherPoligono(pts, normal) {
    try {
      var nv = normal.clone().normalize();
      var ref = Math.abs(nv.y) < 0.9 ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0);
      var bu = new THREE.Vector3().crossVectors(ref, nv).normalize();
      var bv = new THREE.Vector3().crossVectors(nv, bu);
      var p2 = pts.map(function (pp) { return new THREE.Vector2(pp.dot(bu), pp.dot(bv)); });
      var tris = THREE.ShapeUtils.triangulateShape(p2, []);
      if (!tris.length) return null;
      var pos = new Float32Array(pts.length * 3);
      pts.forEach(function (pp, i2) { pos[i2 * 3] = pp.x; pos[i2 * 3 + 1] = pp.y; pos[i2 * 3 + 2] = pp.z; });
      var idx = [];
      tris.forEach(function (t2) { idx.push(t2[0], t2[1], t2[2]); });
      var bg = new THREE.BufferGeometry();
      bg.setAttribute('position', new THREE.BufferAttribute(pos, 3)); bg.setIndex(idx);
      var mh = new THREE.Mesh(bg, new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.16, depthTest: false, side: THREE.DoubleSide }));
      mh.renderOrder = 996;
      return mh;
    } catch (_) { return null; } // polígono auto-intersectado etc.: fica só o contorno + rótulo
  }
  function setArea(on) {
    area.on = !!on;
    if (on) { setMode(false); if (medir.on) setMedir(false); if (ang.on) setAng(false); if (edit && edit.on) setEdit(false); } // coexiste com Planta/Corte; exclusivo entre medições e editor
    else { limparTmp(area.tmp); area.pts = []; esconderSnapMarca(); btnCotas(); }
    var b = bar.querySelector('[data-b="area"]'); if (b) { b.style.background = on ? corAtiva() : ''; b.style.color = on ? '#fff' : ''; }
    atualizarCursor();
    S._hint(on ? ('▱ Área: clique os cantos (3+)' + (planta.on ? ' na planta' : '') + ' e feche clicando de novo no 1º ponto (ou duplo-clique).') : (planta.on ? '' + (typeof Icones !== 'undefined' ? Icones.get('regua', 15) : '') + ' Planta baixa. Ajuste a altura do corte no painel.' : ''));
  }
  S._setArea = setArea;
  function areaClique(p) {
    // fechar: clique perto (na TELA) do 1º ponto, com 3+ pontos marcados.
    // Vetores locais novos — REGRA do gate v1.1.65: nunca passar pra project() um scratch que carrega candidato.
    if (area.pts.length >= 3) {
      var rc2 = canvasEl.getBoundingClientRect();
      var v0 = new THREE.Vector3().copy(area.pts[0]).project(camera);
      var vp = new THREE.Vector3().copy(p).project(camera);
      var ddx = (v0.x - vp.x) / 2 * rc2.width, ddy = (v0.y - vp.y) / 2 * rc2.height;
      if (ddx * ddx + ddy * ddy < 18 * 18) { fecharArea(); return; }
    }
    area.pts.push(p);
    var m = pontoMarca(p); m.material.color.set(0x38bdf8); addMed(m); area.tmp.push(m);
    if (area.pts.length > 1) {
      var seg = new THREE.Line(new THREE.BufferGeometry().setFromPoints([area.pts[area.pts.length - 2], p]), new THREE.LineBasicMaterial({ color: 0x38bdf8, depthTest: false }));
      seg.renderOrder = 997; addMed(seg); area.tmp.push(seg);
    }
    S._hint(area.pts.length < 3 ? ('▱ Ponto ' + area.pts.length + ' — siga marcando os cantos.') : ('▱ ' + area.pts.length + ' pontos — feche clicando no 1º ponto (ou duplo-clique).'));
  }
  function fecharArea() {
    if (!area.on || area.pts.length < 3) { S._hint('▱ Marque pelo menos 3 pontos antes de fechar.'); return; }
    marcarFechamento(); // engole o pointerup irmão do duplo-clique (ponto fantasma)
    // dedupe: duplo-clique de fechar dispara pointerup 2x no mesmo lugar -> pontos consecutivos coincidentes
    var pts = [];
    area.pts.forEach(function (pp) { if (!pts.length || pp.distanceTo(pts[pts.length - 1]) > 2e-3) pts.push(pp); });
    if (pts.length > 1 && pts[pts.length - 1].distanceTo(pts[0]) < 2e-3) pts.pop();
    limparTmp(area.tmp); area.pts = [];
    if (pts.length < 3) { S._hint('▱ Pontos coincidentes — marque 3+ cantos distintos.'); return; }
    if (!desenharArea(pts)) { S._hint('▱ Pontos colineares — não formam área. Recomece.'); return; }
    S._hint('▱ Área medida! Clique os cantos da próxima, ou Esc pra sair.');
  }
  /* desenho final da área — separado do clique para o ponto de vista poder
     redesenhar a área gravada sem passar pela ferramenta */
  function desenharArea(pts, horiz) {
    var res = areaCalc(pts, horiz);
    if (!res || res.area < 1e-4) return null;
    // desenho final: contorno fechado + preenchimento + marcas + rótulo no centro
    var loop = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts.concat([pts[0]])), new THREE.LineBasicMaterial({ color: 0x38bdf8, depthTest: false }));
    loop.renderOrder = 997; addMed(loop);
    pts.forEach(function (pp) { var mk = pontoMarca(pp); mk.material.color.set(0x38bdf8); addMed(mk); });
    var fill = preencherPoligono(pts, res.normal); if (fill) addMed(fill);
    var c = new THREE.Vector3(); pts.forEach(function (pp) { c.add(pp); }); c.multiplyScalar(1 / pts.length);
    var sufixo = res.horizontal ? ' (horizontal)' : (res.aprox ? ' ≈ plano médio' : '');
    var lab = labelSprite('▱ ' + fmtArea(res.area) + ' · per ' + fmtDist(res.per) + sufixo);
    lab.position.copy(c); addMed(lab); btnCotas();
    medir.ultimaArea = { area: res.area, perimetro: res.per, horizontal: res.horizontal, aproximada: res.aprox, pontos: pts.length };
    medir.regs.push({ tipo: 'area', pts: pts.map(pxyz), horizontal: res.horizontal });
    return res;
  }
  function setAng(on) {
    ang.on = !!on;
    if (on) { setMode(false); if (medir.on) setMedir(false); if (area.on) setArea(false); if (edit && edit.on) setEdit(false); }
    else { limparTmp(ang.tmp); ang.pts = []; esconderSnapMarca(); btnCotas(); }
    var b = bar.querySelector('[data-b="angulo"]'); if (b) { b.style.background = on ? corAtiva() : ''; b.style.color = on ? '#fff' : ''; }
    atualizarCursor();
    S._hint(on ? '∠ Ângulo: clique o 1º ponto, depois o VÉRTICE, depois o 2º ponto.' : (planta.on ? '' + (typeof Icones !== 'undefined' ? Icones.get('regua', 15) : '') + ' Planta baixa. Ajuste a altura do corte no painel.' : ''));
  }
  S._setAng = setAng;
  function angClique(p) {
    ang.pts.push(p);
    var m = pontoMarca(p); m.material.color.set(0xf59e0b); addMed(m); ang.tmp.push(m);
    if (ang.pts.length > 1) {
      var seg = new THREE.Line(new THREE.BufferGeometry().setFromPoints([ang.pts[ang.pts.length - 2], p]), new THREE.LineBasicMaterial({ color: 0xf59e0b, depthTest: false }));
      seg.renderOrder = 997; addMed(seg); ang.tmp.push(seg);
    }
    if (ang.pts.length === 1) { S._hint('∠ Agora clique o VÉRTICE do ângulo.'); return; }
    if (ang.pts.length === 2) { S._hint('∠ Agora clique o 2º ponto.'); return; }
    var P1 = ang.pts[0], V = ang.pts[1], P2 = ang.pts[2];
    marcarFechamento(); // 3º ponto pode vir de duplo-clique — engole o irmão
    limparTmp(ang.tmp); ang.pts = [];
    var deg = desenharAngulo(P1, V, P2);
    if (deg == null) { S._hint('∠ Pontos coincidentes — recomece: 1º ponto, vértice, 2º ponto.'); return; }
    S._hint('∠ ' + deg.toFixed(1).replace('.', ',') + '° — clique 3 pontos pra medir outro, ou Esc pra sair.');
  }
  /* desenho final do ângulo — separado do clique pelo mesmo motivo da área */
  function desenharAngulo(P1, V, P2) {
    var u = P1.clone().sub(V), v = P2.clone().sub(V);
    if (u.length() < 2e-3 || v.length() < 2e-3) return null;
    var rad = u.angleTo(v), deg = rad * 180 / Math.PI;
    // desenho final: os 2 lados + arco no plano u,v + rótulo na bissetriz
    [[V, P1], [V, P2]].forEach(function (par) {
      var l2 = new THREE.Line(new THREE.BufferGeometry().setFromPoints(par), new THREE.LineBasicMaterial({ color: 0xf59e0b, depthTest: false }));
      l2.renderOrder = 997; addMed(l2);
    });
    [P1, V, P2].forEach(function (pp) { var mk = pontoMarca(pp); mk.material.color.set(0xf59e0b); addMed(mk); });
    var eixo = new THREE.Vector3().crossVectors(u, v), r = Math.min(u.length(), v.length()) * 0.35;
    if (eixo.lengthSq() > 1e-12) { // 0°/180° não têm plano definido -> sem arco (só rótulo)
      eixo.normalize();
      var arcPts = [], un = u.clone().normalize();
      for (var t2 = 0; t2 <= 16; t2++) arcPts.push(V.clone().add(un.clone().applyAxisAngle(eixo, rad * t2 / 16).multiplyScalar(r)));
      var arco = new THREE.Line(new THREE.BufferGeometry().setFromPoints(arcPts), new THREE.LineBasicMaterial({ color: 0xf59e0b, depthTest: false }));
      arco.renderOrder = 997; addMed(arco);
    }
    var bis = u.clone().normalize().add(v.clone().normalize());
    if (bis.lengthSq() < 1e-9) bis = (eixo.lengthSq() > 1e-12 ? new THREE.Vector3().crossVectors(eixo, u).normalize() : new THREE.Vector3(0, 1, 0)); else bis.normalize();
    var lab = labelSprite('∠ ' + deg.toFixed(1).replace('.', ',') + '°');
    lab.position.copy(V).add(bis.multiplyScalar(Math.max(r * 1.4, 0.05)));
    addMed(lab); btnCotas();
    medir.ultimoAngulo = { graus: deg };
    medir.regs.push({ tipo: 'ang', pts: [pxyz(P1), pxyz(V), pxyz(P2)], horizontal: false });
    return deg;
  }

  // ============================================================
  // PLANTA BAIXA — plano de corte horizontal com altura ajustável
  // ============================================================
  var planta = { on: false, plane: null, y0: 0, y1: 1 };
  S.planta = planta;
  var cortePanel = document.createElement('div');
  cortePanel.style.cssText = 'position:absolute;left:10px;bottom:10px;z-index:4;display:none;flex-direction:column;gap:7px;background:rgba(255,255,255,.98);border:1px solid #d3dce6;border-radius:11px;padding:11px 13px;color:#1a2b3c;font-size:12px;width:220px';
  cortePanel.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:baseline"><b>' + (typeof Icones !== 'undefined' ? Icones.get('regua', 15) : '') + ' Altura do corte</b><span data-c="v" style="color:#15803d;font-weight:700">—</span></div>' +
    '<input type="range" data-c="alt" min="0" max="1000" value="620" style="width:100%;accent-color:#22c55e">' +
    '<div style="font-size:11px;color:#5b6b7c">Esconde o que está acima do corte — a planta baixa do pavimento. A ' + (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '') + ' trena funciona aqui (cota horizontal).</div>' +
    '<button class="btn sm primary" data-c="planta2d" style="width:100%">' + (typeof Icones !== 'undefined' ? Icones.get('nota', 15) : '') + ' Planta baixa técnica (2D)</button>' +
    '<button class="btn sm" data-c="estilo" style="width:100%">' + (typeof Icones !== 'undefined' ? Icones.get('editar', 15) : '') + ' Estilo desenho (branco)</button>' +
    '<button class="btn sm" data-c="cortetec" style="width:100%">' + (typeof Icones !== 'undefined' ? Icones.get('nota', 15) : '') + ' Gerar corte técnico (A–A)</button>';
  host.appendChild(cortePanel);
  S.cortePanel = cortePanel; // guardado p/ re-parentar no re-home (senão o slider some ao revisitar a aba)
  function setAlturaCorte(frac) {
    if (!planta.plane) return;
    var y = planta.y0 + (planta.y1 - planta.y0) * frac; planta.plane.constant = y;
    var rot = cortePanel.querySelector('[data-c="v"]'); if (rot) rot.textContent = fmtDist(Math.max(0, y - planta.y0)) + ' do piso'; // mundo já em metros
  }
  function setPlanta(on) {
    planta.on = !!on;
    if (S._pintarEixo) setTimeout(S._pintarEixo, 0);
    var bp = bar.querySelector('[data-b="planta"]');
    if (on) {
      if (corteL.on) setCorteL(false); // planta e corte livre disputam o MESMO clippingPlanes
      if (S._cxDesligar) S._cxDesligar(); // …e a caixa de corte também
      setMode(false); // trena PODE ficar ligada (medir na planta é o uso pedido)
      var box = new THREE.Box3().setFromObject(modelRoot);
      if (box.isEmpty()) { planta.on = false; S._hint('Carregue um modelo primeiro.'); return; }
      var min = box.min, max = box.max, c = box.getCenter(new THREE.Vector3());
      planta.y0 = min.y; planta.y1 = max.y;
      planta.plane = new THREE.Plane(new THREE.Vector3(0, -1, 0), max.y); // normal -Y: mantém o que está ABAIXO
      renderer.localClippingEnabled = true; renderer.clippingPlanes = [planta.plane];
      orbit.enableRotate = false; // planta: só translada/zoom (vista de topo travada)
      enquadrarTopo();
      cortePanel.style.display = 'flex';
      cortePanel.querySelector('[data-c="alt"]').value = 620; setAlturaCorte(0.62); // ~altura de peitoril
      if (bp) { bp.style.background = corAtiva(); bp.style.color = '#fff'; }
      if (!estiloD.on && !sisColor.on) setEstiloDesenho(true); // planta "como deve ser": entra já em modo desenho (branco + arestas). MAS se o usuário ligou "colorir por sistema", a planta sai COLORIDA (é o pedido: cores do sistema na planta baixa)
      S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('regua', 15) : '') + ' Planta baixa. Ajuste a altura do corte e gere a ' + (typeof Icones !== 'undefined' ? Icones.get('nota', 15) : '') + ' planta técnica com cotas no painel. Toque em ' + (typeof Icones !== 'undefined' ? Icones.get('regua', 15) : '') + ' de novo pra sair.');
    } else {
      ctecCancelar(); // desenho/config do corte técnico só faz sentido NA planta (incondicional: pega a config aberta)
      plantaCfg.style.display = 'none'; // config da planta técnica idem
      if (estiloD.on) setEstiloDesenho(false); // devolve as cores do modelo
      renderer.clippingPlanes = []; renderer.localClippingEnabled = false; planta.plane = null;
      orbit.enableRotate = true; // volta a permitir órbita livre
      cortePanel.style.display = 'none';
      if (bp) { bp.style.background = ''; bp.style.color = ''; }
      enquadrar(); S._hint(medir.on ? '' + (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '') + ' Trena: clique em 2 pontos do modelo pra medir. Esc sai.' : '');
    }
  }
  S._setPlanta = setPlanta;
  // vista de topo travada (reusada por setPlanta ao entrar E pelo Enquadrar dentro da planta)
  function enquadrarTopo() {
    if (S._cancelTween) S._cancelTween(); // fit-na-planta cancela voo pendente (senão o tween puxa a câmera pra fora do topo)
    var box = new THREE.Box3().setFromObject(modelRoot); if (box.isEmpty()) return;
    var c = box.getCenter(new THREE.Vector3());
    var sizeXZ = Math.max(box.max.x - box.min.x, box.max.z - box.min.z) || 10;
    camera.position.set(c.x, box.max.y + sizeXZ * 1.15, c.z);
    orbit.target.set(c.x, box.min.y, c.z); orbit.update();
  }
  S._enquadrarTopo = enquadrarTopo;
  // modelo removido com a planta ativa: re-ancora y0/y1 no bbox restante (senão o slider ganha zona morta)
  function replanejarCorte() {
    if (!planta.on || !planta.plane) return;
    var box = new THREE.Box3().setFromObject(modelRoot);
    if (box.isEmpty()) { setPlanta(false); return; }
    planta.y0 = box.min.y; planta.y1 = box.max.y;
    var sl = cortePanel.querySelector('[data-c="alt"]');
    setAlturaCorte((sl ? +sl.value : 620) / 1000);
  }
  S._replanejarCorte = replanejarCorte;
  cortePanel.querySelector('[data-c="alt"]').addEventListener('input', function () { setAlturaCorte(this.value / 1000); });
  cortePanel.querySelector('[data-c="cortetec"]').addEventListener('click', function () { ctecIniciar(); });
  cortePanel.querySelector('[data-c="planta2d"]').addEventListener('click', function () { fecharPaineis(); ctecCancelar(); plantaCfg.style.display = 'flex'; }); // planta técnica e corte A–A são modais centrais no mesmo z — não empilham
  cortePanel.querySelector('[data-c="estilo"]').addEventListener('click', function () { setEstiloDesenho(!estiloD.on); });

  // ============================================================
  // ✂️ CORTE LIVRE — plano de corte em QUALQUER orientação, ao vivo
  // (horizontal, vertical N–S/L–O ou ângulo custom: azimute 0–360° + inclinação 0–90°).
  // Diferente da planta, a órbita fica LIVRE: o usuário gira em volta do corte.
  // ============================================================
  var corteL = { on: false, plane: new THREE.Plane(new THREE.Vector3(0, -1, 0), 0), az: 0, inc: 0, inv: false, d0: 0, d1: 1 };
  S.corteL = corteL;
  var corteLPanel = document.createElement('div');
  corteLPanel.style.cssText = 'position:absolute;left:10px;bottom:10px;z-index:4;display:none;flex-direction:column;gap:7px;background:rgba(255,255,255,.98);border:1px solid #d3dce6;border-radius:11px;padding:11px 13px;color:#1a2b3c;font-size:12px;width:240px';
  corteLPanel.innerHTML =
    '<div style="display:flex;justify-content:space-between;align-items:baseline"><b>' + (typeof Icones !== 'undefined' ? Icones.get('corte', 15) : '') + ' Plano de corte</b><span data-k="v" style="color:#15803d;font-weight:700">—</span></div>' +
    '<div style="display:flex;gap:5px"><button class="btn sm" data-k="ph" style="flex:1">Horizontal</button><button class="btn sm" data-k="pns" style="flex:1">N–S</button><button class="btn sm" data-k="plo" style="flex:1">L–O</button></div>' +
    '<label style="display:flex;justify-content:space-between;font-size:11px;color:#5b6b7c">Ângulo (azimute) <span data-k="azv">0°</span></label>' +
    '<input type="range" data-k="az" min="0" max="359" value="0" style="width:100%;accent-color:#22c55e">' +
    '<label style="display:flex;justify-content:space-between;font-size:11px;color:#5b6b7c">Inclinação (0=vertical, 90=horizontal) <span data-k="incv">0°</span></label>' +
    '<input type="range" data-k="inc" min="0" max="90" value="0" style="width:100%;accent-color:#22c55e">' +
    '<label style="display:flex;justify-content:space-between;font-size:11px;color:#5b6b7c">Posição do corte <span data-k="posv">50%</span></label>' +
    '<input type="range" data-k="pos" min="0" max="1000" value="500" style="width:100%;accent-color:#22c55e">' +
    '<button class="btn sm" data-k="inv" style="width:100%">' + (typeof Icones !== 'undefined' ? Icones.get('ciclo', 15) : '') + ' Inverter lado visível</button>' +
    '<div style="font-size:11px;color:#5b6b7c">O modelo some do lado cortado conforme você move. Gire a órbita normalmente. A ' + (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '') + ' trena funciona na face do corte.</div>';
  corteLPanel.setAttribute('data-bim', 'corteL');   /* o modo mesa troca este painel pelo controle de dedo */
  host.appendChild(corteLPanel);
  S.corteLPanel = corteLPanel;
  function corteNormal() {
    var az = corteL.az * Math.PI / 180, inc = corteL.inc * Math.PI / 180;
    return new THREE.Vector3(Math.sin(az) * Math.cos(inc), Math.sin(inc), Math.cos(az) * Math.cos(inc));
  }
  function aplicarCorteL() {
    if (!corteL.on) return;
    var n = corteNormal();
    var box = new THREE.Box3().setFromObject(modelRoot);
    if (box.isEmpty()) { setCorteL(false); return; }
    // faixa da posição = projeção dos 8 cantos do bbox na normal
    var d0 = Infinity, d1 = -Infinity, c = new THREE.Vector3();
    for (var i = 0; i < 8; i++) {
      c.set(i & 1 ? box.max.x : box.min.x, i & 2 ? box.max.y : box.min.y, i & 4 ? box.max.z : box.min.z);
      var d = n.dot(c); if (d < d0) d0 = d; if (d > d1) d1 = d;
    }
    corteL.d0 = d0; corteL.d1 = d1;
    var frac = (+corteLPanel.querySelector('[data-k="pos"]').value) / 1000;
    var s = d0 + (d1 - d0) * frac;
    // mantém n·p <= s (plano normal -n, constant s); invertido mantém n·p >= s
    if (corteL.inv) { corteL.plane.normal.copy(n); corteL.plane.constant = -s; }
    else { corteL.plane.normal.copy(n).negate(); corteL.plane.constant = s; }
    renderer.localClippingEnabled = true; renderer.clippingPlanes = [corteL.plane];
    corteLPanel.querySelector('[data-k="v"]').textContent = fmtDist(Math.max(0, s - d0));
    corteLPanel.querySelector('[data-k="azv"]').textContent = corteL.az + '°';
    corteLPanel.querySelector('[data-k="incv"]').textContent = corteL.inc + '°';
    corteLPanel.querySelector('[data-k="posv"]').textContent = Math.round(frac * 100) + '%';
  }
  function setCorteL(on) {
    corteL.on = !!on;
    var bc = bar.querySelector('[data-b="corte"]');
    if (on) {
      if (planta.on) setPlanta(false); // disputam o clippingPlanes
      if (S._cxDesligar) S._cxDesligar();
      setMode(false); // órbita LIVRE (trena pode ficar)
      var box = new THREE.Box3().setFromObject(modelRoot);
      if (box.isEmpty()) { corteL.on = false; S._hint('Carregue um modelo primeiro.'); return; }
      corteLPanel.style.display = 'flex';
      if (bc) { bc.style.background = corAtiva(); bc.style.color = '#fff'; }
      aplicarCorteL();
      S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('corte', 15) : '') + ' Corte livre: escolha a direção e arraste a posição — o modelo abre ao vivo. Esc sai.');
    } else {
      renderer.clippingPlanes = []; renderer.localClippingEnabled = false;
      corteLPanel.style.display = 'none';
      if (bc) { bc.style.background = ''; bc.style.color = ''; }
      S._hint(medir.on ? '' + (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '') + ' Trena: clique em 2 pontos do modelo pra medir. Esc sai.' : '');
    }
  }
  S._setCorteL = setCorteL; S._aplicarCorteL = aplicarCorteL;
  corteLPanel.addEventListener('input', function (e) {
    var k = e.target.getAttribute && e.target.getAttribute('data-k');
    if (k === 'az') corteL.az = +e.target.value;
    else if (k === 'inc') corteL.inc = +e.target.value;
    else if (k !== 'pos') return;
    aplicarCorteL();
  });
  corteLPanel.addEventListener('click', function (e) {
    var b = e.target.closest('[data-k]'); if (!b) return; var k = b.getAttribute('data-k');
    function preset(az, inc) { corteL.az = az; corteL.inc = inc; corteLPanel.querySelector('[data-k="az"]').value = az; corteLPanel.querySelector('[data-k="inc"]').value = inc; aplicarCorteL(); }
    if (k === 'ph') preset(0, 90);
    else if (k === 'pns') preset(0, 0);
    else if (k === 'plo') preset(90, 0);
    else if (k === 'inv') { corteL.inv = !corteL.inv; b.style.background = corteL.inv ? corAtiva() : ''; b.style.color = corteL.inv ? '#fff' : ''; aplicarCorteL(); }
  });

  /* =====================================================================
   * MODO MESA (01/10/2026): CORTE COM O DEDO e GIRAR A VISTA.
   *
   * O corte da mesa é o MESMO plano do corte livre, só que horizontal e numa
   * altura em metros — é o que se faz numa reunião: mostrar pavimento por
   * pavimento. A altura por pavimento é o piso dele (y0, o AABB das peças, no
   * mundo) + 1,20 m, a convenção da planta. Nada de régua nova: o desenho, o
   * clip e a trena continuam os do corte livre.
   * ===================================================================== */
  function corteEstado() {
    var box = new THREE.Box3().setFromObject(modelRoot);
    if (box.isEmpty()) return { on: false };
    var frac = (+corteLPanel.querySelector('[data-k="pos"]').value) / 1000;
    return { on: corteL.on, horizontal: corteL.inc === 90 && !corteL.inv, yMin: box.min.y, yMax: box.max.y, y: box.min.y + (box.max.y - box.min.y) * frac, frac: frac };
  }
  function corteHorizontal(h) {
    if (h == null) { if (corteL.on) setCorteL(false); return corteEstado(); }
    var box = new THREE.Box3().setFromObject(modelRoot);
    if (box.isEmpty()) return { on: false };
    corteL.az = 0; corteL.inc = 90; corteL.inv = false;
    corteLPanel.querySelector('[data-k="az"]').value = 0; corteLPanel.querySelector('[data-k="inc"]').value = 90;
    var bi = corteLPanel.querySelector('[data-k="inv"]'); if (bi) { bi.style.background = ''; bi.style.color = ''; }
    var frac = Math.max(0, Math.min(1, (h - box.min.y) / Math.max(1e-6, box.max.y - box.min.y)));
    corteLPanel.querySelector('[data-k="pos"]').value = Math.round(frac * 1000);
    if (!corteL.on) {
      setCorteL(true);
      /* o recado do corte livre fala do painel de computador ("escolha a direção…"),
         que na mesa nem aparece — aqui o comando é o trilho */
      if (corteL.on) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('corte', 15) : '') + ' Corte horizontal: arraste o trilho ao lado da barra, ou use ▲/▼ pavimento.');
    } else aplicarCorteL();
    return corteEstado();
  }
  function pavimentosCorte() {
    return pavLista().filter(function (pv) { return pv.y0 != null; }).map(function (pv) { return { nome: pv.nome, y: pv.y0 + 1.2 }; });
  }
  S._corteHorizontal = corteHorizontal; S._corteEstado = corteEstado; S._pavimentosCorte = pavimentosCorte;

  /* ⚠ GIRAR A VISTA EM VOLTA DO MODELO — para quem está do outro lado da
     mesa. É ação DELIBERADA (botão), então vale com a câmera travada. Não usa
     o voo da câmera (`voarCam`): ele vai em LINHA RETA, e num giro de 180° a
     câmera passaria por dentro do modelo. Aqui ela roda em volta do alvo,
     mantendo a distância e a altura. */
  var _giro = null, _giroEixo = new THREE.Vector3(0, 1, 0);
  function girarVista(graus) {
    if (fly.on || !graus) return false;
    if (S._cancelTween) S._cancelTween();
    if (S._pararInercia) S._pararInercia();   /* o embalo de um arrasto antigo entortaria o giro */
    _giro = { total: graus * Math.PI / 180, feito: 0, dur: Math.max(0.35, Math.abs(graus) / 180 * 0.7), e: 0 };
    return true;
  }
  S._tickExtra.push(function (dt) {
    if (!_giro) return;
    _giro.e += dt;
    var k = Math.min(1, _giro.e / _giro.dur), s = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
    var alvo = _giro.total * s, d = alvo - _giro.feito; _giro.feito = alvo;
    var off = camera.position.clone().sub(orbit.target).applyAxisAngle(_giroEixo, d);
    camera.position.copy(orbit.target).add(off); camera.lookAt(orbit.target);
    if (k >= 1) _giro = null;
  });
  S._girarVista = girarVista;

  // ============================================================
  // 🧲 SNAP — a trena (e a linha do corte técnico) "agarram" em pontos notáveis:
  // vértice (fim de linha) > meio de aresta > aresta mais próxima > superfície livre.
  // Configurável por tipo, persistido; indicador visual mostra ONDE e O QUE agarrou.
  // ============================================================
  var snap = { on: true, v: true, m: true, a: true, i: true, c: true, raio: 14 };
  try { var _sv = JSON.parse(localStorage.getItem('orcapro:bim:snap') || 'null'); if (_sv) { snap.on = !!_sv.on; snap.v = !!_sv.v; snap.m = !!_sv.m; snap.a = !!_sv.a; snap.i = _sv.i !== false; snap.c = _sv.c !== false; }  /* ⚠ `!== false`: quem já usava o sistema tem preferência gravada SEM a chave nova — com `!!` o centro nasceria desligado justamente para quem pediu o recurso */ } catch (_) {}
  function salvarSnap() { try { localStorage.setItem('orcapro:bim:snap', JSON.stringify({ on: snap.on, v: snap.v, m: snap.m, a: snap.a, i: snap.i, c: snap.c })); } catch (_) {} }
  S.snap = snap;
  var snapPanel = document.createElement('div');
  snapPanel.style.cssText = 'position:absolute;right:10px;top:52px;z-index:4;display:none;flex-direction:column;gap:7px;background:rgba(255,255,255,.98);border:1px solid #d3dce6;border-radius:11px;padding:11px 13px;color:#1a2b3c;font-size:12px;width:210px';
  snapPanel.innerHTML =
    '<div style="display:flex;justify-content:space-between;align-items:center"><b>' + (typeof Icones !== 'undefined' ? Icones.get('ima', 15) : '') + ' Snap da trena</b><button class="btn sm" data-s="on" style="padding:2px 9px">ON</button></div>' +
    '<div style="display:flex;gap:5px;flex-wrap:wrap">' +
    '<button class="btn sm" data-s="v" style="flex:1" title="Agarra no fim de linha (canto/vértice)">▪ Vértice</button>' +
    '<button class="btn sm" data-s="m" style="flex:1" title="Agarra no meio da aresta">● Meio</button>' +
    '<button class="btn sm" data-s="a" style="flex:1" title="Agarra no ponto mais próximo da aresta">◆ Aresta</button>' +
    '<button class="btn sm" data-s="i" style="flex:1" title="Agarra no CRUZAMENTO real de duas arestas (canto parede×viga)">✚ Interseção</button>' +
    '<button class="btn sm" data-s="c" style="flex:1" title="Agarra no EIXO de uma boca redonda: ponta de tubo, furo, pilar circular">⊕ Centro</button></div>' +
    '<div style="font-size:11px;color:#5b6b7c">Aproxime o clique de um canto/aresta: a cota agarra no ponto exato (o marcador mostra o tipo). Sem alvo por perto, mede na superfície livre.</div>';
  host.appendChild(snapPanel);
  S.snapPanel = snapPanel;

  // v1.1.96 — LEGENDA/PERSONALIZAÇÃO das cores por sistema hidrossanitário
  /* =================================================================
   * REQUISITAR PELO MODELO — do IFC para o pedido de material
   *
   * O modelo já diz, peça a peça, o que o projetista especificou:
   * "ESG_Serie Normal_Luva Simples", "UT_Bacia com caixa acoplada". Quem está
   * na obra precisa disso virando pedido de compra, e não de uma busca item a
   * item no banco de insumos.
   *
   * ⚠ O CASAMENTO NÃO ACONTECE AQUI. Ele mora em js/bimpeca.js, que é puro e
   * entra no gate — um casador que decide o que o cliente COMPRA não pode ser
   * código sem teste, e js/bim.js é módulo ES que o Node não consegue exigir.
   * Este bloco só junta as pontas: lê os elementos, pede a bitola à geometria,
   * mostra o resultado e deixa a PESSOA decidir. Nada é escolhido sozinho.
   * ================================================================= */
  var reqPanel = document.createElement('div');
  /* ⚠ 620px NÃO CABIA A LINHA. Com descrição, família, o aviso de fusão, o
     seletor de candidato e quatro botões, a tabela estourava a largura e o
     painel ganhava BARRA DE ROLAGEM HORIZONTAL — a coluna dos botões saía
     cortada no print de 09/09/2026, e "buscar"/"+ insumo"/"remover" ficavam
     fora da tela. Rolagem horizontal dentro de uma janela é o sintoma de que a
     janela está pequena, não de que o conteúdo é grande demais: numa tela de
     trabalho há espaço de sobra ao lado do modelo. */
  /* ⚠ A LARGURA É DO HOST, NÃO DA JANELA DO NAVEGADOR. `min(1180px,96vw)`
     parece razoável e está errado aqui: o viewer vive dentro da casca do BIM,
     com barra lateral e faixa do Revit à volta, então 96vw é MUITO mais largo
     que o espaço real — e o painel continuava saindo cortado à direita, com o
     "+ insumo" pela metade. Medido em foto: host ≈ 1050 px numa tela de
     1600 px. Ancorar `left` e `right` faz a janela caber no que existe,
     qualquer que seja o tamanho da tela, e o `max-width` só impede que ela
     fique larga demais para ler numa tela grande. */
  reqPanel.style.cssText = 'position:absolute;left:10px;right:10px;top:56px;z-index:5;display:none;flex-direction:column;gap:8px;background:rgba(255,255,255,.985);border:1px solid #d3dce6;border-radius:11px;padding:12px 14px;color:#1a2b3c;font-size:12px;max-width:1180px;max-height:86%;overflow:auto;box-shadow:0 14px 38px rgba(12,31,51,.28)';
  host.appendChild(reqPanel);
  S.reqPanel = reqPanel;
  var reqEstado = null;
  /* qual linha está com a busca manual aberta, e o que foi digitado. Uma por
     vez: duas abertas encheriam o painel e nenhuma das duas seria lida. */
  var reqBusca = null;

  /* ⚠ BUSCA NA BASE INTEIRA, e só INSUMO. Sub-composição vendida como insumo
     poria "CONCRETO FCK 25MPA, M3, R$ 587" num pedido de compra de material —
     é a mesma regra que o casador automático já segue.
     Casa por TODAS as palavras digitadas (e pelo código), porque quem busca à
     mão está estreitando de propósito: "te sanitario 50" tem de trazer o tê de
     50, não tudo que tem "50". */
  function reqBuscaResultados(idx, termo) {
    var t = String(termo || '').trim().toLowerCase();
    if (t.length < 2) return '<div style="color:#6b7a8a;font-size:10.5px;padding:3px 0">digite ao menos 2 letras — ou o código do insumo</div>';
    var todos = [];
    try { if (typeof Insumos !== 'undefined') todos = Insumos._idx || []; } catch (e) { todos = []; }
    if (!todos.length) return '<div style="color:#b45309;font-size:10.5px;padding:3px 0">o banco de insumos não está carregado nesta tela</div>';
    var palavras = t.split(/\s+/).filter(Boolean);
    var achados = [];
    for (var i = 0; i < todos.length && achados.length < 40; i++) {
      var it = todos[i];
      if (String(it.tipo || '').toLowerCase() === 'composicao') continue;
      var alvo = (String(it.codigo || '') + ' ' + String(it.descricao || '')).toLowerCase();
      var tem = true;
      for (var w = 0; w < palavras.length; w++) if (alvo.indexOf(palavras[w]) < 0) { tem = false; break; }
      if (tem) achados.push(it);
    }
    if (!achados.length) return '<div style="color:#b45309;font-size:10.5px;padding:3px 0">nenhum insumo com todas essas palavras</div>';
    return achados.slice(0, 25).map(function (it) {
      return '<button class="btn sm" data-rq-pick="' + idx + '" data-rq-cod="' + esc(String(it.codigo)) + '" ' +
        'style="display:block;width:100%;text-align:left;font-size:10.5px;margin:2px 0;white-space:normal">' +
        esc(String(it.descricao).slice(0, 90)) + ' · <b>' + esc(String(it.unidade || '')) + '</b> · R$ ' +
        (Number(it.custoUnitario) || 0).toFixed(2) + '</button>';
    }).join('') + (achados.length > 25 ? '<div style="color:#6b7a8a;font-size:10px">mostrando 25 — refine a busca</div>' : '');
  }

  function reqLevantar() {
    if (typeof BimPeca === 'undefined') { UI0('Motor de peças não carregado.', 'erro'); return null; }
    /* ⚠ FASE. O carimbo do plugin diz o que e OBRA NOVA, o que vai ser
     * DEMOLIDO e o que ja EXISTE. Requisicao e pedido de material a COMPRAR:
     * pedir tubo para o que vai ser derrubado, ou para o que ja esta na
     * parede, e material comprado a toa. Sem fase carimbada, o elemento
     * conta como novo — que e o comportamento de antes e o unico honesto
     * quando o modelo nao diz. */
    var els = (S.elementos || []).filter(function (e) {
      var f = String((e && e.fase) || '').toLowerCase();
      return !(f === 'demolir' || f === 'demolicao' || f === 'existente');
    });
    if (!els.length) { UI0('Carregue um modelo primeiro.', 'info'); return null; }

    /* ⚠ A BITOLA VEM DA GEOMETRIA, e é ela que decide a compra.
       Medido no projeto hidrossanitário real: sem ela, 106 de 119 famílias
       ficam ambíguas — o Revit escreve "Luva Simples série normal" sem dizer
       o DN, e a base tem a mesma luva em 40/50/75/100/150 mm, com 10x de
       diferença de preço. Ler custa uma passada; não ler custa a peça errada
       chegando no canteiro. */
    var entrada = els.map(function (e) {
      var q = e.qto || {}, quant = 0, un = '', fq = '';
      if (q.comprimento > 0) { quant = q.comprimento; un = 'm'; fq = q.compFonte || 'ifc'; }
      else if (q.area > 0) { quant = q.area; un = 'm2'; fq = 'ifc'; }
      else if (q.volume > 0) { quant = q.volume; un = 'm3'; fq = 'ifc'; }
      var bit = 0;
      try {
        if (e.mid != null && typeof BimTubo !== 'undefined' && BimTubo.ehTubo && BimTubo.ehTubo(e)) {
          bit = lerBitolaMm(e.mid, e.id, fatorLen(e.mid)) || 0;
        }
      } catch (eB) {}
      return { tipo: e.tipo, familia: e.familia, sistemaIfc: e.sistemaIfc, nome: e.nome,
               /* o nome de mercado que veio do Revit: e ele que casa com a base
                  de insumos, que fala "TUBO PVC SOLDAVEL DN 25 MM" e nao
                  "AF_Soldavel_Tubo" */
               descricao: e.descricao || '', descricaoFonte: e.descricaoFonte || '',
               bitolaMm: bit, quantidade: quant, unidade: un, fonteQtd: fq, uid: e.uid, n: 1 };
    });

    /* ⚠ E A BITOLA DA CONEXÃO SAI DA REDE, não da geometria dela.
     * Joelho, luva e tê são exportados como malha facetada, sem perfil
     * circular: no modelo hidrossanitário real são 4.201 peças sem bitola
     * contra 1.725 tubos com. Mas TUBO NUNCA É VIZINHO DE TUBO — conferido no
     * arquivo, 0 pares tubo-tubo em 1.722 tubos com vizinho —, então toda
     * conexão encosta em tubo de bitola conhecida.
     * Medido: a propagação leva a cobertura de 1.725 para 3.003 peças.
     *
     * ⚠ E ela se recusa a resolver a REDUÇÃO. Bucha, tê de redução e redução
     * excêntrica ligam bitolas diferentes por definição; dar DN único a elas é
     * comprar a peça errada. A primeira versão fez isso com 111 peças, porque
     * decidia com um lado ainda desconhecido. Agora o nome vale como prova e
     * elas guardam o PAR. */
    var topos = {};
    (S.modelos || []).forEach(function (mo) {
      try { topos[mo.mid] = lerTopologiaRede(mo.mid); } catch (eT) {}
    });
    var topoUnida = { portaDe: {}, portasDe: {}, ligacao: {} };
    Object.keys(topos).forEach(function (mid) {
      var t = topos[mid] || {};
      /* ⚠ as portas são numeradas POR MODELO e colidem entre IFCs federados —
         o mesmo motivo pelo qual o `uid` do elemento carrega o mid. */
      Object.keys(t.portaDe || {}).forEach(function (p) { topoUnida.portaDe[mid + ':' + p] = t.portaDe[p]; });
      Object.keys(t.portasDe || {}).forEach(function (u) {
        topoUnida.portasDe[u] = (t.portasDe[u] || []).map(function (p) { return mid + ':' + p; });
      });
      Object.keys(t.ligacao || {}).forEach(function (p) { topoUnida.ligacao[mid + ':' + p] = mid + ':' + t.ligacao[p]; });
    });
    try {
      var mapaBit = BimPeca.bitolasPorTopologia(entrada, topoUnida);
      BimPeca.aplicarTopologia(entrada, mapaBit);
    } catch (eP) { /* topologia é bônus: sem ela o levantamento segue pela geometria */ }

    return BimPeca.levantar(entrada);
  }

  /* Candidatos vindos do banco de insumos do app.
     ⚠ SÓ INSUMO. Sub-composição vendida como insumo poria "CONCRETO FCK
     25MPA, M3, R$587" num pedido de COMPRA de material. */
  var reqPeso = null;

  /* ⚠ A BASE CARREGA SOB DEMANDA, e o painel tem de puxá-la — não mandar a
   * pessoa abrir outra tela primeiro. `Insumos._idx` nasce VAZIO e só enche
   * quando alguém chama `Insumos.carregar`; a tela do Banco de Insumos faz
   * isso, o painel do BIM não fazia. O sintoma era o pior possível: o painel
   * abria, dizia "0 casadas · 182 sem candidato" e a requisição saía com
   * R$ 0,00 — parecendo que a base não tem os itens, quando ela nem tinha
   * sido lida. */
  function reqCarregarBase() {
    try {
      if (typeof Insumos === 'undefined') return Promise.resolve(0);
      if (Insumos.carregado && (Insumos._idx || []).length) return Promise.resolve(Insumos._idx.length);
      if (typeof Gestao === 'undefined' || !Gestao._analiticoAtivo) return Promise.resolve(0);
      var a = Gestao._analiticoAtivo();
      if (!a || !a.url) return Promise.resolve(0);
      return Insumos.carregar(a.url, a.uf, a.live).then(function () { return (Insumos._idx || []).length; });
    } catch (e) { return Promise.resolve(0); }
  }

  function reqCandidatos(peca) {
    /* ⚠ O CATALOGO E `Insumos._idx`, NAO `Insumos.todos()`.
     * A primeira versao chamava `Insumos.todos()`, que NAO EXISTE em lugar
     * nenhum do repo — o guard `if (Insumos.todos)` engolia o erro e a lista
     * vinha vazia. Efeito: o painel montava, dizia "182 pecas · 0 casadas ·
     * 182 sem candidato", e a requisicao saia com 182 linhas pendentes e
     * R$ 0,00. O recurso inteiro era inerte no navegador, e a medicao que eu
     * tinha (23 familias casadas) era de codigo rodando em Node contra o
     * arquivo da base — nunca pelo caminho do app.
     * Guard que esconde funcao inexistente e pior que erro: nao ha vermelho
     * em lugar nenhum, so um resultado vazio que parece "a base nao tem". */
    var todos = [];
    try {
      if (typeof Insumos !== 'undefined') {
        if (!Insumos.carregado && Insumos.carregar) { /* a base carrega sozinha na tela do banco; aqui so avisamos */ }
        todos = Insumos._idx || [];
      }
    } catch (e) { todos = []; }
    var termos = peca.termos;
    if (!todos.length || !termos.length) return [];
    var pont = [];
    for (var i = 0; i < todos.length; i++) {
      var it = todos[i];
      if (String(it.tipo || '').toLowerCase() === 'composicao') continue;
      var d = String(it.descricao || '').toLowerCase();
      var c = 0;
      for (var t = 0; t < termos.length; t++) if (d.indexOf(termos[t]) >= 0) c++;
      if (c) pont.push({ c: c, item: it });
    }
    pont.sort(function (a, b) { return b.c - a.c; });
    return pont.slice(0, 300).map(function (x) { return { item: x.item, fonte: x.item.fonte || '' }; });
  }

  /* ⚠ UM FILTRO SO, DUAS LEITURAS. O que a tela mostra e o que o botao
     Gerar leva TEM de sair da mesma conta — filtro que filtra so a tela e
     armadilha, e este painel ja teve esse defeito: a pessoa clicava em
     "esgoto", via 40 linhas e recebia uma requisicao com 182.
     A UNICA diferenca e a linha removida — ela continua visivel, riscada,
     para a pessoa notar o clique errado, e nao entra na requisicao. */
  function reqFiltrada(paraGerar) {
    if (!reqEstado) return [];
    return (reqEstado.pecas || []).filter(function (x) {
      if (paraGerar && x.removido) return false;
      if (reqEstado.filtro && (x.p.subsistema || x.p.disciplina || 'sem classificação') !== reqEstado.filtro) return false;
      if (reqEstado.grupo && (x.p.grupo || 'outros') !== reqEstado.grupo) return false;
      return true;
    });
  }

  function reqPintar() {
    if (!reqEstado) return;
    var pecas = reqEstado.pecas;
    var cont = { ok: 0, escolher: 0, sem: 0 };
    pecas.forEach(function (x) { cont[x.escolhido ? 'ok' : (x.v.candidatos.length ? 'escolher' : 'sem')]++; });

    var subs = {};
    pecas.forEach(function (x) { var k = x.p.subsistema || x.p.disciplina || 'sem classificação'; subs[k] = (subs[k] || 0) + x.p.n; });
    var chips = Object.keys(subs).sort(function (a, b) { return subs[b] - subs[a]; }).map(function (k) {
      var on = reqEstado.filtro === k;
      return '<button class="btn sm" data-rq-sub="' + esc(k) + '"' + (on ? ' style="background:#2e6f9e;color:#fff"' : '') + '>' + esc(k) + ' <b>' + subs[k] + '</b></button>';
    }).join(' ');

    /* ⚠ FILTRO DE COMPRA — tubo, conexão, louça, registro. O de cima recorta
       por SISTEMA (água fria, esgoto); este recorta por BALCÃO, que é como
       quem compra procura numa lista de 182 linhas. Pedido de 09/09/2026. */
    var grupos = {};
    pecas.forEach(function (x) { var g = x.p.grupo || 'outros'; grupos[g] = (grupos[g] || 0) + x.p.n; });
    var chipsG = Object.keys(grupos).sort(function (a, b) { return grupos[b] - grupos[a]; }).map(function (g) {
      var on = reqEstado.grupo === g;
      return '<button class="btn sm" data-rq-grp="' + esc(g) + '"' + (on ? ' style="background:#2e6f9e;color:#fff"' : '') + '>' +
        esc(BimPeca.rotuloGrupo ? BimPeca.rotuloGrupo(g) : g) + ' <b>' + grupos[g] + '</b></button>';
    }).join(' ');

    var visiveis = reqFiltrada(false);

    var linhas = visiveis.map(function (x) {
      var p = x.p, v = x.v;
      var medida = BimPeca.resumoDim(p.dims, p.bitolaPar);
      var opcoes = v.candidatos.slice(0, 6).map(function (c, j) {
        var sel = x.escolhido && x.escolhido.codigo === c.item.codigo;
        /* dentro de <option> não cabe SVG — o navegador desenha texto puro.
           Então o aviso vai em PALAVRA, e não em glifo: é a mesma razão das
           duas exceções que o tools/test-sem-emoji.js documenta para
           placeholder e title, sem precisar abrir uma terceira. */
        return '<option value="' + j + '"' + (sel ? ' selected' : '') + '>' +
          (c.dim === 'confere' ? '[medida confere] ' : c.dim === 'diverge' ? '[OUTRA MEDIDA] ' : '') +
          esc(String(c.item.descricao).slice(0, 70)) + '  ·  R$ ' + (Number(c.item.custoUnitario) || 0).toFixed(2) +
          '</option>';
      }).join('');
      /* ⚠ SELECT QUE NÃO SABE REPRESENTAR O VALOR APAGA O VALOR. O item
         escolhido À MÃO na busca quase nunca está entre os 6 candidatos — é
         justamente por isso que a pessoa foi buscar. Sem uma opção para ele, o
         `select` nascia em "— deixar pendente —" e a escolha ficava invisível;
         pior, o primeiro toque no select gravaria por cima dela. A e2e pegou
         isto no navegador ("clicar no resultado escolhe o item" reprovou),
         depois de o motor e os asserts de fonte darem verde — é o mesmo
         defeito que esta base já registrou em outro formulário. */
      if (x.escolhido) {
        var jaTem = false;
        v.candidatos.slice(0, 6).forEach(function (c) {
          if (String(c.item.codigo) === String(x.escolhido.codigo)) jaTem = true;
        });
        if (!jaTem) {
          opcoes = '<option value="M" selected>[escolhido por você] ' +
            esc(String(x.escolhido.descricao).slice(0, 70)) + '  ·  R$ ' +
            (Number(x.escolhido.custoUnitario) || 0).toFixed(2) + '</option>' + opcoes;
        }
      }
      /* linha removida continua VISIVEL, riscada e apagada: sumir de vez
         tiraria da pessoa a chance de perceber que removeu a errada */
      return '<tr' + (x.removido ? ' style="opacity:.45;text-decoration:line-through"' : '') + '>' +
        '<td style="padding:5px 4px;vertical-align:top;border-top:1px solid #d3dce6">' +
          /* ⚠ O NOME DE MERCADO NA FRENTE, A FAMÍLIA LOGO ABAIXO — nunca só um
             dos dois. É a descrição que casa com a base e que o fornecedor
             entende; é a família que o engenheiro reconhece para achar a peça
             de volta no Revit. Trocar uma pela outra deixaria metade das duas
             pessoas sem a referência que ela usa. */
          (p.descricao
            ? '<div><b>' + esc(String(p.descricao).slice(0, 54)) + '</b>' +
                '<span title="O nome de mercado veio do campo Descrição do modelo — é ele que foi usado para casar com a base" style="margin-left:5px;font-size:9.5px;font-weight:700;color:#15803d;border:1px solid #86efac;border-radius:99px;padding:0 5px">Descrição</span></div>' +
              '<div style="color:#6b7a8a;font-size:10.5px">' + esc(String(p.familia || p.rotulo || '(sem família)').slice(0, 54)) + '</div>' +
              (p.descricaoVariantes > 1
                ? '<div style="color:#b45309;font-size:10.5px">' + p.descricaoVariantes + ' descrições diferentes nestas peças — comprando pela primeira</div>'
                : '')
            : '<div><b>' + esc(String(p.familia || p.rotulo || '(sem nome no modelo)').slice(0, 54)) + '</b></div>') +
          '<div style="color:#5b6b7c;font-size:11px">' + p.n + ' pç · ' +
            (p.fonteQtd === 'contagem' ? 'por contagem'
              : p.fonteQtd === 'parcial'
                ? ('<span style="color:#b45309">' + p.quantidade.toFixed(2) + ' ' + p.unidade + ' — INCOMPLETO, ' + p.faltamMedida + ' peça(s) sem medida no IFC</span>')
                : (p.quantidade.toFixed(2) + ' ' + p.unidade + ' medidos no IFC')) +
            (medida !== 'sem medida' ? ' · ' + esc(medida) : '') + '</div>' +
          /* ⚠ A BARRA É O NÚMERO QUE SE PEDE NA LOJA, e ela vem DEPOIS do
             metro, nunca no lugar dele: quem confere o projeto precisa do
             metro do modelo, quem compra precisa da barra. Trocar um pelo
             outro deixaria metade das duas pessoas sem a referência que usa —
             a mesma razão de a linha mostrar descrição E família. */
          (p.barras
            ? '<div style="color:#15803d;font-size:11px;font-weight:700">' + p.barras +
                ' barra(s) de ' + p.barraM + ' m para comprar</div>'
            : '') +
          /* ⚠ O QUE FOI FUNDIDO APARECE. Juntar por descrição some com a
             família, e é pela família que o engenheiro acha a peça de volta
             no Revit. Linha que ninguém rastreia é pior que linha repetida. */
          (p.familiasReunidas > 1
            ? '<div style="color:#5b6b7c;font-size:10.5px" title="' +
                esc((p.familiasOutras || []).join(' · ')) + '">' +
                p.familiasReunidas + ' famílias do modelo reunidas nesta descrição</div>'
            : '') +
        '</td>' +
        '<td style="padding:5px 4px;vertical-align:top;min-width:260px;border-top:1px solid #d3dce6">' +
          (opcoes
            ? '<select data-rq-sel="' + x.idx + '" style="width:100%;font-size:11px"><option value="">— deixar pendente —</option>' + opcoes + '</select>'
            : '<span style="color:#b45309">sem candidato na base</span>') +
          '<div style="color:#5b6b7c;font-size:11px;margin-top:3px">' + esc(v.porque) + '</div>' +
          /* ⚠ A PORTA DE SAÍDA DA LISTA CURTA. Os candidatos são os 6 melhores
             de um casamento automático, e quando ele erra a pessoa ficava sem
             caminho: ou aceitava um dos seis, ou criava insumo próprio
             duplicando um item que JÁ EXISTE na base. Medido no projeto real:
             para o tê 50×50 os seis eram CAP, LUVA, TERMINAL, TUBO, JOELHO e
             ANEL, e o `TE SANITARIO DN 50 X 50` estava na base o tempo todo.
             Quem conhece a obra acha em segundos o que o casador não achou —
             então a busca na base inteira fica aqui, na mesma linha. */
          (reqBusca && reqBusca.idx === x.idx
            ? '<div style="margin-top:5px;border-top:1px dashed #c9d5e1;padding-top:5px">' +
                '<input data-rq-busca="' + x.idx + '" value="' + esc(reqBusca.termo || '') + '" ' +
                  'placeholder="buscar na base: codigo ou palavras da descricao" ' +
                  'style="width:100%;padding:4px 7px;border-radius:6px;border:1px solid #9db4c8;background:#ffffff;color:#1a2b3c;font-size:11px">' +
                '<div id="rq-res-' + x.idx + '" style="max-height:150px;overflow:auto;margin-top:4px">' +
                  reqBuscaResultados(x.idx, reqBusca.termo) + '</div></div>'
            : '') +
        '</td>' +
        '<td style="padding:5px 4px;vertical-align:top;text-align:right;border-top:1px solid #d3dce6;white-space:nowrap">' +
          (x.escolhido ? '<div style="color:#15803d;margin-bottom:3px">✓</div>' : '') +
          /* ⚠ A DÚVIDA SE TIRA NA OBRA. Quando dois insumos parecem iguais no
             papel, quem sabe qual é a peça é o modelo — e ele está do lado.
             Este botão leva a câmera até as peças desta linha e as contorna. */
          '<button class="btn sm" data-rq-3d="' + x.idx + '" title="Levar a câmera até estas ' + p.n + ' peça(s) no modelo e contorná-las">' +
            (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' 3D</button> ' +
          '<button class="btn sm" data-rq-buscar="' + x.idx + '" title="Procurar o item na base inteira, e nao so entre os candidatos que o casador achou">' +
            (reqBusca && reqBusca.idx === x.idx ? 'fechar busca' : 'buscar') + '</button>' +
          (x.escolhido
            ? ''
            : ' <button class="btn sm" data-rq-novo="' + x.idx + '" title="Criar como insumo próprio, com a descrição e a unidade que vieram do modelo">+ insumo</button>') +
          /* ⚠ REMOVER É REVERSÍVEL DE PROPÓSITO. A linha some da requisição,
             mas continua na tela riscada, com "voltar" ao lado: apagar sem
             volta numa lista de 182 peças é a pessoa perder o levantamento
             inteiro por um clique errado e ter de refazer o levantamento. */
          ' <button class="btn sm" data-rq-remover="' + x.idx + '" title="' +
            (x.removido ? 'Trazer esta peça de volta para a requisição' : 'Tirar esta peça da requisição — dá para voltar atrás') + '">' +
            (x.removido ? 'voltar' : 'remover') + '</button>' +
        '</td></tr>';
    }).join('');

    reqPanel.innerHTML =
      '<div style="display:flex;align-items:center;gap:8px">' +
        '<b style="flex:1">Requisitar pelo modelo</b>' +
        '<button class="btn sm" data-rq="fechar" title="Fechar">' + ico('fechar') + '</button></div>' +
      '<div style="color:#5b6b7c">' + pecas.length + ' peças distintas · ' +
        '<span style="color:#15803d">' + cont.ok + ' casadas</span> · ' + cont.escolher + ' a escolher · ' +
        '<span style="color:#b45309">' + cont.sem + ' sem candidato</span>' +
        /* ⚠ O QUE FOI REMOVIDO TEM DE APARECER NO CABEÇALHO. Com 182 linhas a
           pessoa rola a lista e não vê o que riscou lá em cima; sem este
           número ela clica em Gerar achando que está pedindo tudo. */
        (function () {
          var nR = 0;
          pecas.forEach(function (y) { if (y.removido) nR++; });
          return nR ? ' · <span style="color:#b91c1c">' + nR + ' removida(s), fora da requisição</span>' : '';
        })() + '</div>' +
      /* ⚠ ESTA LINHA É O QUE IMPEDE O RECURSO DE FALHAR EM SILÊNCIO. Ler a
         Descrição do Revit só ajuda se o modelo a tiver preenchida, e isso
         muda por escritório e por biblioteca de família. Sem o contador, um
         modelo sem descrição nenhuma se comporta exatamente como antes e a
         pessoa fica sem saber se o recurso não funciona ou se o modelo não
         traz o campo. Com ele, a tela responde a pergunta. */
      (function () {
        var r = reqEstado.resumo || {};
        var cd = r.comDescricao || 0, tot = pecas.length;
        if (cd) {
          return '<div style="color:#15803d;font-size:11px">' + cd + ' de ' + tot +
            ' peças trouxeram a <b>Descrição</b> do modelo — é por ela que o casamento com a base foi feito' +
            (r.descricaoDivergente ? ', e em ' + r.descricaoDivergente + ' há descrições diferentes na mesma peça' : '') + '</div>';
        }
        return '<div style="color:#b45309;font-size:11px">Nenhuma peça trouxe o campo <b>Descrição</b> — o casamento foi feito só pelo nome da família. ' +
          'Preencher a Descrição do tipo no Revit (o nome comercial) melhora o encontro com a base.</div>';
      })() +
      '<div style="display:flex;gap:4px;flex-wrap:wrap">' +
        '<button class="btn sm" data-rq-sub=""' + (reqEstado.filtro ? '' : ' style="background:#2e6f9e;color:#fff"') + '>tudo</button>' + chips + '</div>' +
      /* ⚠ DUAS RÉGUAS DIFERENTES, e por isso duas linhas de chips: a de cima
         recorta por SISTEMA (água fria, esgoto), esta recorta por BALCÃO
         (tubo, conexão, louça, registro). Misturar as duas numa fila só faria
         a pessoa achar que "esgoto" e "conexões" são o mesmo tipo de escolha —
         e elas se COMBINAM: dá para ver só as conexões de esgoto. */
      '<div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center">' +
        '<span style="color:#6b7a8a;font-size:11px">comprar:</span>' +
        '<button class="btn sm" data-rq-grp=""' + (reqEstado.grupo ? '' : ' style="background:#2e6f9e;color:#fff"') + '>tudo</button>' + chipsG + '</div>' +
      '<table style="width:100%;border-collapse:collapse;font-size:11.5px"><tbody>' + linhas + '</tbody></table>' +
      /* ATENÇÃO: o aviso do total parcial nasce aqui e segue para a requisição: ela
         dispara aprovação POR VALOR, e item sem preço puxa o total para baixo
         — o pedido pode passar por baixo do limite de quem precisava aprovar */
      ((cont.sem + cont.escolher)
        ? '<div style="color:#b45309">O que ficar sem item entra como <b>linha pendente, sem preço</b> — o total sai parcial e precisa ser completado antes de mandar aprovar.</div>'
        : '') +
      '<div style="display:flex;gap:6px">' +
        '<button class="btn sm primary" data-rq="gerar">Gerar requisição' +
          (reqEstado.filtro ? ' (' + visiveis.length + ' de ' + pecas.length + ')' : '') + '</button>' +
        '<button class="btn sm" data-rq="fechar">Cancelar</button></div>';
  }

  function reqAbrir() {
    var lev = reqLevantar();
    if (!lev) return;
    /* espera a base antes de casar: sem ela todo mundo sai pendente */
    if (typeof Insumos !== 'undefined' && !(Insumos._idx || []).length) {
      UI0('Carregando o banco de insumos...', 'info');
      reqCarregarBase().then(function (n) {
        if (!n) { UI0('Nao consegui carregar o banco de insumos. Abra o app pelo Iniciar-OrcaPRO e tente de novo.', 'erro'); return; }
        reqAbrir();
      });
      return;
    }
    /* ⚠ O PESO DOS TERMOS SAI DA BASE, e e calculado UMA vez.
       "pvc" esta em 19,3% dos insumos e "joelho" em 1,9%: contando os dois
       igual, um CAP e um TUBO empatam com um JOELHO por compartilharem
       "serie" e "normal", e a peca certa some no meio de dez erradas. */
    try {
      if (!reqPeso && typeof Insumos !== 'undefined' && Insumos._idx) {
        reqPeso = BimPeca.pesosDe((Insumos._idx || []).filter(function (it) {
          return String(it.tipo || '').toLowerCase() !== 'composicao';
        }).map(function (it) { return { item: it }; }));
      }
    } catch (ePz) { reqPeso = null; }
    var pecas = lev.pecas.map(function (p, i) {
      var v = BimPeca.casar(p, reqCandidatos(p), { peso: reqPeso });
      /* ⚠ SÓ PRÉ-SELECIONA QUANDO O MOTOR DISSE "ok". Em ambíguo e pendente a
         escolha fica em branco: pré-marcar o primeiro candidato de um empate
         é escolher pelo usuário sem ele saber — e num empate de bitola isso
         é a peça errada com cara de conferida. */
      return { idx: i, p: p, v: v, escolhido: (v.status === 'ok' && v.candidatos[0]) ? v.candidatos[0].item : null };
    });
    reqEstado = { pecas: pecas, filtro: '', resumo: lev.resumo };
    reqBusca = null;   /* levantamento novo, busca antiga nao sobrevive */
    reqEstado.grupo = '';
    fecharPaineis(reqPanel);
    reqPanel.style.display = 'flex';
    reqPintar();
  }

  /* ⚠ DIGITAR NÃO PODE REPINTAR O PAINEL INTEIRO. Repintar recria o <input> e
     o cursor sai dele: a pessoa digita a primeira letra e perde o foco, o que
     na prática torna a busca inusável. Então o `input` atualiza SÓ a caixa de
     resultados daquela linha. */
  reqPanel.addEventListener('input', function (ev) {
    var cx = ev.target && ev.target.getAttribute ? ev.target.getAttribute('data-rq-busca') : null;
    if (cx === null || !reqBusca) return;
    reqBusca.termo = ev.target.value || '';
    var box = document.getElementById('rq-res-' + cx);
    if (box) box.innerHTML = reqBuscaResultados(+cx, reqBusca.termo);
  });

  reqPanel.addEventListener('change', function (ev) {
    var sel = ev.target && ev.target.closest ? ev.target.closest('[data-rq-sel]') : null;
    if (!sel || !reqEstado) return;
    var x = reqEstado.pecas[+sel.getAttribute('data-rq-sel')];
    if (!x) return;
    var j = sel.value;
    /* ⚠ "M" É A OPÇÃO DO ITEM ESCOLHIDO À MÃO, e ela não indexa `candidatos`.
       Sem este ramo, `+'M'` vira NaN, `candidatos[NaN]` é undefined e o
       próprio ato de abrir o select APAGAVA a escolha manual — o valor sumia
       sem a pessoa ter escolhido nada. */
    if (j === 'M') { x.escolhaManual = true; return; }
    x.escolhido = (j === '') ? null : ((x.v.candidatos[+j] || {}).item || null);
    if (x.escolhido) x.escolhaManual = false;
    reqPintar();
  });

  reqPanel.addEventListener('click', function (ev) {
    var b = ev.target && ev.target.closest ? ev.target.closest('button') : null;
    if (!b || !reqEstado) return;
    var sub = b.getAttribute('data-rq-sub');
    if (sub !== null) { reqEstado.filtro = sub; reqPintar(); return; }
    var grp = b.getAttribute('data-rq-grp');
    /* clicar de novo no mesmo chip DESLIGA o filtro: sem isso a pessoa fica
       presa num recorte e o botão Gerar leva só parte da obra sem ela notar */
    if (grp !== null) { reqEstado.grupo = (reqEstado.grupo === grp) ? '' : grp; reqPintar(); return; }
    var ver3d = b.getAttribute('data-rq-3d');
    if (ver3d !== null) {
      var x3 = reqEstado.pecas[+ver3d];
      if (x3) {
        var achou = S._verNo3D ? S._verNo3D(x3.p.uids || []) : 0;
        /* ⚠ RECADO QUE MENTE É PIOR QUE RECADO NENHUM: o levantamento guarda
           no máximo 200 uids por peça, e um modelo restaurado do cache pode
           não trazer a caixa de todas. Quando não dá para mostrar, a tela diz
           — em vez de a câmera não mexer e a pessoa achar que o botão quebrou. */
        if (!achou) UI0('Não consegui localizar estas peças no 3D — o modelo restaurado do cache pode não trazer a caixa delas. Abra o .ifc de novo.', 'info');
        else UI0(achou + ' peça(s) contornadas no modelo' + (achou < x3.p.n ? ' (de ' + x3.p.n + ' — a lista guarda até 200 por linha)' : '') + '.', 'ok');
      }
      return;
    }
    var abrir = b.getAttribute('data-rq-buscar');
    if (abrir !== null) {
      reqBusca = (reqBusca && reqBusca.idx === +abrir) ? null : { idx: +abrir, termo: '' };
      reqPintar();
      /* o foco vai para a caixa: quem clicou em "buscar" quer digitar agora */
      try { var cx = reqPanel.querySelector('[data-rq-busca]'); if (cx) cx.focus(); } catch (eF) {}
      return;
    }
    var pick = b.getAttribute('data-rq-pick');
    if (pick !== null) {
      var xp = reqEstado.pecas[+pick];
      var cod = b.getAttribute('data-rq-cod');
      if (xp && cod) {
        var achado = null;
        try {
          var lista = (typeof Insumos !== 'undefined' && Insumos._idx) || [];
          for (var q = 0; q < lista.length; q++) if (String(lista[q].codigo) === cod) { achado = lista[q]; break; }
        } catch (eP) {}
        /* ⚠ ESCOLHA À MÃO É ESCOLHA, e ela manda. Não se mistura com o
           casamento automático nem se "confirma" por cima dele: quem clicou
           leu a descrição inteira e o preço. Mas ela também não vira veredito
           do motor — o status continua contando a história do casador, e o
           carimbo de quem escolheu vai junto. */
        if (achado) { xp.escolhido = achado; xp.escolhaManual = true; reqBusca = null; reqPintar(); }
      }
      return;
    }
    var rem = b.getAttribute('data-rq-remover');
    if (rem !== null) {
      var xr = reqEstado.pecas[+rem];
      if (xr) { xr.removido = !xr.removido; reqPintar(); }
      return;
    }
    var novo = b.getAttribute('data-rq-novo');
    if (novo !== null) {
      var xn = reqEstado.pecas[+novo];
      if (xn) {
        /* ⚠ o preço NÃO é chutado aqui — quem digita é o usuário, na tela do
           insumo próprio. Herdar o preço de um item apenas parecido poria o
           preço de OUTRA peça dentro do acervo autoral do cliente, com cara
           de dado conferido — e lá ele fica para sempre.
           (sem aspas duplas nesta prosa: o tools/test-sem-emoji.js tira as
           strings ANTES dos comentários, e uma aspa aqui parte o bloco ao
           meio, fazendo o resto passar por código.) */
        try { window.dispatchEvent(new CustomEvent('orcapro:insumo-do-bim', { detail: BimPeca.paraInsumoProprio(xn.p) })); } catch (e2) {}
      }
      return;
    }
    var k = b.getAttribute('data-rq');
    if (k === 'fechar') { reqPanel.style.display = 'none'; reqEstado = null; reqBusca = null;
      /* o contorno do "ver no 3D" e do painel: fechar o painel sem limpar
         deixaria molduras verdes penduradas na cena sem nada que as explique */
      if (S._limparLupa3d) S._limparLupa3d(); return; }
    if (k === 'gerar') {
      /* ⚠ O BOTAO GERA O QUE ESTA A VISTA. Ele mandava o modelo INTEIRO
         mesmo com um chip de subsistema ligado: a pessoa clicava em "esgoto",
         via 40 linhas, clicava em Gerar e recebia uma requisicao com as 182 —
         incluindo agua fria e pluvial que ela nao pediu. Filtro que filtra so
         a tela e armadilha, nao filtro. */
      /* ⚠ MESMA CONTA DA TELA (`reqFiltrada`), com `paraGerar` ligado. Duas
         cópias desta regra é o caminho para elas divergirem na próxima
         mudança — e a linha removida é a única diferença entre as duas
         leituras: ela sai da requisição e continua visível, riscada. */
      var visiveis = reqFiltrada(true);
      if (!visiveis.length) { UI0('Não sobrou nenhuma peça para requisitar — todas foram removidas ou o filtro não deixou nenhuma.', 'info'); return; }
      var escolhas = {};
      visiveis.forEach(function (x) { escolhas[x.p.chave] = x.escolhido; });
      var pac = BimPeca.paraRequisicao(visiveis.map(function (x) { return x.p; }), escolhas);
      try { window.dispatchEvent(new CustomEvent('orcapro:requisicao-do-bim', { detail: pac })); } catch (e3) {}
      reqPanel.style.display = 'none'; reqEstado = null; reqBusca = null;
    }
  });

  S._reqAbrir = reqAbrir;
  /* ⚠ HOOK DE TESTE — desenha o painel a partir de uma lista de peças já
     levantada, sem exigir um IFC com tubulação aberto no navegador.
     POR QUE ELE EXISTE: o agrupamento por descrição e as barras de 6 m são
     provados em Node contra `BimPeca.levantar`, e a planilha é provada numa
     bancada com o `construir` real. Faltava o terceiro consumidor — a GAVETA —
     e nesta base motor verde já conviveu com recurso inerte na tela (52
     asserts e a função que a tela chamava não existia). Sem este hook, medir
     o que a gaveta escreve exigiria um IFC hidrossanitário no repositório.
     Ele NÃO cria caminho novo de produto: monta o mesmo `reqEstado` que
     `reqAbrir` monta e chama o mesmo `reqPintar`. */
  S._reqPintarTeste = function (pecas, resumo) {
    reqEstado = {
      pecas: (pecas || []).map(function (p, i) {
        return { idx: i, p: p, v: { candidatos: [], porque: 'bancada de teste' }, escolhido: null };
      }),
      filtro: '', resumo: resumo || {}
    };
    reqPanel.style.display = 'flex';
    reqPintar();
    return reqPanel.innerHTML;
  };

  var sisPanel = document.createElement('div');
  sisPanel.style.cssText = 'position:absolute;left:10px;bottom:14px;z-index:4;display:none;flex-direction:column;gap:6px;background:rgba(255,255,255,.98);border:1px solid #d3dce6;border-radius:11px;padding:11px 13px;color:#1a2b3c;font-size:12px;width:238px;max-height:72%;overflow:auto';
  host.appendChild(sisPanel);
  S.sisPanel = sisPanel;
  function pintarSisPanel() {
    var cnt = sistemasPresentes();
    var linhas = SIS_ORDEM.filter(function (k) { return cnt[k]; }).map(function (k) {
      return '<label style="display:flex;align-items:center;gap:8px;cursor:pointer">' +
        '<input type="color" data-sk="' + k + '" value="' + sisCores[k] + '" style="width:26px;height:22px;border:0;background:none;padding:0;cursor:pointer">' +
        '<span style="flex:1">' + esc(SIS_PADRAO[k].nome) + '</span>' +
        '<b style="color:#5b6b7c;font-weight:600">' + cnt[k] + '</b></label>';
    }).join('');
    sisPanel.innerHTML =
      '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><b>' + (typeof Icones !== 'undefined' ? Icones.get('paleta', 15) : '') + ' Sistemas hidrossanitários</b>' +
      '<button class="btn sm" data-sx="fechar" style="padding:2px 8px" title="Desligar as cores por sistema">' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + '</button></div>' +
      (linhas || '<div style="color:#5b6b7c;line-height:1.4">Nenhum sistema hidráulico reconhecido pelos nomes dos elementos. As cores aparecem quando o IFC tiver tubulação nomeada (água fria, esgoto, pluvial, gás, incêndio…).</div>') +
      '<div style="display:flex;gap:6px;margin-top:2px"><button class="btn sm" data-sx="padrao" style="flex:1" title="Voltar às cores padrão">' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Cores padrão</button></div>' +
      '<div style="font-size:11px;color:#5b6b7c;line-height:1.4">Estas cores também valem na <b>Planta baixa</b> e no <b>RA/RV</b>. Clique numa cor pra trocar.</div>';
  }
  // legenda compacta (chips) para o overlay do imersivo — pintada dentro do xrHud
  function montarLegendaChips() {
    var cnt = sistemasPresentes();
    var chips = SIS_ORDEM.filter(function (k) { return cnt[k]; }).map(function (k) {
      return '<span style="display:inline-flex;align-items:center;gap:4px;background:rgba(11,26,43,.72);border-radius:12px;padding:3px 8px;margin:2px"><span style="width:11px;height:11px;border-radius:3px;background:' + sisCores[k] + '"></span>' + esc(SIS_PADRAO[k].nome) + '</span>';
    }).join('');
    return chips ? '<div data-h="sisleg" style="position:absolute;left:8px;top:8px;max-width:62%;pointer-events:none;display:flex;flex-wrap:wrap;font-size:11px;color:#eaf2fb">' + chips + '</div>' : '';
  }
  S._montarLegendaChips = function () { return sisColor.on ? montarLegendaChips() : ''; };
  function repintarSisBase() { S.modelos.forEach(function (mo) { refreshModelo(mo); }); if (S._reaplicarEstilo) S._reaplicarEstilo(); if (S._sisImersivoSync) S._sisImersivoSync(); }
  function setSisColor(on) {
    on = !!on;
    if (on && S._estiloOn && S._estiloOn() && S._setEstiloDesenho) S._setEstiloDesenho(false); // exclusivo do estilo-desenho P&B do corte técnico
    sisColor.on = on;
    if (on) construirSisIdx();
    S.modelos.forEach(function (mo) { refreshModelo(mo); }); // repinta a base respeitando 4D/seleção/clash
    if (S.selected) S.prevMat = matBase(S.selected); // seleção fica com selMat: ressincroniza o material a restaurar (senão desselecionar volta a cor do estado anterior). matBase já lê o sisColor.on novo
    if (S._reaplicarEstilo) S._reaplicarEstilo();
    var b = bar.querySelector('[data-b="sistema"]');
    if (b) { b.classList.toggle('on', on); b.style.background = on ? corAtiva() : ''; b.style.color = on ? '#fff' : ''; }
    pintarSisPanel();
    // no imersivo NÃO abre o painel lateral (tampa a vista) — a legenda vai como chips no HUD
    if (!(S.xr && S.xr.on)) { sisPanel.style.display = on ? 'flex' : 'none'; if (on) fecharPaineis(sisPanel); }
    if (S._sisImersivoSync) S._sisImersivoSync();
    if (S._hint) S._hint(on ? '' + (typeof Icones !== 'undefined' ? Icones.get('paleta', 15) : '') + ' Colorido por sistema hidrossanitário. Toque nas cores da legenda pra personalizar.' : 'Cores originais do modelo restauradas.');
  }
  S._setSistema = setSisColor;
  S._sisColorOn = function () { return !!sisColor.on; };
  S._sisClassificar = function (texto) { return classificaSistemaTxt(texto); };
  // modelo que ENTRAR/mudar com o modo já ligado (IFC federado, edição) pega a cor por sistema —
  // simétrico ao S._reaplicarEstilo; chamado pelo notifyModelos após qualquer mudança de modelos.
  S._reaplicarSistema = function () { if (!sisColor.on) return; construirSisIdx(); S.modelos.forEach(function (mo) { refreshModelo(mo); }); };
  S._sisInfo = function () { // E2E/diagnóstico: estado + classificação + cor efetiva do material por sistema
    var pres = sistemasPresentes(), cores = {}, amostra = {};
    SIS_ORDEM.forEach(function (k) { cores[k] = sisCores[k]; });
    (S.elementos || []).forEach(function (e) {
      var k = e.sistema || classificaEl(e);
      if (amostra[k]) return;
      var m = S.meshPorUid[e.uid];
      amostra[k] = { uid: e.uid, nome: e.nome, matCor: (m && m.material && m.material.color) ? '#' + m.material.color.getHexString() : null };
    });
    return { on: !!sisColor.on, presentes: pres, cores: cores, amostra: amostra };
  };
  sisPanel.addEventListener('input', function (e) {
    var ci = e.target.closest && e.target.closest('input[data-sk]'); if (!ci) return;
    var k = ci.getAttribute('data-sk'); if (!/^#[0-9a-f]{6}$/i.test(ci.value)) return;
    sisCores[k] = ci.value; salvarSisCores(); limparSisMatCache();
    if (sisColor.on) repintarSisBase();
  });
  sisPanel.addEventListener('click', function (e) {
    var b = e.target.closest('[data-sx]'); if (!b) return; var k = b.getAttribute('data-sx');
    if (k === 'fechar') setSisColor(false);
    else if (k === 'padrao') { SIS_ORDEM.forEach(function (kk) { sisCores[kk] = SIS_PADRAO[kk].cor; }); salvarSisCores(); limparSisMatCache(); pintarSisPanel(); if (sisColor.on) repintarSisBase(); }
  });

  // ============================================================
  // 🧱 BLOCOK — PLANTAS EXECUTIVAS (paginação de painéis 90×90 cm)
  // Lê as PAREDES de qualquer IFC, extrai comprimento×altura×espessura pela OBB 2D
  // (motor blocok.js), pagina as placas NUMERADAS (recortes de borda + desconto de
  // vãos) e gera: prancha executiva SVG de CADA parede + mapa de localização + tabela
  // de material (placas por espessura) + INSUMOS calculados (produção das placas +
  // assentamento pela junta escolhida) + carga própria na fundação (peso líquido).
  // ⚠️ EXCLUSIVO de um cliente (feito p/ ele primeiro) — gate por e-mail logado.
  // ============================================================
  function getBK() { return (typeof Blocok !== 'undefined' && Blocok) || (typeof window !== 'undefined' && window.Blocok) || null; }
  function blocokLiberado() {
    try {
      // desbloqueio PERMANENTE desta máquina (dono/teste): sobrevive a updates (localStorage não é
      // sobrescrito pelo pacote de atualização). Ligado pelo LIBERAR-BLOCOK.html do instalador.
      try { if (typeof localStorage !== 'undefined' && localStorage.getItem('orcapro:blocok:owner') === '1') return true; } catch (_) {}
      var norm = function (e) { return String(e || '').trim().toLowerCase(); };
      var A = (typeof window !== 'undefined' && window.Auth) ? window.Auth : (typeof Auth !== 'undefined' ? Auth : null);
      var emLocal = (A && A.usuario && A.usuario()) ? norm(A.usuario().email) : '';           // login local
      var N = (typeof window !== 'undefined' && window.Nuvem) ? window.Nuvem : null;
      var emNuvem = (N && N.auth && N.auth.currentUser) ? norm(N.auth.currentUser.email) : '';  // login da nuvem
      return blocokEmailLiberado(emLocal) || (!!emNuvem && blocokEmailLiberado(emNuvem));
    } catch (_) { return false; }
  }
  var blocokCfg = { espForcada: 'auto', pesoPorEsp: { 10: 46, 13: 46, 15: 46, 20: 46 }, insCfg: null, moCfg: null, logCfg: null, descontarVaos: true };
  function ensureInsCfg() { if (!blocokCfg.insCfg) { var bk = getBK(); blocokCfg.insCfg = bk ? bk.insumoDefaults() : {}; } return blocokCfg.insCfg; }
  function ensureMoCfg() { if (!blocokCfg.moCfg) { var bk = getBK(); blocokCfg.moCfg = bk ? bk.maoDeObraDefaults() : {}; } return blocokCfg.moCfg; }
  function ensureLogCfg() { if (!blocokCfg.logCfg) { var bk = getBK(); blocokCfg.logCfg = bk ? bk.logisticaDefaults() : {}; } return blocokCfg.logCfg; }
  function ehParedeTipo(t) { t = String(t || '').toUpperCase(); return t.indexOf('WALL') >= 0 || t === 'PAREDE'; }
  function ehVaoTipo(t) { t = String(t || '').toUpperCase(); return t.indexOf('DOOR') >= 0 || t.indexOf('WINDOW') >= 0 || t === 'PORTA' || t === 'JANELA'; }
  function fmtB(n) { return (Math.round((+n || 0) * 100) / 100).toFixed(2).replace('.', ','); }
  // pavimento de uma parede: 1) membership declarada no IFC (IfcRelContainedInSpatialStructure via
  // pavLista) 2) por elevação (maior y0 ≤ base) 3) "Pavimento único".
  function pavDaParede(uid, yBase) {
    try {
      var lst = (S._pavLista) ? S._pavLista() : [];
      if (!lst.length) return 'Pavimento único';
      for (var i = 0; i < lst.length; i++) { if (lst[i].uids && lst[i].uids[uid]) return lst[i].nome; }
      var melhor = null;
      lst.forEach(function (pv) { if (pv.y0 != null && pv.y0 <= yBase + 0.5 && (!melhor || pv.y0 > melhor.y0)) melhor = pv; });
      return (melhor && melhor.nome) || lst[0].nome || 'Pavimento único';
    } catch (_) { return 'Pavimento único'; }
  }

  // extrai as paredes VISÍVEIS: pontos XZ (mundo) por parede → OBB 2D (comprimento×
  // espessura + linha de base) + altura pelo Y da malha; detecta vãos pela AABB das
  // portas/janelas projetada na linha da parede.
  function extrairParedesBlocok() {
    var BK = getBK(); if (!BK) return { paredes: [], vaosDet: 0 };
    modelRoot.updateMatrixWorld(true);
    var acc = {}, ordem = [], tmpV = new THREE.Vector3();
    todasMalhas(function (m) {
      var ud = m.userData || {}; if (ud.expressID == null || !m.geometry) return;
      if (!ehParedeTipo(ud.tipo)) return;
      if (m.visible === false || !cadeiaVisivel(m)) return; // respeita isolar/pavimento/4D
      var uid = ud.mid + ':' + ud.expressID, a = acc[uid];
      if (!a) { a = acc[uid] = { pts: [], yMin: Infinity, yMax: -Infinity, tipo: ud.tipo }; ordem.push(uid); }
      var pos = m.geometry.attributes && m.geometry.attributes.position; if (!pos) return;
      var step = Math.max(1, Math.floor(pos.count / 260));
      for (var i = 0; i < pos.count; i += step) {
        tmpV.fromBufferAttribute(pos, i).applyMatrix4(m.matrixWorld);
        a.pts.push([tmpV.x, tmpV.z]);
        if (tmpV.y < a.yMin) a.yMin = tmpV.y; if (tmpV.y > a.yMax) a.yMax = tmpV.y;
      }
    });
    // portas/janelas (AABB de mundo já calculada no load) + nomes por uid
    var vaos = [], nomePorUid = {};
    (S.modelos || []).forEach(function (mo) {
      (mo.elementos || []).forEach(function (e) {
        nomePorUid[e.uid] = e.nome;
        if (ehVaoTipo(e.tipo) && e.aabb) {
          var mn = e.aabb.min, mx = e.aabb.max;
          vaos.push({ cx: (mn[0] + mx[0]) / 2, cz: (mn[2] + mx[2]) / 2, y0: mn[1], y1: mx[1], sx: mx[0] - mn[0], sz: mx[2] - mn[2] });
        }
      });
    });
    // PASSO 1 — paredes válidas, cada uma com seu frame de base (p1 + eixo ux/uz) p/ atribuir vãos
    var raw = [];
    ordem.forEach(function (uid) {
      var a = acc[uid]; if (a.pts.length < 6) return;
      var obb = BK.obb2dXZ(a.pts); if (!obb) return;
      var L = obb.comprimento, esp = obb.espessura, H = (a.yMax - a.yMin);
      if (L < 0.3 || H < 0.3) return;             // fragmento/degenerada: fora
      if (esp < 0.03) esp = 0.10;                 // espessura implausível → mínima Blocok
      var dx = obb.p2[0] - obb.p1[0], dz = obb.p2[1] - obb.p1[1], dl = Math.sqrt(dx * dx + dz * dz) || 1;
      raw.push({ uid: uid, obb: obb, L: L, esp: esp, H: H, yMin: a.yMin, p1: obb.p1, ux: dx / dl, uz: dz / dl, vlist: [] });
    });
    // PASSO 2 — atribui cada vão à parede DONA (motor puro Blocok.distribuirVaos, Node-testável):
    // menor distância perpendicular → evita descontar a mesma abertura de paredes paralelas próximas
    // (fachada dupla, geminada como 2 IfcWall, shaft, gesso). Desconto desligado → nenhum vão entra.
    var vaosDet = BK.distribuirVaos(raw, blocokCfg.descontarVaos ? vaos : []);
    // PASSO 3 — pagina cada parede com os vãos que lhe pertencem + marca o pavimento
    var paredes = [], np = 0;
    raw.forEach(function (w) {
      var espCm = (blocokCfg.espForcada === 'auto') ? BK.espBlocok(w.esp) : +blocokCfg.espForcada;
      var pag = BK.paginar({ comprimento: w.L, altura: w.H, vaos: w.vlist });
      np++;
      paredes.push({ id: 'P' + np, uid: w.uid, nome: nomePorUid[w.uid] || ('Parede ' + np), comprimento: w.L, altura: w.H, espessura: espCm, espM: w.esp, pag: pag, p1: w.obb.p1, p2: w.obb.p2, vaos: w.vlist, pavimento: pavDaParede(w.uid, w.yMin) });
    });
    return { paredes: paredes, vaosDet: vaosDet };
  }
  S._extrairParedesBlocok = extrairParedesBlocok;

  // prancha executiva SVG de UMA parede (elevação com placas numeradas + recortes cotados + vãos)
  function svgParedeBlocok(pd) {
    var pag = pd.pag, L = pag.comprimento, H = pag.altura, pad = 30;
    var sc = Math.min(720 / L, 300 / H); if (!isFinite(sc) || sc <= 0) sc = 40;
    var iw = L * sc, ih = H * sc, W = iw + pad * 2, Ht = ih + pad * 2 + 20;
    function X(x) { return pad + x * sc; }
    function Y(y) { return pad + (H - y) * sc; } // base embaixo (WebGL/desenho: Y pra cima)
    var s = '<svg viewBox="0 0 ' + W.toFixed(0) + ' ' + Ht.toFixed(0) + '" width="100%" style="max-width:' + Math.min(760, W).toFixed(0) + 'px;height:auto;background:#fff;border:1px solid #ccc;border-radius:6px">';
    s += '<rect x="' + X(0).toFixed(1) + '" y="' + Y(H).toFixed(1) + '" width="' + iw.toFixed(1) + '" height="' + ih.toFixed(1) + '" fill="#fbfdff" stroke="#123" stroke-width="1.4"/>';
    (pd.vaos || []).forEach(function (v) {
      s += '<rect x="' + X(v.x).toFixed(1) + '" y="' + Y(v.y + v.h).toFixed(1) + '" width="' + (v.w * sc).toFixed(1) + '" height="' + (v.h * sc).toFixed(1) + '" fill="#e8ecef" stroke="#8a97a3" stroke-dasharray="4 3"/>';
      if (v.w * sc > 30 && v.h * sc > 18) s += '<text x="' + X(v.x + v.w / 2).toFixed(1) + '" y="' + Y(v.y + v.h / 2).toFixed(1) + '" font-size="10" fill="#6b7a8a" text-anchor="middle" dominant-baseline="middle">VÃO</text>';
    });
    var fs = Math.max(8, Math.min(15, sc * 0.28));
    pag.placas.forEach(function (p) {
      var px = X(p.x), py = Y(p.y + p.h), pw = p.w * sc, ph = p.h * sc, rec = p.tipo === 'recorte';
      s += '<rect x="' + px.toFixed(1) + '" y="' + py.toFixed(1) + '" width="' + pw.toFixed(1) + '" height="' + ph.toFixed(1) + '" fill="' + (rec ? '#fdecc8' : '#e6f0fb') + '" stroke="#2b4a6b" stroke-width="0.7"/>';
      if (pw > 15 && ph > 13) {
        s += '<text x="' + (px + pw / 2).toFixed(1) + '" y="' + (py + ph / 2).toFixed(1) + '" font-size="' + fs.toFixed(1) + '" font-weight="bold" fill="#12314f" text-anchor="middle" dominant-baseline="middle">' + p.n + '</text>';
        if (rec && pw > 42 && ph > 30) s += '<text x="' + (px + pw / 2).toFixed(1) + '" y="' + (py + ph - 3).toFixed(1) + '" font-size="8" fill="#8a5a10" text-anchor="middle">' + Math.round(p.w * 100) + '×' + Math.round(p.h * 100) + '</text>';
      }
    });
    s += '<text x="' + (pad + iw / 2).toFixed(1) + '" y="' + (Ht - 5).toFixed(1) + '" font-size="11" fill="#333" text-anchor="middle">L = ' + fmtB(L) + ' m · H = ' + fmtB(H) + ' m · esp ' + pd.espessura + ' cm</text>';
    return s + '</svg>';
  }

  // mapa de localização das paredes (planta esquemática, P1..Pn nas linhas de base)
  function svgMapaBlocok(paredes) {
    if (!paredes.length) return '';
    var xs = [], zs = [];
    paredes.forEach(function (pd) { xs.push(pd.p1[0], pd.p2[0]); zs.push(pd.p1[1], pd.p2[1]); });
    var minX = Math.min.apply(null, xs), maxX = Math.max.apply(null, xs), minZ = Math.min.apply(null, zs), maxZ = Math.max.apply(null, zs);
    var w = (maxX - minX) || 1, h = (maxZ - minZ) || 1, pad = 26;
    var sc = Math.min(680 / w, 420 / h); if (!isFinite(sc) || sc <= 0) sc = 20;
    var W = w * sc + pad * 2, H = h * sc + pad * 2;
    function X(x) { return pad + (x - minX) * sc; }
    function Y(z) { return pad + (z - minZ) * sc; }
    var s = '<svg viewBox="0 0 ' + W.toFixed(0) + ' ' + H.toFixed(0) + '" width="100%" style="max-width:' + Math.min(720, W).toFixed(0) + 'px;height:auto;background:#fff;border:1px solid #ccc;border-radius:6px">';
    paredes.forEach(function (pd) {
      var x1 = X(pd.p1[0]), y1 = Y(pd.p1[1]), x2 = X(pd.p2[0]), y2 = Y(pd.p2[1]), mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
      s += '<line x1="' + x1.toFixed(1) + '" y1="' + y1.toFixed(1) + '" x2="' + x2.toFixed(1) + '" y2="' + y2.toFixed(1) + '" stroke="#1858a8" stroke-width="4" stroke-linecap="round"/>';
      s += '<circle cx="' + mx.toFixed(1) + '" cy="' + my.toFixed(1) + '" r="10" fill="#fff" stroke="#1858a8"/>';
      s += '<text x="' + mx.toFixed(1) + '" y="' + my.toFixed(1) + '" font-size="10" font-weight="bold" fill="#123" text-anchor="middle" dominant-baseline="middle">' + esc(pd.id) + '</text>';
    });
    return s + '</svg>';
  }

  function gerarBlocok(opts) {
    opts = opts || {};
    if (!blocokLiberado()) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Plantas Executivas Blocok é um recurso exclusivo (liberado por licença).'); return null; }
    var BK = getBK();
    if (!BK) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Motor Blocok não carregou (js/blocok.js).'); return null; }
    if (!(S.modelos && S.modelos.length)) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Abra um IFC primeiro — o Blocok lê as paredes do modelo.'); return null; }
    var ext = extrairParedesBlocok(), paredes = ext.paredes;
    if (!paredes.length) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Nenhuma parede visível reconhecida (IfcWall). Verifique se o andar/disciplina está ligado.'); return { paredes: [], material: null, carga: null, insumos: null }; }
    var mat = BK.material(paredes, { pesoPorEsp: blocokCfg.pesoPorEsp });
    var carga = BK.cargaFundacao(paredes, { pesoPorEsp: blocokCfg.pesoPorEsp });
    var ins = BK.insumos(paredes, ensureInsCfg());
    var dados = { paredes: paredes, material: mat, carga: carga, insumos: ins, vaosDet: ext.vaosDet };
    if (!opts.semJanela) abrirRelatorioBlocok(dados);
    if (S._hint) S._hint('🧱 ' + paredes.length + ' paredes · ' + mat.totalPlacas + ' placas · ' + fmtB(mat.pesoTotalT) + ' t. Prancha aberta em nova aba.');
    return dados;
  }
  S.blocok = gerarBlocok;
  S._blocokLiberado = blocokLiberado;

  // 📊 planilha Excel multi-abas (Resumo, por pavimento, romaneio, material, insumos, MO, cargas, logística)
  function gerarPlanilhaBlocok() {
    if (!blocokLiberado()) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Recurso exclusivo (liberado por licença).'); return null; }
    var BK = getBK(); if (!BK) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Motor Blocok não carregou.'); return null; }
    var XLS = (typeof window !== 'undefined' && window.BlocokXLS) || null;
    if (!XLS) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('graficos', 15) : '') + ' Módulo de planilha não carregou (js/blocokxls.js).'); return null; }
    if (!(S.modelos && S.modelos.length)) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Abra um IFC primeiro.'); return null; }
    var ext = extrairParedesBlocok(), paredes = ext.paredes;
    if (!paredes.length) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Nenhuma parede visível reconhecida (IfcWall).'); return null; }
    var pesoCfg = { pesoPorEsp: blocokCfg.pesoPorEsp }, ic = ensureInsCfg();
    var mat = BK.material(paredes, pesoCfg);
    var pacote = {
      obra: (S.opts && (S.opts.obraNome || S.opts.obra)) || 'Obra', data: new Date().toLocaleDateString('pt-BR'),
      paredes: paredes, material: mat, insumos: BK.insumos(paredes, ic), carga: BK.cargaFundacao(paredes, pesoCfg),
      maoObra: BK.maoDeObra(mat, ensureMoCfg()), logistica: BK.logistica(mat, ensureLogCfg()),
      moCfg: ensureMoCfg(), pesoCfg: pesoCfg,
      juntaNome: (ic.junta && ic.junta.tipo === 'argamassa') ? 'argamassa polimérica (junta preenchida)' : (ic.junta && ic.junta.tipo === 'seca') ? 'encaixe seco' : 'cola/adesivo polimérico (cordão)',
      premissas: { faceCm: ic.faceCm, cimento: ic.mix && ic.mix.cimento, areia: ic.mix && ic.mix.areia, pedrisco: ic.mix && ic.mix.pedrisco, aditivo: ic.mix && ic.mix.aditivo }
    };
    if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('graficos', 15) : '') + ' Gerando a planilha Excel (' + paredes.length + ' paredes, ' + mat.totalPlacas + ' placas)…');
    XLS.gerar(pacote, {
      nome: 'Blocok — ' + pacote.obra + ' — ' + pacote.data.replace(/\//g, '-'),
      ok: function () { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('graficos', 15) : '') + ' Planilha Excel baixada — abas por pavimento + romaneio + material + insumos + mão de obra + cargas + logística.'); },
      erro: function (e) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('graficos', 15) : '') + ' Não gerou a planilha (' + e + ').'); }
    });
    return pacote;
  }
  S.blocokPlanilha = gerarPlanilhaBlocok;

  function abrirRelatorioBlocok(d) {
    var w = null; try { w = window.open('', '_blank'); } catch (_) {}
    if (!w) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('imprimir', 15) : '') + ' O navegador bloqueou a nova aba — libere pop-ups pra ver as pranchas Blocok.'); return; }
    var obra = (S.opts && (S.opts.obraNome || S.opts.obra)) || 'Obra', hoje = new Date().toLocaleDateString('pt-BR');
    var m = d.material, cg = d.carga;
    function card(v, l) { return '<div class="cd"><b>' + v + '</b><span>' + esc(l) + '</span></div>'; }
    var cards = card(d.paredes.length, 'paredes') + card(m.totalPlacas, 'placas 90×90') + card(m.totalInteiras, 'inteiras') + card(m.totalRecortes, 'recortes') + card(fmtB(m.areaPlacas) + ' m²', 'área de placa') + card(fmtB(m.pesoTotalT) + ' t', 'peso p/ compra');
    var trEsp = m.porEspessura.map(function (e) { return '<tr><td>' + e.espessura + ' cm</td><td>' + e.placas + '</td><td>' + e.inteiras + '</td><td>' + e.recortes + '</td><td>' + fmtB(e.area) + '</td><td>' + fmtB(e.peso) + '</td></tr>'; }).join('');
    var ins = d.insumos || { producao: [], montagem: [], areaCheia: 0, areaInstalada: 0, juntaTipo: '' };
    function trInsumo(i) { return '<tr><td>' + esc(i.nome) + '</td><td>' + fmtB(i.total) + '</td><td>' + esc(i.unid) + '</td></tr>'; }
    var trProd = (ins.producao || []).map(trInsumo).join('');
    var juntaNome = ins.juntaTipo === 'argamassa' ? 'argamassa polimérica (junta preenchida)' : (ins.juntaTipo === 'seca' ? 'encaixe seco (sem argamassa)' : 'adesivo/argamassa polimérica (cordão)');
    var trMont = (ins.montagem || []).length ? (ins.montagem || []).map(trInsumo).join('') : '<tr><td colspan="3" style="text-align:left;color:#6b7a8a">Junta seca — sem consumo de argamassa/adesivo.</td></tr>';
    var trCg = cg.linhas.map(function (l, ix) { var pd = d.paredes[ix]; return '<tr><td>' + esc(pd ? pd.id : ('P' + (ix + 1))) + '</td><td>' + fmtB(l.comprimento) + '</td><td>' + l.espessura + '</td><td>' + l.placas + '</td><td>' + fmtB(l.pesoKg) + '</td><td>' + fmtB(l.cargaKgM) + '</td><td>' + fmtB(l.cargaKNm) + '</td></tr>'; }).join('');
    var pranchas = d.paredes.map(function (pd) {
      var pg = pd.pag;
      return '<div class="pr"><h3>' + esc(pd.id) + ' — ' + esc(pd.nome) + '</h3><div class="meta">' + fmtB(pd.comprimento) + ' × ' + fmtB(pd.altura) + ' m · esp ' + pd.espessura + ' cm · ' + pg.total + ' placas (' + pg.inteiras + ' inteiras + ' + pg.recortes + ' recortes)' + (pd.vaos && pd.vaos.length ? ' · ' + pd.vaos.length + ' vão(s)' : '') + '</div>' + svgParedeBlocok(pd) + '</div>';
    }).join('');
    var mapa = svgMapaBlocok(d.paredes);
    var css = '*{box-sizing:border-box}body{font-family:-apple-system,Segoe UI,Arial,sans-serif;margin:0;color:#12314f;background:#f4f7fb}'
      + 'header{background:linear-gradient(135deg,#0f2740,#1858a8);color:#fff;padding:20px 26px;display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap}'
      + 'header h1{margin:0;font-size:21px}header .sub{opacity:.85;font-size:13px;margin-top:3px}'
      + '.wrap{max-width:1000px;margin:0 auto;padding:18px 22px 20px}.cards{display:flex;flex-wrap:wrap;gap:10px;margin:14px 0}'
      + '.cd{background:#fff;border:1px solid #dbe4ee;border-radius:10px;padding:10px 14px;min-width:96px;flex:1}.cd b{display:block;font-size:20px;color:#1858a8}.cd span{font-size:11px;color:#6b7a8a;text-transform:uppercase;letter-spacing:.4px}'
      + 'h2{font-size:15px;border-bottom:2px solid #1858a8;padding-bottom:5px;margin:26px 0 12px}'
      + 'table{width:100%;border-collapse:collapse;font-size:12.5px;background:#fff}th,td{border:1px solid #d5dfea;padding:6px 9px;text-align:right}th{background:#eaf1f8}td:first-child,th:first-child{text-align:left}'
      + '.conf{color:#b26a00;font-style:italic}.leg{display:flex;flex-wrap:wrap;gap:16px;font-size:11.5px;color:#6b7a8a;margin:8px 0}.leg span{display:inline-flex;align-items:center;gap:5px}.sw{width:14px;height:14px;border-radius:3px;border:1px solid #2b4a6b;display:inline-block}'
      + '.pr{background:#fff;border:1px solid #dbe4ee;border-radius:10px;padding:14px;margin:14px 0;page-break-inside:avoid}.pr h3{margin:0 0 3px;font-size:14px;color:#1858a8}.pr .meta{font-size:12px;color:#6b7a8a;margin-bottom:8px}'
      + 'footer{max-width:1000px;margin:0 auto;padding:8px 22px 40px;font-size:11px;color:#7a8a99;line-height:1.55}'
      + '.pbtn{background:#16a34a;color:#fff;border:0;border-radius:8px;padding:9px 16px;font-size:13px;cursor:pointer}'
      + '@media print{.pbtn,.noprint{display:none}body{background:#fff}}';
    var html = '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Plantas Executivas Blocok — ' + esc(obra) + '</title><style>' + css + '</style></head><body>'
      + '<header><div><h1>' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Plantas Executivas — Sistema Blocok</h1><div class="sub">' + esc(obra) + ' · ' + hoje + ((typeof Empresa!=='undefined'&&Empresa.creditoTexto&&Empresa.creditoTexto())?' · gerado no OrçaPRO BIM':'') + '</div></div><button class="pbtn noprint" onclick="window.print()">' + (typeof Icones !== 'undefined' ? Icones.get('imprimir', 15) : '') + ' Imprimir / PDF</button></header>'
      + '<div class="wrap">'
      + '<div class="cards">' + cards + '</div>'
      + '<div class="leg"><span><i class="sw" style="background:#e6f0fb"></i> placa inteira 90×90 cm</span><span><i class="sw" style="background:#fdecc8"></i> recorte (dimensão em cm)</span><span><i class="sw" style="background:#e8ecef;border-style:dashed"></i> vão (porta/janela)</span></div>'
      + (mapa ? '<h2>' + (typeof Icones !== 'undefined' ? Icones.get('planta', 15) : '') + ' Mapa de localização das paredes</h2>' + mapa : '')
      + '<h2>' + (typeof Icones !== 'undefined' ? Icones.get('estoque', 15) : '') + ' Material — placas por espessura</h2><table><thead><tr><th>Espessura</th><th>Placas</th><th>Inteiras</th><th>Recortes</th><th>Área (m²)</th><th>Peso (kg)</th></tr></thead><tbody>' + trEsp + '<tr style="font-weight:bold;background:#eef4fa"><td>Total</td><td>' + m.totalPlacas + '</td><td>' + m.totalInteiras + '</td><td>' + m.totalRecortes + '</td><td>' + fmtB(m.areaPlacas) + '</td><td>' + fmtB(m.pesoTotalKg) + '</td></tr></tbody></table>'
      + '<h2>🏭 Insumos de produção das placas <span style="font-size:11px;color:#6b7a8a;font-weight:400">(fábrica — por placa cheia produzida: ' + fmtB(ins.areaCheia) + ' m²)</span></h2><table><thead><tr><th>Insumo</th><th>Quantidade</th><th>Unid.</th></tr></thead><tbody>' + trProd + '</tbody></table>'
      + '<h2>' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Insumos de montagem/assentamento <span style="font-size:11px;color:#6b7a8a;font-weight:400">(obra — junta: ' + esc(juntaNome) + ' · por ' + fmtB(ins.areaInstalada) + ' m² instalados)</span></h2><table><thead><tr><th>Insumo</th><th>Quantidade</th><th>Unid.</th></tr></thead><tbody>' + trMont + '</tbody></table>'
      + '<h2>' + (typeof Icones !== 'undefined' ? Icones.get('obra', 15) : '') + ' Carga própria das paredes na fundação</h2><table><thead><tr><th>Parede</th><th>Comp. (m)</th><th>Esp. (cm)</th><th>Placas</th><th>Peso (kg)</th><th>Carga (kg/m)</th><th>Carga (kN/m)</th></tr></thead><tbody>' + trCg + '<tr style="font-weight:bold;background:#eef4fa"><td>Total</td><td>—</td><td>—</td><td>' + m.totalPlacas + '</td><td>' + fmtB(cg.pesoTotalKg) + '</td><td>—</td><td>—</td></tr></tbody></table>'
      + '<h2>' + (typeof Icones !== 'undefined' ? Icones.get('regua', 15) : '') + ' Pranchas executivas por parede</h2>' + pranchas
      + '</div>'
      + '<footer><b>Observações e premissas (honestidade técnica):</b><br>'
      + '1) Os insumos são uma <b>estimativa técnica calculada</b> a partir da geometria do painel (2 faces de micro concreto + núcleo EPS + junta de assentamento) com um <b>traço de referência editável</b>: produção por placa cheia produzida, assentamento por m² instalado conforme a <b>junta escolhida</b>. Ajuste traço/junta/peso no painel se a sua fábrica usar valores próprios.<br>'
      + '2) Comprimento, altura e espessura de cada parede são extraídos da geometria do IFC (OBB 2D no plano); paredes fora de esquadro, curvas ou fragmentadas podem exigir conferência manual.<br>'
      + '3) Vãos de porta/janela são detectados automaticamente pela posição no modelo — confira nas pranchas (só some a placa 100% dentro do vão).<br>'
      + '4) A carga na fundação é o <b>peso próprio LÍQUIDO</b> das paredes (área de placa efetivamente instalada — o retalho do recorte é descartado, não pesa na parede). Já o card <b>“peso p/ compra”</b> soma <b>placas cheias</b> (o que você adquire/transporta). Não inclui laje, cobertura nem sobrecarga de uso — some às demais cargas no dimensionamento estrutural.<br>'
      + '5) Placas numeradas em fiadas da <b>base para o topo</b>, da <b>esquerda para a direita</b>. ' + ((typeof Empresa!=='undefined'&&Empresa.creditoTexto&&Empresa.creditoTexto())?'Gerado no OrçaPRO BIM.':'') + '</footer>'
      + '</body></html>';
    try { w.document.write(html); w.document.close(); } catch (_) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Não deu pra montar a prancha na nova aba.'); }
  }

  // painel flutuante do Blocok (espessura + peso + insumos editáveis + desconto de vãos)
  var blocokPanel = document.createElement('div');
  blocokPanel.style.cssText = 'position:absolute;left:10px;bottom:14px;z-index:4;display:none;flex-direction:column;gap:7px;background:rgba(255,255,255,.985);border:1px solid #d3dce6;border-radius:11px;padding:12px 13px;color:#1a2b3c;font-size:12px;width:264px;max-height:80%;overflow:auto';
  host.appendChild(blocokPanel);
  S.blocokPanel = blocokPanel;
  var INP = 'width:58px;background:#0b1a2b;border:1px solid #d3dce6;color:#1a2b3c;border-radius:5px;padding:2px 5px';
  function linhaNum(rot, attrs, val, unid) {
    return '<label style="display:flex;align-items:center;gap:5px;margin-top:3px"><span style="flex:1;color:#5b6b7c;font-size:11px">' + rot + '</span><input type="number" min="0" step="0.1" ' + attrs + ' value="' + val + '" style="' + INP + '"><span style="color:#5b6b7c;font-size:10px;width:40px">' + unid + '</span></label>';
  }
  function pintarBlocokPanel() {
    var c = ensureInsCfg();
    var espOpts = ['auto', 10, 13, 15, 20].map(function (v) { return '<option value="' + v + '"' + (String(blocokCfg.espForcada) === String(v) ? ' selected' : '') + '>' + (v === 'auto' ? 'Automática (espessura real)' : v + ' cm') + '</option>'; }).join('');
    var juntaOpts = [['cola', 'Cola/adesivo polimérico (cordão)'], ['argamassa', 'Argamassa polimérica (junta preenchida)'], ['seca', 'Encaixe seco (sem argamassa)']].map(function (o) { return '<option value="' + o[0] + '"' + (c.junta.tipo === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('');
    var juntaExtra = (c.junta.tipo === 'cola') ? linhaNum('Consumo do adesivo', 'data-bkj="cola"', c.junta.colaKgM2, 'kg/m²')
      : (c.junta.tipo === 'argamassa') ? linhaNum('Espessura da junta', 'data-bkj="gap"', c.junta.gapCm, 'cm') : '';
    var pesos = [10, 13, 15, 20].map(function (e) { return '<label style="display:flex;align-items:center;gap:5px;margin-top:3px"><span style="width:36px;color:#5b6b7c">' + e + ' cm</span><input type="number" min="1" step="0.5" data-bkp="peso" data-esp="' + e + '" value="' + blocokCfg.pesoPorEsp[e] + '" style="' + INP + '"><span style="color:#5b6b7c;font-size:11px">kg/placa</span></label>'; }).join('');
    var traco = linhaNum('Cimento CP-V', 'data-bkm="cimento"', c.mix.cimento, 'kg/m³')
      + linhaNum('Areia industrial', 'data-bkm="areia"', c.mix.areia, 'm³/m³')
      + linhaNum('Pedrisco', 'data-bkm="pedrisco"', c.mix.pedrisco, 'm³/m³')
      + linhaNum('Aditivo polimérico', 'data-bkm="aditivo"', c.mix.aditivo, 'kg/m³')
      + linhaNum('Face de micro concreto', 'data-bkf="face"', c.faceCm, 'cm');
    var mc = ensureMoCfg(), lc = ensureLogCfg();
    var molog = linhaNum('Rendimento', 'data-bkmo="placasDiaEquipe"', mc.placasDiaEquipe, 'placas/dia')
      + linhaNum('Equipes', 'data-bkmo="nEquipes"', mc.nEquipes, 'equipe')
      + linhaNum('Pessoas/equipe', 'data-bkmo="pessoasEquipe"', mc.pessoasEquipe, 'pess.')
      + linhaNum('Jornada', 'data-bkmo="jornadaH"', mc.jornadaH, 'h/dia')
      + linhaNum('Custo MO', 'data-bkmo="custoHh"', mc.custoHh, 'R$/Hh')
      + linhaNum('Capac./viagem', 'data-bklg="pesoViagemKg"', lc.pesoViagemKg, 'kg')
      + linhaNum('Placas/pallet', 'data-bklg="placasPallet"', lc.placasPallet, 'un');
    blocokPanel.innerHTML =
      '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><b>' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Plantas Executivas Blocok</b><button class="btn sm" data-bk="fechar" style="padding:2px 8px">' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + '</button></div>'
      + '<div style="font-size:11px;color:#5b6b7c;line-height:1.35">Lê as paredes do IFC → pranchas 90×90 numeradas + material + <b>insumos calculados</b> + carga na fundação.</div>'
      + '<label style="display:flex;flex-direction:column;gap:2px"><span style="color:#5b6b7c">Espessura Blocok</span><select data-bk="esp" style="background:#0b1a2b;border:1px solid #d3dce6;color:#1a2b3c;border-radius:5px;padding:3px 5px">' + espOpts + '</select></label>'
      + '<label style="display:flex;flex-direction:column;gap:2px;margin-top:2px"><span style="color:#5b6b7c">Junta de assentamento</span><select data-bk="junta" style="background:#0b1a2b;border:1px solid #d3dce6;color:#1a2b3c;border-radius:5px;padding:3px 5px">' + juntaOpts + '</select></label>' + juntaExtra
      + '<details style="border-top:1px solid #d3dce6;padding-top:5px"><summary style="cursor:pointer;font-size:11px;color:#243b52">Traço do micro concreto (avançado)</summary>' + traco + '</details>'
      + '<details style="border-top:1px solid #d3dce6;padding-top:5px"><summary style="cursor:pointer;font-size:11px;color:#243b52">Peso por placa (compra)</summary>' + pesos + '</details>'
      + '<details style="border-top:1px solid #d3dce6;padding-top:5px"><summary style="cursor:pointer;font-size:11px;color:#243b52">Mão de obra & logística (planilha)</summary>' + molog + '</details>'
      + '<label style="display:flex;align-items:center;gap:6px;margin-top:2px"><input type="checkbox" data-bk="vaos"' + (blocokCfg.descontarVaos ? ' checked' : '') + '> descontar vãos (portas/janelas)</label>'
      + '<button class="btn sm primary" data-bk="gerar" style="margin-top:2px">' + (typeof Icones !== 'undefined' ? Icones.get('regua', 15) : '') + ' Gerar plantas executivas</button>'
      + '<button class="btn sm" data-bk="planilha" style="margin-top:2px">' + (typeof Icones !== 'undefined' ? Icones.get('graficos', 15) : '') + ' Gerar planilha (Excel)</button>'
      + '<div style="font-size:10px;color:#8296ab;line-height:1.3">Planilha com abas por pavimento, romaneio de placas, material, insumos, mão de obra, cargas e logística. Insumos <b>calculados</b> (traço editável).</div>';
  }
  function toggleBlocokPanel() {
    if (!blocokLiberado()) { if (S._hint) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Plantas Executivas Blocok é um recurso exclusivo (liberado por licença).'); return; }
    var abrir = (blocokPanel.style.display === 'none' || !blocokPanel.style.display);
    if (abrir) { pintarBlocokPanel(); fecharPaineis(blocokPanel); blocokPanel.style.display = 'flex'; }
    else blocokPanel.style.display = 'none';
    var b = bar.querySelector('[data-b="blocok"]'); if (b) { b.style.background = abrir ? corAtiva() : ''; b.style.color = abrir ? '#fff' : ''; }
  }
  S._toggleBlocok = toggleBlocokPanel;
  blocokPanel.addEventListener('change', function (e) {
    var t = e.target; if (!t.getAttribute) return;
    var k = t.getAttribute('data-bk'), kp = t.getAttribute('data-bkp'), kj = t.getAttribute('data-bkj'), kf = t.getAttribute('data-bkf'), km = t.getAttribute('data-bkm'), kmo = t.getAttribute('data-bkmo'), klg = t.getAttribute('data-bklg');
    var c = ensureInsCfg();
    if (k === 'esp') blocokCfg.espForcada = (t.value === 'auto') ? 'auto' : +t.value;
    else if (k === 'vaos') blocokCfg.descontarVaos = !!t.checked;
    else if (k === 'junta') { c.junta.tipo = t.value; pintarBlocokPanel(); } // re-renderiza p/ mostrar o campo da junta escolhida
    else if (kj === 'cola') c.junta.colaKgM2 = Math.max(0, +t.value || 0);
    else if (kj === 'gap') c.junta.gapCm = Math.max(0, +t.value || 0);
    else if (kf === 'face') c.faceCm = Math.max(0.3, +t.value || 1.5);
    else if (km) c.mix[km] = Math.max(0, +t.value || 0);
    else if (kmo) ensureMoCfg()[kmo] = Math.max(0, +t.value || 0);
    else if (klg) ensureLogCfg()[klg] = Math.max(0, +t.value || 0);
    else if (kp === 'peso') { var esp = t.getAttribute('data-esp'), val = +t.value; if (val > 0) blocokCfg.pesoPorEsp[esp] = val; }
  });
  blocokPanel.addEventListener('click', function (e) {
    var b = e.target.closest('[data-bk]'); if (!b) return; var k = b.getAttribute('data-bk');
    if (k === 'fechar') toggleBlocokPanel();
    else if (k === 'gerar') gerarBlocok({});
    else if (k === 'planilha') gerarPlanilhaBlocok();
  });

  function pintarSnapPanel() {
    var cfg = { on: snap.on, v: snap.v, m: snap.m, a: snap.a, i: snap.i, c: snap.c };
    ['on', 'v', 'm', 'a', 'i', 'c'].forEach(function (kk) {
      var b = snapPanel.querySelector('[data-s="' + kk + '"]'); if (!b) return;
      b.style.background = cfg[kk] ? corAtiva() : ''; b.style.color = cfg[kk] ? '#fff' : '';
      if (kk === 'on') b.textContent = cfg.on ? 'ON' : 'OFF';
    });
    var bs = bar.querySelector('[data-b="snap"]'); if (bs) { bs.style.background = snap.on ? corAtiva() : ''; bs.style.color = snap.on ? '#fff' : ''; bs.style.outline = (snapPanel.style.display === 'flex') ? '2px solid #15803d' : ''; }
  }
  pintarSnapPanel();
  function toggleSnapPanel() { var abrir = (snapPanel.style.display === 'none' || !snapPanel.style.display); fecharPaineis(abrir ? snapPanel : null); snapPanel.style.display = abrir ? 'flex' : 'none'; pintarSnapPanel(); } // repinta -> botão mostra painel aberto
  snapPanel.addEventListener('click', function (e) {
    var b = e.target.closest('[data-s]'); if (!b) return; var kk = b.getAttribute('data-s');
    if (kk === 'on') snap.on = !snap.on; else snap[kk] = !snap[kk];
    if (!snap.on) esconderSnapMarca();
    salvarSnap(); pintarSnapPanel();
  });
  // marcador HTML (não entra na cena 3D: não é clipado nem raycastado)
  var snapMarca = document.createElement('div');
  /* ⚠ O ÍCONE FICA CRAVADO NO PONTO, e os rótulos penduram EMBAIXO dele.
     Antes o bloco inteiro (ícone + rótulo) era centralizado no ponto com
     translate(-50%,-50%): com o rótulo escrito, o ícone subia ~7 px acima do
     ponto de verdade, enquanto as linhas-guia cruzavam no lugar certo — o
     marcador e a guia discordavam de onde a trena ia agarrar. A âncora agora
     tem 0×0 e cada peça é posicionada a partir dela. */
  snapMarca.style.cssText = 'position:absolute;z-index:5;display:none;pointer-events:none;width:0;height:0;overflow:visible';
  snapMarca.innerHTML = '<div data-sm="ico" style="position:absolute;left:-8px;top:-8px;width:16px;height:16px;box-sizing:border-box;border:2px solid #22c55e"></div>' +
    '<div data-sm="rot" style="position:absolute;top:11px;left:0;transform:translateX(-50%);white-space:nowrap;font-size:10px;font-weight:700;color:#15803d;background:rgba(15,39,64,.8);border-radius:5px;padding:1px 6px;text-align:center"></div>' +
    '<div data-sm="dist" style="position:absolute;top:25px;left:0;transform:translateX(-50%);white-space:nowrap;display:none;font-size:11px;font-weight:800;color:#fff;background:rgba(15,39,64,.88);border-radius:6px;padding:1px 7px"></div>';
  host.appendChild(snapMarca);
  S.snapMarca = snapMarca;
  var SNAP_VIS = { vertice: { cor: '#22c55e', borda: '0', rot: 'vértice' }, meio: { cor: '#f59e0b', borda: '50%', rot: 'meio' }, aresta: { cor: '#38bdf8', borda: '0', rot: 'aresta' }, intersecao: { cor: '#e879f9', borda: '0', rot: '✚ interseção' }, centro: { cor: '#facc15', borda: '50%', rot: '⊕ centro' } };
  // o marcador é ANCORADO NO MUNDO e re-projetado a cada frame (achado do usuário: posicionado
  // uma única vez, ficava "pendurado" na tela enquanto o damping da câmera ainda deslizava —
  // o ponto mostrado parecia longe/bugado em relação ao ponto real)
  var snapVivo = null; // { p: Vector3, tipo }

  // ============================================================
  // ┿ TRAÇOS FINOS nos cantos, começos e meios à volta do cursor
  //
  // Traços de 1 px marcando canto, começo, meio e centro dos objetos ao redor
  // do cursor, enquanto uma ferramenta de ponto está ativa.
  //
  // O marcador mostra UM ponto: o que venceu. Isso responde "onde vai agarrar"
  // mas não responde "o que existe aqui" — e é a segunda pergunta de quem acha
  // que o snap pegou no lugar errado. Vendo os candidatos, move-se dois pixels
  // e pega-se o que se queria, em vez de tentar de novo às cegas.
  //
  // São 1 px de verdade e no máximo 8: mais que isso vira sujeira sobre o
  // modelo, e tela limpa é requisito desta mesma tela.
  // ============================================================
  var NOTAVEL_MAX = 8;
  var NOTAVEL_MIN_SEP = 9;   // px entre dois traços: o próprio traço tem 11 px de vao
  var notavelPool = [], notavelPts = [];
  function notavelEl(i) {
    var vivo = (S && S.host) || host;   // nunca o `host` do fecho: ele morre na 2ª visita à aba
    if (notavelPool[i]) {
      /* re-pendura sozinho depois de o viewer trocar de host (App.render refaz o
         HTML da aba). Sem isto os traços ficariam presos no host descartado — o
         mesmo jeito de sumir calado que já pegou o sisPanel e o blocokPanel. */
      if (notavelPool[i].parentNode !== vivo) vivo.appendChild(notavelPool[i]);
      return notavelPool[i];
    }
    var d = document.createElement('div');
    d.setAttribute('data-bim', 'notavel');
    d.style.cssText = 'position:absolute;z-index:3;display:none;pointer-events:none;width:11px;height:11px;transform:translate(-50%,-50%);opacity:.75';
    vivo.appendChild(d); notavelPool[i] = d; return d;
  }
  function notaveisEsconder() { notavelPts = []; for (var i = 0; i < notavelPool.length; i++) notavelPool[i].style.display = 'none'; }
  function notaveisDefinir(lista) {
    notavelPts = [];
    if (!lista || !lista.length || !snap.on) { notaveisEsconder(); return; }
    /* mais perto primeiro, e sem repetir o mesmo canto que dezenas de arestas
       vizinhas devolvem — senão os 8 lugares vão todos para o mesmo ponto.
       ⚠ A DEDUPLICAÇÃO É POR TELA, não pelo mundo. Deduplicar em 3D deixava
       passar pontos legitimamente distintos que se PROJETAM no mesmo pixel — as
       duas faces de uma parede fina vistas de canto, por exemplo. Na primeira
       versão os 8 traços saíram empilhados em 2 lugares: tecnicamente corretos
       e visualmente inúteis, que é justamente o oposto do que foi pedido. O que
       importa aqui é o olho, então a régua tem de ser a do olho. */
    var rc = canvasEl.getBoundingClientRect();
    var ord = lista.slice().sort(function (a, b) { return a.d - b.d; }), aceitos = [];
    for (var i = 0; i < ord.length && notavelPts.length < NOTAVEL_MAX; i++) {
      var q = _snP.copy(ord[i].v).project(camera);
      if (q.z > 1 || q.z < -1) continue;
      var sx = (q.x + 1) / 2 * rc.width, sy = (1 - q.y) / 2 * rc.height;
      /* ⚠ DISTÂNCIA, não balde de grade. Arredondar para uma grade de 6 px
         separa 92 e 94 em baldes vizinhos e os dois traços saem colados assim
         mesmo — foi o que apareceu na tela. Com no máximo 8 aceitos, comparar
         um a um custa nada e não tem borda de balde. */
      var colado = false;
      for (var ai = 0; ai < aceitos.length; ai++) {
        var ddx = aceitos[ai][0] - sx, ddy = aceitos[ai][1] - sy;
        if (ddx * ddx + ddy * ddy < NOTAVEL_MIN_SEP * NOTAVEL_MIN_SEP) { colado = true; break; }
      }
      if (colado) continue;
      aceitos.push([sx, sy]); notavelPts.push(ord[i]);
    }
    posicionarNotaveis();
  }
  function posicionarNotaveis() {
    /* ⚠ `S.host`: o `host` do fecho MORRE na 2ª visita à aba (ver `resize`). Medir o host descartado devolve zeros e a sobreposição sai deslocada da origem do palco — lupa longe do dedo, guias fora do ponto. */
    var rc = canvasEl.getBoundingClientRect(), hr = ((S && S.host) || host).getBoundingClientRect(), i;
    for (i = 0; i < notavelPool.length; i++) if (i >= notavelPts.length) notavelPool[i].style.display = 'none';
    for (i = 0; i < notavelPts.length; i++) {
      var el = notavelEl(i), n = notavelPts[i];
      var q = _snP.copy(n.v).project(camera);
      if (q.z > 1 || q.z < -1) { el.style.display = 'none'; continue; }
      el.style.left = ((q.x + 1) / 2 * rc.width + (rc.left - hr.left)) + 'px';
      el.style.top = ((1 - q.y) / 2 * rc.height + (rc.top - hr.top)) + 'px';
      /* ⚠ a COR só muda quando o tipo muda, e o tipo não muda entre quadros.
         Remontar a string do gradiente e reescrever `background` nos 8 traços a
         cada quadro era trabalho puro, para sempre, mesmo com nada se mexendo. */
      if (el._corBim !== n.tipo) {
        var cor = (SNAP_VIS[n.tipo] || { cor: '#22c55e' }).cor;
        /* cruz de 1 px em duas faixas — sem borda, sem sombra: fino de verdade */
        el.style.background = 'linear-gradient(' + cor + ',' + cor + ') center/11px 1px no-repeat,'
          + 'linear-gradient(' + cor + ',' + cor + ') center/1px 11px no-repeat';
        el._corBim = n.tipo;
      }
      el.style.display = 'block';
    }
  }

  function posicionarSnapMarca() {
    if (notavelPts.length) posicionarNotaveis();
    if (!snapVivo) return;
    var rc = canvasEl.getBoundingClientRect(), hr = ((S && S.host) || host).getBoundingClientRect();   // host VIVO (idem)
    var q = snapVivo.p.clone().project(camera);
    if (q.z > 1 || q.z < -1) { snapMarca.style.display = 'none'; return; } // atrás da câmera/fora do frustum
    var x = (q.x + 1) / 2 * rc.width + (rc.left - hr.left), y = (1 - q.y) / 2 * rc.height + (rc.top - hr.top);
    snapMarca.style.left = x + 'px'; snapMarca.style.top = y + 'px'; snapMarca.style.display = 'block';
    /* as guias seguem o MESMO ponto do mundo, reprojetado a cada quadro — se
       fossem posicionadas uma vez só, ficariam penduradas na tela enquanto o
       amortecimento da câmera ainda desliza, que é o defeito que esta função
       já corrige para o marcador. */
    var vg = SNAP_VIS[snapVivo.tipo];
    if (snapVivo.tipo) guiasEm(x, y, vg ? vg.cor : '#22c55e');
    else guiasEsconder();   /* sem ponto agarrado não há alinhamento a mostrar: guia aí seria promessa falsa */
  }
  S._tickExtra.push(function () { posicionarSnapMarca(); });
  /* ⚠ O QUE A TRENA ESTÁ SEGUINDO FICA ACESO. O marcador diz o TIPO do ponto;
     com arestas de várias peças passando perto, faltava dizer QUAL aresta e
     de QUAL peça — "sempre fico com dúvida de onde estou pegando" (30/09/2026).
     A aresta acesa mora na CENA (fora do modelo: não é raycastada nem vai para
     o arquivo da RA) e desenha por cima de tudo. */
  var destaqueSnap = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]), new THREE.LineBasicMaterial({ color: 0x38bdf8, depthTest: false, transparent: true, opacity: 0.95 }));
  destaqueSnap.renderOrder = 999; destaqueSnap.visible = false; destaqueSnap.frustumCulled = false; scene.add(destaqueSnap);
  /* o ELÁSTICO: do 1º ponto da trena até onde o cursor vai agarrar, com a
     distância AO VIVO. Antes o número só aparecia depois do 2º clique — a
     pessoa media no escuro e conferia depois. A conta é a mesma do
     `desenharMedida` (na planta, horizontal, e o rótulo diz). */
  var elastico = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]), new THREE.LineBasicMaterial({ color: 0x22c55e, depthTest: false, transparent: true, opacity: 0.85 }));
  elastico.renderOrder = 996; elastico.visible = false; elastico.frustumCulled = false; scene.add(elastico);
  function linhaEm(l, a, b) { var pa = l.geometry.attributes.position; pa.setXYZ(0, a.x, a.y, a.z); pa.setXYZ(1, b.x, b.y, b.z); pa.needsUpdate = true; l.geometry.computeBoundingSphere(); l.visible = true; }
  function distElastico(a, b, eixoRot) {
    var horizontal = !eixoRot && !!planta.on;
    var d = horizontal ? Math.sqrt((a.x - b.x) * (a.x - b.x) + (a.z - b.z) * (a.z - b.z)) : a.distanceTo(b);
    return fmtDist(d) + (eixoRot ? ' (' + eixoRot + ')' : horizontal ? ' (horizontal)' : '');
  }
  function atualizarElastico(p) {
    var dv = snapMarca.querySelector('[data-sm="dist"]');
    if (!p || !medir.on || medir.pts.length !== 1) { elastico.visible = false; dv.style.display = 'none'; return; }
    var rr = restringir(medir.pts[0].p, p);
    linhaEm(elastico, medir.pts[0].p, rr.p);
    dv.textContent = distElastico(medir.pts[0].p, rr.p, rr.rot); dv.style.display = 'block';
  }
  /* =====================================================================
   * ⚠ EIXO TRAVADO DA TRENA (01/10/2026): medir SÓ na horizontal, SÓ na
   * vertical (pé-direito, peitoril) ou AO LONGO de uma aresta — e, no
   * computador, Shift trava no eixo dominante (X, Z ou vertical), como nos
   * programas de CAD. Sem isso, medir um pé-direito exigia achar dois pontos
   * exatamente um sobre o outro; qualquer desvio entrava na cota.
   * O ponto travado é o que o elástico mostra E o que a medida grava — a conta
   * é uma só (`restringir`). Na planta vale a regra de sempre (horizontal).
   * ===================================================================== */
  var EIXOS = [{ k: 'livre', rot: 'Livre' }, { k: 'h', rot: 'Horizontal' }, { k: 'v', rot: 'Vertical' }, { k: 'aresta', rot: 'Ao longo da aresta' }];
  medir.eixo = 'livre'; medir.dirAresta = null;
  var _shift = false;
  function dirDaAresta(sn) {
    if (!sn || !sn.seg || (sn.tipo !== 'aresta' && sn.tipo !== 'meio')) return null;
    var d = sn.seg[1].clone().sub(sn.seg[0]); return d.lengthSq() > 1e-10 ? d.normalize() : null;
  }
  function restringir(a, p) {
    var eixo = _shift ? 'orto' : medir.eixo;
    if (planta.on && eixo !== 'orto') return { p: p.clone(), rot: '' };   /* a planta já mede na horizontal */
    if (eixo === 'h') return { p: new THREE.Vector3(p.x, a.y, p.z), rot: 'horizontal' };
    if (eixo === 'v' && !planta.on) return { p: new THREE.Vector3(a.x, p.y, a.z), rot: 'vertical' };
    if (eixo === 'orto') {
      var dx = Math.abs(p.x - a.x), dy = planta.on ? 0 : Math.abs(p.y - a.y), dz = Math.abs(p.z - a.z);
      if (dy >= dx && dy >= dz) return { p: new THREE.Vector3(a.x, p.y, a.z), rot: 'vertical' };
      if (dx >= dz) return { p: new THREE.Vector3(p.x, a.y, a.z), rot: 'eixo X' };
      return { p: new THREE.Vector3(a.x, a.y, p.z), rot: 'eixo Z' };
    }
    if (eixo === 'aresta' && medir.dirAresta) { var k = p.clone().sub(a).dot(medir.dirAresta); return { p: a.clone().add(medir.dirAresta.clone().multiplyScalar(k)), rot: 'ao longo da aresta' }; }
    return { p: p.clone(), rot: '' };
  }
  S._restringirTrena = restringir;   // hook de teste
  var eixoBar = document.createElement('div');
  eixoBar.setAttribute('data-bim', 'eixo');
  /* `eixoBase`: quem monta pode pôr faixa própria em cima da barra de baixo
     (o visor do link põe a da trena) — o eixo sobe para não ficar por baixo.
     max-width: num celular de 360 px os quatro botões não cabem na largura
     do conteúdo — o teto faz os botões encolherem (o rótulo quebra dentro
     deles) em vez de a barra sair da tela. */
  eixoBar.style.cssText = 'position:absolute;left:50%;transform:translateX(-50%);bottom:' + (opts.eixoBase != null ? opts.eixoBase : (opts.baseReservada || 0) + 14) + 'px;z-index:21;display:none;justify-content:center;width:max-content;max-width:calc(100% - 16px);box-sizing:border-box;gap:4px;padding:4px;border-radius:12px;background:rgba(11,26,43,.86);box-shadow:0 2px 10px rgba(0,0,0,.3);font:600 12px Inter,system-ui,sans-serif';
  host.appendChild(eixoBar); S.eixoBar = eixoBar;   /* ⚠ e entra na lista do RE-HOME */
  function pintarEixo() {
    var vis = medir.on && !planta.on;
    eixoBar.style.display = vis ? 'flex' : 'none';
    if (!vis) return;
    eixoBar.innerHTML = EIXOS.map(function (x) {
      var on = medir.eixo === x.k;
      return '<button type="button" data-eixo="' + x.k + '" style="border:0;border-radius:9px;padding:7px 11px;cursor:pointer;touch-action:manipulation;color:' + (on ? '#fff' : '#cbd8e6') + ';background:' + (on ? '#2563eb' : 'transparent') + '">' + x.rot + '</button>';
    }).join('') + (ehToque() ? '' : '<span style="align-self:center;color:#7d93ab;font-size:11px;padding:0 6px">Shift: eixo mais perto</span>');   /* no dedo não há Shift */
  }
  eixoBar.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-eixo]') : null; if (!b) return;
    e.stopPropagation();
    medir.eixo = b.getAttribute('data-eixo'); pintarEixo();
    if (_ultimaMira && _ultimaMira.sn && _ultimaMira.sn.p) atualizarElastico(_ultimaMira.sn.p);
  });
  S._pintarEixo = pintarEixo;
  S._elasticoTexto = function () { var dv = snapMarca.querySelector('[data-sm="dist"]'); return dv.style.display === 'none' ? '' : dv.textContent; };   // hook de teste
  /* nome curto da peça do ponto agarrado — lido com textContent, nunca HTML:
     vem cru de um IFC de terceiros */
  var _elUid = { n: -1, arr: null, mapa: {} };
  function nomeDaPeca(obj) {
    var ud = obj && obj.userData; if (!ud || ud.expressID == null) return '';
    var els = S.elementos || [];
    if (_elUid.arr !== els || _elUid.n !== els.length) { _elUid = { n: els.length, arr: els, mapa: {} }; for (var i = 0; i < els.length; i++) _elUid.mapa[els[i].uid] = els[i]; }
    var el = _elUid.mapa[(ud.mid != null ? ud.mid : S.modelID) + ':' + ud.expressID];
    var nm = String((el && (el.familia || el.nome || el.tipo)) || ud.tipo || '');
    return nm.length > 30 ? nm.slice(0, 29) + '…' : nm;
  }
  function mostrarSnapMarca(sn) {
    notaveisDefinir(sn && sn.notaveis);
    if (sn && sn.p && sn.seg && (sn.tipo === 'aresta' || sn.tipo === 'meio')) { linhaEm(destaqueSnap, sn.seg[0], sn.seg[1]); destaqueSnap.material.color.set((SNAP_VIS[sn.tipo] || SNAP_VIS.aresta).cor); }
    else destaqueSnap.visible = false;
    atualizarElastico(sn && sn.p);
    if (!sn || !sn.tipo) {
      snapVivo = null; guiasEsconder();
      /* ⚠ ELEMENTO PESADO: o snap não é pulado à toa — gerar as arestas de uma
         malha densa (terreno, mobiliário importado) trava o hover. Mas até aqui
         ele PULAVA CALADO: nenhuma marca, nenhum aviso, e quem media concluia
         que "o snap não pega direito". Um limite técnico legítimo virava queixa
         de imprecião. Agora ele diz o que houve; inventar ponto continua fora. */
      if (sn && sn.pesado && snap.on) {
        var icoP = snapMarca.querySelector('[data-sm="ico"]');
        icoP.style.borderColor = '#94a3b8'; icoP.style.borderRadius = '50%'; icoP.style.transform = '';
        var rotP = snapMarca.querySelector('[data-sm="rot"]');
        rotP.textContent = 'sem snap (peça pesada)'; rotP.style.color = '#94a3b8';
        snapVivo = { p: sn.p.clone(), tipo: null };
        posicionarSnapMarca();
        return;
      }
      /* SUPERFÍCIE: sem canto nem aresta perto o clique cai na face — e isso
         também se mostra. Sumir com o marcador deixava a dúvida de "vai pegar
         o quê?" justo onde a resposta era simples. */
      if (sn && sn.p && snap.on) {
        var icoS = snapMarca.querySelector('[data-sm="ico"]');
        icoS.style.borderColor = '#cbd5e1'; icoS.style.borderRadius = '50%'; icoS.style.transform = 'scale(.6)';
        var rotS = snapMarca.querySelector('[data-sm="rot"]'), nmS = nomeDaPeca(sn.obj);
        rotS.textContent = 'superfície' + (nmS ? ' · ' + nmS : ''); rotS.style.color = '#cbd5e1';
        snapVivo = { p: sn.p.clone(), tipo: null };
        posicionarSnapMarca();
        return;
      }
      snapMarca.style.display = 'none';
      return;
    }
    var vis = SNAP_VIS[sn.tipo], ico = snapMarca.querySelector('[data-sm="ico"]');
    ico.style.borderColor = vis.cor; ico.style.borderRadius = vis.borda;
    ico.style.transform = (sn.tipo === 'aresta' || sn.tipo === 'intersecao') ? 'rotate(45deg)' : '';
    var nmP = nomeDaPeca(sn.obj);
    snapMarca.querySelector('[data-sm="rot"]').textContent = vis.rot + (nmP ? ' · ' + nmP : '');
    snapMarca.querySelector('[data-sm="rot"]').style.color = vis.cor;
    snapVivo = { p: sn.p.clone(), tipo: sn.tipo };
    posicionarSnapMarca();
  }
  function esconderSnapMarca() { snapVivo = null; snapMarca.style.display = 'none'; guiasEsconder(); notaveisEsconder(); destaqueSnap.visible = false; atualizarElastico(null); }

  // ============================================================
  // ┼ LINHAS-GUIA FINAS — onde o ponto vai cair, atravessando a tela
  //
  // O marcador de snap é um quadradinho de 12px. Num modelo cheio ele se
  // perde no meio da geometria: o ponto agarrado até estava certo, mas não
  // dava para VER onde tinha caído antes de soltar o clique — e isso se lê
  // como imprecião.
  //
  // Duas linhas de 1px atravessando a tela pelo ponto resolvem porque dão
  // ALINHAMENTO: a pessoa enxerga que o ponto está na mesma altura do topo
  // da parede, ou na mesma prumada do eixo do tubo. É o que o CAD faz há
  // trinta anos, e é barato — duas divs, sem custo de GPU.
  // ============================================================
  var guiaH = document.createElement('div'), guiaV = document.createElement('div');
  guiaH.setAttribute('data-bim', 'guia-h');
  guiaH.style.cssText = 'position:absolute;left:0;right:0;height:0;border-top:1px dashed rgba(34,197,94,.55);z-index:4;display:none;pointer-events:none';
  guiaV.setAttribute('data-bim', 'guia-v');
  guiaV.style.cssText = 'position:absolute;top:0;bottom:0;width:0;border-left:1px dashed rgba(34,197,94,.55);z-index:4;display:none;pointer-events:none';
  host.appendChild(guiaH); host.appendChild(guiaV);
  S.guiaH = guiaH; S.guiaV = guiaV;
  function guiasEsconder() { guiaH.style.display = 'none'; guiaV.style.display = 'none'; }
  function guiasEm(x, y, cor) {
    guiaH.style.borderTopColor = cor; guiaV.style.borderLeftColor = cor;
    guiaH.style.top = y + 'px'; guiaV.style.left = x + 'px';
    guiaH.style.display = 'block'; guiaV.style.display = 'block';
  }

  // ============================================================
  // 🔍 LUPA — mirar no dedo sem o dedo tapar o alvo
  //
  // O PROBLEMA, no celular e no tablet: para colocar um ponto você toca — e
  // o dedo cobre exatamente o pixel que você quer. Pior, o `pointerup` só
  // aceita o ponto se você NÃO arrastou (>10px vira órbita), então não dá
  // nem para ajustar a mira: é acertar de primeira, às cegas. E o marcador
  // de snap, que mostraria onde vai agarrar, só aparecia no `pointermove` —
  // que no toque não existe antes do toque.
  //
  // COMO FUNCIONA: toque e SEGURE (~350 ms). A lupa abre ACIMA do dedo,
  // ampliando 3× a região sob ele, com a cruz no centro. A partir daí,
  // arrastar move a MIRA (a câmera fica parada), o snap roda a cada quadro
  // e o que vai ser agarrado aparece dentro da lupa. Solta: o ponto entra
  // onde a cruz estava.
  //
  // ⚠ POR QUE TOQUE-E-SEGURE, e não "arrastar mira sempre": arrastar com um
  //   dedo é ORBITAR, e sempre foi. Roubar esse gesto quebraria a navegação
  //   de quem já usa. O toque simples continua funcionando igual — a lupa é
  //   para quem precisa de precisão, e ela se anuncia sozinha.
  // ============================================================
  var LUPA_Z = 3.0, LUPA_D = 132, LUPA_ESPERA = 350;
  var lupa = { on: false, x: 0, y: 0, timer: null, id: null, sn: null };
  S.lupa = lupa;
  var lupaEl = document.createElement('div');
  lupaEl.setAttribute('data-bim', 'lupa');   // âncora do teste e do suporte
  lupaEl.style.cssText = 'position:absolute;z-index:9;display:none;pointer-events:none;width:' + LUPA_D + 'px;height:' + LUPA_D + 'px;' +
    'border-radius:50%;overflow:hidden;border:3px solid rgba(34,197,94,.95);box-shadow:0 6px 22px rgba(0,0,0,.45);transform:translate(-50%,-50%);background:#ffffff';
  var lupaCv = document.createElement('canvas');
  lupaCv.width = LUPA_D; lupaCv.height = LUPA_D;
  lupaCv.style.cssText = 'width:100%;height:100%;display:block';
  lupaEl.appendChild(lupaCv);
  host.appendChild(lupaEl);
  S.lupaEl = lupaEl;
  var lupaCtx = lupaCv.getContext('2d');

  function lupaDesenhar() {
    if (!lupa.on || !lupaCtx) return;
    var rc = canvasEl.getBoundingClientRect();
    var dpr = (canvasEl.width / Math.max(1, rc.width)) || 1;   // canvas em pixels do aparelho
    var cx = (lupa.x - rc.left) * dpr, cy = (lupa.y - rc.top) * dpr;
    var lado = (LUPA_D / LUPA_Z) * dpr;
    lupaCtx.clearRect(0, 0, LUPA_D, LUPA_D);
    try {
      lupaCtx.drawImage(canvasEl, cx - lado / 2, cy - lado / 2, lado, lado, 0, 0, LUPA_D, LUPA_D);
    } catch (e) { return; }   // buffer indisponível: melhor lupa vazia que exceção no laço de render
    var m = LUPA_D / 2;
    /* a cruz da mira: fina, para não esconder o que se está mirando */
    lupaCtx.strokeStyle = 'rgba(255,255,255,.85)'; lupaCtx.lineWidth = 1;
    lupaCtx.beginPath();
    lupaCtx.moveTo(m - 16, m); lupaCtx.lineTo(m - 4, m);
    lupaCtx.moveTo(m + 4, m); lupaCtx.lineTo(m + 16, m);
    lupaCtx.moveTo(m, m - 16); lupaCtx.lineTo(m, m - 4);
    lupaCtx.moveTo(m, m + 4); lupaCtx.lineTo(m, m + 16);
    lupaCtx.stroke();
    /* e ONDE vai agarrar: o mesmo código de cor do marcador, dentro da lupa */
    if (lupa.sn && lupa.sn.tipo) {
      var vis = SNAP_VIS[lupa.sn.tipo] || { cor: '#22c55e', rot: '' };
      var q = lupa.sn.p.clone().project(camera);
      var sx = (q.x + 1) / 2 * rc.width + rc.left, sy = (1 - q.y) / 2 * rc.height + rc.top;
      var lx = m + (sx - lupa.x) * LUPA_Z, ly = m + (sy - lupa.y) * LUPA_Z;
      lupaCtx.strokeStyle = vis.cor; lupaCtx.lineWidth = 2;
      if (lupa.sn.tipo === 'meio') { lupaCtx.beginPath(); lupaCtx.arc(lx, ly, 7, 0, 6.284); lupaCtx.stroke(); }
      else { lupaCtx.strokeRect(lx - 6, ly - 6, 12, 12); }
      lupaCtx.fillStyle = vis.cor; lupaCtx.font = 'bold 11px Arial'; lupaCtx.textAlign = 'center';
      lupaCtx.fillText(vis.rot, m, LUPA_D - 9);
    }
  }
  S._tickPos.push(function () { lupaDesenhar(); });

  function lupaPosicionar() {
    var hr = ((S && S.host) || host).getBoundingClientRect();   // host VIVO (idem)
    /* ACIMA do dedo — e desce para baixo quando não cabe em cima, senão a
       lupa sairia da tela justamente perto da borda de cima, que é onde mais
       se mede (topo de parede, laje). */
    var offset = LUPA_D * 0.78;
    var y = lupa.y - hr.top - offset;
    if (y - LUPA_D / 2 < 4) y = lupa.y - hr.top + offset;
    lupaEl.style.left = (lupa.x - hr.left) + 'px';
    lupaEl.style.top = y + 'px';
  }
  function lupaAtualizarSnap() {
    var sn = mirarEm(lupa.x, lupa.y, raioToque({ pointerType: 'touch' }));
    if (!sn || !sn.p) { lupa.sn = null; esconderSnapMarca(); return; }
    /* ⚠ O MESMO RAIO QUE A SOLTURA VAI USAR. Aqui era 26 e a soltura sintetiza um
       evento `pointerType:'touch'`, que cai em `raioToque` = 30. Dois raios = a lupa
       podia MOSTRAR um ponto e a cota GRAVAR outro — exatamente a queixa que esta
       versão veio consertar, reintroduzida dentro do próprio conserto. */
    lupa.sn = { p: sn.p.clone(), tipo: sn.tipo || null };
    mostrarSnapMarca(sn);   /* mesmo sem tipo: os traços finos dos notáveis continuam úteis, e o aviso de elemento pesado precisa aparecer TAMBÉM dentro da lupa */
  }
  function lupaAbrir(x, y, pid) {
    lupa.on = true; lupa.x = x; lupa.y = y; lupa.id = pid;
    lupaEl.style.display = 'block';
    if (orbit) orbit.enabled = false;        // enquanto mira, a câmera fica parada
    lupaPosicionar(); lupaAtualizarSnap();
    S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '') + ' Arraste para ajustar a mira. Solte para marcar o ponto.');
  }
  function lupaFechar(semDica) {
    if (!lupa.on) return;
    lupa.on = false; lupa.id = null; lupa.sn = null;
    lupaEl.style.display = 'none';
    if (orbit) orbit.enabled = !trava.on;   /* ⚠ fechar a lupa não destrava a câmera */
    /* ⚠ e a dica da lupa NÃO pode ficar no ar. "Arraste para ajustar a mira,
       solte para marcar o ponto" mandando fazer uma coisa que já não é possível
       é pior que balão nenhum — principalmente quando a lupa fechou sozinha
       (segundo dedo, cancelamento do sistema). Quem soltou um PONTO passa
       `semDica`: ali a próxima mensagem já vem do fluxo da medição. */
    if (!semDica && S._hint) S._hint('');
  }
  S._lupaFechar = lupaFechar;
  S._ferramentaClique = ferramentaClique;   // o hook de estado precisa dizer POR QUE a lupa nao abriu
  function lupaCancelarEspera() { if (lupa.timer) { clearTimeout(lupa.timer); lupa.timer = null; } }

  /* Os três ganchos que o `pointerdown/move/up` lá de cima chama. Ficam aqui,
     junto do resto da lupa, porque o handler nasce ANTES deste bloco (o
     `canvasEl` é criado no começo) e chamá-los por `S._` é o que a casa já faz
     para o preview da parede. */
  S._lupaAgendar = function (e) {
    lupaCancelarEspera();
    var x = e.clientX, y = e.clientY, pid = e.pointerId;
    lupa.timer = setTimeout(function () {
      lupa.timer = null;
      if (!S || !S.alive || !ferramentaClique()) return;
      if (!medir.down) return;                    // já soltou: foi toque simples
      lupaAbrir(x, y, pid);
    }, LUPA_ESPERA);
  };
  var _lupaSnapT = 0;
  S._lupaMover = function (e) {
    if (lupa.on) {
      if (lupa.id != null && e.pointerId !== lupa.id) return;
      lupa.x = e.clientX; lupa.y = e.clientY;
      lupaPosicionar();
      /* ⚠ O MESMO estrangulamento do hover do mouse (60 ms). A mira roda um
         raycast + varredura completa de snap; sem teto, cada evento de dedo
         arrastando pagava tudo de novo, e o dedo emite muito mais eventos que
         o mouse justamente no aparelho mais fraco. A posição da lupa segue o
         dedo a cada evento (é barato); só o snap espera. */
      var _tl = performance.now();
      if (_tl - _lupaSnapT >= 60) { _lupaSnapT = _tl; lupaAtualizarSnap(); }
      e.preventDefault();                          // não deixa virar rolagem da página
      return true;                                 // avisa o handler: este movimento é MIRA, não órbita
    }
    /* ainda esperando o tempo do toque-e-segure: mexeu muito = quis orbitar */
    if (lupa.timer && medir.down) {
      var dx = e.clientX - medir.down.x, dy = e.clientY - medir.down.y;
      if (dx * dx + dy * dy > 144) lupaCancelarEspera();   // >12px
    }
    return false;
  };
  /* Devolve o ponto mirado (e fecha a lupa), ou null se a lupa não estava
     aberta. Quem chama decide o que fazer com o ponto. */
  S._lupaSoltar = function (e) {
    lupaCancelarEspera();
    if (!lupa.on) return null;
    if (lupa.id != null && e && e.pointerId !== lupa.id) return null;
    var alvo = { x: lupa.x, y: lupa.y, sn: lupa.sn };
    lupaFechar(true);   // o fluxo da medição escreve a próxima dica
    return alvo;
  };
  // cache de arestas por geometria (espaço LOCAL); WeakMap → some junto com a geometria no GC
  var arestasCache = new WeakMap();
  function arestasDe(geo) {
    var c = arestasCache.get(geo);
    if (!c) { try { var e = new THREE.EdgesGeometry(geo, 25); c = e.attributes.position.array.slice(); e.dispose(); } catch (_) { c = new Float32Array(0); } arestasCache.set(geo, c); }
    return c;
  }
  S._arestasDe = arestasDe; // reusado pelo corte técnico (linhas pretas do desenho)

  // ============================================================
  // ⊕ CENTRO — "onde começa o tubo"
  //
  // Identificar onde COMEÇA um tubo não era possível. Numa parede o vértice
  // resolve — o canto É um vértice da malha.
  // Para o TUBO não resolvia, e não era imprecisão: o ponto que o projetista
  // quer (o eixo do tubo, no topo da ponta) SIMPLESMENTE NÃO EXISTIA na lista
  // de candidatos. A boca do tubo é um anel de arestas; havia vértice em toda
  // a volta do anel e nenhum no meio dele. Clicar "no começo do tubo" agarrava
  // um vértice qualquer da borda — a tal «mostrando em pontos que não é».
  //
  // O centro do anel não é invenção: é o baricentro de uma laçada FECHADA e
  // PLANA de arestas reais da malha. Sem laçada fechada, nenhum centro é
  // oferecido — a régua da casa vale aqui igual: não existe ponto, não
  // aparece ponto.
  //
  // Custo: calculado UMA vez por geometria e guardado no WeakMap (some junto
  // com a geometria no GC), como as arestas. Por quadro é só testar N pontos.
  // ============================================================
  var centrosCache = new WeakMap();
  var CENTRO_MIN_VERT = 6;    // 4 seria a face retangular de uma parede: isso é "meio de face", não centro
  var CENTRO_MAX = 64;        // teto de SAÍDA por geometria
  /* tetos de TRABALHO — os que de fato impedem o travamento (ver a nota grande
     em `_acharAneis`). CENTRO_MAX só limita a saída, e no pior caso a saída é
     vazia: era exatamente onde a busca ficava solta. */
  var CENTRO_MAX_ARESTAS = 12000;   // segmentos do EdgesGeometry: acima disto nem monta o grafo
  var CENTRO_MAX_NOS = 6000;       // nós distintos (100 tubos mesclados cabem; terreno nao)
  var CENTRO_MAX_VOLTA = 160;      // lados de um anel: 160 já é absurdo em modelo de obra
  var CENTRO_ORCAMENTO = 15000;    // passos totais: com estes tres, o PIOR terreno medido custa 32 ms
  function centrosDe(geo) {
    var c = centrosCache.get(geo);
    if (c) return c;
    c = [];
    try {
      var np = (geo.attributes && geo.attributes.position) ? geo.attributes.position.count : 0;
      if (np <= SNAP_MAX_VERT) c = _acharAneis(arestasDe(geo));
    } catch (_) { c = []; }
    centrosCache.set(geo, c);
    return c;
  }
  /* Valida a laçada e devolve o baricentro, ou null. É a régua que impede o
     ⊕ centro de virar chute: sem ela, QUALQUER ciclo fechado do modelo viraria
     um "centro" — inclusive a laçada torta que passa pelas duas bocas do tubo.
     Plana (4 mm), com raio de verdade, e com nós suficientes para ser boca e
     não face de parede. Devolve {x,y,z} puro: quem chama embrulha no Vector3. */
  function _aneiCentro(nos, laco) {
    if (!laco || laco.length < CENTRO_MIN_VERT) return null;
    var cx = 0, cy = 0, cz = 0, j;
    for (j = 0; j < laco.length; j++) { var pj = nos[laco[j]]; cx += pj.x; cy += pj.y; cz += pj.z; }
    cx /= laco.length; cy /= laco.length; cz /= laco.length;
    var p0 = nos[laco[0]], p1 = nos[laco[Math.floor(laco.length / 3)]], p2 = nos[laco[Math.floor(2 * laco.length / 3)]];
    var ax = p1.x - p0.x, ay = p1.y - p0.y, az = p1.z - p0.z;
    var bx = p2.x - p0.x, by = p2.y - p0.y, bz = p2.z - p0.z;
    var nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
    var mn = Math.sqrt(nx * nx + ny * ny + nz * nz);
    if (!mn) return null;
    nx /= mn; ny /= mn; nz /= mn;
    var raioMed = 0, raios = [];
    for (j = 0; j < laco.length; j++) {
      var q = nos[laco[j]];
      if (Math.abs((q.x - cx) * nx + (q.y - cy) * ny + (q.z - cz) * nz) > 0.004) return null;  // 4 mm de planeza
      var r = Math.sqrt((q.x - cx) * (q.x - cx) + (q.y - cy) * (q.y - cy) + (q.z - cz) * (q.z - cz));
      raios.push(r); raioMed += r;
    }
    raioMed /= laco.length;
    if (raioMed < 0.002) return null;   // anel degenerado (todos os pontos no mesmo lugar)
    /* ⚠ TEM DE SER REDONDO, não só fechado e plano.
     *
     * O contorno da face de uma laje em L (ou em U) também é uma laçada fechada,
     * plana e com 6+ vértices — e o baricentro dela cai NO VAZIO, fora da laje.
     * O snap ofereceria, com peso alto, um ponto que não existe em lugar nenhum
     * do modelo. É exatamente a invenção de ponto que a casa não faz, e seria
     * pior do que o defeito que este recurso veio consertar: ali o ponto estava
     * na borda errada, aqui estaria no ar.
     *
     * Num círculo todo vértice fica à MESMA distância do centro. Num L, não.
     * 25% de variação aceita polígono regular, tubo achatado e furo oval leve;
     * recusa contorno de laje, que varia muito mais. */
    var desvio = 0;
    for (j = 0; j < raios.length; j++) desvio = Math.max(desvio, Math.abs(raios[j] - raioMed));
    if (desvio / raioMed > 0.25) return null;
    return { x: cx, y: cy, z: cz };
  }
  /* Uma tentativa de laçada: sai de `ini` pelo vizinho `primeiro` e segue
     sempre o vizinho que MELHOR CONTINUA a direção atual (a longitudinal de um
     tubo sai a ~90° e nunca é a melhor continuação). Devolve a lista de nós se
     fechou, ou null. */
  function _andarLaco(nos, ini, primeiro, vistos, orc) {
    var laco = [ini, primeiro], noLaco = {}, ant = ini, atual = primeiro, fechou = false, k;
    if (vistos[primeiro]) return null;
    noLaco[ini] = 1; noLaco[primeiro] = 1;
    /* ⚠ CENTRO_MAX_VOLTA, não 512. Uma boca de tubo tem dezenas de lados; um anel
       de 128 lados já é absurdo em modelo de obra. O teto alto só servia para
       gastar trabalho antes de desistir numa malha que não tem anel nenhum. */
    for (k = 0; k < CENTRO_MAX_VOLTA; k++) {
      if (orc && --orc.passos < 0) return null;   // orçamento estourado: desiste sem travar
      var n = nos[atual], prox = null, melhorCos = -2;
      for (var vi = 0; vi < n.viz.length; vi++) {
        var cand = n.viz[vi];
        if (cand === ant) continue;
        if (cand === ini && laco.length >= CENTRO_MIN_VERT) { fechou = true; break; }
        /* ⚠ MAPA, não `laco.indexOf`. O indexOf é O(k) DENTRO do passo, e com ele
           uma caminhada de k passos custa k². Num terreno era o segundo fator do
           travamento de dezenas de segundos. */
        if (vistos[cand] || noLaco[cand]) continue;
        var a = nos[ant], b = n, cc = nos[cand];
        var u1 = b.x - a.x, u2 = b.y - a.y, u3 = b.z - a.z;
        var v1 = cc.x - b.x, v2 = cc.y - b.y, v3 = cc.z - b.z;
        var mu = Math.sqrt(u1 * u1 + u2 * u2 + u3 * u3), mv = Math.sqrt(v1 * v1 + v2 * v2 + v3 * v3);
        var cos = (mu && mv) ? (u1 * v1 + u2 * v2 + u3 * v3) / (mu * mv) : -2;
        if (cos > melhorCos) { melhorCos = cos; prox = cand; }
      }
      if (fechou) return laco;
      if (!prox) return null;
      laco.push(prox); noLaco[prox] = 1; ant = atual; atual = prox;
    }
    return null;
  }
  /* Recebe o array plano de arestas (x1,y1,z1,x2,y2,z2, ...) em espaço LOCAL e
     devolve os baricentros das laçadas fechadas e planas. */
  function _acharAneis(arr) {
    if (!arr || arr.length < CENTRO_MIN_VERT * 6) return [];
    /* ⚠⚠ O TETO QUE FALTAVA, E QUE QUASE FOI PUBLICADO SEM.
     *
     * Esta busca roda DENTRO do hover do snap, síncrona. Quando a malha não tem
     * anel nenhum, nenhum nó entra em `vistos`, o laço externo tenta TODOS os
     * nós, cada um com todos os vizinhos como primeira saída — e o custo cresce
     * ~quadrático. Medido no fonte de produção contra um terreno triangulado:
     *
     *     441 vértices →  0,3 s        3.721 vértices → 24 s
     *   1.681 vértices →  3,7 s        6.561 vértices → 59 s
     *
     * Isso é a ABA INTEIRA travada — o OrçaPRO é uma página só: Gestão,
     * Orçamento e Financeiro param junto, sem barra e sem Esc.
     *
     * ⚠ E `SNAP_MAX_VERT` (90.000) NÃO PROTEGE: ele conta VÉRTICES da malha, e o
     *   custo daqui é o número de ARESTAS que sobram do EdgesGeometry num grafo
     *   CONECTADO. O travamento começa 200× abaixo daquele limite. Guarda que
     *   mede a grandeza errada é guarda que não existe.
     *
     * Os anéis que interessam são PEQUENOS e LOCAIS: uma boca de tubo tem
     * dezenas de nós, um flange com furos tem centenas. Terreno, telhado
     * facetado e família de alto poli não têm boca redonda nenhuma — desistir
     * neles não perde recurso, e é o que estes tetos fazem, barato e cedo. */
    if (arr.length / 6 > CENTRO_MAX_ARESTAS) return [];
    var nos = {}, ordem = [], i, k;
    function chave(x, y, z) { return (Math.round(x * 1e4) / 1e4) + '|' + (Math.round(y * 1e4) / 1e4) + '|' + (Math.round(z * 1e4) / 1e4); }
    function no(x, y, z) {
      var ch = chave(x, y, z);
      if (!nos[ch]) { nos[ch] = { x: x, y: y, z: z, viz: [] }; ordem.push(ch); }
      return ch;
    }
    for (i = 0; i + 5 < arr.length; i += 6) {
      var ca = no(arr[i], arr[i + 1], arr[i + 2]), cb = no(arr[i + 3], arr[i + 4], arr[i + 5]);
      if (ca === cb) continue;
      if (nos[ca].viz.indexOf(cb) < 0) nos[ca].viz.push(cb);
      if (nos[cb].viz.indexOf(ca) < 0) nos[cb].viz.push(ca);
    }
    /* ⚠ SEGUIR A CURVA, não só "grau 2". Num tubo bem facetado o EdgesGeometry
       descarta as arestas longitudinais (ângulo < 25°) e cada vértice do anel
       fica com grau 2 — fácil. Num tubo GROSSEIRO (12 lados, 30° entre faces)
       as longitudinais entram e o mesmo vértice vira grau 3. Exigir grau 2
       faria o centro funcionar no tubo fino e sumir no grosso, que é o pior
       dos mundos: o recurso existe mas o usuário não confia nele. Por isso a
       caminhada escolhe o vizinho que MELHOR CONTINUA a direção atual — a
       longitudinal sai a ~90° e nunca é a melhor continuação. */
    /* ⚠ O PRIMEIRO PASSO NÃO PODE SER ARBITRÁRIO — e era, e isso REPROVOU na
       geometria de verdade depois de passar no teste de bancada. Num tubo de
       12 lados o vértice do anel tem TRÊS vizinhos: os dois do anel e a
       longitudinal que desce. Como no primeiro passo ainda não há direção
       anterior para comparar, a escolha caía no primeiro da lista — se fosse a
       longitudinal, a caminhada descia para a outra boca e nunca fechava. O
       tubo de 16 e 32 lados funcionava (lá a longitudinal nem entra no
       EdgesGeometry), o de 8 e 12 não: o recurso "às vezes". Agora cada
       vizinho é TENTADO como primeiro passo, e vale o que fechar. */
    if (ordem.length > CENTRO_MAX_NOS) return [];
    var vistos = {}, saida = [], orc = { passos: CENTRO_ORCAMENTO };
    for (var oi = 0; oi < ordem.length && saida.length < CENTRO_MAX; oi++) {
      if (orc.passos < 0) break;              // orçamento estourado: entrega o que achou
      var ini = ordem[oi];
      if (vistos[ini] || nos[ini].viz.length < 2) continue;
      /* ⚠ E NÃO BASTA "a primeira que fechar". Saindo pela longitudinal, a
         caminhada desce até a outra boca, dá a volta e VOLTA — fecha uma
         laçada de 14 nós que passa pelos dois anéis. Ela é fechada e é
         inválida (não é plana), e aceitá-la fazia o nó inteiro ser descartado
         com um `continue`, sem nunca tentar as outras saídas: o tubo de 8 e 12
         lados ficava sem centro. Vale a MAIS CURTA que passa na validação — o
         anel é sempre o ciclo mais apertado que sai do vértice. */
      var laco = null;
      for (var si = 0; si < nos[ini].viz.length; si++) {
        var tent = _andarLaco(nos, ini, nos[ini].viz[si], vistos, orc);
        if (!tent || !_aneiCentro(nos, tent)) continue;
        if (!laco || tent.length < laco.length) laco = tent;
      }
      /* ⚠ NÓ QUE FALHOU NÃO SE TENTA DE NOVO — e este era o fator quadrático.
         Se NENHUMA saída de `ini` fecha um anel válido, `ini` não está em anel
         que esta caminhada ache; marcá-lo custa uma entrada e poupa tentar de
         novo a partir de cada vizinho depois. Antes, `vistos` só era preenchido
         em caso de SUCESSO — ou seja, na malha sem anel nenhum (o pior caso)
         ele ficava vazio e todo nó era tentado do zero. */
      if (!laco) { vistos[ini] = 1; continue; }
      var ctr = _aneiCentro(nos, laco);
      if (!ctr) continue;
      for (var j = 0; j < laco.length; j++) vistos[laco[j]] = 1;
      saida.push(new THREE.Vector3(ctr.x, ctr.y, ctr.z));
    }
    return saida;
  }
  S._acharAneis = _acharAneis;   // hook de teste: a laçada é a parte que erra sozinha
  // scratches DISTINTOS: _snP é EXCLUSIVO do px() (project() muta in-place) — nunca pode ser o mesmo
  // vetor que carrega um candidato (senão o ponto snapado sai em NDC, não em metros). _snM/_snCl
  // são reusados nos loops (o candidato aceito é clonado dentro de testar()).
  var _snA = new THREE.Vector3(), _snB = new THREE.Vector3(), _snM = new THREE.Vector3(), _snCl = new THREE.Vector3(), _snP = new THREE.Vector3(), _snCt = new THREE.Vector3(), _snL = new THREE.Line3();
  var SNAP_MAX_VERT = 90000; // malha densa (terreno/mobiliário) trava o hover ao gerar EdgesGeometry -> pula snap
  // PESOS de desempate (achado do usuário: prioridade ABSOLUTA fazia um vértice a 13px "roubar"
  // de uma aresta a 2px do cursor — o snap agarrava LONGE de onde se clicava). Agora ganha o
  // candidato mais PRÓXIMO em distância efetiva; o peso só desempata tipos ~equidistantes.
  var SNAP_PESO = { intersecao: 1.5, centro: 1.4, vertice: 1.35, meio: 1.15, aresta: 1.0 };
  /* ⚠ O TETO DO DESEMPATE — e é MENOR do que parece, então segue a conta.
   *
   * O peso é uma RAZÃO: um candidato de peso P vence quando `d/P` é o menor,
   * logo o mais que ele pode ganhar estando ATRÁS é `raio - raio/P`.
   *   mouse (raio 14): vértice rouba no máximo 3,6 px · interseção 4,7 px
   *   toque (raio 30): vértice rouba até     7,8 px · interseção 10,0 px
   *
   * Ou seja: NO MOUSE o peso já se auto-limita, e esta folga praticamente não
   * dispara. A conta acima diz que ela NÃO é o conserto do lado do mouse — quem
   * resolve ali são os outros três: o ⊕ centro que não existia, os 3 objetos do
   * raio e o aviso de peça pesada. Fica registrado para ninguém "consertar"
   * de novo por aqui.
   *
   * NO TOQUE ela vale: 10 px de roubo com o dedo é exatamente «mostrando em
   * pontos que não é», e a folga corta isso para 7,5 px. O conserto de fato do
   * toque, porém, é a lupa — ver antes de soltar. */
  function snapFolga(raio) { return Math.max(6, raio * 0.25); }
  // pontos mais próximos entre dois segmentos 3D (Ericson) — devolve {d, p} (p = ponto médio do par)
  function segSeg3D(a1, a2, b1, b2) {
    var d1x = a2.x - a1.x, d1y = a2.y - a1.y, d1z = a2.z - a1.z;
    var d2x = b2.x - b1.x, d2y = b2.y - b1.y, d2z = b2.z - b1.z;
    var rx = a1.x - b1.x, ry = a1.y - b1.y, rz = a1.z - b1.z;
    var A = d1x * d1x + d1y * d1y + d1z * d1z, E = d2x * d2x + d2y * d2y + d2z * d2z;
    var F = d2x * rx + d2y * ry + d2z * rz, s, t;
    if (A <= 1e-12 && E <= 1e-12) { s = 0; t = 0; }
    else if (A <= 1e-12) { s = 0; t = Math.max(0, Math.min(1, F / E)); }
    else {
      var C = d1x * rx + d1y * ry + d1z * rz;
      if (E <= 1e-12) { t = 0; s = Math.max(0, Math.min(1, -C / A)); }
      else {
        var B = d1x * d2x + d1y * d2y + d1z * d2z, den = A * E - B * B;
        s = den > 1e-12 ? Math.max(0, Math.min(1, (B * F - C * E) / den)) : 0;
        t = Math.max(0, Math.min(1, (B * s + F) / E));
        s = Math.max(0, Math.min(1, (B * t - C) / A));
      }
    }
    var px1 = a1.x + d1x * s, py1 = a1.y + d1y * s, pz1 = a1.z + d1z * s;
    var qx1 = b1.x + d2x * t, qy1 = b1.y + d2y * t, qz1 = b1.z + d2z * t;
    var dd = Math.sqrt((px1 - qx1) * (px1 - qx1) + (py1 - qy1) * (py1 - qy1) + (pz1 - qz1) * (pz1 - qz1));
    return { d: dd, p: new THREE.Vector3((px1 + qx1) / 2, (py1 + qy1) / 2, (pz1 + qz1) / 2) };
  }
  /* ⚠ DUAS JANELAS — o conserto da queixa de 30/09/2026 ("ainda está difícil
   * encontrar aresta e pontos de forma fluida, sempre fico com dúvida de onde
   * estou pegando").
   *
   * O canto (e o meio, e o cruzamento) fica EM CIMA das arestas que chegam
   * nele. A distância do cursor até a aresta é, portanto, SEMPRE menor ou
   * igual à distância até o canto — e o peso de 1,35 só fazia o canto ganhar
   * com d_canto ≤ 1,35 × d_aresta. Chegando num canto em 45° isso NUNCA
   * acontece. Medido na bancada (exemplo.ifc, 6 vistas): a 8 px de um canto
   * visível, com o cursor em cima da própria peça, o snap pegou o canto 1 vez
   * em 176 — a aresta levou 125.
   *
   * A regra dos programas de CAD: PONTO primeiro, numa janela menor; ARESTA só
   * quando não há ponto na janela. A janela de ponto (70 % do raio) dá 10 px no
   * mouse e 21 px no dedo — abaixo dos 27 px do relato de 27/08 («um vértice a
   * 27 px levando o clique de uma aresta a 20 px»), que continua impossível. */
  function snapRaioPonto(raio) { return Math.round(raio * 0.7); }
  var SNAP_PONTOS = { vertice: 1, meio: 1, intersecao: 1, centro: 1 };
  var _snRc = new THREE.Raycaster(), _snRc2 = new THREE.Raycaster(), _snNdc = new THREE.Vector2(), _snRay = new THREE.Ray(), _snNaRay = new THREE.Vector3();
  /* ⚠ PONTO ESCONDIDO NÃO VALE. Com as peças vizinhas do cursor entrando na
     varredura (a coroa, em `mirarEm`) e as de TRÁS do raio também (o canto
     parede×viga×laje), um canto que não está à vista pode cair a poucos pixels
     do cursor — e a trena mediria até um ponto que a pessoa nem está vendo.
     O raio da câmera até o candidato não pode bater em superfície visível
     ANTES dele. Testa só contra as peças varridas: quem tampa um ponto a
     poucos pixels do cursor é uma delas, e o modelo inteiro a cada movimento
     do mouse pesaria. `setFromCamera` serve à perspectiva e à ortográfica. */
  function snapVisivel(p, objs) {
    if (!objs.length) return true;
    /* ⚠ A CAMADA DO RAIO DO CLIQUE. Com a agregação ligada as peças moram na
       camada 1 (a tela desenha a malha mesclada, camada 0) e o raio do clique
       só olha a 1. Um Raycaster novo nasce na camada 0: não via peça nenhuma e
       aprovava TODO ponto como visível — medido: desligar esta checagem não
       mudava nada, e era por isso. */
    _snRc2.layers.mask = ray.layers.mask;
    var q = _snP.copy(p).project(camera);
    _snRc2.setFromCamera(_snNdc.set(q.x, q.y), camera);
    var L = _snRc2.ray.origin.distanceTo(p), tol = Math.max(0.01, L * 0.002);
    _snRc2.far = L + tol;
    var hs = _snRc2.intersectObjects(objs, false);
    for (var i = 0; i < hs.length; i++) {
      if (!cadeiaVisivel(hs[i].object) || foraDoClip(hs[i].point)) continue;
      return hs[i].distance >= L - tol;
    }
    return true;
  }
  function aplicarSnap(hit, raioPx, cursor, extras) {
    if (!snap.on || (!hit && !cursor)) return hit ? { p: hit.point, tipo: null } : null;
    if (hit && (!hit.object || !hit.object.geometry)) return { p: hit.point, tipo: null };
    var raio = raioPx || snap.raio, raioP = snapRaioPonto(raio), rc = canvasEl.getBoundingClientRect();
    function px(v) { var q = _snP.copy(v).project(camera); return { x: (q.x + 1) / 2 * rc.width, y: (1 - q.y) / 2 * rc.height }; }
    /* o alvo é o CURSOR quando ele é conhecido: com o cursor fora da peça não
       há ponto 3D debaixo dele, e a aresta é medida contra o raio da câmera que
       passa por ali (não contra o ponto do hit, que pode ser de outra peça) */
    var alvoPx = cursor ? { x: cursor.x - rc.left, y: cursor.y - rc.top } : px(hit.point);
    _snRc.setFromCamera(_snNdc.set(alvoPx.x / rc.width * 2 - 1, -(alvoPx.y / rc.height) * 2 + 1), camera);
    _snRay.copy(_snRc.ray);
    var pontos = [], arestas = [], notaveis = [], varridos = [];
    function testar(v, tipo, obj, a, b) {
      var p2 = px(v), dx = p2.x - alvoPx.x, dy = p2.y - alvoPx.y, d = Math.sqrt(dx * dx + dy * dy);
      var ehPonto = !!SNAP_PONTOS[tipo];
      if (d > raio) return;
      if (foraDoClip(v)) return; // vértice/aresta do lado CLIPADO (invisível) do corte NÃO pode ser snapado -> cota errada
      /* pontos notáveis à vista, para os traços finos do item 6 — só canto,
         começo, meio e centro; aresta é linha inteira, não é um "ponto". Eles
         continuam aparecendo no raio CHEIO: mostram o que existe por perto,
         mesmo o que ainda não está na janela de agarrar. */
      if (ehPonto && notaveis.length < 24) notaveis.push({ v: v.clone(), tipo: tipo, d: d });
      if (ehPonto && d > raioP) return;
      var c = { p: v.clone(), tipo: tipo, d: d, dEff: d / (SNAP_PESO[tipo] || 1), obj: obj, a: a ? a.clone() : null, b: b ? b.clone() : null };
      if (ehPonto) pontos.push(c); else arestas.push(c);
    }
    // arestas PRÓXIMAS do cursor (candidatas ao ✚ interseção) — dos objetos varridos
    var proximas = [], pulouPesado = false;
    function varrerObjeto(obj) {
      if (!obj || !obj.geometry || varridos.indexOf(obj) > -1) return;
      var g = obj.geometry, np = (g.attributes && g.attributes.position) ? g.attributes.position.count : 0;
      /* ⚠ elemento pesado: sem snap nesse objeto — e ANTES isso era um silêncio.
         O marcador simplesmente não aparecia, e quem estava medindo concluía que
         o snap "não pega direito" nesse pedaço do modelo. Falhar calado é o que
         transforma um limite técnico legítimo em queixa de imprecisão. Agora a
         marca diz por quê; inventar um ponto que não existe continua fora. */
      if (np > SNAP_MAX_VERT) { if (hit && obj === hit.object) pulouPesado = true; return; }   /* ⚠ só o objeto ATINGIDO. A bandeira era única para a chamada toda: bastava o terreno estar ATRÁS da parede para o marcador dizer "sem snap" em cima de uma parede que tinha snap perfeito */
      varridos.push(obj);
      var arr = arestasDe(g); if (!arr.length) return;
      var mw = obj.matrixWorld;
      if (snap.c !== false) {
        var ctr = centrosDe(g);
        for (var ci = 0; ci < ctr.length; ci++) testar(_snCt.copy(ctr[ci]).applyMatrix4(mw), 'centro', obj);
      }
      for (var i = 0; i < arr.length; i += 6) {
        _snA.set(arr[i], arr[i + 1], arr[i + 2]).applyMatrix4(mw);
        _snB.set(arr[i + 3], arr[i + 4], arr[i + 5]).applyMatrix4(mw);
        if (snap.v) { testar(_snA, 'vertice', obj); testar(_snB, 'vertice', obj); }
        if (snap.m) { testar(_snM.addVectors(_snA, _snB).multiplyScalar(0.5), 'meio', obj, _snA, _snB); }
        /* o ponto da aresta mais perto do RAIO do cursor (não do ponto 3D do
           hit): é o que se projeta embaixo do cursor, com ou sem peça ali */
        _snRay.distanceSqToSegment(_snA, _snB, _snNaRay, _snCl);
        if (snap.a) testar(_snCl, 'aresta', obj, _snA, _snB);
        if (snap.i !== false && proximas.length < 14) {
          var pc = px(_snCl), ddx = pc.x - alvoPx.x, ddy = pc.y - alvoPx.y;
          if (ddx * ddx + ddy * ddy <= (raio + 6) * (raio + 6)) proximas.push({ a: _snA.clone(), b: _snB.clone(), obj: obj });
        }
      }
    }
    if (hit) varrerObjeto(hit.object);
    // demais objetos do raio: o canto parede×viga vive na FRONTEIRA entre elementos
    for (var oh = 1; oh < _ultimosHits.length; oh++) if (!hit || _ultimosHits[oh].object !== hit.object) varrerObjeto(_ultimosHits[oh].object);
    // e as peças vizinhas que a coroa trouxe (cursor na borda ou fora da peça)
    if (extras) { var ate = performance.now() + SNAP_ORCAMENTO_MS; for (var ex = 0; ex < extras.length; ex++) { if (ex >= SNAP_MIN_PECAS && performance.now() > ate) break; varrerObjeto(extras[ex]); } }
    // ✚ INTERSEÇÃO REAL: pares de arestas próximas cujos pontos-mais-próximos em 3D distam < 1 cm
    // (cruzamento genuíno no espaço, não coincidência visual de projeção — nunca inventa ponto)
    if (snap.i !== false) {
      for (var ii = 0; ii < proximas.length; ii++) for (var jj = ii + 1; jj < proximas.length; jj++) {
        var r3 = segSeg3D(proximas[ii].a, proximas[ii].b, proximas[jj].a, proximas[jj].b);
        if (r3.d < 0.01) testar(r3.p, 'intersecao', proximas[ii].obj);
      }
    }
    /* PONTOS: ganha o de menor distância efetiva. A FOLGA continua valendo
       ENTRE tipos de ponto: um centro a 9 px não leva o clique de um canto a
       2 px — era exatamente o "ponto que não é". */
    var melhor = null, maisPerto = null, k;
    for (k = 0; k < pontos.length; k++) {
      if (!melhor || pontos[k].dEff < melhor.dEff) melhor = pontos[k];
      if (!maisPerto || pontos[k].d < maisPerto.d) maisPerto = pontos[k];
    }
    if (melhor && maisPerto && melhor.tipo !== maisPerto.tipo && melhor.d > maisPerto.d + snapFolga(raioP)) melhor = maisPerto;
    /* fila: o ponto escolhido, os outros pontos por distância efetiva, e só
       então as arestas por distância — o primeiro que estiver À VISTA vence */
    /* ⚠ UM CANDIDATO POR LUGAR. O mesmo canto chega uma vez por aresta que
       encosta nele (3 a 6 vezes), e cada cópia custava uma checagem de
       visibilidade. Num trecho com peças atrás, as cópias de cantos
       ESCONDIDOS esgotavam as checagens antes de a fila chegar à aresta
       visível — a bancada contou 53 "nada" onde havia aresta à vista. */
    function semRepetir(lista, chaveD) {
      var visto = {}, out = [];
      for (var i = 0; i < lista.length; i++) {
        var c = lista[i], kk = Math.round(c.p.x * 1000) + ',' + Math.round(c.p.y * 1000) + ',' + Math.round(c.p.z * 1000);
        var ja = visto[kk];
        if (ja === undefined) { visto[kk] = out.length; out.push(c); } else if (c[chaveD] < out[ja][chaveD]) out[ja] = c;
      }
      return out;
    }
    pontos = semRepetir(pontos, 'dEff'); arestas = semRepetir(arestas, 'd');
    var fila = [];
    if (melhor) fila.push(melhor);
    pontos.sort(function (a, b) { return a.dEff - b.dEff; });
    for (k = 0; k < pontos.length; k++) if (pontos[k].p.distanceToSquared(melhor.p) > 1e-12 || pontos[k].tipo !== melhor.tipo) fila.push(pontos[k]);
    arestas.sort(function (a, b) { return a.d - b.d; });
    for (k = 0; k < arestas.length; k++) fila.push(arestas[k]);
    /* as checagens de visibilidade vão até achar um visível — com teto de
       TEMPO (não de contagem) depois das 40 primeiras */
    var venc = null, ateVis = performance.now() + SNAP_ORCAMENTO_MS;
    for (k = 0; k < fila.length; k++) {
      if (k >= SNAP_MIN_CHECAGENS && performance.now() > ateVis) break;
      if (snapVisivel(fila[k].p, varridos)) { venc = fila[k]; break; }
    }
    return venc
      ? { p: venc.p, tipo: venc.tipo, notaveis: notaveis, pesado: pulouPesado, obj: venc.obj || null, seg: (venc.a && venc.b) ? [venc.a, venc.b] : null }
      : { p: hit ? hit.point : null, tipo: null, notaveis: notaveis, pesado: pulouPesado, obj: hit ? hit.object : null, seg: null };
  }
  /* ⚠ AS PEÇAS PERTO DO CURSOR SE ACHAM PELA CAIXA NA TELA, NÃO POR RAIOS.
     O snap só varria as peças que o raio do cursor ATRAVESSA. Com o cursor na
     borda ou fora da peça, o canto dela nem existia como candidato — bancada
     com gabarito (exemplo.ifc, 6 vistas, 30/09/2026): de 556 pontos visíveis
     na janela, 158 saíam como "nada".
     A primeira tentativa foi uma coroa de 8 raios à volta do cursor e não
     resolveu NENHUM dos 158: o canto que escapa é o da ponta de uma LASCA
     fina — parede de 15 cm, laje ou viga vista de lado —, com 1 a 3 px de
     largura na tela, e nem 48 raios em volta a acertavam. A caixa da peça
     projetada na tela não tem fresta: se ela encosta na janela do cursor, a
     peça entra, e `snapVisivel` descarta o ponto que estiver escondido.
     As caixas são projetadas numa passada pelo modelo e só de novo quando a
     câmera, o tamanho da tela ou os modelos mudam — mirando, a câmera está
     parada. Visibilidade (ocultar/isolar) é conferida na hora do uso. */
  /* ⚠ SEM TETO DE CONTAGEM, COM TETO DE TEMPO. Com teto de 60 peças, 7 dos
     107 pontos da bancada do modelo real (6.733 peças, 1.099 barras de
     armadura) ficavam de fora — num trecho denso, mais de 300 caixas encostam
     no cursor. Sem teto nenhum o acerto foi 100 %, mas a PRIMEIRA passada
     calculava as arestas de milhares de peças de uma vez: 543 ms de tela
     parada. O orçamento espalha esse cálculo (que fica em cache) pelos
     movimentos seguintes, das peças mais próximas da câmera para trás. */
  var PERTO_MAX = 5000, SNAP_ORCAMENTO_MS = 12;
  /* ⚠ E UM MÍNIMO GARANTIDO, que o orçamento de tempo não corta. Só com o
     teto de tempo, a trena ficava PIOR com o computador ocupado: medido em
     30/09/2026 com outros programas pesando na máquina, o acerto de longe caiu
     de 95,7 % para menos de 90 % — cabiam menos checagens nos mesmos 12 ms.
     Com o mínimo, o resultado não depende da carga até esse ponto, e o custo
     no pior caso fica em ~20 ms por movimento (o hover é estrangulado em 60). */
  var SNAP_MIN_PECAS = 60, SNAP_MIN_CHECAGENS = 150;
  var _caixasTela = { chave: '', lista: [] }, _cxV = new THREE.Vector3(), _cxB = new THREE.Box3();
  function chaveDaCena() {
    var rc = canvasEl.getBoundingClientRect();
    camera.updateMatrixWorld();
    var ids = []; for (var ci = 0; ci < modelRoot.children.length; ci++) ids.push(modelRoot.children[ci].id);
    return camera.matrixWorld.elements.join(',') + '|' + camera.projectionMatrix.elements.join(',') + '|' + Math.round(rc.width) + 'x' + Math.round(rc.height) + '|' + ids.join(',');
  }
  function caixasNaTela() {
    var rc = canvasEl.getBoundingClientRect();
    var chave = chaveDaCena();
    if (_caixasTela.chave === chave) return _caixasTela.lista;
    var lista = [];
    modelRoot.updateMatrixWorld(true);
    modelRoot.traverse(function (o) {
      if (!o.isMesh || !o.geometry) return;
      var g = o.geometry; if (!g.boundingBox) g.computeBoundingBox();
      if (!g.boundingBox) return;
      _cxB.copy(g.boundingBox).applyMatrix4(o.matrixWorld);
      var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, atras = false;
      for (var i = 0; i < 8; i++) {
        _cxV.set(i & 1 ? _cxB.max.x : _cxB.min.x, i & 2 ? _cxB.max.y : _cxB.min.y, i & 4 ? _cxB.max.z : _cxB.min.z).project(camera);
        /* canto atrás da câmera (andando dentro do modelo): a projeção dele
           não vale — a peça entra sempre, pelo lado seguro */
        if (_cxV.z > 1 || _cxV.z < -1) atras = true;
        var sx = (_cxV.x + 1) / 2 * rc.width, sy = (1 - _cxV.y) / 2 * rc.height;
        if (sx < x0) x0 = sx; if (sx > x1) x1 = sx; if (sy < y0) y0 = sy; if (sy > y1) y1 = sy;
      }
      lista.push({ o: o, x0: x0, y0: y0, x1: x1, y1: y1, atras: atras, perto: _cxB.distanceToPoint(camera.position) });
    });
    _caixasTela = { chave: chave, lista: lista };
    return lista;
  }
  function pecasPerto(cx, cy, raio) {
    var rc = canvasEl.getBoundingClientRect(), x = cx - rc.left, y = cy - rc.top, L = caixasNaTela(), sel = [];
    for (var i = 0; i < L.length; i++) {
      var c = L[i];
      if (!c.atras && (x + raio < c.x0 || x - raio > c.x1 || y + raio < c.y0 || y - raio > c.y1)) continue;
      if (!cadeiaVisivel(c.o)) continue;
      sel.push(c);
    }
    sel.sort(function (a, b) { return a.perto - b.perto; });
    var out = [];
    for (var k = 0; k < sel.length && k < PERTO_MAX; k++) out.push(sel[k].o);
    return out;
  }
  /* o cálculo que o MARCADOR mostra e que o CLIQUE grava — um só, para os
     dois nunca discordarem. Devolve null quando não há nada: nem peça sob o
     cursor, nem ponto ou aresta visível na janela. */
  function mirarEm(cx, cy, raioPx) {
    var hit = raycastEm(cx, cy), raio = raioPx || snap.raio;
    var sn = aplicarSnap(hit, raio, { x: cx, y: cy }, snap.on ? pecasPerto(cx, cy, raio) : null);
    if (!sn || (!sn.tipo && !hit && !sn.pesado)) sn = null;
    _ultimaMira = { x: cx, y: cy, raio: raio, chave: chaveDaCena(), sn: sn };
    return sn;
  }
  /* ⚠ O CLIQUE GRAVA O QUE O MARCADOR MOSTROU. O cálculo trabalha com
     orçamento de tempo, e o cache de arestas esquenta entre um movimento e
     outro: o mesmo pixel podia dar "superfície" no marcador e "aresta" no
     clique — visto na e2e com a máquina ocupada, e é exatamente a queixa
     ("fico com dúvida de onde estou pegando"). Com o cursor parado (até 2 px)
     e a câmera igual, o clique usa a mira que já está na tela. */
  var _ultimaMira = null;
  function mirarParaClique(cx, cy, raioPx) {
    var m = _ultimaMira, raio = raioPx || snap.raio;
    /* e a peça da mira ainda à vista, e o ponto fora do corte: ocultar ou
       cortar sem mexer o mouse não pode deixar o clique gravar o que sumiu */
    if (m && m.raio === raio && Math.abs(m.x - cx) <= 2 && Math.abs(m.y - cy) <= 2 && m.chave === chaveDaCena() &&
        (!m.sn || ((!m.sn.obj || cadeiaVisivel(m.sn.obj)) && !(m.sn.p && foraDoClip(m.sn.p))))) return m.sn;
    return mirarEm(cx, cy, raio);
  }
  S._snapLimites = function (ms, pecas, checagens) { var ant = [SNAP_ORCAMENTO_MS, SNAP_MIN_PECAS, SNAP_MIN_CHECAGENS]; if (ms != null) { SNAP_ORCAMENTO_MS = ms; SNAP_MIN_PECAS = pecas; SNAP_MIN_CHECAGENS = checagens; } return ant; };   // hook de teste
  S._ultimaMiraXY = function () { return _ultimaMira ? [_ultimaMira.x, _ultimaMira.y] : null; };   // hook de teste
  S._marcaAtual = function () { return snapVivo ? { p: [snapVivo.p.x, snapVivo.p.y, snapVivo.p.z], tipo: snapVivo.tipo } : null; };   // hook de teste
  S._mirarEm = mirarEm; S._centrosDe = centrosDe; S._pecasPerto = pecasPerto; S._destaqueSnap = destaqueSnap; S._raioCamadas = function () { return ray.layers.mask; }; // hooks de teste
  function raioToque(e) { return (e && e.pointerType === 'touch') ? 30 : snap.raio; } // dedo tem ~mais incerteza

  // ============================================================
  // 📝 CORTE TÉCNICO — o usuário risca a linha A–A' NA PLANTA e o viewer gera a
  // vista de corte em preto-e-branco estilo desenho técnico, NA ESCALA escolhida
  // (px/m derivado de 96dpi), com carimbo e escala gráfica. Câmera ortográfica
  // perpendicular à linha; clipping no próprio plano de corte. Faces cortadas saem
  // HACHURADAS (caps por stencil: saldo backface−frontface ≠ 0 = interior de sólido).
  // ============================================================
  var ctec = { ativo: false, pts: [], objs: [] };
  S._tickExtra.push(function () { for (var i = 0; i < ctec.objs.length; i++) rescaleObj(ctec.objs[i]); });
  function ctecLimparDesenho() { ctec.objs.forEach(limparMarca); ctec.objs = []; ctec.pts = []; }
  function ctecIniciar() {
    if (!planta.on) { setPlanta(true); if (!planta.on) return; } // linha se risca NA planta
    if (S.plantaCfg) S.plantaCfg.style.display = 'none'; // config da planta técnica não pode ficar cobrindo os cliques A/B
    if (edit && edit.on) setEdit(false); // corte técnico e editor disputariam o mesmo clique
    ctecLimparDesenho(); ctec.ativo = true;
    S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('nota', 15) : '') + ' Clique o 1º ponto da linha de corte (A) sobre a planta.');
  }
  function ctecCancelar(pergunta) {
    var tinha = ctec.ativo || ctecCfg.style.display !== 'none' || ctec.objs.length;
    ctec.ativo = false; ctecLimparDesenho(); ctecCfg.style.display = 'none';
    if (tinha && !pergunta) S._hint('');
    return !!tinha;
  }
  S._ctecCancelar = ctecCancelar;
  function ctecClique(p) {
    ctec.pts.push(p);
    var m = pontoMarca(p); m.material.color.set(0x38bdf8);
    scene.add(m); ctec.objs.push(m); rescaleObj(m);
    var rot = labelSprite(ctec.pts.length === 1 ? 'A' : "A'"); rot.position.copy(p).add(new THREE.Vector3(0, 0.02, 0));
    scene.add(rot); ctec.objs.push(rot); rescaleObj(rot);
    if (ctec.pts.length === 1) { S._hint("" + (typeof Icones !== "undefined" ? Icones.get("nota", 15) : "") + " Agora clique o 2º ponto (A')."); return; }
    var line = new THREE.Line(new THREE.BufferGeometry().setFromPoints([ctec.pts[0], ctec.pts[1]]), new THREE.LineBasicMaterial({ color: 0x38bdf8, depthTest: false }));
    line.renderOrder = 997; scene.add(line); ctec.objs.push(line);
    ctec.ativo = false;
    marcarFechamento(); // duplo-clique no A' não vaza o irmão pra trena/área coexistente
    ctecCfg.style.display = 'flex'; S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('nota', 15) : '') + ' Configure o corte e clique Gerar.');
  }
  // painel de configuração do corte
  var ctecCfg = document.createElement('div');
  ctecCfg.style.cssText = 'position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:6;display:none;flex-direction:column;gap:8px;background:rgba(255,255,255,.985);border:1px solid #d3dce6;border-radius:12px;padding:14px 16px;color:#1a2b3c;font-size:12px;width:260px;box-shadow:0 12px 34px rgba(0,0,0,.5)';
  ctecCfg.innerHTML =
    '<b>' + (typeof Icones !== 'undefined' ? Icones.get('nota', 15) : '') + ' Gerar corte técnico</b>' +
    '<label style="display:flex;justify-content:space-between;align-items:center">Tipo de vista <select data-t="tipo" class="inp" style="width:130px"><option value="corte">Corte (A–A)</option><option value="fachada">Fachada/Elevação</option></select></label>' +
    '<label style="display:flex;justify-content:space-between;align-items:center">Escala <select data-t="esc" class="inp" style="width:130px"><option value="50">1:50</option><option value="75">1:75</option><option value="100" selected>1:100</option><option value="200">1:200</option></select></label>' +
    '<label style="display:flex;justify-content:space-between;align-items:center">Profundidade de visão <input data-t="prof" class="inp" type="number" min="0.5" step="0.5" value="10" style="width:70px"> m</label>' +
    '<label style="display:flex;gap:6px;align-items:center;font-size:12px"><input data-t="inv" type="checkbox"> Olhar para o outro lado</label>' +
    '<div style="font-size:11px;color:#b45309;line-height:1.35">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Auxílio visual de coordenação, não substitui o projeto executivo. Faces cortadas saem <b>hachuradas</b>; superfícies curvas/tubos podem sair sem contorno. Confira sempre pela escala gráfica.</div>' +
    '<div style="display:flex;gap:6px"><button class="btn sm primary" data-t="gerar" style="flex:1">Gerar</button><button class="btn sm" data-t="cancelar" style="flex:1">Cancelar</button></div>';
  host.appendChild(ctecCfg);
  S.ctecCfg = ctecCfg;
  // modal do resultado
  var ctecModal = document.createElement('div');
  ctecModal.style.cssText = 'position:absolute;inset:0;z-index:7;display:none;align-items:center;justify-content:center;background:rgba(4,12,22,.82)';
  ctecModal.innerHTML =
    '<div style="display:flex;flex-direction:column;gap:9px;max-width:92%;max-height:92%;background:#ffffff;border:1px solid #d3dce6;border-radius:12px;padding:13px">' +
    '<div style="display:flex;justify-content:space-between;align-items:center;color:#1a2b3c;font-size:13px"><b data-r="titulo">Corte técnico</b>' +
    '<span><button class="btn sm" data-r="ajustar" title="Mudar escala/tipo/profundidade sem redesenhar a linha">🔧 Ajustar</button> <button class="btn sm" data-r="imprimir">' + (typeof Icones !== 'undefined' ? Icones.get('imprimir', 15) : '') + ' Imprimir</button> <button class="btn sm" data-r="baixar">' + (typeof Icones !== 'undefined' ? Icones.get('baixar', 15) : '') + ' PNG</button> <button class="btn sm" data-r="fechar">' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + '</button></span></div>' +
    '<div style="overflow:auto;background:#fff;border-radius:6px;text-align:center"><img data-r="img" style="max-width:100%;display:block;margin:0 auto"></div></div>';
  host.appendChild(ctecModal);
  S.ctecModal = ctecModal;
  // série de escalas padrão de arquitetura (denominadores que existem em escalímetro)
  var SERIE_ESC = [50, 75, 100, 125, 150, 200, 250, 300, 400, 500, 750, 1000, 1250, 1500, 2000, 2500];
  function gerarCorteTec(o) {
    // o: {ax,az,bx,bz, escala, tipo:'corte'|'fachada', prof, inv} — coords do MUNDO (metros)
    var box = new THREE.Box3().setFromObject(modelRoot);
    if (box.isEmpty()) return null;
    var dx = o.bx - o.ax, dz = o.bz - o.az, L = Math.sqrt(dx * dx + dz * dz);
    if (L < 0.05) return null;
    var vx = dz / L, vz = -dx / L; if (o.inv) { vx = -vx; vz = -vz; } // direção do olhar (perpendicular à linha)
    var margem = Math.max(0.4, L * 0.03), yMin = box.min.y, yMax = box.max.y;
    var wM = L + margem * 2, hM = (yMax - yMin) + margem * 2;
    var escBase = o.escala || 100, PPM96 = 96 / 25.4;
    // cap honesto pelo que a GPU aguenta. Se a escala pedida estourar, SOBE pra próxima escala da
    // SÉRIE PADRÃO que caiba (escala inteira, medível com escalímetro) e recomputa px/m EXATO a
    // partir dela — assim o carimbo declara a MESMA escala que os pixels representam.
    var MAXPX = Math.min(4096, (renderer.capabilities && renderer.capabilities.maxTextureSize) || 4096);
    var escalaEf = escBase, pxM = PPM96 * (1000 / escalaEf);
    if (Math.max(wM, hM) * pxM > MAXPX) {
      escalaEf = null;
      for (var si = 0; si < SERIE_ESC.length; si++) { if (SERIE_ESC[si] >= escBase && Math.max(wM, hM) * (PPM96 * (1000 / SERIE_ESC[si])) <= MAXPX) { escalaEf = SERIE_ESC[si]; break; } }
      // modelo gigante (nem a maior escala da série cabe): escala contínua, arredondada PRA CIMA
      // (denominador maior -> desenho menor -> cabe garantido) e pxM recomputado EXATO dela -> carimbo==pixels
      if (escalaEf == null) { escalaEf = Math.ceil(PPM96 * 1000 / (MAXPX / Math.max(wM, hM))); pxM = PPM96 * (1000 / escalaEf); }
      else pxM = PPM96 * (1000 / escalaEf);
    }
    var ajustada = escalaEf !== escBase;
    var W = Math.round(wM * pxM), H = Math.round(hM * pxM);
    var cx = (o.ax + o.bx) / 2, cz = (o.az + o.bz) / 2, cy = (yMin + yMax) / 2;
    var diag = box.getSize(new THREE.Vector3()).length();
    var recuo = (o.tipo === 'fachada') ? diag : 0.02; // epsilon > 0 no near evita z-fighting da aresta no plano
    // plano de corte REAL (só no corte; a fachada olha de fora, não corta): além de clipar as
    // massas exatamente na linha A–A, é a referência dos passes de stencil da HACHURA
    var secPlane = (o.tipo === 'fachada') ? null : new THREE.Plane(new THREE.Vector3(vx, 0, vz), -(vx * cx + vz * cz));
    var cam = new THREE.OrthographicCamera(-wM / 2, wM / 2, hM / 2, -hM / 2, 0.01, recuo + ((o.tipo === 'fachada') ? diag * 2 : Math.max(0.5, +o.prof || 10)));
    cam.position.set(cx - vx * recuo, cy, cz - vz * recuo);
    cam.up.set(0, 1, 0); cam.lookAt(cx, cy, cz); cam.updateProjectionMatrix(); cam.updateMatrixWorld(true);
    // snapshot do estado do renderer ANTES do try — o finally SEMPRE restaura (mesmo se um passo lançar)
    var prevClip = renderer.clippingPlanes, prevLocal = renderer.localClippingEnabled;
    var prevClear = renderer.getClearColor(new THREE.Color()).clone(), prevAlpha = renderer.getClearAlpha();
    var prevTone = renderer.toneMapping, prevAuto = renderer.autoClear;
    var rt = new THREE.WebGLRenderTarget(W, H, { depthBuffer: true, stencilBuffer: true }), buf = null, edgesRoot = null, matMassa = null, matLinha = null, escondidos = [];
    var stBack = null, stFront = null, capMat = null, capGeo = null, hatchTex = null;
    try {
      renderer.clippingPlanes = secPlane ? [secPlane] : []; renderer.localClippingEnabled = false;
      renderer.toneMapping = THREE.NoToneMapping; // P&B fiel (sem ACES escurecer os cinzas)
      scene.children.forEach(function (c) { if (c !== modelRoot && c.visible !== false) { escondidos.push(c); c.visible = false; } });
      // PASSE 1 — massas cinza-claro sobre branco; polygonOffset empurra as faces no depth p/ as
      // arestas coplanares do passe 2 vencerem sem z-fighting.
      matMassa = new THREE.MeshBasicMaterial({ color: 0xededed, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1 });
      scene.overrideMaterial = matMassa;
      renderer.setRenderTarget(rt); renderer.setClearColor(0xffffff, 1); renderer.clear();
      renderer.render(scene, cam);
      scene.overrideMaterial = null;
      // PASSE 1.5 — HACHURA nas faces cortadas (caps por stencil, só no corte):
      // com o plano ativo, conta backfaces (+1) e frontfaces (−1) do que sobrou além do plano;
      // onde o saldo ≠ 0 o plano atravessa o INTERIOR de um sólido → pinta o quad hachurado 45°.
      if (secPlane) {
        renderer.autoClear = false;
        // câmera EXCLUSIVA do stencil com far cobrindo o MODELO INTEIRO (achado do gate): o far
        // da câmera do desenho (= profundidade de visão) descartava backfaces distantes e
        // desbalanceava a paridade — hachura sumia em laje cortada profunda e aparecia FALSA em
        // parede em vista atravessando o far. L/R/T/B idênticos -> os pixels casam 1:1.
        var camSt = cam.clone(); camSt.far = recuo + diag * 2 + 1; camSt.updateProjectionMatrix();
        stBack = new THREE.MeshBasicMaterial({ colorWrite: false, depthWrite: false, depthTest: false, side: THREE.BackSide,
          stencilWrite: true, stencilFunc: THREE.AlwaysStencilFunc, stencilFail: THREE.IncrementWrapStencilOp, stencilZFail: THREE.IncrementWrapStencilOp, stencilZPass: THREE.IncrementWrapStencilOp });
        stFront = new THREE.MeshBasicMaterial({ colorWrite: false, depthWrite: false, depthTest: false, side: THREE.FrontSide,
          stencilWrite: true, stencilFunc: THREE.AlwaysStencilFunc, stencilFail: THREE.DecrementWrapStencilOp, stencilZFail: THREE.DecrementWrapStencilOp, stencilZPass: THREE.DecrementWrapStencilOp });
        scene.overrideMaterial = stBack; renderer.render(scene, camSt);
        scene.overrideMaterial = stFront; renderer.render(scene, camSt);
        scene.overrideMaterial = null;
        // textura de hachura 45° com espaçamento constante NO PAPEL (~2 mm × escala, em metros de mundo)
        var hcv = document.createElement('canvas'); hcv.width = hcv.height = 32;
        var hg = hcv.getContext('2d');
        hg.fillStyle = '#dfdfdf'; hg.fillRect(0, 0, 32, 32);
        hg.strokeStyle = '#141414'; hg.lineWidth = 2.4;
        hg.beginPath(); hg.moveTo(-4, 36); hg.lineTo(36, -4); hg.moveTo(-20, 20); hg.lineTo(20, -20); hg.moveTo(12, 52); hg.lineTo(52, 12); hg.stroke();
        hatchTex = new THREE.CanvasTexture(hcv);
        hatchTex.wrapS = hatchTex.wrapT = THREE.RepeatWrapping; hatchTex.minFilter = THREE.LinearFilter;
        var esp = 0.0028 * escalaEf; // período da hachura em metros de mundo (~2 mm no papel em qualquer escala)
        hatchTex.repeat.set(wM / esp, hM / esp);
        // depthFunc Always + depthWrite TRUE (achado do gate): o quad GRAVA depth na região
        // hachurada — arestas de geometria ATRÁS do corte não riscam a hachura no PASSE 2
        // (as do contorno, clipadas exatamente no plano, ficam mais perto que o quad e vencem)
        capMat = new THREE.MeshBasicMaterial({ map: hatchTex, depthTest: true, depthFunc: THREE.AlwaysDepth, depthWrite: true, side: THREE.DoubleSide,
          stencilWrite: true, stencilRef: 0, stencilFunc: THREE.NotEqualStencilFunc, stencilFail: THREE.ZeroStencilOp, stencilZFail: THREE.ZeroStencilOp, stencilZPass: THREE.ZeroStencilOp });
        capGeo = new THREE.PlaneGeometry(wM, hM);
        var capQuad = new THREE.Mesh(capGeo, capMat);
        capQuad.position.set(cx + vx * 1e-3, cy, cz + vz * 1e-3); // um fio ALÉM do plano (lado mantido pelo clip)
        capQuad.lookAt(cx + vx * 2, cy, cz + vz * 2);
        var capScene = new THREE.Scene(); capScene.add(capQuad);
        renderer.render(capScene, camSt);
      }
      // PASSE 2 — arestas pretas (cache local + matrixWorld de cada malha)
      edgesRoot = new THREE.Group(); matLinha = new THREE.LineBasicMaterial({ color: 0x111111 });
      modelRoot.children.forEach(function (g) {
        (g.children || []).forEach(function (m) {
          if (!m.geometry || !cadeiaVisivel(m)) return;
          var arr = arestasDe(m.geometry); if (!arr.length) return;
          var bg = new THREE.BufferGeometry(); bg.setAttribute('position', new THREE.BufferAttribute(arr, 3));
          var ls = new THREE.LineSegments(bg, matLinha);
          ls.matrixAutoUpdate = false; ls.matrix.copy(m.matrixWorld);
          edgesRoot.add(ls);
        });
      });
      scene.add(edgesRoot); modelRoot.visible = false; renderer.autoClear = false;
      renderer.render(scene, cam);
      buf = new Uint8Array(W * H * 4);
      renderer.readRenderTargetPixels(rt, 0, 0, W, H, buf);
    } finally {
      // restaura o viewer SEMPRE — uma exceção no meio não pode congelar/vazar estado do renderer
      scene.overrideMaterial = null; renderer.autoClear = prevAuto; modelRoot.visible = true;
      if (edgesRoot) { scene.remove(edgesRoot); edgesRoot.children.forEach(function (ls) { if (ls.geometry) ls.geometry.dispose(); }); }
      if (matLinha) matLinha.dispose(); if (matMassa) matMassa.dispose();
      if (stBack) stBack.dispose(); if (stFront) stFront.dispose();
      if (capMat) capMat.dispose(); if (capGeo) capGeo.dispose(); if (hatchTex) hatchTex.dispose();
      escondidos.forEach(function (c) { c.visible = true; });
      renderer.setRenderTarget(null); try { rt.dispose(); } catch (_) {}
      renderer.clippingPlanes = prevClip; renderer.localClippingEnabled = prevLocal;
      renderer.setClearColor(prevClear, prevAlpha); renderer.toneMapping = prevTone;
    }
    if (!buf) return null;
    // composição 2D: flip vertical (WebGL lê de baixo pra cima) + moldura + carimbo + escala gráfica
    var faixa = 46, cnv = document.createElement('canvas'); cnv.width = W; cnv.height = H + faixa;
    var g2 = cnv.getContext('2d'), img = g2.createImageData(W, H);
    for (var y = 0; y < H; y++) { var srcY = (H - 1 - y) * W * 4; img.data.set(buf.subarray(srcY, srcY + W * 4), y * W * 4); }
    g2.putImageData(img, 0, 0);
    g2.fillStyle = '#fff'; g2.fillRect(0, H, W, faixa);
    g2.strokeStyle = '#111'; g2.lineWidth = 2; g2.strokeRect(1, 1, W - 2, H + faixa - 2); g2.beginPath(); g2.moveTo(1, H); g2.lineTo(W - 1, H); g2.stroke();
    // escala gráfica de 1 m à direita (reserva a faixa antes do carimbo pra não colidir)
    g2.fillStyle = '#111'; var temBarra = pxM >= 8 && pxM < W * 0.45, barW = temBarra ? pxM + 26 : 0;
    if (temBarra) { g2.fillRect(W - pxM - 12, H + 16, pxM, 6); g2.font = '10px Arial'; g2.fillText('1 m', W - pxM - 12, H + 37); }
    // carimbo: encolhe a fonte até caber na largura livre (evita clip/transbordo em desenho estreito)
    var titulo = (o.tipo === 'fachada' ? 'FACHADA' : 'CORTE A–A') + '  ·  ESC 1:' + escalaEf + (ajustada ? ' (ajustada)' : '') + '  ·  ' + (((typeof Empresa!=='undefined'&&Empresa.nomeDoc&&Empresa.nomeDoc())||'') || 'Desenho técnico') + ((typeof Empresa!=='undefined'&&Empresa.creditoTexto&&Empresa.creditoTexto())?' · OrçaPRO BIM':'') + '  ·  ' + new Date().toLocaleDateString('pt-BR');
    var livre = W - 16 - barW, fs = 15;
    g2.font = 'bold ' + fs + 'px Arial';
    while (fs > 8 && g2.measureText(titulo).width > livre) { fs--; g2.font = 'bold ' + fs + 'px Arial'; }
    if (g2.measureText(titulo).width > livre) { titulo = 'ESC 1:' + escalaEf + (ajustada ? ' (aj.)' : ''); g2.font = 'bold 11px Arial'; } // fallback mínimo
    g2.fillStyle = '#111'; g2.fillText(titulo, 10, H + 29);
    return { url: cnv.toDataURL('image/png'), w: W, h: H + faixa, escala: escalaEf, pxPorMetro: pxM, ajustada: ajustada, larguraMM: (H + faixa ? W / 96 * 25.4 : 0), alturaMM: (H + faixa) / 96 * 25.4 };
  }
  S._gerarCorteTec = gerarCorteTec;
  ctecCfg.addEventListener('click', function (e) {
    var b = e.target.closest('[data-t]'); if (!b) return; var k = b.getAttribute('data-t');
    if (k === 'cancelar') { ctecCancelar(); return; }
    if (k !== 'gerar') return;
    var a = ctec.pts[0], p2 = ctec.pts[1]; if (!a || !p2) { ctecCancelar(); return; }
    var res = gerarCorteTec({
      ax: a.x, az: a.z, bx: p2.x, bz: p2.z,
      escala: +ctecCfg.querySelector('[data-t="esc"]').value,
      tipo: ctecCfg.querySelector('[data-t="tipo"]').value,
      prof: +ctecCfg.querySelector('[data-t="prof"]').value,
      inv: ctecCfg.querySelector('[data-t="inv"]').checked
    });
    ctecCfg.style.display = 'none';
    if (!res) { ctecIniciar(); S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('nota', 15) : '') + ' Linha muito curta — clique o 1º ponto da linha de corte (A) de novo.'); return; } // re-arma (senão a ferramenta fica morta)
    ctecModal._ajustar = null; ctecModal._nomeArq = null; // modal é compartilhado com a planta técnica: limpa os hooks dela
    ctecModal._res = res; // guarda p/ imprimir em mm físicos
    ctecModal.querySelector('[data-r="img"]').src = res.url;
    ctecModal.querySelector('[data-r="titulo"]').textContent = (ctecCfg.querySelector('[data-t="tipo"]').value === 'fachada' ? 'Fachada' : 'Corte A–A') + ' — ESC 1:' + res.escala + (res.ajustada ? ' (ajustada p/ caber)' : '');
    ctecModal.style.display = 'flex'; S._hint('');
  });
  S._fecharCtecModal = function () { ctecModal.style.display = 'none'; ctecLimparDesenho(); };
  ctecModal.addEventListener('click', function (e) {
    var b = e.target.closest('[data-r]'); if (!b) return; var k = b.getAttribute('data-r');
    var url = ctecModal.querySelector('[data-r="img"]').src, res = ctecModal._res || {};
    if (k === 'fechar') { S._fecharCtecModal(); }
    else if (k === 'ajustar') {
      ctecModal.style.display = 'none';
      if (ctecModal._ajustar) { ctecModal._ajustar(); S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('nota', 15) : '') + ' Ajuste e clique Gerar.'); } // planta técnica reabre a config DELA
      else { ctecCfg.style.display = 'flex'; S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('nota', 15) : '') + ' Ajuste e clique Gerar (a linha A–A foi mantida).'); } // pts preservados
    }
    else if (k === 'baixar') { var aEl = document.createElement('a'); aEl.href = url; aEl.download = ctecModal._nomeArq || 'corte-tecnico.png'; aEl.click(); }
    else if (k === 'imprimir') {
      // imprime na DIMENSÃO FÍSICA (mm) pra a escala do carimbo valer no papel — max-width:100% encolheria
      var w = null; try { w = window.open('', '_blank'); } catch (_) {}
      if (!w) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('imprimir', 15) : '') + ' O navegador bloqueou a janela de impressão — use ' + (typeof Icones !== 'undefined' ? Icones.get('baixar', 15) : '') + ' PNG e imprima o arquivo em 100%.'); return; }
      try {
        var ttlImp = esc((ctecModal.querySelector('[data-r="titulo"]').textContent || 'Desenho técnico')) + ((typeof Empresa!=='undefined'&&Empresa.creditoTexto&&Empresa.creditoTexto())?' — OrçaPRO BIM':'');
        w.document.write('<!doctype html><meta charset="utf-8"><title>' + ttlImp + '</title>' +
          '<style>@page{size:auto;margin:8mm}body{margin:0;font-family:Arial}.av{font-size:12px;color:#444;margin:6px 2px}@media print{.av{display:none}}</style>' +
          '<p class="av">Imprima em <b>100%</b> (sem “ajustar à página”) para a escala do carimbo valer. A escala gráfica de 1 m serve de conferência.</p>' +
          '<img src="' + url + '" style="width:' + (res.larguraMM || 200).toFixed(1) + 'mm;height:' + (res.alturaMM || 150).toFixed(1) + 'mm;display:block" onload="setTimeout(function(){window.print()},300)">');
        w.document.close();
      } catch (_) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('imprimir', 15) : '') + ' Não deu pra abrir a impressão — use ' + (typeof Icones !== 'undefined' ? Icones.get('baixar', 15) : '') + ' PNG.'); }
    }
  });

  // ============================================================
  // 📄 PLANTA BAIXA TÉCNICA — desenho 2D de verdade (estilo Revit):
  // corte horizontal na altura do slider, paredes cortadas HACHURADAS
  // (mesmo stencil por paridade do corte técnico), arestas pretas, fundo
  // branco, escala exata e COTAS AUTOMÁTICAS em cadeia nos 2 eixos
  // (motor BimPlanta — parede fora de esquadro fica FORA e é declarada).
  // ✏️ Estilo desenho: a própria vista ao vivo vira "planta de verdade"
  // (massas cinza + arestas pretas + fundo branco) enquanto navega.
  // ============================================================
  var estiloD = { on: false, mat: null, matLinha: null };
  S._estiloOn = function () { return !!estiloD.on; };
  function nVerts(geo) { return (geo && geo.attributes && geo.attributes.position) ? geo.attributes.position.count : 0; }
  // silencioso=true: re-aplicação automática (modelo novo / refreshModelo / alpha) — não repinta hint nem outline
  function setEstiloDesenho(on, silencioso) {
    if (on && S._limparRaioX) S._limparRaioX(); // estilo desenho reescreve todos os materiais → tira o raio-X antes (senão o ghostMat vira o "material antes do estilo")
    estiloD.on = !!on;
    var bt = cortePanel.querySelector('[data-c="estilo"]');
    var h2 = (S && S.host) || host; // re-home troca o host — o closure original aponta pro morto
    if (on) {
      if (!estiloD.mat) estiloD.mat = new THREE.MeshBasicMaterial({ color: 0xe9e9e9, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1 });
      if (!estiloD.matLinha) estiloD.matLinha = new THREE.LineBasicMaterial({ color: 0x111111 });
      todasMalhas(function (m) {
        if (!m.geometry) return;
        // salva o material ORIGINAL só na 1ª passada (idempotente); mas FORÇA o cinza SEMPRE que
        // reaplicar — senão refreshModelo/transparência/4D deixariam a cor original de volta com o
        // estilo ainda ligado (o _matAntesEstilo guarda o que restaurar; o material vivo é o cinza).
        if (!('_matAntesEstilo' in m.userData)) {
          if (m === S.selected) m.userData._matAntesEstilo = S.prevMat || m.material;
          else m.userData._matAntesEstilo = m.material;
        }
        if (m === S.selected) S.prevMat = estiloD.mat; // desselecionar devolve o cinza, não a cor
        else if (m.material !== estiloD.mat) m.material = estiloD.mat;
        // arestas pretas: pula malha densa (mesmo guard do snap) — EdgesGeometry em terreno de 90k
        // vértices trava a UI; a massa cinza continua, só sem contorno
        if (!m.userData._edgeLn && nVerts(m.geometry) <= SNAP_MAX_VERT) {
          var arr = arestasDe(m.geometry);
          if (arr.length) {
            var bge = new THREE.BufferGeometry(); bge.setAttribute('position', new THREE.BufferAttribute(arr, 3));
            var ln = new THREE.LineSegments(bge, estiloD.matLinha);
            ln.raycast = function () {}; // aresta é decoração — nunca rouba o clique/snap da parede
            m.add(ln); m.userData._edgeLn = ln;
          }
        }
        if (m.userData._edgeLn) m.userData._edgeLn.visible = true;
      });
      h2.style.background = '#fff';
      _chao.visible = false; // fundo branco: o blob da sombra de contato viraria borrão cinza (some no fundo escuro normal)
      if (bt) bt.style.outline = '2px solid ' + corAtiva();
      if (!silencioso) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('editar', 15) : '') + ' Estilo desenho: massas + arestas no fundo branco (as cores voltam ao sair).');
    } else {
      _chao.visible = true;
      todasMalhas(function (m) {
        if ('_matAntesEstilo' in m.userData) {
          if (m === S.selected) { if (S.prevMat === estiloD.mat) S.prevMat = m.userData._matAntesEstilo; }
          else m.material = m.userData._matAntesEstilo;
          delete m.userData._matAntesEstilo;
        }
        if (m.userData._edgeLn) m.userData._edgeLn.visible = false;
      });
      if (bt) bt.style.outline = '';
      if (S._aplicarTema) S._aplicarTema(); // devolve o fundo do tema atual
    }
  }
  S._setEstiloDesenho = setEstiloDesenho;
  S._reaplicarEstilo = function () { if (estiloD.on) setEstiloDesenho(true, true); }; // modelo novo/refresh entra no estilo, sem spam de hint
  // esconde/mostra as arestas do estilo (thumbnail e foto de 1 elemento não podem sair com wireframe)
  S._edgesEstilo = function (mostrar) { if (!estiloD.on) return; todasMalhas(function (m) { if (m.userData._edgeLn) m.userData._edgeLn.visible = !!mostrar; }); };

  var plantaCfg = document.createElement('div');
  plantaCfg.style.cssText = 'position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:6;display:none;flex-direction:column;gap:8px;background:rgba(255,255,255,.985);border:1px solid #d3dce6;border-radius:12px;padding:14px 16px;color:#1a2b3c;font-size:12px;width:270px;box-shadow:0 12px 34px rgba(0,0,0,.5)';
  plantaCfg.innerHTML =
    '<b>' + (typeof Icones !== 'undefined' ? Icones.get('nota', 15) : '') + ' Planta baixa técnica</b>' +
    '<label style="display:flex;justify-content:space-between;align-items:center">Escala <select data-q="esc" class="inp" style="width:130px"><option value="50" selected>1:50</option><option value="75">1:75</option><option value="100">1:100</option><option value="200">1:200</option></select></label>' +
    '<label style="display:flex;gap:6px;align-items:center"><input data-q="cotas" type="checkbox" checked> Cotas automáticas nas paredes</label>' +
    '<label style="display:flex;justify-content:space-between;align-items:center">Profundidade abaixo do corte <input data-q="prof" class="inp" type="number" min="0.5" step="0.5" value="3" style="width:64px"> m</label>' +
    '<div style="font-size:11px;color:#b45309;line-height:1.35">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' As cotas saem dos alinhamentos das faces das paredes retas nos eixos do modelo. Parede fora de esquadro fica sem cota automática (declarada no desenho) — use a ' + (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '') + ' trena.</div>' +
    '<div style="display:flex;gap:6px"><button class="btn sm primary" data-q="gerar" style="flex:1">Gerar</button><button class="btn sm" data-q="cancelar" style="flex:1">Cancelar</button></div>';
  host.appendChild(plantaCfg);
  S.plantaCfg = plantaCfg;

  // cadeias de cota (parciais + total) desenhadas em volta do desenho, estilo prancha
  function desenharCotas(g2, cad, geo) {
    var mmpx = 96 / 25.4;
    function mm(v) { return Math.round(v * mmpx); }
    function px(x) { return geo.padL + (x - geo.x0) * geo.pxM; }
    function py(z) { return (z - geo.z0) * geo.pxM; }
    function tick(x, y) { g2.beginPath(); g2.moveTo(x - 3.5, y + 3.5); g2.lineTo(x + 3.5, y - 3.5); g2.stroke(); }
    g2.lineWidth = 1;
    if (cad.x) {
      var y1 = geo.H + mm(6), y2 = geo.H + mm(12);
      g2.strokeStyle = '#888'; // linhas de chamada
      cad.x.ticks.forEach(function (t) { g2.beginPath(); g2.moveTo(px(t), geo.H + 2); g2.lineTo(px(t), y2 + mm(1.5)); g2.stroke(); });
      g2.strokeStyle = '#111'; g2.fillStyle = '#111';
      g2.beginPath(); g2.moveTo(px(cad.x.total.a) - 6, y1); g2.lineTo(px(cad.x.total.b) + 6, y1); g2.stroke();
      cad.x.ticks.forEach(function (t) { tick(px(t), y1); });
      cad.x.segs.forEach(function (s) {
        var w = px(s.b) - px(s.a), t = BimPlanta.fmtM(s.v);
        g2.font = '10px Arial'; var tw = g2.measureText(t).width;
        if (tw > w - 4) { g2.font = '8px Arial'; tw = g2.measureText(t).width; if (tw > w - 2) return; } // sem espaço: fica só o tick
        g2.fillText(t, (px(s.a) + px(s.b)) / 2 - tw / 2, y1 - 3);
      });
      g2.beginPath(); g2.moveTo(px(cad.x.total.a) - 6, y2); g2.lineTo(px(cad.x.total.b) + 6, y2); g2.stroke();
      tick(px(cad.x.total.a), y2); tick(px(cad.x.total.b), y2);
      g2.font = 'bold 11px Arial'; var tt = BimPlanta.fmtM(cad.x.total.v), ttw = g2.measureText(tt).width;
      g2.fillText(tt, (px(cad.x.total.a) + px(cad.x.total.b)) / 2 - ttw / 2, y2 - 3);
    }
    if (cad.z) {
      var x1 = geo.padL - mm(6), x2 = geo.padL - mm(12);
      g2.strokeStyle = '#888';
      cad.z.ticks.forEach(function (t) { g2.beginPath(); g2.moveTo(geo.padL - 2, py(t)); g2.lineTo(x2 - mm(1.5), py(t)); g2.stroke(); });
      g2.strokeStyle = '#111'; g2.fillStyle = '#111';
      g2.beginPath(); g2.moveTo(x1, py(cad.z.total.a) - 6); g2.lineTo(x1, py(cad.z.total.b) + 6); g2.stroke();
      cad.z.ticks.forEach(function (t) { tick(x1, py(t)); });
      cad.z.segs.forEach(function (s) {
        var h = py(s.b) - py(s.a), t = BimPlanta.fmtM(s.v);
        g2.font = '10px Arial'; var tw = g2.measureText(t).width;
        if (tw > h - 4) { g2.font = '8px Arial'; tw = g2.measureText(t).width; if (tw > h - 2) return; }
        g2.save(); g2.translate(x1 - 3, (py(s.a) + py(s.b)) / 2 + tw / 2); g2.rotate(-Math.PI / 2); g2.fillText(t, 0, 0); g2.restore();
      });
      g2.beginPath(); g2.moveTo(x2, py(cad.z.total.a) - 6); g2.lineTo(x2, py(cad.z.total.b) + 6); g2.stroke();
      tick(x2, py(cad.z.total.a)); tick(x2, py(cad.z.total.b));
      g2.save(); g2.font = 'bold 11px Arial'; var tz = BimPlanta.fmtM(cad.z.total.v), tzw = g2.measureText(tz).width;
      g2.translate(x2 - 3, (py(cad.z.total.a) + py(cad.z.total.b)) / 2 + tzw / 2); g2.rotate(-Math.PI / 2); g2.fillText(tz, 0, 0); g2.restore();
    }
  }

  function gerarPlantaTec(o) {
    // o: {y (altura do corte no MUNDO, metros), escala, cotas, prof, rotAlt}
    var box = new THREE.Box3().setFromObject(modelRoot);
    if (box.isEmpty()) return null;
    var minX = box.min.x, maxX = box.max.x, minZ = box.min.z, maxZ = box.max.z;
    var margem = Math.max(0.4, Math.max(maxX - minX, maxZ - minZ) * 0.03);
    var wM = (maxX - minX) + margem * 2, hM = (maxZ - minZ) + margem * 2;
    var escBase = o.escala || 50, PPM96 = 96 / 25.4;
    // mesmo cap honesto do corte técnico: se a escala pedida estoura a GPU, sobe pra próxima da
    // série padrão (medível com escalímetro) e recomputa px/m EXATO — carimbo == pixels
    var MAXPX = Math.min(4096, (renderer.capabilities && renderer.capabilities.maxTextureSize) || 4096);
    var escalaEf = escBase, pxM = PPM96 * (1000 / escalaEf);
    if (Math.max(wM, hM) * pxM > MAXPX) {
      escalaEf = null;
      for (var si = 0; si < SERIE_ESC.length; si++) { if (SERIE_ESC[si] >= escBase && Math.max(wM, hM) * (PPM96 * (1000 / SERIE_ESC[si])) <= MAXPX) { escalaEf = SERIE_ESC[si]; break; } }
      if (escalaEf == null) { escalaEf = Math.ceil(PPM96 * 1000 / (MAXPX / Math.max(wM, hM))); pxM = PPM96 * (1000 / escalaEf); }
      else pxM = PPM96 * (1000 / escalaEf);
    }
    var ajustada = escalaEf !== escBase;
    var W = Math.round(wM * pxM), H = Math.round(hM * pxM);
    var cx = (minX + maxX) / 2, cz = (minZ + maxZ) / 2;
    var recuo = 0.02, prof = Math.max(0.5, +o.prof || 3);
    var secPlane = new THREE.Plane(new THREE.Vector3(0, -1, 0), o.y); // mantém o que está ABAIXO do corte
    var cam = new THREE.OrthographicCamera(-wM / 2, wM / 2, hM / 2, -hM / 2, 0.01, recuo + prof);
    cam.position.set(cx, o.y + recuo, cz);
    cam.up.set(0, 0, -1); // norte pra cima (X do modelo pra direita)
    cam.lookAt(cx, o.y - 1, cz); cam.updateProjectionMatrix(); cam.updateMatrixWorld(true);
    var prevClip = renderer.clippingPlanes, prevLocal = renderer.localClippingEnabled;
    var prevClear = renderer.getClearColor(new THREE.Color()).clone(), prevAlpha = renderer.getClearAlpha();
    var prevTone = renderer.toneMapping, prevAuto = renderer.autoClear;
    var rt = new THREE.WebGLRenderTarget(W, H, { depthBuffer: true, stencilBuffer: true }), buf = null, edgesRoot = null, matMassa = null, matLinha = null, escondidos = [];
    var stBack = null, stFront = null, capMat = null, capGeo = null, hatchTex = null;
    try {
      renderer.clippingPlanes = [secPlane]; renderer.localClippingEnabled = false;
      renderer.toneMapping = THREE.NoToneMapping; // P&B fiel
      scene.children.forEach(function (c) { if (c !== modelRoot && c.visible !== false) { escondidos.push(c); c.visible = false; } });
      // PASSE 1 — massas cinza-claro sobre branco
      matMassa = new THREE.MeshBasicMaterial({ color: 0xededed, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1 });
      scene.overrideMaterial = matMassa;
      renderer.setRenderTarget(rt); renderer.setClearColor(0xffffff, 1); renderer.clear();
      renderer.render(scene, cam);
      scene.overrideMaterial = null;
      // PASSE 1.5 — HACHURA nas paredes cortadas (paridade de stencil, mesma técnica do corte
      // técnico; câmera do stencil com far cobrindo o modelo INTEIRO abaixo do corte)
      renderer.autoClear = false;
      var camSt = cam.clone(); camSt.far = recuo + Math.max(0.5, o.y - box.min.y) + 1; camSt.updateProjectionMatrix();
      stBack = new THREE.MeshBasicMaterial({ colorWrite: false, depthWrite: false, depthTest: false, side: THREE.BackSide,
        stencilWrite: true, stencilFunc: THREE.AlwaysStencilFunc, stencilFail: THREE.IncrementWrapStencilOp, stencilZFail: THREE.IncrementWrapStencilOp, stencilZPass: THREE.IncrementWrapStencilOp });
      stFront = new THREE.MeshBasicMaterial({ colorWrite: false, depthWrite: false, depthTest: false, side: THREE.FrontSide,
        stencilWrite: true, stencilFunc: THREE.AlwaysStencilFunc, stencilFail: THREE.DecrementWrapStencilOp, stencilZFail: THREE.DecrementWrapStencilOp, stencilZPass: THREE.DecrementWrapStencilOp });
      scene.overrideMaterial = stBack; renderer.render(scene, camSt);
      scene.overrideMaterial = stFront; renderer.render(scene, camSt);
      scene.overrideMaterial = null;
      var hcv = document.createElement('canvas'); hcv.width = hcv.height = 32;
      var hg = hcv.getContext('2d');
      hg.fillStyle = '#dfdfdf'; hg.fillRect(0, 0, 32, 32);
      hg.strokeStyle = '#141414'; hg.lineWidth = 2.4;
      hg.beginPath(); hg.moveTo(-4, 36); hg.lineTo(36, -4); hg.moveTo(-20, 20); hg.lineTo(20, -20); hg.moveTo(12, 52); hg.lineTo(52, 12); hg.stroke();
      hatchTex = new THREE.CanvasTexture(hcv);
      hatchTex.wrapS = hatchTex.wrapT = THREE.RepeatWrapping; hatchTex.minFilter = THREE.LinearFilter;
      var esp = 0.0028 * escalaEf; // ~2 mm no papel em qualquer escala
      hatchTex.repeat.set(wM / esp, hM / esp);
      capMat = new THREE.MeshBasicMaterial({ map: hatchTex, depthTest: true, depthFunc: THREE.AlwaysDepth, depthWrite: true, side: THREE.DoubleSide,
        stencilWrite: true, stencilRef: 0, stencilFunc: THREE.NotEqualStencilFunc, stencilFail: THREE.ZeroStencilOp, stencilZFail: THREE.ZeroStencilOp, stencilZPass: THREE.ZeroStencilOp });
      capGeo = new THREE.PlaneGeometry(wM, hM);
      var capQuad = new THREE.Mesh(capGeo, capMat);
      capQuad.rotation.x = Math.PI / 2; // XY -> XZ, normal pra baixo (lado mantido pelo clip)
      capQuad.position.set(cx, o.y - 1e-3, cz); // um fio ALÉM do plano, no lado mantido
      var capScene = new THREE.Scene(); capScene.add(capQuad);
      renderer.render(capScene, camSt);
      // PASSE 2 — arestas pretas
      edgesRoot = new THREE.Group(); matLinha = new THREE.LineBasicMaterial({ color: 0x111111 });
      modelRoot.children.forEach(function (g) {
        (g.children || []).forEach(function (m) {
          if (!m.geometry || !cadeiaVisivel(m)) return;
          var arr = arestasDe(m.geometry); if (!arr.length) return;
          var bg = new THREE.BufferGeometry(); bg.setAttribute('position', new THREE.BufferAttribute(arr, 3));
          var ls = new THREE.LineSegments(bg, matLinha);
          ls.matrixAutoUpdate = false; ls.matrix.copy(m.matrixWorld);
          edgesRoot.add(ls);
        });
      });
      scene.add(edgesRoot); modelRoot.visible = false; renderer.autoClear = false;
      renderer.render(scene, cam);
      buf = new Uint8Array(W * H * 4);
      renderer.readRenderTargetPixels(rt, 0, 0, W, H, buf);
    } finally {
      // restaura o viewer SEMPRE (mesma disciplina do corte técnico)
      scene.overrideMaterial = null; renderer.autoClear = prevAuto; modelRoot.visible = true;
      if (edgesRoot) { scene.remove(edgesRoot); edgesRoot.children.forEach(function (ls) { if (ls.geometry) ls.geometry.dispose(); }); }
      if (matLinha) matLinha.dispose(); if (matMassa) matMassa.dispose();
      if (stBack) stBack.dispose(); if (stFront) stFront.dispose();
      if (capMat) capMat.dispose(); if (capGeo) capGeo.dispose(); if (hatchTex) hatchTex.dispose();
      escondidos.forEach(function (c) { c.visible = true; });
      renderer.setRenderTarget(null); try { rt.dispose(); } catch (_) {}
      renderer.clippingPlanes = prevClip; renderer.localClippingEnabled = prevLocal;
      renderer.setClearColor(prevClear, prevAlpha); renderer.toneMapping = prevTone;
    }
    if (!buf) return null;
    // COTAS AUTOMÁTICAS — só paredes VISÍVEIS que o corte atravessa (motor puro BimPlanta)
    var cad = null;
    if (o.cotas && typeof BimPlanta !== 'undefined') {
      var els = [];
      S.modelos.forEach(function (mo) {
        if (mo.visivel === false) return;
        (mo.elementos || []).forEach(function (el) {
          if (!el.aabb) return;
          var m = S.meshPorUid[el.uid];
          if (!m || !m.visible || !cadeiaVisivel(m)) return;
          els.push({ tipo: el.tipo, aabb: el.aabb });
        });
      });
      cad = BimPlanta.cadeias(BimPlanta.paredesDoCorte(els, o.y));
    }
    var temCotas = !!(cad && (cad.x || cad.z));
    // avisos honestos numa FAIXA reservada no topo (nunca por cima do desenho)
    var avisos = [];
    if (cad && cad.diagonais) avisos.push('⚠ ' + cad.diagonais + ' parede(s) fora de esquadro/curtas sem cota automática — meça com a trena');
    if (o.cotas && !temCotas) avisos.push('' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Nenhuma parede reta atravessa o corte — sem cotas automáticas');
    var padTop = avisos.length ? (avisos.length * 15 + 8) : 0;
    var padL = (cad && cad.z) ? Math.round(17 * PPM96) : 0; // 17 mm p/ cadeia vertical
    var padB = (cad && cad.x) ? Math.round(17 * PPM96) : 0;
    var faixa = 46, totalW = padL + W, totalH = padTop + H + padB + faixa, yBase = padTop + H + padB;
    var cnv = document.createElement('canvas'); cnv.width = totalW; cnv.height = totalH;
    var g2 = cnv.getContext('2d');
    g2.fillStyle = '#fff'; g2.fillRect(0, 0, totalW, totalH);
    var img = g2.createImageData(W, H);
    for (var y2f = 0; y2f < H; y2f++) { var srcY = (H - 1 - y2f) * W * 4; img.data.set(buf.subarray(srcY, srcY + W * 4), y2f * W * 4); }
    g2.putImageData(img, padL, padTop); // putImageData ignora transform — posiciona direto abaixo da faixa de avisos
    if (cad) { g2.save(); g2.translate(0, padTop); desenharCotas(g2, cad, { padL: padL, H: H, pxM: pxM, x0: minX - margem, z0: minZ - margem }); g2.restore(); }
    // faixa de avisos no topo
    if (avisos.length) {
      g2.font = '11px Arial'; g2.fillStyle = '#b45309';
      for (var ai = 0; ai < avisos.length; ai++) g2.fillText(avisos[ai], 8, 16 + ai * 15);
    }
    // moldura + divisória do carimbo + escala gráfica + carimbo (mesma régua do corte técnico)
    g2.strokeStyle = '#111'; g2.lineWidth = 2; g2.strokeRect(1, 1, totalW - 2, totalH - 2);
    g2.beginPath(); g2.moveTo(1, yBase); g2.lineTo(totalW - 1, yBase); g2.stroke();
    g2.fillStyle = '#111'; var temBarra = pxM >= 8 && pxM < totalW * 0.45, barW = temBarra ? pxM + 26 : 0;
    if (temBarra) { g2.fillRect(totalW - pxM - 12, yBase + 16, pxM, 6); g2.font = '10px Arial'; g2.fillText('1 m', totalW - pxM - 12, yBase + 37); }
    var rotAlt = o.rotAlt || (fmtDist(Math.max(0, o.y - box.min.y)) + ' do piso');
    var titulo = 'PLANTA BAIXA (corte a ' + rotAlt + ')  ·  ESC 1:' + escalaEf + (ajustada ? ' (ajustada)' : '') + '  ·  ' + (((typeof Empresa!=='undefined'&&Empresa.nomeDoc&&Empresa.nomeDoc())||'') || 'Desenho técnico') + ((typeof Empresa!=='undefined'&&Empresa.creditoTexto&&Empresa.creditoTexto())?' · OrçaPRO BIM':'') + '  ·  ' + new Date().toLocaleDateString('pt-BR');
    var livre = totalW - 16 - barW, fs = 15;
    g2.font = 'bold ' + fs + 'px Arial';
    while (fs > 8 && g2.measureText(titulo).width > livre) { fs--; g2.font = 'bold ' + fs + 'px Arial'; }
    if (g2.measureText(titulo).width > livre) { titulo = 'ESC 1:' + escalaEf + (ajustada ? ' (aj.)' : ''); g2.font = 'bold 11px Arial'; }
    g2.fillStyle = '#111'; g2.fillText(titulo, 10, yBase + 29);
    return { url: cnv.toDataURL('image/png'), w: totalW, h: totalH, escala: escalaEf, pxPorMetro: pxM, ajustada: ajustada, cotas: temCotas, diagonais: cad ? cad.diagonais : 0, larguraMM: totalW / 96 * 25.4, alturaMM: totalH / 96 * 25.4 };
  }
  S._gerarPlantaTec = gerarPlantaTec;
  plantaCfg.addEventListener('click', function (e) {
    var b = e.target.closest('[data-q]'); if (!b) return; var k = b.getAttribute('data-q');
    if (k === 'cancelar') { plantaCfg.style.display = 'none'; return; }
    if (k !== 'gerar') return;
    if (!planta.on || !planta.plane) { plantaCfg.style.display = 'none'; S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('regua', 15) : '') + ' Abra a Planta primeiro — o corte usa a altura do slider.'); return; }
    var res = gerarPlantaTec({
      y: planta.plane.constant,
      escala: +plantaCfg.querySelector('[data-q="esc"]').value,
      cotas: plantaCfg.querySelector('[data-q="cotas"]').checked,
      prof: +plantaCfg.querySelector('[data-q="prof"]').value,
      rotAlt: (cortePanel.querySelector('[data-c="v"]') || {}).textContent
    });
    plantaCfg.style.display = 'none';
    if (!res) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('nota', 15) : '') + ' Carregue um modelo primeiro.'); return; }
    ctecModal._res = res;
    ctecModal._nomeArq = 'planta-baixa.png';
    ctecModal._ajustar = function () { plantaCfg.style.display = 'flex'; };
    ctecModal.querySelector('[data-r="img"]').src = res.url;
    ctecModal.querySelector('[data-r="titulo"]').textContent = 'Planta baixa — ESC 1:' + res.escala + (res.ajustada ? ' (ajustada p/ caber)' : '') + (res.cotas ? ' · cotas automáticas' : '');
    ctecModal.style.display = 'flex'; S._hint('');
  });

  // ============================================================
  // 🏢 PAVIMENTOS — lê os IfcBuildingStorey do arquivo e permite isolar um andar
  // ou gerar a planta baixa DELE (isola + corta a 1,20 m do piso do pavimento).
  // Isolamento é SÓ visibilidade (mesh.visible) — 4D/mostrarTudo (externos)
  // sobrescrevem e limpam o marcador. Merge por NOME entre modelos federados
  // (o engenheiro pensa em andares, não em arquivos).
  // ============================================================
  var pav = { isolado: null, manual: false }; // manual = isolamento via 👁 (sem nome de pavimento)
  S.pav = pav;
  // COMPOSIÇÃO COM O 4D (achado do gate — família "camada nova reintroduz o que o filtro matou"):
  // aplicarEstado guarda os "futuros" em S._fut4d; toda escrita de visibilidade do 🏢/👁 compõe
  // com ele (visível = pertence ao alvo E não é futuro) — senão isolar um pavimento ressuscitaria
  // paredes que o cronograma ainda não construiu, com o rótulo de avanço ainda na tela.
  function ehFuturo4d(m) {
    var f = S._fut4d; if (!f) return false;
    var id = m.userData.expressID;
    return !!(f[m.userData.mid + ':' + id] || f[id]);
  }
  // irmão de ehFuturo4d: elemento "em andamento" (âmbar) no estágio 4D corrente — usado no restore do raio-X
  function ehAndamento4d(m) {
    var a = S._and4d; if (!a) return false;
    var id = m.userData.expressID;
    return !!(a[m.userData.mid + ':' + id] || a[id]);
  }
  S._ehAndamento4d = ehAndamento4d;
  // malhas que o usuário REALMENTE vê (grupo do modelo ligado + mesh visível)
  function visiveisEfetivos() {
    var v = 0;
    modelRoot.children.forEach(function (g) { if (g.visible === false) return; (g.children || []).forEach(function (m) { if (m.visible) v++; }); });
    return v;
  }
  var pavPanel = document.createElement('div');
  pavPanel.style.cssText = 'position:absolute;left:10px;top:52px;z-index:4;display:none;flex-direction:column;gap:6px;background:rgba(255,255,255,.98);border:1px solid #d3dce6;border-radius:11px;padding:11px 13px;color:#1a2b3c;font-size:12px;width:250px;max-height:55%;overflow:auto';
  host.appendChild(pavPanel);
  S.pavPanel = pavPanel;
  function todasMalhas(fn) { modelRoot.children.forEach(function (g) { (g.children || []).forEach(fn); }); }
  // lista mesclada por nome (entre modelos), ordenada pela altura real (y0 do AABB dos membros)
  function pavLista() {
    var mapa = {}, ordem = [];
    S.modelos.forEach(function (mo) {
      (mo.pavimentos || []).forEach(function (pv) {
        var k = pv.nome.trim().toLowerCase();
        if (!mapa[k]) { mapa[k] = { nome: pv.nome.trim(), uids: {}, y0: null, yMax: null, elev: null, n: 0 }; ordem.push(mapa[k]); }
        pv.eids.forEach(function (eid) { if (!mapa[k].uids[mo.mid + ':' + eid]) { mapa[k].uids[mo.mid + ':' + eid] = 1; mapa[k].n++; } });
        // FRAMES DISTINTOS (achado do gate): y0 é MUNDO (AABB dos membros); elev é LOCAL do
        // arquivo (datum próprio, ignora placement) — NUNCA entram na mesma régua. elev fica
        // num campo separado e serve SÓ de desempate de ordenação entre pavimentos sem malha.
        if (pv.y0 != null) {
          if (mapa[k].y0 == null || pv.y0 < mapa[k].y0) mapa[k].y0 = pv.y0;
          if (mapa[k].yMax == null || pv.y0 > mapa[k].yMax) mapa[k].yMax = pv.y0;
        }
        if (pv.elev != null && (mapa[k].elev == null || pv.elev < mapa[k].elev)) mapa[k].elev = pv.elev;
      });
    });
    // merge por nome com cotas REALMENTE diferentes (blocos em desnível) -> marca p/ avisar na planta
    ordem.forEach(function (pv) { pv.spread = (pv.y0 != null && pv.yMax != null && (pv.yMax - pv.y0) > 1.5); });
    // ordena pela altura de MUNDO; sem geometria vai pro fim (ordenado entre si pelo elev local)
    ordem.sort(function (a, b) {
      var ka = (a.y0 == null) ? 1 : 0, kb = (b.y0 == null) ? 1 : 0;
      if (ka !== kb) return ka - kb;
      if (ka === 1) return (a.elev == null ? 1e9 : a.elev) - (b.elev == null ? 1e9 : b.elev);
      return a.y0 - b.y0;
    });
    return ordem;
  }
  S._pavLista = pavLista;
  function pavRender() {
    var lst = pavLista();
    var html = '<div style="display:flex;justify-content:space-between;align-items:center"><b>' + (typeof Icones !== 'undefined' ? Icones.get('niveis', 15) : '') + ' Pavimentos</b><button class="btn sm" data-p="todos" title="Mostrar todos os pavimentos de novo">' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Todos</button></div>';
    if (!lst.length) {
      html += '<div style="font-size:11px;color:#5b6b7c">Este IFC não declara pavimentos (IfcBuildingStorey). Use a ' + (typeof Icones !== 'undefined' ? Icones.get('regua', 15) : '') + ' Planta com o slider de altura.</div>';
    } else {
      var base = null;
      lst.forEach(function (pv) { if (pv.y0 != null && (base == null || pv.y0 < base)) base = pv.y0; });
      lst.forEach(function (pv) {
        var atv = pav.isolado === pv.nome;
        var nivel = (pv.y0 != null && base != null) ? ' <span style="color:#5b6b7c;font-size:11px">nível +' + fmtDist(Math.max(0, pv.y0 - base)) + '</span>' : '';
        html += '<div style="display:flex;align-items:center;gap:5px;border:1px solid ' + (atv ? corAtiva() : 'transparent') + ';border-radius:7px;padding:2px 4px">' +
          '<span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + esc(pv.nome) + ' · ' + pv.n + ' elementos">' + esc(pv.nome) + nivel + '</span>' +
          '<button class="btn sm" data-p="iso" data-n="' + esc(pv.nome) + '" title="Isolar este pavimento">' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + '</button>' +
          '<button class="btn sm" data-p="pl" data-n="' + esc(pv.nome) + '" title="Planta baixa deste pavimento">' + (typeof Icones !== 'undefined' ? Icones.get('regua', 15) : '') + '</button></div>';
      });
      html += '<div style="font-size:11px;color:#5b6b7c">Isolar mostra só o que o IFC declara nesse andar — o que não está em pavimento nenhum também some. ' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Todos restaura.</div>';
    }
    pavPanel.innerHTML = html;
    var bp2 = bar.querySelector('[data-b="pav"]'); if (bp2) { bp2.style.background = pav.isolado ? corAtiva() : ''; bp2.style.color = pav.isolado ? '#fff' : ''; bp2.style.outline = (pavPanel.style.display === 'flex') ? '2px solid #15803d' : ''; }
  }
  S._pavRender = pavRender;
  function restaurarVisibilidade() {
    pav.isolado = null; pav.manual = false;
    if (S._limparRaioX) S._limparRaioX(); // ↺ também tira o raio-X (materiais fantasma → originais)
    todasMalhas(function (m) { m.visible = !ehFuturo4d(m) && !ehRemovidoEd(m); }); // restaurar NÃO ressuscita futuros do 4D nem removidos da edição
    pavRender();
  }
  S._restaurarVis = restaurarVisibilidade;
  function isolarPavimento(nome) {
    var lst = pavLista(), alvo = null;
    for (var i = 0; i < lst.length; i++) if (lst[i].nome === nome) { alvo = lst[i]; break; }
    if (!alvo) return false;
    todasMalhas(function (m) { m.visible = !!alvo.uids[m.userData.mid + ':' + m.userData.expressID] && !ehFuturo4d(m) && !ehRemovidoEd(m); });
    pav.isolado = alvo.nome; pav.manual = false; pavRender();
    if (visiveisEfetivos() === 0) S._hint('🏢 "' + alvo.nome + '" isolado, mas nada visível — o pavimento pertence a um modelo desligado (religue no painel Modelos) ou não tem geometria/está no futuro do 4D. ' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Todos restaura.');
    else S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('niveis', 15) : '') + ' Pavimento "' + alvo.nome + '" isolado. ' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Todos (painel 🏢) restaura.');
    return true;
  }
  S._isolarPavimento = isolarPavimento;
  function plantaPavimento(nome) {
    var lst = pavLista(), alvo = null;
    for (var i = 0; i < lst.length; i++) if (lst[i].nome === nome) { alvo = lst[i]; break; }
    if (!alvo) return false;
    isolarPavimento(alvo.nome);
    if (!planta.on) setPlanta(true);
    if (!planta.on) return false; // bbox vazio
    // corte a 1,20 m do piso do PAVIMENTO (altura de peitoril), limitado à faixa do modelo
    var y = (alvo.y0 != null ? alvo.y0 : planta.y0) + 1.2;
    y = Math.max(planta.y0 + 0.05, Math.min(planta.y1 - 0.001, y));
    var frac = (y - planta.y0) / ((planta.y1 - planta.y0) || 1);
    var sl = cortePanel.querySelector('[data-c="alt"]'); if (sl) sl.value = Math.round(frac * 1000);
    setAlturaCorte(frac);
    // rótulo honesto: merge com cotas diferentes / pavimento sem geometria têm ressalva explícita
    var aviso = '';
    if (alvo.y0 == null) aviso = ' ' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Este pavimento não tem geometria própria — o corte ficou na base do modelo.';
    else if (alvo.spread) aviso = ' ' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Há "' + alvo.nome + '" em cotas diferentes entre os modelos — parte pode ficar acima do corte (ajuste no slider).';
    S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('regua', 15) : '') + ' Planta do pavimento "' + alvo.nome + '".' + aviso + ' Ajuste fino no slider; ' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Todos (painel 🏢) traz o prédio de volta.');
    return true;
  }
  S._plantaPavimento = plantaPavimento;
  pavPanel.addEventListener('click', function (e) {
    var b = e.target.closest('[data-p]'); if (!b) return; var k = b.getAttribute('data-p');
    if (k === 'todos') { restaurarVisibilidade(); S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('niveis', 15) : '') + ' Todos os pavimentos visíveis.'); }
    else if (k === 'iso') isolarPavimento(b.getAttribute('data-n'));
    else if (k === 'pl') plantaPavimento(b.getAttribute('data-n'));
  });
  function togglePavPanel() {
    var abrir = (pavPanel.style.display === 'none' || !pavPanel.style.display);
    fecharPaineis(abrir ? pavPanel : null);
    pavPanel.style.display = abrir ? 'flex' : 'none';
    if (abrir) pavRender(); else { var bp3 = bar.querySelector('[data-b="pav"]'); if (bp3) bp3.style.outline = ''; }
  }

  // ============================================================
  // 👁 VISIBILIDADE — isolar/ocultar o elemento selecionado (duplo-clique) ou
  // todos do mesmo tipo. Só mexe em mesh.visible (materiais intactos).
  // ============================================================
  var visPanel = document.createElement('div');
  visPanel.style.cssText = 'position:absolute;right:10px;top:52px;z-index:4;display:none;flex-direction:column;gap:6px;background:rgba(255,255,255,.98);border:1px solid #d3dce6;border-radius:11px;padding:11px 13px;color:#1a2b3c;font-size:12px;width:220px';
  visPanel.innerHTML =
    // ✕ próprio (padrão dos outros painéis): sem ele, o único jeito de fechar era o
    // botão "Ver" lá dentro do leque do dock — e com a barra recolhida o painel ficava
    // órfão na tela, sem nenhum fechador alcançável.
    '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><b>' + (typeof Icones !== 'undefined' ? Icones.get('olho', 15) : '') + ' Visibilidade</b>' +
      '<button class="btn sm" data-v="fechar" title="Fechar este painel" style="padding:2px 8px;line-height:1.2">' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + '</button></div>' +
    '<button class="btn sm" data-v="iso" title="Esconde tudo, menos o elemento selecionado">' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' Isolar seleção</button>' +
    '<button class="btn sm" data-v="occ" title="Esconde o elemento selecionado">' + (typeof Icones !== 'undefined' ? Icones.get('olhoFechado', 15) : '') + ' Ocultar seleção</button>' +
    '<button class="btn sm" data-v="tipo" title="Mostra só os elementos do MESMO tipo do selecionado (ex.: todas as paredes)">' + (typeof Icones !== 'undefined' ? Icones.get('quebracabeca', 15) : '') + ' Só este tipo</button>' +
    '<button class="btn sm" data-v="rx" title="Raio-X: deixa o resto translúcido (não some) e destaca o elemento. Enxergue o que está atrás/dentro.">' + (typeof Icones !== 'undefined' ? Icones.get('camadas', 15) : '') + ' Raio-X da seleção</button>' +
    '<button class="btn sm" data-v="rxt" title="Raio-X por tipo: destaca todos deste tipo (ex.: toda a hidráulica) e translucidez o resto — bom pra ver onde há cano antes de furar.">' + (typeof Icones !== 'undefined' ? Icones.get('camadas', 15) : '') + ' Raio-X deste tipo</button>' +
    '<button class="btn sm" data-v="tudo" title="Volta a mostrar tudo">' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Restaurar tudo</button>' +
    '<div style="font-size:11px;color:#5b6b7c">Dê <b>dois cliques</b> num elemento do modelo pra selecionar antes.</div>';
  host.appendChild(visPanel);
  S.visPanel = visPanel;
  function selInfo() { return (S.selected && S.selected.userData && S.selected.userData.expressID != null) ? { mid: S.selected.userData.mid, eid: S.selected.userData.expressID, tipo: S.selected.userData.tipo } : null; }
  function isolarSelecao() {
    var si = selInfo(); if (!si) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('olho', 15) : '') + ' Dê dois cliques num elemento do modelo primeiro.'); return; }
    todasMalhas(function (m) { m.visible = (m.userData.mid === si.mid && m.userData.expressID === si.eid) && !ehFuturo4d(m) && !ehRemovidoEd(m); });
    pav.isolado = null; pav.manual = true; pavRender(); // isolamento manual substitui o de pavimento (e é restaurável)
    if (visiveisEfetivos() === 0) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' Isolado, mas nada visível — o modelo desse elemento está desligado no painel Modelos. ' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Restaurar tudo volta o modelo.');
    else S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' Elemento isolado. ' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Restaurar tudo (painel 👁) volta o modelo.');
  }
  S._isolarSelecao = isolarSelecao;
  function ocultarSelecao() {
    var si = selInfo(); if (!si) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('olho', 15) : '') + ' Dê dois cliques num elemento do modelo primeiro.'); return; }
    // devolve o material e desseleciona ANTES de esconder — senão o selMat fica preso no mesh oculto
    if (S.selected) { S.selected.material = S.prevMat; S.selected = null; S.prevMat = null; contornoSelecao(null); if (opts.onPick) { try { opts.onPick(null); } catch (_) {} } } // contornoSelecao(null): senão o contorno verde fica flutuando sobre o vazio (gate v1.1.89)
    todasMalhas(function (m) { if (m.userData.mid === si.mid && m.userData.expressID === si.eid) m.visible = false; });
    pav.manual = true; // remover/carregar modelo restaura (nada fica escondido "pra sempre" sem marcador)
    S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('olhoFechado', 15) : '') + ' Elemento oculto. ' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Restaurar tudo (painel 👁) traz de volta.');
  }
  S._ocultarSelecao = ocultarSelecao;
  function isolarTipo() {
    var si = selInfo(); if (!si) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('olho', 15) : '') + ' Dê dois cliques num elemento do modelo primeiro.'); return; }
    todasMalhas(function (m) { m.visible = (m.userData.tipo === si.tipo) && !ehFuturo4d(m) && !ehRemovidoEd(m); });
    pav.isolado = null; pav.manual = true; pavRender();
    if (visiveisEfetivos() === 0) S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('quebracabeca', 15) : '') + ' Só "' + rotuloDisciplina(si.tipo) + '", mas nada visível — o modelo está desligado no painel Modelos. ' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Restaurar tudo volta.');
    else S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('quebracabeca', 15) : '') + ' Mostrando só "' + rotuloDisciplina(si.tipo) + '". ' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Restaurar tudo volta o modelo.');
  }
  S._isolarTipo = isolarTipo;
  // ---- 🫥 RAIO-X: deixa o resto translúcido (não oculto) para ver o que está DENTRO/ATRÁS
  //      (ex.: onde passa cano/eletroduto antes de furar a parede) — material fantasma, restaurável.
  var xray = { on: false, ghosted: [] };
  var _ghostMat = null;
  function ghostMat() { if (!_ghostMat) _ghostMat = new THREE.MeshStandardMaterial({ color: 0x93a7bd, transparent: true, opacity: .1, depthWrite: false, metalness: 0, roughness: 1, side: THREE.DoubleSide }); return _ghostMat; }
  function limparRaioX() { if (!xray.on) return; xray.ghosted.forEach(function (m) { m.material = ehAndamento4d(m) ? S.matAndamento : matBase(m); }); xray.ghosted = []; xray.on = false; } // devolve o âmbar do 4D a quem estava "em andamento" (senão o restore mostra como concluído)
  S._limparRaioX = limparRaioX;
  function aplicarRaioX(ehAlvo, msg) {
    limparRaioX();
    xray.on = true; // ANTES do loop: senão o aborto abaixo chama limparRaioX() com xray.on=false e ele sai no early-return, deixando o modelo translúcido travado (gate v1.1.89)
    var nAlvo = 0;
    todasMalhas(function (m) {
      if (m.userData.expressID == null) return;
      if (ehFuturo4d(m) || ehRemovidoEd(m) || !m.visible) return; // não fantasmiza futuro/removido/já-oculto
      if (ehAlvo(m)) { nAlvo++; return; } // alvo permanece sólido
      m.material = ghostMat(); xray.ghosted.push(m);
    });
    if (!nAlvo) { limparRaioX(); S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('camadas', 15) : '') + ' Nada correspondeu ao alvo do raio-X.'); return 0; } // agora restaura de verdade
    S._hint(msg);
    return nAlvo;
  }
  function raioXSelecao() {
    var si = selInfo(); if (!si) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('olho', 15) : '') + ' Dê dois cliques num elemento primeiro.'); return; }
    aplicarRaioX(function (m) { return m.userData.mid === si.mid && m.userData.expressID === si.eid; }, '' + (typeof Icones !== 'undefined' ? Icones.get('camadas', 15) : '') + ' Raio-X: elemento em destaque, resto translúcido. ' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Restaurar tudo volta.');
    if (S.selected) contornoSelecao(S.selected);
  }
  function raioXTipo() {
    var si = selInfo(); if (!si) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('olho', 15) : '') + ' Dê dois cliques num elemento primeiro.'); return; }
    aplicarRaioX(function (m) { return m.userData.tipo === si.tipo; }, '' + (typeof Icones !== 'undefined' ? Icones.get('camadas', 15) : '') + ' Raio-X de "' + rotuloDisciplina(si.tipo) + '": resto translúcido — bom pra ver onde há cano/eletroduto antes de furar. ' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Restaurar tudo volta.');
  }
  S._raioXSelecao = raioXSelecao; S._raioXTipo = raioXTipo;
  /* raio-X de um GRUPO de peças (disciplina, etapa construtiva — js/bimdisc.js):
     o grupo fica sólido e o resto translúcido, para ver a armação DENTRO da
     sapata ou os painéis sobre a laje sem perder o contexto. Devolve quantas
     malhas ficaram em destaque (0 = nada do grupo está visível). */
  function raioXChaves(chaves, msg) {
    var alvo = {};
    uidsDeChaves(chaves).forEach(function (u) { alvo[u] = 1; });
    return aplicarRaioX(function (m) { return !!alvo[m.userData.mid + ':' + m.userData.expressID]; },
      msg || ('' + (typeof Icones !== 'undefined' ? Icones.get('camadas', 15) : '') + ' Raio-X: o grupo em destaque, o resto translúcido. ' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Restaurar tudo volta.')) || 0;
  }
  S._raioXChaves = raioXChaves;
  visPanel.addEventListener('click', function (e) {
    var b = e.target.closest('[data-v]'); if (!b) return; var k = b.getAttribute('data-v');
    if (k === 'fechar') { visPanel.style.display = 'none'; var bvF = bar.querySelector('[data-b="vis"]'); if (bvF) bvF.style.outline = ''; return; }
    if (k === 'iso') isolarSelecao();
    else if (k === 'occ') ocultarSelecao();
    else if (k === 'tipo') isolarTipo();
    else if (k === 'rx') raioXSelecao();
    else if (k === 'rxt') raioXTipo();
    else if (k === 'tudo') { restaurarVisibilidade(); S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Tudo visível de novo.'); }
  });
  function toggleVisPanel() {
    var abrir = (visPanel.style.display === 'none' || !visPanel.style.display);
    fecharPaineis(abrir ? visPanel : null);
    visPanel.style.display = abrir ? 'flex' : 'none';
    var bv = bar.querySelector('[data-b="vis"]'); if (bv) bv.style.outline = abrir ? '2px solid #15803d' : '';
  }
  // um painel flutuante por vez (snap/pav/vis disputam os cantos da tela)
  function fecharPaineis(exceto) {
    // abrir um painel flutuante fecha o editor (senão o painel nasce ATRÁS dele, invisível)
    if (exceto && edit && edit.on && typeof setEdit === 'function') setEdit(false);
    /* ⚠ o reqPanel entra aqui TAMBEM: painel que abre por cima de outro e
       nao fecha vira caixa presa sem fechador — o mesmo defeito que o
       comentario logo abaixo do re-home descreve. */
    [snapPanel, pavPanel, visPanel, xrPanel, sisPanel, blocokPanel, reqPanel].forEach(function (pn) { if (pn && pn !== exceto) pn.style.display = 'none'; });
    if (blocokPanel !== exceto) { var bbk = bar.querySelector('[data-b="blocok"]'); if (bbk) { bbk.style.background = ''; bbk.style.color = ''; } }
    pintarSnapPanel();
    var bp4 = bar.querySelector('[data-b="pav"]'); if (bp4 && pavPanel.style.display !== 'flex') bp4.style.outline = '';
    var bv2 = bar.querySelector('[data-b="vis"]'); if (bv2 && visPanel.style.display !== 'flex') bv2.style.outline = '';
  }
  S._fecharPaineis = fecharPaineis;

  /* ✕ EM TODOS OS PAINÉIS FLUTUANTES (v1.1.126).
   * O visPanel ganhou o seu no cabeçalho, mas snap/pav/sis/blocok continuavam dependendo
   * do botão que os abriu — que mora dentro do leque do dock e some com a barra recolhida.
   * No celular ainda por cima não existe Esc. Um fechador absoluto no canto de cada painel
   * resolve todos de uma vez, sem tocar no HTML (que alguns montam dinamicamente). */
  function porFechadorNoPainel(pn) {
    if (!pn || pn.querySelector('[data-pnl-fechar]')) return;
    var x = document.createElement('button');
    x.className = 'btn sm';
    x.setAttribute('data-pnl-fechar', '1');
    x.title = 'Fechar este painel';
    x.textContent = '✕';
    x.style.cssText = 'position:absolute;right:7px;top:7px;z-index:2;padding:1px 7px;line-height:1.25;font-size:12px;opacity:.9';
    x.addEventListener('click', function (ev) { ev.stopPropagation(); pn.style.display = 'none'; fecharPaineis(null); });
    // espaço p/ o ✕ não cair em cima do título do painel
    pn.style.paddingRight = '30px';
    pn.appendChild(x);
  }
  [snapPanel, pavPanel, sisPanel, blocokPanel].forEach(function (pn) {
    if (!pn) return;
    porFechadorNoPainel(pn);
    /* Painéis que montam a lista na hora de abrir (pavimentos, sistemas, Blocok) fazem
     * innerHTML = ... e APAGAM o ✕ junto — o fechador sumia justo depois do primeiro uso.
     * O observer devolve o botão sempre que o conteúdo é reescrito. */
    if (typeof MutationObserver === 'function') {
      new MutationObserver(function () { porFechadorNoPainel(pn); }).observe(pn, { childList: true });
    }
  });

  // toolbar com flex-wrap pode ter 2+ linhas em tela estreita: hint/painéis ancoram ABAIXO da
  // altura REAL da barra (o top:52px fixo cobriria a 2ª linha de botões)
  function ajustarTopFlutuantes() {
    // barra recolhida (offsetHeight 0): ancora os painéis abaixo do toggle — que no CELULAR
    // agora vive no PÉ do viewer, então lá os painéis podem colar no topo (t=8).
    var bh = (bar && bar.offsetHeight) || 0;
    var t = bh ? bh + 8 : (ehTelaPequena ? 8 : 44);
    /* ⚠ QUEM MONTA O VIEWER PODE RESERVAR O TOPO. O visor da nuvem (app.js,
       _abrirRVCloud) tem botões fixos lá em cima — 🔄 à direita, Reunião à
       esquerda — por cima de tudo (z 2147483000). Com o painel colado em
       t=8, o 🔄 cobria o ✕ do painel de RA/RV: no iPhone, a pessoa não
       conseguia fechar o painel que abre sozinho. */
    var o0 = (S && S.opts) || opts || {};
    if (o0.topoReservado > t) t = o0.topoReservado;
    [hint, snapPanel, pavPanel, visPanel, xrPanel].forEach(function (el) { if (el) el.style.top = t + 'px'; });
    /* o aviso "Câmera travada" mora em topoReservado+10 (≈28 px de altura):
       com a câmera travada a dica desce para baixo dele — medir com o tablet
       travado na mesa é justamente o caso, e o aviso cobria o começo da frase */
    if (hint && trava.on) hint.style.top = Math.max(t, (o0.topoReservado || 0) + 46) + 'px';
    /* no celular o painel de RA/RV ocupa a largura (até 340 px): em 250 px os
       rótulos dos modos não cabiam nem quebrando linha */
    if (xrPanel) { xrPanel.style.width = ehTelaPequena ? 'calc(100% - 20px)' : '250px'; xrPanel.style.maxWidth = '340px'; xrPanel.style.boxSizing = 'border-box'; }
    /* e a faixa de BAIXO: a barra do visitante mora lá, fixa; sem o teto de
       altura o fim do painel (os últimos modos) ficava atrás dela */
    if (xrPanel && o0.baseReservada > 0) xrPanel.style.maxHeight = 'calc(100% - ' + (t + o0.baseReservada + 10) + 'px)';
    /* v1.1.126: os painéis voltam para a DIREITA (o right:10px do próprio cssText).
     * Em left:64px eles ficavam embaixo do leque do dock (que abre em ~56px com 172px
     * de largura e z-index 60): no PC, passar o mouse na direção do painel fazia o leque
     * saltar na frente e os botões pararem de responder — parecia painel travado.
     * O dock mora à esquerda; à direita não há disputa. */
    /* z-index 7: a gaveta de análise (#bim-drawer) mora em z=6 e encosta na borda
     * direita — com os painéis em z=4 o ✕ e os botões ficavam ATRÁS dela, e o painel
     * voltava a parecer travado. Achado do gate de 25/07. */
    [snapPanel, pavPanel, visPanel, xrPanel].forEach(function (el) { if (el) { el.style.left = "auto"; el.style.right = "10px"; el.style.zIndex = "7"; } });
  }
  S._ajustarTop = ajustarTopFlutuantes;
  ajustarTopFlutuantes();
  window.addEventListener('resize', ajustarTopFlutuantes);

  // ============================================================
  // 📸 FOTO — captura o canvas (render síncrono + toDataURL, funciona com
  // preserveDrawingBuffer:false) e compõe carimbo. O fundo é gradiente CSS
  // (não sai na captura) -> pinta um fundo sólido só durante o render.
  // ============================================================
  // v1.1.82 — thumbnail de UM elemento (banco de famílias / quantitativo ilustrado): salva a
  // visibilidade REAL de cada malha + câmera, isola as malhas do elemento, enquadra pelo AABB,
  // renderiza síncrono (preserveDrawingBuffer=false: render+toDataURL na MESMA task), reduz p/
  // maxPx e RESTAURA tudo (visibilidade por malha — não usa restaurarVisibilidade, que apagaria
  // um isolamento que o usuário tinha feito). Devolve dataURL jpeg ou null.
  function thumbFamilia(uid, maxPx) {
    try {
      if (!S.modelos.length) return null;
      var px = uid.lastIndexOf(':'); if (px < 0) return null;
      var midStr = uid.slice(0, px), eidRaw = uid.slice(px + 1);
      var alvoEid = /^\d+$/.test(eidRaw) ? +eidRaw : eidRaw; // ids do editor são strings 'eN'
      var alvoMid = /^\d+$/.test(midStr) ? +midStr : midStr;
      var mo = modeloDe(alvoMid); if (!mo) return null;
      var elA = (mo.elementos || []).filter(function (e) { return e.id === alvoEid; })[0];
      var aabb = elA && elA.aabb; if (!aabb) return null;
      // snapshot: visibilidade por MALHA (não usa restaurarVisibilidade — apagaria isolamento do usuário)
      // + MATERIAL ORIGINAL das malhas do alvo (seleção verde/4D âmbar/clash não podem sair na foto)
      var visAntes = [], matAntes = [];
      cadaMalha(function (m) {
        visAntes.push([m, m.visible]);
        var ehAlvo = (m.userData.mid === alvoMid && m.userData.expressID === alvoEid);
        m.visible = ehAlvo;
        if (ehAlvo && m.userData.matOrig && m.material !== m.userData.matOrig) { matAntes.push([m, m.material]); m.material = m.userData.matOrig; }
      });
      var gAntes = []; modelRoot.children.forEach(function (g) { gAntes.push([g, g.visible]); g.visible = true; });
      if (S._edgesEstilo) S._edgesEstilo(false); // estilo desenho ligado: sem wireframe preto na foto da família
      // grid, cotas, pins e avatares vivem FORA do modelRoot — esconde (menos as LUZES, senão a foto sai preta)
      var cenaAntes = [];
      scene.children.forEach(function (c) { if (c !== modelRoot && !c.isLight && c.visible) { cenaAntes.push(c); c.visible = false; } });
      var camPos = camera.position.clone(), camNear = camera.near, camFar = camera.far, tgt = orbit.target.clone();
      var clipAntes = renderer.clippingPlanes; renderer.clippingPlanes = [];
      var prevBg = scene.background, thumb = null;
      try {
        var cx = (aabb.min[0] + aabb.max[0]) / 2, cy = (aabb.min[1] + aabb.max[1]) / 2, cz = (aabb.min[2] + aabb.max[2]) / 2;
        var dim = Math.max(aabb.max[0] - aabb.min[0], aabb.max[1] - aabb.min[1], aabb.max[2] - aabb.min[2]) || 1;
        var dist = dim * 1.9;
        camera.position.set(cx + dist * 0.72, cy + dist * 0.5, cz + dist * 0.72);
        camera.near = dim / 100; camera.far = dim * 50; camera.updateProjectionMatrix();
        camera.lookAt(cx, cy, cz);
        scene.background = new THREE.Color(0xf3f6fa); // fundo claro: legível no impresso
        renderer.render(scene, camera); // preserveDrawingBuffer=false → drawImage na MESMA task
        var srcCnv = renderer.domElement, lado = Math.min(srcCnv.width, srcCnv.height);
        var out = document.createElement('canvas'); var mp = maxPx || 220; out.width = mp; out.height = mp;
        out.getContext('2d').drawImage(srcCnv, (srcCnv.width - lado) / 2, (srcCnv.height - lado) / 2, lado, lado, 0, 0, mp, mp);
        thumb = out.toDataURL('image/jpeg', 0.85);
      } catch (_) { thumb = null; }
      // restaura TUDO
      scene.background = prevBg;
      renderer.clippingPlanes = clipAntes;
      matAntes.forEach(function (par) { par[0].material = par[1]; });
      visAntes.forEach(function (par) { par[0].visible = par[1]; });
      gAntes.forEach(function (par) { par[0].visible = par[1]; });
      cenaAntes.forEach(function (c) { c.visible = true; });
      camera.position.copy(camPos); camera.near = camNear; camera.far = camFar; camera.updateProjectionMatrix();
      orbit.target.copy(tgt); orbit.update();
      return thumb;
    } catch (e) { return null; }
  }

  S._thumbFamilia = thumbFamilia;
  S._propsCompletas = function (uid) { // uid 'mid:eid' → grupos de propriedades
    try {
      var px = uid.lastIndexOf(':'); if (px < 0) return [];
      var midStr = uid.slice(0, px), eidRaw2 = uid.slice(px + 1);
      var eid2 = /^\d+$/.test(eidRaw2) ? +eidRaw2 : eidRaw2; // 'eN' do editor é string
      return propsCompletas(/^\d+$/.test(midStr) ? +midStr : midStr, eid2);
    } catch (e) { return []; }
  };

  /* =====================================================================
   * O CARIMBO HONESTO — quantos elementos a imagem está REALMENTE mostrando
   *
   * ⚠ Isto era código dentro do `tirarFoto`. Virou função porque o vídeo do
   *   4D precisa do MESMO carimbo: um quadro de vídeo é tão entregável quanto
   *   um PNG, e nele a vista é filtrada por definição — o 4D esconde o que
   *   ainda não começou. Uma segunda contagem escrita à mão daria dois
   *   números diferentes para a mesma cena, e o do vídeo seria o errado
   *   justamente porque ninguém confere vídeo.
   * ===================================================================== */
  /* =====================================================================
   * QUANTOS ELEMENTOS A CENA ESTÁ REALMENTE MOSTRANDO
   *
   * ⚠ TRÊS VERSÕES ERRADAS ANTES DESTA, e as três só caíram porque foram
   *   MEDIDAS no modelo real (13.229 peças) em vez de raciocinadas:
   *
   *   1. contar montando `visSet[mid + ':' + expressID]` a cada 500 ms —
   *      correto, mas 7,25 ms por chamada contra um quadro de 17,16 ms. Não é
   *      1,45% diluído: é um PICO dentro de UM quadro, que vai de 17 para
   *      24 ms — engasgo visível duas vezes por segundo ao orbitar. O
   *      comentário que eu tinha escrito aqui dizia que "custa nada perto do
   *      render"; a medição disse o contrário.
   *
   *   2. contar as malhas visíveis direto, supondo uma malha por elemento.
   *      NÃO HÁ UMA: geometria multi-material vira várias malhas com o MESMO
   *      expressID. Deu 30.526 num modelo de 13.229 — 2,5× o certo.
   *
   *   3. montar um vetor de "uma malha por elemento" em `rebuildIndices`.
   *      Rápido e ERRADO por outro motivo: a agregação (B2) TROCA as malhas
   *      depois, e o vetor fica apontando para objetos que saíram da cena —
   *      a conta passou a dar 0 com o modelo inteiro na tela.
   *
   * O que sobra é separar as duas perguntas. Contar malha visível é barato
   * (0,15 ms) e não serve como resposta, mas serve como SINAL: se esse número
   * mudou, alguma coisa apareceu ou sumiu, e só então vale pagar a contagem
   * exata. Em repouso o laço custa 0,15 ms a cada 500 ms; a conta cara só
   * acontece no quadro seguinte a uma mudança de verdade.
   * =================================================================== */
  function contarMalhasVisiveis() {
    var n = 0, filhos = modelRoot.children;
    for (var i = 0; i < filhos.length; i++) {
      var g = filhos[i];
      if (g.visible === false) continue;
      var ms = g.children;
      for (var j = 0; j < ms.length; j++) if (ms[j].visible) n++;
    }
    return n;
  }
  function contarVisiveis() {
    var visSet = {};
    modelRoot.children.forEach(function (g) {
      if (g.visible === false) return;
      (g.children || []).forEach(function (m) {
        if (m.visible && m.userData.expressID != null) visSet[m.userData.mid + ':' + m.userData.expressID] = 1;
      });
    });
    return Object.keys(visSet).length;
  }
  function totalElementos() { var t2 = 0; S.modelos.forEach(function (mo) { t2 += mo.nEl || 0; }); return t2; }
  S._contarVisiveis = contarVisiveis;
  S._contarMalhasVisiveis = contarMalhasVisiveis;
  function totalElementos() { var t2 = 0; S.modelos.forEach(function (mo) { t2 += mo.nEl || 0; }); return t2; }
  S._contarVisiveis = contarVisiveis;

  function rotuloElementos() {
    var tot = totalElementos();
    var nv = contarVisiveis();
    /* planta/corte escondem via clippingPlanes (GPU) sem tocar mesh.visible →
       também é vista parcial, e o carimbo tem de dizer */
    var cortado = (renderer.clippingPlanes || []).length > 0;
    return nv < tot ? (nv + ' de ' + tot + ' elementos (vista filtrada)')
      : (cortado ? (tot + ' elementos (vista cortada)') : (tot + ' elementos'));
  }
  S._rotuloElementos = rotuloElementos;

  /* =====================================================================
   * UM QUADRO, DESENHADO NA HORA
   *
   * ⚠ O `preserveDrawingBuffer` é FALSE (bim.js:869), então o conteúdo do
   *   canvas WebGL só é legível no mesmo instante do `render`. É por isso que
   *   o `tirarFoto` faz render e `toDataURL` grudados, e é por isso que o
   *   vídeo não pode usar `captureStream` automático: o compositor do
   *   navegador captura quando quer, e pega quadro em branco.
   *
   * ⚠ E O `requestAnimationFrame` NÃO DISPARA COM A ABA OCULTA. Gravar um
   *   vídeo de 15 s com o usuário olhando outra aba renderizaria zero quadros
   *   e devolveria um arquivo preto — sem erro nenhum. Este gancho desenha
   *   SÍNCRONO, então a gravação anda com a aba escondida.
   *
   * Devolve o canvas do renderer, recém-desenhado, para quem quiser copiar.
   * ===================================================================== */
  function desenharQuadro(fundo) {
    if (!S || !S.alive || !renderer) return null;
    var prevBg = scene.background;
    var vLn = _selLn ? _selLn.visible : null;   /* o contorno de seleção é UI, não entrega */
    try {
      if (fundo) scene.background = new THREE.Color(fundo);
      if (_selLn) _selLn.visible = false;
      renderer.render(scene, camera);
    } catch (e) { return null; }
    finally { scene.background = prevBg; if (_selLn && vLn !== null) _selLn.visible = vLn; }
    return renderer.domElement;
  }
  S._desenharQuadro = desenharQuadro;

  /* ⚠ A FOTO DA PRANCHA NA PROPORÇÃO DO QUADRO DELA. O desenharQuadro devolve
   *   o canvas da tela (1,9:1 num monitor largo); num quadro quase quadrado da
   *   prancha A1 a foto ocupava metade da altura e o título ficava solto lá
   *   embaixo (visto na prancha de painéis de wood frame, 29/09/2026). Aqui o
   *   renderer desenha no tamanho pedido, a imagem é COPIADA NA MESMA HORA
   *   (preserveDrawingBuffer é false: depois do resize o buffer some) e a
   *   tela volta ao tamanho dela.
   * ⚠ A LARGURA DA TELA É O MÍNIMO: quadro mais estreito que a tela ganha
   *   ALTURA (o fov vertical abre), nunca perde as laterais — a vista gravada
   *   foi enquadrada numa tela larga e a cota do comprimento mora na borda.
   * ⚠ SEM O SOLO: o solo da sondagem é ferramenta de estudo e não faz parte
   *   da vista gravada. Ligado na tela, ele entrava na foto da prancha (faixa
   *   vermelha atrás da parede). `semSolo: false` o mantém de propósito. */
  function desenharQuadroEm(fundo, larg, alt, opts) {
    opts = opts || {};
    larg = Math.round(+larg || 0); alt = Math.round(+alt || 0);
    if (!S || !S.alive || !renderer || larg < 8 || alt < 8) return null;
    var prevBg = scene.background, vLn = _selLn ? _selLn.visible : null;
    var vSolo = solo.grupo ? solo.grupo.visible : null;
    var pr = renderer.getPixelRatio(), asp = camera.aspect, fov = camera.fov, out = null;
    try {
      if (fundo) scene.background = new THREE.Color(fundo);
      if (_selLn) _selLn.visible = false;
      if (opts.semSolo !== false && solo.grupo) solo.grupo.visible = false;
      renderer.setPixelRatio(1); renderer.setSize(larg, alt, false);
      var na = larg / alt;
      if (na < asp) camera.fov = 2 * Math.atan(Math.tan(fov * Math.PI / 360) * asp / na) * 180 / Math.PI;
      camera.aspect = na; camera.updateProjectionMatrix();
      renderer.render(scene, camera);
      out = document.createElement('canvas'); out.width = larg; out.height = alt;
      out.getContext('2d').drawImage(renderer.domElement, 0, 0);
    } catch (e) { out = null; }
    finally {
      scene.background = prevBg; if (_selLn && vLn !== null) _selLn.visible = vLn;
      if (solo.grupo && vSolo !== null) solo.grupo.visible = vSolo;
      camera.fov = fov; camera.aspect = asp; camera.updateProjectionMatrix();
      renderer.setPixelRatio(pr);
      if (S._resize) S._resize();
      try { renderer.render(scene, camera); } catch (e2) {}
    }
    return out;
  }
  S._desenharQuadroEm = desenharQuadroEm;

  function tirarFoto() {
    if (!S.modelos.length) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('camera', 15) : '') + ' Carregue um modelo primeiro.'); return null; }
    var prevBg = scene.background, url;
    var vLn = _selLn ? _selLn.visible : null; // o contorno verde de seleção é overlay de UI: não sai no PNG entregável
    try {
      scene.background = new THREE.Color(estiloD.on ? 0xffffff : 0x0d1f33); // estilo desenho: foto sai no branco
      if (_selLn) _selLn.visible = false;
      renderer.render(scene, camera);
      url = renderer.domElement.toDataURL('image/png');
    } catch (_) { url = null; } finally { scene.background = prevBg; if (_selLn && vLn !== null) _selLn.visible = vLn; }
    if (!url) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('camera', 15) : '') + ' Não consegui capturar a imagem.'); return null; }
    var img = new Image();
    img.onload = function () {
      try {
        var faixa = 44, cnv = document.createElement('canvas');
        cnv.width = img.width; cnv.height = img.height + faixa;
        var g2 = cnv.getContext('2d');
        g2.drawImage(img, 0, 0);
        g2.fillStyle = '#0b1a2b'; g2.fillRect(0, img.height, cnv.width, faixa);
        /* o carimbo honesto virou função: o vídeo do 4D usa o MESMO, e duas
           contagens escritas à mão dariam dois números para a mesma cena */
        var rotEl = rotuloElementos();
        g2.fillStyle = '#15803d'; g2.font = 'bold 16px Segoe UI, Arial';
        g2.fillText((((typeof Empresa!=='undefined'&&Empresa.nomeDoc&&Empresa.nomeDoc())||'') ? ((typeof Empresa!=='undefined'&&Empresa.nomeDoc&&Empresa.nomeDoc())||'') + ' · ' : '') + ((typeof Empresa!=='undefined'&&Empresa.creditoTexto&&Empresa.creditoTexto())?'OrçaPRO BIM · ':'') + new Date().toLocaleString('pt-BR') + ' · ' + rotEl + (pav.isolado ? ' · pavimento: ' + pav.isolado : ''), 12, img.height + 28);
        var a2 = document.createElement('a'); a2.href = cnv.toDataURL('image/png'); a2.download = 'bim-foto.png'; a2.click();
        S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('camera', 15) : '') + ' Foto salva (bim-foto.png).');
      } catch (_) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('camera', 15) : '') + ' Não consegui montar o arquivo da foto.'); }
    };
    img.src = url;
    return url; // p/ testes (dataURL do render puro)
  }
  S._tirarFoto = tirarFoto;

  // ============================================================
  // 🥽 RA/RV — Realidade Mista e Virtual (v1.1.84)
  // Andar dentro do modelo em escala REAL (1:1) ou escolhida, medir na
  // escala, cortar a altura de visão, filtrar por DISCIPLINA e — no
  // Android/Chrome — colocar o projeto no ambiente com a câmera (RA).
  // O modo "Caminhar" funciona em QUALQUER aparelho (não exige WebXR),
  // então iPhone/iPad entram por ele. Tudo restaura ao sair.
  // ============================================================
  var EYE = 1.6; // altura dos olhos ao caminhar (m)
  var xr = { on: false, mode: null, escala: 1, session: null, hitSrc: null, reticle: null,
             placed: false, travado: false, prevClip: null, clip: null, prevLocal: false,
             cam: null, look: { yaw: 0, pitch: 0 }, joy: { x: 0, z: 0 }, ori: false, oriBase: null,
             oriQuat: null, oriOk: false, oriYawOff: 0, // v1.1.92 — giroscópio por QUATERNION (device-orientation real)
             boxOrig: null, posOrig: null, // bbox/posição do modelo em escala 1 (âncora da escala)
             modelSnap: null, medir: { on: false, pts: [], objs: [] }, discOcultas: {} };
  S.xr = xr;

  // painel de controle (fica sobre o canvas; entra no re-home)
  var xrPanel = document.createElement('div');
  xrPanel.style.cssText = 'position:absolute;left:10px;top:52px;z-index:5;display:none;flex-direction:column;gap:8px;background:rgba(255,255,255,.985);border:1px solid #d3dce6;border-radius:12px;padding:12px 13px;color:#1a2b3c;font-size:12px;width:250px;max-height:78vh;overflow:auto';
  host.appendChild(xrPanel);
  S.xrPanel = xrPanel;
  // HUD imersivo (joystick + sair + mira) — some quando não está no modo
  var xrHud = document.createElement('div');
  xrHud.style.cssText = 'position:absolute;inset:0;z-index:6;display:none;pointer-events:none';
  // O toggle de ferramentas some enquanto o HUD imersivo está ativo (celular E desktop —
  // no celular o FAB sobreporia a barra de disciplina/medir/sair; no PC evita botão órfão
  // sobre o HUD; mudança intencional de comportamento no PC, v1.1.114).
  try {
    new MutationObserver(function () {
      if (S && S.barToggle) S.barToggle.style.visibility = (xrHud.style.display !== 'none') ? 'hidden' : '';
    }).observe(xrHud, { attributes: true, attributeFilter: ['style'] });
  } catch (eMo) {}
  host.appendChild(xrHud);
  S.xrHud = xrHud;

  function xrSupport(modo) { return !!(navigator.xr && navigator.xr.isSessionSupported) ? navigator.xr.isSessionSupported(modo).catch(function () { return false; }) : Promise.resolve(false); }

  function pintarXRPanel() {
    var box = new THREE.Box3().setFromObject(modelRoot);
    var vazio = box.isEmpty();
    var discs = disciplinasPresentes();
    var html = '<div style="display:flex;justify-content:space-between;align-items:center"><b>' + (typeof Icones !== 'undefined' ? Icones.get('vr', 15) : '') + ' Realidade Mista / Virtual</b><button class="btn sm" data-x="fechar" title="Fechar painel">' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + '</button></div>';
    if (vazio) { html += '<div style="font-size:11px;color:#5b6b7c">Carregue um modelo primeiro.</div>'; xrPanel.innerHTML = html; return; }
    if (!xr.on) {
      /* ⚠ `longo` nos botões de modo: o `.btn` não quebra linha, e a 390 px
         os rótulos saíam cortados dos dois lados ("âmera + Projeto (ver no
         seu ambie") — medido no visor da nuvem aberto como iPhone. */
      var ql = quickLookAqui();
      /* ⚠ O QUE ENTRA NA RA É ESCOLHIDO AQUI, ANTES do modo. A RA do
         iPhone e a do app do Google levam o que está VISÍVEL; sem estes
         controles no seletor, no iPhone não havia como mandar "só a
         Hidráulica" para a RA — os chips só existiam DENTRO do imersivo,
         que o Quick Look nem usa. */
      var pavsXR = (S._pavLista ? S._pavLista() : []).map(function (x) { return x.nome; });
      if (discs.length > 1 || pavsXR.length > 1) {
        html += '<div style="font-size:11px;color:#5b6b7c;margin-top:2px">O que aparece (vale para todos os modos):</div>';
        if (discs.length > 1) {
          html += '<div style="display:flex;flex-wrap:wrap;gap:5px">';
          discs.forEach(function (d) { var off = !!xr.discOcultas[d.chave]; html += '<button class="btn sm" data-xd="' + esc(d.chave) + '" style="' + (off ? 'opacity:.45' : 'background:' + corAtiva() + ';color:#fff') + '">' + esc(d.nome) + '</button>'; });
          html += '</div>';
        }
        if (pavsXR.length > 1) {
          html += '<label style="display:flex;justify-content:space-between;align-items:center;gap:6px">Pavimento <select data-x="pavxr" class="inp" style="flex:1;min-width:0"><option value="">Todos</option>' +
            pavsXR.map(function (nm) { return '<option value="' + esc(nm) + '"' + (pav.isolado === nm ? ' selected' : '') + '>' + esc(nm) + '</option>'; }).join('') + '</select></label>';
        }
      }
      var android = /Android/i.test(navigator.userAgent || '') && !!(S.opts && S.opts.onSceneViewer);
      html += '<button class="btn sm longo" data-x="ratrava" style="width:100%;' + (raTrava ? 'background:#15803d;color:#fff' : '') + '">' +
        (raTrava ? (typeof Icones !== 'undefined' ? Icones.get('cadeado', 15) : '') + ' RA travada: encostar a mão não muda o tamanho nem tira do lugar' : (typeof Icones !== 'undefined' ? Icones.get('destravado', 15) : '') + ' RA livre: a pinça muda o tamanho da maquete') + '</button>';
      html += '<div style="font-size:11px;color:#5b6b7c">Veja o projeto no ambiente ou ande dentro dele. Escolha o modo:</div>' +
        (ql ? '<button class="btn sm primary longo" data-x="quicklook" data-ql="real" style="width:100%">' + (typeof Icones !== 'undefined' ? Icones.get('celular', 15) : '') + ' RA do iPhone — no chão, tamanho real</button>' +
              '<button class="btn sm longo" data-x="quicklook" data-ql="maquete" style="width:100%">' + (typeof Icones !== 'undefined' ? Icones.get('celular', 15) : '') + ' RA do iPhone — maquete na mesa</button>' : '') +
        (android ? '<button class="btn sm primary longo" data-x="sceneviewer" data-ql="real" style="width:100%">' + (typeof Icones !== 'undefined' ? Icones.get('celular', 15) : '') + ' RA do Android (app do Google) — tamanho real</button>' +
                   '<button class="btn sm longo" data-x="sceneviewer" data-ql="maquete" style="width:100%">' + (typeof Icones !== 'undefined' ? Icones.get('celular', 15) : '') + ' RA do Android — maquete na mesa</button>' : '') +
        '<button class="btn sm ' + (ql || android ? '' : 'primary ') + 'longo" data-x="camera" style="width:100%">' + (typeof Icones !== 'undefined' ? Icones.get('camera', 15) : '') + ' Câmera + Projeto (ver no seu ambiente)</button>' +
        '<button class="btn sm longo" data-x="caminhar" style="width:100%">' + (typeof Icones !== 'undefined' ? Icones.get('caminhar', 15) : '') + ' Caminhar no projeto (fundo liso)</button>' +
        (ql ? '' : '<button class="btn sm longo" data-x="ar" style="width:100%" disabled>' + (typeof Icones !== 'undefined' ? Icones.get('celular', 15) : '') + ' RA com âncora (Android) <span data-x="arst" style="color:#5b6b7c">(verificando…)</span></button>') +
        '<button class="btn sm longo" data-x="vr" style="width:100%" disabled>' + (typeof Icones !== 'undefined' ? Icones.get('vr', 15) : '') + ' VR imersivo <span data-x="vrst" style="color:#5b6b7c">(verificando…)</span></button>' +
        (ql
          ? '<div style="font-size:11px;color:#5b6b7c;line-height:1.35"><b>RA do iPhone</b>: abre a realidade aumentada do próprio iPhone — o projeto fica preso no chão enquanto você anda em volta. Nada é instalado e o arquivo não sai do aparelho.</div>'
          : '<div style="font-size:11px;color:#5b6b7c;line-height:1.35">📷 <b>funciona no iPhone e Android</b>: liga a câmera e o projeto aparece no ambiente real — mova o celular pra olhar, joystick pra chegar perto (precisa HTTPS: use o link ' + (typeof Icones !== 'undefined' ? Icones.get('nuvem', 15) : '') + ' da nuvem). ' + (typeof Icones !== 'undefined' ? Icones.get('celular', 15) : '') + ' RA com âncora (fixa no chão): Android com ARCore; no iPhone, pela RA do iPhone.</div>');
    } else {
      var em = xr.mode === 'ar' ? '' + (typeof Icones !== 'undefined' ? Icones.get('celular', 15) : '') + ' RA no ambiente' : xr.mode === 'vr' ? '' + (typeof Icones !== 'undefined' ? Icones.get('vr', 15) : '') + ' VR imersivo' : xr.mode === 'camera' ? '' + (typeof Icones !== 'undefined' ? Icones.get('camera', 15) : '') + ' Câmera + Projeto' : '' + (typeof Icones !== 'undefined' ? Icones.get('caminhar', 15) : '') + ' Caminhando';
      html += '<div style="font-size:11px;color:#15803d"><b>' + em + '</b> ativo</div>';
      // escala — no AR de mesa (hit-test) e agora TAMBÉM no câmera/caminhar (1:1 real OU miniatura na sala)
      if (xr.mode === 'ar') {
        var ESCS = [['1', '1:1 (real)'], ['0.04', '1:25'], ['0.02', '1:50'], ['0.01', '1:100'], ['0.005', '1:200']];
        html += '<label style="display:flex;justify-content:space-between;align-items:center">Escala <select data-x="esc" class="inp" style="width:120px">' +
          ESCS.map(function (o) { return '<option value="' + o[0] + '"' + (Math.abs(parseFloat(o[0]) - (xr.escala || 1)) < 1e-6 ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></label>';
      } else {
        var real = (xr.escala || 1) >= 0.999;
        var ESCS2 = [['1', '1:1 real (andar dentro)'], ['fit', 'Caber na sala (auto)'], ['0.04', '1:25'], ['0.02', '1:50'], ['0.01', '1:100'], ['0.005', '1:200']];
        // seleção: 1:1 se real; senão a numérica mais próxima; senão "fit"
        var selNum = null; if (!real) { for (var _i = 2; _i < ESCS2.length; _i++) { if (Math.abs(parseFloat(ESCS2[_i][0]) - (xr.escala || 1)) < 1e-4) { selNum = ESCS2[_i][0]; break; } } }
        var selVal = real ? '1' : (selNum || 'fit');
        html += '<label style="display:flex;justify-content:space-between;align-items:center">Escala <select data-x="esc2" class="inp" style="width:150px">' +
          ESCS2.map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === selVal ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></label>' +
          '<div style="display:flex;gap:6px">' +
          '<button class="btn sm" data-x="centralizar" style="flex:1">' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' Centralizar</button>' +
          '<button class="btn sm" data-x="travarcam" style="flex:1">' + (xr.travado ? '' + (typeof Icones !== 'undefined' ? Icones.get('destravado', 15) : '') + ' Destravar' : '' + (typeof Icones !== 'undefined' ? Icones.get('cadeado', 15) : '') + ' Travar') + '</button></div>' +
          '<div style="font-size:11px;color:#5b6b7c;line-height:1.3">1:1 = andar DENTRO em tamanho real. Miniatura = ver o projeto inteiro na sua frente. ' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' recoloca à frente; ' + (typeof Icones !== 'undefined' ? Icones.get('cadeado', 15) : '') + ' fixa no lugar.</div>';
      }
      // altura do corte de visão (reflete o valor atual — não reseta no repaint)
      var cf = (xr.cortefrac == null ? 1000 : xr.cortefrac);
      html += '<div style="display:flex;justify-content:space-between;align-items:baseline"><span>' + (typeof Icones !== 'undefined' ? Icones.get('corte', 15) : '') + ' Teto de visão</span><span data-x="cortev" style="color:#15803d">' + (cf >= 999 ? 'inteiro' : '') + '</span></div>' +
        '<input type="range" data-x="corte" min="0" max="1000" value="' + cf + '" style="width:100%;accent-color:#22c55e">';
      // passos: sensibilidade (só caminhar/câmera — no AR a locomoção é do WebXR). Tablet precisa de mais
      // sensibilidade (movimento gentil); o usuário ajusta se não anda ou anda demais.
      if (xr.mode !== 'ar' && xr.mode !== 'vr') {
        var ps = Math.round(_passSens() * 100); // valor REAL (localStorage c/ fallback), não o default fixo — bate com o aplicado
        html += '<div style="display:flex;justify-content:space-between;align-items:baseline"><span>' + (typeof Icones !== 'undefined' ? Icones.get('caminhar', 15) : '') + ' Sensibilidade dos passos</span><span data-x="passv" style="color:#15803d">' + (ps / 100).toFixed(1) + '×</span></div>' +
          '<input type="range" data-x="passsens" min="40" max="300" value="' + ps + '" style="width:100%;accent-color:#0d9488">' +
          '<div style="font-size:10.5px;color:#5b6b7c;line-height:1.25;margin-top:-2px">Ande com o aparelho na mão pra andar no projeto. Se o projeto não anda, <b>aumente</b>; se anda sozinho, <b>diminua</b>. (No tablet costuma precisar mais.)</div>';
      }
      // medir
      html += '<button class="btn sm" data-x="medir" style="width:100%">' + (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '') + ' Medir na escala (toque 2 pontos)</button>';
      // disciplinas
      if (discs.length > 1) {
        html += '<div style="font-size:11px;color:#5b6b7c;margin-top:2px">Disciplinas (toque pra ligar/desligar):</div><div style="display:flex;flex-wrap:wrap;gap:5px">';
        discs.forEach(function (d) {
          var off = !!xr.discOcultas[d.chave];
          html += '<button class="btn sm" data-xd="' + esc(d.chave) + '" style="' + (off ? 'opacity:.45' : 'background:' + corAtiva() + ';color:#fff') + '">' + esc(d.nome) + '</button>';
        });
        html += '</div>';
      }
      if (xr.mode === 'ar') {
        html += '<button class="btn sm" data-x="travar" style="width:100%">' + (xr.travado ? '' + (typeof Icones !== 'undefined' ? Icones.get('destravado', 15) : '') + ' Destravar do ponto' : '' + (typeof Icones !== 'undefined' ? Icones.get('cadeado', 15) : '') + ' Travar neste ponto') + '</button>' +
          '<div style="font-size:11px;color:#5b6b7c;line-height:1.3">Aponte pro chão, toque pra fixar o projeto no lugar real; trave pra ele não sair do lugar.</div>';
      }
      html += '<button class="btn sm" data-x="sair" style="width:100%">⏹ Sair do imersivo</button>';
    }
    xrPanel.innerHTML = html;
    if (!xr.on && !vazio) {
      // habilita VR/AR conforme suporte real do aparelho
      xrSupport('immersive-vr').then(function (ok) { var b = xrPanel.querySelector('[data-x="vr"]'), st = xrPanel.querySelector('[data-x="vrst"]'); if (!b) return; b.disabled = !ok; if (st) st.textContent = ok ? '' : '(indisponível aqui)'; });
      xrSupport('immersive-ar').then(function (ok) { var b = xrPanel.querySelector('[data-x="ar"]'), st = xrPanel.querySelector('[data-x="arst"]'); if (!b) return; b.disabled = !ok; if (st) st.textContent = ok ? '' : '(precisa Android/ARCore)'; });
    }
  }
  function disciplinasPresentes() {
    var mapa = {};
    S.modelos.forEach(function (mo) { var d = (mo.disciplina || 'outros'); if (!mapa[d]) mapa[d] = { chave: d, nome: nomeDisc(d), n: 0 }; mapa[d].n += mo.elementos.length; });
    return Object.keys(mapa).map(function (k) { return mapa[k]; });
  }
  function nomeDisc(d) { var M = { arquitetura: 'Arquitetura', estrutura: 'Estrutura', hidraulica: 'Hidráulica', eletrica: 'Elétrica', mecanica: 'Mecânica', incendio: 'Incêndio', outros: 'Outros' }; return M[d] || (d.charAt(0).toUpperCase() + d.slice(1)); }

  // ---- 📱 RA DO iPHONE (AR Quick Look) — o motor é js/bimusdz.js; aqui só a cena e o clique ----
  function quickLookAqui() {
    if (typeof window === 'undefined' || !window.BimUsdz) return false;
    var a = document.createElement('a');
    var rel = false; try { rel = !!(a.relList && a.relList.supports && a.relList.supports('ar')); } catch (_) {}
    return BimUsdz.quickLook({ ua: navigator.userAgent, plataforma: navigator.platform, toques: navigator.maxTouchPoints || 0,
      relAr: rel, webview: !!(window.webkit && window.webkit.messageHandlers) });
  }
  /* O que vai para o iPhone é O QUE ESTÁ NA TELA: disciplina desligada,
     pavimento isolado e peça escondida ficam de fora (traverseVisible).
     A matriz é relativa ao modelRoot — no imersivo ele anda e escala, e o
     arquivo tem de sair no tamanho do projeto, não no da miniatura. */
  function pecasVisiveis() {
    modelRoot.updateMatrixWorld(true);
    var inv = new THREE.Matrix4().copy(modelRoot.matrixWorld).invert(), rel = new THREE.Matrix4(), out = [];
    modelRoot.traverseVisible(function (o) {
      if (!o.isMesh || o.isInstancedMesh || !o.geometry || !o.geometry.attributes) return;
      var pa = o.geometry.attributes.position, na = o.geometry.attributes.normal;
      if (!pa || pa.isInterleavedBufferAttribute || pa.count < 3) return;
      var mat = Array.isArray(o.material) ? o.material[0] : o.material;
      if (!mat || mat.visible === false || mat.colorWrite === false) return;
      var cor = (o.userData && o.userData.matOrig && o.userData.matOrig.color && o.material === selMat) ? o.userData.matOrig : mat; // peça SELECIONADA vai com a cor dela, não o verde da seleção
      var op = mat.transparent ? (mat.opacity == null ? 1 : mat.opacity) : 1;
      if (op < 0.05) return;
      var idx = o.geometry.index ? o.geometry.index.array : null;
      if (!idx) { idx = new Uint32Array(pa.count); for (var i = 0; i < pa.count; i++) idx[i] = i; }
      rel.multiplyMatrices(inv, o.matrixWorld);
      out.push({ cor: [cor.color ? cor.color.r : 0.8, cor.color ? cor.color.g : 0.8, cor.color ? cor.color.b : 0.8, op],
        pos: pa.array, nor: (na && !na.isInterleavedBufferAttribute) ? na.array : null, idx: idx, matriz: rel.elements.slice() });
    });
    return out;
  }
  var _ql = null; // { chave, url } — o mesmo arquivo serve ao segundo toque
  function abrirQuickLook(modo, btn) {
    var pecas = pecasVisiveis(), tri = 0;
    pecas.forEach(function (p) { tri += Math.floor(p.idx.length / 3); });
    var chave = modo + '|' + pecas.length + '|' + tri;
    if (_ql && _ql.chave === chave) { dispararQuickLook(_ql.url); return; }
    var rot = btn ? btn.innerHTML : '';
    if (btn) { btn.disabled = true; btn.textContent = 'Montando o arquivo da RA…'; }
    // setTimeout: deixa o botão mostrar o "montando" antes do trabalho pesado
    setTimeout(function () {
      var r;
      try { r = BimUsdz.gerar(pecas, { modo: modo }); } catch (e) { r = { ok: false, erro: String(e && e.message || e) }; }
      if (btn) { btn.disabled = false; btn.innerHTML = rot; }
      S._qlUltimo = { ok: r.ok, erro: r.erro || '', tri: r.tri || 0, malhas: r.malhas || 0, bytes: r.ok ? r.bytes.length : 0, modo: modo };
      if (!r.ok) {
        S._hint(r.erro === 'grande'
          ? 'Este modelo tem ' + Math.round(r.tri / 1000) + ' mil triângulos visíveis; a RA do iPhone aguenta até ' + Math.round(r.limite / 1000) + ' mil. Desligue disciplinas (ex.: deixe só a Arquitetura) e toque de novo — ou use Caminhar.'
          : r.erro === 'vazio' ? 'Nada visível para mostrar. Ligue ao menos uma disciplina.'
          : 'Não consegui montar o arquivo da RA: ' + r.erro);
        return;
      }
      var url = URL.createObjectURL(new Blob([r.bytes], { type: 'model/vnd.usdz+zip' }));
      if (_ql) { try { URL.revokeObjectURL(_ql.url); } catch (_) {} }
      _ql = { chave: chave, url: url };
      dispararQuickLook(url);
    }, 40);
  }
  /* ⚠ O LINK TEM DE SER <a rel="ar"> COM UMA <img> DENTRO — é assim que o
     Safari decide abrir o Quick Look em vez de baixar o arquivo. O
     `download` segue o <model-viewer> do Google para arquivo gerado na hora
     (blob:), que é o nosso caso. Clique depois de montar (assíncrono)
     funciona: o Quick Look não é janela nova, não precisa do gesto. */
  /* ⚠ TRAVA DA RA — uma só para os três caminhos, ligada por padrão e
     guardada no aparelho. No iPhone a tela é a do AR Quick Look (da Apple): o
     que ela deixa travar é a pinça de TAMANHO (allowsContentScaling=0) —
     girar e arrastar a Apple não deixa. No app do Google é o resizable=false.
     Na RA do próprio OrçaPRO, a maquete fica presa no lugar ao ser fixada. */
  var raTrava = true;
  try { raTrava = localStorage.getItem('orcapro:bim:raTrava') !== '0'; } catch (_) {}
  S._raTravada = function () { return raTrava; };
  function dispararQuickLook(url) {
    var a = document.createElement('a');
    a.setAttribute('rel', 'ar');
    a.setAttribute('href', url + (raTrava ? '#allowsContentScaling=0' : ''));
    a.setAttribute('download', 'projeto.usdz');
    a.appendChild(document.createElement('img'));
    a.style.display = 'none';
    document.body.appendChild(a);
    S._qlDisparos = (S._qlDisparos || 0) + 1;
    a.click();
    setTimeout(function () { try { a.remove(); } catch (_) {} }, 1500);
  }

  /* o arquivo da RA nativa a partir do que está NA TELA — .usdz (iPhone) ou
     .glb (app do Google no Android). Motor em js/bimusdz.js. */
  function arquivoRA(formato, modo) {
    if (!window.BimUsdz) return { ok: false, erro: 'motor da RA não carregou' };
    var pecas = pecasVisiveis();
    try { return formato === 'glb' ? BimUsdz.gerarGlb(pecas, { modo: modo }) : BimUsdz.gerar(pecas, { modo: modo }); }
    catch (e) { return { ok: false, erro: String(e && e.message || e) }; }
  }
  S._arquivoRA = arquivoRA;

  function toggleXRPanel() {
    if (xrPanel.style.display === 'flex') { xrPanel.style.display = 'none'; return; }
    if (S._fecharPaineis) S._fecharPaineis(xrPanel);
    pintarXRPanel(); xrPanel.style.display = 'flex';
    if (S._ajustarTop) S._ajustarTop();
  }
  S._toggleXR = toggleXRPanel;

  // ---- qualidade: sombras só no imersivo e só se o modelo não for gigante ----
  function ligarSombras(on) {
    var tri = 0; S.modelos.forEach(function (mo) { tri += mo.nTri || 0; });
    if (on && tri > 1800000) return false; // modelo pesado: sombra travaria — segue sem
    dir.castShadow = !!on;
    todasMalhas(function (m) { if (m.geometry) { m.castShadow = !!on; m.receiveShadow = !!on; } });
    /* ⚠ a malha MESCLADA é o que a câmera desenha (as peças acima estão na camada do clique): sem ela, a sombra do imersivo
       não aparecia desde a agregação — achado no modo foto do içamento (02/10/2026) */
    S.modelos.forEach(function (mo) { if (mo._agreg && mo._agreg.grupo) mo._agreg.grupo.traverse(function (m) { if (m.isMesh) { m.castShadow = !!on; m.receiveShadow = !!on; } }); });
    return true;
  }

  // ---- escala: só na RA de mesa (AR). Andar/VR é sempre 1:1 (escala real) — escalar o
  // modelRoot em torno da origem no Caminhar jogava a câmera pra fora do modelo (achado do gate).
  function aplicarEscalaXR(f) {
    if (xr.mode !== 'ar') { xr.escala = 1; return; } // AR de mesa tem seu próprio fluxo (hit-test)
    xr.escala = f || 1;
    if (xr.placed) posicionarModeloAR();
  }

  // ---- ESCALA + ÂNCORA no modo CÂMERA/CAMINHAR (iPhone/Android sem WebXR): 1:1 real (andar DENTRO)
  //      ou miniatura na sua frente. Escala em torno de uma ÂNCORA (ponto à frente), NÃO da origem —
  //      escalar na origem jogava a câmera pra fora do modelo (achado do gate). modelRoot fica na
  //      origem durante o imersivo (posOrig restaurado ao sair), então world = position + escala*local. ----
  var _imFwd = new THREE.Vector3(), _imC = new THREE.Vector3();
  function fitEscala() { // escala que faz o modelo caber ~2,2 m à frente (miniatura de sala)
    var b = xr.boxLocal; if (!b) return 0.02;
    var d = b.getSize(new THREE.Vector3()), maior = Math.max(d.x, d.y, d.z) || 1;
    return Math.max(0.002, Math.min(1, 2.2 / maior));
  }
  function posicionarNaFrente(dist) {
    var b = xr.boxLocal; if (!b) return;
    var s = xr.escala || 1;
    camera.getWorldDirection(_imFwd); _imFwd.y = 0; if (_imFwd.lengthSq() < 1e-6) _imFwd.set(0, 0, -1); _imFwd.normalize();
    var pisoY = camera.position.y - EYE; // chão sob os olhos (altura real do usuário)
    var ax = camera.position.x + _imFwd.x * dist, az = camera.position.z + _imFwd.z * dist;
    b.getCenter(_imC);
    modelRoot.position.set(ax - s * _imC.x, pisoY - s * b.min.y, az - s * _imC.z); // base-centro do modelo cai em (ax, pisoY, az)
    xr._pisoY = pisoY;
  }
  function aplicarEscalaImersivo(f) {
    if (xr.mode === 'ar') { aplicarEscalaXR(f); return; }
    if (!xr.on || !xr.boxLocal) return; // só no imersivo câmera/caminhar
    if (xr.travado) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('cadeado', 15) : '') + ' Destrave pra mudar a escala.'); pintarXRPanel(); return; } // repinta pro <select> voltar ao valor real
    xr.escala = f > 0 ? f : 1;
    modelRoot.scale.setScalar(xr.escala);
    if (xr.escala >= 0.999) { // 1:1 real: modelo nas coords locais, câmera no piso do centro (andar DENTRO)
      modelRoot.position.set(0, 0, 0);
      xr.boxLocal.getCenter(_imC);
      camera.position.set(_imC.x, xr.boxLocal.min.y + EYE, _imC.z);
      xr._pisoY = xr.boxLocal.min.y;
      xrDica('Escala real 1:1 — você está DENTRO do projeto. Vire o celular; ande com o joystick.');
    } else { // miniatura à frente (na sua sala)
      posicionarNaFrente(2.0);
      xrDica('Miniatura na sua frente. Vire o celular pra olhar; ' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' recentraliza; joystick pra rodear.');
    }
    if (xr.cortefrac != null && xr.cortefrac < 999) aplicarTetoVisao(xr.cortefrac / 1000); // recalcula o teto de visão p/ a nova escala (senão o corte fica na altura de mundo antiga e some o modelo)
  }
  S._aplicarEscalaImersivo = aplicarEscalaImersivo;
  function centralizarProjeto() {
    if (xr.mode === 'ar') { if (!xr.travado) { xr.placed = false; xrDica('Aponte pro chão e toque pra fixar de novo.'); } else S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('cadeado', 15) : '') + ' Destrave pra reposicionar.'); return; }
    if (!xr.on || !xr.boxLocal) return; // simétrico com aplicarEscalaImersivo: fora do imersivo câmera/caminhar não faz nada
    if (xr.travado) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('cadeado', 15) : '') + ' Destrave pra reposicionar.'); return; }
    if (xr.escala >= 0.999) { xr.boxLocal.getCenter(_imC); camera.position.set(_imC.x, xr.boxLocal.min.y + EYE, _imC.z); xr._pisoY = xr.boxLocal.min.y; }
    else posicionarNaFrente(2.0);
    S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' Projeto recolocado à sua frente.');
  }
  S._centralizarImersivo = centralizarProjeto;
  // re-snapshot da âncora (boxLocal) quando modelos entram/saem DURANTE o imersivo câmera/caminhar —
  // senão centralizar/escala ancoram no bbox antigo. Se ficou sem geometria, sai do imersivo.
  function xrReSnap() {
    if (!xr.on || xr.mode === 'ar' || xr.mode === 'vr') return;
    var p = modelRoot.position.clone(), s = modelRoot.scale.clone();
    modelRoot.position.set(0, 0, 0); modelRoot.scale.setScalar(1); modelRoot.updateMatrixWorld(true);
    var b = new THREE.Box3().setFromObject(modelRoot);
    modelRoot.position.copy(p); modelRoot.scale.copy(s); modelRoot.updateMatrixWorld(true);
    if (b.isEmpty()) { sairImersivo(); return; }
    xr.boxLocal = b.clone();
    aplicarEscalaImersivo(xr.escala || 1); // reancora na escala corrente
  }
  S._xrReSnap = xrReSnap;

  // ---- teto de visão (corte horizontal que esconde o que está acima) ----
  function aplicarTetoVisao(frac) {
    var box = new THREE.Box3().setFromObject(modelRoot); if (box.isEmpty()) return;
    xr.cortefrac = Math.round(frac * 1000); // lembra a posição p/ o repaint não resetar
    var y = box.min.y + (box.max.y - box.min.y) * frac;
    var rot = xrPanel.querySelector('[data-x="cortev"]');
    if (frac >= 0.999) { var walk = (xr.mode !== 'ar' && xr.mode !== 'vr'); renderer.clippingPlanes = walk ? [] : (xr.prevClip || []); renderer.localClippingEnabled = walk ? false : xr.prevLocal; if (rot) rot.textContent = 'inteiro'; return; } // no Caminhar/Câmera "inteiro" = modelo inteiro (não reinstala o corte da planta)
    if (!xr.clip) xr.clip = new THREE.Plane(new THREE.Vector3(0, -1, 0), 0);
    xr.clip.constant = y;
    renderer.localClippingEnabled = true; renderer.clippingPlanes = [xr.clip];
    if (rot) rot.textContent = fmtDist(Math.max(0, y - box.min.y) / (xr.escala || 1)) + ' do piso'; // metro REAL (divide pela escala do AR)
  }

  // ---- HUD: joystick de andar + mira + (no AR) barra de disciplina/medir/sair ----
  // No AR imersivo SÓ o dom-overlay (xrHud) aparece — o xrPanel de config fica invisível.
  // Então as ferramentas essenciais da obra (disciplina, medir, sair) vão pra CÁ.
  function montarHud(comReticulo) {
    // barra compacta de ferramentas SEMPRE (Caminhar E AR) — no celular o painel grande de config
    // tampa a vista, então as ações essenciais (disciplina/medir/ajustes/sair) ficam nesta barra.
    var discs = disciplinasPresentes();
    var chips = discs.length > 1 ? discs.map(function (d) { var off = !!xr.discOcultas[d.chave]; return '<button data-har="' + esc(d.chave) + '" style="pointer-events:auto;border:0;border-radius:14px;padding:7px 11px;font-size:12px;color:#fff;background:' + (off ? 'rgba(90,110,130,.7)' : corAtiva()) + '">' + esc(d.nome) + '</button>'; }).join('') : '';
    /* ⚠ AS FERRAMENTAS NUMA COLUNA AO LADO DO MODELO (pedido de 30/09/2026):
       a fileira de baixo competia com a mão de quem segura o celular e com a
       maquete na mesa. Embaixo ficam só as disciplinas (filtro). */
    var passosOn = !!(xr._pass && xr._pass.on);
    function bt(k, ico, rot, bg, cor) {
      return '<button data-har="' + k + '" style="pointer-events:auto;border:0;border-radius:12px;width:68px;min-height:52px;padding:5px 2px;font-size:10.5px;line-height:1.15;color:' + (cor || '#fff') + ';background:' + bg +
        ';font-weight:700;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;touch-action:manipulation">' + (typeof Icones !== 'undefined' ? Icones.get(ico, 18) : '') + '<span>' + rot + '</span></button>';
    }
    var barra = '<div data-h="lateral" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;gap:6px;max-height:calc(100% - 130px);overflow-y:auto;pointer-events:auto;padding:6px;background:rgba(11,26,43,.55);border-radius:14px">' +
      (comReticulo ? bt('trava', xr.travado ? 'cadeado' : 'destravado', xr.travado ? 'Travado' : 'Livre', xr.travado ? '#15803d' : '#b45309') : '') +
      bt('medir', 'medir', 'Medir', xr.medir.on ? '#b45309' : '#15803d', xr.medir.on ? '#fff' : '#0b1a2b') +
      bt('centralizar', 'alvo', 'Centralizar', '#2563eb') +
      // Passos SÓ em Caminhar/Câmera (no AR a locomoção é do WebXR, o botão seria morto). Rótulo reflete
      // o estado REAL (listener ativo) — nunca mostra "on" sem sensor ligado (gate v1.1.93).
      (comReticulo ? '' : bt('passos', 'caminhar', 'Passos: ' + (passosOn ? 'on' : 'off'), passosOn ? '#0d9488' : 'rgba(90,110,130,.7)')) +
      bt('sistema', 'paleta', 'Cores', sisColor.on ? corAtiva() : '#334a63') +
      bt('ajustes', 'ajustes', 'Ajustes', '#334a63') +
      bt('sair', 'fechar', 'Sair', '#b91c1c') + '</div>' +
      (chips ? '<div style="position:absolute;left:0;right:0;bottom:16px;display:flex;flex-wrap:wrap;gap:6px;justify-content:center;padding:0 92px 0 10px">' + chips + '</div>' : '');
    xrHud.innerHTML =
      (comReticulo ? '' : '<div data-h="joy" style="position:absolute;left:16px;bottom:60px;width:108px;height:108px;border-radius:50%;background:rgba(20,40,64,.4);border:2px solid rgba(127,224,163,.5);pointer-events:auto;touch-action:none">' +
      '<div data-h="knob" style="position:absolute;left:31px;top:31px;width:46px;height:46px;border-radius:50%;background:rgba(127,224,163,.85)"></div></div>') +
      (comReticulo ? '<div style="position:absolute;left:50%;top:50%;width:22px;height:22px;margin:-11px 0 0 -11px;border:2px solid #15803d;border-radius:50%;box-shadow:0 0 0 1px rgba(0,0,0,.4)"></div>' : '') +
      barra +
      (S._montarLegendaChips ? S._montarLegendaChips() : '') + // legenda de cores por sistema (só quando o modo está ligado)
      '<div style="position:absolute;left:0;right:0;top:0;display:flex;justify-content:center;pointer-events:none"><div data-h="dica" style="margin-top:8px;background:rgba(11,26,43,.82);color:#1a2b3c;font-size:12px;padding:5px 12px;border-radius:20px;max-width:88%;text-align:center"></div></div>';
    xrHud.style.display = 'block';
    if (!comReticulo) ligarJoystick();
  }
  // cliques da barra (disciplina/medir/ajustes/sair) — no dom-overlay do imersivo
  xrHud.addEventListener('click', function (e) {
    var b = e.target.closest('[data-har]'); if (!b) return; var k = b.getAttribute('data-har');
    if (k === 'sair') sairImersivo();
    else if (k === 'trava') { xr.travado = !xr.travado; if (xr.reticle) xr.reticle.visible = false; pintarTravaHud(); xrDica(xr.travado ? 'Travado: a maquete não sai do lugar.' : 'Livre: use "Centralizar" (ou Ajustes → reposicionar) para mover.'); }
    else if (k === 'centralizar') centralizarProjeto();
    else if (k === 'passos') {
      if (xr._passH) { xr._pass.on = !xr._pass.on; _syncPassosHud(xr._pass.on ? 'Andar com o celular na mão move você no projeto (por passos).' : 'Passos desligados — use o joystick.'); }
      else { ligarPassos(); } // sem listener (permissão negada/pendente) → re-tenta de fato em vez de mentir "on"
    }
    else if (k === 'medir') { xr.medir.on = !xr.medir.on; if (!xr.medir.on) limparMedirXR(); b.style.background = xr.medir.on ? '#b45309' : '#15803d'; xrDica(xr.medir.on ? '' + (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '') + ' Toque em 2 pontos do modelo pra medir na escala.' : ''); } // limpa as medições ao desligar (paridade com o painel)
    else if (k === 'ajustes') { var aberto = xrPanel.style.display === 'flex'; if (aberto) { xrPanel.style.display = 'none'; } else { pintarXRPanel(); xrPanel.style.display = 'flex'; if (S._ajustarTop) S._ajustarTop(); } }
    else if (k === 'sistema') { if (S._setSistema) S._setSistema(!(S._sisColorOn && S._sisColorOn())); } // recolore por sistema; _sisImersivoSync remonta o HUD (botão + legenda)
    else { toggleDisciplinaXR(k); var off = !!xr.discOcultas[k]; b.style.background = off ? 'rgba(90,110,130,.7)' : corAtiva(); }
  });
  // atualiza SÓ o botão 🎨 + a legenda de chips do imersivo quando o modo por-sistema muda
  // (update cirúrgico, sem remontar o HUD inteiro — não reseta joystick nem o estado do 📏 Medir)
  S._sisImersivoSync = function () {
    if (!(xr.on && xrHud.style.display !== 'none')) return;
    var b = xrHud.querySelector('[data-har="sistema"]'); if (b) b.style.background = S._sisColorOn && S._sisColorOn() ? corAtiva() : '#c9d5e1';
    var leg = xrHud.querySelector('[data-h="sisleg"]'); if (leg && leg.parentNode) leg.parentNode.removeChild(leg);
    if (S._sisColorOn && S._sisColorOn() && S._montarLegendaChips) { var html = S._montarLegendaChips(); if (html) xrHud.insertAdjacentHTML('beforeend', html); }
  };
  function xrDica(t) { var d = xrHud.querySelector('[data-h="dica"]'); if (d) d.textContent = t || ''; }
  // espelha no botão do HUD o estado REAL dos passos (listener ativo) — evita "on" mentiroso quando a
  // permissão de Movimento foi negada/está pendente no iOS (gate v1.1.93).
  function _syncPassosHud(dica) {
    var b = xrHud.querySelector('[data-har="passos"]');
    /* ⚠ innerHTML com o ícone: o textContent de antes jogava o CÓDIGO do SVG na tela */
    if (b) { var on = !!(xr._pass && xr._pass.on); b.innerHTML = (typeof Icones !== 'undefined' ? Icones.get('caminhar', 18) : '') + '<span>Passos: ' + (on ? 'on' : 'off') + '</span>'; b.style.background = on ? '#0d9488' : 'rgba(90,110,130,.7)'; }
    if (dica) xrDica(dica);
  }
  S._xrPassosHud = function (n) { var b = xrHud.querySelector('[data-har="passos"] span'); if (b && xr._pass && xr._pass.on) b.textContent = n + ' passos'; };
  function pintarTravaHud() {
    var b = xrHud.querySelector('[data-har="trava"]'); if (!b) return;
    b.innerHTML = (typeof Icones !== 'undefined' ? Icones.get(xr.travado ? 'cadeado' : 'destravado', 18) : '') + '<span>' + (xr.travado ? 'Travado' : 'Livre') + '</span>';
    b.style.background = xr.travado ? '#15803d' : '#b45309';
  }
  function ligarJoystick() {
    var joy = xrHud.querySelector('[data-h="joy"]'), knob = xrHud.querySelector('[data-h="knob"]');
    if (!joy) return;
    var ativo = false, cx = 60, cy = 60, R = 42;
    function set(px, py) {
      var dx = px - cx, dy = py - cy, d = Math.sqrt(dx * dx + dy * dy) || 1;
      if (d > R) { dx = dx / d * R; dy = dy / d * R; }
      knob.style.left = (35 + dx) + 'px'; knob.style.top = (35 + dy) + 'px';
      xr.joy.x = dx / R; xr.joy.z = dy / R; // x=strafe, z=frente(-)/trás(+)
    }
    function pos(e) { var r = joy.getBoundingClientRect(), t = e.touches ? e.touches[0] : e; return [t.clientX - r.left, t.clientY - r.top]; }
    joy.addEventListener('pointerdown', function (e) { ativo = true; joy.setPointerCapture && joy.setPointerCapture(e.pointerId); var p = pos(e); set(p[0], p[1]); e.preventDefault(); });
    joy.addEventListener('pointermove', function (e) { if (!ativo) return; var p = pos(e); set(p[0], p[1]); e.preventDefault(); });
    var solta = function () { ativo = false; xr.joy.x = 0; xr.joy.z = 0; knob.style.left = '35px'; knob.style.top = '35px'; };
    joy.addEventListener('pointerup', solta); joy.addEventListener('pointercancel', solta);
  }

  // ---- olhar arrastando (não-XR): drag no canvas gira a câmera ----
  var xrDrag = null;
  function xrPointerDown(e) { if (!xr.on || xr.mode === 'ar' || xr.mode === 'vr') return; if (xr.medir.on) { medirTocar(e); return; } xrDrag = { x: e.clientX, y: e.clientY }; }
  function xrPointerMove(e) {
    if (!xrDrag) return;
    if (xr.oriOk) { xr.oriYawOff -= (e.clientX - xrDrag.x) * 0.005; } // com giroscópio: arrastar na horizontal RECENTRALIZA (o pitch vem do aparelho)
    else { xr.look.yaw -= (e.clientX - xrDrag.x) * 0.005; xr.look.pitch -= (e.clientY - xrDrag.y) * 0.005; xr.look.pitch = Math.max(-1.4, Math.min(1.4, xr.look.pitch)); }
    xrDrag = { x: e.clientX, y: e.clientY };
  }
  function xrPointerUp() { xrDrag = null; }

  // ---- orientação do aparelho: giroscópio REAL por QUATERNION (fórmula do DeviceOrientationControls
  //      do three.js). O jeito antigo (só yaw a partir de alpha + pitch de beta) IGNORAVA gamma e a
  //      orientação da tela → a câmera "bugava" ao inclinar/girar o celular. Agora acompanha os 3 eixos. ----
  var _oriZee = new THREE.Vector3(0, 0, 1);
  var _oriEul = new THREE.Euler();
  var _oriQ0 = new THREE.Quaternion();
  var _oriQ1 = new THREE.Quaternion(-Math.sqrt(0.5), 0, 0, Math.sqrt(0.5)); // -90° em X: a câmera aponta pra "fora" do fundo do aparelho
  var _oriYaw = new THREE.Quaternion(); // offset de recentragem (horizontal), aplicado em torno do Y do MUNDO
  var _oriUp = new THREE.Vector3(0, 1, 0);
  function _screenAngRad() { var a = 0; try { a = (window.screen && screen.orientation && typeof screen.orientation.angle === 'number') ? screen.orientation.angle : (window.orientation || 0); } catch (e) {} return (a || 0) * Math.PI / 180; }
  // iOS exige que DeviceOrientation/Motion.requestPermission rode DENTRO do gesto de toque. No modo
  // Câmera+Projeto, ligarOrientacao/ligarPassos só rodam depois do getUserMedia().then (gesto já
  // gasto) → sem isto os sensores NUNCA ligavam no iPhone (gate v1.1.93). Cacheamos a PROMISE do
  // pedido: _pedirSensores() a cria no toque; ligar* reusa a mesma promise (sem 2º requestPermission,
  // que o iOS rejeitaria como "já pendente"). Só limpa em não-granted, p/ permitir retry depois.
  function _permOri() {
    if (typeof DeviceOrientationEvent === 'undefined' || !DeviceOrientationEvent.requestPermission) return null; // Android/desktop: sem gate
    if (!xr._oriPromise) xr._oriPromise = DeviceOrientationEvent.requestPermission().then(function (p) { xr._oriPerm = p; if (p !== 'granted') xr._oriPromise = null; return p; }).catch(function () { xr._oriPromise = null; return 'denied'; });
    return xr._oriPromise;
  }
  function _permPasso() {
    if (typeof DeviceMotionEvent === 'undefined' || !DeviceMotionEvent.requestPermission) return null;
    if (!xr._passPromise) xr._passPromise = DeviceMotionEvent.requestPermission().then(function (p) { xr._passPerm = p; if (p !== 'granted') xr._passPromise = null; return p; }).catch(function () { xr._passPromise = null; return 'denied'; });
    return xr._passPromise;
  }
  function _pedirSensores() { _permOri(); _permPasso(); } // dispara AMBOS no gesto (usado pelo modo câmera)
  function ligarOrientacao() {
    if (xr.ori) return;
    function handler(ev) {
      if (ev.alpha == null && ev.beta == null && ev.gamma == null) return;
      var alpha = (ev.alpha || 0) * Math.PI / 180, beta = (ev.beta || 0) * Math.PI / 180, gamma = (ev.gamma || 0) * Math.PI / 180;
      _oriEul.set(beta, alpha, -gamma, 'YXZ');       // ordem canônica do device-orientation
      var q = xr.oriQuat || (xr.oriQuat = new THREE.Quaternion());
      q.setFromEuler(_oriEul);
      q.multiply(_oriQ1);                            // olhar pra frente (não pro céu)
      q.multiply(_oriQ0.setFromAxisAngle(_oriZee, -_screenAngRad())); // corrige retrato/paisagem
      // recentragem horizontal: gira o resultado em torno do Y do mundo pelo offset do usuário
      _oriYaw.setFromAxisAngle(_oriUp, xr.oriYawOff || 0);
      q.premultiply(_oriYaw);
      xr.oriOk = true;
    }
    var start = function () { window.addEventListener('deviceorientation', handler, true); xr.ori = true; xr._oriH = handler; xrDica('Vire e incline o celular pra olhar — o projeto acompanha. Joystick pra andar. Arraste na horizontal pra recentralizar.'); };
    var pr = _permOri();
    if (pr) { pr.then(function (p) { if (p === 'granted') start(); }); }
    else if (typeof DeviceOrientationEvent !== 'undefined') { start(); } // Android/desktop: sem requestPermission → liga direto
  }
  function desligarOrientacao() { if (xr.ori && xr._oriH) { window.removeEventListener('deviceorientation', xr._oriH, true); } xr.ori = false; xr.oriOk = false; xr.oriBase = null; }

  // ---- ANDAR POR PASSOS (acelerômetro): andar com o celular na mão → andar no projeto. iPhone/Android
  //      sem SLAM nativo — é APROXIMADO (detecção de passo), rotulado como "por passos". Cada passo move
  //      pra frente ~0,68 m na escala do mundo (na 1:1 = passo real dentro do projeto). Toggle no HUD. ----
  var _passLen = 0.68;
  function _passSens() { if (xr.passSens == null) { var v = 1.3; try { var s = parseFloat(localStorage.getItem('orcapro:bim:passSens')); if (s > 0) v = s; } catch (_) {} xr.passSens = Math.max(0.4, Math.min(3, v)); } return xr.passSens; }
  // detector de passo ADAPTATIVO (pura, testável): o limiar escala com o VIGOR do movimento (dev = média
  // do |dinâmico|) e tem piso BAIXO — o antigo `din>2.6` fixo não disparava com TABLET (movimento mais
  // gentil que o celular na mão). Pico com histerese (conta 1 por passo) + refratário. Retorna true no passo.
  function _passoDetecta(P, mag, now, sens) {
    P.ema = P.ema * 0.9 + mag * 0.1;                          // baseline SEMPRE EMA (P semeado c/ ema≈9.81 → sem transiente que engula os 1ºs passos)
    var din = mag - P.ema;                                    // parte dinâmica do passo
    P.dev = P.dev * 0.92 + Math.abs(din) * 0.08;              // vigor do movimento
    var thr = Math.max(0.55, P.dev * 1.4) / (sens || 1);      // limiar adaptativo (÷ sensibilidade do usuário)
    // dev>0.35: exige movimento REAL de translação — tremor/agito do aparelho parado não vira passo fantasma
    if (!P.up && din > thr && P.dev > 0.35 && (now - P.last) > 300) { P.up = true; P.last = now; P.n++; return true; }
    if (P.up && din < thr * 0.5) P.up = false;                // rearma ao descer (1 passo por pico)
    return false;
  }
  function ligarPassos() {
    if (xr._passH) return;
    xr._pass = { last: 0, ema: 9.81, dev: 0.2, up: false, on: false, n: 0 }; // baseline semeado (gravidade); 'on' só vira true quando o listener EXISTIR (start)
    function handler(ev) {
      if (!xr.on || !xr._pass || !xr._pass.on) return;
      var a = ev.accelerationIncludingGravity || ev.acceleration; if (!a) return;
      var mag = Math.sqrt((a.x || 0) * (a.x || 0) + (a.y || 0) * (a.y || 0) + (a.z || 0) * (a.z || 0));
      var now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
      if (_passoDetecta(xr._pass, mag, now, _passSens())) { xr._stepMove = (xr._stepMove || 0) + _passLen; if (S._xrPassosHud) S._xrPassosHud(xr._pass.n); } // pico → 1 passo pra frente
    }
    var start = function () { window.addEventListener('devicemotion', handler); xr._passH = handler; if (xr._pass) xr._pass.on = true; _syncPassosHud(); };
    var pr = _permPasso();
    if (pr) { pr.then(function (p) { if (p === 'granted') start(); else _syncPassosHud('📵 Passos precisam da permissão de Movimento (negada) — use o joystick.'); }); }
    else if (typeof DeviceMotionEvent !== 'undefined') { start(); } // Android/desktop: sem requestPermission → liga direto
  }
  function desligarPassos() { if (xr._passH) { try { window.removeEventListener('devicemotion', xr._passH); } catch (_) {} xr._passH = null; } xr._pass = null; xr._stepMove = 0; }
  S._xrStep = function () { xr._stepMove = (xr._stepMove || 0) + _passLen; }; // hook de teste: simula 1 passo
  S._passSensSet = function (v) { v = Math.max(0.4, Math.min(3, +v || 1)); xr.passSens = v; try { localStorage.setItem('orcapro:bim:passSens', String(v)); } catch (_) {} return v; };
  S._xrSimPassos = function (mags) { // hook de teste: alimenta uma sequência de magnitudes e conta os passos
    var P = { last: -9999, ema: 9.81, dev: 0.2, up: false, n: 0 }, i, t = 0, passos = 0;
    for (i = 0; i < mags.length; i++) { t += 60; if (_passoDetecta(P, mags[i], t, _passSens())) passos++; }
    return passos;
  };

  // ---- passo de andar (roda todo frame via S._xrWalk) ----
  var _xrFwd = new THREE.Vector3(), _xrRight = new THREE.Vector3(), _xrUp = new THREE.Vector3(0, 1, 0);
  function xrWalkStep(dt) {
    if (xr.mode === 'vr') { xrVRLoco(dt); return; }
    // câmera olha conforme o giroscópio (quaternion real) OU, sem giroscópio (desktop/permissão negada),
    // pelo arraste (yaw/pitch). No AR a câmera é da sessão, só nudge no plano.
    if (xr.mode !== 'ar') {
      if (xr.oriOk && xr.oriQuat) { camera.quaternion.copy(xr.oriQuat); }
      else { var e = new THREE.Euler(xr.look.pitch, xr.look.yaw, 0, 'YXZ'); camera.quaternion.setFromEuler(e); }
      // PASSOS: andou com o celular na mão → anda pra frente no projeto (independe do joystick).
      // Só zera o acumulador quando REALMENTE aplica (olhando ~reto p/ cima/baixo o fwd horizontal some →
      // adia o passo pro próximo frame com direção válida, em vez de descartá-lo). (gate v1.1.95)
      if (xr._stepMove) { camera.getWorldDirection(_xrFwd); _xrFwd.y = 0; if (_xrFwd.lengthSq() > 1e-6) { var sm = xr._stepMove; xr._stepMove = 0; _xrFwd.normalize(); camera.position.addScaledVector(_xrFwd, sm); camera.position.y = xr._pisoY + EYE; } }
    }
    var mv = xr.joy.x * xr.joy.x + xr.joy.z * xr.joy.z;
    if (mv < 0.0009) return;
    camera.getWorldDirection(_xrFwd); _xrFwd.y = 0; _xrFwd.normalize();
    _xrRight.crossVectors(_xrFwd, _xrUp).normalize();
    var vel = 1.4 * dt; // ~caminhada humana (m/s), em unidades de mundo já escaladas
    var alvo = new THREE.Vector3();
    alvo.addScaledVector(_xrFwd, -xr.joy.z * vel).addScaledVector(_xrRight, xr.joy.x * vel);
    if (xr.mode === 'ar') { modelRoot.position.sub(alvo); } // no AR movo o MODELO (a câmera é do device)
    else { camera.position.add(alvo); camera.position.y = xr._pisoY + EYE; } // altura REAL do olho (não escala com a miniatura)
  }
  function xrVRLoco(dt) {
    try {
      var s = renderer.xr.getSession(); if (!s) return;
      s.inputSources.forEach(function (src) {
        if (!src.gamepad || !src.handedness) return;
        var ax = src.gamepad.axes || [];
        var x = ax[2] || ax[0] || 0, y = ax[3] || ax[1] || 0;
        if (Math.abs(x) < 0.15 && Math.abs(y) < 0.15) return;
        if (src.handedness === 'left') {
          camera.getWorldDirection(_xrFwd); _xrFwd.y = 0; _xrFwd.normalize(); _xrRight.crossVectors(_xrFwd, _xrUp).normalize();
          var v = 1.6 * dt, mov = new THREE.Vector3(); mov.addScaledVector(_xrFwd, -y * v).addScaledVector(_xrRight, x * v);
          xrRig.position.add(mov);
        } else if (src.handedness === 'right' && Math.abs(x) > 0.6) {
          if (!xr._snapT || performance.now() - xr._snapT > 300) { xrRig.rotation.y -= (x > 0 ? 1 : -1) * Math.PI / 6; xr._snapT = performance.now(); }
        }
      });
    } catch (_) {}
  }

  // rig de VR: a câmera XR fica dentro dele; mover/girar o rig = teletransporte suave
  var xrRig = new THREE.Group(); scene.add(xrRig);

  // ---- ENTRAR: Caminhar / Câmera (universal, sem WebXR) ----
  // modo 'caminhar' = modelo em fundo liso; modo 'camera' = modelo POR CIMA do vídeo da câmera
  // (RA simples que roda no iPhone: giroscópio olha, joystick anda, o projeto aparece no ambiente).
  function iniciarAndar(modo) {
    if (xr.on) return; // guarda de reentrada: 2ª entrada (toque duplo 📷/👣) capturaria posOrig JÁ deslocado → modelo torto no 3D ao sair (gate v1.1.92)
    if (!modelRoot.children.length) { S._hint('Carregue um modelo primeiro.'); return; }
    // trabalha no frame LOCAL (modelRoot na origem) p/ a escala ancorar certo; posOrig restaurado ao sair
    xr.posOrig = modelRoot.position.clone();
    modelRoot.position.set(0, 0, 0); modelRoot.scale.setScalar(1); modelRoot.updateMatrixWorld(true);
    var box = new THREE.Box3().setFromObject(modelRoot);
    if (box.isEmpty()) { modelRoot.position.copy(xr.posOrig); S._hint('Modelo sem geometria visível.'); return; }
    xr.boxLocal = box.clone();
    xr.on = true; xr.mode = modo; xr.escala = 1; xr.cortefrac = 1000;
    xr.oriYawOff = 0; xr.oriOk = false; xr.travado = false;
    xr.cam = { pos: camera.position.clone(), quat: camera.quaternion.clone(), near: camera.near, far: camera.far };
    xr.prevClip = renderer.clippingPlanes; xr.prevLocal = renderer.localClippingEnabled;
    renderer.clippingPlanes = []; renderer.localClippingEnabled = false; // Caminhar/Câmera entram INTEIROS; Planta/Corte ativos NÃO vazam (prevClip volta no sair)
    orbit.enabled = false; if (S.fly && S.fly.on && S._setMode) S._setMode(false);
    ligarSombras(true);
    var c = box.getCenter(new THREE.Vector3());
    camera.near = 0.02; camera.far = 5000;
    camera.quaternion.identity(); // olhar pra frente (-Z) até o giroscópio assumir
    if (modo === 'camera') { camera.position.set(0, box.min.y + EYE, 0); xr._pisoY = box.min.y; }
    else { camera.position.set(c.x, box.min.y + EYE, c.z); xr._pisoY = box.min.y; } // caminhar: dentro, 1:1
    camera.updateProjectionMatrix();
    xr.look.yaw = 0; xr.look.pitch = 0; xr.joy.x = 0; xr.joy.z = 0; // zera o joystick (senão anda sozinho na reentrada)
    S._xrWalk = xrWalkStep;
    montarHud(false);
    if (typeof DeviceOrientationEvent !== 'undefined') ligarOrientacao();
    ligarPassos(); // andar com o celular na mão → andar no projeto (por passos)
    canvasEl.addEventListener('pointerdown', xrPointerDown); canvasEl.addEventListener('pointermove', xrPointerMove); window.addEventListener('pointerup', xrPointerUp);
    marcarBtnXR(true); pintarXRPanel(); xrPanel.style.display = 'none';
    // câmera: começa como MINIATURA na frente (vê o projeto inteiro na sala); caminhar: 1:1 DENTRO
    if (modo === 'camera') { aplicarEscalaImersivo(fitEscala()); S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('camera', 15) : '') + ' Projeto no seu ambiente. Vire o celular pra olhar; ' + (typeof Icones !== 'undefined' ? Icones.get('ajustes', 15) : '') + ' Ajustes p/ escala (1:1 = andar dentro) e ' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' Centralizar. ⏹ Sair.'); }
    else { xrDica('' + (typeof Icones !== 'undefined' ? Icones.get('caminhar', 15) : '') + ' Você está DENTRO em escala real 1:1. Vire o celular pra olhar; joystick pra andar.'); S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('caminhar', 15) : '') + ' Dentro do projeto 1:1. Vire o celular; joystick pra andar. ⏹ Sair.'); }
  }
  function entrarCaminhar() { iniciarAndar('caminhar'); }
  // ---- ENTRAR: Câmera + Projeto (RA simples: vídeo da câmera de fundo + modelo por cima) ----
  function entrarCamera() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('camera', 15) : '') + ' Este navegador não dá acesso à câmera.'); return; }
    // câmera só em contexto seguro (HTTPS ou localhost) — regra do navegador. No QR da rede local (http) não rola.
    // (fix v1.1.90: o regex antigo `^https:$` NUNCA batia em "https://host" — bloqueava a câmera em TODO HTTPS, inclusive o link da nuvem)
    var h = location.hostname;
    var origemSegura = (location.protocol === 'https:') || (typeof window.isSecureContext !== 'undefined' && window.isSecureContext) || h === 'localhost' || h === '127.0.0.1' || h === '::1' || /\.localhost$/.test(h);
    if (!origemSegura) {
      S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('camera', 15) : '') + ' A câmera só abre por HTTPS. Use o link ' + (typeof Icones !== 'undefined' ? Icones.get('nuvem', 15) : '') + ' da nuvem (ou rode no próprio computador).');
      return;
    }
    if (xr.on || xr._camPend) return; // já imersivo ou pedido de câmera em voo: ignora toque duplo (senão orfã stream + corrompe posOrig)
    xr._camPend = true;
    _pedirSensores(); // AINDA no gesto do toque: concede giroscópio+passos p/ o iPhone (o getUserMedia().then já gastaria o gesto)
    S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('camera', 15) : '') + ' Pedindo acesso à câmera…');
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false }).then(function (stream) {
      xr._camPend = false;
      if (xr.on) { try { stream.getTracks().forEach(function (t) { t.stop(); }); } catch (_) {} return; } // usuário já entrou em outro modo enquanto pedíamos a câmera → descarta o stream
      xr.stream = stream;
      var v = document.createElement('video');
      v.setAttribute('playsinline', ''); v.setAttribute('muted', ''); v.muted = true; v.autoplay = true;
      v.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:0;background:#000';
      v.srcObject = stream; host.insertBefore(v, host.firstChild); xr.video = v; try { v.play(); } catch (_) {}
      canvasEl.style.position = 'relative'; canvasEl.style.zIndex = '1'; canvasEl.style.background = 'transparent';
      iniciarAndar('camera');
    }).catch(function (e) {
      xr._camPend = false;
      var nm = (e && e.name) || e;
      S._hint(nm === 'NotAllowedError' ? '' + (typeof Icones !== 'undefined' ? Icones.get('camera', 15) : '') + ' Você negou a câmera. Toque de novo e permita.' : '' + (typeof Icones !== 'undefined' ? Icones.get('camera', 15) : '') + ' Não consegui abrir a câmera: ' + nm);
    });
  }
  function limparCamera() {
    if (xr.stream) { try { xr.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (_) {} xr.stream = null; }
    if (xr.video) { try { xr.video.pause(); xr.video.srcObject = null; if (xr.video.parentNode) xr.video.parentNode.removeChild(xr.video); } catch (_) {} xr.video = null; }
    try { canvasEl.style.zIndex = ''; canvasEl.style.background = ''; } catch (_) {}
  }

  // ---- ENTRAR: VR imersivo (WebXR) ----
  function entrarVR() {
    if (!navigator.xr) return;
    var box = new THREE.Box3().setFromObject(modelRoot); if (box.isEmpty()) return;
    navigator.xr.requestSession('immersive-vr', { optionalFeatures: ['local-floor', 'bounded-floor'] }).then(function (session) {
      xr.on = true; xr.mode = 'vr'; xr.session = session; xr.escala = 1;
      xr.cam = { pos: camera.position.clone(), quat: camera.quaternion.clone() };
      xr.prevClip = renderer.clippingPlanes; xr.prevLocal = renderer.localClippingEnabled; // preserva Planta/Corte ativos
      xr.joy.x = 0; xr.joy.z = 0;
      S._xrWalk = xrWalkStep; // locomoção (analógico → xrVRLoco) roda no xrLoop
      ligarSombras(true);
      var c = box.getCenter(new THREE.Vector3());
      xrRig.position.set(c.x, box.min.y, c.z); xrRig.rotation.set(0, 0, 0);
      renderer.xr.setReferenceSpaceType('local-floor');
      xrRig.add(camera); // câmera XR dentro do rig → mover o rig te leva pelo modelo
      renderer.xr.setSession(session).then(function () {
        if (!xr.on) return; // sessão já encerrada antes deste callback (Esc/tirou o headset) — não ressuscita o loop
        /* ⚠ AS COTAS SAEM ANTES DO IMERSIVO. A ancora vem do `aabb`, que e foto
           do carregamento; no RA/RV o `modelRoot` e transladado e escalado, e
           `_tickExtra` continua rodando la dentro (o laco do XR o re-executa).
           Sem isto, as cotas flutuam soltas no meio do ambiente, com
           `depthTest` desligado, e `sairImersivo` nao as conhece. */
        if (S._setCota && S._cotaEstado && S._cotaEstado().on) S._setCota(false);
        xr._xrActivePrev = S._xrActive; S._xrActive = true; if (S.raf) { cancelAnimationFrame(S.raf); S.raf = 0; }
        renderer.setAnimationLoop(xrLoop);
      }).catch(function (e) { sairImersivo(); S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('vr', 15) : '') + ' Falha ao iniciar a sessão VR: ' + (e && e.message || e)); });
      session.addEventListener('end', sairImersivo);
      marcarBtnXR(true); pintarXRPanel(); xrPanel.style.display = 'none'; // no imersivo o painel grande some (tampava a vista no celular); ⚙️ Ajustes reabre
    }).catch(function (e) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('vr', 15) : '') + ' Não deu pra entrar em VR: ' + (e && e.message || e)); });
  }

  // ---- ENTRAR: RA no ambiente (WebXR immersive-ar, Android) ----
  function entrarAR() {
    if (!navigator.xr) return;
    montarHud(true); // dom-overlay usa o xrHud
    navigator.xr.requestSession('immersive-ar', { requiredFeatures: ['hit-test'], optionalFeatures: ['dom-overlay', 'local-floor'], domOverlay: { root: xrHud } }).then(function (session) {
      xr.on = true; xr.mode = 'ar'; xr.session = session; xr.placed = false; xr.travado = false;
      xr.modelSnap = { pos: modelRoot.position.clone(), quat: modelRoot.quaternion.clone(), scale: modelRoot.scale.clone() };
      xr.prevClip = renderer.clippingPlanes; xr.prevLocal = renderer.localClippingEnabled; // preserva Planta/Corte ativos
      xr.joy.x = 0; xr.joy.z = 0;
      S._xrWalk = xrWalkStep; // nudge do joystick no modo AR roda no xrLoop
      modelRoot.visible = false; // só aparece após colocar
      ligarSombras(true);
      // retículo de colocação
      if (!xr.reticle) {
        var g = new THREE.RingGeometry(0.09, 0.11, 32).rotateX(-Math.PI / 2);
        xr.reticle = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: 0x7fe0a3 }));
        xr.reticle.matrixAutoUpdate = false; xr.reticle.visible = false; scene.add(xr.reticle);
      }
      renderer.xr.setReferenceSpaceType('local');
      renderer.xr.setSession(session).then(function () {
        if (!xr.on) return; // sessão já encerrada antes deste callback
        S._xrActive = true; if (S.raf) { cancelAnimationFrame(S.raf); S.raf = 0; }
        session.requestReferenceSpace('viewer').then(function (vs) {
          session.requestHitTestSource({ space: vs }).then(function (src) { if (xr.on) xr.hitSrc = src; else { try { src.cancel(); } catch (_) {} } });
        });
        renderer.setAnimationLoop(xrLoop);
      }).catch(function (e) { sairImersivo(); S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('celular', 15) : '') + ' Falha ao iniciar a sessão RA: ' + (e && e.message || e)); });
      // toque no AR: mede (se a régua estiver ligada) ou fixa o projeto
      session.addEventListener('select', function () { if (xr.medir.on && xr.placed) medirTocar({}); else arColocar(); });
      session.addEventListener('end', sairImersivo);
      xrDica('Aponte a câmera pro chão e toque na tela pra fixar o projeto.');
      marcarBtnXR(true); pintarXRPanel(); xrPanel.style.display = 'none'; // no imersivo o painel grande some (tampava a vista no celular); ⚙️ Ajustes reabre
    }).catch(function (e) { xrHud.style.display = 'none'; S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('celular', 15) : '') + ' RA indisponível neste aparelho: ' + (e && e.message || e)); });
  }
  function arColocar() {
    if (xr.travado || !xr.reticle || !xr.reticle.visible) return;
    xr._anchorMat = xr.reticle.matrix.clone();
    xr.placed = true; modelRoot.visible = true;
    posicionarModeloAR();
    /* travada por padrão: o pedido é "só se tiver destravado" */
    xr.travado = raTrava; pintarTravaHud();
    xrDica(raTrava ? 'Projeto fixado e TRAVADO: encostar a mão não tira ele do lugar. Toque em "Travado" para mover.' : 'Projeto fixado. Ande em volta! Toque em "Livre" para travar no lugar.');
    pintarXRPanel();
  }
  function posicionarModeloAR() {
    if (!xr._anchorMat) return;
    var box = new THREE.Box3().setFromObject(modelRoot); // em coords atuais
    var p = new THREE.Vector3(), q = new THREE.Quaternion(), s = new THREE.Vector3();
    xr._anchorMat.decompose(p, q, s);
    modelRoot.scale.setScalar(xr.escala || 1);
    // apoia a BASE do modelo no ponto do chão
    var box0 = new THREE.Box3().setFromObject(modelRoot);
    modelRoot.position.set(0, 0, 0);
    var min = box0.min.clone();
    modelRoot.position.set(p.x - (box0.getCenter(new THREE.Vector3()).x), p.y - min.y, p.z - (box0.getCenter(new THREE.Vector3()).z));
    modelRoot.quaternion.copy(q);
  }

  // ---- loop XR (VR/AR): dt + locomoção + hit-test + render ----
  function xrLoop(t, frame) {
    if (!S || !S.alive) { renderer.setAnimationLoop(null); return; }
    var dt = Math.min(clock.getDelta(), 0.1);
    if (S._xrWalk) S._xrWalk(dt);
    if (xr.mode === 'ar' && frame && xr.hitSrc && !xr.travado) {
      try {
        var ref = renderer.xr.getReferenceSpace(), hits = frame.getHitTestResults(xr.hitSrc);
        if (hits.length) { var pose = hits[0].getPose(ref); if (pose) { xr.reticle.visible = !xr.placed; xr.reticle.matrix.fromArray(pose.transform.matrix); } }
        else xr.reticle.visible = false;
      } catch (_) {}
    }
    for (var i = 0; i < S._tickExtra.length; i++) { try { S._tickExtra[i](dt); } catch (_) {} }
    renderer.render(scene, camera);
  }

  // ---- medir na escala (2 toques) ----
  /* ⚠ A TRENA DA RA COM O MESMO ÍMÃ DO 3D. Ela pegava o ponto cru da
     superfície no centro da tela — nenhum canto, nenhuma aresta — e no
     imersivo o marcador de snap (HTML) nem aparece: só o dom-overlay é
     desenhado. Aqui o alvo é o centro da tela (a mira), o ímã é o `mirarEm`
     (raio de dedo) e o marcador é uma bolinha NA CENA, com o tipo, a peça e a
     distância real na dica. */
  var marcaXR = null, elasticoXR = null, _marcaXRT = 0, _miraXR = null;
  var COR_TIPO = { vertice: 0x22c55e, meio: 0xf59e0b, aresta: 0x38bdf8, intersecao: 0xe879f9, centro: 0xfacc15 };
  function centroDaTela() { var r = canvasEl.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }
  S._tickExtra.push(function () {
    var vivo = xr.on && xr.medir && xr.medir.on && (xr.mode !== 'ar' || xr.placed);
    if (!vivo) { if (marcaXR) marcaXR.visible = false; if (elasticoXR) elasticoXR.visible = false; _miraXR = null; return; }
    var agora = performance.now(); if (agora - _marcaXRT < 150) { if (marcaXR && marcaXR.visible) rescaleObj(marcaXR); return; }
    _marcaXRT = agora;
    var c = centroDaTela(), sn = mirarEm(c.x, c.y, 30);
    _miraXR = sn && sn.p ? sn : null;
    if (!marcaXR) { marcaXR = pontoMarca(new THREE.Vector3()); marcaXR.userData._sc = 0.012; scene.add(marcaXR); }
    if (!_miraXR) { marcaXR.visible = false; if (elasticoXR) elasticoXR.visible = false; return; }
    marcaXR.position.copy(_miraXR.p); marcaXR.material.color.setHex(COR_TIPO[_miraXR.tipo] || 0xcbd5e1); marcaXR.visible = true; rescaleObj(marcaXR);
    var rot = (_miraXR.tipo ? (SNAP_VIS[_miraXR.tipo] || {}).rot : 'superfície') || 'superfície', nm = nomeDaPeca(_miraXR.obj), dist = '';
    if (xr.medir.pts.length === 1) {
      if (!elasticoXR) { elasticoXR = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]), new THREE.LineBasicMaterial({ color: 0x7fe0a3, depthTest: false })); elasticoXR.renderOrder = 997; elasticoXR.frustumCulled = false; scene.add(elasticoXR); }
      linhaEm(elasticoXR, xr.medir.pts[0], _miraXR.p);
      dist = ' · ' + fmtDist(xr.medir.pts[0].distanceTo(_miraXR.p) / (xr.escala || 1)) + ' (real)';
    } else if (elasticoXR) elasticoXR.visible = false;
    xrDica(rot + (nm ? ' · ' + nm : '') + dist);
  });
  function medirTocar(e) {
    /* o ponto que a bolinha está mostrando (a mira) — ou, sem ela, o ímã no
       lugar do toque/centro. Nunca o ponto cru da superfície. */
    var c = centroDaTela(), cx = e.clientX != null ? e.clientX : c.x, cy = e.clientY != null ? e.clientY : c.y;
    var sn = (e.clientX == null && _miraXR) ? _miraXR : mirarEm(cx, cy, 30);
    if (!sn || !sn.p) { xrDica('' + (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '') + ' Mire numa superfície do modelo.'); return; }
    var P = sn.p.clone();
    xr.medir.pts.push(P);
    var m = pontoMarca(P.clone()); scene.add(m); xr.medir.objs.push(m); rescaleObj(m);
    if (xr.medir.pts.length === 2) {
      var a = xr.medir.pts[0], b = xr.medir.pts[1];
      var dReal = a.distanceTo(b) / (xr.escala || 1); // divide pela escala → metros reais
      var ln = new THREE.Line(new THREE.BufferGeometry().setFromPoints([a, b]), new THREE.LineBasicMaterial({ color: 0x7fe0a3, depthTest: false }));
      ln.renderOrder = 998; scene.add(ln); xr.medir.objs.push(ln);
      var lab = labelSprite(fmtDist(dReal)); lab.position.copy(a.clone().add(b).multiplyScalar(0.5)); scene.add(lab); xr.medir.objs.push(lab); rescaleObj(lab);
      xrDica('📏 ' + fmtDist(dReal) + ' (real). Toque 2 pontos pra medir de novo.');
      xr.medir.pts = [];
      if (elasticoXR) elasticoXR.visible = false;
    } else xrDica('' + (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '') + ' Agora toque no 2º ponto.');
  }
  S._medirTocarXR = medirTocar;   // hook de teste
  function limparMedirXR() { xr.medir.objs.forEach(function (o) { scene.remove(o); if (o.geometry) o.geometry.dispose(); }); xr.medir.objs = []; xr.medir.pts = []; }

  // ---- disciplina: liga/desliga MODELOS por disciplina ----
  function toggleDisciplinaXR(chave) {
    xr.discOcultas[chave] = !xr.discOcultas[chave];
    S.modelos.forEach(function (mo) { if ((mo.disciplina || 'outros') === chave) mo.grupo.visible = !xr.discOcultas[chave] && mo.visivel !== false; });
    pintarXRPanel();
  }
  /* a mesma chave de disciplina do painel da RA, para a barra do visitante:
     escolher em "Camadas" ou no painel da RA é a MESMA escolha */
  S._disciplinas = function () { return disciplinasPresentes().map(function (d) { d.oculta = !!xr.discOcultas[d.chave]; return d; }); };
  S._disciplinaVisivel = function (chave, on) { if (!!xr.discOcultas[chave] !== !on) toggleDisciplinaXR(chave); };

  // ---- SAIR: restaura tudo ----
  function sairImersivo() {
    if (!xr.on) return;
    var eraVR = xr.mode === 'vr', eraAR = xr.mode === 'ar';
    xr.on = false;
    if (xr.hitSrc) { try { xr.hitSrc.cancel(); } catch (_) {} }
    if (xr.session) { try { xr.session.end(); } catch (_) {} }
    xr.session = null; xr.hitSrc = null; xr.joy.x = 0; xr.joy.z = 0; xr.cortefrac = 1000;
    limparCamera(); // para a câmera + remove o vídeo de fundo (modo 📷)
    S._xrActive = false; S._xrWalk = null;
    try { renderer.setAnimationLoop(null); } catch (_) {}
    if (xr.reticle) xr.reticle.visible = false;
    if (eraVR) { scene.add(camera); xrRig.remove(camera); } // devolve a câmera à cena
    // restaura modelo (escala/posição do AR) e disciplinas
    modelRoot.visible = true;
    modelRoot.scale.setScalar(1);
    if (xr.modelSnap) { modelRoot.position.copy(xr.modelSnap.pos); modelRoot.quaternion.copy(xr.modelSnap.quat); modelRoot.scale.copy(xr.modelSnap.scale); xr.modelSnap = null; }
    else if (xr.posOrig) { modelRoot.position.copy(xr.posOrig); } // câmera/caminhar movem o modelRoot p/ a origem — devolve a posição real
    xr.posOrig = null; xr.boxLocal = null;
    /* no visitante a disciplina é escolhida FORA do imersivo (Camadas) e tem
       de continuar valendo depois de sair; no computador, sair devolve tudo */
    if (!visitante) { S.modelos.forEach(function (mo) { mo.grupo.visible = mo.visivel !== false; }); xr.discOcultas = {}; }
    ligarSombras(false);
    limparMedirXR(); xr.medir.on = false;
    desligarOrientacao(); desligarPassos();
    renderer.clippingPlanes = xr.prevClip || []; renderer.localClippingEnabled = xr.prevLocal;
    canvasEl.removeEventListener('pointerdown', xrPointerDown); canvasEl.removeEventListener('pointermove', xrPointerMove); window.removeEventListener('pointerup', xrPointerUp);
    xrHud.style.display = 'none'; xrHud.innerHTML = '';
    if (xr.cam) { camera.position.copy(xr.cam.pos); if (xr.cam.quat) camera.quaternion.copy(xr.cam.quat); if (xr.cam.near) { camera.near = xr.cam.near; camera.far = xr.cam.far; camera.updateProjectionMatrix(); } xr.cam = null; }
    orbit.enabled = !trava.on; orbit.update();   /* ⚠ sair da RA não destrava a câmera */
    xr.escala = 1; xr.mode = null; xr.placed = false; xr.travado = false;
    marcarBtnXR(false); pintarXRPanel();
    if (S._retomarTick) S._retomarTick();
    S._hint('');
  }
  S._sairImersivo = sairImersivo;
  function marcarBtnXR(on) { var b = bar.querySelector('[data-b="xr"]'); if (b) { b.style.background = on ? corAtiva() : ''; b.style.color = on ? '#fff' : ''; } }

  xrPanel.addEventListener('click', function (e) {
    var bd = e.target.closest('[data-xd]'); if (bd) { toggleDisciplinaXR(bd.getAttribute('data-xd')); return; }
    var b = e.target.closest('[data-x]'); if (!b) return; var k = b.getAttribute('data-x');
    if (k === 'fechar') { xrPanel.style.display = 'none'; }
    else if (k === 'ratrava') { raTrava = !raTrava; try { localStorage.setItem('orcapro:bim:raTrava', raTrava ? '1' : '0'); } catch (_) {} pintarXRPanel(); }
    else if (k === 'quicklook') { abrirQuickLook(b.getAttribute('data-ql') === 'maquete' ? 'maquete' : 'real', b); }
    else if (k === 'sceneviewer') { if (S.opts && S.opts.onSceneViewer) S.opts.onSceneViewer(b.getAttribute('data-ql') === 'maquete' ? 'maquete' : 'real', b); }
    else if (k === 'camera') { entrarCamera(); }
    else if (k === 'caminhar') { entrarCaminhar(); }
    else if (k === 'vr') { entrarVR(); }
    else if (k === 'ar') { entrarAR(); }
    else if (k === 'sair') { sairImersivo(); }
    else if (k === 'travar') { xr.travado = !xr.travado; if (xr.reticle) xr.reticle.visible = false; pintarXRPanel(); }
    else if (k === 'centralizar') { centralizarProjeto(); }
    else if (k === 'travarcam') { xr.travado = !xr.travado; S._hint(xr.travado ? '' + (typeof Icones !== 'undefined' ? Icones.get('cadeado', 15) : '') + ' Projeto travado no lugar.' : '' + (typeof Icones !== 'undefined' ? Icones.get('destravado', 15) : '') + ' Projeto liberado — dá pra reposicionar/escalar.'); pintarXRPanel(); }
    else if (k === 'medir') { xr.medir.on = !xr.medir.on; if (!xr.medir.on) limparMedirXR(); xrDica(xr.medir.on ? '' + (typeof Icones !== 'undefined' ? Icones.get('medir', 15) : '') + ' Toque 2 pontos do modelo pra medir na escala.' : ''); b.style.background = xr.medir.on ? corAtiva() : ''; b.style.color = xr.medir.on ? '#fff' : ''; }
  });
  xrPanel.addEventListener('change', function (e) {
    var b = e.target.closest('[data-x]'); if (!b) return; var k = b.getAttribute('data-x');
    if (k === 'pavxr') { if (b.value) isolarPavimento(b.value); else if (pav.isolado) restaurarVisibilidade(); pintarXRPanel(); return; }
    if (k === 'esc') aplicarEscalaXR(parseFloat(b.value) || 1);
    else if (k === 'esc2') { var v = b.value; aplicarEscalaImersivo(v === 'fit' ? fitEscala() : (parseFloat(v) || 1)); }
  });
  xrPanel.addEventListener('input', function (e) {
    var b = e.target.closest('[data-x]'); if (!b) return; var k = b.getAttribute('data-x');
    if (k === 'corte') aplicarTetoVisao((+b.value) / 1000);
    else if (k === 'passsens') { var v = S._passSensSet((+b.value) / 100); var lab = xrPanel.querySelector('[data-x="passv"]'); if (lab) lab.textContent = v.toFixed(1) + '×'; }
  });

  // ============================================================
  // 🏗 2D→3D (Fase C.1) — reconstrução ASSISTIDA a partir de DXF: o parser
  // (js/dxf.js) lê a planta, o detector (js/planta3d.js) PROPÕE paredes por
  // pares de linhas paralelas, o usuário confirma/desliga no preview e o
  // viewer extruda como MODELO SINTÉTICO (QTO/4D/clash/parede-cebola ganham
  // de graça). Honesto: volumetria de ESTUDO — não substitui projeto.
  // ============================================================
  var p3dSeq = 0;
  function carregarSintetico(caixas, nome) {
    caixas = caixas || [];
    if (!caixas.length) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('obra', 15) : '') + ' Nenhuma parede ligada pra gerar.'); return null; }
    if (S.modelos.length >= 8) { S._hint('Limite de 8 modelos abertos — remova um antes.'); return null; }
    var mid = 'p3d' + (++p3dSeq);
    var modelo = { mid: mid, sintetico: true, nome: nome || ('Planta 2D→3D (' + caixas.length + ' paredes)'), disciplina: 'arquitetura', alpha: 1, visivel: true, grupo: new THREE.Group(), matCache: {}, transCache: {}, elementos: [], tipos: { IFCWALL: caixas.length }, nEl: 0, nTri: 0, pavimentos: [], carimbos: {}, qto: {} };
    modelo.grupo.userData.mid = mid;
    modelRoot.add(modelo.grupo);
    var mat = new THREE.MeshStandardMaterial({ color: 0xd8cfc0, metalness: .05, roughness: .85, side: THREE.DoubleSide });
    modelo.matCache.parede = mat;
    caixas.forEach(function (c, i) {
      var g = new THREE.BoxGeometry(c.comprimento, c.altura, c.espessura);
      var m = new THREE.Mesh(g, mat);
      m.position.set(c.cx, c.cy, c.cz); m.rotation.y = c.rotY;
      m.userData.expressID = c.id != null ? c.id : (i + 1); m.userData.tipo = 'IFCWALL'; m.userData.mid = mid; m.userData.matOrig = mat;
      modelo.grupo.add(m);
      S.meshPorId[m.userData.expressID] = m; S.meshPorUid[mid + ':' + m.userData.expressID] = m;
      modelo.nTri += 12;
      // qto REAL da parede (área de 1 face; a Parede-Cebola/QTO consomem daqui — nada estimado por caixa)
      modelo.qto[m.userData.expressID] = { comprimento: c.comprimento, area: c.area, volume: +(c.comprimento * c.altura * c.espessura).toFixed(4), contagem: 1 };
      modelo.elementos.push({ id: m.userData.expressID, uid: mid + ':' + m.userData.expressID, mid: mid, arquivo: modelo.nome, tipo: 'IFCWALL', nome: 'Parede ' + (i + 1) + ' (' + c.comprimento.toFixed(2).replace('.', ',') + ' m)', etapa: null, codOrc: null, qto: modelo.qto[m.userData.expressID], disciplina: 'arquitetura' });
      modelo.nEl++;
    });
    S.modelos.push(modelo);
    recarimbarIdentidade();   /* B0: 2D->3D e sintetico, GlobalId proprio */
    agregarModelo(modelo);    /* B2 */
    carimbarConsulta();     /* B3 */
    // AABB mundo por elemento (clash/QTO)
    try {
      modelRoot.updateMatrixWorld(true);
      modelo.grupo.children.forEach(function (m) {
        var bb = new THREE.Box3().setFromObject(m);
        var elx = modelo.elementos.filter(function (e) { return e.id === m.userData.expressID; })[0];
        if (elx && !bb.isEmpty()) elx.aabb = { min: [bb.min.x, bb.min.y, bb.min.z], max: [bb.max.x, bb.max.y, bb.max.z] };
      });
    } catch (_) {}
    over.style.display = 'none';
    atualizarHud();
    if (planta.on) setPlanta(false);
    if (corteL.on) setCorteL(false);
    enquadrar();
    S.elementos = []; S.modelos.forEach(function (mo) { S.elementos = S.elementos.concat(mo.elementos); });
    if (pav.isolado || pav.manual) restaurarVisibilidade(); else pavRender();
    if (S._editReaplicarRem) S._editReaplicarRem(); // removidos da edição valem pro sintético recém-chegado
    notifyModelos();
    if (S._xrReSnap) S._xrReSnap(); // se chegou modelo durante o imersivo, re-ancora (o enquadrar() acima é ignorado no imersivo)
    if (opts.onLoaded) opts.onLoaded(elementosVivos());
    return mid;
  }
  S._carregarSintetico = carregarSintetico;

  // ============================================================
  // 🪨 SONDAGEM 3D — as camadas de solo debaixo da obra. O motor
  // (js/sondagem.js) monta os volumes em coordenadas do IFC; aqui só se
  // desenha. NÃO é modelo: fica fora da federação, do QTO, do clash, do
  // 4D e do limite de 8 modelos — é uma sobreposição que some num clique.
  // ⚠ IFC → cena é a permutação do web-ifc (x, z, −y), a mesma de
  //   BimVista.ifcParaCena. Somar translação aqui tira o solo de baixo da
  //   obra sem erro nenhum na tela.
  // ⚠ Fica DENTRO do modelRoot: o AR e o "caminhar" movem o modelRoot, e o
  //   solo tem de ir junto com o prédio.
  // ============================================================
  var solo = { grupo: null, vols: [], furos: [], plano: null, opac: 0.5, destaque: null, n: 0 };
  function soloV(p) { return new THREE.Vector3(+p[0], +p[2], -(+p[1])); }
  function soloLimpar() {
    if (solo.grupo) {
      solo.grupo.traverse(function (o) { if (o.geometry) o.geometry.dispose(); if (o.material) { (Array.isArray(o.material) ? o.material : [o.material]).forEach(function (m) { m.dispose(); }); } });
      if (solo.grupo.parent) solo.grupo.parent.remove(solo.grupo);
    }
    solo.grupo = null; solo.vols = []; solo.furos = []; solo.plano = null; solo.destaque = null; solo.n = 0;
  }
  function soloHexa(v, cor, opac) {
    // v: 8 vértices — base 0..3 e topo 4..7 na mesma ordem (o retângulo da área)
    var P = v.map(soloV), pos = [];
    var F = [[0, 2, 1], [0, 3, 2], [4, 5, 6], [4, 6, 7], [0, 1, 5], [0, 5, 4], [1, 2, 6], [1, 6, 5], [2, 3, 7], [2, 7, 6], [3, 0, 4], [3, 4, 7]];
    F.forEach(function (t) { t.forEach(function (i) { pos.push(P[i].x, P[i].y, P[i].z); }); });
    var g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.computeVertexNormals();
    var m = new THREE.MeshStandardMaterial({ color: new THREE.Color(cor), transparent: true, opacity: opac, depthWrite: false, side: THREE.DoubleSide, roughness: 0.95, metalness: 0 });
    var mesh = new THREE.Mesh(g, m); mesh.renderOrder = 2;
    var ar = new THREE.LineSegments(new THREE.EdgesGeometry(g, 20), new THREE.LineBasicMaterial({ color: new THREE.Color(cor).multiplyScalar(0.55), transparent: true, opacity: Math.min(1, opac + 0.3) }));
    ar.renderOrder = 3;
    return { mesh: mesh, arestas: ar };
  }
  function soloMostrar(def) {
    soloLimpar();
    def = def || {};
    var vols = def.volumes || [], furos = def.furos || [];
    if (!vols.length && !furos.length) return { ok: false, erro: 'sem volumes nem furos para desenhar' };
    if (def.opacidade != null) solo.opac = Math.max(0.05, Math.min(1, +def.opacidade));
    solo.grupo = new THREE.Group(); solo.grupo.name = 'sondagem3d'; solo.grupo.userData.sondagem = true;
    vols.forEach(function (v) {
      if (!v || !v.v || v.v.length !== 8) return;
      var h = soloHexa(v.v, v.cor || '#c8b58a', solo.opac);
      h.mesh.userData = { soloUnidade: v.unidade, nome: v.nome, critico: !!v.critico };
      solo.grupo.add(h.mesh); solo.grupo.add(h.arestas);
      solo.vols.push({ unidade: v.unidade, mesh: h.mesh, arestas: h.arestas, critico: !!v.critico, cor: v.cor });
    });
    // furos: cilindro fino, um trecho por camada, na cor do solo daquele trecho
    furos.forEach(function (f) {
      if (!f || f.x == null || f.y == null || f.zBoca == null) return;
      (f.trechos || []).forEach(function (t) {
        var alt = Math.max(0.01, t.ate - t.de);
        var cil = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, alt, 18), new THREE.MeshStandardMaterial({ color: new THREE.Color(t.cor || '#999'), roughness: 0.8 }));
        var c = soloV([f.x, f.y, f.zBoca - (t.de + t.ate) / 2]); cil.position.copy(c);
        cil.userData = { soloFuro: f.id }; solo.grupo.add(cil);
      });
      var topo = new THREE.Mesh(new THREE.CylinderGeometry(0.30, 0.30, 0.06, 18), new THREE.MeshStandardMaterial({ color: 0x1d1d1d }));
      topo.position.copy(soloV([f.x, f.y, f.zBoca + 0.03])); solo.grupo.add(topo);
      solo.furos.push({ id: f.id, x: f.x, y: f.y, zBoca: f.zBoca });
    });
    // plano de profundidade (o cursor do relatório): começa escondido
    if (def.area && def.area.length >= 4) {
      var a = def.area, sh = new THREE.Shape();
      sh.moveTo(a[0][0], a[0][1]); for (var i = 1; i < a.length; i++) sh.lineTo(a[i][0], a[i][1]);
      /* rotateX(−90°) leva (x, y, 0) em (x, 0, −y): é exatamente IFC (x, y) → cena (x, −y) */
      var pg = new THREE.ShapeGeometry(sh); pg.rotateX(-Math.PI / 2);
      var pl = new THREE.Mesh(pg, new THREE.MeshBasicMaterial({ color: 0x1565c0, transparent: true, opacity: 0.28, side: THREE.DoubleSide, depthWrite: false }));
      pl.visible = false; pl.renderOrder = 4; solo.plano = pl; solo.grupo.add(pl);
    }
    modelRoot.add(solo.grupo);
    solo.n = solo.vols.length;
    return { ok: true, volumes: solo.vols.length, furos: solo.furos.length };
  }
  function soloProfundidade(zIfc) {
    if (!solo.plano) return false;
    if (zIfc == null || !isFinite(+zIfc)) { solo.plano.visible = false; return true; }
    solo.plano.position.y = +zIfc; solo.plano.visible = true; return true;
  }
  function soloAplicarOpac() {
    solo.vols.forEach(function (v) {
      var alvo = solo.destaque == null ? solo.opac : (v.unidade === solo.destaque ? Math.min(0.92, solo.opac + 0.35) : solo.opac * 0.25);
      v.mesh.material.opacity = alvo; v.arestas.material.opacity = Math.min(1, alvo + 0.3);
    });
  }
  S._soloMostrar = soloMostrar; S._soloLimpar = soloLimpar; S._soloProfundidade = soloProfundidade;
  S._soloDestacar = function (u) { solo.destaque = (u == null || u === '') ? null : String(u); soloAplicarOpac(); return solo.destaque; };
  S._soloOpacidade = function (a) { solo.opac = Math.max(0.05, Math.min(1, +a || 0.5)); soloAplicarOpac(); return solo.opac; };
  S._soloEstado = function () {
    return { on: !!solo.grupo, volumes: solo.vols.map(function (v) { return { unidade: v.unidade, critico: v.critico, opacidade: +v.mesh.material.opacity.toFixed(3), cor: v.cor }; }),
             furos: solo.furos.slice(), plano: solo.plano ? { visivel: solo.plano.visible, y: solo.plano.position.y } : null, destaque: solo.destaque, opacidade: solo.opac,
             dentroDoModelRoot: !!(solo.grupo && solo.grupo.parent === modelRoot) };
  };

  // ============================================================
  // ✏️ EDITOR — cria/edita volumetria SINTÉTICA no viewer (motor puro:
  // js/bimedit.js; ops serializáveis, undo por REPLAY determinístico).
  // Honestidade RA: o que nasce aqui é "sintético (criado no OrçaPRO)"
  // com QTO exato das peças; elemento de IFC importado NUNCA é alterado —
  // "apagar" IFC apenas OCULTA marcado como removido na edição.
  // ============================================================
  var edit = { on: false, sub: null, p1: null, prov: null, ops: [], seq: 0,
               /* espLaje separado de esp de propósito: a espessura do TIPO DE
                  PAREDE (bloco + revestimento das duas faces) não tem relação
                  nenhuma com a espessura do piso. Compartilhar o campo fazia a
                  laje nascer com 19,7 cm em vez de 15 — 31% de concreto a mais,
                  em silêncio, e a espessura do piso virava função do reboco. */
               moverId: null, moverMesh: null, esp: 0.15, espLaje: 0.15, alt: 2.8, secao: 0.2,
               base: 0, modelo: null, sprites: [], removidosAntes: [],
               // v1.1.82 — desenho estilo Revit: trava orto, ângulo predefinido (0=livre),
               // traço ENCADEADO (a próxima parede continua do fim da anterior) e o último
               // ponto ajustado do preview (direção p/ o input de distância)
               orto: false, angPre: 0, chain: true, pPrev: null, linhaProv: null };
  S.edit = edit;
  var editPanel = document.createElement('div');
  editPanel.style.cssText = 'position:absolute;left:10px;top:52px;z-index:6;display:none;flex-direction:column;gap:8px;background:rgba(255,255,255,.985);border:1px solid #d3dce6;border-radius:12px;padding:10px 12px;color:#1a2b3c;font-size:12px;width:280px;max-width:94%';
  editPanel.innerHTML =
    '<div style="display:flex;justify-content:space-between;align-items:center"><b>' + (typeof Icones !== 'undefined' ? Icones.get('editar', 15) : '') + ' Editor <span style="color:#5b6b7c;font-weight:400">(sintético)</span></b><button class="btn sm" data-ed="fechar">' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + '</button></div>' +
    '<div style="display:flex;gap:6px;flex-wrap:wrap">' +
    '<button class="btn sm" data-ed="parede">' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Parede</button>' +
    '<button class="btn sm" data-ed="laje">' + (typeof Icones !== 'undefined' ? Icones.get('laje', 15) : '') + ' Laje</button>' +
    '<button class="btn sm" data-ed="pilar">' + (typeof Icones !== 'undefined' ? Icones.get('pilar', 15) : '') + ' Pilar</button>' +
    '<button class="btn sm" data-ed="mover">↔️ Mover</button>' +
    '<button class="btn sm" data-ed="apagar">' + (typeof Icones !== 'undefined' ? Icones.get('lixeira', 15) : '') + ' Apagar</button>' +
    '<button class="btn sm" data-ed="anotar">' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' Anotar</button></div>' +
    '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">' +
    '<label style="display:flex;gap:4px;align-items:center">Esp. <input data-ed="esp" class="inp" type="number" value="0.15" step="0.01" min="0.05" max="1.0" style="width:56px"> m</label>' +
    '<label style="display:flex;gap:4px;align-items:center">Alt. <input data-ed="alt" class="inp" type="number" value="2.80" step="0.1" min="0.3" max="8" style="width:56px"> m</label>' +
    '<label style="display:flex;gap:4px;align-items:center">Pilar <input data-ed="secao" class="inp" type="number" value="0.20" step="0.05" min="0.1" max="1" style="width:56px"> m</label></div>' +
    '<input data-ed="txt" class="inp" placeholder="Texto da anotação (p/ ' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' Anotar)" maxlength="200" style="width:100%">' +
    // v1.1.82 — controles de desenho estilo Revit (orto/ângulo/encadear)
    '<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">' +
    '<button class="btn sm" data-ed="orto" title="Trava a parede na horizontal/vertical (ou segure Shift enquanto desenha)">⟂ Orto</button>' +
    '<button class="btn sm" data-ed="angpre" title="Ângulos predefinidos: livre → 45° → 15°">∠ Livre</button>' +
    '<button class="btn sm" data-ed="chain" title="A próxima parede continua do fim da anterior (Esc encerra a cadeia)">⛓ Encadear</button>' +
    '</div>' +
    '<div style="font-size:10.5px;color:#5b6b7c">' + (typeof Icones !== 'undefined' ? Icones.get('lampada', 15) : '') + ' Desenhando parede: digite a <b>distância</b> na caixinha junto ao cursor e Enter — igual no Revit.</div>' +
    '<div style="display:flex;gap:6px;align-items:center"><button class="btn sm" data-ed="undo">' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Desfazer</button><span data-ed="st" style="color:#5b6b7c;font-size:11.5px"></span></div>' +
    '<div style="font-size:11px;color:#b45309;line-height:1.35">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Volumetria SINTÉTICA de estudo, com QTO exato das peças criadas. Elemento de IFC importado nunca muda — "apagar" só o oculta como removido na edição.</div>';
  host.appendChild(editPanel);
  S.editPanel = editPanel; // re-home re-parenteia via S.* — fora da lista o painel fica órfão
  var editMats = null;
  function editMat(tipo) {
    if (!editMats) {
      editMats = {
        parede: new THREE.MeshStandardMaterial({ color: 0xd8cfc0, metalness: .05, roughness: .85, side: THREE.DoubleSide }),
        laje: new THREE.MeshStandardMaterial({ color: 0x9aa7b4, metalness: .05, roughness: .9, side: THREE.DoubleSide }),
        pilar: new THREE.MeshStandardMaterial({ color: 0x7fa7d4, metalness: .1, roughness: .8, side: THREE.DoubleSide }),
        sel: new THREE.MeshStandardMaterial({ color: 0x22c55e, emissive: 0x114422, metalness: .1, roughness: .6, side: THREE.DoubleSide })
      };
    }
    return editMats[tipo] || editMats.parede;
  }
  function editBase() {
    try {
      // só modelos IMPORTADOS ancoram o plano de trabalho — incluir o próprio modelo
      // do editor faria a laje (que cresce pra baixo) rebaixar a base a cada reentrada
      var bb = new THREE.Box3(), tem = false;
      S.modelos.forEach(function (mo) { if (mo.mid === 'edit' || !mo.grupo) return; bb.expandByObject(mo.grupo); tem = true; });
      return (!tem || bb.isEmpty()) ? 0 : bb.min.y;
    } catch (_) { return 0; }
  }
  // ponto no PLANO DE TRABALHO (y = base) quando o raio não acha malha —
  // permite desenhar no vazio (terreno limpo) e ao lado do modelo
  function editPontoPlano(clientX, clientY) {
    var rc = canvasEl.getBoundingClientRect();
    mouse.x = ((clientX - rc.left) / rc.width) * 2 - 1; mouse.y = -((clientY - rc.top) / rc.height) * 2 + 1;
    ray.setFromCamera(mouse, camera);
    var alvo = new THREE.Vector3();
    var plano = new THREE.Plane(new THREE.Vector3(0, 1, 0), -edit.base); // y = base
    return ray.ray.intersectPlane(plano, alvo) ? alvo : null;
  }
  function editTirarProv() {
    if (edit.prov) { limparMarca(edit.prov); edit.prov = null; }
    edit.p1 = null;
    editPreviewLimpar();
  }
  // ---- v1.1.82: desenho estilo Revit ----
  // ajusta o 2º ponto pela trava orto (botão OU Shift) e pelos ângulos predefinidos
  function editAjustarPonto(p, ev) {
    if (!edit.p1 || !p || edit.sub !== 'parede') return p;
    var dx = p.x - edit.p1.x, dz = p.z - edit.p1.z;
    var dist = Math.sqrt(dx * dx + dz * dz);
    if (dist < 1e-6) return p;
    var q = p.clone(); q.y = edit.p1.y;
    if (edit.orto || (ev && ev.shiftKey)) {
      if (Math.abs(dx) >= Math.abs(dz)) q.z = edit.p1.z; else q.x = edit.p1.x;
      return q;
    }
    if (edit.angPre > 0) {
      var passo = edit.angPre * Math.PI / 180;
      var a2 = Math.round(Math.atan2(dz, dx) / passo) * passo;
      q.x = edit.p1.x + dist * Math.cos(a2); q.z = edit.p1.z + dist * Math.sin(a2);
    }
    return q;
  }
  // preview vivo (rubber-band) + caixinha de distância junto ao cursor (padrão do snapMarca:
  // DOM fora da cena — nunca é clipado nem raycastado)
  var editDist = document.createElement('div');
  editDist.style.cssText = 'position:absolute;z-index:6;display:none;background:rgba(255,255,255,.98);border:1px solid #2FBF71;border-radius:8px;padding:3px 6px;color:#1a2b3c;font-size:12px;white-space:nowrap;pointer-events:auto';
  editDist.innerHTML = '<span data-edd="txt" style="font-weight:700;color:#15803d"></span> <input data-edd="inp" inputmode="decimal" placeholder="m" style="width:52px;background:#ffffff;border:1px solid #9db4c8;border-radius:5px;color:#1a2b3c;font-size:12px;padding:1px 4px">';
  host.appendChild(editDist);
  S.editDist = editDist; // re-home
  function editPreviewLimpar() {
    if (edit.linhaProv) { scene.remove(edit.linhaProv); if (edit.linhaProv.geometry) edit.linhaProv.geometry.dispose(); edit.linhaProv = null; }
    edit.pPrev = null;
    editDist.style.display = 'none';
  }
  function editPreview(p, clientX, clientY) {
    if (!edit.p1 || !p) { editPreviewLimpar(); return; }
    edit.pPrev = p.clone();
    if (!edit.linhaProv) {
      if (!edit._linhaMat) edit._linhaMat = new THREE.LineBasicMaterial({ color: 0x2fbf71, depthTest: false }); // 1 material vivo (sem leak por segmento)
      var g3 = new THREE.BufferGeometry().setFromPoints([edit.p1, p]);
      edit.linhaProv = new THREE.Line(g3, edit._linhaMat);
      edit.linhaProv.renderOrder = 999;
      scene.add(edit.linhaProv);
    } else {
      edit.linhaProv.geometry.setFromPoints([edit.p1, p]);
    }
    var d = Math.sqrt(Math.pow(p.x - edit.p1.x, 2) + Math.pow(p.z - edit.p1.z, 2));
    var rc2 = canvasEl.getBoundingClientRect();
    editDist.style.display = '';
    editDist.style.left = (clientX - rc2.left + 16) + 'px';
    editDist.style.top = (clientY - rc2.top + 12) + 'px';
    var tx = editDist.querySelector('[data-edd="txt"]');
    if (tx) tx.textContent = d.toFixed(2).replace('.', ',') + ' m';
  }
  // digitar a distância + Enter = parede com o comprimento EXATO na direção do preview
  editDist.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { // Esc DENTRO do input: encerra a cadeia (o stopPropagation não pode engolir)
      e.stopPropagation();
      var iEsc = editDist.querySelector('[data-edd="inp"]'); if (iEsc) { iEsc.value = ''; iEsc.blur(); }
      if (S._editFimCadeia) S._editFimCadeia();
      return;
    }
    e.stopPropagation(); // não aciona atalhos do viewer (WASD do voo etc.)
    if (e.key !== 'Enter') return;
    var inp2 = editDist.querySelector('[data-edd="inp"]');
    var num2 = parseFloat(String(inp2.value || '').replace(',', '.'));
    if (!(num2 > 0.01) || !edit.p1) return;
    var dir;
    if (edit.pPrev) {
      var ddx = edit.pPrev.x - edit.p1.x, ddz = edit.pPrev.z - edit.p1.z;
      var len = Math.sqrt(ddx * ddx + ddz * ddz);
      dir = len > 1e-6 ? { x: ddx / len, z: ddz / len } : { x: 1, z: 0 };
    } else dir = { x: 1, z: 0 };
    var p2 = new THREE.Vector3(edit.p1.x + dir.x * num2, edit.p1.y, edit.p1.z + dir.z * num2);
    inp2.value = '';
    editConcluirParede(p2);
  });
  // conclui a parede em p2 (2º clique OU distância digitada) com o traço ENCADEADO
  function editConcluirParede(p2) {
    var cxP = BimEdit.parede({ x: edit.p1.x, z: edit.p1.z }, { x: p2.x, z: p2.z }, edit.esp, edit.alt, edit.base);
    if (!cxP) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Pontos muito próximos — clique 2 pontos distintos.'); return; }
    editOp({ op: 'criar', id: 'e' + (++edit.seq), caixa: cxP });
    var comp = cxP.comprimento.toFixed(2).replace('.', ',');
    if (edit.chain) {
      // encadeia: a próxima parede nasce do fim desta (Esc encerra a cadeia)
      if (edit.prov) { limparMarca(edit.prov); edit.prov = null; }
      editPreviewLimpar();
      edit.p1 = p2.clone();
      edit.prov = pontoMarca(p2); scene.add(edit.prov); rescaleObj(edit.prov);
      S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Parede criada (' + comp + ' m). ⛓ Continuando do fim — clique o próximo ponto, ou Esc pra encerrar.');
    } else {
      editTirarProv();
      S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Parede criada (' + comp + ' m). Siga clicando, ou Esc.');
    }
    marcarFechamento();
  }
  // Esc no meio da cadeia: encerra SÓ o traço (não fecha o editor)
  S._editFimCadeia = function () {
    editTirarProv();
    S._hint(edit.sub ? '' + (typeof Icones !== 'undefined' ? Icones.get('editar', 15) : '') + ' Traço encerrado — clique o INÍCIO da próxima parede.' : '');
    marcarFechamento();
  };
  // preview no pointermove (registrado lá em cima via S._ — o handler nasce antes deste bloco)
  var _edPrevT = 0;
  S._editPreviewMove = function (e) {
    var t2 = performance.now(); if (t2 - _edPrevT < 33) return; _edPrevT = t2;
    var hit2 = raycastEm(e.clientX, e.clientY);
    var sn2 = hit2 ? aplicarSnap(hit2, raioToque(e)) : null;
    var pM = sn2 ? sn2.p.clone() : editPontoPlano(e.clientX, e.clientY);
    if (!pM) return;
    editPreview(editAjustarPonto(pM, e), e.clientX, e.clientY);
  };
  function editSt() {
    var el = editPanel.querySelector('[data-ed="st"]');
    if (el) el.textContent = edit.ops.length + ' operação(ões) · ' + ((edit.modelo && edit.modelo.nEl) || 0) + ' elemento(s)';
    editPanel.querySelectorAll('[data-ed]').forEach(function (b) {
      var k = b.getAttribute('data-ed');
      if (['parede', 'laje', 'pilar', 'mover', 'apagar', 'anotar'].indexOf(k) >= 0) {
        b.style.background = (edit.sub === k) ? corAtiva() : ''; b.style.color = (edit.sub === k) ? '#fff' : '';
      }
    });
  }
  function editSoltarSel() {
    if (edit.moverMesh && edit.moverMesh.userData.matOrig) edit.moverMesh.material = edit.moverMesh.userData.matOrig;
    edit.moverMesh = null; edit.moverId = null;
  }
  // reconstrói o modelo sintético 'edit' a partir do REPLAY das ops (fonte
  // única de verdade = motor puro; nada de estado paralelo no viewer)
  // uid gravado numa op pode ser de OUTRA sessão (o mid muda com a ordem de abertura dos
  // arquivos) — resolve pela identidade estável arquivo+expressID quando o uid direto não existe
  function editUidRemovido(info) {
    if (S.meshPorUid[info.uid]) return info.uid;
    if (info.arq != null && info.eid != null) {
      var mo2 = S.modelos.filter(function (x) { return x.mid !== 'edit' && x.nome === info.arq; })[0];
      if (mo2) return mo2.mid + ':' + info.eid;
    }
    return info.uid;
  }
  function editRebuild() {
    // restaura visibilidade dos IFC ocultados na rodada anterior (diff limpo) — TODAS as
    // malhas do elemento (multi-material tem várias), compondo com o 4D
    if (edit.removidosAntes.length) {
      var ra = {}; edit.removidosAntes.forEach(function (u) { ra[u] = 1; });
      todasMalhas(function (m) { if (ra[m.userData.mid + ':' + m.userData.expressID]) m.visible = !ehFuturo4d(m); });
    }
    editSoltarSel();
    // a malha 'edit' selecionada será destruída+recriada abaixo: limpa a seleção/contorno obsoletos
    // (senão o contorno verde fica congelado na posição antiga — mesmo padrão de removerModelo). Gate v1.1.89.
    if (S.selected && S.selected.userData && S.selected.userData.mid === 'edit') { S.selected = null; S.prevMat = null; if (S._contornoSelecao) S._contornoSelecao(null); }
    if (edit.modelo) {
      modelRoot.remove(edit.modelo.grupo);
      edit.modelo.grupo.traverse(function (o) { if (o.geometry) o.geometry.dispose(); });
      edit.modelo.grupo.children.slice().forEach(function (m) { delete S.meshPorUid['edit:' + m.userData.expressID]; });
      var ix = S.modelos.indexOf(edit.modelo); if (ix >= 0) S.modelos.splice(ix, 1);
      edit.modelo = null;
    }
    edit.sprites.forEach(function (sp) { scene.remove(sp); if (sp.material && sp.material.map) sp.material.map.dispose(); if (sp.material) sp.material.dispose(); });
    edit.sprites = [];
    var st = BimEdit.aplicar(edit.ops);
    if (st.caixas.length) {
      var mo = { mid: 'edit', sintetico: true, editor: true, nome: 'Criados no OrçaPRO (' + st.caixas.length + ')', disciplina: 'arquitetura', alpha: 1, visivel: true, grupo: new THREE.Group(), matCache: {}, transCache: {}, elementos: [], tipos: {}, nEl: 0, nTri: 0, pavimentos: [], carimbos: {}, qto: {} };
      mo.grupo.userData.mid = 'edit';
      st.caixas.forEach(function (c) {
        var g = new THREE.BoxGeometry(c.comprimento, c.altura, c.espessura);
        var m = new THREE.Mesh(g, editMat(c.tipo));
        m.position.set(c.cx, c.cy, c.cz); m.rotation.y = c.rotY;
        m.userData.expressID = c.id; m.userData.tipo = c.ifc; m.userData.mid = 'edit'; m.userData.matOrig = editMat(c.tipo);
        mo.grupo.add(m);
        S.meshPorUid['edit:' + c.id] = m;
        mo.nTri += 12; mo.tipos[c.ifc] = (mo.tipos[c.ifc] || 0) + 1;
        mo.qto[c.id] = { comprimento: c.tipo === 'pilar' ? (c.comprimentoPilar || c.altura) : c.comprimento, area: c.area, volume: c.volume, contagem: 1 };
        mo.elementos.push({ id: c.id, uid: 'edit:' + c.id, mid: 'edit', arquivo: mo.nome, tipo: c.ifc, nome: (c.tipo === 'parede' ? 'Parede' : c.tipo === 'laje' ? 'Laje' : 'Pilar') + ' (sintética ' + c.id + ')', etapa: null, codOrc: null, qto: mo.qto[c.id], disciplina: 'arquitetura' });
        mo.nEl++;
      });
      modelRoot.add(mo.grupo);
      try {
        modelRoot.updateMatrixWorld(true);
        mo.grupo.children.forEach(function (m) {
          var bb = new THREE.Box3().setFromObject(m);
          var elx = mo.elementos.filter(function (e2) { return e2.id === m.userData.expressID; })[0];
          if (elx && !bb.isEmpty()) elx.aabb = { min: [bb.min.x, bb.min.y, bb.min.z], max: [bb.max.x, bb.max.y, bb.max.z] };
        });
      } catch (_) {}
      S.modelos.push(mo);
      recarimbarIdentidade();   /* B0: criados no editor, GlobalId proprio */
      agregarModelo(mo);        /* B2 */
      carimbarConsulta();     /* B3 */
      edit.modelo = mo;
    }
    st.anotacoes.forEach(function (a) {
      var sp = labelSprite('📍 ' + a.texto);
      sp.position.set(a.x, a.y, a.z); sp.userData._anotId = a.id;
      scene.add(sp); rescaleObj(sp); edit.sprites.push(sp);
    });
    // oculta os removidos (uid resolvido p/ a sessão atual; TODAS as malhas do elemento) e
    // publica S._remEd — todo escritor de visibilidade (4D/isolar/restaurar/focar) compõe com ele
    S._remEd = {};
    (st.removidosIfcInfo || []).forEach(function (info) { S._remEd[editUidRemovido(info)] = 1; });
    if (st.removidosIfc.length) todasMalhas(function (m) { if (S._remEd[m.userData.mid + ':' + m.userData.expressID]) m.visible = false; });
    edit.removidosAntes = Object.keys(S._remEd);
    S.elementos = []; S.modelos.forEach(function (mo2) { S.elementos = S.elementos.concat(mo2.elementos); });
    over.style.display = (S.modelos.length || st.anotacoes.length) ? 'none' : 'flex'; // sintético/anotação também tira o "arraste um IFC"
    atualizarHud(); notifyModelos(); editSt();
    if (opts.onLoaded) opts.onLoaded(elementosVivos());
    if (opts.onEdicao && !edit._replay) { try { opts.onEdicao(edit.ops.slice()); } catch (_) {} }
  }
  S._tickExtra.push(function () { for (var i = 0; i < edit.sprites.length; i++) rescaleObj(edit.sprites[i]); });
  function editOp(o) { edit.ops.push(o); editRebuild(); }
  function editHintSub() {
    var h = { parede: '' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Clique o INÍCIO e o FIM da parede (no modelo ou no chão vazio).',
              laje: '' + (typeof Icones !== 'undefined' ? Icones.get('laje', 15) : '') + ' Clique 2 cantos OPOSTOS do retângulo da laje.',
              pilar: '' + (typeof Icones !== 'undefined' ? Icones.get('pilar', 15) : '') + ' Clique onde o pilar nasce.',
              mover: '↔️ Clique num elemento CRIADO AQUI e depois no novo lugar (IFC não se move — honestidade).',
              apagar: '' + (typeof Icones !== 'undefined' ? Icones.get('lixeira', 15) : '') + ' Clique no elemento: criado aqui = removido; do IFC = ocultado como "removido na edição".',
              anotar: '' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' Escreva o texto no campo e clique no ponto do modelo.' };
    S._hint(edit.sub ? h[edit.sub] : '' + (typeof Icones !== 'undefined' ? Icones.get('editar', 15) : '') + ' Editor: escolha uma ferramenta no painel.');
  }
  function editClique(e, hit) {
    var sn = hit ? aplicarSnap(hit, raioToque(e)) : null;
    var p = sn ? sn.p.clone() : editPontoPlano(e.clientX, e.clientY);
    if (sn) mostrarSnapMarca(sn, e.clientX, e.clientY);
    var sub = edit.sub;
    if (sub === 'apagar') {
      if (!hit) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('lixeira', 15) : '') + ' Clique em cima de um elemento.'); return; }
      var mA = _ultimosHits[0].object, midA = mA.userData.mid, idA = mA.userData.expressID;
      if (midA === 'edit') { editOp({ op: 'apagar', id: idA }); S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('lixeira', 15) : '') + ' Removido (Desfazer volta).'); }
      else {
        var moRem = S.modelos.filter(function (x) { return x.mid === midA; })[0];
        // arq+eid = identidade que sobrevive a F5/ordem de abertura (o mid é da sessão)
        editOp({ op: 'apagarIfc', uid: midA + ':' + idA, arq: moRem ? moRem.nome : null, eid: idA });
        S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('lixeira', 15) : '') + ' Elemento do modelo OCULTADO como removido na edição — o arquivo original não muda.');
      }
      marcarFechamento(); return;
    }
    if (sub === 'mover') {
      if (!edit.moverId) {
        if (!hit) { S._hint('↔️ Clique num elemento criado no editor.'); return; }
        var mM = _ultimosHits[0].object;
        if (mM.userData.mid !== 'edit') { S._hint('↔️ Só elementos CRIADOS AQUI se movem (IFC importado não é alterado).'); return; }
        edit.moverId = mM.userData.expressID; edit.moverMesh = mM; mM.material = editMat('sel');
        S._hint('↔️ Agora clique no NOVO lugar (o centro vai pra lá).'); return;
      }
      if (!p) { S._hint('↔️ Não achei o ponto — clique no modelo ou no plano do chão.'); return; }
      editOp({ op: 'mover', id: edit.moverId, cx: p.x, cz: p.z });
      S._hint('↔️ Movido. Clique noutro elemento pra mover de novo, ou Esc.');
      marcarFechamento(); return;
    }
    if (!p) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('editar', 15) : '') + ' Não achei o ponto — clique no modelo ou no plano do chão.'); return; }
    if (sub === 'pilar') {
      var cP = BimEdit.pilar({ x: p.x, z: p.z }, edit.secao, edit.alt, edit.base);
      if (cP) { editOp({ op: 'criar', id: 'e' + (++edit.seq), caixa: cP }); S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('pilar', 15) : '') + ' Pilar criado. Clique pra outro, ou Esc.'); }
      marcarFechamento(); return;
    }
    if (sub === 'anotar') {
      var txt = (editPanel.querySelector('[data-ed="txt"]').value || '').trim();
      if (!txt) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' Escreva o texto da anotação no painel primeiro.'); return; }
      editOp({ op: 'anotar', id: 'a' + (++edit.seq), x: p.x, y: p.y, z: p.z, texto: txt });
      S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' Anotado! O pin fica salvo com a obra.');
      marcarFechamento(); return;
    }
    if (sub === 'parede' || sub === 'laje') {
      if (!edit.p1) {
        edit.p1 = p.clone();
        edit.prov = pontoMarca(p); scene.add(edit.prov); rescaleObj(edit.prov);
        S._hint(sub === 'parede' ? '' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Agora clique o FIM da parede (ou digite a distância na caixinha + Enter).' : '' + (typeof Icones !== 'undefined' ? Icones.get('laje', 15) : '') + ' Agora clique o canto OPOSTO.');
        return;
      }
      if (sub === 'parede') { editConcluirParede(editAjustarPonto(p, e)); return; } // orto/ângulo/encadeado/distância
      var cx2 = BimEdit.laje({ x: edit.p1.x, z: edit.p1.z }, { x: p.x, z: p.z }, Math.min(edit.espLaje, 0.4), edit.base);
      editTirarProv();
      if (!cx2) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('editar', 15) : '') + ' Pontos muito próximos — clique 2 pontos distintos.'); return; }
      editOp({ op: 'criar', id: 'e' + (++edit.seq), caixa: cx2 });
      S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('laje', 15) : '') + ' Laje criada (' + cx2.area.toFixed(2).replace('.', ',') + ' m²).');
      marcarFechamento(); return;
    }
  }
  function setEditSub(sub) {
    edit.sub = (edit.sub === sub) ? null : sub;
    editTirarProv(); editSoltarSel(); editHintSub(); editSt();
    canvasEl.style.cursor = edit.sub ? 'crosshair' : '';
    // ferramenta ativa marcada no painel — sem isso o toggle fica invisível pro usuário
    ['parede', 'laje', 'pilar', 'mover', 'apagar', 'anotar'].forEach(function (k) {
      var b = editPanel.querySelector('[data-ed="' + k + '"]'); if (!b) return;
      var on2 = edit.sub === k;
      b.style.background = on2 ? corAtiva() : ''; b.style.color = on2 ? '#fff' : '';
    });
  }
  function setEdit(on) {
    edit.on = !!on;
    if (on) {
      if (medir.on) setMedir(false); if (area.on) setArea(false); if (ang.on) setAng(false);
      if (ctec.ativo && S._ctecCancelar) S._ctecCancelar(true);
      setMode(false); fecharPaineis(null);
      edit.base = editBase();
      editPanel.style.display = 'flex';
      editHintSub(); editSt();
    } else {
      editTirarProv(); editSoltarSel();
      edit.sub = null; editPanel.style.display = 'none';
      canvasEl.style.cursor = ''; S._hint('');
    }
    var be = bar.querySelector('[data-b="editar"]'); if (be) { be.style.background = on ? corAtiva() : ''; be.style.color = on ? '#fff' : ''; }
  }
  S._setEdit = setEdit;
  S._editOps = function () { return edit.ops.slice(); };
  S._editAplicar = function (ops) {
    if (!S || !S.alive) return; // viewer morto (ctx perdido): rebuild apagaria o aviso de recarregar
    edit.ops = BimEdit.sanear(ops);
    var mx = 0;
    edit.ops.forEach(function (o) { var m2 = /^[ea](\d+)$/.exec(String(o.id || '')); if (m2) mx = Math.max(mx, parseInt(m2[1], 10)); });
    edit.seq = mx;
    // replay NÃO re-dispara onEdicao (gravaria de volta o que acabou de ser lido)
    edit._replay = true;
    try { editRebuild(); } finally { edit._replay = false; }
    // replay externo (reentrar na obra / F5): enquadra o que voltou — no uso ao vivo
    // a câmera NÃO pula (editRebuild não enquadra; o usuário está desenhando nela)
    if (edit.ops.length) enquadrar();
  };
  // IFC chega DEPOIS do replay (pós-F5 só as ops persistem): re-resolve os removidos
  // sobre o modelo recém-carregado — sem isto o "removido na edição" voltaria visível
  S._editReaplicarRem = function () {
    if (!edit.ops.length) return;
    var st2 = BimEdit.aplicar(edit.ops);
    if (!st2.removidosIfc.length) return;
    S._remEd = {};
    (st2.removidosIfcInfo || []).forEach(function (info) { S._remEd[editUidRemovido(info)] = 1; });
    todasMalhas(function (m) { if (S._remEd[m.userData.mid + ':' + m.userData.expressID]) m.visible = false; });
    edit.removidosAntes = Object.keys(S._remEd);
  };
  // 🗑 Limpar / remover o modelo "Criados no OrçaPRO": o editor zera JUNTO (persistido) —
  // senão pins ficam órfãos na cena e a próxima op ressuscitaria tudo do replay
  S._editReset = function () {
    edit.ops = []; edit.seq = 0; edit.removidosAntes = []; edit.modelo = null; S._remEd = null;
    edit.sprites.forEach(function (sp) { scene.remove(sp); if (sp.material && sp.material.map) sp.material.map.dispose(); if (sp.material) sp.material.dispose(); });
    edit.sprites = [];
    if (edit.on) setEdit(false);
    if (opts.onEdicao) { try { opts.onEdicao([]); } catch (_) {} }
  };
  editPanel.addEventListener('click', function (e) {
    var b = e.target.closest('[data-ed]'); if (!b) return; var k = b.getAttribute('data-ed');
    if (k === 'fechar') setEdit(false);
    else if (k === 'undo') { if (edit.ops.length) { edit.ops.pop(); editTirarProv(); editRebuild(); S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Desfeito.'); } else { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Nada pra desfazer.'); } } // TirarProv: cadeia não pode ficar apontando pra parede que sumiu
    else if (k === 'orto') { edit.orto = !edit.orto; b.style.background = edit.orto ? corAtiva() : ''; b.style.color = edit.orto ? '#fff' : ''; S._hint(edit.orto ? '⟂ Orto LIGADO — paredes só na horizontal/vertical.' : '⟂ Orto desligado (Shift também trava).'); }
    else if (k === 'angpre') {
      edit.angPre = edit.angPre === 0 ? 45 : (edit.angPre === 45 ? 15 : 0);
      b.textContent = '∠ ' + (edit.angPre === 0 ? 'Livre' : edit.angPre + '°');
      b.style.background = edit.angPre ? corAtiva() : ''; b.style.color = edit.angPre ? '#fff' : '';
      S._hint(edit.angPre ? '∠ Ângulos travados em múltiplos de ' + edit.angPre + '°.' : '∠ Ângulo livre.');
    }
    else if (k === 'chain') { edit.chain = !edit.chain; b.style.background = edit.chain ? corAtiva() : ''; b.style.color = edit.chain ? '#fff' : ''; S._hint(edit.chain ? '⛓ Encadear LIGADO — cada parede continua da anterior (Esc encerra o traço).' : '⛓ Encadear desligado.'); }
    else if (['parede', 'laje', 'pilar', 'mover', 'apagar', 'anotar'].indexOf(k) >= 0) setEditSub(k);
  });
  // estado inicial dos toggles (chain nasce ligado — fluxo Revit)
  (function () { var bC = editPanel.querySelector('[data-ed="chain"]'); if (bC) { bC.style.background = corAtiva(); bC.style.color = '#fff'; } })();
  editPanel.addEventListener('change', function (e) {
    var i = e.target.closest('input[data-ed]'); if (!i) return; var k = i.getAttribute('data-ed'), v = parseFloat(i.value);
    // clamp nos limites do input — valor DIGITADO ignora min/max do HTML (parede de 50 m de espessura não passa)
    var lim = { esp: [0.05, 1.0], alt: [0.3, 8], secao: [0.1, 1] }[k];
    if (!lim || !(v > 0) || !isFinite(v)) return;
    v = Math.min(lim[1], Math.max(lim[0], v));
    i.value = String(v);
    /* o mesmo campo alimenta parede e laje conforme a ferramenta ativa */
    if (k === 'esp') { if (edit.sub === 'laje') edit.espLaje = v; else edit.esp = v; }
    else if (k === 'alt') edit.alt = v; else edit.secao = v;
  });

  /* --------------------------------------------------------------
   * O TIPO DE PAREDE manda na espessura do editor.
   * Até aqui, `edit.esp` nascia com 0,15 m FIXOS: o painel de tipo
   * calculava a parede executiva em 19,7 cm e o 3D desenhava 15.
   * Agora quem define é o tipo ativo (js/alvtipos.js), e o número
   * chega aqui em metros, já somado com as camadas das duas faces.
   * -------------------------------------------------------------- */
  S._setEspEditor = function (metros, rotulo) {
    var v = parseFloat(metros);
    if (!(v > 0) || !isFinite(v)) return false;
    /* se não mudou nada, não escreve: o painel de propriedades repinta a cada
       tecla, e sobrescrever aqui apagaria o que o usuário digitou no viewer */
    if (Math.abs(v - edit.esp) < 1e-6 && (rotulo || "") === (edit.tipoRotulo || "")) return true;
    /* parede de 5 cm ou de 5 m não existe. O teto sobe para 1,00 m porque a
       espessura agora inclui as camadas: bloco de 19 com emboço nas duas
       faces já passa de 24 cm, e parede dupla passa de 60. */
    v = Math.min(1.0, Math.max(0.05, v));
    edit.esp = v;
    edit.tipoRotulo = rotulo || "";
    /* o campo na tela mostra a grandeza da ferramenta ATIVA — se o usuário
       está no Piso, escrever a espessura da parede ali seria mentira */
    if (edit.sub !== 'laje') {
      var inp = editPanel.querySelector('input[data-ed="esp"]');
      if (inp) inp.value = String(Math.round(v * 1000) / 1000);
    }
    return true;
  };
  S._espEditor = function () { return { esp: edit.esp, espLaje: edit.espLaje, tipo: edit.tipoRotulo || "" }; };

  var p3d = { parse: null, det: null };
  var p3dPanel = document.createElement('div');
  p3dPanel.style.cssText = 'position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:6;display:none;flex-direction:column;gap:8px;background:rgba(255,255,255,.985);border:1px solid #d3dce6;border-radius:12px;padding:14px 16px;color:#1a2b3c;font-size:12px;width:480px;max-width:94%;max-height:92%;overflow:auto;box-shadow:0 12px 34px rgba(0,0,0,.5)';
  p3dPanel.innerHTML =
    '<div style="display:flex;justify-content:space-between;align-items:center"><b>' + (typeof Icones !== 'undefined' ? Icones.get('obra', 15) : '') + ' Planta 2D → 3D (DXF)</b><button class="btn sm" data-p3="fechar">' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + '</button></div>' +
    '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">' +
    '<button class="btn sm primary" data-p3="abrir">' + (typeof Icones !== 'undefined' ? Icones.get('abrir', 15) : '') + ' Abrir .DXF</button>' +
    '<label style="display:flex;gap:5px;align-items:center">Pé-direito <input data-p3="pd" class="inp" type="number" value="2.80" step="0.1" min="2" max="6" style="width:64px"> m</label>' +
    '<label style="display:flex;gap:5px;align-items:center">Unidade <select data-p3="un" class="inp" style="width:76px"><option value="">auto</option><option value="0.001">mm</option><option value="0.01">cm</option><option value="1">m</option></select></label>' +
    '<input type="file" data-p3="file"' + (ehToque() ? '' : ' accept=".dxf"') + ' style="display:none"></div>' +
    '<div data-p3="info" style="font-size:11.5px;color:#5b6b7c">Exporte a planta baixa do seu CAD em <b>DXF</b> (AutoCAD/QCAD/LibreCAD; DWG? salve-como DXF). O sistema propõe as paredes — você confirma.</div>' +
    '<canvas data-p3="cv" width="448" height="300" style="background:#0b1a2b;border:1px solid #d3dce6;border-radius:8px;cursor:pointer;display:none"></canvas>' +
    '<div data-p3="res" style="font-size:12px"></div>' +
    '<button class="btn sm primary" data-p3="gerar" style="display:none">' + (typeof Icones !== 'undefined' ? Icones.get('obra', 15) : '') + ' Gerar 3D</button>' +
    '<div style="font-size:11px;color:#b45309;line-height:1.35">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Volumetria de ESTUDO (paredes por par de linhas paralelas de 6–40 cm) — clique numa parede verde do preview pra ligar/desligar. Portas, janelas e cobertura não entram nesta fase. Não substitui o projeto.</div>';
  host.appendChild(p3dPanel);
  S.p3dPanel = p3dPanel;
  function toggleP3dPanel() { var abrir = p3dPanel.style.display === 'none' || !p3dPanel.style.display; fecharPaineis(null); p3dPanel.style.display = abrir ? 'flex' : 'none'; }
  S._toggleP3d = toggleP3dPanel; // a fita chama por aqui (BIM.painelP3d)
  function p3dDesenhar() {
    var cv = p3dPanel.querySelector('[data-p3="cv"]'); if (!cv || !p3d.parse) return;
    cv.style.display = '';
    var g = cv.getContext('2d'), ex = p3d.parse.extents;
    g.fillStyle = '#0b1a2b'; g.fillRect(0, 0, cv.width, cv.height);
    if (!ex) return;
    var mrg = 14, sw = (cv.width - mrg * 2) / Math.max(1e-6, ex.x1 - ex.x0), sh = (cv.height - mrg * 2) / Math.max(1e-6, ex.y1 - ex.y0);
    var sc = Math.min(sw, sh);
    function px(x) { return mrg + (x - ex.x0) * sc; }
    function py(y) { return cv.height - mrg - (y - ex.y0) * sc; } // Y da planta pra cima
    p3d._px = px; p3d._py = py; p3d._sc = sc;
    g.strokeStyle = '#3a5570'; g.lineWidth = 1;
    p3d.parse.segmentos.forEach(function (s) { g.beginPath(); g.moveTo(px(s.x1), py(s.y1)); g.lineTo(px(s.x2), py(s.y2)); g.stroke(); });
    (p3d.det ? p3d.det.paredes : []).forEach(function (p) {
      g.strokeStyle = p.ligada !== false ? '#22c55e' : '#64748b';
      g.setLineDash(p.ligada !== false ? [] : [5, 4]);
      g.lineWidth = Math.max(3, p.espessura * sc);
      g.beginPath(); g.moveTo(px(p.x1), py(p.y1)); g.lineTo(px(p.x2), py(p.y2)); g.stroke();
      g.setLineDash([]);
    });
  }
  function p3dResumo() {
    var res = p3dPanel.querySelector('[data-p3="res"]'), bg = p3dPanel.querySelector('[data-p3="gerar"]');
    if (!p3d.det) { res.innerHTML = ''; bg.style.display = 'none'; return; }
    var ligadas = p3d.det.paredes.filter(function (p) { return p.ligada !== false; });
    var mTot = ligadas.reduce(function (s, p) { return s + p.comprimento; }, 0);
    res.innerHTML = '<b style="color:#15803d">' + ligadas.length + ' parede(s) ligadas</b> (' + mTot.toFixed(1).replace('.', ',') + ' m lineares) · ' +
      /* NÃO AFIRMAR A CAUSA. "portas/mobiliário/cotas" era chute apresentado
         como fato: no DXF com a parede fatiada em LINEs, boa parte dos
         sem-par é FACE DE PAREDE que o pareador não casou — e o texto
         mandava o usuário ignorar justamente o que estava faltando. */
      p3d.det.stats.segmentosSemPar + ' segmento(s) não formaram par (porta, mobiliário, cota — ou face de parede que o pareador não casou) · unidade: ' + (p3d.parse.unidade.origem === 'insunits' ? 'do arquivo' : p3d.parse.unidade.origem);
    /* O MOTIVO SAI DO PRÓPRIO OBJETO, não de uma lista fixa de causas.
       Concatenar só viaTrio e provavelPilar como se fossem exaustivas
       imprimia "⚠ 4 item(ns) NÃO entram no 3D: ." — prefixo com ponto solto
       e nenhuma explicação — sempre que a exclusão viesse por outro caminho. */
    var dubias = p3d.det.paredes.filter(function (p) { return p.ligada === false; });
    if (dubias.length) {
      var nTrio = dubias.filter(function (p) { return p.viaTrio; }).length;
      var nPil = dubias.filter(function (p) { return p.provavelPilar && !p.viaTrio; }).length;
      var nOutro = dubias.length - nTrio - nPil;
      var mot = [];
      if (nTrio) mot.push(nTrio + ' com três linhas paralelas (pode ser cota, não parede)');
      if (nPil) mot.push(nPil + ' com comprimento próximo da espessura (parece pilar, contaria em dobro)');
      if (nOutro > 0) mot.push(nOutro + ' desligados por você');
      res.innerHTML += '<br><span style="color:#b45309">⚠ ' + dubias.length + ' NÃO entram no 3D: ' + mot.join(' · ') + '.</span>';
    }
    /* botão que gera NADA não fica oferecido: com zero ligadas ele produzia
       um modelo vazio e o painel continuava aberto, sem dizer por quê */
    if (!ligadas.length) {
      bg.style.display = 'none';
      /* dois casos DIFERENTES, e mandar clicar no segundo é mandar clicar
         no vazio: sem parede proposta não há o que ligar no desenho */
      res.innerHTML += p3d.det.paredes.length
        ? '<br><b style="color:#b45309">Nenhuma parede ligada</b> — clique nas do desenho para ligar ' +
          'o que for parede de verdade. O 3D só nasce com pelo menos uma.'
        : '<br><b style="color:#b45309">Nenhuma parede foi proposta</b> — não há o que clicar. ' +
          'Confira a UNIDADE no seletor acima (envergadura errada joga toda espessura fora da faixa de ' +
          '6–40 cm) e explode os blocos no CAD antes de exportar.';
      return;
    }
    bg.style.display = ''; bg.textContent = '' + (typeof Icones !== 'undefined' ? Icones.get('obra', 15) : '') + ' Gerar 3D (' + ligadas.length + ' paredes)';
  }
  function p3dProcessar(texto, nome) {
    if (typeof window === 'undefined' || !window.DXF || !window.Planta3D) { S._hint('' + (typeof Icones !== 'undefined' ? Icones.get('obra', 15) : '') + ' Motores 2D→3D não carregados — atualize o app.'); return; }
    p3d._texto = String(texto || ''); // guardado: trocar a unidade re-processa (a UI instrui isso)
    var fu = parseFloat(p3dPanel.querySelector('[data-p3="un"]').value) || 0;
    p3d.parse = window.DXF.parse(texto, fu > 0 ? { fatorUnidade: fu } : {});
    p3d.nome = nome || 'planta.dxf';
    var info = p3dPanel.querySelector('[data-p3="info"]');
    if (!p3d.parse.segmentos.length) { info.innerHTML = '' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Não achei geometria 2D neste DXF (só ' + JSON.stringify(p3d.parse.stats.ignoradas) + '). Exporte como DXF ASCII (R12/2000) com as linhas das paredes.'; p3d.det = null; p3dDesenhar(); p3dResumo(); return; }
    /* ESCADA, HACHURA E COTA SAEM ANTES — este painel chamava o detector
       direto e não passava pelo filtro de famílias que o assistente de
       volumetria usa. Um lance de escada de 28 cm cai no meio da faixa de
       espessura de parede e virava meia dúzia de paredes por aqui. */
    var fam3d = window.Planta3D.filtrarFamilias(p3d.parse.segmentos, { espMin: 0.06, espMax: 0.40, angTol: 4 });
    p3d.familias = fam3d.familias || [];
    p3d.det = window.Planta3D.detectarParedes(fam3d.segmentos);
    var env = p3d.parse.extents ? ((p3d.parse.extents.x1 - p3d.parse.extents.x0).toFixed(1) + '×' + (p3d.parse.extents.y1 - p3d.parse.extents.y0).toFixed(1) + ' m') : '—';
    var ign = Object.keys(p3d.parse.stats.ignoradas || {}).map(function (k) { return k + '×' + p3d.parse.stats.ignoradas[k]; }).join(', ');
    info.innerHTML = '<b>' + esc(p3d.nome) + '</b> · ' + p3d.parse.segmentos.length + ' segmentos · envergadura ' + env +
      (p3d.parse.unidade.origem.indexOf('heuristica') === 0 ? ' · <span style="color:#b45309">unidade ASSUMIDA (' + p3d.parse.unidade.origem.slice(11) + ') — confira a envergadura e corrija no seletor se preciso</span>' : '');
    if (ign) info.innerHTML += '<br>' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Entidades ignoradas: ' + esc(ign) + (/INSERT/.test(ign) ? ' — geometria DENTRO de bloco não entra: exploda os blocos no CAD antes de exportar.' : '.');
    if (!p3d.det.paredes.length) info.innerHTML += '<br>' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Nenhum par de linhas com cara de parede (6–40 cm). Confira a UNIDADE — envergadura errada = espessuras fora da faixa.';
    /* o que saiu e o que entrou DESMARCADO tem de aparecer: sem isso o
       painel diz "N paredes" e gera outro número */
    if (p3d.familias.length) {
      info.innerHTML += '<br>' + (typeof Icones !== 'undefined' ? Icones.get('proibido', 15) : '') + ' Descartado como não-parede: ' + p3d.familias.map(function (fx) {
        return fx.linhas + ' linhas a ' + Math.round(fx.espacamento * 100) + ' cm (' + esc(fx.motivo) + ')';
      }).join(' · ') + '. Parede tem DUAS faces.';
    }
    /* o aviso do que NÃO entra mora no resumo, não aqui: o bloco `info` só
       é escrito ao abrir o arquivo, e depois que o usuário liga paredes na
       mão ele continuaria afirmando que N itens ficam de fora */
    p3dDesenhar(); p3dResumo();
  }
  p3dPanel.addEventListener('click', function (e) {
    var b = e.target.closest('[data-p3]'); if (!b) return; var k = b.getAttribute('data-p3');
    if (k === 'fechar') p3dPanel.style.display = 'none';
    else if (k === 'abrir') p3dPanel.querySelector('[data-p3="file"]').click();
    else if (k === 'gerar') {
      if (!p3d.det) return;
      var pd = parseFloat(p3dPanel.querySelector('[data-p3="pd"]').value) || 2.8;
      var caixas = window.Planta3D.extrudar(p3d.det.paredes, pd);
      var mid = carregarSintetico(caixas, p3d.nome.replace(/\.dxf$/i, '') + ' (2D→3D)');
      if (mid) { p3dPanel.style.display = 'none'; S._hint('🏗 ' + caixas.length + ' paredes no 3D! O QTO já mede os m² — e a ' + (typeof Icones !== 'undefined' ? Icones.get('bloco', 15) : '') + ' Parede-Cebola explode em camadas SINAPI no orçamento.'); }
    }
  });
  p3dPanel.addEventListener('change', function (e) {
    var t = e.target;
    if (t.getAttribute('data-p3') === 'file' && t.files && t.files[0]) {
      var f = t.files[0], fr = new FileReader();
      /* mesma razão do IFC: sem `accept` no celular, quem valida somos nós */
      if (!/\.dxf$/i.test(f.name || '')) {
        t.value = '';
        var m3 = 'O arquivo “' + f.name + '” não é um DXF. Exporte a planta do seu CAD em DXF e tente de novo.';
        try { if (typeof UI !== 'undefined' && UI.toast) UI.toast(m3, 'erro'); else alert(m3); } catch (_) {}
        return;
      }
      fr.onload = function () { p3dProcessar(String(fr.result || ''), f.name); };
      fr.readAsText(f); t.value = '';
    } else if (t.getAttribute('data-p3') === 'un' && p3d._texto) { p3dProcessar(p3d._texto, p3d.nome); } // achado do gate: era no-op — agora re-parseia com a unidade nova
  });
  // clique no preview: liga/desliga a parede proposta mais próxima
  p3dPanel.querySelector('[data-p3="cv"]').addEventListener('click', function (e) {
    if (!p3d.det || !p3d._px) return;
    var cv = e.target, rc = cv.getBoundingClientRect();
    var mx = (e.clientX - rc.left) * (cv.width / rc.width), my = (e.clientY - rc.top) * (cv.height / rc.height);
    var melhor = null, dMin = 12;
    p3d.det.paredes.forEach(function (p) {
      var x1 = p3d._px(p.x1), y1 = p3d._py(p.y1), x2 = p3d._px(p.x2), y2 = p3d._py(p.y2);
      var dx = x2 - x1, dy = y2 - y1, L2 = dx * dx + dy * dy;
      var t2 = L2 > 0 ? Math.max(0, Math.min(1, ((mx - x1) * dx + (my - y1) * dy) / L2)) : 0;
      var d = Math.sqrt(Math.pow(mx - (x1 + dx * t2), 2) + Math.pow(my - (y1 + dy * t2), 2));
      if (d < dMin) { dMin = d; melhor = p; }
    });
    if (melhor) { melhor.ligada = melhor.ligada === false; p3dDesenhar(); p3dResumo(); }
  });
  S._p3dProcessar = p3dProcessar; // hook de teste (injeta o texto DXF sem file input)

  // rejeição NÃO fica memoizada: falha transitória do wasm (offline/atualização) permite retentar na próxima carga
  function initApi() { if (!S._initP) S._initP = (async function () { S.api.SetWasmPath('bim/vendor/'); await S.api.Init(); S.apiReady = true; })().catch(function (e) { S._initP = null; throw e; }); return S._initP; }
  var _loadChain = Promise.resolve(); // cadeia LOCAL do mount (a global misturaria cargas de um viewer morto com o novo)
  function enfileirar(fn) { _loadChain = _loadChain.then(fn, fn); return _loadChain; }

  // Lê os carimbos do exportador pyRevit e devolve mapa expressID -> {etapa, codOrc}.
  // Uma passada por todos os IfcRelDefinesByProperties; para cada, resolve o pset e varre
  // seus IfcPropertySingleValue atrás de OrcaPRO_Etapa/OrcaPRO_CodOrc, atribuindo a TODOS os
  // RelatedObjects (um rel pode carimbar vários elementos). Blindado: qualquer falha de leitura
  // devolve o que já achou — NUNCA impede o modelo 3D de abrir (property é bônus sobre a geometria).
  /* =====================================================================
   * TOPOLOGIA DA REDE — porta a porta, como o IFC publica.
   *
   * Três passadas no molde de `lerCarimbosOrcaPro`:
   *   IfcRelConnectsPortToElement  porta  → peça
   *   IfcRelConnectsPorts          porta ↔ porta
   *   IfcDistributionPort          o sentido do fluxo, quando declarado
   *
   * ⚠ PREGUIÇOSA, DE PROPÓSITO. Não entra no bloco síncrono da carga: são
   *   ~20 mil chamadas que TODO cliente pagaria ao abrir QUALQUER modelo,
   *   inclusive quem nunca vai numerar rede — e no celular isso é aba
   *   travada. Roda no primeiro uso e fica no `modelo.topologia`.
   *
   * ⚠ E NÃO usar a rota inversa `HasPorts`: medido no arquivo real, 1.120 ms
   *   contra 131 ms destas três passadas em lote.
   *
   * ⚠ O SENTIDO NÃO ORDENA NADA. No arquivo real, 2.246 das 8.430 portas
   *   (27%) são SOURCEANDSINK — o IFC não diz para onde corre. FlowDirection
   *   serve só para ESCOLHER a ponta onde o percurso começa; quando não há,
   *   a origem é declarada arbitrária em vez de deduzida. */
  function lerTopologiaRede(mid) {
    var mo = modeloDe(mid);
    if (mo && mo.topologia) return mo.topologia;
    /* ⚠ B1: sem isto um modelo restaurado varreria o WASM com mid string e
       leria a rede de OUTRO arquivo. Topologia vazia e a resposta honesta. */
    if (semWasm(mo)) return { portaDe: {}, ligacao: {}, portasDe: {}, dirPorta: {}, nPortas: 0, nLigacoes: 0 };
    var topo = { portaDe: {}, ligacao: {}, portasDe: {}, dirPorta: {}, nPortas: 0, nLigacoes: 0 };
    try {
      var re1 = S.api.GetLineIDsWithType(mid, IFC_RELCONNECTSPORTTOELEMENT), n1 = re1.size();
      for (var i = 0; i < n1; i++) {
        var r1; try { r1 = S.api.GetLine(mid, re1.get(i), false); } catch (_) { continue; }
        if (!r1 || !r1.RelatingPort || !r1.RelatedElement) continue;
        var pid = r1.RelatingPort.value, eid = r1.RelatedElement.value;
        if (pid == null || eid == null) continue;
        var uid = mid + ':' + eid;
        topo.portaDe[pid] = uid;
        (topo.portasDe[uid] = topo.portasDe[uid] || []).push(pid);
        topo.nPortas++;
      }
      var re2 = S.api.GetLineIDsWithType(mid, IFC_RELCONNECTSPORTS), n2 = re2.size();
      for (var j = 0; j < n2; j++) {
        var r2; try { r2 = S.api.GetLine(mid, re2.get(j), false); } catch (_) { continue; }
        if (!r2 || !r2.RelatingPort || !r2.RelatedPort) continue;
        var pa = r2.RelatingPort.value, pb = r2.RelatedPort.value;
        if (pa == null || pb == null) continue;
        topo.ligacao[pa] = pb; topo.ligacao[pb] = pa;
        topo.nLigacoes++;
      }
      var re3 = S.api.GetLineIDsWithType(mid, IFC_DISTRIBUTIONPORT), n3 = re3.size();
      for (var k = 0; k < n3; k++) {
        var id3 = re3.get(k), p3;
        try { p3 = S.api.GetLine(mid, id3, false); } catch (_) { continue; }
        /* enum chega embrulhado: { type: 3, value: 'SINK' } — sem os pontos do STEP */
        if (p3 && p3.FlowDirection && p3.FlowDirection.value) topo.dirPorta[id3] = String(p3.FlowDirection.value);
      }
    } catch (e) { /* topologia é bônus: falha devolve o que já achou */ }
    if (mo) mo.topologia = topo;
    return topo;
  }

  /* =====================================================================
   * BITOLA — o raio que o projetista declarou, não medido por nós.
   *
   * O pset do tubo traz só Length/Manufacturer/Reference: a bitola NÃO está
   * lá. Mas está publicada na geometria, no perfil que foi varrido:
   *   IfcExtrudedAreaSolid.SweptArea → IfcCircleProfileDef.Radius
   * Amostra do arquivo real: raio 0,05 m → 100 mm de diâmetro externo, que é
   * como o PVC é designado comercialmente no Brasil.
   *
   * ⚠ É Ø EXTERNO, e o rótulo diz isso. Chamar de "DN" sem ressalva
   *   atropelaria a norma em bitola onde o DN nominal não é o externo — no
   *   PVC brasileiro coincide, em outros materiais não.
   *
   * ⚠ E É POR ELEMENTO, sob demanda. Varrer todos os IfcCircleProfileDef de
   *   uma vez sairia mais barato, mas o perfil não sabe a que peça pertence:
   *   o caminho de volta é justamente pela representação do elemento. Só roda
   *   para o que vai entrar na lista. */
  function lerBitolaMm(mid, eid, fLen) {
    /* ⚠ B1: o cache traz a bitola pronta; o modelo sintetico nao tem nenhuma.
       Os dois precisam sair antes do GetLine (ver `semWasm`). */
    var moB = modeloDe(mid);
    if (semWasm(moB)) return (moB.bitolas && moB.bitolas[eid]) || 0;
    try {
      var el = S.api.GetLine(mid, eid, false);
      if (!el || !el.Representation || el.Representation.value == null) return 0;
      var pds = S.api.GetLine(mid, el.Representation.value, false);
      var reps = pds && pds.Representations; if (!reps) return 0;
      reps = Array.isArray(reps) ? reps : [reps];
      for (var i = 0; i < reps.length; i++) {
        if (!reps[i] || reps[i].value == null) continue;
        var sr; try { sr = S.api.GetLine(mid, reps[i].value, false); } catch (_) { continue; }
        var itens = sr && sr.Items; if (!itens) continue;
        itens = Array.isArray(itens) ? itens : [itens];
        for (var j = 0; j < itens.length; j++) {
          if (!itens[j] || itens[j].value == null) continue;
          var it; try { it = S.api.GetLine(mid, itens[j].value, false); } catch (_) { continue; }
          if (!it || !it.SweptArea || it.SweptArea.value == null) continue;
          var pf; try { pf = S.api.GetLine(mid, it.SweptArea.value, false); } catch (_) { continue; }
          if (!pf) continue;
          var r = pf.Radius; if (r && r.value != null) r = r.value;
          /* perfil OCO (anel de vedação) traz Radius + WallThickness: o
             externo continua sendo Radius, então serve igual */
          var v = parseFloat(r);
          if (!isNaN(v) && v > 0) return Math.round(v * 2 * (fLen || 1) * 1000);
        }
      }
    } catch (_) {}
    return 0;
  }

  /* O PERFIL I DA PEÇA (IfcIShapeProfileDef da área varrida), em METROS pela unidade do arquivo — a peça içada da física do
     içamento (ESPEC-ICAMENTO §II.4.5: W pela geometria da seção). Mesmo caminho do lerBitolaMm. Sem wasm (cache) ou sem perfil
     I: null — a física mostra "sem dado (perfil)" em vez de inventar a seção. */
  function lerPerfilI(mid, eid) {
    var moP = modeloDe(mid);
    if (!moP || semWasm(moP)) return null;
    var fLen = unidadePrefixoBase(mid, 'LENGTHUNIT'); if (fLen == null) fLen = 1;
    function vl(x) { var n = x && x.value != null ? parseFloat(x.value) : parseFloat(x); return isFinite(n) && n > 0 ? n * fLen : null; }
    try {
      var el = S.api.GetLine(mid, eid, false);
      if (!el || !el.Representation || el.Representation.value == null) return null;
      var pds = S.api.GetLine(mid, el.Representation.value, false);
      var reps = pds && pds.Representations; if (!reps) return null;
      reps = Array.isArray(reps) ? reps : [reps];
      for (var i = 0; i < reps.length; i++) {
        if (!reps[i] || reps[i].value == null) continue;
        var sr; try { sr = S.api.GetLine(mid, reps[i].value, false); } catch (_) { continue; }
        var itens = sr && sr.Items; if (!itens) continue;
        itens = Array.isArray(itens) ? itens : [itens];
        for (var j = 0; j < itens.length; j++) {
          if (!itens[j] || itens[j].value == null) continue;
          var it; try { it = S.api.GetLine(mid, itens[j].value, false); } catch (_) { continue; }
          if (!it || !it.SweptArea || it.SweptArea.value == null) continue;
          var pf; try { pf = S.api.GetLine(mid, it.SweptArea.value, false); } catch (_) { continue; }
          var h = vl(pf && pf.OverallDepth), b = vl(pf && pf.OverallWidth), tw = vl(pf && pf.WebThickness), tf = vl(pf && pf.FlangeThickness);
          if (h && b && tw && tf) return { tipo: 'I', h: h, b: b, tw: tw, tf: tf, comprimento: vl(it.Depth), fonte: 'IfcIShapeProfileDef do IFC' + (pf.ProfileName && pf.ProfileName.value ? ' (' + pf.ProfileName.value + ')' : '') };
        }
      }
    } catch (_) {}
    return null;
  }
  S._icarPerfil = function (uid) { var p = String(uid || '').split(':'); return p.length === 2 ? lerPerfilI(+p[0], +p[1]) : null; };

  /* Nomes sob os quais o campo "Descrição" do Revit chega num pset. Varia por
     exportador e pelo idioma da instalação — por isso os três, sem acento e em
     minúscula. ⚠ Lista FECHADA de propósito: qualquer propriedade cujo nome
     "pareça" descrição entraria como nome de mercado e iria parar na linha que
     o fornecedor lê. Só entra o que É o campo Descrição. */
  var NOME_DESCRICAO = { description: 1, descricao: 1, 'descrição': 1 };
  function ehNomeDeDescricao(nm) {
    var s = String(nm == null ? '' : nm).trim().toLowerCase()
      .replace(/[àáâãä]/g, 'a').replace(/[èéêë]/g, 'e').replace(/[ìíîï]/g, 'i')
      .replace(/[òóôõö]/g, 'o').replace(/[ùúûü]/g, 'u').replace(/ç/g, 'c');
    return !!NOME_DESCRICAO[s];
  }

  /* ⚠ TRÊS FONTES, UMA ORDEM SÓ, E O CARIMBO DE QUAL VENCEU.
     A mesma "Descrição" do Revit chega ao IFC por caminhos diferentes conforme
     o exportador: atributo da instância, atributo do tipo, ou propriedade num
     pset. Ler as três é o que impede o recurso de funcionar no modelo de um
     cliente e ficar inerte no do outro. Do mais específico para o mais geral —
     e a fonte viaja junto porque um "ok" decidido por texto livre não vale o
     mesmo que um decidido pela geometria, e quem confere precisa saber disso.
     ⚠ O nome NÃO se inventa: sem nenhuma das três, sai vazio e o casador segue
     com a família, exatamente como antes. */
  function descricaoDeMercado(idIfc, famEl, carimbo) {
    var inst = (idIfc && String(idIfc.descricao || '').trim()) || '';
    if (inst) return { descricao: inst, fonte: 'instancia' };
    var tipo = (famEl && String(famEl.descricao || '').trim()) || '';
    if (tipo) return { descricao: tipo, fonte: 'tipo' };
    var ps = (carimbo && String(carimbo.descricaoPset || '').trim()) || '';
    if (ps) return { descricao: ps, fonte: 'pset' };
    return { descricao: '', fonte: '' };
  }

  function lerCarimbosOrcaPro(mid) {
    var mapa = {};
    try {
      var rels = S.api.GetLineIDsWithType(mid, IFC_RELDEFINESBYPROPERTIES);
      var nRel = rels.size();
      for (var i = 0; i < nRel; i++) {
        var rel; try { rel = S.api.GetLine(mid, rels.get(i), false); } catch (_) { continue; }
        if (!rel || !rel.RelatingPropertyDefinition || !rel.RelatedObjects) continue;
        var psetID = rel.RelatingPropertyDefinition.value; if (psetID == null) continue;
        var pset; try { pset = S.api.GetLine(mid, psetID, false); } catch (_) { continue; }
        if (!pset || !pset.HasProperties) continue; // não é IfcPropertySet (ex.: quantities/type)
        var props = Array.isArray(pset.HasProperties) ? pset.HasProperties : [pset.HasProperties];
        var etapa = null, cod = null, fase = null, descrPset = null, tarefa = null, discP = null, detalhe = null, montagem = null, folha = null;
        for (var p = 0; p < props.length; p++) {
          var h = props[p]; if (!h || h.value == null) continue;
          var pv; try { pv = S.api.GetLine(mid, h.value, false); } catch (_) { continue; }
          if (!pv || pv.type !== IFC_PROPERTYSINGLEVALUE) continue;
          var nm = pv.Name && pv.Name.value;
          if (nm === 'OrcaPRO_Etapa' && pv.NominalValue) etapa = pv.NominalValue.value;
          else if (nm === 'OrcaPRO_CodOrc' && pv.NominalValue) cod = pv.NominalValue.value;
          else if (nm === 'OrcaPRO_Fase' && pv.NominalValue) fase = pv.NominalValue.value; // reforma: nova|demolir|existente
          /* a TAREFA do plano executivo ("3.2 Pilares"): o elo que liga a peça
             ao prazo, ao custo e ao avanço dela (js/bimelo.js) */
          else if (nm === 'OrcaPRO_Tarefa' && pv.NominalValue) tarefa = pv.NominalValue.value;
          /* a DISCIPLINA / etapa construtiva da peça ("Fundação", "Armação",
             "Painéis de parede") — o filtro "só fundação / só armação" do
             js/bimdisc.js — e o DETALHE do projeto estrutural que desenha a
             peça ("S5", "P6", "BALDRAMES/V3"), que liga a peça à vista do PDF
             (js/estrutpdf.js). Carimbados pelo plugin ou pelo gerador do modelo. */
          else if (nm === 'OrcaPRO_Disciplina' && pv.NominalValue) discP = pv.NominalValue.value;
          else if (nm === 'OrcaPRO_Detalhe' && pv.NominalValue) detalhe = pv.NominalValue.value;
          /* a ETAPA DE MONTAGEM ("M05 · Vigas primárias"): a ordem em que a peça
             sobe na obra. Não é a etapa da EAP — a mesma etapa 09 do orçamento tem
             pilares (M06) e coberturas (M10, M12) que sobem em dias diferentes. */
          else if (nm === 'OrcaPRO_Montagem' && pv.NominalValue) montagem = pv.NominalValue.value;
          /* as FOLHAS que desenham a peça ("OBRA-FUND_R02 folha 02; …"): o
             "Ver no 3D" de uma prancha inteira do Projeto estrutural casa por
             aqui (js/estrutui.js casaFolha) — por identidade, nunca pelo texto */
          else if (nm === 'OrcaPRO_Folha' && pv.NominalValue) folha = pv.NominalValue.value;
          /* ⚠ TERCEIRA PORTA DA DESCRIÇÃO, e ela sai de graça. Nem todo
             exportador leva o campo Descrição do Revit para o atributo
             `Description` do IFC — vários o despejam como propriedade num
             pset. Esta varredura por TODOS os IfcRelDefinesByProperties já
             estava acontecendo aqui para achar o carimbo do plugin, então
             pegar a descrição junto não custa nem uma leitura a mais. Sem
             isto, um modelo com a descrição preenchida no Revit chegaria ao
             casador SEM ela, e o sintoma seria "não melhorou nada". */
          else if (nm && pv.NominalValue && descrPset == null && ehNomeDeDescricao(nm)) {
            var vD = pv.NominalValue.value;
            if (vD != null && String(vD).trim()) descrPset = String(vD).trim();
          }
        }
        if (etapa == null && cod == null && fase == null && descrPset == null && tarefa == null && discP == null && detalhe == null && montagem == null && folha == null) continue;
        var objs = Array.isArray(rel.RelatedObjects) ? rel.RelatedObjects : [rel.RelatedObjects];
        for (var o = 0; o < objs.length; o++) {
          var oh = objs[o]; if (!oh || oh.value == null) continue;
          var eid = oh.value; if (!mapa[eid]) mapa[eid] = {};
          if (etapa != null) mapa[eid].etapa = etapa;
          if (cod != null) mapa[eid].codOrc = cod;
          if (fase != null) mapa[eid].fase = fase;
          if (tarefa != null && String(tarefa).trim()) mapa[eid].tarefa = String(tarefa).trim();
          if (discP != null && String(discP).trim()) mapa[eid].disciplinaPeca = String(discP).trim();
          if (detalhe != null && String(detalhe).trim()) mapa[eid].detalhe = String(detalhe).trim();
          if (montagem != null && String(montagem).trim()) mapa[eid].montagem = String(montagem).trim();
          if (folha != null && String(folha).trim()) mapa[eid].folhas = String(folha).trim();
          if (descrPset != null && !mapa[eid].descricaoPset) mapa[eid].descricaoPset = descrPset;
        }
      }
    } catch (e) { /* leitura de propriedades é bônus; nunca impede o modelo de abrir */ }
    return mapa;
  }

  // v1.1.82 — FAMÍLIA/TIPO por elemento (IfcRelDefinesByType): o Revit exporta o nome do TIPO
  // como Name do IfcTypeObject (e 'Família:Tipo' no ObjectType da instância). Devolve mapa
  // expressID -> { familia, tipoId } — tipoId guarda o IfcTypeObject p/ ler os psets do TIPO depois.
  // Blindado: property é bônus, nunca impede o 3D de abrir.
  function lerTipos(mid) {
    var mapa = {};
    try {
      var rels = S.api.GetLineIDsWithType(mid, IFC_RELDEFINESBYTYPE);
      var n = rels.size();
      for (var i = 0; i < n; i++) {
        var rel; try { rel = S.api.GetLine(mid, rels.get(i), false); } catch (_) { continue; }
        if (!rel || !rel.RelatingType || !rel.RelatedObjects) continue;
        var tid = rel.RelatingType.value; if (tid == null) continue;
        var tipoObj; try { tipoObj = S.api.GetLine(mid, tid, false); } catch (_) { continue; }
        var nomeFam = (tipoObj && tipoObj.Name && tipoObj.Name.value) || null;
        if (!nomeFam) continue;
        /* ⚠ ESTA É A "Descrição" QUE O ENGENHEIRO VÊ NO REVIT — o campo de
           Dados de identidade do TIPO, onde a biblioteca do fabricante grava
           o nome comercial. É por tipo, então vale para todas as instâncias
           dele de uma vez, e sai do `tipoObj` que já foi lido aqui. */
        var descrFam = (tipoObj && tipoObj.Description && tipoObj.Description.value) || '';
        var objs = Array.isArray(rel.RelatedObjects) ? rel.RelatedObjects : [rel.RelatedObjects];
        for (var o = 0; o < objs.length; o++) {
          var oh = objs[o]; if (!oh || oh.value == null) continue;
          mapa[oh.value] = { familia: nomeFam, tipoId: tid, descricao: descrFam };
        }
      }
    } catch (e) { /* bônus */ }
    return mapa;
  }

  /* MATERIAL por objeto (IfcRelAssociatesMaterial) → { id: [{ n, f, rho }] }:
   * `n` o nome do material no IFC, `f` a fração do volume (camadas de parede
   * pela espessura; constituinte pela `Fraction`; null quando o IFC não diz) e
   * `rho` a massa específica que o PRÓPRIO IFC publica (Pset_MaterialCommon
   * .MassDensity, kg/m³), quando publica.
   *
   * ⚠ O MATERIAL PODE ESTAR NO TIPO, não na peça (o Revit faz isso com
   *   família). O mapa sai por objeto — peça OU tipo — e quem monta o elemento
   *   cai no do tipo (`familias[eid].tipoId`) quando a peça não tem o seu.
   * ⚠ Sem fração, NADA de dividir igual entre os materiais: uma janela de
   *   alumínio e vidro meio a meio seria um número inventado. O motor do peso
   *   recusa a peça e pede o material, em vez de chutar. */
  function lerMateriais(mid) {
    var mapa = {}, memo = {}, dens = {};
    function linha(id) { if (id == null) return null; try { return S.api.GetLine(mid, id, false); } catch (_) { return null; } }
    function lista(x) { return x == null ? [] : (Array.isArray(x) ? x : [x]); }
    function ref(x) { return (x && x.value != null) ? x.value : null; }
    function numv(x) { if (x == null) return NaN; if (typeof x === 'object') x = x.value; var v = parseFloat(x); return isNaN(v) ? NaN : v; }
    try {
      var mps = S.api.GetLineIDsWithType(mid, IFC_MATERIALPROPERTIES), nmp = mps.size();
      for (var a = 0; a < nmp; a++) {
        var mp = linha(mps.get(a)), matId = mp && ref(mp.Material); if (matId == null) continue;
        lista(mp.Properties).forEach(function (h) {
          var pv = linha(ref(h)); if (!pv || pv.type !== IFC_PROPERTYSINGLEVALUE) return;
          if (!pv.Name || pv.Name.value !== 'MassDensity' || !pv.NominalValue) return;
          var v = numv(pv.NominalValue.value); if (v > 0) dens[matId] = v;
        });
      }
    } catch (_) {}
    function item(matId, f) {
      var m = linha(matId), n = m && m.Name && m.Name.value ? String(m.Name.value).trim() : '';
      return n ? { n: n, f: (f == null || isNaN(f)) ? null : f, rho: dens[matId] || null } : null;
    }
    function resolver(id, prof) {
      if (id == null || prof > 4) return [];
      if (memo[id]) return memo[id];
      var m = linha(id), out = [];
      if (m) {
        var t = m.type;
        if (t === IFC_MATERIAL) { var it = item(id, null); if (it) out.push(it); }
        else if (t === IFC_MATERIALLAYERSETUSAGE) out = resolver(ref(m.ForLayerSet), prof + 1);
        else if (t === IFC_MATERIALPROFILESETUSAGE) out = resolver(ref(m.ForProfileSet), prof + 1);
        else if (t === IFC_MATERIALLAYERSET) {
          var cams = lista(m.MaterialLayers).map(function (h) { return linha(ref(h)); }).filter(Boolean), tot = 0;
          cams.forEach(function (c) { var e = numv(c.LayerThickness); if (e > 0) tot += e; });
          cams.forEach(function (c) { var e = numv(c.LayerThickness), it2 = item(ref(c.Material), tot > 0 ? (e > 0 ? e / tot : 0) : null); if (it2) out.push(it2); });
        } else if (t === IFC_MATERIALPROFILESET) {
          lista(m.MaterialProfiles).forEach(function (h) { var p = linha(ref(h)), it3 = p && item(ref(p.Material), null); if (it3) out.push(it3); });
        } else if (t === IFC_MATERIALCONSTITUENTSET) {
          lista(m.MaterialConstituents).forEach(function (h) { var c = linha(ref(h)), it4 = c && item(ref(c.Material), numv(c.Fraction)); if (it4) out.push(it4); });
        } else if (t === IFC_MATERIALLIST) {
          lista(m.Materials).forEach(function (h) { var it5 = item(ref(h), null); if (it5) out.push(it5); });
        }
      }
      /* ⚠ perfil com o mesmo material repetido (montante + travessa do mesmo
         aço) contaria duas vezes o mesmo nome: junta, somando a fração */
      var por = {}, uniq = [];
      out.forEach(function (x) {
        if (!por[x.n]) { por[x.n] = { n: x.n, f: x.f, rho: x.rho }; uniq.push(por[x.n]); }
        else if (por[x.n].f != null && x.f != null) por[x.n].f += x.f;
        else por[x.n].f = null;
      });
      memo[id] = uniq;
      return uniq;
    }
    try {
      var rels = S.api.GetLineIDsWithType(mid, IFC_RELASSOCIATESMATERIAL), n = rels.size();
      for (var i = 0; i < n; i++) {
        var rel = linha(rels.get(i)); if (!rel || !rel.RelatingMaterial || !rel.RelatedObjects) continue;
        var mats = resolver(ref(rel.RelatingMaterial), 0); if (!mats.length) continue;
        lista(rel.RelatedObjects).forEach(function (oh) { var eid = ref(oh); if (eid != null) mapa[eid] = mats; });
      }
    } catch (e) { /* bônus: material nunca impede o modelo de abrir */ }
    return mapa;
  }

  // v1.1.98 — SISTEMA por elemento (IfcRelAssignsToGroup → IfcSystem/IfcDistributionSystem): o Revit
  // agrupa a tubulação em sistemas nomeados ("Sanitário 1", "Água Fria 3", "Ventilação 2"…). É esse
  // Name que diz o SISTEMA de verdade — o nome do elemento costuma ser genérico ("Tubo/duto"). Só
  // aceita grupos que SÃO sistema (filtra IfcGroup genérico, ex.: "Grupo de modelos"). Blindado.
  function lerSistemas(mid) {
    var mapa = {};
    try {
      var rels = S.api.GetLineIDsWithType(mid, IFC_RELASSIGNSTOGROUP);
      var n = rels.size();
      for (var i = 0; i < n; i++) {
        var rel; try { rel = S.api.GetLine(mid, rels.get(i), false); } catch (_) { continue; }
        if (!rel || !rel.RelatingGroup || rel.RelatingGroup.value == null || !rel.RelatedObjects) continue;
        var grp; try { grp = S.api.GetLine(mid, rel.RelatingGroup.value, false); } catch (_) { continue; }
        if (!grp || (grp.type !== IFC_SYSTEM && grp.type !== IFC_DISTRIBUTIONSYSTEM)) continue; // só SISTEMA (não zona/grupo/lista)
        var nomeSis = (grp.Name && grp.Name.value) || (grp.LongName && grp.LongName.value) || null;
        if (!nomeSis) continue;
        var objs = Array.isArray(rel.RelatedObjects) ? rel.RelatedObjects : [rel.RelatedObjects];
        for (var o = 0; o < objs.length; o++) {
          var oh = objs[o]; if (!oh || oh.value == null) continue;
          if (!mapa[oh.value]) mapa[oh.value] = nomeSis; // 1º sistema vence (um elemento pode estar em vários grupos)
        }
      }
    } catch (e) { /* bônus */ }
    return mapa;
  }

  // valor legível de uma property (SingleValue/Enumerated/List/Bounded/Complex — nada é descartado)
  function propValor(mid, pv) {
    try {
      if (pv.type === IFC_PROPERTYSINGLEVALUE) return pv.NominalValue != null ? pv.NominalValue.value : null;
      if (pv.type === IFC_PROP_ENUM) return (pv.EnumerationValues || []).map(function (x) { return x && x.value; }).join(", ");
      if (pv.type === IFC_PROP_LIST) return (pv.ListValues || []).map(function (x) { return x && x.value; }).join(", ");
      if (pv.type === IFC_PROP_BOUNDED) {
        var lo = pv.LowerBoundValue && pv.LowerBoundValue.value, hi = pv.UpperBoundValue && pv.UpperBoundValue.value;
        return (lo != null ? lo : "…") + " – " + (hi != null ? hi : "…");
      }
      if (pv.type === IFC_PROP_COMPLEX) {
        var subs = Array.isArray(pv.HasProperties) ? pv.HasProperties : [pv.HasProperties];
        return subs.map(function (h) {
          try { var sub = S.api.GetLine(mid, h.value, false); return (sub.Name && sub.Name.value) + ": " + propValor(mid, sub); } catch (_) { return ""; }
        }).filter(Boolean).join(" · ");
      }
    } catch (e) {}
    return null;
  }
  function lerPropsDePset(mid, psetId, grupos, origem) {
    var pset; try { pset = S.api.GetLine(mid, psetId, false); } catch (_) { return; }
    if (!pset) return;
    var nomePset = (pset.Name && pset.Name.value) || "Propriedades";
    var props = [];
    if (pset.HasProperties) { // IfcPropertySet
      var hs = Array.isArray(pset.HasProperties) ? pset.HasProperties : [pset.HasProperties];
      for (var p = 0; p < hs.length; p++) {
        var h = hs[p]; if (!h || h.value == null) continue;
        var pv; try { pv = S.api.GetLine(mid, h.value, false); } catch (_) { continue; }
        if (!pv) continue;
        var v = propValor(mid, pv);
        if (v != null && v !== "") props.push({ n: (pv.Name && pv.Name.value) || "?", v: String(v) });
      }
    } else if (pset.Quantities) { // IfcElementQuantity — quantidades cruas do arquivo
      var qs = Array.isArray(pset.Quantities) ? pset.Quantities : [pset.Quantities];
      for (var q = 0; q < qs.length; q++) {
        var qh = qs[q]; if (!qh || qh.value == null) continue;
        var qv; try { qv = S.api.GetLine(mid, qh.value, false); } catch (_) { continue; }
        if (!qv) continue;
        var val = null, camp = ["LengthValue", "AreaValue", "VolumeValue", "CountValue", "WeightValue"];
        for (var c = 0; c < camp.length; c++) if (qv[camp[c]] != null) { val = qv[camp[c]].value != null ? qv[camp[c]].value : qv[camp[c]]; break; }
        if (val != null) props.push({ n: (qv.Name && qv.Name.value) || "?", v: String(val) });
      }
    }
    if (props.length) grupos.push({ pset: nomePset, origem: origem, props: props });
  }
  // TODAS as propriedades de um elemento, on-demand (clique): psets da INSTÂNCIA
  // (IfcRelDefinesByProperties) + psets do TIPO/família (IfcTypeObject.HasPropertySets — atributo
  // direto, caminho diferente!). Devolve [{pset, origem:'instância'|'família', props:[{n,v}]}].
  function propsCompletas(mid, expressID) {
    var grupos = [];
    var mo = modeloDe(mid);
    /* ⚠ B1: o cache guarda o que os paineis do produto consomem (etapa,
       quantitativo, familia, sistema, pavimento) e NAO guarda o despejo
       completo de psets do arquivo — sao dezenas de propriedades por peca,
       vezes dezenas de milhares de pecas. Aqui isso e DITO, em vez de a lista
       aparecer curta e o usuario achar que o projetista nao preencheu. */
    if (mo && mo.doCache) {
      var elK = (mo.elementos || []).filter(function (e) { return e.id === expressID; })[0];
      var qK = (mo.qto && mo.qto[expressID]) || null;
      var pr = [];
      if (elK && elK.tipo) pr.push({ n: 'Tipo IFC', v: String(elK.tipo) });
      if (elK && elK.globalId) pr.push({ n: 'GlobalId', v: String(elK.globalId) });
      if (elK && elK.familia) pr.push({ n: 'Família/tipo', v: String(elK.familia) });
      if (elK && elK.descricao) pr.push({ n: 'Descrição (nome de mercado)', v: String(elK.descricao) });
      if (elK && elK.tag) pr.push({ n: 'Tag', v: String(elK.tag) });
      if (elK && elK.etapa) pr.push({ n: 'Etapa (OrçaPRO)', v: String(elK.etapa) });
      if (elK && elK.codOrc) pr.push({ n: 'Código do orçamento', v: String(elK.codOrc) });
      if (pr.length) grupos.push({ pset: 'Do modelo guardado', origem: 'instância', props: pr });
      if (qK) grupos.push({ pset: 'Quantitativos', origem: 'instância', props: [
        { n: 'Comprimento', v: String(qK.comprimento == null ? '—' : qK.comprimento) },
        { n: 'Área', v: String(qK.area == null ? '—' : qK.area) },
        { n: 'Volume', v: String(qK.volume == null ? '—' : qK.volume) }] });
      grupos.push({ pset: 'Lista completa de propriedades', origem: 'instância', props: [
        { n: 'Não está guardada', v: 'Abra o arquivo .ifc de novo para ver todas as propriedades desta peça.' }] });
      return grupos;
    }
    if (mo && mo.sintetico) { // criado no OrçaPRO: propriedades do editor
      var elS = (mo.elementos || []).filter(function (e) { return e.id === expressID; })[0];
      if (elS && elS.qto) grupos.push({ pset: "Dimensões (criado no OrçaPRO)", origem: "instância", props: [
        { n: "Comprimento (m)", v: String(elS.qto.comprimento || 0) }, { n: "Área (m²)", v: String(elS.qto.area || 0) }, { n: "Volume (m³)", v: String(elS.qto.volume || 0) }] });
      return grupos;
    }
    try {
      // psets da instância
      var rels = S.api.GetLineIDsWithType(mid, IFC_RELDEFINESBYPROPERTIES);
      var n = rels.size();
      for (var i = 0; i < n; i++) {
        var rel; try { rel = S.api.GetLine(mid, rels.get(i), false); } catch (_) { continue; }
        if (!rel || !rel.RelatingPropertyDefinition || !rel.RelatedObjects) continue;
        var objs = Array.isArray(rel.RelatedObjects) ? rel.RelatedObjects : [rel.RelatedObjects];
        var meu = false;
        for (var o = 0; o < objs.length; o++) if (objs[o] && objs[o].value === expressID) { meu = true; break; }
        if (!meu) continue;
        lerPropsDePset(mid, rel.RelatingPropertyDefinition.value, grupos, "instância");
      }
      // psets do TIPO (família)
      var fam = (mo && mo.familias && mo.familias[expressID]) || null;
      if (fam && fam.tipoId != null) {
        var tipoObj; try { tipoObj = S.api.GetLine(mid, fam.tipoId, false); } catch (_) { tipoObj = null; }
        if (tipoObj && tipoObj.HasPropertySets) {
          var hps = Array.isArray(tipoObj.HasPropertySets) ? tipoObj.HasPropertySets : [tipoObj.HasPropertySets];
          for (var t = 0; t < hps.length; t++) if (hps[t] && hps[t].value != null) lerPropsDePset(mid, hps[t].value, grupos, "família");
        }
      }
    } catch (e) { /* bônus */ }
    return grupos;
  }

  // Fator linear do prefixo do IfcSIUnit de um tipo (LENGTHUNIT/AREAUNIT/VOLUMEUNIT). Ex.: CENTI→0.01.
  // Devolve null se o tipo não estiver declarado no arquivo. IMPORTANTE: no IFC, área e volume têm
  // unidade PRÓPRIA (SQUARE_METRE/CUBIC_METRE, quase sempre m²/m³ mesmo com comprimento em cm/mm) —
  // por isso NÃO se converte área com comprimento². Só se AREAUNIT/VOLUMEUNIT faltarem é que caímos
  // no derivado (comprimento² / comprimento³).
  function unidadePrefixoBase(mid, tipo) {
    try {
      var us = S.api.GetLineIDsWithType(mid, IFC_SIUNIT), n = us.size();
      for (var i = 0; i < n; i++) {
        var u; try { u = S.api.GetLine(mid, us.get(i), false); } catch (_) { continue; }
        if (!u || !u.UnitType || u.UnitType.value !== tipo) continue;
        var p = u.Prefix && u.Prefix.value;
        return p === 'MILLI' ? 0.001 : p === 'CENTI' ? 0.01 : p === 'DECI' ? 0.1 : p === 'KILO' ? 1000 : 1;
      }
    } catch (_) {}
    return null;
  }

  // Lê BaseQuantities (IfcElementQuantity) por elemento → {comprimento, area, volume, contagem} já
  // em metros/m²/m³. Espelha lerCarimbosOrcaPro, mas atua nos psets que têm .Quantities (não
  // .HasProperties — exatamente os que o traversal de carimbos pula). Escolhe por nome:
  // comprimento='Length' (ignora Width/Height/Perímetro); área/volume preferem 'Net' sobre 'Gross'.
  // Quando existir, o motor de quantitativos prefere isto (MEDIDO) ao AABB (ESTIMADO). Blindado:
  // qualquer falha devolve o que já achou — quantidade é bônus, NUNCA impede o 3D de abrir.
  function lerQuantitativos(mid) {
    var mapa = {};
    // 3 fatores independentes → metros / m² / m³. Área/volume usam a unidade própria (m²/m³ se
    // declarada); só caem no comprimento²/³ se AREAUNIT/VOLUMEUNIT não existirem no arquivo.
    var bL = unidadePrefixoBase(mid, 'LENGTHUNIT'); if (bL == null) bL = 1;
    var bA = unidadePrefixoBase(mid, 'AREAUNIT'), bV = unidadePrefixoBase(mid, 'VOLUMEUNIT');
    var fLen = bL, fArea = (bA != null ? bA * bA : bL * bL), fVol = (bV != null ? bV * bV * bV : bL * bL * bL);
    /* MASSA em kg. O SI do IFC chama a unidade de GRAM e põe o KILO no prefixo:
       KILO GRAM → 1000 g → fator 1. Sem MASSUNIT declarada, vale o kg — é o que
       os exportadores gravam (e o que o gerador dos modelos da RA grava). */
    var bM = unidadePrefixoBase(mid, 'MASSUNIT'), fMassa = (bM != null ? bM / 1000 : 1);
    function vnum(x) { if (x == null) return NaN; if (typeof x === 'object') x = x.value; var v = parseFloat(x); return isNaN(v) ? NaN : v; }
    try {
      var rels = S.api.GetLineIDsWithType(mid, IFC_RELDEFINESBYPROPERTIES), nRel = rels.size();
      for (var i = 0; i < nRel; i++) {
        var rel; try { rel = S.api.GetLine(mid, rels.get(i), false); } catch (_) { continue; }
        if (!rel || !rel.RelatingPropertyDefinition || !rel.RelatedObjects) continue;
        var qid = rel.RelatingPropertyDefinition.value; if (qid == null) continue;
        var qset; try { qset = S.api.GetLine(mid, qid, false); } catch (_) { continue; }
        if (!qset) continue;
        var comp = { v: 0, s: -1 }, ar = { v: 0, s: -1 }, vol = { v: 0, s: -1 }, mas = { v: 0, s: -1 }, cont = 0;
        /* ⚠ MUITO IFC NÃO TEM BaseQuantities — E O COMPRIMENTO ESTÁ LÁ MESMO ASSIM.
         *
         * Este leitor só olhava `IfcElementQuantity`. Medido num projeto
         * hidrossanitário real de creche (80 MB, 1.725 IFCFLOWSEGMENT): o
         * arquivo tem ZERO IfcElementQuantity e ZERO IfcQuantityLength — e
         * tem 1.725 propriedades `Length`, uma por tubo, em
         * `Pset_FlowSegmentPipeSegment`. O comprimento estava publicado; o
         * leitor é que olhava só uma das duas gavetas. A tela dizia "sem
         * comprimento no IFC" sobre um arquivo que trazia todos.
         *
         * ⚠ MAIS ESTRITO QUE NA GAVETA DAS QUANTIDADES, de propósito. Num
         *   `IfcElementQuantity`, um `LengthValue` já se declara comprimento
         *   mesmo sem nome. Num pset comum cabe qualquer número: aqui o nome
         *   TEM de dizer comprimento — anônimo não vira cota. */
        if (!qset.Quantities && qset.HasProperties) {
          var props = Array.isArray(qset.HasProperties) ? qset.HasProperties : [qset.HasProperties];
          for (var pp = 0; pp < props.length; pp++) {
            var ph = props[pp]; if (!ph || ph.value == null) continue;
            var pv; try { pv = S.api.GetLine(mid, ph.value, false); } catch (_) { continue; }
            if (!pv || pv.type !== IFC_PROPERTYSINGLEVALUE || !pv.NominalValue) continue;
            var pnm = (pv.Name && pv.Name.value) ? String(pv.Name.value).toLowerCase() : '';
            if (/width|height|thick|depth|perimet|larg|altura|espess|diamet|diâmet|bore|radius|raio/.test(pnm)) continue;
            var sP = pnm === 'length' ? 3 : /length|comprim/.test(pnm) ? 2 : 0;
            if (!sP) continue;
            var Pv = vnum(pv.NominalValue.value);
            if (isNaN(Pv) || Pv <= 0) continue;
            if (sP > comp.s) comp = { v: Pv, s: sP };
          }
          if (comp.s < 0) continue;
          /* mesma unidade do projeto que as quantidades usam: IfcPositiveLengthMeasure
             é expresso no LENGTHUNIT declarado no arquivo */
          var qtoP = { comprimento: comp.v * fLen, area: 0, volume: 0, contagem: 0,
            compFonte: comp.s === 3 ? 'exata' : 'nomeada' };
          var objsP = Array.isArray(rel.RelatedObjects) ? rel.RelatedObjects : [rel.RelatedObjects];
          for (var op = 0; op < objsP.length; op++) {
            var ohp = objsP[op]; if (!ohp || ohp.value == null) continue;
            var eidp = ohp.value;
            if (!mapa[eidp]) mapa[eidp] = { comprimento: 0, area: 0, volume: 0, contagem: 0, compFonte: '' };
            if (qtoP.comprimento > mapa[eidp].comprimento) { mapa[eidp].comprimento = qtoP.comprimento; mapa[eidp].compFonte = qtoP.compFonte; }
          }
          continue;
        }
        if (!qset.Quantities) continue; // nem quantidade nem propriedade útil
        var qs = Array.isArray(qset.Quantities) ? qset.Quantities : [qset.Quantities];
        for (var q = 0; q < qs.length; q++) {
          var qh = qs[q]; if (!qh || qh.value == null) continue;
          var qv; try { qv = S.api.GetLine(mid, qh.value, false); } catch (_) { continue; }
          if (!qv) continue;
          var nm = (qv.Name && qv.Name.value) ? String(qv.Name.value).toLowerCase() : '';
          if (qv.LengthValue != null) {
            var Lv = vnum(qv.LengthValue); if (isNaN(Lv)) continue;
            /* ⚠ O VETO FOI ESCRITO PARA PAREDE E NÃO CONHECIA O VOCABULÁRIO DA REDE.
             * Faltavam DIÂMETRO e RAIO. Num qset de tubo ou duto que carimbe
             * `Diameter`/`NominalDiameter` e NÃO carimbe `Length` — exportador
             * que só publica a bitola, caso comum —, o diâmetro sobrevivia ao
             * filtro, ganhava nota 1 por falta de concorrente e virava "o
             * comprimento": um duto DN 400 saía com 0,40 m. Plausível, errado, e
             * em cima da peça que alguém vai serrar. */
            if (/width|height|thick|depth|perimet|larg|altura|espess|diamet|diâmet|bore|radius|raio/.test(nm)) continue;
            var sL = nm === 'length' ? 3 : /length|comprim/.test(nm) ? 2 : 1;
            /* ⚠ E a nota vira DADO, não só desempate. `s === 1` é uma quantidade
             * de comprimento SEM nome que diga comprimento — pode ser a peça,
             * pode ser outra dimensão que ninguém batizou. Serve para somar num
             * quantitativo que o engenheiro confere; não serve para carimbar um
             * número sobre o tubo, onde não há contexto para desconfiar. Quem
             * consome decide, mas agora sabe. */
            if (sL > comp.s) comp = { v: Lv, s: sL };
          } else if (qv.AreaValue != null) {
            var Av = vnum(qv.AreaValue); if (isNaN(Av)) continue;
            var sA = /net/.test(nm) ? 3 : /gross/.test(nm) ? 2 : 1;
            if (sA > ar.s) ar = { v: Av, s: sA };
          } else if (qv.VolumeValue != null) {
            var Vv = vnum(qv.VolumeValue); if (isNaN(Vv)) continue;
            var sV = /net/.test(nm) ? 3 : /gross/.test(nm) ? 2 : 1;
            if (sV > vol.s) vol = { v: Vv, s: sV };
          } else if (qv.CountValue != null) {
            var Cv = vnum(qv.CountValue); if (!isNaN(Cv)) cont += Cv;
          } else if (qv.WeightValue != null) {
            /* o PESO que o projetista (ou o fabricante) publicou: vale mais que
               volume × peso específico, que é estimativa. Líquido antes do bruto,
               como área e volume. */
            var Wv = vnum(qv.WeightValue); if (isNaN(Wv) || Wv <= 0) continue;
            var sW = /net/.test(nm) ? 3 : /gross/.test(nm) ? 2 : 1;
            if (sW > mas.s) mas = { v: Wv, s: sW };
          }
        }
        if (comp.s < 0 && ar.s < 0 && vol.s < 0 && mas.s < 0 && cont === 0) continue;
        var qto = { comprimento: comp.s >= 0 ? comp.v * fLen : 0, area: ar.s >= 0 ? ar.v * fArea : 0, volume: vol.s >= 0 ? vol.v * fVol : 0, contagem: cont,
          massa: mas.s >= 0 ? mas.v * fMassa : 0, massaFonte: mas.s === 3 ? 'liquida' : mas.s === 2 ? 'bruta' : mas.s === 1 ? 'anonima' : '',
          /* 'exata' = a quantidade se chama Length; 'nomeada' = o nome cita
             comprimento; 'anonima' = e de comprimento mas ninguem a batizou. */
          compFonte: comp.s === 3 ? 'exata' : comp.s === 2 ? 'nomeada' : comp.s === 1 ? 'anonima' : '' };
        var objs = Array.isArray(rel.RelatedObjects) ? rel.RelatedObjects : [rel.RelatedObjects];
        for (var o = 0; o < objs.length; o++) {
          var oh = objs[o]; if (!oh || oh.value == null) continue;
          var eid = oh.value;
          // um elemento pode ter mais de um IfcElementQuantity → fica o MAIOR por dimensão (não soma, p/ não duplicar)
          if (!mapa[eid]) mapa[eid] = { comprimento: 0, area: 0, volume: 0, contagem: 0, compFonte: '' };
          if (qto.comprimento > mapa[eid].comprimento) { mapa[eid].comprimento = qto.comprimento; mapa[eid].compFonte = qto.compFonte; }
          if (qto.area > mapa[eid].area) mapa[eid].area = qto.area;
          if (qto.volume > mapa[eid].volume) mapa[eid].volume = qto.volume;
          if (qto.contagem > mapa[eid].contagem) mapa[eid].contagem = qto.contagem;
          if (qto.massa > (mapa[eid].massa || 0)) { mapa[eid].massa = qto.massa; mapa[eid].massaFonte = qto.massaFonte; }
        }
      }
    } catch (e) { /* quantidade é bônus; nunca impede o modelo de abrir */ }
    return mapa;
  }

  // Lê os IfcBuildingStorey + a relação de contenção espacial → [{sid, nome, elev, eids:[expressID]}].
  // Elevation vem na unidade CRUA do arquivo (×fLen) e o placement pode deslocar — por isso é só
  // FALLBACK de ordenação; a altura confiável (y0) vem do AABB dos membros, no mundo (metros),
  // preenchida depois que as malhas existem. Blindado: pavimento é bônus, nunca impede o 3D.
  function lerPavimentos(mid) {
    var out = [], st = {};
    try {
      var fLen = unidadePrefixoBase(mid, 'LENGTHUNIT'); if (fLen == null) fLen = 1;
      var ids = S.api.GetLineIDsWithType(mid, IFC_BUILDINGSTOREY), n = ids.size();
      for (var i = 0; i < n; i++) {
        var sid = ids.get(i), ln; try { ln = S.api.GetLine(mid, sid, false); } catch (_) { continue; }
        if (!ln) continue;
        var nome = (ln.Name && ln.Name.value) || (ln.LongName && ln.LongName.value) || ('Pavimento ' + (out.length + 1));
        var reg = { sid: sid, nome: String(nome), elev: null, y0: null, eids: [] };
        var ev = ln.Elevation; if (ev && typeof ev === 'object') ev = ev.value;
        ev = parseFloat(ev); if (!isNaN(ev)) reg.elev = ev * fLen;
        st[sid] = reg; out.push(reg);
      }
      if (!out.length) return out;
      var rels = S.api.GetLineIDsWithType(mid, IFC_RELCONTAINEDINSPATIALSTRUCTURE), nR = rels.size();
      for (var r = 0; r < nR; r++) {
        var rel; try { rel = S.api.GetLine(mid, rels.get(r), false); } catch (_) { continue; }
        if (!rel || !rel.RelatingStructure || rel.RelatingStructure.value == null) continue;
        var alvo = st[rel.RelatingStructure.value]; if (!alvo) continue; // contido em Building/Space, não em pavimento
        var els = Array.isArray(rel.RelatedElements) ? rel.RelatedElements : (rel.RelatedElements ? [rel.RelatedElements] : []);
        for (var k2 = 0; k2 < els.length; k2++) { var h2 = els[k2]; if (h2 && h2.value != null) alvo.eids.push(h2.value); }
      }
    } catch (_) { /* pavimento é bônus; nunca impede o modelo de abrir */ }
    return out;
  }

  // ---------- MULTI-IFC: cada arquivo vira um MODELO independente (disciplina + transparência próprias) ----------
  /* ⚠ O PREFIXO DA ABNT PRECISA CASAR, E ELE É CURTO.
     O projetista nomeia o arquivo por disciplina: ARQ_, EST_, ELE_, HID_, PLU_,
     MEC_. As regras pegavam só a palavra inteira ("eletrica", "hidraulica") — e
     um `ELE_CRECHE_PONTAL_REV00.ifc` real (Revit, 4.432 elementos, medido em
     09/09/2026) NÃO casava com /elet|elec|el[ée]tr/.
     ⚠ E QUANDO O NOME FALHA NÃO SOBRA REDE: a contagem por tipo IFC não
     distingue MEP nenhum — eletroduto e tubo hidráulico são os DOIS
     `IfcFlowSegment` (está escrito em js/bimclash.js). A elétrica caía como
     HIDRÁULICA, e a compatibilização reportava "Estrutura × Hidráulica" para
     choque que é com a elétrica: número certo, rótulo errado — e é o rótulo
     que vai no relatório e no BCF que o projetista abre.
     ⚠ O limite de palavra antes do prefixo não é enfeite: sem ele "tele_" viraria elétrica
     e "aplu_" viraria pluvial. */
  function detectarDisciplina(nome, tipos) {
    var n = String(nome || '').toLowerCase();
    if (/estrut|struct|\best[_\-.]|founda/.test(n)) return 'estrutural';
    if (/arq|arch/.test(n)) return 'arquitetura';
    if (/hidr|hydro|sanit|agua|água|esgoto|plumb|\bhid[_\-.]|\bplu[_\-.]|\bsan[_\-.]/.test(n)) return 'hidraulica';
    if (/elet|elec|el[ée]tr|\bele[_\-.]/.test(n)) return 'eletrica';
    if (/avac|hvac|mec[aâ]|clima|\bmec[_\-.]/.test(n)) return 'mecanica';
    var t = tipos || {};
    var est = (t.IFCBEAM || 0) + (t.IFCCOLUMN || 0) + (t.IFCFOOTING || 0) + (t.IFCPILE || 0) + (t.IFCMEMBER || 0);
    var hid = (t.IFCFLOWSEGMENT || 0) + (t.IFCFLOWFITTING || 0) + (t.IFCFLOWTERMINAL || 0);
    var arq = (t.IFCWALL || 0) + (t.IFCWALLSTANDARDCASE || 0) + (t.IFCDOOR || 0) + (t.IFCWINDOW || 0) + (t.IFCCOVERING || 0) + (t.IFCROOF || 0) + (t.IFCSLAB || 0);
    var max = Math.max(est, hid, arq);
    if (!max) return 'arquitetura';
    return max === hid ? 'hidraulica' : (max === est ? 'estrutural' : 'arquitetura');
  }
  function modeloDe(mid) { for (var i = 0; i < S.modelos.length; i++) if (S.modelos[i].mid === mid) return S.modelos[i]; return null; }
  function publicos() { return S.modelos.map(function (mo) { return { mid: mo.mid, nome: mo.nome, disciplina: mo.disciplina, alpha: mo.alpha, visivel: mo.visivel, n: mo.elementos.length, modeloId: mo.modeloId || '', arquivoId: mo.versaoId || '', doCache: !!mo.doCache, sintetico: !!mo.sintetico, temColeta: !!mo._coleta, semCache: mo._semCache || '', exemplo: !!mo.exemplo }; }); }
  function notifyModelos() { if (S._reaplicarEstilo) S._reaplicarEstilo(); if (S._reaplicarSistema) S._reaplicarSistema(); if (S.opts && S.opts.onModelos) { try { S.opts.onModelos(publicos()); } catch (_) {} } } // estilo desenho E cor-por-sistema pegam modelo que entrar depois
  S._publicos = publicos;

  /* =====================================================================
   * B3 — ISOLAR E PINTAR UM CONJUNTO
   *
   * O motor (js/bimset.js) devolve CHAVES do B0; a cena entende `uid`. Estas
   * três funções são a ponte, e ficam aqui porque dependem da cena — a regra
   * em si não depende de nada disto e por isso mora no motor puro.
   * ===================================================================== */
  var _corMatCache = {};
  function corMat(hex, alpha) {
    var a = (alpha == null ? 1 : alpha);
    var k = hex + '_' + a.toFixed(2);
    if (!_corMatCache[k]) {
      _corMatCache[k] = new THREE.MeshStandardMaterial({
        color: new THREE.Color(hex), metalness: .05, roughness: .85, side: THREE.DoubleSide,
        transparent: a < 1, opacity: a, depthWrite: a >= 1
      });
    }
    return _corMatCache[k];
  }

  function uidsDeChaves(chaves) {
    var alvo = {}, out = [];
    (chaves || []).forEach(function (c) { alvo[c] = 1; });
    (S.elementos || []).forEach(function (e) { if (e.chave && alvo[e.chave]) out.push(e.uid); });
    return out;
  }

  /* deixa visível só o que está no conjunto. Usa o mesmo caminho do isolar por
     seleção, então o botão ↺ Restaurar tudo desfaz como o usuário já espera. */
  function isolarChaves(chaves) {
    var alvo = {}, n = 0;
    uidsDeChaves(chaves).forEach(function (u) { alvo[u] = 1; });
    todasMalhas(function (m) {
      if (m.userData.expressID == null) return;
      var vis = !!alvo[m.userData.mid + ':' + m.userData.expressID] && !ehFuturo4d(m) && !ehRemovidoEd(m);
      m.visible = vis; if (vis) n++;
    });
    pav.isolado = null; pav.manual = true; pavRender();
    return n;
  }

  /* pinta o conjunto. `mapa` é { chave: '#rrggbb' } — vem do perfil de cores do
     motor, onde a PRIMEIRA regra que casa manda. */
  /* =====================================================================
   * ⚠ A CENA TEM UM DONO DE CADA VEZ
   *
   * Cinco lugares pintam ou isolam esta cena: os conjuntos de seleção (B3),
   * a comparação de versões (B7), o 4D automático, o Cronograma 4D (B6) e o
   * avanço medido (B10). Todos escrevem no MESMO `S._pintura`, e quem chega
   * por último ganha — o que é o comportamento certo.
   *
   * O que estava errado é o painel não SABER que perdeu. Medido: pintar pelo
   * avanço, mexer no 4D automático e voltar ao quantitativo mostrava a
   * legenda inteira do avanço — "Nada medido · 816 peças", com as cores e o
   * botão "Tirar as cores" — sobre uma cena que estava pintada pelo 4D.
   * Quem olhasse o 3D leria as cores de um recurso através da legenda de
   * outro, e as duas pareceriam concordar.
   *
   * O dono é uma etiqueta, não um dono de verdade: ninguém é impedido de
   * pintar. Ela existe para que cada painel saiba se a legenda dele ainda
   * descreve o que está na tela.
   * =================================================================== */
  function pintarChaves(mapa, dono) {
    var porUid = {}, n = 0;
    var alvo = mapa || {};
    (S.elementos || []).forEach(function (e) {
      if (e.chave && alvo[e.chave]) { porUid[e.uid] = alvo[e.chave]; n++; }
    });
    S._pintura = n ? porUid : null;
    S._pinturaDono = n ? (dono || "?") : null;
    S.modelos.forEach(function (mo) { refreshModelo(mo); });
    return n;
  }
  function limparPintura() { S._pintura = null; S._pinturaDono = null; S.modelos.forEach(function (mo) { refreshModelo(mo); }); }
  S._isolarChaves = isolarChaves; S._pintarChaves = pintarChaves; S._limparPintura = limparPintura;
  S._uidsDeChaves = uidsDeChaves;

  /* =====================================================================
   * B6 — APLICAR A SIMULACAO 4D DIRIGIDA POR TAREFAS
   *
   * O motor (js/bimtarefa.js) decide QUEM esta em que estado numa data; aqui
   * fica so o que a cena sabe fazer: esconder, pintar com opacidade e
   * contornar.
   *
   * ⚠ O CONTORNO DO ATRASO VAI NUMA MALHA SO. A tentacao e criar um
   * LineSegments por peca atrasada — e foi exatamente isso que o B2 mediu
   * custando 1.793 draw calls no caminho da planta. Aqui as arestas de todas
   * as pecas atrasadas sao mescladas num unico BufferGeometry: um objeto,
   * uma chamada de desenho, independente de haver 3 ou 300 atrasos.
   *
   * ⚠ E ELE NAO PISCA. O atraso precisa aparecer numa FOTO que vai para o
   * relatorio; cor que pisca sai ora de um jeito ora de outro e o engenheiro
   * nao consegue mandar a imagem para o cliente.
   * ===================================================================== */
  var _lnAtraso = null, _lnAtrasoMat = null;
  var MAX_CONTORNO = 4000;   /* pecas; acima disso so a cor, e a tela avisa */

  function limparContorno4D() {
    if (_lnAtraso && _lnAtraso.parent) _lnAtraso.parent.remove(_lnAtraso);
    if (_lnAtraso && _lnAtraso.geometry) { try { _lnAtraso.geometry.dispose(); } catch (e) {} }
    _lnAtraso = null;
  }

  function aplicar4DTarefas(sim) {
    if (!S || !sim) return { ok: false, erro: 'simulação vazia' };
    /* o 4D manda na visibilidade inteira: o isolamento por pavimento deixa de
       valer, como ja acontece no aplicarEstado do 4D automatico */
    if (S.pav && (S.pav.isolado || S.pav.manual)) { S.pav.isolado = null; S.pav.manual = false; if (S._pavRender) S._pavRender(); }

    var fora = {};
    uidsDeChaves(sim.ocultos || []).forEach(function (u) { fora[u] = 1; });

    var porChave = {}, n = 0;
    Object.keys(sim.pinturas || {}).forEach(function (k) { porChave[k] = sim.pinturas[k]; n++; });
    var porUid = {};
    (S.elementos || []).forEach(function (e) { if (e.chave && porChave[e.chave]) porUid[e.uid] = porChave[e.chave]; });
    S._pintura = n ? porUid : null;
    S._pinturaDono = "4d-tarefas";
    S._fut4d = fora;   /* o 🏢/👁 compoe com isto e nao ressuscita o que ainda nao existe */

    cadaMalha(function (m) {
      var id = m.userData.expressID; if (id == null) return;
      var uid = m.userData.mid + ':' + id;
      if (fora[uid] || ehRemovidoEd(m)) { m.visible = false; return; }
      m.visible = true;
      if (m === S.selected) return;
      m.material = S._matBase ? S._matBase(m) : (m.userData.matOrig || m.material);
    });

    /* ---- o contorno do atraso, numa malha so ---- */
    limparContorno4D();
    var alvos = uidsDeChaves(Object.keys(sim.contornos || {}));
    var res = { ok: true, ocultos: Object.keys(fora).length, pintados: n, contornados: 0, contornoCortado: false };
    if (!alvos.length) return res;
    var mapaUid = {};
    alvos.forEach(function (u) { mapaUid[u] = 1; });
    var pos = [], usados = 0, cortou = false;
    var _v = new THREE.Vector3();
    cadaMalha(function (m) {
      if (m.userData.expressID == null) return;
      if (!mapaUid[m.userData.mid + ':' + m.userData.expressID]) return;
      if (usados >= MAX_CONTORNO) { cortou = true; return; }
      var g = m.geometry;
      if (!g || !g.attributes || !g.attributes.position) return;
      /* malha densa fica sem contorno: o EdgesGeometry dela sozinho trava a aba
         (mesma guarda que o contorno da selecao ja usa desde a v1.1.89) */
      if (g.attributes.position.count > 60000) return;
      /* ⚠ O CACHE DE ARESTAS JÁ EXISTE — use-o. Construir um EdgesGeometry por
         peça a cada quadro custava ~0,29 ms cada; num arrasto com 350 peças
         atrasadas são 100 ms por evento, e a régua arrastava atrás do dedo.
         A geometria não muda enquanto o modelo está aberto, e `arestasDe`
         guarda por geometria num WeakMap, em espaço LOCAL — que é o que este
         laço consome, porque aplica a `matrixWorld` logo em seguida. */
      var arr;
      try { arr = arestasDe(g); } catch (e) { return; }
      if (!arr || !arr.length) return;
      var mw = m.matrixWorld;
      for (var i = 0; i < arr.length; i += 3) {
        _v.set(arr[i], arr[i + 1], arr[i + 2]).applyMatrix4(mw);
        pos.push(_v.x, _v.y, _v.z);
      }
      usados++;
    });
    if (pos.length) {
      var bg = new THREE.BufferGeometry();
      bg.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
      var cor = sim.contornos[Object.keys(sim.contornos)[0]] || '#ea580c';
      if (!_lnAtrasoMat) _lnAtrasoMat = new THREE.LineBasicMaterial({ color: new THREE.Color(cor), depthTest: true, transparent: false });
      else _lnAtrasoMat.color = new THREE.Color(cor);
      _lnAtraso = new THREE.LineSegments(bg, _lnAtrasoMat);
      _lnAtraso.renderOrder = 998;
      scene.add(_lnAtraso);
    }
    res.contornados = usados;
    res.contornoCortado = cortou;
    return res;
  }

  function limpar4DTarefas() {
    limparContorno4D();
    S._pintura = null; S._fut4d = null; S._and4d = null;
    cadaMalha(function (m) { m.visible = !ehRemovidoEd(m); if (m !== S.selected) m.material = S._matBase ? S._matBase(m) : (m.userData.matOrig || m.material); });
  }
  S._aplicar4DTarefas = aplicar4DTarefas; S._limpar4DTarefas = limpar4DTarefas;

  /* =====================================================================
   * SIMULAÇÃO 4D POR DATA (js/bim4dsim.js) — a cena que o motor decidiu.
   *
   * O motor devolve, por UID da sessão (`mid:expressID`, o mesmo id que o
   * `onLoaded` entrega à casca), quem some e quem é pintado de quê
   * ({cor, opacidade}). Aqui fica só o que a cena sabe fazer.
   *
   * ⚠ QUEM CHEGA TOMA A CENA INTEIRA, como o 4D automático antigo: a
   *   pintura de outro painel (conjunto, avanço medido) não pode sobrar nas
   *   peças "concluídas" — a cena viraria duas legendas ao mesmo tempo (ver o
   *   ⚠ "A CENA TEM UM DONO DE CADA VEZ"). O contorno de atraso do Cronograma
   *   4D do engenheiro também sai: ele desenharia laranja sobre peças que esta
   *   simulação escondeu.
   * ⚠ `_fut4d` recebe TODOS os ocultos (futuro e filtrado): é ele que o
   *   isolamento por pavimento e o restaurar consultam para não ressuscitar o
   *   que a simulação escondeu.
   * ===================================================================== */
  function aplicar4DSim(cena) {
    if (!S || !cena) return { ok: false, erro: 'simulação vazia' };
    if (S.pav && (S.pav.isolado || S.pav.manual)) { S.pav.isolado = null; S.pav.manual = false; if (S._pavRender) S._pavRender(); }
    limparContorno4D();
    var fora = {};
    (cena.ocultos || []).forEach(function (u) { fora[u] = 1; });
    var pint = {}, n = 0;
    Object.keys(cena.pinturas || {}).forEach(function (u) {
      var p = cena.pinturas[u];
      if (p && typeof p.cor === 'string' && /^#[0-9a-fA-F]{6}$/.test(p.cor)) { pint[u] = { cor: p.cor, opacidade: Math.max(0.05, Math.min(1, +p.opacidade || 1)) }; n++; }
    });
    S._pintura = n ? pint : null;
    S._pinturaDono = '4d-sim';
    S._fut4d = fora; S._and4d = null;
    var vis = 0;
    cadaMalha(function (m) {
      var id = m.userData.expressID; if (id == null) return;
      var uid = m.userData.mid + ':' + id;
      if (fora[uid] || ehRemovidoEd(m)) { m.visible = false; return; }
      m.visible = true; vis++;
      if (m === S.selected) return;
      m.material = S._matBase ? S._matBase(m) : (m.userData.matOrig || m.material);
    });
    return { ok: true, ocultos: Object.keys(fora).length, pintados: n, malhasVisiveis: vis };
  }
  /* voo até um conjunto de peças (a atividade escolhida na lista do 4D).
     Mede o que EXISTE na cena, visível ou não: a etapa futura está escondida
     e o enquadramento tem de mostrar onde ela vai nascer. */
  /* `opts.direita` = quantos px do lado direito do canvas estão TAPADOS (a
     gaveta do painel 4D fica por cima do 3D). ⚠ Sem isto o enquadramento
     centralizava a etapa no canvas inteiro — medido: a metade dela caía
     atrás da gaveta de 640 px, e o "enquadrar" mostrava meia parede. O alvo
     anda para a direita no mundo e a peça aparece no meio da parte livre. */
  function enquadrarUids(uids, opts) {
    if (!S || !uids || !uids.length) return false;
    var alvo = {}; uids.forEach(function (u) { alvo[u] = 1; });
    var box = new THREE.Box3(), achou = 0, bm = new THREE.Box3();
    cadaMalha(function (m) {
      if (m.userData.expressID == null || !alvo[m.userData.mid + ':' + m.userData.expressID]) return;
      if (!m.geometry) return;
      if (!m.geometry.boundingBox) { try { m.geometry.computeBoundingBox(); } catch (e) { return; } }
      if (!m.geometry.boundingBox) return;
      bm.copy(m.geometry.boundingBox).applyMatrix4(m.matrixWorld);
      box.union(bm); achou++;
    });
    if (!achou || box.isEmpty()) return false;
    var W = (S.renderer && S.renderer.domElement) ? (S.renderer.domElement.clientWidth || 0) : 0;
    var tampa = Math.max(0, Math.min(W * 0.7, +((opts && opts.direita) || 0)));
    if (!tampa || !W) { if (S._enquadrarObj) S._enquadrarObj(box, 1.5); return true; }
    if (S._cancelTween) S._cancelTween();
    var c = box.getCenter(new THREE.Vector3()), sz = box.getSize(new THREE.Vector3());
    var raio = Math.max(sz.x, sz.y, sz.z, 0.5) * 0.5, livre = (W - tampa) / W;
    var tg = Math.tan((camera.fov * Math.PI / 180) / 2);
    /* cabe na ALTURA e na LARGURA LIVRE: a que apertar mais manda (numa tela
       larga, com a gaveta aberta, quase sempre ainda é a altura) */
    var tgLivre = tg * (camera.aspect || 1) * Math.max(0.3, livre);
    var dist = (raio / Math.min(tg, tgLivre)) * 1.3;
    var dir = camera.position.clone().sub(orbit.target); if (dir.lengthSq() < 1e-6) dir.set(0.7, 0.55, 0.8); dir.normalize();
    var largMundo = 2 * dist * tg * (camera.aspect || 1);
    var direita = new THREE.Vector3().crossVectors(dir.clone().negate(), camera.up).normalize();
    var alvoCam = c.clone().add(direita.multiplyScalar((tampa / W) * largMundo / 2));
    var near = Math.max(0.01, (dist - raio) * 0.5); if (near < camera.near) { camera.near = near; camera.updateProjectionMatrix(); }
    voarCam(alvoCam.clone().add(dir.multiplyScalar(dist)), alvoCam, 0.55);
    return true;
  }
  S._aplicar4DSim = aplicar4DSim; S._enquadrarUids = enquadrarUids;

  /* =====================================================================
   * B4 — LER E APLICAR UM PONTO DE VISTA
   *
   * O motor (js/bimvista.js) decide o que a vista E; aqui ficam as duas pontas
   * que so a cena sabe fazer: onde a camera esta agora, e como voltar para la.
   * ===================================================================== */
  function cameraAtual() {
    var alvo = (orbit && orbit.target) ? orbit.target : { x: 0, y: 0, z: 0 };
    return {
      pos: [camera.position.x, camera.position.y, camera.position.z],
      alvo: [alvo.x, alvo.y, alvo.z],
      up: [camera.up.x, camera.up.y, camera.up.z],
      fov: camera.fov, orto: false
    };
  }

  /* =====================================================================
   * ⚠ O ESTADO INTEIRO DA CENA — o que o ponto de vista grava
   *
   * Ver "A VISTA COMPLETA" em js/bimvista.js: a vista antiga guardava só a
   * câmera, e o engenheiro perdia o que tinha ocultado, cortado e medido.
   * Aqui entra tudo o que a pessoa ajustou e que muda o que se vê: câmera,
   * planta ou corte livre (com a posição do slider), peças ocultas/isoladas,
   * raio-X, cores, estilo desenho, modelos desligados/transparentes, cotas da
   * trena (área e ângulo também) e as cotas da rede.
   *
   * ⚠ O QUE OUTRO DONO ESCONDEU NÃO ENTRA. Peça no futuro do 4D e peça
   * removida no editor estão escondidas por outro recurso; gravá-las como
   * "ocultas pela vista" faria a vista escondê-las para sempre, mesmo depois
   * de o 4D andar.
   *
   * ⚠ PEÇA SEM CHAVE NÃO TEM COMO SER GRAVADA (o B0 não conseguiu
   * identificá-la). Ela é CONTADA em `semChave`, para a tela avisar em vez de
   * a vista abrir mostrando uma peça que a pessoa tinha escondido.
   * ===================================================================== */
  function corParaV3(h) {
    var m = /^#?([0-9a-fA-F]{6})$/.exec(String(h || ''));
    if (!m) return null;
    var n = parseInt(m[1], 16);
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }
  function v3ParaCor(c) {
    function h(x) { var t = Math.round(Math.max(0, Math.min(1, +x || 0)) * 255).toString(16); return t.length < 2 ? '0' + t : t; }
    return '#' + h(c[0]) + h(c[1]) + h(c[2]);
  }
  function estadoVista() {
    var fantasma = {};
    if (xray.on) xray.ghosted.forEach(function (m) { fantasma[m.uuid] = 1; });
    var porUid = {};
    todasMalhas(function (m) {
      if (m.userData.expressID == null) return;
      if (ehFuturo4d(m) || ehRemovidoEd(m)) return;
      var u = m.userData.mid + ':' + m.userData.expressID;
      var r = porUid[u] || (porUid[u] = { vis: false, solido: false });
      if (m.visible) { r.vis = true; if (!fantasma[m.uuid]) r.solido = true; }
    });
    var visiveis = [], ocultos = [], alvoRx = [], semChave = 0;
    (S.elementos || []).forEach(function (e) {
      var r = porUid[e.uid]; if (!r) return;
      if (!e.chave) { if (!r.vis) semChave++; return; }
      if (r.vis) visiveis.push(e.chave); else ocultos.push(e.chave);
      if (xray.on && r.vis && r.solido) alvoRx.push(e.chave);
    });
    var BV = (typeof window !== 'undefined') ? window.BimVista : null;
    var vis = BV ? BV.escolherVisibilidade(visiveis, ocultos) : { isolados: [], ocultos: ocultos };
    var aparencias = [];
    if (S._pintura) {
      (S.elementos || []).forEach(function (e) {
        var p = S._pintura[e.uid]; if (!p || !e.chave) return;
        var obj = (typeof p === 'object');
        var rgb = corParaV3(obj ? p.cor : p); if (!rgb) return;
        aparencias.push({ chave: e.chave, cor: rgb, alpha: (obj && p.opacidade != null) ? +p.opacidade : 1 });
      });
    }
    var fixados = [];
    if (cota.on) {
      var fx = cota.fixados || {};
      (S.elementos || []).forEach(function (e) { if (fx[e.uid] && e.chave) fixados.push(e.chave); });
    }
    var slP = cortePanel.querySelector('[data-c="alt"]'), slL = corteLPanel.querySelector('[data-k="pos"]');
    return {
      completa: true,
      camera: cameraAtual(),
      cortes: {
        planta: { on: !!planta.on, y: planta.plane ? planta.plane.constant : 0, frac: slP ? (+slP.value) / 1000 : 0.62 },
        livre: { on: !!corteL.on, az: corteL.az, inc: corteL.inc, inv: !!corteL.inv, pos: slL ? (+slL.value) / 1000 : 0.5,
                 plano: [corteL.plane.normal.x, corteL.plane.normal.y, corteL.plane.normal.z, corteL.plane.constant] }
      },
      visibilidade: { isolados: vis.isolados, ocultos: vis.ocultos, raioX: !!(xray.on && alvoRx.length), raioXAlvo: alvoRx },
      aparencias: aparencias,
      modelos: S.modelos.map(function (mo) { return { arquivoId: mo.versaoId || '', modeloId: mo.modeloId || '', visivel: mo.visivel !== false, alpha: mo.alpha == null ? 1 : mo.alpha }; }),
      estilo: { desenho: !!estiloD.on },
      medidas: medir.regs.map(function (r) { return { tipo: r.tipo, pts: r.pts.map(function (p) { return p.slice(); }), horizontal: !!r.horizontal }; }),
      cotaRede: { on: !!cota.on, modo: cota.modo, fixados: fixados, chave: cota.chave || '' },
      semChave: semChave
    };
  }

  /* =====================================================================
   * ⚠ APLICAR = ZERAR A CENA E MONTAR SÓ O QUE A VISTA GUARDOU
   *
   * A versão anterior somava por cima do que estava na tela: o corte aberto
   * para uma vista continuava aberto na próxima, o raio-X e a cor também.
   * Agora cada passo abaixo primeiro DESFAZ e depois aplica, e o que a vista
   * não guardou volta ao neutro (modelo inteiro, sem corte, sem cota).
   *
   * ⚠ A ORDEM IMPORTA, e cada troca aqui já custou uma vista errada:
   *   - cortes antes de tudo: ligar a planta põe o estilo desenho, e
   *     desligá-la re-enquadra a câmera;
   *   - estilo antes do raio-X: o estilo reescreve os materiais e apaga o
   *     fantasma do raio-X;
   *   - visibilidade antes do raio-X: o raio-X só deixa translúcido o que
   *     está VISÍVEL;
   *   - câmera por ÚLTIMO, com o voo cancelado: `setPlanta(false)` chama o
   *     enquadrar, e o tween dele puxaria a câmera para fora da vista meio
   *     segundo depois de ela ter sido posta no lugar.
   *
   * ⚠ VISTA ANTIGA (sem `completa`): o que ela não guardou não existe para
   * ela — abre com a câmera dela e o resto no neutro. Os modelos ficam como
   * estão, porque ela nunca soube deles.
   * ===================================================================== */
  function aplicarVista(v, opts) {
    if (!v) return { ok: false, erro: 'ponto de vista vazio' };
    opts = opts || {};
    var completa = v.completa === true;
    var res = { ok: true, naoLocalizadas: [], completa: completa };
    try {
      var BV = (typeof window !== 'undefined') ? window.BimVista : null;
      var r = BV ? BV.resolver(v, S.elementos || []) : null;
      cancelTween();

      /* 1) cotas: nenhuma da vista anterior sobrevive */
      limparMedidas();
      if (cota.on) setCota(false);
      cota.fixados = {}; cota.chave = null;

      /* 2) cortes */
      var cs = v.cortes || {}, cp = cs.planta || {}, cl = cs.livre || {};
      var querP = !!cp.on, querL = !querP && !!cl.on;
      if (planta.on && !querP) setPlanta(false);
      if (corteL.on && !querL) setCorteL(false);
      if (querP) {
        if (!planta.on) setPlanta(true);
        if (planta.on) {
          var fr = (cp.frac != null) ? +cp.frac : ((planta.y1 - planta.y0) ? (+cp.y - planta.y0) / (planta.y1 - planta.y0) : 0.62);
          if (!isFinite(fr)) fr = 0.62;
          fr = Math.max(0, Math.min(1, fr));
          var slP = cortePanel.querySelector('[data-c="alt"]'); if (slP) slP.value = Math.round(fr * 1000);
          setAlturaCorte(fr);
        }
      }
      if (querL) {
        corteL.az = +cl.az || 0; corteL.inc = +cl.inc || 0; corteL.inv = !!cl.inv;
        var elAz = corteLPanel.querySelector('[data-k="az"]'), elInc = corteLPanel.querySelector('[data-k="inc"]');
        var elPos = corteLPanel.querySelector('[data-k="pos"]'), elInv = corteLPanel.querySelector('[data-k="inv"]');
        if (elAz) elAz.value = corteL.az;
        if (elInc) elInc.value = corteL.inc;
        if (elPos) elPos.value = Math.round((cl.pos == null ? 0.5 : Math.max(0, Math.min(1, +cl.pos))) * 1000);
        if (elInv) { elInv.style.background = corteL.inv ? corAtiva() : ''; elInv.style.color = corteL.inv ? '#fff' : ''; }
        if (!corteL.on) setCorteL(true); else aplicarCorteL();
      }

      /* 3) estilo desenho */
      var querE = completa ? !!(v.estilo && v.estilo.desenho) : (planta.on && estiloD.on);
      if (!!estiloD.on !== querE) setEstiloDesenho(querE);

      /* 4) modelos — só a vista completa sabe deles. Casa primeiro pela
         versão exata do arquivo; se não houver, pela identidade do modelo. */
      if (completa && Array.isArray(v.modelos)) {
        S.modelos.forEach(function (mo) {
          var reg = null, i;
          for (i = 0; i < v.modelos.length && !reg; i++) if (v.modelos[i].arquivoId && v.modelos[i].arquivoId === mo.versaoId) reg = v.modelos[i];
          for (i = 0; i < v.modelos.length && !reg; i++) if (v.modelos[i].modeloId && v.modelos[i].modeloId === mo.modeloId) reg = v.modelos[i];
          var querVis = reg ? reg.visivel !== false : true;
          var querA = (reg && reg.alpha != null) ? +reg.alpha : 1;
          if ((mo.visivel !== false) !== querVis) setVisivel(mo.mid, querVis);
          if (Math.abs((mo.alpha == null ? 1 : mo.alpha) - querA) > 0.001) setTransparencia(mo.mid, querA);
        });
      }

      /* 5) visibilidade — do zero (o restaurar também tira o raio-X) */
      restaurarVisibilidade();
      if (r) {
        res.naoLocalizadas = r.naoLocalizadas;
        if (r.isolados.length) isolarChaves(r.isolados);
        else if (r.ocultos.length) {
          var fora = {};
          uidsDeChaves(r.ocultos).forEach(function (u) { fora[u] = 1; });
          todasMalhas(function (m) {
            if (m.userData.expressID == null) return;
            if (fora[m.userData.mid + ':' + m.userData.expressID]) m.visible = false;
          });
          pav.isolado = null; pav.manual = true; pavRender();
        }
      }

      /* 6) cores: a vista sem cor tira a cor que estava na tela */
      if (r && r.aparencias.length) {
        var mapa = {};
        r.aparencias.forEach(function (a) {
          var hx = v3ParaCor(a.cor);
          mapa[a.chave] = (a.alpha != null && a.alpha < 0.999) ? { cor: hx, opacidade: a.alpha } : hx;
        });
        pintarChaves(mapa, 'vista');
      } else if (S._pintura) limparPintura();

      /* 7) raio-X */
      if (r && v.visibilidade && v.visibilidade.raioX && r.raioXAlvo.length) raioXChaves(r.raioXAlvo);

      /* 8) cotas da trena, área e ângulo — redesenhadas dos pontos */
      (v.medidas || []).forEach(function (m) {
        var P = (m.pts || []).map(function (p) { return new THREE.Vector3(+p[0], +p[1], +p[2]); });
        if (m.tipo === 'dist' && P.length === 2) desenharMedida(P[0], P[1], !!m.horizontal, m.eixo || '');
        else if (m.tipo === 'area' && P.length >= 3) desenharArea(P, !!m.horizontal);
        else if (m.tipo === 'ang' && P.length === 3) desenharAngulo(P[0], P[1], P[2]);
      });

      /* 9) cotas da rede */
      if (v.cotaRede && v.cotaRede.on) {
        setCota(true, v.cotaRede.modo || 'clicado');
        if (cota.on) {
          uidsDeChaves(r ? r.cotaFixados : []).forEach(function (u) { cota.fixados[u] = 1; });
          cota.chave = v.cotaRede.chave || null;
          cota.acum = cota.periodo;
        }
      }

      /* 10) câmera por último */
      cancelTween();
      /* ⚠ o embalo de um arrasto anterior é zerado ANTES de pôr a câmera: o
         `orbit.update()` logo abaixo aplicava um pedaço dele e a vista abria
         ~45 cm fora da câmera gravada (e o rabisco dela não aparecia) —
         medido na e2e-bim-mesa [11], 01/10/2026 */
      if (S._pararInercia) S._pararInercia();
      var c = v.camera;
      if (c && c.pos) {
        camera.position.set(c.pos[0], c.pos[1], c.pos[2]);
        if (c.up) camera.up.set(c.up[0], c.up[1], c.up[2]);
        if (c.fov) { camera.fov = c.fov; camera.updateProjectionMatrix(); }
        if (orbit && orbit.target && c.alvo) { orbit.target.set(c.alvo[0], c.alvo[1], c.alvo[2]); orbit.update(); }
        camera.lookAt(c.alvo[0], c.alvo[1], c.alvo[2]);
      }
      /* 11) as marcações da vista (o rabisco) por cima do 3D, nesta câmera */
      mostrarMarcas(v.marcacoes || [], c && c.pos ? c : null);
      S._hint('');
    } catch (e) { return { ok: false, erro: String(e && e.message || e) }; }
    return res;
  }
  S._cameraAtual = cameraAtual; S._aplicarVista = aplicarVista; S._estadoVista = estadoVista;

  /* =====================================================================
   * MARCAÇÕES DA VISTA SOBRE O 3D — o RABISCO (01/10/2026)
   *
   * As marcações (`marcacoes` do ponto de vista: linha, seta, nuvem, texto,
   * retângulo e o traço livre do modo mesa) são 2D, em 0..1 da tela — valem
   * para AQUELA câmera. Até aqui elas eram só dado: nada as desenhava.
   * Agora aparecem quando a vista é aplicada e SOMEM quando a câmera sai dela
   * (um traço que "fica no lugar" com a câmera girando apontaria para outra
   * coisa — pior que não mostrar). Aplicar a vista de novo traz de volta.
   * ===================================================================== */
  var SVGNS = 'http://www.w3.org/2000/svg';
  var marcasSvg = document.createElementNS(SVGNS, 'svg');
  marcasSvg.setAttribute('data-bim', 'marcas');
  marcasSvg.style.cssText = 'position:absolute;left:0;top:0;pointer-events:none;z-index:6;display:none;overflow:visible';
  host.appendChild(marcasSvg); S.marcasSvg = marcasSvg;   /* ⚠ e entra na lista do RE-HOME */
  var _marcas = null, _mkV1 = new THREE.Vector3(), _mkV2 = new THREE.Vector3();
  function svgEl(tag, at) { var e = document.createElementNS(SVGNS, tag); for (var k in at) if (Object.prototype.hasOwnProperty.call(at, k)) e.setAttribute(k, at[k]); return e; }
  function desenharMarcas(svg, lista, w, h) {
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    svg.setAttribute('width', w); svg.setAttribute('height', h); svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
    (lista || []).forEach(function (m) {
      if (!m || !m.pts || !m.pts.length) return;
      var cor = /^#[0-9a-fA-F]{6}$/.test(m.cor || '') ? m.cor : '#e11d48';
      var P = m.pts.map(function (q) { return [q[0] * w, q[1] * h]; });
      var traco = { stroke: cor, 'stroke-width': 4, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' };
      if (m.tipo === 'livre' && P.length > 1) { traco.points = P.map(function (q) { return q[0].toFixed(1) + ',' + q[1].toFixed(1); }).join(' '); svg.appendChild(svgEl('polyline', traco)); }
      else if ((m.tipo === 'linha' || m.tipo === 'seta') && P.length > 1) {
        svg.appendChild(svgEl('line', { x1: P[0][0], y1: P[0][1], x2: P[1][0], y2: P[1][1], stroke: cor, 'stroke-width': 4, 'stroke-linecap': 'round' }));
        if (m.tipo === 'seta') {
          var ang = Math.atan2(P[1][1] - P[0][1], P[1][0] - P[0][0]), L = 16;
          var a1 = [P[1][0] - L * Math.cos(ang - 0.45), P[1][1] - L * Math.sin(ang - 0.45)], a2 = [P[1][0] - L * Math.cos(ang + 0.45), P[1][1] - L * Math.sin(ang + 0.45)];
          svg.appendChild(svgEl('polygon', { points: P[1].join(',') + ' ' + a1.join(',') + ' ' + a2.join(','), fill: cor }));
        }
      } else if ((m.tipo === 'retangulo' || m.tipo === 'nuvem') && P.length > 1) {
        var x = Math.min(P[0][0], P[1][0]), y = Math.min(P[0][1], P[1][1]), rw = Math.abs(P[1][0] - P[0][0]), rh = Math.abs(P[1][1] - P[0][1]);
        if (m.tipo === 'retangulo') svg.appendChild(svgEl('rect', { x: x, y: y, width: rw, height: rh, stroke: cor, 'stroke-width': 4, fill: 'none' }));
        else svg.appendChild(svgEl('ellipse', { cx: x + rw / 2, cy: y + rh / 2, rx: rw / 2, ry: rh / 2, stroke: cor, 'stroke-width': 4, fill: 'none', 'stroke-dasharray': '10 6' }));
      } else if (m.tipo === 'texto' && m.texto) {
        var tx = svgEl('text', { x: P[0][0], y: P[0][1], fill: cor, 'font-size': 16, 'font-weight': 700, 'font-family': 'Inter,system-ui,sans-serif', 'paint-order': 'stroke', stroke: '#fff', 'stroke-width': 3 });
        tx.textContent = String(m.texto);   /* texto vem do usuário (ou de um BCF de fora): só textContent */
        svg.appendChild(tx);
      }
    });
  }
  S._desenharMarcas = desenharMarcas;
  function mostrarMarcas(lista, cam) {
    if (!lista || !lista.length) { _marcas = null; marcasSvg.style.display = 'none'; return false; }
    var c = cam || cameraAtual();
    _marcas = { lista: lista, cam: { pos: c.pos.slice(), alvo: c.alvo.slice() }, w: 0, h: 0 };
    return true;
  }
  S._mostrarMarcas = mostrarMarcas;
  S._tickExtra.push(function () {
    if (!_marcas) { if (marcasSvg.style.display !== 'none') marcasSvg.style.display = 'none'; return; }
    var c = _marcas.cam, dist = camera.position.distanceTo(orbit.target);
    var d = camera.position.distanceTo(_mkV1.set(c.pos[0], c.pos[1], c.pos[2])) + orbit.target.distanceTo(_mkV2.set(c.alvo[0], c.alvo[1], c.alvo[2]));
    if (d > Math.max(1e-4, dist * 1e-3)) { _marcas = null; marcasSvg.style.display = 'none'; return; }   /* a câmera saiu da vista: o traço apontaria para outra coisa */
    var rc = canvasEl.getBoundingClientRect(), hr = ((S && S.host) || host).getBoundingClientRect();
    if (_marcas.w !== rc.width || _marcas.h !== rc.height) {
      _marcas.w = rc.width; _marcas.h = rc.height;
      marcasSvg.style.left = (rc.left - hr.left) + 'px'; marcasSvg.style.top = (rc.top - hr.top) + 'px';
      marcasSvg.style.width = rc.width + 'px'; marcasSvg.style.height = rc.height + 'px';
      desenharMarcas(marcasSvg, _marcas.lista, rc.width, rc.height);
    }
    if (marcasSvg.style.display === 'none') marcasSvg.style.display = 'block';
  });

  // material corrente de um mesh respeitando a TRANSPARÊNCIA do modelo dele
  function matBase(m) {
    /* ⚠ B3 — A COR DO CONJUNTO ENTRA AQUI, e não num `m.material = …` solto.
     * `refreshModelo` reescreve o material de toda malha do modelo a cada troca
     * de transparência, disciplina ou estilo. Pintura aplicada por fora seria
     * apagada pelo primeiro ajuste que o usuário fizesse, sem nada na tela
     * explicando por quê. Entrando na aparência-base, ela sobrevive — e vale de
     * uma vez no 3D, na Planta e no imersivo, como a cor por sistema.
     * ⚠ E o material NÃO tem `emissive`: com o B2 ligado, peça com emissão sai
     * do desenho mesclado e vira chamada própria — pintar um conjunto de 600
     * peças custaria 600 chamadas. */
    if (S._pintura) {
      var _cp = S._pintura[m.userData.mid + ':' + m.userData.expressID];
      if (_cp) {
        var _moP = modeloDe(m.userData.mid);
        /* ⚠ A PINTURA PASSOU A TER DOIS FORMATOS, e o antigo continua valendo.
           O B3 (conjuntos) grava uma string de cor; o B6 (4D) precisa de cor E
           opacidade — "em execucao" e translucido de proposito, para o
           engenheiro ver o que esta atras. Trocar o formato quebraria o B3,
           que ja esta no ar; aceitar os dois nao quebra nada. */
        if (typeof _cp === 'object' && _cp) {
          var _aM = (_moP ? _moP.alpha : 1);
          var _aP = (_cp.opacidade == null ? 1 : _cp.opacidade);
          return corMat(_cp.cor, Math.min(_aM, _aP));
        }
        return corMat(_cp, _moP ? _moP.alpha : 1);
      }
    }
    // v1.1.96 — modo "colorir por sistema" ligado: a aparência-base vira a COR DO SISTEMA
    // hidrossanitário (isto faz a cor valer no 3D, na Planta e no imersivo de uma vez).
    if (sisColor.on) { var _moS = modeloDe(m.userData.mid); return sisMat(m.userData._sisK || 'outros', _moS ? _moS.alpha : 1); }
    var mo = modeloDe(m.userData.mid);
    var orig = m.userData.matOrig || m.material;
    if (!mo || mo.alpha >= 0.99) return orig;
    var k = orig.uuid;
    if (!mo.transCache[k]) {
      var c = orig.clone();
      c.transparent = true; c.opacity = (orig.opacity != null ? orig.opacity : 1) * mo.alpha; c.depthWrite = false;
      mo.transCache[k] = c;
    }
    return mo.transCache[k];
  }
  S._matBase = matBase;
  function refreshModelo(mo) {
    mo.grupo.visible = !!mo.visivel;
    mo.grupo.children.forEach(function (m) {
      if (m === S.selected) return;
      if (S._clashSel && S._clashSel.indexOf(m) !== -1) return;
      if (m.material === S.matAndamento) return; // estado 4D "em andamento" mantém o âmbar
      if (xray.on && xray.ghosted.indexOf(m) !== -1) return; // raio-X: preserva o fantasma (senão trocar transparência/cor-por-sistema desfaz o isolamento)
      m.material = matBase(m);
    });
  }
  function setTransparencia(mid, alpha) {
    var mo = modeloDe(mid); if (!mo) return;
    mo.alpha = Math.max(0.05, Math.min(1, +alpha || 0));
    Object.keys(mo.transCache).forEach(function (k) { try { mo.transCache[k].dispose(); } catch (_) {} });
    mo.transCache = {};
    refreshModelo(mo); notifyModelos();
  }
  function setVisivel(mid, v) { var mo = modeloDe(mid); if (!mo) return; mo.visivel = !!v; mo.grupo.visible = !!v; notifyModelos(); }
  function setDisciplina(mid, d) {
    var mo = modeloDe(mid); if (!mo) return;
    mo.disciplina = d; mo.elementos.forEach(function (e) { e.disciplina = d; });
    notifyModelos();
    if (opts.onLoaded) opts.onLoaded(elementosVivos()); // 4D/QTO/clash replanejam com a disciplina nova
  }
  /* =====================================================================
   * ⚠ O CONTADOR CONTAVA O QUE CARREGOU, NÃO O QUE SE VÊ
   *
   * `Elementos: 13.229` ficava na tela mesmo com a cena VAZIA. Medido no
   * modelo real: com o 4D na semana 1, `rotuloElementos()` (o carimbo que já
   * era honesto, e que só era usado em foto e vídeo) dizia "0 de 13.229
   * elementos (vista filtrada)" enquanto o HUD e a barra de status diziam
   * 13.229. O engenheiro olha um visualizador vazio e o app afirma que há
   * treze mil peças ali.
   *
   * E não é só o 4D: escondem peça o isolamento por pavimento, o isolamento
   * manual, o conjunto de seleção, a comparação de versões, a fase
   * "existente" da reforma, as remoções do editor e o corte (que some pela
   * GPU, sem tocar em `visible`). Sete caminhos, um contador que ignorava
   * todos.
   *
   * ⚠ A CONTA É POR TEMPO, NÃO POR EVENTO. Ligar em cada um dos sete deixaria
   *   o oitavo de fora no dia em que ele nascer — e o corte nem passa por
   *   `visible`. Uma passada a cada 500 ms pega qualquer caminho, inclusive os
   *   que ainda não existem. O custo dela foi MEDIDO e teve de ser reduzido:
   *   ver a nota em `contarVisiveis`.
   * =================================================================== */
  var _hudUltimo = 0, _hudVis = -1;
  function atualizarHud() {
    var el = 0, tri = 0;
    S.modelos.forEach(function (mo) { el += mo.nEl || 0; tri += mo.nTri || 0; });
    var nv = el ? contarVisiveis() : 0;
    _hudVis = nv;
    var cortado = (renderer.clippingPlanes || []).length > 0;
    var elBox = hud.querySelector('[data-h="el"]');
    elBox.textContent = (nv < el ? nv.toLocaleString('pt-BR') + ' de ' + el.toLocaleString('pt-BR') : el.toLocaleString('pt-BR'));
    elBox.title = nv < el
      ? 'A cena está mostrando ' + nv.toLocaleString('pt-BR') + ' de ' + el.toLocaleString('pt-BR') +
        ' elementos. Escondem peça: a simulação 4D, o isolamento por pavimento, o isolamento manual, um conjunto de seleção, a fase "existente" de reforma e as remoções do editor. O botão ↺ restaura.'
      : (cortado ? 'Todos os elementos estão na cena, mas há um corte ativo: parte da geometria não aparece.' : 'Todos os elementos do modelo estão na cena.');
    hud.querySelector('[data-h="tri"]').textContent = Math.round(tri).toLocaleString('pt-BR');
    var _cb = S._onContadores || (S.opts && S.opts.onVisibilidade);
    if (_cb) { try { _cb(nv, el); } catch (e) {} }
  }
  /* releitura por tempo — ver a nota de `contarVisiveis`: o sinal é barato,
     a conta é cara, e a cara só roda quando o sinal muda */
  var _hudMalhas = -1, _hudConferido = 0;
  S._tickExtra.push(function () {
    var ag = Date.now();
    if (ag - _hudUltimo < 500) return;
    _hudUltimo = ag;
    if (!S.modelos.length) return;
    var mv = contarMalhasVisiveis();
    if (mv !== _hudMalhas) { _hudMalhas = mv; _hudConferido = ag; atualizarHud(); return; }
    /* ⚠ O SINAL BARATO NÃO PEGA TUDO, e isso foi MEDIDO: ao abrir o modelo o
       HUD acertava 12.103 aos 2,7 s e REGREDIA para 13.229 aos 3,6 s, ficando
       errado para sempre. A agregação (B2) refaz a cena trocando malhas, e o
       número de malhas visíveis pode cair no mesmo valor de antes enquanto o
       de ELEMENTOS mudou. Então, além do sinal, uma conferência exata a cada
       2 s: 7,8 ms nesse intervalo é 0,4% do tempo, e é o preço de o número na
       tela não poder ficar mentindo indefinidamente. */
    if (ag - _hudConferido < 2000) return;
    _hudConferido = ag;
    if (contarVisiveis() !== _hudVis) atualizarHud();
  });
  function rebuildIndices() {
    S.elementos = []; S.meshPorId = {}; S.meshPorUid = {};
    S.modelos.forEach(function (mo) {
      S.elementos = S.elementos.concat(mo.elementos);
      mo.grupo.children.forEach(function (m) {
        var eid = m.userData.expressID; if (eid == null) return;
        S.meshPorId[eid] = m; S.meshPorUid[mo.mid + ':' + eid] = m;
      });
    });
  }
  function removerModelo(mid) {
    var mo = modeloDe(mid); if (!mo) return;
    desagregarModelo(mo);     /* B2: as malhas mescladas saem junto */
    /* o indice de cotas guarda uid e ancora deste modelo: invalida e apaga o
       que estiver na tela, senao sobra cota pendurada no vazio */
    if (S._setCota && S._cotaEstado && S._cotaEstado().on) S._setCota(false);
    S.modelos.splice(S.modelos.indexOf(mo), 1);
    mo.grupo.children.slice().forEach(function (m) { if (m.geometry) { try { m.geometry.dispose(); } catch (_) {} } if (m.userData && m.userData._edgeLn && m.userData._edgeLn.geometry) { try { m.userData._edgeLn.geometry.dispose(); } catch (_) {} } });
    Object.keys(mo.matCache).forEach(function (k) { try { mo.matCache[k].dispose(); } catch (_) {} });
    Object.keys(mo.transCache).forEach(function (k) { try { mo.transCache[k].dispose(); } catch (_) {} });
    modelRoot.remove(mo.grupo);
    if (typeof mid === 'number') { try { S.api.CloseModel(mid); } catch (_) {} } // mid sintético ('p3dN') no embind vira >>>0 = 0 e FECHARIA o 1º IFC real
    if (S.selected && S.selected.userData.mid === mid) { S.selected = null; S.prevMat = null; if (S._contornoSelecao) S._contornoSelecao(null); }
    if (S._limparRaioX) S._limparRaioX(); // raio-X segura refs de malhas que podem ter saído do modelo removido
    S._clashSel = (S._clashSel || []).filter(function (m) { return m.userData.mid !== mid; });
    rebuildIndices(); atualizarHud(); notifyModelos();
    if (S._limparMedidas) S._limparMedidas(); // medidas referenciam coordenadas que podem ter saído
    if (S._ctecCancelar) S._ctecCancelar(); // linha de corte riscada pode referenciar o modelo removido
    if (!S.modelos.length && S.planta && S.planta.on && S._setPlanta) S._setPlanta(false);
    else if (S.planta && S.planta.on && S._replanejarCorte) S._replanejarCorte(); // sobrou modelo: corte re-ancorado
    if (S.corteL && S.corteL.on && S._aplicarCorteL) S._aplicarCorteL(); // re-ancora (ou sai, se o bbox esvaziou)
    if (S._xrReSnap) S._xrReSnap(); // imersivo câmera/caminhar: re-ancora a escala no bbox restante (ou sai se esvaziou)
    if (pav.isolado || pav.manual) restaurarVisibilidade(); else pavRender(); // isolamento (🏢 OU 👁) pode ter ficado sem alvo
    if (mid === 'edit' && S._editReset) S._editReset(); // apagar "Criados no OrçaPRO" = zerar edições (senão replay ressuscita + pins órfãos)
    if (opts.onLoaded) opts.onLoaded(elementosVivos());
    if (S._cristalFechouTudo) S._cristalFechouTudo();
    if (!S.modelos.length) { over.style.display = 'flex'; limparSisMatCache(); } // sem modelos: nenhuma malha referencia os materiais de sistema → pode liberar a GPU (com modelos vivos, NÃO limpar: eles ainda apontam pro cache global)
  }
  function limparTudo() {
    if (S.planta && S.planta.on && S._setPlanta) S._setPlanta(false);
    if (S.corteL && S.corteL.on && S._setCorteL) S._setCorteL(false);
    if (S._ctecCancelar) S._ctecCancelar();
    if (S._limparMedidas) S._limparMedidas();
    /* as cotas da rede vao junto: elas apontam para uid de modelo que esta
       saindo, e o indice ficaria com anconra de coisa que nao existe mais */
    if (S._setCota) S._setCota(false);
    /* ⚠ o 🗑 tem de tirar os modelos da OBRA, nao so da cena. Sem este aviso,
       o usuario limpava tudo para comecar do zero, saia da aba, voltava — e a
       restauracao devolvia exatamente os modelos que ele acabou de remover. */
    var indoEmbora = S.modelos.map(function (mo) { return { mid: mo.mid, modeloId: mo.modeloId || '', arquivoId: mo.versaoId || '', sintetico: !!mo.sintetico }; });
    S.modelos.slice().forEach(function (mo) { removerModelo(mo.mid); });
    if (S.opts && S.opts.onModelosRemovidos) { try { S.opts.onModelosRemovidos(indoEmbora); } catch (_) {} }
    if (S._editReset) S._editReset(); // 🗑 limpa TAMBÉM as edições (anotações/removidos sem modelo 'edit')
    S.carimbos = {}; S.qto = {}; S._fut4d = null; S._remEd = null;
    /* ⚠ O CONTORNO DO ATRASO MORA EM `scene`, NÃO EM `modelRoot` — tirar os
       modelos deixava um esqueleto laranja pairando numa cena vazia. E a
       pintura do 4D fica no `_pintura`, que o `matBase` consulta antes de tudo:
       sem zerar, o próximo modelo carregado nasceria com a cor do cronograma
       do modelo anterior. */
    try { limparContorno4D(); } catch (_c4) {}
    S._pintura = null; S._and4d = null;
    pav.isolado = null; pav.manual = false; pavRender();
  }
  S._setTransparencia = setTransparencia; S._setVisivel = setVisivel; S._setDisciplina = setDisciplina;
  /* ⚠ AQUI, e nao onde as funcoes sao declaradas: `S` so passa a existir
     algumas centenas de linhas depois delas, e atribuir antes estoura o
     `montar` inteiro — a aba BIM nao abre. */
  S._carimbarConsulta = carimbarConsulta; S._valoresDe = valoresDe;   /* B3 */
  S._removerModelo = removerModelo; S._limparTudo = limparTudo;

  async function carregarIFC(arrayBuffer, nome, disc, ehExemplo) {
    // identidade + vida: um FileReader em voo de um viewer MORTO não pode nem apagar o overlay
    // nem despejar meshes/índices no viewer NOVO (S global pode já ser outra instância)
    if (S !== Sm || !S.alive) return;
    over.style.display = 'none'; loading.style.display = 'flex';
    if (S._cristalEvento) S._cristalEvento('carregar');
    loading.querySelector('[data-l="txt"]').textContent = 'Lendo ' + (nome || 'IFC') + '…';
    if (S.modelos.length >= 8) { loading.style.display = 'none'; over.style.display = S.modelos.length ? 'none' : 'flex'; if (S._cristalEvento) S._cristalEvento('falhou'); try { alert('Limite de 8 modelos abertos ao mesmo tempo. Remova um antes de abrir outro (memória de vídeo).'); } catch (_) {} return; }
    var mid;
    try {
      await initApi();
      if (S !== Sm || !S.alive) return; // o mundo pode ter mudado durante o await (ctx-lost + remount)
      var data = new Uint8Array(arrayBuffer);
      mid = S.api.OpenModel(data);
      S.modelID = mid; // compat: "modelo corrente" = último carregado
      var modelo = { mid: mid, nome: nome || ('Modelo ' + (S.modelos.length + 1)), disciplina: disc || '', alpha: 1, visivel: true, grupo: new THREE.Group(), matCache: {}, transCache: {}, elementos: [], tipos: {}, nEl: 0, nTri: 0 };
      modelo._bytes = data; // v1.1.85: guarda os bytes do IFC p/ o ☁️ Compartilhar na nuvem (RA/RV)
      /* B0: o LUGAR do arquivo na obra (sobrevive a versao nova) e o hash do
         CONTEUDO (muda a cada reexportacao, de proposito — invalida cache e
         alimenta a comparacao entre versoes; NUNCA entra na chave) */
      /* ⚠ a ORDEM importa desde o B1: o conteudo identifica o arquivo, e e
         por ele que a federacao acha a vaga do modelo. Derivar o modeloId
         antes de conhecer o versaoId cairia sempre no nome. */
      modelo.versaoId = (typeof window !== 'undefined' && window.BimId) ? window.BimId.versaoId(data, data.length) : '';
      modelo.modeloId = idModelo(modelo.nome, modelo.versaoId);
      modelo.grupo.userData.mid = mid;
      modelRoot.add(modelo.grupo);
      // carimbos do exportador pyRevit + BaseQuantities — merge nos mapas compartilhados (4D/5D)
      var carimbos = lerCarimbosOrcaPro(mid), qto = lerQuantitativos(mid);
      modelo.carimbos = carimbos; modelo.qto = qto; // por modelo (expressID colide entre IFCs)
      modelo.familias = lerTipos(mid); // v1.1.82: família/tipo por elemento (Revit → IfcTypeObject)
      modelo.sistemas = lerSistemas(mid); // v1.1.98: SISTEMA por elemento (IfcSystem) → cor por sistema hidrossanitário
      var materiais = lerMateriais(mid); // material da peça (ou do tipo dela) → peso por volume (js/bimpeso.js)
      modelo.pavimentos = lerPavimentos(mid); // 🏢 (y0 real preenchido depois, pelo AABB dos membros)
      var tmpMat = new THREE.Matrix4();
      var getMat = criarGetMat(modelo);
      /* B1: a coleta para o cache anda junto com a montagem — os dados so
         existem aqui, `geo.delete()` os devolve ao WASM logo abaixo.
         ⚠ E ela guarda a REFERENCIA, sem copiar: `GetVertexArray`/
         `GetIndexArray` do web-ifc terminam em `.slice(0)`, entao ja sao
         copias proprias, e `m.applyMatrix4` age no OBJETO (a matriz do mesh),
         nao na geometria — ninguem mexe nesses vetores depois. Copiar aqui
         dobraria a memoria sem motivo. */
      var colG = [], colI = [], colVistos = {}, colBytes = 0, colOk = !!(typeof window !== 'undefined' && window.BimCache);
      S.api.StreamAllMeshes(mid, function (mesh) {
        var geos = mesh.geometries, n = geos.size(), tipoNum = 0;
        try { tipoNum = S.api.GetLineType(mid, mesh.expressID); } catch (_) {}
        var tipoNome = nomeTipo(tipoNum);
        var tKey = String(tipoNome).toUpperCase(); modelo.tipos[tKey] = (modelo.tipos[tKey] || 0) + 1;
        for (var i = 0; i < n; i++) {
          var pg = geos.get(i), geo = S.api.GetGeometry(mid, pg.geometryExpressID);
          var verts = S.api.GetVertexArray(geo.GetVertexData(), geo.GetVertexDataSize());
          var idx = S.api.GetIndexArray(geo.GetIndexData(), geo.GetIndexDataSize());
          var nv = verts.length / 6, pos = new Float32Array(nv * 3), nor = new Float32Array(nv * 3);
          for (var v = 0; v < nv; v++) { pos[v * 3] = verts[v * 6]; pos[v * 3 + 1] = verts[v * 6 + 1]; pos[v * 3 + 2] = verts[v * 6 + 2]; nor[v * 3] = verts[v * 6 + 3]; nor[v * 3 + 1] = verts[v * 6 + 4]; nor[v * 3 + 2] = verts[v * 6 + 5]; }
          var bg = new THREE.BufferGeometry();
          bg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
          bg.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
          bg.setIndex(new THREE.BufferAttribute(idx, 1));
          var c = pg.color, m = new THREE.Mesh(bg, getMat(c.x, c.y, c.z, c.w));
          tmpMat.fromArray(pg.flatTransformation); m.applyMatrix4(tmpMat);
          m.userData.expressID = mesh.expressID; m.userData.tipo = tipoNome; m.userData.mid = mid; m.userData.matOrig = m.material;
          modelo.grupo.add(m);
          S.meshPorId[mesh.expressID] = m; S.meshPorUid[mid + ':' + mesh.expressID] = m;
          if (colOk) {
            var gK = String(pg.geometryExpressID);
            if (!colVistos[gK]) {
              colBytes += pos.byteLength + nor.byteLength + idx.byteLength;
              if (colBytes > TETO_COLETA) { colOk = false; colG = []; colI = []; colVistos = {}; }
              else { colVistos[gK] = 1; colG.push({ gid: gK, pos: pos, nor: nor, idx: idx }); }
            }
            /* ⚠ a MATRIZ em dupla precisao: `flatTransformation` vem em double do
               web-ifc e e ela que carrega a POSICAO da peca no mundo. Estreitar
               aqui perdia precisao ANTES de o motor do cache ver o numero — foi
               medido no navegador (3,9 µm num modelo de ~100 m; num IFC
               georreferenciado isso vira metro). A cor pode ser float32: e 0..1. */
            if (colOk) colI.push({ e: mesh.expressID, gid: gK, m: new Float64Array(pg.flatTransformation), cor: new Float32Array([c.x, c.y, c.z, c.w]) });
          }
          modelo.nTri += idx.length / 3; geo.delete();
        }
        var cb = carimbos[mesh.expressID] || {};
        var famEl = (modelo.familias && modelo.familias[mesh.expressID]) || null;
        /* B0: a identidade que sobrevive a reexportacao. O `uid` fica ao lado
           porque toda a maquina de malhas e indices e feita nele; o que muda e
           que o que se GRAVA passa a ser a `chave`. */
        var idIfc = lerIdentidadeIfc(S.api, mid, mesh.expressID);
        var idB = idElemento(modelo.modeloId, { id: mesh.expressID, globalId: idIfc.globalId });
        var dM = descricaoDeMercado(idIfc, famEl, cb);
        modelo.elementos.push({ globalId: idB.globalId, chave: idB.chave, chaveInstavel: idB.instavel, nomeIfc: idIfc.nomeIfc, tag: idIfc.tag, id: mesh.expressID, uid: mid + ':' + mesh.expressID, mid: mid, arquivo: modelo.nome, tipo: tipoNome, nome: rotuloDisciplina(tipoNome), familia: famEl ? famEl.familia : null, descricao: dM.descricao, descricaoFonte: dM.fonte, sistemaIfc: (modelo.sistemas && modelo.sistemas[mesh.expressID]) || '', etapa: cb.etapa || null, codOrc: cb.codOrc || null, fase: cb.fase || null, tarefa: cb.tarefa || null, disciplinaPeca: cb.disciplinaPeca || null, detalhe: cb.detalhe || null, montagem: cb.montagem || null, folhas: cb.folhas || null, materiais: materiais[mesh.expressID] || (famEl && famEl.tipoId != null && materiais[famEl.tipoId]) || null, qto: (qto && qto[mesh.expressID]) || null });
        modelo.nEl++;
      });
      /* a disciplina que o engenheiro deixou no modelo viaja no manifesto do
         link da nuvem (só o visor da nuvem passa `disc`); sem ela, o celular
         adivinhava pelo nome do arquivo e a Hidráulica podia virar "Outros" —
         justo o filtro de "não furar em cima do cano". Mesma regra do cache. */
      modelo.disciplina = String(disc || '') || detectarDisciplina(modelo.nome, modelo.tipos);
      modelo.elementos.forEach(function (e) { e.disciplina = modelo.disciplina; });
      /* B1: fica pendurado no modelo ate a casca gravar (ou desistir). Nao e
         o viewer quem escreve no disco — a fronteira do produto diz que quem
         persiste e a casca. */
      modelo._coleta = colOk ? { geometrias: colG, instancias: colI, bytes: colBytes } : null;
      /* ⚠ POR QUE ELE NAO COUBE, para a casca poder DIZER. Sem isto o modelo
         entrava na obra, nunca era guardado, e toda reabertura pedia o arquivo
         de novo — a mesma frase, para sempre, sem o usuario jamais saber o
         motivo nem ter como consertar. */
      /* ⚠ O MODELO DE DEMONSTRAÇÃO NÃO É DA OBRA DO CLIENTE. Ele é o IFC de
         outra obra (Murumbir, da RA). Sem esta marca ele entrava em
         `bim_modelos`, voltava na cena a cada abertura, era contado por
         "Gerar orçamento do modelo" e subia para a nuvem junto com o resto. */
      modelo.exemplo = !!ehExemplo;
      modelo._semCache = colOk ? '' : (colBytes > TETO_COLETA
        ? 'a geometria deste modelo passa de ' + Math.round(TETO_COLETA / (1024 * 1024)) + ' MB — ele abre normalmente, mas não fica guardado para reabrir rápido'
        : 'o motor de cache não carregou nesta sessão');
      S.modelos.push(modelo);
      recarimbarIdentidade();   /* B0 */
      agregarModelo(modelo);    /* B2 */
      carimbarConsulta();     /* B3 */
      atualizarHud();
      if (planta.on) setPlanta(false); // carregar modelo com a planta ativa: sai da planta (senão vista fica incoerente)
      if (corteL.on) setCorteL(false); // idem corte livre (o bbox mudou; o usuário re-corta no modelo federado)
      enquadrar(); loading.style.display = 'none';
      if (S._cristalModeloPronto) S._cristalModeloPronto(modelo);
      // AABB (mundo) por elemento do modelo novo — p/ compatibilização entre DISCIPLINAS
      try {
        modelRoot.updateMatrixWorld(true);
        var caixas = {};
        modelo.grupo.children.forEach(function (m) {
          var id = m.userData && m.userData.expressID; if (id == null) return;
          var bb = new THREE.Box3().setFromObject(m); if (bb.isEmpty()) return;
          if (!caixas[id]) caixas[id] = bb; else caixas[id].union(bb);
        });
        modelo.elementos.forEach(function (elx) { var bb = caixas[elx.id]; if (bb) elx.aabb = { min: [bb.min.x, bb.min.y, bb.min.z], max: [bb.max.x, bb.max.y, bb.max.z] }; });
        // 🏢 altura real de cada pavimento = menor Y (mundo, metros) entre os membros com malha
        (modelo.pavimentos || []).forEach(function (pv) {
          var y0 = Infinity;
          pv.eids.forEach(function (eid) { var bb = caixas[eid]; if (bb && bb.min.y < y0) y0 = bb.min.y; });
          if (isFinite(y0)) pv.y0 = y0;
        });
      } catch (_) {}
      S.elementos = []; S.modelos.forEach(function (mo) { S.elementos = S.elementos.concat(mo.elementos); });
      // isolamento antigo (🏢 OU 👁) ficaria incoerente (modelo novo nasce visível) -> restaura; senão só re-lista
      if (pav.isolado || pav.manual) restaurarVisibilidade(); else pavRender();
      if (S._editReaplicarRem) S._editReaplicarRem(); // "removidos na edição" persistidos valem pro IFC que acabou de chegar
      notifyModelos();
      avisarModeloCarregado(modelo);   /* B1: a casca grava o cache e a federacao */
      if (opts.onLoaded) opts.onLoaded(elementosVivos());
    } catch (err) {
      try { if (mid != null && mid !== -1) S.api.CloseModel(mid); } catch (_) {}
      try { if (typeof modelo !== 'undefined' && modelo && S.modelos.indexOf(modelo) === -1) { (modelo.grupo.children || []).forEach(function (m) { if (m.geometry) { try { m.geometry.dispose(); } catch (_) {} } }); Object.keys(modelo.matCache || {}).forEach(function (k) { try { modelo.matCache[k].dispose(); } catch (_) {} }); modelRoot.remove(modelo.grupo); } } catch (_) {}
      try { rebuildIndices(); } catch (_) {} // meshPorId E meshPorUid sem restos do modelo que falhou (o manual só limpava o Uid)
      loading.style.display = 'none'; if (!S.modelos.length) over.style.display = 'flex';
      if (S._cristalEvento) S._cristalEvento('falhou');
      over.querySelector('div').innerHTML = '<div style="font-size:30px">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + '</div><h3 style="margin:8px 0">Não consegui ler este IFC</h3><p style="color:#a9c1d8;font-size:13px">' + esc(String(err && err.message || err)) + '</p><p style="color:#a9c1d8;font-size:12px">Confira se é um .ifc válido (IFC2x3 ou IFC4).</p>';
    }
  }
  function rotuloDisciplina(ifcName) { var u = String(ifcName).toUpperCase(); return TIPOS[u] || String(ifcName).replace(/^IFC/, ''); }

  /* =====================================================================
   * B1 — MONTAR O MODELO A PARTIR DO CACHE, SEM WASM
   *
   * Espelha `carregarIFC` do ponto em que ela ja tem os dados. O molde e o
   * `carregarSintetico` (2D->3D), que ja monta cena sem web-ifc desde a fase C.
   *
   * ⚠ A CENA TEM DE SAIR IDENTICA a de uma abertura normal — mesma malha por
   * peca, mesma matriz no OBJETO (nao assada na geometria), mesmos indices
   * `meshPorId`/`meshPorUid`. Cache que monta "quase igual" e pior que cache
   * nenhum: trena, encaixe e corte tecnico passariam a responder diferente
   * conforme a obra tivesse sido aberta antes ou nao.
   * ===================================================================== */
  function criarGetMat(modelo) {
    return function (r, g, b, a) {
      var k = (r * 255 | 0) + '_' + (g * 255 | 0) + '_' + (b * 255 | 0) + '_' + a.toFixed(2);
      if (!modelo.matCache[k]) modelo.matCache[k] = new THREE.MeshStandardMaterial({ color: new THREE.Color(r, g, b), transparent: a < 1, opacity: a, metalness: .05, roughness: .85, side: THREE.DoubleSide });
      return modelo.matCache[k];
    };
  }

  function montarDoCache(reg, estado) {
    estado = estado || {};
    if (!S || !S.alive) return { ok: false, erro: 'visualizador não está montado' };
    if (typeof window === 'undefined' || !window.BimCache) return { ok: false, erro: 'motor de cache não carregado' };
    if (S.modelos.length >= 8) return { ok: false, erro: 'Limite de 8 modelos abertos ao mesmo tempo.' };

    /* ⚠ o mid e STRING, e isso e requisito, nao estilo: `removerModelo` so
       chama `CloseModel` quando o mid e numero, e uma string no embind vira 0,
       que FECHARIA o primeiro IFC de verdade. */
    var mid = 'cache' + (++cacheSeq);
    var r = BimCache.paraCena(reg, mid);
    if (!r.ok) return { ok: false, erro: r.erro };
    var c = r.modelo;

    /* ⚠ o nome vem do registro da OBRA, nao do cache. O cache e chaveado por
       conteudo e o mesmo arquivo pode estar em duas obras com nomes
       diferentes — a ultima importacao sobrescrevia o campo `nome` do
       registro compartilhado, e a outra obra passava a exibir o rotulo da
       vizinha. */
    var nomeDaObra = String(estado.nome || '') || c.nome;
    var modelo = {
      mid: mid, doCache: true, nome: nomeDaObra,
      disciplina: '', alpha: 1, visivel: true,
      grupo: new THREE.Group(), matCache: {}, transCache: {},
      elementos: c.elementos, tipos: c.tipos, nEl: c.nEl, nTri: 0,
      versaoId: c.arquivoId, modeloId: '',
      /* os mapas que so o WASM sabia produzir — e por eles que o modelo
         restaurado continua tendo etapa, quantitativo, familia e pavimento */
      carimbos: c.carimbos, qto: c.qto, familias: c.familias, sistemas: c.sistemas,
      pavimentos: c.pavimentos, topologia: c.topologia, bitolas: c.bitolas,
      fatorLenCache: c.fatorLen, bytesArquivo: c.bytesArquivo, convertidoEm: c.criadoEm
    };
    modelo.grupo.userData.mid = mid;
    modelRoot.add(modelo.grupo);

    var getMat = criarGetMat(modelo);
    var tmpM = new THREE.Matrix4();
    var tipoPorId = {};
    for (var t = 0; t < c.elementos.length; t++) { tipoPorId[c.elementos[t].id] = c.elementos[t].tipo; c.elementos[t].arquivo = nomeDaObra; }

    for (var i = 0; i < c.instancias.length; i++) {
      var it = c.instancias[i];
      var g = c.geometrias[it.g]; if (!g) continue;
      var bg = new THREE.BufferGeometry();
      /* copia por instancia, igual a abertura normal: geometria compartilhada
         entre malhas e o B2, e mexe em raycast, trena e descarte */
      bg.setAttribute('position', new THREE.BufferAttribute(new Float32Array(g.pos), 3));
      bg.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(g.nor), 3));
      bg.setIndex(new THREE.BufferAttribute(new Uint32Array(g.idx), 1));
      var cor = it.cor || [1, 1, 1, 1];
      var m = new THREE.Mesh(bg, getMat(cor[0], cor[1], cor[2], cor[3]));
      tmpM.fromArray(it.m); m.applyMatrix4(tmpM);
      m.userData.expressID = it.e; m.userData.tipo = tipoPorId[it.e] || ''; m.userData.mid = mid; m.userData.matOrig = m.material;
      modelo.grupo.add(m);
      S.meshPorId[it.e] = m; S.meshPorUid[mid + ':' + it.e] = m;
      modelo.nTri += g.idx.length / 3;
    }

    /* a disciplina escolhida pelo usuario NAQUELA obra manda; sem escolha,
       detecta como na abertura normal */
    modelo.disciplina = String(estado.disciplina || '') || detectarDisciplina(modelo.nome, modelo.tipos);
    modelo.elementos.forEach(function (e) { e.disciplina = modelo.disciplina; });

    S.modelos.push(modelo);
    recarimbarIdentidade();   /* B0 */
    agregarModelo(modelo);    /* B2 */
    carimbarConsulta();     /* B3 */
    atualizarHud();
    if (planta.on) setPlanta(false);
    if (corteL.on) setCorteL(false);
    enquadrar(); over.style.display = 'none'; loading.style.display = 'none';
    if (S._cristalModeloPronto) S._cristalModeloPronto(modelo);

    /* caixa envolvente por peca e altura real do pavimento: THREE puro, sao
       recalculados de proposito (guardar criaria uma segunda verdade) */
    try {
      modelRoot.updateMatrixWorld(true);
      var caixas = {};
      modelo.grupo.children.forEach(function (mm) {
        var id = mm.userData && mm.userData.expressID; if (id == null) return;
        var bb = new THREE.Box3().setFromObject(mm); if (bb.isEmpty()) return;
        if (!caixas[id]) caixas[id] = bb; else caixas[id].union(bb);
      });
      modelo.elementos.forEach(function (elx) { var bb = caixas[elx.id]; if (bb) elx.aabb = { min: [bb.min.x, bb.min.y, bb.min.z], max: [bb.max.x, bb.max.y, bb.max.z] }; });
      (modelo.pavimentos || []).forEach(function (pv) {
        var y0 = Infinity;
        (pv.eids || []).forEach(function (eid2) { var bb2 = caixas[eid2]; if (bb2 && bb2.min.y < y0) y0 = bb2.min.y; });
        if (isFinite(y0)) pv.y0 = y0;
      });
    } catch (_) {}

    S.elementos = []; S.modelos.forEach(function (mo) { S.elementos = S.elementos.concat(mo.elementos); });
    if (pav.isolado || pav.manual) restaurarVisibilidade(); else pavRender();
    if (S._editReaplicarRem) S._editReaplicarRem();

    /* o que o usuario tinha ajustado nesta obra volta pelos caminhos normais */
    if (estado.visivel === false && S._setVisivel) S._setVisivel(mid, false);
    var al = +estado.alpha;
    if (isFinite(al) && al > 0 && al < 1 && S._setTransparencia) S._setTransparencia(mid, al);

    notifyModelos();
    avisarModeloCarregado(modelo);
    if (S._xrReSnap) S._xrReSnap();
    if (opts && opts.onLoaded) opts.onLoaded(elementosVivos());
    return { ok: true, mid: mid, nome: modelo.nome, nEl: modelo.elementos.length };
  }
  S._montarDoCache = montarDoCache; S._dadosParaCache = dadosParaCache; S._soltarColeta = soltarColeta;

  function avisarModeloCarregado(mo) {
    if (!mo || !S.opts || !S.opts.onModeloCarregado) return;
    try {
      S.opts.onModeloCarregado({
        mid: mo.mid, nome: mo.nome, arquivoId: mo.versaoId || '', modeloId: mo.modeloId || '',
        disciplina: mo.disciplina || '', doCache: !!mo.doCache, exemplo: !!mo.exemplo,
        temColeta: !!mo._coleta, semCache: mo._semCache || '', nEl: (mo.elementos || []).length
      });
    } catch (_) {}
  }

  /* o pacote que a casca entrega ao BimCache.montar — o viewer nao escreve no
     disco, so entrega dado simples */
  function dadosParaCache(mid) {
    var mo = modeloDe(mid);
    if (!mo || !mo._coleta || mo.doCache || mo.sintetico) return null;
    return {
      arquivoId: mo.versaoId, nome: mo.nome, bytesArquivo: (mo._bytes && mo._bytes.length) || 0,
      criadoEm: new Date().toISOString(), webIfc: '0.0.44', three: THREE.REVISION ? ('r' + THREE.REVISION) : '',
      geometrias: mo._coleta.geometrias, instancias: mo._coleta.instancias,
      elementos: mo.elementos, tipos: mo.tipos, carimbos: mo.carimbos, qto: mo.qto,
      familias: mo.familias, sistemas: mo.sistemas, pavimentos: mo.pavimentos,
      topologia: mo.topologia || lerTopologiaRede(mo.mid), bitolas: bitolasDoModelo(mo),
      fatorLen: fatorLen(mo.mid), nEl: mo.elementos.length, nTri: mo.nTri
    };
  }
  /* bitola por peca: so existe via WASM, e sem ela o modelo restaurado perde a
     cota de rede e a relacao de tubos — recursos que o produto ja vende */
  function bitolasDoModelo(mo) {
    var out = {}, f = fatorLen(mo.mid);
    (mo.elementos || []).forEach(function (e) {
      if (!/IFCPIPE|IFCDUCT|IFCFLOWSEGMENT/i.test(String(e.tipo || ''))) return;
      try { var b = lerBitolaMm(mo.mid, e.id, f); if (b) out[e.id] = b; } catch (_) {}
    });
    return out;
  }
  /* a coleta e grande: uma vez gravada (ou recusada), sai da memoria */
  function soltarColeta(mid) { var mo = modeloDe(mid); if (mo) mo._coleta = null; }

  function abrirArquivo(file) { var fr = new FileReader(); fr.onload = function () { enfileirar(function () { return carregarIFC(fr.result, file.name); }); }; fr.readAsArrayBuffer(file); }
  // v1.1.85 — carrega IFC a partir de bytes (compartilhamento em nuvem: o celular baixa o modelo do VPS)
  /* devolve a promessa da fila: o arquivo da obra (.zip) só importa as vistas DEPOIS que as peças chegaram */
  S._abrirBytes = function (ab, nome, disc) { return enfileirar(function () { return carregarIFC(ab, nome || 'modelo.ifc', disc); }); };
  // modelos IFC atuais com bytes guardados (p/ subir pra nuvem) — sintéticos/editor ficam de fora
  /* arquivoId (hash do conteúdo) vai junto: o link limpa o dinheiro do .ifc antes de enviar e troca o
     arquivoId pelo do arquivo LIMPO — é ele que o celular calcula ao abrir (rvnuvem.limparDinheiroIfc) */
  S._bytesModelos = function () { return S.modelos.filter(function (m) { return m._bytes && m._bytes.length; }).map(function (m) { return { nome: m.nome, disc: m.disciplina || '', bytes: m._bytes, arquivoId: m.versaoId || '' }; }); };
  function carregarExemplo() {
    // v1.1.97 — exemplo = modelo REAL de obra (Murumbir, RA Engenharia) da nuvem; atualizável sem
    // release e sem inchar o pacote. Offline/sem nuvem cai no exemplo embutido (bim/samples/exemplo.ifc).
    var CLOUD = 'https://orcapro.raengenhariaespecial.com.br/samples/murumbir-demolicao.ifc';
    function embutido() { fetch('bim/samples/exemplo.ifc').then(function (r) { return r.arrayBuffer(); }).then(function (ab) { enfileirar(function () { return carregarIFC(ab, 'exemplo.ifc', '', true); }); }).catch(function () { over.querySelector('div').innerHTML = '<div style="font-size:30px">' + (typeof Icones !== 'undefined' ? Icones.get('tabela', 15) : '') + '</div><p style="color:#a9c1d8">Abra um arquivo .ifc seu — o exemplo não foi encontrado.</p>'; }); }
    fetch(CLOUD).then(function (r) { if (!r.ok) throw new Error('http'); return r.arrayBuffer(); }).then(function (ab) { enfileirar(function () { return carregarIFC(ab, 'Murumbir — Demolição (exemplo)', '', true); }); }).catch(embutido);
  }
  S._abrirArquivo = abrirArquivo; S._carregarExemplo = carregarExemplo;
}

// desmonta um viewer MORTO (pós webglcontextlost): remove listeners globais, cancela o RAF,
// libera os modelos do WASM e o renderer — deixa o caminho limpo pro montar() criar um novo.
function desmontarMorto() {
  if (!S) return;
  try { if (S.xr && S.xr.on && S._sairImersivo) S._sairImersivo(); } catch (_) {} // fecha sessão XR/loop antes de derrubar
  try { S._xrActive = false; if (S.renderer && S.renderer.setAnimationLoop) S.renderer.setAnimationLoop(null); } catch (_) {}
  try { if (S.raf) cancelAnimationFrame(S.raf); } catch (_) {}
  try { if (Reuniao.on) Reuniao.sair(); } catch (_) {}
  try { if (S._onKeyDown) window.removeEventListener('keydown', S._onKeyDown); } catch (_) {}
  try { if (S._onKeyUp) window.removeEventListener('keyup', S._onKeyUp); } catch (_) {}
  try { if (S._onMouseMove) document.removeEventListener('mousemove', S._onMouseMove); } catch (_) {}
  try { if (S._resize) window.removeEventListener('resize', S._resize); } catch (_) {}
  try { if (S._ajustarTop) window.removeEventListener('resize', S._ajustarTop); } catch (_) {}
  try { if (S._fabObserver) S._fabObserver.disconnect(); } catch (_) {}
  try { if (S._fabEstilo) window.removeEventListener('resize', S._fabEstilo); } catch (_) {}
  /* o ouvinte de rolagem sai junto: sem isto cada remontagem do viewer deixa
     mais um rAF por quadro amarrado a um dock que já não existe */
  try { if (S._dockRolar) window.removeEventListener('scroll', S._dockRolar, true); } catch (_) {}
  try { if (S._dockDocClick) document.removeEventListener('click', S._dockDocClick, true); } catch (_) {}
  try { S.modelos.slice().forEach(function (mo) { if (typeof mo.mid === 'number') { try { S.api.CloseModel(mo.mid); } catch (_) {} } }); } catch (_) {}
  try { S.renderer.dispose(); } catch (_) {}
  S = null;
}
// itera as MALHAS REAIS de todos os modelos (um elemento pode ter VÁRIAS malhas — uma por cor;
// meshPorUid guarda só a última, então visibilidade via mapa deixava peças meio-escondidas)
function cadaMalha(fn) { if (!S) return; S.modelRoot.children.forEach(function (g) { (g.children || []).forEach(fn); }); }
// "removido na edição" (✏️ apagarIfc) compõe com TODO escritor de visibilidade — mesma família
// do ehFuturo4d: sem isto, 4D/isolar/restaurar/focar ressuscitam o que o editor ocultou.
function ehRemovidoEd(m) {
  var r = S && S._remEd; if (!r) return false;
  return !!r[m.userData.mid + ':' + m.userData.expressID];
}
// elementos SEM os "removidos na edição" — o que o EAP/QTO/4D/clash consomem tem que ser
// o MESMO modelo que o viewer mostra (peça apagada no ✏️ não pode ser orçada/quantificada)
function elementosVivos() {
  if (!S) return [];
  var r = S._remEd; if (!r) return S.elementos.slice();
  return S.elementos.filter(function (e) { return !r[e.uid]; });
}
// aplica o estado 4D: esconde futuros; construídos = material original; em andamento = âmbar
function aplicarEstado(est) {
  if (!S) return;
  // 4D sobrescreve a visibilidade inteira -> o isolamento (🏢/👁) deixa de valer; limpa o marcador
  if (S.pav && (S.pav.isolado || S.pav.manual)) { S.pav.isolado = null; S.pav.manual = false; if (S._pavRender) S._pavRender(); }
  var fut = {}, and = {};
  (est && est.futuros || []).forEach(function (id) { fut[id] = 1; });
  (est && est.emAndamento || []).forEach(function (id) { and[id] = 1; });
  S._fut4d = fut; // isolamento 🏢/👁 compõe com isto (não ressuscita futuros)
  S._and4d = and; // "em andamento" (âmbar): o restore do raio-X consulta isto p/ NÃO apagar o âmbar do 4D
  /* ⚠ O 4D AUTOMÁTICO TOMA A CENA — e antes ele a tomava PELA METADE. Ele não
     escreve `_pintura`, mas `_matBase` consulta: com uma pintura de outro
     painel ainda ativa (conjunto de seleção, ou o avanço medido do B10), as
     peças "construídas" saíam com a cor DAQUELE outro recurso e as "em
     andamento" com o âmbar do 4D. A cena virava uma mistura de duas legendas,
     e cada painel achava que a sua estava valendo. Quem chega, limpa. */
  S._pintura = null; S._pinturaDono = "4d-auto";
  cadaMalha(function (m) {
    var id = m.userData.expressID; if (id == null) return;
    var uid = m.userData.mid + ':' + id;
    var chave = (fut[uid] != null || and[uid] != null) ? uid : id;
    if (fut[chave] || ehRemovidoEd(m)) { m.visible = false; return; }
    m.visible = true;
    if (m === S.selected) return; // não mexe no selecionado
    m.material = and[chave] ? S.matAndamento : (S._matBase ? S._matBase(m) : (m.userData.matOrig || m.material));
  });
}
function mostrarTudo() {
  if (!S) return;
  if (S.pav && (S.pav.isolado || S.pav.manual)) { S.pav.isolado = null; S.pav.manual = false; if (S._pavRender) S._pavRender(); }
  S._fut4d = null; S._and4d = null; // sair do 4D: nada mais é "futuro" nem "em andamento"
  if (S._pinturaDono === "4d-auto") { S._pintura = null; S._pinturaDono = null; }
  if (S._pinturaDono === "4d-sim") { S._pintura = null; S._pinturaDono = null; }   /* a simulação por data (bim4dsim) também é "o 4D" */
  cadaMalha(function (m) { m.visible = !ehRemovidoEd(m); if (m !== S.selected) m.material = S._matBase ? S._matBase(m) : (m.userData.matOrig || m.material); });
}

// Compatibilização: destaca (vermelho) os elementos de um clash e enquadra a câmera no par.
function focarClash(ids) {
  if (!S) return;
  // caminho EXTERNO (gestao.js "ver clash"): sai da Planta/Corte/Trena antes de voar a câmera —
  // senão o clash fica clipado pelo plano de corte e a órbita segue travada ("não funciona")
  if (S.planta && S.planta.on && S._setPlanta) S._setPlanta(false);
  if (S.corteL && S.corteL.on && S._setCorteL) S._setCorteL(false);
  if (S.medir && S.medir.on && S._setMedir) S._setMedir(false);
  if (S.area && S.area.on && S._setArea) S._setArea(false);
  if (S.ang && S.ang.on && S._setAng) S._setAng(false);
  if (S._fecharCtecModal && S.ctecModal && S.ctecModal.style.display === 'flex') S._fecharCtecModal(); // modal do resultado tapa o viewer -> fecha antes de voar a câmera
  if (S._ctecCancelar) S._ctecCancelar();
  if (S.edit && S.edit.on && S._setEdit) S._setEdit(false); // editor armado + câmera voando = clique seguinte criaria parede sem querer (setEdit já limpa a cadeia)
  if (S.p3dPanel && S.p3dPanel.style.display === 'flex') S.p3dPanel.style.display = 'none'; // modal 2D→3D também taparia o clash
  limparClash();
  // desfaz a seleção anterior ANTES de pintar o par de vermelho: devolve o material e apaga o contorno verde
  // (senão o selMat/contorno da seleção antiga sobrevivem por cima da cena do clash). Gate v1.1.89.
  if (S.selected) { S.selected.material = S.prevMat; S.selected = null; S.prevMat = null; }
  if (S._contornoSelecao) S._contornoSelecao(null);
  var idset = {}; (ids || []).forEach(function (id) { idset[id] = 1; });
  var box = new THREE.Box3(), any = false;
  S.modelRoot.children.forEach(function (g) { (g.children || []).forEach(function (m) {
    if (m.userData && (idset[m.userData.mid + ':' + m.userData.expressID] || idset[m.userData.expressID])) {
      if (ehRemovidoEd(m)) return; // "removido na edição" não é destacável — segue oculto
      m.visible = true; m.material = S.clashMat; box.expandByObject(m); any = true; S._clashSel.push(m);
    }
  }); });
  if (any) {
    var size = box.getSize(new THREE.Vector3()), c = box.getCenter(new THREE.Vector3());
    var maxDim = Math.max(size.x, size.y, size.z) || 2, dist = maxDim * 3 + 2;
    S.camera.position.set(c.x + dist * .7, c.y + dist * .55, c.z + dist * .7);
    S.camera.near = Math.max(0.01, maxDim / 100); S.camera.far = Math.max(1000, maxDim * 200); S.camera.updateProjectionMatrix();
    S.orbit.target.copy(c); S.orbit.update();
    S.fly.yaw = Math.atan2(S.camera.position.x - c.x, S.camera.position.z - c.z); S.fly.pitch = -0.3;
  }
}
function limparClash() { if (!S) return; (S._clashSel || []).forEach(function (m) { m.material = S._matBase ? S._matBase(m) : (m.userData.matOrig || m.material); }); S._clashSel = []; }

// ============================================================
// REFINO DO CLASH — geometria REAL (triângulo-a-triângulo, motor BIMTri)
// sobre os pares que o envelope (AABB) apontou. Cada clash ganha
// geo = 'confirmado' (tri de A atravessa tri de B) | 'descartado' (caixas se
// tocam mas a geometria não) | 'nao-verificavel' (sem malha/cap estourado —
// honesto: não-verificável NÃO vira "sem conflito"). Só triângulos dentro da
// caixa de interseção (expandida) entram no teste — mantém o custo baixo.
// ============================================================
function refinarClash(clashes, opts) {
  clashes = clashes || [];
  if (!S || typeof window === 'undefined' || !window.BIMTri) return clashes;
  opts = opts || {};
  var MAX_TRI = opts.maxTriPorElemento || 40000; // por ELEMENTO (malha completa em mundo)
  var FOLGA = opts.folga != null ? opts.folga : 0.01;
  var MAX_TESTES = opts.maxTestes || 400000;     // pares tri×tri por clash
  var MAX_CLASHES = opts.maxClashes || 800;      // refina os N piores (a lista já vem ordenada)
  var DEADLINE_MS = opts.deadlineMs || 2500;     // orçamento GLOBAL: estourou -> resto vira não-verificável (UI explica)
  var MODO_FOLGA = opts.modo === "folga";        // B5: mede distância em vez de cruzamento
  var FOLGA_ALVO = opts.folgaAlvo != null ? opts.folgaAlvo : 0.30;
  try { S.modelRoot.updateMatrixWorld(true); } catch (_) {} // RAF pode estar congelado (aba em background)
  var t0 = performance.now();
  // índice uid/eid -> malhas (um elemento pode ter VÁRIAS malhas)
  var porId = {};
  S.modelRoot.children.forEach(function (g) {
    (g.children || []).forEach(function (m) {
      var ud = m.userData || {}; if (ud.expressID == null) return;
      var uid = ud.mid + ':' + ud.expressID;
      (porId[uid] = porId[uid] || []).push(m);
      (porId[ud.expressID] = porId[ud.expressID] || []).push(m);
    });
  });
  var _va = new THREE.Vector3(), _vb = new THREE.Vector3(), _vc = new THREE.Vector3();
  // CACHE por elemento (achado do gate: o mesmo elemento grande aparece em dezenas de clashes —
  // transformar a malha 1x por elemento, não 1x por clash): id -> { tris: Float32Array (mundo),
  // aabb: [x0,y0,z0,x1,y1,z1] } | 'cap' | null (sem malha)
  var cache = {};
  function cacheDe(id) {
    if (id in cache) return cache[id];
    var malhas = porId[id];
    if (!malhas || !malhas.length) return (cache[id] = null);
    var total = 0, mi, m, g;
    for (mi = 0; mi < malhas.length; mi++) {
      g = malhas[mi].geometry;
      if (g && g.attributes && g.attributes.position) total += Math.floor(((g.index ? g.index.array.length : g.attributes.position.count)) / 3);
    }
    if (total > MAX_TRI) return (cache[id] = 'cap');
    var arr = new Float32Array(total * 9), w = 0;
    var bx0 = Infinity, by0 = Infinity, bz0 = Infinity, bx1 = -Infinity, by1 = -Infinity, bz1 = -Infinity;
    for (mi = 0; mi < malhas.length; mi++) {
      m = malhas[mi]; g = m.geometry;
      if (!g || !g.attributes || !g.attributes.position) continue;
      var pos = g.attributes.position, idx = g.index ? g.index.array : null;
      var nTri = Math.floor((idx ? idx.length : pos.count) / 3), mw = m.matrixWorld;
      for (var t = 0; t < nTri; t++) {
        var i0 = idx ? idx[t * 3] : t * 3, i1 = idx ? idx[t * 3 + 1] : t * 3 + 1, i2 = idx ? idx[t * 3 + 2] : t * 3 + 2;
        _va.fromBufferAttribute(pos, i0).applyMatrix4(mw);
        _vb.fromBufferAttribute(pos, i1).applyMatrix4(mw);
        _vc.fromBufferAttribute(pos, i2).applyMatrix4(mw);
        arr[w] = _va.x; arr[w + 1] = _va.y; arr[w + 2] = _va.z;
        arr[w + 3] = _vb.x; arr[w + 4] = _vb.y; arr[w + 5] = _vb.z;
        arr[w + 6] = _vc.x; arr[w + 7] = _vc.y; arr[w + 8] = _vc.z;
        w += 9;
        if (_va.x < bx0) bx0 = _va.x; if (_va.x > bx1) bx1 = _va.x; if (_va.y < by0) by0 = _va.y; if (_va.y > by1) by1 = _va.y; if (_va.z < bz0) bz0 = _va.z; if (_va.z > bz1) bz1 = _va.z;
        if (_vb.x < bx0) bx0 = _vb.x; if (_vb.x > bx1) bx1 = _vb.x; if (_vb.y < by0) by0 = _vb.y; if (_vb.y > by1) by1 = _vb.y; if (_vb.z < bz0) bz0 = _vb.z; if (_vb.z > bz1) bz1 = _vb.z;
        if (_vc.x < bx0) bx0 = _vc.x; if (_vc.x > bx1) bx1 = _vc.x; if (_vc.y < by0) by0 = _vc.y; if (_vc.y > by1) by1 = _vc.y; if (_vc.z < bz0) bz0 = _vc.z; if (_vc.z > bz1) bz1 = _vc.z;
      }
    }
    return (cache[id] = { tris: arr.subarray(0, w), aabb: [bx0, by0, bz0, bx1, by1, bz1] });
  }
  // recorte da malha em cache pela zona da interseção (+folga)
  function filtrar(ce, caixa, exp) {
    var E = FOLGA + (exp || 0);
    var x0 = caixa.min[0] - E, y0 = caixa.min[1] - E, z0 = caixa.min[2] - E;
    var x1 = caixa.max[0] + E, y1 = caixa.max[1] + E, z1 = caixa.max[2] + E;
    var tris = ce.tris, out = [];
    for (var b = 0; b < tris.length; b += 9) {
      var tx0 = Math.min(tris[b], tris[b + 3], tris[b + 6]), tx1 = Math.max(tris[b], tris[b + 3], tris[b + 6]);
      if (tx1 < x0 || tx0 > x1) continue;
      var ty0 = Math.min(tris[b + 1], tris[b + 4], tris[b + 7]), ty1 = Math.max(tris[b + 1], tris[b + 4], tris[b + 7]);
      if (ty1 < y0 || ty0 > y1) continue;
      var tz0 = Math.min(tris[b + 2], tris[b + 5], tris[b + 8]), tz1 = Math.max(tris[b + 2], tris[b + 5], tris[b + 8]);
      if (tz1 < z0 || tz0 > z1) continue;
      for (var q = 0; q < 9; q++) out.push(tris[b + q]);
    }
    return out;
  }
  function contido(bIn, bOut) { // AABB bIn dentro de bOut (com folga)
    return bIn[0] >= bOut[0] - FOLGA && bIn[1] >= bOut[1] - FOLGA && bIn[2] >= bOut[2] - FOLGA &&
           bIn[3] <= bOut[3] + FOLGA && bIn[4] <= bOut[4] + FOLGA && bIn[5] <= bOut[5] + FOLGA;
  }
  for (var i = 0; i < clashes.length; i++) {
    var c = clashes[i]; if (!c) continue;
    if (i >= MAX_CLASHES || performance.now() - t0 > DEADLINE_MS) { c.geo = 'nao-verificavel'; continue; }
    if (!c.inter || !c.inter.min || !c.inter.max) { c.geo = 'nao-verificavel'; continue; }
    var A = cacheDe(c.aId), B = cacheDe(c.bId);
    if (A === null || A === 'cap' || B === null || B === 'cap') { c.geo = 'nao-verificavel'; continue; }
    /* ⚠ NO MODO FOLGA A CAIXA `inter` NAO CONTEM SUPERFICIE NENHUMA.
       Ela e a intersecao das AABB DILATADAS: com as pecas separadas por um
       vao `g`, ela e uma FATIA DENTRO DO VAO, de espessura folga - g,
       centrada entre as duas. A superficie de A fica em `g - folga/2` de
       distancia da borda da fatia — ou seja, FORA dela sempre que o vao
       passar de metade da folga pedida.
       Recortar por ela zerava os dois lados, o par saia como "descartado",
       e o modo folga perdia CALADO metade da faixa que o usuario pediu:
       com folga de 30 cm, nada entre 15 e 30 cm era achado.
       Reabrir por folga/2 e exatamente o necessario e suficiente:
       inter.min - folga/2 = B.min - folga <= A.max sempre que o vao real
       for <= folga; e simetrico do outro lado. Menos perde face, mais so
       custa triangulo. No modo rigido a expansao e zero e nada muda. */
    var EXP = MODO_FOLGA ? FOLGA_ALVO / 2 : 0;
    var ta = filtrar(A, c.inter, EXP), tb = filtrar(B, c.inter, EXP);
    var conf = false, naoVer = false;
    if (ta.length && tb.length) {
      if (MODO_FOLGA) {
        /* ⚠ B5 modo FOLGA: a pergunta nao e "cruza?" e sim "quao perto?".
           distMalhas para no primeiro par abaixo do limite — o modo so
           precisa do SIM, e varrer o resto custaria o detector inteiro.
           A distancia so e anotada quando ELE ACHOU: quando nao acha, o
           motor devolve null de proposito, porque o menor par examinado
           nao e o minimo verdadeiro (o pre-filtro por caixa descarta
           pares que podem estar mais perto). Numero inventado aqui vira
           decisao de obra. */
        var rf = window.BIMTri.distMalhas(ta, tb, { limite: FOLGA_ALVO, maxTestes: MAX_TESTES });
        if (rf.estourou) naoVer = true;
        else if (rf.abaixo) { conf = true; c.distancia = rf.distancia; }
      } else {
        var r = window.BIMTri.algumIntersecta(ta, tb, MAX_TESTES);
        if (r.estourou) naoVer = true; else conf = r.confirmado;
      }
    }
    // CONTENÇÃO TOTAL (achado bloqueador do gate): tubo INTEIRO dentro da viga não tem
    // cruzamento de superfície — teste ponto-dentro-do-sólido (paridade de raio, voto 3 eixos)
    // com um vértice do elemento menor contra a malha COMPLETA do maior.
    /* ⚠ A CONTENCAO VALE NOS DOIS MODOS, e tirar o modo folga daqui foi erro
       meu. O raciocinio era "se um esta dentro do outro, a distancia e zero e
       o distMalhas ja pega" — e e falso: as SUPERFICIES nao se cruzam, e a
       distancia minima entre elas e o vao entre a peca de dentro e a parede
       da de fora. Um tubo inteiro dentro de uma viga larga da distancia
       MAIOR que a folga pedida e sai como "sem conflito" — justamente o
       conflito mais grave que existe. */
    if (!conf && !naoVer) {
      var menor = null, maior = null;
      if (contido(A.aabb, B.aabb)) { menor = A; maior = B; }
      else if (contido(B.aabb, A.aabb)) { menor = B; maior = A; }
      if (menor && menor.tris.length >= 3) {
        conf = window.BIMTri.dentroVoto([menor.tris[0], menor.tris[1], menor.tris[2]], maior.tris);
        /* contido = atravessa de fato: a distancia entre os solidos e ZERO,
           e nao a que o distMalhas mediu entre as superficies. */
        if (conf && MODO_FOLGA) c.distancia = 0;
      }
    }
    c.geo = naoVer ? 'nao-verificavel' : (conf ? 'confirmado' : 'descartado');
    /* no modo folga a gravidade e o quanto FALTA de espaco, nao a penetracao:
       10 cm faltando numa folga exigida de 30 e outra conversa que 1 cm. */
    if (MODO_FOLGA && conf && c.distancia != null && FOLGA_ALVO > 0) {
      var frac = c.distancia / FOLGA_ALVO;
      c.severidade = frac <= 0.34 ? 'grave' : (frac <= 0.67 ? 'media' : 'leve');
    }
  }
  return clashes;
}

// ===================== REUNIÃO: presença multi-usuário no modelo =====================
// Vários usuários andam no MESMO modelo com um avatar nomeado (compatibilização ao vivo).
// Transporte simples e robusto: SSE (recebe) + POST (envia pose) num relay do VPS — sem
// dependências. Sem internet, o BIM segue 100% (a reunião só não conecta).
var Reuniao = {
  on: false, sala: '', uid: 'u' + Math.random().toString(36).slice(2, 9),
  es: null, outros: {}, grupo: null, cfg: null, _lastPost: 0,
  base: function () { return ((typeof window !== 'undefined' && window.CONFIG && window.CONFIG.licencaServer) ? String(window.CONFIG.licencaServer).replace(/\/$/, '') : '') + '/bim-sala/'; },
  _sprite: function (nome, cor) {
    var cv = document.createElement('canvas'); cv.width = 512; cv.height = 128;
    var x = cv.getContext('2d');
    x.fillStyle = 'rgba(12,31,51,.88)'; x.beginPath();
    if (x.roundRect) x.roundRect(6, 18, 500, 92, 26); else x.rect(6, 18, 500, 92);
    x.fill();
    x.strokeStyle = cor; x.lineWidth = 6; x.stroke();
    x.font = 'bold 56px Segoe UI, Arial'; x.fillStyle = '#fff'; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(String(nome || 'Visitante').slice(0, 16), 256, 66);
    var tex = new THREE.CanvasTexture(cv); tex.anisotropy = 4;
    var sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false }));
    sp.scale.set(2.6, 0.65, 1); sp.renderOrder = 999;
    return sp;
  },
  // camisa (jersey) com LOGO da empresa + NOME + TELEFONE — identifica cada um na reunião.
  // Duas texturas: frente normal e verso espelhado (pra ler certo por trás, como no Augin).
  _jerseyTex: function (u) {
    var cv = document.createElement('canvas'); cv.width = 256; cv.height = 256;
    var x = cv.getContext('2d');
    var shirt = u.c1 || '#222b34';
    function desenha(logoImg) {
      x.clearRect(0, 0, 256, 256);
      x.fillStyle = shirt; x.fillRect(0, 0, 256, 256);
      x.fillStyle = 'rgba(255,255,255,.10)'; x.fillRect(0, 0, 256, 20); // "gola"
      if (logoImg) { try { var r = (logoImg.width || 1) / (logoImg.height || 1), w = 100, h = w / r; if (h > 84) { h = 84; w = h * r; } x.drawImage(logoImg, 128 - w / 2, 34, w, h); } catch (e) {} }
      else { // sem logo (convidado da nuvem): iniciais do nome num disco → cada um fica distinto
        var ini = String(u.nome || 'Visitante').trim().split(/\s+/).map(function (p) { return p.charAt(0); }).join('').slice(0, 2).toUpperCase() || 'RA';
        x.fillStyle = 'rgba(255,255,255,.16)'; x.beginPath(); x.arc(128, 64, 34, 0, Math.PI * 2); x.fill();
        x.fillStyle = 'rgba(255,255,255,.95)'; x.font = 'bold 34px Segoe UI, Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(ini, 128, 65); x.textBaseline = 'alphabetic';
      }
      x.textAlign = 'center'; x.fillStyle = '#fff'; x.font = 'bold 27px Segoe UI, Arial';
      x.fillText(String(u.nome || 'Visitante').slice(0, 18), 128, 168);
      if (u.tel) { x.font = '20px Segoe UI, Arial'; x.fillStyle = 'rgba(255,255,255,.88)'; x.fillText(String(u.tel).slice(0, 20), 128, 202); }
    }
    desenha(null);
    var texF = new THREE.CanvasTexture(cv); texF.anisotropy = 4;
    var texB = new THREE.CanvasTexture(cv); texB.anisotropy = 4; texB.wrapS = THREE.RepeatWrapping; texB.repeat.x = -1; texB.offset.x = 1; // verso: espelha p/ ler certo por trás
    if (u.logo) { var img = new Image(); img.onload = function () { desenha(img); texF.needsUpdate = true; texB.needsUpdate = true; }; img.onerror = function () {}; img.src = u.logo; }
    return { texF: texF, texB: texB, shirt: new THREE.Color(shirt) };
  },
  // avatar HUMANO (cabeça/tronco/braços/pernas + capacete); homem/mulher; camisa c/ logo+nome+tel
  _avatar: function (u) {
    var g = new THREE.Group();
    var corC = new THREE.Color(u.c2 || '#f59e0b'), mulher = u.sexo === 'm';
    var matPele = new THREE.MeshStandardMaterial({ color: 0xe4b48e, roughness: .75 });
    var matCalca = new THREE.MeshStandardMaterial({ color: 0x2b3440, roughness: .85 });
    var matSapato = new THREE.MeshStandardMaterial({ color: 0x14181f, roughness: .6 });
    var j = this._jerseyTex(u);
    var matShirt = new THREE.MeshStandardMaterial({ color: j.shirt, roughness: .85 });
    var matJf = new THREE.MeshStandardMaterial({ map: j.texF, roughness: .85 });
    var matJb = new THREE.MeshStandardMaterial({ map: j.texB, roughness: .85 });
    var lh = 0.82, th = 0.52, tw = mulher ? 0.36 : 0.42, td = 0.24, lw = mulher ? 0.13 : 0.15;
    [-1, 1].forEach(function (s) {
      var perna = new THREE.Mesh(new THREE.CylinderGeometry(lw * 0.5, lw * 0.45, lh, 10), matCalca); perna.position.set(s * 0.11, lh / 2, 0); g.add(perna);
      var pe = new THREE.Mesh(new THREE.BoxGeometry(lw * 1.1, 0.07, 0.26), matSapato); pe.position.set(s * 0.11, 0.035, 0.06); g.add(pe);
    });
    // tronco: jersey na frente (+z, idx4) e verso (-z, idx5); camisa lisa nas laterais/topo/base
    var tronco = new THREE.Mesh(new THREE.BoxGeometry(tw, th, td), [matShirt, matShirt, matShirt, matShirt, matJf, matJb]);
    tronco.position.y = lh + th / 2; g.add(tronco);
    var aw = mulher ? 0.09 : 0.11;
    [-1, 1].forEach(function (s) {
      var br = new THREE.Mesh(new THREE.CylinderGeometry(aw * 0.5, aw * 0.45, 0.5, 8), matShirt); br.position.set(s * (tw / 2 + aw * 0.45), lh + th - 0.27, 0); br.rotation.z = s * 0.09; g.add(br);
      var mao = new THREE.Mesh(new THREE.SphereGeometry(aw * 0.55, 8, 6), matPele); mao.position.set(s * (tw / 2 + aw * 0.5), lh + th - 0.5, 0); g.add(mao);
    });
    var cab = new THREE.Mesh(new THREE.SphereGeometry(0.135, 18, 14), matPele); cab.position.y = lh + th + 0.16; g.add(cab);
    if (mulher) { // cabelo + rabo de cavalo
      var matCab = new THREE.MeshStandardMaterial({ color: 0x3a2a1a, roughness: .9 });
      var cabelo = new THREE.Mesh(new THREE.SphereGeometry(0.15, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.62), matCab); cabelo.position.set(0, lh + th + 0.19, -0.015); g.add(cabelo);
      var rabo = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.028, 0.3, 8), matCab); rabo.position.set(0, lh + th + 0.03, -0.14); rabo.rotation.x = 0.2; g.add(rabo);
    }
    var capacete = new THREE.Mesh(new THREE.SphereGeometry(0.155, 18, 10, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: corC, roughness: .35, metalness: .15 })); capacete.position.y = lh + th + 0.19; g.add(capacete);
    var aba = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.025, 18), capacete.material); aba.position.set(0, lh + th + 0.15, 0.07); g.add(aba);
    var nome = this._sprite(u.nome, u.c2 || '#f59e0b'); nome.position.y = lh + th + 0.55; g.add(nome);
    // indicador de fala (🎤): aparece quando o áudio detecta ESSE avatar falando (Voz.falandoUid)
    var mic = new THREE.Sprite(new THREE.SpriteMaterial({ map: this._micTex(), depthTest: false, transparent: true }));
    mic.scale.set(0.42, 0.42, 1); mic.position.y = lh + th + 0.92; mic.visible = false; mic.renderOrder = 1001;
    g.add(mic); g.userData.mic = mic;
    var esc2 = u.esc === 'baixo' ? 0.9 : u.esc === 'alto' ? 1.1 : 1; g.scale.set(esc2, esc2, esc2);
    g.userData.alvo = { p: new THREE.Vector3(), yaw: 0 };
    return g;
  },
  _micTex: function () {
    // textura POR avatar (não compartilhada): o _dispor libera o .map de cada avatar; uma textura
    // compartilhada seria disposta pelo 1º descarte e sumiria dos outros.
    var cv = document.createElement('canvas'); cv.width = 128; cv.height = 128;
    var x = cv.getContext('2d');
    x.fillStyle = 'rgba(22,163,74,.92)'; x.beginPath(); x.arc(64, 64, 60, 0, Math.PI * 2); x.fill();
    x.strokeStyle = '#eafff2'; x.lineWidth = 6; x.stroke();
    x.font = '64px Segoe UI Emoji, Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('🎤', 64, 70);
    var t = new THREE.CanvasTexture(cv); t.anisotropy = 4;
    return t;
  },
  _aplicar: function (usuarios) {
    var self = this, vistos = {};
    Object.keys(usuarios || {}).forEach(function (uid) {
      if (uid === self.uid) return;
      var u = usuarios[uid]; if (!u || !u.p) return;
      vistos[uid] = 1;
      // LOGO vem fora do broadcast (só o hash 'lv' no SSE): busca 1x por uid quando o lv mudar
      if (!self._logos) self._logos = {};
      var lc = self._logos[uid];
      if (u.lv && (!lc || (lc.lv !== u.lv && !lc.pend))) {
        self._logos[uid] = { lv: u.lv, logo: (lc && lc.logo) || '', pend: true };
        (function (id, lv) { fetch(self.base() + encodeURIComponent(self.sala) + '/logo/' + encodeURIComponent(id)).then(function (r) { return r.ok ? r.text() : ''; }).then(function (t) { self._logos[id] = { lv: lv, logo: t || '', pend: false }; }).catch(function () { if (self._logos[id]) self._logos[id].pend = false; }); })(uid, u.lv);
      } else if (!u.lv && lc) { self._logos[uid] = { lv: '', logo: '', pend: false }; }
      u.logo = (self._logos[uid] && self._logos[uid].logo) || ''; // avatar usa o logo do cache; rebuild dispara quando chega
      var av = self.outros[uid];
      if (!av || av.userData.c1 !== u.c1 || av.userData.c2 !== u.c2 || av.userData.nome !== u.nome || av.userData.esc !== u.esc || av.userData.sexo !== u.sexo || av.userData.tel !== u.tel || av.userData.logo !== u.logo) {
        if (av) { self._dispor(av); self.grupo.remove(av); }
        av = self._avatar(u); av.userData.c1 = u.c1; av.userData.c2 = u.c2; av.userData.nome = u.nome; av.userData.esc = u.esc; av.userData.sexo = u.sexo; av.userData.tel = u.tel; av.userData.logo = u.logo;
        av.position.set(u.p[0], u.p[1] - 1.6, u.p[2]);
        self.grupo.add(av); self.outros[uid] = av;
      }
      av.userData.alvo.p.set(u.p[0], u.p[1] - 1.6, u.p[2]); // câmera ≈ olhos → pé do avatar ~1,6m abaixo
      av.userData.alvo.yaw = u.yaw || 0;
    });
    Object.keys(this.outros).forEach(function (uid) { if (!vistos[uid]) { self._dispor(self.outros[uid]); self.grupo.remove(self.outros[uid]); delete self.outros[uid]; delete self._logos[uid]; } });
    if (S && S.opts && S.opts.onReuniao) { try { S.opts.onReuniao(Object.keys(vistos).length + 1); } catch (_) {} }
  },
  // libera GPU: o TRONCO usa material ARRAY [camisa×4, frente, verso] → normaliza p/ array e
  // dispõe .map+.dispose de cada submaterial (o antigo o.material.map casava Array.prototype.map
  // → TypeError abortava o traverse e VAZAVA texturas/geometrias — bloqueador do gate v1.1.93).
  _dispor: function (g) {
    try {
      g.traverse(function (o) {
        try {
          if (o.geometry && !o.isSprite) o.geometry.dispose(); // Sprite (nome/🎤) usa geometria COMPARTILHADA do three r150 — não dispor
          var m = o.material; if (!m) return;
          var arr = Array.isArray(m) ? m : [m];
          for (var i = 0; i < arr.length; i++) { var mm = arr[i]; if (!mm) continue; if (mm.map) mm.map.dispose(); mm.dispose(); }
        } catch (_) {}
      });
    } catch (_) {}
  },
  _tick: function () {
    var self = Reuniao; if (!self.on || !S) return;
    var vozOn = (typeof Voz !== 'undefined' && Voz.on);
    Object.keys(self.outros).forEach(function (uid) {
      var av = self.outros[uid], a = av.userData.alvo;
      av.position.lerp(a.p, 0.14);
      var dy = a.yaw - av.rotation.y; while (dy > Math.PI) dy -= 2 * Math.PI; while (dy < -Math.PI) dy += 2 * Math.PI;
      av.rotation.y += dy * 0.14;
      if (av.userData.mic) av.userData.mic.visible = vozOn && Voz.falandoUid(uid); // 🎤 quando esse colega fala
    });
    if (!self.conectado) return; // sem SSE conectado não martela POST
    var now = Date.now();
    var c = S.camera, e = new THREE.Euler().setFromQuaternion(c.quaternion, 'YXZ');
    // POSE (leve, frequente): só posição/rotação — o relay MERGE preserva a identidade
    if (now - self._lastPost > 180) {
      self._lastPost = now;
      // 429 = sala CHEIA (relay capa em 20 no POST, mas o SSE conecta mesmo assim → sem isto o 21º
      // vira "zumbi": vê todos e some pra todos, sem aviso). Detecta o 429 e sai avisando (gate v1.1.93).
      try { fetch(self.base() + encodeURIComponent(self.sala) + '/pose', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify({ uid: self.uid, p: [c.position.x, c.position.y, c.position.z], yaw: e.y }) }).then(function (r) { if (r && r.status === 429) { self.sair(); if (S && S.opts) { var cb = S.opts.onReuniaoCheia || S.opts.onReuniaoFalha; if (cb) { try { cb(); } catch (_) {} } } } }).catch(function () {}); } catch (_) {}
    }
    // IDENTIDADE (nome/tel/sexo/cores) a cada ~4s — p/ quem entra depois montar o avatar.
    // O LOGO (dataURL pesado) só entra no corpo quando MUDA: o relay guarda por sessão e serve via
    // GET /logo; reenviar a cada 4s desperdiçava ~6 KB/s de upload por participante (gate v1.1.93).
    // Se o POST com o logo falhar, _logoEnviado fica desalinhado e o próximo tick reenvia (retry).
    if (now - (self._lastIdent || 0) > 4000) {
      self._lastIdent = now;
      var g = self.cfg;
      var mudouLogo = g.logo !== self._logoEnviado;
      var body = { uid: self.uid, nome: g.nome, c1: g.c1, c2: g.c2, esc: g.esc, sexo: g.sexo, tel: g.tel, p: [c.position.x, c.position.y, c.position.z], yaw: e.y };
      if (mudouLogo) body.logo = g.logo;
      try { fetch(self.base() + encodeURIComponent(self.sala) + '/pose', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify(body) }).then(function (r) { if (mudouLogo && r && r.ok) self._logoEnviado = g.logo; }).catch(function () {}); } catch (_) {}
    }
  },
  entrar: function (cfg) {
    if (!S) return false;
    this.sair();
    this.cfg = { nome: (cfg && cfg.nome) || 'Visitante', c1: (cfg && cfg.c1) || '#222b34', c2: (cfg && cfg.c2) || '#f59e0b', esc: (cfg && cfg.esc) || 'normal', sexo: (cfg && cfg.sexo) || 'h', tel: (cfg && cfg.tel) || '', logo: (cfg && cfg.logo) || '' };
    this.sala = (cfg && cfg.sala) || 'geral';
    this.grupo = new THREE.Group(); S.scene.add(this.grupo);
    this.conectado = false; this.falhas = 0; this.jaConectou = false; this._logos = {}; this._lastIdent = 0; this._logoEnviado = null;
    var self = this;
    try {
      this.es = new EventSource(this.base() + encodeURIComponent(this.sala) + '/stream');
      // _logoEnviado=null no (re)conectar: se a sessão expirou no relay durante uma queda >6s (TTL),
      // o logo é reenviado no próximo tick; senão o hash bate e ninguém re-busca (gate v1.1.93).
      this.es.onopen = function () { self.conectado = true; self.jaConectou = true; self.falhas = 0; self._logoEnviado = null; if (self._connTimer) { clearTimeout(self._connTimer); self._connTimer = 0; } if (S && S.opts && S.opts.onReuniao) { try { S.opts.onReuniao(self.on ? (Object.keys(self.outros).length + 1) : 0); } catch (_) {} } };
      this.es.onmessage = function (ev) { try { var d = JSON.parse(ev.data); self.conectado = true; self.jaConectou = true; self._aplicar(d.usuarios || {}); } catch (_) {} };
      // queda DEPOIS de conectado: pausa os POSTs (conectado=false) e deixa o SSE reconectar
      // sozinho (onopen religa); só desiste de vez quem NUNCA conectou (3 falhas na entrada).
      // EXCEÇÃO: resposta ≠200 (ex.: 502 do proxy com o relay morto) FECHA o EventSource pra
      // sempre (readyState=CLOSED, sem retry da spec) → sem sair() aqui viraria reunião-zumbi
      // silenciosa (botão verde, contagem stale, nunca se recupera sozinha).
      this.es.onerror = function () {
        self.conectado = false; self.falhas++;
        var fatal = self.jaConectou && self.es && self.es.readyState === 2; // 2 = CLOSED (não reconecta mais)
        if (fatal || (!self.jaConectou && self.falhas >= 3)) { self.sair(); if (S && S.opts && S.opts.onReuniaoFalha) { try { S.opts.onReuniaoFalha(); } catch (_) {} } }
      };
    } catch (_) { this.sair(); return false; }
    this._connTimer = setTimeout(function () { if (self.on && !self.jaConectou) { self.sair(); if (S && S.opts && S.opts.onReuniaoFalha) { try { S.opts.onReuniaoFalha(); } catch (_) {} } } }, 8000);
    S._tickExtra.push(this._tick);
    this.on = true;
    return true;
  },
  sair: function () {
    this.on = false; this.conectado = false;
    if (typeof Voz !== 'undefined' && (Voz.on || Voz.wanted)) { try { Voz.sair(); } catch (_) {} } // sai da reunião → corta o áudio junto (Voz.wanted cobre o mic em aquisição)
    if (this._connTimer) { clearTimeout(this._connTimer); this._connTimer = 0; }
    if (this.es) { try { this.es.close(); } catch (_) {} this.es = null; }
    var i = S ? S._tickExtra.indexOf(this._tick) : -1; if (i !== -1) S._tickExtra.splice(i, 1);
    var selfS = this; if (this.grupo) { Object.keys(this.outros).forEach(function (uid) { selfS._dispor(selfS.outros[uid]); }); if (S) S.scene.remove(this.grupo); }
    this.grupo = null; this.outros = {}; this._logos = {};
    if (S && S.opts && S.opts.onReuniao) { try { S.opts.onReuniao(0); } catch (_) {} }
  }
};

// ===================== VOZ: áudio walkie-talkie da reunião (VAD) =====================
// Cada um só TRANSMITE enquanto FALA (VAD no navegador) → quem não fala não gera tráfego e
// fica em silêncio pros outros (o "pausado" que o Rogério pediu; no exato momento que fala,
// o gate abre e a voz vai). PCM 8kHz mono int16 em frames de ~100ms via o canal /audio do relay
// (separado da pose). Playback por locutor com jitter buffer. getUserMedia + AudioContext exigem
// HTTPS + gesto do usuário (por isso é um botão), igual à câmera.
var Voz = {
  on: false, ctx: null, stream: null, src: null, proc: null, muteGain: null,
  es: null, sala: '', uid: '', base: '', seq: 0, HZ: 8000, frameLen: 800,
  frameBuf: null, frameFill: 0, ratio: 1, wanted: false, _acc: 0, _cnt: 0, _phase: 0,
  vad: { floor: 0.003, hang: 0, speaking: false },
  rx: {}, // uid -> { gain, next, last }
  entrar: function (sala, uid, base) {
    if (this.on) return true;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return false;
    var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return false;
    var self = this; this.sala = sala; this.uid = uid; this.base = base; this.wanted = true;
    // cria + resume o AudioContext AINDA no gesto do toque: no iOS o ctx nasce 'suspended' e só sai do
    // suspenso dentro da ativação do usuário; criar dentro do getUserMedia().then (microtask) deixaria o
    // áudio MUDO no iPhone. ratio já sai daqui (síncrono).
    try { this.ctx = new AC(); if (this.ctx.state === 'suspended') this.ctx.resume(); } catch (_) { this.ctx = null; }
    if (!this.ctx) { this.wanted = false; return false; }
    this.ratio = Math.max(1, this.ctx.sampleRate / this.HZ);
    navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false }).then(function (stream) {
      // saiu no meio da aquisição (wanted=false) OU já ligou de novo (on): descarta o stream E o ctx órfão
      if (self.on || !self.wanted) { try { stream.getTracks().forEach(function (t) { t.stop(); }); } catch (_) {} if (!self.wanted && self.ctx) { try { self.ctx.close(); } catch (_) {} self.ctx = null; } return; }
      self.stream = stream;
      self.frameBuf = new Float32Array(self.frameLen); self.frameFill = 0; self.seq = 0; self._acc = 0; self._cnt = 0; self._phase = 0;
      self.src = self.ctx.createMediaStreamSource(stream);
      var proc = self.ctx.createScriptProcessor(2048, 1, 1); self.proc = proc;
      self.muteGain = self.ctx.createGain(); self.muteGain.gain.value = 0; // não ecoa o próprio microfone
      proc.onaudioprocess = function (e) { self._captura(e); };
      self.src.connect(proc); proc.connect(self.muteGain); self.muteGain.connect(self.ctx.destination);
      try {
        self.es = new EventSource(base + encodeURIComponent(sala) + '/audiostream?uid=' + encodeURIComponent(uid));
        self.es.onmessage = function (ev) { self._recebe(ev.data); };
        self.es.onerror = function () {}; // reconecta sozinho pela spec do EventSource
      } catch (_) {}
      self.on = true;
      if (S && S.opts && S.opts.onVoz) { try { S.opts.onVoz(true); } catch (_) {} }
    }).catch(function (e) {
      self.wanted = false; if (self.ctx) { try { self.ctx.close(); } catch (_) {} self.ctx = null; } // mic negado → fecha o ctx criado no gesto
      if (S && S.opts && S.opts.onVozErro) { try { S.opts.onVozErro((e && e.name) || String(e)); } catch (_) {} }
    });
    return true;
  },
  // downsample p/ 8kHz com acumulador de FASE fracionário e PERSISTENTE entre callbacks: com ratio
  // fracionário (44100/8000=5.5125) um contador inteiro travaria em 6:1 (=7350Hz → voz de esquilo) e
  // ainda descartaria o resto de cada bloco. A fase média converge pra 8000Hz exatos (grupos de ~5 e ~6).
  _captura: function (e) {
    if (!this.on) return;
    var input = e.inputBuffer.getChannelData(0), ratio = this.ratio, i;
    for (i = 0; i < input.length; i++) {
      this._acc += input[i]; this._cnt++; this._phase++;
      if (this._phase >= ratio) {
        this._phase -= ratio;
        this.frameBuf[this.frameFill++] = this._acc / this._cnt; this._acc = 0; this._cnt = 0;
        if (this.frameFill >= this.frameLen) { this._frame(); this.frameFill = 0; }
      }
    }
  },
  _frame: function () {
    var buf = this.frameBuf, n = this.frameLen, i, sum = 0;
    for (i = 0; i < n; i++) sum += buf[i] * buf[i];
    var rms = Math.sqrt(sum / n), v = this.vad;
    // noise floor adaptativo: sobe devagar, desce rápido quando fica quieto
    if (rms < v.floor) v.floor = v.floor * 0.9 + rms * 0.1; else v.floor = v.floor * 0.995 + rms * 0.005;
    var thrOpen = Math.max(0.012, v.floor * 3.2), thrClose = Math.max(0.008, v.floor * 2.0);
    var era = v.speaking;
    if (!v.speaking) { if (rms > thrOpen) { v.speaking = true; v.hang = 6; } }
    else { if (rms > thrClose) v.hang = 6; else if (--v.hang <= 0) v.speaking = false; }
    if (v.speaking !== era && S && S.opts && S.opts.onFala) { try { S.opts.onFala(v.speaking); } catch (_) {} }
    if (!v.speaking) return; // silêncio: NÃO transmite (é o "pausado")
    var pcm = new Int16Array(n);
    for (i = 0; i < n; i++) { var x = buf[i]; if (x > 1) x = 1; else if (x < -1) x = -1; pcm[i] = x < 0 ? (x * 0x8000) | 0 : (x * 0x7fff) | 0; }
    var b64 = this._toB64(pcm);
    try { fetch(this.base + encodeURIComponent(this.sala) + '/audio', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify({ uid: this.uid, q: this.seq++, a: b64 }) }).catch(function () {}); } catch (_) {}
  },
  _recebe: function (data) {
    if (!this.on || !this.ctx) return;
    var msg; try { msg = JSON.parse(data); } catch (_) { return; }
    if (!msg || !msg.a || !msg.u || msg.u === this.uid) return;
    var pcm = this._fromB64(msg.a); if (!pcm || !pcm.length) return;
    var n = pcm.length, f32 = new Float32Array(n), i;
    for (i = 0; i < n; i++) f32[i] = pcm[i] / 0x8000;
    var r = this.rx[msg.u];
    if (!r) { r = this.rx[msg.u] = { gain: this.ctx.createGain(), next: 0, last: 0 }; r.gain.gain.value = 1; try { r.gain.connect(this.ctx.destination); } catch (_) {} }
    r.last = Date.now();
    var ab = this.ctx.createBuffer(1, n, this.HZ); ab.getChannelData(0).set(f32);
    var srcN = this.ctx.createBufferSource(); srcN.buffer = ab; try { srcN.connect(r.gain); } catch (_) { return; }
    var t = this.ctx.currentTime, dur = n / this.HZ;
    if (r.next < t + 0.02) r.next = t + 0.12; // buffer de jitter inicial (evita estouros/gaps)
    if (r.next > t + 0.5) return; // TETO: já há ~0.5s enfileirado (rajada de rede) → descarta este frame p/ não acumular latência
    try { srcN.start(r.next); } catch (_) {}
    r.next += dur;
  },
  falandoUid: function (uid) { var r = this.rx[uid]; return !!(r && (Date.now() - r.last) < 500); },
  euFalando: function () { return !!(this.on && this.vad.speaking); },
  sair: function () {
    this.on = false; this.wanted = false; // wanted=false: se um getUserMedia estiver pendente, ele descarta o mic ao resolver (sem hot-mic)
    if (this.es) { try { this.es.close(); } catch (_) {} this.es = null; }
    if (this.proc) { try { this.proc.disconnect(); this.proc.onaudioprocess = null; } catch (_) {} this.proc = null; }
    if (this.src) { try { this.src.disconnect(); } catch (_) {} this.src = null; }
    if (this.muteGain) { try { this.muteGain.disconnect(); } catch (_) {} this.muteGain = null; }
    if (this.stream) { try { this.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (_) {} this.stream = null; }
    var self = this; Object.keys(this.rx).forEach(function (u) { try { self.rx[u].gain.disconnect(); } catch (_) {} });
    this.rx = {}; this.vad.speaking = false; this.vad.hang = 0;
    if (this.ctx) { try { this.ctx.close(); } catch (_) {} this.ctx = null; }
    if (S && S.opts && S.opts.onVoz) { try { S.opts.onVoz(false); } catch (_) {} }
  },
  _toB64: function (int16) {
    var bytes = new Uint8Array(int16.buffer), bin = '', i, chunk = 0x8000;
    for (i = 0; i < bytes.length; i += chunk) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    return btoa(bin);
  },
  _fromB64: function (b64) {
    try { var bin = atob(b64), len = bin.length, bytes = new Uint8Array(len), i; for (i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i); return new Int16Array(bytes.buffer); } catch (_) { return null; }
  }
};

window.BIM = {
  montar: montar,
  /* ---- B0: identidade duravel ----
     `setObra` e chamado pela casca (js/gestao.js) na montagem e em toda troca
     de obra. `chaveDe` e a porta unica para quem GRAVA vinculo: montar
     'modelo::gid' na mao daria dois donos ao formato. */
  setObra: function (obraId) {
    var novo = String(obraId == null ? '' : obraId);
    if (novo === OBRA_ID) return OBRA_ID;
    OBRA_ID = novo; recarimbarIdentidade(); return OBRA_ID;
  },
  obraAtual: function () { return OBRA_ID; },
  /* ---- B1: cache do modelo e federacao da obra ----
     A casca entrega o mapa da federacao e pede/entrega o cache; o viewer nao
     encosta em Store nem em IndexedDB. */
  setFederacao: function (mapa) {
    FED = mapa || null;
    if (mapa && mapa.obraId) OBRA_ID = String(mapa.obraId);
    recarimbarIdentidade();
    return true;
  },
  federacao: function () { return FED; },
  dadosParaCache: function (mid) { return (S && S._dadosParaCache) ? S._dadosParaCache(mid) : null; },
  soltarColeta: function (mid) { if (S && S._soltarColeta) S._soltarColeta(mid); },
  /* ⚠ os modelos que estao na cena mas cujo ARQUIVO nao esta em memoria — o
     caso do modelo restaurado do cache, que por projeto nao guarda o .ifc. Sem
     isto, o "Compartilhar na nuvem" subia so parte da obra e dizia que estava
     tudo la; o cliente abria no celular e faltava metade do predio. */
  /* ---- B2: agregacao de geometria ----
     Liga/desliga o desenho mesclado. A bandeira existe porque a tabela de
     riscos manda manter o caminho antigo alcancavel: qualquer coisa estranha
     na trena, no encaixe ou no corte tecnico, desliga e volta ao de antes. */
  agregacao: function (on) { return (S && S._ligarAgregacao) ? S._ligarAgregacao(on) : false; },
  agregacaoEstado: function () { return (S && S._agregEstado) ? S._agregEstado() : { on: false }; },
  /* ---- B3: conjuntos de selecao e busca ----
     O motor (js/bimset.js) avalia a regra sobre `BIM.elementos`; aqui ficam so
     as pontas que dependem da cena. */
  carimbarConsulta: function () { return (S && S._carimbarConsulta) ? S._carimbarConsulta() : 0; },
  /* os valores que EXISTEM no modelo para um campo — o editor de regra oferece
     em vez de exigir que o usuario adivinhe a grafia do projetista */
  valoresDe: function (campo) { return (S && S._valoresDe) ? S._valoresDe(campo) : []; },
  /* de chave (B0) para o uid da sessao — a ponte entre o que fica gravado e o
     que a cena entende */
  uidsDeChaves: function (chaves) { return (S && S._uidsDeChaves) ? S._uidsDeChaves(chaves) : []; },
  /* deixa visível só o conjunto; o ↺ Restaurar tudo desfaz */
  isolarChaves: function (chaves) { return (S && S._isolarChaves) ? S._isolarChaves(chaves) : 0; },
  /* { chave: '#rrggbb' } — a cor por regra do B3 */
  /* `dono` é a etiqueta de quem está pintando — ver a nota em `pintarChaves`.
     ⚠ A primeira versão desta linha esquecia de repassá-lo, e a etiqueta
     chegava sempre como "?": todo painel concluía que tinha perdido a cena
     para outro, inclusive logo depois de pintar. Argumento novo em função
     interna precisa atravessar a porta de entrada também. */
  pintarChaves: function (mapa, dono) { return (S && S._pintarChaves) ? S._pintarChaves(mapa, dono) : 0; },
  limparPintura: function () { if (S && S._limparPintura) S._limparPintura(); },
  /* ---- B4: pontos de vista ----
     `cameraAtual` e o que a vista GUARDA; `aplicarVista` e como se volta para
     ela. A miniatura sai do `foto()`, que ja existia. */
  /* ---- B6: simulação 4D dirigida pelo cronograma do engenheiro ---- */
  aplicar4DTarefas: function (sim) { return (S && S._aplicar4DTarefas) ? S._aplicar4DTarefas(sim) : { ok: false, erro: 'visualizador não montado' }; },
  limpar4DTarefas: function () { if (S && S._limpar4DTarefas) S._limpar4DTarefas(); },
  /* ---- simulação 4D por data (js/bim4dsim.js): {ocultos:[uid], pinturas:{uid:{cor,opacidade}}} ---- */
  aplicar4DSim: function (cena) { return (S && S._aplicar4DSim) ? S._aplicar4DSim(cena) : { ok: false, erro: 'visualizador não montado' }; },
  enquadrarUids: function (uids, opts) { return (S && S._enquadrarUids) ? S._enquadrarUids(uids, opts) : false; },
  cameraAtual: function () { return (S && S._cameraAtual) ? S._cameraAtual() : null; },
  aplicarVista: function (v, opts) {
    /* opts.vista = id: aplica SÓ naquela vista (a aba do ponto de vista); as outras ficam como estão */
    if (opts && opts.vista && opts.vista !== '3d') return (S && S._aplicarVistaNa) ? S._aplicarVistaNa(opts.vista, v) : { ok: false, erro: 'visualizador não montado' };
    return (S && S._aplicarVista) ? S._aplicarVista(v, opts) : { ok: false, erro: 'visualizador não montado' };
  },
  /* a fotografia inteira da cena para o ponto de vista (ver `estadoVista`) */
  estadoVista: function (opts) {
    if (opts && opts.vista && opts.vista !== '3d') return (S && S._estadoDaVista) ? S._estadoDaVista(opts.vista) : null;
    return (S && S._estadoVista) ? S._estadoVista() : null;
  },
  vistaTemEstado: function (id) { return !!(S && S._vistaTemEstado && S._vistaTemEstado(id)); },
  vistaInfo: function (id) { return (S && S._vistaInfo) ? S._vistaInfo(id) : null; },
  modelosSemArquivo: function () {
    return ((S && S.modelos) || []).filter(function (m) { return !m.sintetico && !(m._bytes && m._bytes.length); })
      .map(function (m) { return { mid: m.mid, nome: m.nome, doCache: !!m.doCache }; });
  },
  abrirDoCache: function (reg, estado) { return (S && S._montarDoCache) ? S._montarDoCache(reg, estado) : { ok: false, erro: 'visualizador não montado' }; },
  chaveDe: function (el) {
    if (typeof el === 'string') el = ((S && S.elementos) || []).filter(function (x) { return x.uid === el; })[0];
    return (el && el.chave) || '';
  },
  modelosIdentidade: function () {
    return ((S && S.modelos) || []).map(function (m) { return { mid: m.mid, nome: m.nome, modeloId: m.modeloId, versaoId: m.versaoId }; });
  },
  /* ⚠ o canvas do WebGL NÃO redimensiona sozinho quando o layout muda por CSS
   * (esconder a lateral, entrar no modo foco): só o evento `resize` da janela
   * o acorda, e trocar de painel não dispara `resize`. Sem isto o modelo sai
   * esticado e — pior para a trena — o clique cai alguns pixels fora do que a
   * pessoa vê, porque a matriz de projeção continua a da largura antiga. */
  redimensionar: function () { if (S && S._resize) S._resize(); },
  abrirArquivo: function (f) { if (S && S._abrirArquivo) S._abrirArquivo(f); },
  /* ⚠ a disciplina tem de passar: o visor da nuvem recebe do manifesto qual
     arquivo é Hidráulica, Estrutura… e sem ela o filtro por disciplina do
     celular ficava adivinhando pelo nome do arquivo */
  abrirBytes: function (ab, nome, disc) { return (S && S._abrirBytes) ? S._abrirBytes(ab, nome, disc) : null; }, // v1.1.85 — RA/RV nuvem; null = visualizador não montado
  bytesModelos: function () { return (S && S._bytesModelos) ? S._bytesModelos() : []; },
  carregarExemplo: function () { if (S && S._carregarExemplo) S._carregarExemplo(); },
  aplicarEstado: aplicarEstado,
  mostrarTudo: mostrarTudo,
  focarClash: function (ids) { if (S) focarClash(ids); },
  limparClash: function () { if (S) limparClash(); },
  refinarClash: function (clashes, opts) { return refinarClash(clashes, opts); }, // tri-a-tri: anota geo=confirmado/descartado/nao-verificavel
  // ---- ferramentas de coordenação ----
  medir: function (on) { if (S && S._setMedir) S._setMedir(on == null ? !(S.medir && S.medir.on) : !!on); },
  get ultimaMedida() { return (S && S.medir && S.medir.ultima) || null; }, // {valor(m), horizontal}
  area: function (on) { if (S && S._setArea) S._setArea(on == null ? !(S.area && S.area.on) : !!on); },
  get ultimaArea() { return (S && S.medir && S.medir.ultimaArea) || null; }, // {area(m²), perimetro(m), horizontal, aproximada}
  angulo: function (on) { if (S && S._setAng) S._setAng(on == null ? !(S.ang && S.ang.on) : !!on); },
  get ultimoAngulo() { return (S && S.medir && S.medir.ultimoAngulo) || null; }, // {graus}
  limparMedidas: function () { if (S && S._limparMedidas) S._limparMedidas(); },
  /* a trena vista de fora (o visor do link desenha a faixa dele com isto):
     ligada?, quantas medidas, 1º ponto pendente?, a última e o eixo */
  trenaEstado: function () {
    if (!S || !S.medir) return null;
    var m = S.medir, n = 0;
    for (var i = 0; i < m.regs.length; i++) if (m.regs[i].tipo === 'dist') n++;
    return { on: !!m.on, n: n, pendente: m.pts.length, ultima: m.ultima ? { valor: m.ultima.valor, horizontal: !!m.ultima.horizontal, eixo: m.ultima.eixo || '' } : null, eixo: m.eixo || 'livre', objs: m.objs.length };
  },
  desfazerMedida: function () { return (S && S._desfazerMedida) ? S._desfazerMedida() : null; },
  // ---- pavimentos (IfcBuildingStorey) ----
  get pavimentos() { return (S && S._pavLista) ? S._pavLista().map(function (p) { return { nome: p.nome, y0: p.y0, n: p.n }; }) : []; },
  get pavimentoIsolado() { return (S && S.pav && S.pav.isolado) || null; },
  isolarPavimento: function (nome) { return (S && S._isolarPavimento) ? S._isolarPavimento(nome) : false; },
  plantaPavimento: function (nome) { return (S && S._plantaPavimento) ? S._plantaPavimento(nome) : false; },
  // ---- visibilidade ----
  isolarSelecao: function () { if (S && S._isolarSelecao) S._isolarSelecao(); },
  ocultarSelecao: function () { if (S && S._ocultarSelecao) S._ocultarSelecao(); },
  isolarTipo: function () { if (S && S._isolarTipo) S._isolarTipo(); },
  restaurarVisibilidade: function () { if (S && S._restaurarVis) S._restaurarVis(); },
  // ---- RA/RV (v1.1.84): imersivo — andar em escala real, VR, RA Android ----
  abrirXR: function () { if (S && S._toggleXR) S._toggleXR(); },
  painelXRAberto: function () { return !!(S && S.xrPanel && S.xrPanel.style.display === 'flex'); },
  /* ---- API do visitante (js/rvvisor.js) ---- */
  pontoNaTela: function (x, y) { return S && S._pontoNaTela ? S._pontoNaTela(x, y) : null; },
  aoTocar: function (fn) { if (S) S._aoTocar = typeof fn === 'function' ? fn : null; },
  /* coletor de cliques (peso/içamento): fn({uid, chave, nome, tipo, p}) a cada
     clique simples numa peça — ou {uid:''} no vazio — até `coletarCliques(null)` */
  coletarCliques: function (fn) { if (S) S._aoClicarPeca = typeof fn === 'function' ? fn : null; return !!(S && S._aoClicarPeca); },
  coletandoCliques: function () { return !!(S && S._aoClicarPeca); },
  _cliqueColetorEm: function (x, y) { if (S && S._cliqueColetor) S._cliqueColetor({ clientX: x, clientY: y }); }, // gancho de teste
  /* volume pela malha (m³) da peça sem volume no IFC — ESTIMATIVA: {volume, caixa} ou null */
  volumeMalha: function (uid) { return (S && S._volumeMalha) ? S._volumeMalha(uid) : null; },
  /* ---- içamento (js/icarplano.js; casca gestao.js _icar*) — coordenadas do MOTOR (m, z para cima) ---- */
  icarGeometria: function (uids) { return (S && S._icar) ? S._icar.geometria(uids) : {}; },          // {uid: {min, max, cg, cgPelaMalha}}
  icarChao: function () { return (S && S._icar) ? S._icar.chao() : 0; },
  /* um clique simples no 3D devolve o ponto no chão (peça acertada ou plano do chão): fn({x,y,z,uid,noModelo}) — uma vez */
  icarMarcarPonto: function (fn, opts) { if (S) { S._aoMarcarPonto = typeof fn === 'function' ? fn : null; S._aoMarcarOpts = S._aoMarcarPonto ? (opts || null) : null; } return !!(S && S._aoMarcarPonto); },
  icarSondar: function (pts) { return (S && S._icar) ? S._icar.sondar(pts) : []; },        // [{x,y,z,sup}] superfície sob cada ponto (motor)
  /* os pavimentos com a ELEVAÇÃO do IFC (IfcBuildingStorey.Elevation). ⚠ O `y0` do `pavimentos` é a peça mais BAIXA
     do pavimento — com estaca, o Térreo dava −6. Para o nível de apoio vale a elevação; sem ela, null (a tela usa 0). */
  icarPavimentos: function () { return (S && S._pavLista) ? S._pavLista().map(function (p) { return { nome: p.nome, elev: p.elev, y0: p.y0, n: p.n }; }) : []; },
  icarMarcandoPonto: function () { return !!(S && S._aoMarcarPonto); },
  _icarMarcarEm: function (x, y) { if (S && S._aoMarcarPonto) { var f = S._aoMarcarPonto, o = S._aoMarcarOpts; S._aoMarcarPonto = null; S._aoMarcarOpts = null; f(S._icar.pontoNoChao(x, y, o)); return true; } return false; }, // gancho de teste
  icarDesenhar: function (c) { return (S && S._icar) ? S._icar.desenhar(c) : { ok: false, erro: 'visualizador não montado' }; },
  icarLimpar: function () { if (S && S._icar) S._icar.limpar(); },
  icarSimular: function (s) { return (S && S._icar) ? S._icar.simular(s) : { ok: false, erro: 'visualizador não montado' }; },
  icarSimulando: function () { return !!(S && S._icar && S._icar.simulando()); },
  icarPararSimulacao: function () { if (S && S._icar) S._icar.parar(); },
  icarCaptura: function (vista) { return (S && S._icar) ? S._icar.captura(vista) : null; },              // dataURL PNG (fundo branco)
  icarEnquadrar: function () { return !!(S && S._icar && S._icar.enquadrar()); },
  _cristalEstado: function () { return (S && S._cristalEstado) ? S._cristalEstado() : null; },   // centro|carregando|abrindo|cubo|sem-cristal
  _cristalPular: function () { if (S && S._cristalPular) S._cristalPular(); },
  _cristalDiag: function () { return (S && S._cristalDiag) ? S._cristalDiag() : null; },
  _cristalCanto: function () { return (S && S._cristalCanto) ? S._cristalCanto() : null; },
  _cristalCongelar: function (ms) { if (S && S._cristalCongelar) S._cristalCongelar(ms); },   // hook de teste: abertura parada em `ms` (null solta)
  _icarEstado: function (uids) { return (S && S._icar) ? S._icar.estado(uids) : null; }, // gancho de teste
  icarColisoes: function (opts) { return (S && S._icar) ? S._icar.colisoes(opts || {}) : { ok: false, erro: 'visualizador não montado' }; },   // choques e folgas no caminho
  icarVisada: function (o) { return (S && S._icar) ? S._icar.visada(o) : { ok: false, erro: 'visualizador não montado' }; },   // visão do operador (olho → ponto)
  icarCaixas: function (fora, regiao) { return (S && S._icar) ? S._icar.caixas(fora, regiao) : []; },     // caixa (motor) de cada peça visível — para o agente do equipamento
  icarMapa: function (mp) { return (S && S._icar) ? S._icar.mapa(mp) : { ok: false, erro: 'visualizador não montado' }; },   // mapa do agente no chão (null apaga)
  icarPlanta: function (cfg) { return (S && S._icar) ? S._icar.planta(cfg) : { ok: false, erro: 'visualizador não montado' }; }, // planta PDF/DXF + entorno (null apaga)
  icarGoogle3d: function (cfg) { return (S && S._icar) ? S._icar.google3d(cfg) : Promise.resolve({ ok: false, erro: 'visualizador não montado' }); },   // 3D fotorrealista do Google (null desliga)
  icarGoogle3dEstado: function () { return (S && S._icar) ? S._icar.google3dEstado() : null; },
  _icarGoogle3dSondar: function (x, y) { return (S && S._icar) ? S._icar.google3dSondar(x, y) : null; },   // gancho de teste
  icarFotoHD: function (o) { return (S && S._icar) ? S._icar.fotoHD(o) : { ok: false, erro: 'visualizador não montado' }; },   // modo foto: PNG grande, com sombra e anti-serrilhado
  icarLocal: function (cfg) { return (S && S._icar) ? S._icar.local(cfg) : { ok: false, erro: 'visualizador não montado' }; },   // relevo, ruas, postes, sol e clima da obra (null apaga)
  icarGeoIfc: function () { return (S && S._icar) ? S._icar.geoIfc() : { ok: false, motivo: 'visualizador não montado' }; },     // latitude/longitude e norte que o IFC traz
  _icarLocalEstado: function () { return (S && S._icar) ? S._icar.localEstado() : null; },                                     // gancho de teste
  _icarPlantaPonto: function (x, y) { return (S && S._icar) ? S._icar.plantaPonto(x, y) : null; },  // gancho de teste
  _icarPlantaEstado: function () { return (S && S._icar) ? S._icar.plantaEstado() : null; },        // gancho de teste
  _icarMapaEstado: function () { return (S && S._icar) ? S._icar.mapaEstado() : null; },              // gancho de teste: o mapa do agente na cena
  icarSimIr: function (t) { return (S && S._icar) ? S._icar.simIr(t) : false; },
  icarSimPausado: function () { return (S && S._icar) ? S._icar.simPausado() : false; },
  icarPerfil: function (uid) { return (S && S._icarPerfil) ? S._icarPerfil(uid) : null; },            // perfil I da peça (m), ou null
  icarGirar: function (on, dur) { return (S && S._icar) ? S._icar.girar(on, dur) : false; },          // "▶ girar a lança" (uma volta)
  icarGirando: function () { return (S && S._icar) ? S._icar.girando() : false; },
  icarTheta: function (graus) { return (S && S._icar) ? S._icar.theta(graus) : null; },               // lança em θ (graus a partir da dianteira)
  icarSobrecarga: function (k) { return (S && S._icar) ? S._icar.sobrecarga(k) : null; },             // "além do limite": carga × k
  icarOpcoes: function (o) { return (S && S._icar) ? S._icar.opcoes(o || {}) : false; },              // { valores, soCritico, modoFalha }
  _icarEquipEstado: function () { return (S && S._icar) ? S._icar.equipEstado() : null; }, // gancho de teste: pose, cores e rótulos do equipamento articulado
  pinos: function (lista) { if (S && S._pinos) S._pinos(lista || []); },
  olharPara: function (p, dist) { if (S && S._olharPara) S._olharPara(p, dist); },
  tetoVisitante: function (frac) { return S && S._tetoVisitante ? S._tetoVisitante(frac) : null; },
  disciplinas: function () { return S && S._disciplinas ? S._disciplinas() : []; },
  disciplinaVisivel: function (chave, on) { if (S && S._disciplinaVisivel) S._disciplinaVisivel(chave, on); },
  arquivoRA: function (formato, modo) { return S && S._arquivoRA ? S._arquivoRA(formato, modo) : { ok: false, erro: 'visualizador não montado' }; },
  selecionarEm: function (x, y) { if (S && S._selecionarEm) S._selecionarEm(x, y); },
  _selecionarUid: function (uid) { return !!(S && S._selecionarUid && S._selecionarUid(uid)); }, // hook de teste
  imersivo: function (modo) { if (!S || !S.xr) return false; if (S.xr.on) return true; if (S._toggleXR && (!S.xrPanel || S.xrPanel.style.display !== 'flex')) S._toggleXR(); var b = S.xrPanel && S.xrPanel.querySelector('[data-x="' + (modo || 'caminhar') + '"]'); if (b) { b.click(); return true; } return false; },
  imersivoAtivo: function () { return !!(S && S.xr && S.xr.on); },
  sairImersivo: function () { if (S && S._sairImersivo) S._sairImersivo(); },
  foto: function () { return (S && S._tirarFoto) ? S._tirarFoto() : null; }, // dataURL do render (também baixa o PNG carimbado)
  /* ⚠ OS DOIS GANCHOS DO VÍDEO DO 4D. `desenharQuadro` renderiza SÍNCRONO e
     devolve o canvas — é o que faz a gravação andar com a aba escondida, onde
     o requestAnimationFrame não dispara e um vídeo de 15 s sairia preto sem
     erro nenhum. `rotuloElementos` é o mesmo carimbo honesto da foto: quantos
     elementos a cena está REALMENTE mostrando, que num vídeo de 4D é sempre
     menos que o total. */
  /* quem pintou a cena por último — "conjunto", "4d-tarefas", "4d-auto",
     "avanco"… ou null se ninguém pintou. É como cada painel confere se a
     legenda dele ainda descreve o que está na tela. */
  donoDaPintura: function () { return (S && S._pinturaDono) || null; },
  /* quantos elementos a cena está REALMENTE mostrando — ver a nota em
     `atualizarHud`. É o número que a barra de status e o carimbo da foto usam. */
  contarVisiveis: function () { return (S && S._contarVisiveis) ? S._contarVisiveis() : 0; },
  /* o sinal barato de mudança de visibilidade — exposto só para o teste
     provar que ele reage a tudo que a contagem exata reage */
  _contarMalhasVisiveis: function () { return (S && S._contarMalhasVisiveis) ? S._contarMalhasVisiveis() : 0; },
  /* o app registra aqui para saber quando a visibilidade mudou sozinha
     (o 4D, um corte, um isolamento) e repintar a própria barra de status */
  aoMudarVisibilidade: function (fn) { if (S) S._onContadores = fn; },
  desenharQuadro: function (fundo) { return (S && S._desenharQuadro) ? S._desenharQuadro(fundo) : null; },
  /* a foto no tamanho de um quadro de prancha, sem o solo da sondagem (ver `desenharQuadroEm`) */
  desenharQuadroEm: function (fundo, larg, alt, opts) { return (S && S._desenharQuadroEm) ? S._desenharQuadroEm(fundo, larg, alt, opts) : null; },
  /* enquadramento INSTANTANEO (sem tween). O `fit` da fita usa o tween
     cinematografico, que leva ~0,55 s — bonito na tela e inutil para quem vai
     capturar a imagem no mesmo instante: a foto sairia no meio do movimento,
     ou com a camera onde estava. Quem gera documento chama este. */
  enquadrarAgora: function () { if (S && S._enquadrar) { try { S._enquadrar(); return true; } catch (e) {} } return false; },
  rotuloElementos: function () { return (S && S._rotuloElementos) ? S._rotuloElementos() : ""; },
  // v1.1.83 — planta baixa técnica 2D (corte na altura do slider da Planta, hachura + cotas automáticas)
  plantaBaixa: function (o) {
    o = o || {};
    if (!S || !S._gerarPlantaTec) return null;
    var y = o.y != null ? o.y : (S.planta && S.planta.plane ? S.planta.plane.constant : null);
    if (y == null) return null; // sem Planta ativa e sem altura explícita, não há corte honesto
    return S._gerarPlantaTec({ y: y, escala: o.escala || 50, cotas: o.cotas !== false, prof: o.prof || 3, rotAlt: o.rotAlt });
  },
  estiloDesenho: function (on) { if (S && S._setEstiloDesenho) S._setEstiloDesenho(on == null ? !(S._estiloOn && S._estiloOn()) : !!on); },
  // v1.1.96 — colorir por sistema hidrossanitário (3D + planta + RA/RV); sistemaInfo p/ E2E
  sistema: function (on) { if (S && S._setSistema) S._setSistema(on == null ? !(S._sisColorOn && S._sisColorOn()) : !!on); },
  /* tema da CENA 3D: 'orcapro' (navy) | 'revit' (cinza escuro) | 'claro'.
   * A casca do ambiente chama isto para a cena acompanhar a interface. */
  tema: function (id) { return !!(S && S._definirTema && S._definirTema(id)); },
  sistemaOn: function () { return !!(S && S._sisColorOn && S._sisColorOn()); },
  sistemaInfo: function () { return (S && S._sisInfo) ? S._sisInfo() : null; },
  sistemaClassificar: function (texto) { return (S && S._sisClassificar) ? S._sisClassificar(texto) : null; }, // classifica um nome/descrição num sistema (pura; p/ testes e plugins)
  // v1.1.99 — Plantas Executivas Blocok: lê as paredes do IFC → pranchas 90×90 numeradas + material + carga na fundação
  blocok: function (opts) { return (S && S.blocok) ? S.blocok(opts) : null; }, // {semJanela?:bool} → {paredes,material,carga}; abre a prancha em nova aba salvo semJanela
  blocokParedes: function () { return (S && S._extrairParedesBlocok && S._blocokLiberado && S._blocokLiberado()) ? S._extrairParedesBlocok() : { paredes: [], vaosDet: 0 }; }, // só a extração (E2E/diagnóstico) — mesmo gate por licença
  blocokPlanilha: function () { return (S && S.blocokPlanilha) ? S.blocokPlanilha() : null; }, // planilha Excel multi-abas (por pavimento, romaneio, material, insumos, MO, cargas, logística)
  // v1.1.82 — propriedades completas do elemento (todos os psets, instância+família) e thumbnail
  propriedades: function (uid) { return (S && S._propsCompletas) ? S._propsCompletas(uid) : []; },
  thumbFamilia: function (uid, maxPx) { return (S && S._thumbFamilia) ? S._thumbFamilia(uid, maxPx) : null; },
  // ---- 2D→3D (Fase C.1): paredes confirmadas viram modelo sintético no viewer ----
  carregarSintetico: function (caixas, nome) { return (S && S._carregarSintetico) ? S._carregarSintetico(caixas, nome) : null; },
  /* ---- Sondagem 3D (js/sondagem.js monta; aqui só a cena) ---- */
  soloMostrar: function (def) { return (S && S._soloMostrar) ? S._soloMostrar(def) : { ok: false, erro: 'visualizador não montado' }; },
  soloLimpar: function () { if (S && S._soloLimpar) S._soloLimpar(); },
  soloProfundidade: function (zIfc) { return (S && S._soloProfundidade) ? S._soloProfundidade(zIfc) : false; },
  soloDestacar: function (u) { return (S && S._soloDestacar) ? S._soloDestacar(u) : null; },
  soloOpacidade: function (a) { return (S && S._soloOpacidade) ? S._soloOpacidade(a) : null; },
  soloEstado: function () { return (S && S._soloEstado) ? S._soloEstado() : { on: false }; },
  editar: function (on) { if (S && S._setEdit) S._setEdit(on == null ? !(S.edit && S.edit.on) : !!on); },
  /* a espessura com que a próxima parede nasce — vem do tipo (alvtipos.js),
     em METROS, já com as camadas das duas faces somadas */
  espessuraTipo: function (metros, rotulo) { return !!(S && S._setEspEditor && S._setEspEditor(metros, rotulo)); },
  espessuraAtual: function () { return (S && S._espEditor) ? S._espEditor() : null; },
  editarOps: function () { return (S && S._editOps) ? S._editOps() : []; },
  editarAplicar: function (ops) { if (S && S._editAplicar) S._editAplicar(ops); },
  // nº de malhas efetivamente visíveis (modelo ligado + mesh visível) — E2E/diagnóstico
  visiveis: function () {
    var v = 0; if (!S) return 0;
    S.modelRoot.children.forEach(function (g) { if (g.visible === false) return; (g.children || []).forEach(function (m) { if (m.visible) v++; }); });
    return v;
  },
  _p3dTexto: function (txt, nome) { if (S && S._p3dProcessar) S._p3dProcessar(txt, nome); }, // hook de teste: injeta DXF sem file input
  /* "Gerar de desenho" na fita chamava BIM.painelP3d(), que NUNCA EXISTIU:
     o registro devolvia false e o comando respondia "ainda não está
     disponível nesta versão". O painel só abria pelo botão antigo dentro
     do viewer. É o botão da função que o cliente mais pediu — 2D vira 3D
     — e ele estava mudo desde que a fita nasceu. */
  painelP3d: function () { if (S && S._toggleP3d) { S._toggleP3d(); return true; } return false; },
  voo: function (on) { if (S && S._setVoo) { S._setVoo(on); return true; } return false; },
  home: function () { if (S && S._fit) { S._fit(); return true; } return false; },
  painelVis: function () { if (S && S._toggleVis) { S._toggleVis(); return true; } return false; },
  painelPav: function () { if (S && S._togglePav) { S._togglePav(); return true; } return false; },
  planta: function (on) { if (S && S._setPlanta) S._setPlanta(on == null ? !(S.planta && S.planta.on) : !!on); },
  corte: function (on) { if (S && S._setCorteL) S._setCorteL(on == null ? !(S.corteL && S.corteL.on) : !!on); },
  corteConfig: function (cfg) { // {az?, inc?, pos0a1?, inv?} — programático/testes
    if (!S || !S.corteL || !S.corteL.on) return;
    if (cfg && cfg.az != null) { S.corteL.az = +cfg.az; var e1 = S.corteLPanel.querySelector('[data-k="az"]'); if (e1) e1.value = +cfg.az; }
    if (cfg && cfg.inc != null) { S.corteL.inc = +cfg.inc; var e2 = S.corteLPanel.querySelector('[data-k="inc"]'); if (e2) e2.value = +cfg.inc; }
    if (cfg && cfg.pos0a1 != null) { var e3 = S.corteLPanel.querySelector('[data-k="pos"]'); if (e3) e3.value = Math.round(Math.max(0, Math.min(1, +cfg.pos0a1)) * 1000); }
    if (cfg && cfg.inv != null) S.corteL.inv = !!cfg.inv;
    if (S._aplicarCorteL) S._aplicarCorteL();
  },
  snapConfig: function (cfg) { // {on?, v?, m?, a?} — liga/desliga tipos de snap
    if (!S || !S.snap) return { on: false };
    ['on', 'v', 'm', 'a', 'i', 'c'].forEach(function (k) { if (cfg && cfg[k] != null) S.snap[k] = !!cfg[k]; });
    try { localStorage.setItem('orcapro:bim:snap', JSON.stringify({ on: S.snap.on, v: S.snap.v, m: S.snap.m, a: S.snap.a, i: S.snap.i, c: S.snap.c })); } catch (_) {}
    return { on: S.snap.on, v: S.snap.v, m: S.snap.m, a: S.snap.a, i: S.snap.i, c: S.snap.c };
  },
  corteTecnico: function (o) { return (S && S._gerarCorteTec) ? S._gerarCorteTec(o || {}) : null; }, // {ax,az,bx,bz,escala,tipo,prof,inv} -> {url,w,h,escala}
  /* hook de teste do ⊕ centro: o teste de bancada monta o anel à mão, mas quem
     monta o anel de verdade é o EdgesGeometry do three em cima da malha do IFC.
     Sem este gancho, a única prova possível seria "achei um centro no modelo",
     que depende de o modelo ter tubo — e o de exemplo não tem. */
  _aneisDe: function (arrArestas) { return (S && S._acharAneis) ? S._acharAneis(arrArestas) : null; },
  /* hook de teste da lupa: sem ele, provar que ela abriu exige adivinhar por
     pixel, e um falso negativo aí manda procurar defeito no lugar errado. */
  _lupaEstado: function () { if (!S || !S.lupa) return null; var L = S.lupa; return { on: !!L.on, orbita: !!(S.orbit && S.orbit.enabled), x: L.x, y: L.y, id: L.id, esperando: !!L.timer, tipoSnap: L.sn && L.sn.tipo || null, mediDown: !!(S.medir && S.medir.down), ferramenta: !!(S._ferramentaClique && S._ferramentaClique()) }; },
  /* =====================================================================
   * _coordMatriz — a matriz que o web-ifc aplicou ao abrir o arquivo
   *
   * O IFC e Z-up; a cena e Y-up. Quem converte e o web-ifc, e ele guarda a
   * conta. Sem esta janela, exportar camera para BCF (que fala IFC) seria
   * deduzir a permutacao de cabeca — e o criterio do B4 e justamente o
   * projetista abrir o arquivo no Revit NA MESMA CAMERA. Deduzir errado poe
   * a camera dele em outro lugar, sem erro nenhum.
   * ===================================================================== */
  _coordMatriz: function (mid) {
    if (!S || !S.api || !S.api.GetCoordinationMatrix) return null;
    var alvo = (mid != null) ? mid : (S.modelos.filter(function (m) { return typeof m.mid === 'number'; })[0] || {}).mid;
    if (alvo == null) return null;
    try { var m = S.api.GetCoordinationMatrix(alvo); return Array.prototype.slice.call(m); } catch (e) { return String(e && e.message || e); }
  },
  _snapAt: function (cx, cy, raio) { if (!S || !S._mirarEm) return null; var sn = S._mirarEm(cx, cy, raio || (S.snap ? S.snap.raio : 14)); if (!sn || !sn.p) return null; return { tipo: sn.tipo, p: [sn.p.x, sn.p.y, sn.p.z] }; }, // hook de teste: o MESMO cálculo do marcador e do clique (mirarEm)
  /* =====================================================================
   * _perf — a régua do B2, e a razão de ela existir
   *
   * A especificação proíbe declarar ganho de desempenho sem medir: "nenhum
   * número desses vai para nota de versão, apresentação ou proposta antes de
   * ser medido no aparelho e no modelo reais". Sem um gancho, medir `draw
   * calls` exigiria expor o renderer — e aí qualquer código passaria a poder
   * mexer nele.
   *
   * ⚠ `renderer.info.render` só tem número DEPOIS de um quadro desenhado, e a
   * aba do painel fica com `document.hidden === true`, onde o
   * `requestAnimationFrame` não dispara. Por isso ele desenha um quadro
   * síncrono antes de ler: sem isso o número volta zero e a medição mente para
   * o lado bom.
   * ===================================================================== */
  _perf: function () {
    if (!S || !S.alive || !S.renderer) return null;
    try { S.renderer.info.reset(); } catch (_) {}
    var t0 = (typeof performance !== 'undefined' ? performance.now() : 0);
    try { S.renderer.render(S.scene, S.camera); } catch (_) { return null; }
    var msQuadro = (typeof performance !== 'undefined' ? performance.now() : 0) - t0;
    var i = S.renderer.info;
    var malhas = 0, geos = 0, vistos = {};
    try {
      S.modelRoot.traverse(function (o) {
        if (!o.isMesh) return;
        malhas++;
        var g = o.geometry; if (g && !vistos[g.uuid]) { vistos[g.uuid] = 1; geos++; }
      });
    } catch (_) {}
    /* ⚠ a cena INTEIRA, por camada — sem isto nao da para saber QUEM esta
       sendo desenhado quando a conta de draw calls sobe. O modelRoot sozinho
       nao conta: as malhas mescladas do B2 vivem fora dele. */
    var porCamada = { visiveisNaCamera: 0, ocultasDaCamera: 0, invisiveis: 0, foraDoModelo: 0, linhasNaCamera: 0 };
    try {
      S.scene.traverse(function (o) {
        /* ⚠ NAO SO isMesh: linha e ponto tambem gastam chamada de desenho, e o
           produto desenha ARESTAS por peca no estilo desenho. Contar so malha
           fazia a conta nao fechar com o renderer — e a diferenca parecia
           defeito da agregacao quando era outra fonte inteira. */
        if (!(o.isMesh || o.isLine || o.isLineSegments || o.isPoints)) return;
        if (o.isLine || o.isLineSegments || o.isPoints) {
          var vl = true; for (var pl = o; pl; pl = pl.parent) if (pl.visible === false) { vl = false; break; }
          if (vl && S.camera.layers.test(o.layers)) porCamada.linhasNaCamera++;
          return;
        }
        var vis = true;
        for (var p = o; p; p = p.parent) if (p.visible === false) { vis = false; break; }
        if (!vis) { porCamada.invisiveis++; return; }
        if (S.camera.layers.test(o.layers)) porCamada.visiveisNaCamera++; else porCamada.ocultasDaCamera++;
        var dentro = false; for (var q = o; q; q = q.parent) if (q === S.modelRoot) { dentro = true; break; }
        if (!dentro) porCamada.foraDoModelo++;
      });
    } catch (_) {}
    return {
      drawCalls: i.render.calls, triangulos: i.render.triangles,
      geometriasNaGpu: i.memory.geometries, texturas: i.memory.textures,
      malhasNaCena: malhas, geometriasDistintas: geos, cena: porCamada,
      msQuadro: +msQuadro.toFixed(2),
      /* diagnostico: mascara de camada da camera e do renderer — sem isto nao
         da para saber por que a conta de chamadas nao bate com o que a camera
         enxerga */
      mascaraCamera: S.camera.layers.mask, autoReset: S.renderer.info.autoReset,
      sombras: !!(S.renderer.shadowMap && S.renderer.shadowMap.enabled),
      elementos: (S.elementos || []).length,
      modelos: (S.modelos || []).length
    };
  },
  /* mede o clique de verdade: o raycast que o duplo-clique usa */
  _perfClique: function (cx, cy, n) {
    if (!S || !S._raycastEm) return null;
    n = n || 20;
    var t0 = performance.now(), acertos = 0;
    for (var k = 0; k < n; k++) { if (S._raycastEm(cx, cy)) acertos++; }
    return { ms: +((performance.now() - t0) / n).toFixed(3), amostras: n, acertos: acertos };
  },
  // Cotar rede — hooks de teste: ligar/desligar por modo e ler o estado real
  _cota: function (on, modo) { if (S && S._setCota) S._setCota(on, modo); return this._cotaEstado(); },
  _cotaEstado: function () { return (S && S._cotaEstado) ? S._cotaEstado() : null; },
  _cotaIndice: function () { return (S && S._cotaIndice) ? S._cotaIndice() : null; },
  // Numerar rede — hook público: dispara o encadeamento e devolve o pacote
  numerarRede: function () { return (S && S._numerarRede) ? S._numerarRede() : null; },
  numeracao: function () { return (S && S._numeracao) ? S._numeracao() : null; },
  _testeTrena: function () { return S ? { S: S, THREE: THREE } : null; }, // hook de teste (tools/e2e-bim-trena.js): o gabarito da trena precisa das peças, da câmera e das arestas
  _px: function (p) { if (!S) return null; var v = new THREE.Vector3(p[0], p[1], p[2]).project(S.camera); var rc = S.renderer.domElement.getBoundingClientRect(); return { x: rc.left + (v.x + 1) / 2 * rc.width, y: rc.top + (1 - v.y) / 2 * rc.height }; }, // hook de teste: mundo -> px da tela
  _visiveis: function () { if (!S) return null; var v = 0, t = 0; S.modelRoot.children.forEach(function (g) { (g.children || []).forEach(function (m) { t++; if (m.visible) v++; }); }); return { visiveis: v, total: t }; }, // hook de teste: malhas visíveis
  _cam: function () { if (!S) return null; var c = S.camera, t = S.orbit.target; return { p: [c.position.x, c.position.y, c.position.z], t: [t.x, t.y, t.z], near: c.near, far: c.far, rot: S.orbit.enableRotate }; }, // hook de teste: estado da câmera
  // ---- v1.1.89 render/navegação/raio-X: hooks de teste ----
  _selecionarPrimeiro: function () { // seleciona a 1ª malha real (imita o duplo-clique) p/ testar contorno/raio-X sem evento DOM
    if (!S) return null; var alvo = null;
    S.modelRoot.children.some(function (g) { return (g.children || []).some(function (m) { if (m.userData && m.userData.expressID != null && m.visible) { alvo = m; return true; } return false; }); });
    if (!alvo) return null;
    if (S.selected) S.selected.material = S.prevMat;
    S.selected = alvo; S.prevMat = alvo.material; alvo.material = S.selMat;
    if (S._contornoSelecao) S._contornoSelecao(alvo);
    return { tipo: alvo.userData.tipo, eid: alvo.userData.expressID, mid: alvo.userData.mid };
  },
  _temContorno: function () { if (!S) return false; var n = 0; S.scene.children.forEach(function (c) { if (c.type === 'LineSegments' && c.renderOrder === 1000) n++; }); return n; }, // nº de contornos de seleção na cena
  _contornoVis: function () { if (!S) return null; var v = null; S.scene.children.forEach(function (c) { if (c.type === 'LineSegments' && c.renderOrder === 1000) v = c.visible; }); return v; }, // visibilidade do contorno (segue o elemento)
  raioXSelecao: function () { if (S && S._raioXSelecao) S._raioXSelecao(); },
  raioXTipo: function () { if (S && S._raioXTipo) S._raioXTipo(); },
  limparRaioX: function () { if (S && S._limparRaioX) S._limparRaioX(); },
  raioXChaves: function (chaves, msg) { return (S && S._raioXChaves) ? S._raioXChaves(chaves, msg) : 0; },
  _ghostCount: function () { if (!S) return 0; var n = 0, gm = null; S.modelRoot.children.forEach(function (g) { (g.children || []).forEach(function (m) { if (m.material && m.material.opacity === 0.1 && m.material.transparent && m.material.depthWrite === false && m.material.color && m.material.color.getHex() === 0x93a7bd) n++; }); }); return n; }, // malhas em material fantasma
  _amberCount: function () { if (!S) return 0; var n = 0; S.modelRoot.children.forEach(function (g) { (g.children || []).forEach(function (m) { if (m.material === S.matAndamento) n++; }); }); return n; }, // malhas em âmbar (4D em andamento)
  _chaoVis: function () { if (!S || !S.scene) return null; var v = null; S.scene.children.forEach(function (o) { if (o.type === 'Mesh' && o.geometry && o.geometry.type === 'PlaneGeometry' && o.material && o.material.map && o.renderOrder === -1) v = o.visible; }); return v; }, // visibilidade da sombra de contato
  _envSet: function () { return !!(S && S.scene && S.scene.environment); }, // ambiente PMREM aplicado?
  _xr: function () { if (!S || !S.xr) return null; var x = S.xr, c = S.camera, m = S.modelRoot; return { on: x.on, mode: x.mode, escala: +(x.escala || 1).toFixed(4), oriOk: !!x.oriOk, travado: !!x.travado, camY: +c.position.y.toFixed(2), mScale: +m.scale.x.toFixed(4), mPos: [+m.position.x.toFixed(2), +m.position.y.toFixed(2), +m.position.z.toFixed(2)], camDist: +m.position.clone().sub(c.position).length().toFixed(2), camQuat: [+c.quaternion.x.toFixed(3), +c.quaternion.y.toFixed(3), +c.quaternion.z.toFixed(3), +c.quaternion.w.toFixed(3)] }; }, // hook de teste: estado do imersivo RA/RV
  _xrEscala: function (f) { if (S && S._aplicarEscalaImersivo) S._aplicarEscalaImersivo(f); }, // hook de teste
  _xrCentralizar: function () { if (S && S._centralizarImersivo) S._centralizarImersivo(); }, // hook de teste
  _xrTickWalk: function () { if (S && S._xrWalk) S._xrWalk(0.016); }, // hook de teste: roda o passo do imersivo (giroscópio/andar), que o loop real chama
  _xrPasso: function () { if (S && S._xrStep) S._xrStep(); }, // hook de teste: simula 1 passo do acelerômetro
  _xrSimPassos: function (mags) { return (S && S._xrSimPassos) ? S._xrSimPassos(mags) : 0; }, // hook de teste: conta passos numa sequência de |accel|
  _passSens: function (v) { return (S && S._passSensSet) ? S._passSensSet(v) : 1; }, // sensibilidade dos passos (persistida)
  _chaoSet: function () { if (!S || !S.scene) return null; var c = null; S.scene.children.forEach(function (o) { if (o.type === 'Mesh' && o.geometry && o.geometry.type === 'PlaneGeometry' && o.material && o.material.map && o.renderOrder === -1) c = o; }); return c ? { x: c.scale.x, y: c.position.y } : null; }, // sombra de contato
  _frame: function () { if (!S || !S.alive) return false; try { S.orbit.update(); for (var tx = 0; tx < S._tickExtra.length; tx++) { try { S._tickExtra[tx](0.016); } catch (_) {} } S.renderer.render(S.scene, S.camera); for (var tp = 0; tp < (S._tickPos || []).length; tp++) { try { S._tickPos[tp](0.016); } catch (_) {} } return true; } catch (_) { return false; } }, // hook de teste: 1 frame síncrono FIEL ao tick real (inclui _tickExtra E _tickPos — sem _tickPos a lupa nunca desenha fora do navegador, e o teste passaria medindo nada — marcador de snap, rescale de cotas, reunião)
  _foraDoClip: function (p) { return (S && S._foraDoClipRef) ? S._foraDoClipRef({ x: p[0], y: p[1], z: p[2] }) : false; }, // hook de teste
  _ctecModal: function () { return (S && S.ctecModal) ? S.ctecModal : null; }, // hook de teste: elemento do modal do resultado
  _reqPintarTeste: function (pecas, resumo) { return (S && S._reqPintarTeste) ? S._reqPintarTeste(pecas, resumo) : ''; }, // hook de teste: HTML da gaveta da requisição a partir de peças já levantadas
  get elementos() { return elementosVivos(); },
  // ---- multi-IFC (interoperabilidade entre disciplinas) ----
  get modelos() { return S && S._publicos ? S._publicos() : []; },
  setTransparencia: function (mid, a) { if (S && S._setTransparencia) S._setTransparencia(mid, a); },
  setVisivel: function (mid, v) { if (S && S._setVisivel) S._setVisivel(mid, v); },
  setDisciplina: function (mid, d) { if (S && S._setDisciplina) S._setDisciplina(mid, d); },
  removerModelo: function (mid) { if (S && S._removerModelo) S._removerModelo(mid); },
  limpar: function () { if (S && S._limparTudo) S._limparTudo(); },
  /* aciona um botão da barra do viewer pelo `data-b` — a fita no topo chama as
     MESMAS ações (e o mesmo estado) em vez de reescrever cada uma. Devolve
     false quando o botão não existe (ex.: Blocok numa conta sem ele). */
  botao: function (k) {
    if (!S || !S.bar) return false;
    var b = S.bar.querySelector('[data-b="' + String(k).replace(/"/g, '') + '"]');
    if (!b) return false;
    b.click();
    return true;
  },
  /* ---- ambiente tipo Revit (ViewCube, ortogonal, caixa de corte, vistas) ---- */
  caixaCorte: function (on) { return (S && S._caixaCorte) ? S._caixaCorte(!!on) : false; },
  caixaCorteAtiva: function () { return !!(S && S._cxMain && S._cxMain.on); },
  caixaCorteEstado: function () { return (S && S._cxMain) ? S._cxMain.estado() : null; },
  /* onde está, na tela, a seta da face k (0..5 = x−, x+, y−, y+, z−, z+) — usado pelas e2e para puxar a face */
  caixaCorteSetaNaTela: function (k) {
    if (!S || !S._cxMain || !S._cxMain.on || !S._cxMain.setas[k]) return null;
    var p = S._cxMain.setas[k].position.clone().project(S.camera), r = S.renderer.domElement.getBoundingClientRect();
    return { x: r.left + (p.x + 1) / 2 * r.width, y: r.top + (1 - p.y) / 2 * r.height };
  },
  ortogonal: function (on) { return (S && S._ortoMain) ? S._ortoMain(!!on) : false; },
  ortogonalAtivo: function () { return !!(S && S._ortoEstado && S._ortoEstado()); },
  /* só leitura (near/far/fov da câmera principal) — fora do cameraAtual de
     propósito: aquele é o que o ponto de vista GRAVA */
  camPlanos: function () { return (S && S._camPlanos) ? S._camPlanos() : null; },
  irParaInicio: function () { if (S && S._irInicio) { S._irInicio(); return true; } return false; },
  principalOculta: function (on) { if (S) { S._principalOculta = !!on; if (!on && S._resize) S._resize(); } },
  vistaNova: function (cont, nome) { return (S && S._novaVista && cont) ? S._novaVista(cont, nome) : null; },
  vistaFechar: function (id) { return !!(S && S._fecharVista && S._fecharVista(id)); },
  vistaMover: function (id, cont) { return !!(S && S._moverVista && S._moverVista(id, cont)); },
  vistaVisivel: function (id, on) { var v = S && S.vistas && S.vistas[id]; if (v) v.visivel = !!on; return !!v; },
  vistasRedimensionar: function () { if (S && S._redimVistas) S._redimVistas(); if (S && S._resize) S._resize(); },
  vistaCaixaCorte: function (id, on) { var v = S && S.vistas && S.vistas[id]; return v && v.cx ? v.cx.ligar(!!on) : false; },
  vistaRaio: function (id, x, y) { return S && S._raioVista ? S._raioVista(id, x, y) : null; },
  vistaOrtogonal: function (id, on) { return !!(S && S._ortoVista && S._ortoVista(id, on)); },
  vistaOrtoAtivo: function (id) { var v = S && S.vistas && S.vistas[id]; return !!(v && v.orto && v.orto.on); },
  vistaCaixaAtiva: function (id) { var v = S && S.vistas && S.vistas[id]; return !!(v && v.cx && v.cx.on); },
  vistasAbertas: function () { return S && S.vistas ? Object.keys(S.vistas).map(function (k) { var v = S.vistas[k]; return { id: v.id, nome: v.nome, caixa: !!(v.cx && v.cx.on), orto: !!(v.orto && v.orto.on) }; }) : []; },
  vistaCamera: function (id) { var v = S && S.vistas && S.vistas[id]; return v ? { pos: v.camera.position.toArray(), alvo: v.orbit ? v.orbit.target.toArray() : v.alvo.toArray() } : null; },
  temBotao: function (k) { return !!(S && S.bar && S.bar.querySelector('[data-b="' + String(k).replace(/"/g, '') + '"]')); },
  /* ligado = o que a própria barra pinta (classe `on` ou a cor de ativo) — a
     barra do modo mesa lê daqui em vez de guardar estado paralelo */
  botaoAtivo: function (k) { var b = S && S.bar && S.bar.querySelector('[data-b="' + String(k).replace(/"/g, '') + '"]'); if (!b) return false; return b.classList.contains('on') || !!(b.style.background && b.style.background !== 'transparent'); },
  travar: function (on) { if (!S || !S._setTrava) return false; return S._setTrava(on == null ? !(S.trava && S.trava.on) : !!on); },
  travado: function () { return !!(S && S.trava && S.trava.on); },
  /* marcações da vista (o rabisco do modo mesa) por cima do 3D */
  marcacoesMostrar: function (lista, cam) { return !!(S && S._mostrarMarcas && S._mostrarMarcas(lista, cam)); },
  marcacoesVisiveis: function () { return !!(S && S.marcasSvg && S.marcasSvg.style.display !== 'none'); },
  desenharMarcasEm: function (svg, lista, w, h) { if (S && S._desenharMarcas) S._desenharMarcas(svg, lista, w, h); },
  canvasRect: function () { return S ? S.renderer.domElement.getBoundingClientRect() : null; },
  /* modo mesa: girar a vista em volta do modelo e o corte horizontal com o dedo */
  girarVista: function (graus) { return !!(S && S._girarVista && S._girarVista(graus)); },
  corteHorizontal: function (y) { return S && S._corteHorizontal ? S._corteHorizontal(y) : null; },
  corteEstado: function () { return S && S._corteEstado ? S._corteEstado() : null; },
  pavimentosCorte: function () { return S && S._pavimentosCorte ? S._pavimentosCorte() : []; },
  host: function () { return S ? S.host : null; },
  ehVisitante: function () { return !!(S && S._visitante); },
  /* trava da RA (iPhone: sem pinça de tamanho; Android: maquete presa no lugar) */
  raTravada: function () { return S && S._raTravada ? S._raTravada() : true; },
  ultraAtivo: function () { return !!(S && S.ultra); },
  setUltra: function (v) { if (S && S._setUltra) S._setUltra(v); },
  // ---- reunião multi-usuário (avatares no modelo) ----
  reuniao: {
    entrar: function (cfg) { return Reuniao.entrar(cfg); },
    sair: function () { Reuniao.sair(); },
    get ativa() { return Reuniao.on; },
    get sala() { return Reuniao.sala; },
    get participantes() { return Reuniao.on ? Object.keys(Reuniao.outros).length + 1 : 0; },
    // ---- áudio walkie-talkie (v1.1.94): só liga DENTRO de uma reunião, precisa de gesto (botão) + HTTPS ----
    audioEntrar: function () { if (!Reuniao.on) return false; return Voz.entrar(Reuniao.sala, Reuniao.uid, Reuniao.base()); },
    audioSair: function () { Voz.sair(); },
    get audioAtiva() { return Voz.on; },
    euFalando: function () { return Voz.euFalando(); },
    _vozRecebeTest: function (data) { Voz._recebe(data); }, // hook de teste: injeta 1 frame recebido
    _tickTest: function () { Reuniao._tick(); }, // hook de teste: roda 1 tick (rAF fica pausado em aba de fundo)
    _avatarTest: function (u) { // hook de teste: monta um avatar e devolve a estrutura
      var g = Reuniao._avatar(u || {}); var meshes = 0, jersey = false;
      g.traverse(function (o) { if (o.isMesh) { meshes++; var m = o.material; if (Array.isArray(m) ? m.some(function (x) { return x && x.map; }) : (m && m.map)) jersey = true; } });
      var alt = new THREE.Box3().setFromObject(g); var sz = alt.getSize(new THREE.Vector3());
      Reuniao._dispor(g);
      return { meshes: meshes, jersey: jersey, alturaM: +sz.y.toFixed(2), filhos: g.children.length };
    }
  }
};
