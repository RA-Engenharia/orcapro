# =====================================================================
# escolher-base.ps1 — na instalação, deixa o cliente escolher a BASE SINAPI
# do estado dele. Escreve data\base-ativa.json (o app lê isso na carga).
# Só pergunta se houver mais de uma base disponível na pasta data\.
# =====================================================================
$ErrorActionPreference = "SilentlyContinue"
$root = Split-Path -Parent $PSScriptRoot
$dataDir = Join-Path $root "data"
$bases = @(Get-ChildItem $dataDir -Filter "sinapi-*.json" | Where-Object { $_.Name -notmatch "analitico|sample|insumos" })
if ($bases.Count -eq 0) { exit 0 }

function Set-Base($file) {
  $uf = ""; $comp = ""
  if ($file.BaseName -match "sinapi-([A-Za-z]{2})-(\d{4}-\d{2})") { $uf = $Matches[1].ToUpper(); $comp = $Matches[2] }
  $obj = [ordered]@{ arquivo = "data/$($file.Name)"; uf = $uf; competencia = $comp; rotulo = "SINAPI $uf $comp" }
  $json = $obj | ConvertTo-Json -Compress
  [IO.File]::WriteAllText((Join-Path $dataDir "base-ativa.json"), $json, (New-Object System.Text.UTF8Encoding($false)))
  Write-Host ("  -> Base ativa: SINAPI {0} {1}" -f $uf, $comp)
}

if ($bases.Count -eq 1) { Set-Base $bases[0]; exit 0 }

Write-Host ""
Write-Host "  Qual base SINAPI (estado) voce quer usar como padrao?"
for ($i = 0; $i -lt $bases.Count; $i++) {
  $n = $bases[$i].BaseName
  Write-Host ("    [{0}] {1}" -f ($i + 1), $n)
}
$sel = Read-Host "  Numero (Enter = 1)"
if ([string]::IsNullOrWhiteSpace($sel)) { $sel = "1" }
$idx = 0; [int]::TryParse($sel, [ref]$idx) | Out-Null; $idx = $idx - 1
if ($idx -lt 0 -or $idx -ge $bases.Count) { $idx = 0 }
Set-Base $bases[$idx]
exit 0
