# =====================================================================
# baixar-node.ps1 — prepara o Node.js SEM instalar no sistema (sem admin).
# Baixa o Node portátil (win-x64), extrai e deixa node.exe em runtime\node.exe.
# Chamado pelo Instalar-OrcaPRO.bat / Iniciar-OrcaPRO.bat quando não há Node.
# =====================================================================
$ErrorActionPreference = "Stop"
try {
  $root = Split-Path -Parent $PSScriptRoot       # pasta do app (instalador\..)
  $runtime = Join-Path $root "runtime"
  $nodeExe = Join-Path $runtime "node.exe"
  if (Test-Path $nodeExe) { Write-Host "Node ja preparado (runtime\node.exe)."; exit 0 }

  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

  function Get-NodeUrl {
    try {
      $idx = Invoke-RestMethod -Uri "https://nodejs.org/dist/index.json" -TimeoutSec 40
      $lts = $idx | Where-Object { $_.lts -and $_.version -like "v22.*" } | Select-Object -First 1
      if (-not $lts) { $lts = $idx | Where-Object { $_.lts } | Select-Object -First 1 }
      if ($lts) { return "https://nodejs.org/dist/$($lts.version)/node-$($lts.version)-win-x64.zip" }
    } catch { }
    return "https://nodejs.org/dist/v22.23.0/node-v22.23.0-win-x64.zip"   # fallback conhecido
  }

  $url = Get-NodeUrl
  Write-Host "Baixando Node.js de: $url"
  $zip = Join-Path $env:TEMP "orcapro-node.zip"
  Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing -TimeoutSec 600

  $tmp = Join-Path $env:TEMP "orcapro-node-extract"
  if (Test-Path $tmp) { [IO.Directory]::Delete($tmp, $true) }
  Expand-Archive -Path $zip -DestinationPath $tmp -Force

  $node = Get-ChildItem $tmp -Recurse -Filter node.exe | Select-Object -First 1
  if (-not $node) { throw "node.exe nao encontrado no pacote baixado." }

  New-Item -ItemType Directory -Force -Path $runtime | Out-Null
  Copy-Item $node.FullName $nodeExe -Force
  try { [IO.File]::Delete($zip) } catch { }
  try { [IO.Directory]::Delete($tmp, $true) } catch { }
  Write-Host "Node.js pronto em runtime\node.exe"
  exit 0
} catch {
  Write-Host "ERRO ao preparar o Node: $($_.Exception.Message)"
  exit 1
}
