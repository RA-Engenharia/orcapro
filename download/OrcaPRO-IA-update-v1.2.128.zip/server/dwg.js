'use strict';
/* =====================================================================
 * dwg.js — DWG → DXF na máquina do cliente (07/10/2026)
 *
 * O DWG é formato FECHADO da Autodesk: o navegador não lê, e biblioteca livre
 * que "lê DWG" lê pela metade (perde dado calado). O caminho que não perde é
 * converter com um programa que entende DWG de verdade, se ele estiver
 * instalado NESTA máquina:
 *   1. ODA File Converter (gratuito, Open Design Alliance) — ODAFileConverter.exe
 *   2. AutoCAD (accoreconsole.exe, sem janela) — `_.DXFOUT`, provado em 07/10/2026
 *      com o AutoCAD 2026: DWG → DXF 2018 em ~3 s, entidades e textos inteiros.
 * Nenhum dos dois → `disponivel:false` com o motivo e o que fazer (salvar
 * como DXF no programa de origem). Só roda em Windows.
 * ⚠ accoreconsole SEMPRE com `/product ACAD`: sem isso ele carrega os módulos
 *   AEC, e DWG de terceiro com objeto AEC já derrubou o console (memória
 *   autocad-abrir-pelo-atalho).
 * ===================================================================== */
const fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process');

function existe(p) { try { return fs.statSync(p).isFile(); } catch (e) { return false; } }
function procurar() {
  const achados = [];
  if (process.platform !== 'win32') return achados;
  const pf = [process.env['ProgramFiles'] || 'C:\\Program Files', process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)'];
  pf.forEach(function (base) {
    try {
      const oda = path.join(base, 'ODA');
      if (fs.existsSync(oda)) fs.readdirSync(oda).filter(function (d) { return /^ODAFileConverter/i.test(d); }).sort().reverse().forEach(function (d) {
        const exe = path.join(oda, d, 'ODAFileConverter.exe'); if (existe(exe)) achados.push({ tipo: 'oda', exe: exe, nome: d });
      });
    } catch (e) {}
    try {
      const ad = path.join(base, 'Autodesk');
      if (fs.existsSync(ad)) fs.readdirSync(ad).filter(function (d) { return /^AutoCAD( LT)? \d{4}$/i.test(d); }).sort().reverse().forEach(function (d) {
        const exe = path.join(ad, d, 'accoreconsole.exe'); if (existe(exe)) achados.push({ tipo: 'acad', exe: exe, nome: d });
      });
    } catch (e) {}
  });
  return achados;
}
function status() {
  const a = procurar();
  return a.length ? { disponivel: true, conversor: a[0].nome, tipo: a[0].tipo, opcoes: a.map(function (x) { return x.nome; }) }
    : { disponivel: false, motivo: process.platform !== 'win32' ? 'a conversão de DWG só existe no Windows' : 'nem o AutoCAD nem o ODA File Converter estão instalados neste computador',
        fazer: 'Salve como DXF no AutoCAD/programa de origem e importe o .dxf — ou instale o ODA File Converter (gratuito).' };
}
/* converte o DWG (Buffer) → cb({ ok, dxf(Buffer), conversor, ms } | { ok:false, codigo, erro }) */
function converter(buf, cb) {
  const a = procurar();
  if (!a.length) { const st = status(); return cb({ ok: false, codigo: 'sem-conversor', erro: 'Não há conversor de DWG neste computador: ' + st.motivo + '. ' + st.fazer }); }
  if (!buf || buf.length < 32 || buf.slice(0, 2).toString('latin1') !== 'AC') return cb({ ok: false, codigo: 'nao-dwg', erro: 'O arquivo não é um DWG (o cabeçalho não começa com "AC").' });
  const pasta = fs.mkdtempSync(path.join(os.tmpdir(), 'orcapro-dwg-'));
  const ent = path.join(pasta, 'entrada'), sai = path.join(pasta, 'saida');
  fs.mkdirSync(ent); fs.mkdirSync(sai);
  const dwg = path.join(ent, 'desenho.dwg');
  fs.writeFileSync(dwg, buf);
  const conv = a[0], t0 = Date.now();
  function limpar() { try { fs.rmSync(pasta, { recursive: true, force: true }); } catch (e) {} }
  function fim(dxfPath, saida) {
    if (!existe(dxfPath)) { limpar(); return cb({ ok: false, codigo: 'nao-gerou', erro: 'O ' + conv.nome + ' não gerou o DXF. ' + String(saida || '').slice(-300) }); }
    const dxf = fs.readFileSync(dxfPath); limpar();
    cb({ ok: true, dxf: dxf, conversor: conv.nome, ms: Date.now() - t0 });
  }
  if (conv.tipo === 'oda') {
    /* ODAFileConverter <pasta-in> <pasta-out> <versão> <tipo> <recursivo> <auditar> [filtro] */
    cp.execFile(conv.exe, [ent, sai, 'ACAD2018', 'DXF', '0', '1', '*.DWG'], { timeout: 180000, windowsHide: true }, function (err, so, se) {
      fim(path.join(sai, 'desenho.dxf'), (so || '') + (se || '') + (err ? err.message : ''));
    });
    return;
  }
  const dxf = path.join(sai, 'desenho.dxf').replace(/\\/g, '/');
  const scr = path.join(pasta, 'dxf.scr');
  fs.writeFileSync(scr, '_.DXFOUT\n"' + dxf + '"\n_V\n2018\n16\n', 'utf8');
  cp.execFile(conv.exe, ['/i', dwg, '/s', scr, '/product', 'ACAD', '/l', 'en-US'], { timeout: 180000, windowsHide: true, encoding: 'utf16le' }, function (err, so) {
    fim(dxf, String(so || '').replace(/\0/g, '') + (err ? ' ' + err.message : ''));
  });
}
module.exports = { status: status, converter: converter, _procurar: procurar };
