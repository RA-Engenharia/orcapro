@echo off
chcp 65001 >nul
title OrcaPRO IA
cd /d "%~dp0"

REM --- Node: usa o runtime embutido/baixado; senao o do sistema; senao baixa ---
if exist "%~dp0runtime\node.exe" set "PATH=%~dp0runtime;%PATH%"
where node >nul 2>nul
if errorlevel 1 (
  echo Preparando o Node.js ^(so na 1a vez, precisa de internet^)...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalador\baixar-node.ps1"
  if exist "%~dp0runtime\node.exe" set "PATH=%~dp0runtime;%PATH%"
)
where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js indisponivel. Rode Instalar-OrcaPRO.bat com a internet ligada.
  pause
  exit /b 1
)

REM --- PORTA: porta.txt manda, senao 8754 ---
REM  Uma maquina pode ter mais de uma instalacao do OrcaPRO (a do atalho, a de
REM  um pacote antigo, a saida do instalador). Todas subiam na 8754, e quem
REM  chegava primeiro vencia — inclusive uma com MENOS bases SINAPI que a
REM  outra, sem nada na tela avisar qual respondeu. Criar um porta.txt com o
REM  numero desejado ao lado deste .bat resolve, e o arquivo NAO viaja no
REM  pacote de atualizacao: a escolha sobrevive ao proximo update.
set "PORT_APP=8754"
if exist "%~dp0porta.txt" (for /f "usebackq delims=" %%p in ("%~dp0porta.txt") do set "PORT_APP=%%p")

echo [OK] Subindo o OrcaPRO IA ^(porta %PORT_APP%^)... a IA ja vem pronta, roda na nuvem.

REM --- SEM JANELA DE CONSOLE ---
REM  Aqui era:  start "OrcaPRO App" /min cmd /c "node server\static.js"
REM  Isso deixava uma janela de console ABERTA O TEMPO TODO na barra de
REM  tarefas — minimizada nao e escondida: ocupa a barra, aparece no
REM  Alt+Tab, e um clique com uma tecla derruba o servidor no meio do
REM  trabalho. Clientes reclamaram disso.
REM  O wscript sobe o node sem console nenhum. Para PARAR o app agora
REM  existe o Fechar-OrcaPRO.bat (fechar a janela nao e mais uma opcao,
REM  porque nao ha janela).
REM  SUPERVISOR (N23, 25/10/2026): o servidor caiu 3 vezes em 2 dias sem deixar rastro e
REM  ninguem o religava. server\vida.js e um VIGIA minimo: roda o static.js como filho e
REM  o RELIGA se ele cair; o log fica em Documents\OrcaPRO-Backups\diag\servidor-vida.log.
REM  O Fechar-OrcaPRO.bat continua fechando: grava o arquivo .parar-vida, termina o servidor e o vigia sai
REM  junto (o codigo de saida do servidor nao diz mais "fechou": codigo 1 agora e queda e e religado).
REM  JA ABERTO: se a porta ja responde com um servidor SUPERVISIONADO, so abre o navegador. Um segundo
REM  vigia nao ajuda em nada (o proprio vida.js se recusa a tomar a porta de outro vigia).
REM  Sem o vida.js (pacote antigo) sobe o static.js direto, como sempre.
curl -s -m 2 "http://127.0.0.1:%PORT_APP%/__backup/status" 2>nul | findstr /c:"\"supervisionado\":true" >nul 2>nul
if not errorlevel 1 (
  echo [OK] O OrcaPRO IA ja estava aberto ^(porta %PORT_APP%^). Abrindo no navegador...
  goto :abrir
)
set "CMD_SERVIDOR=node server\static.js"
if exist "%~dp0server\vida.js" set "CMD_SERVIDOR=node server\vida.js"
if exist "%~dp0iniciar-oculto.vbs" (
  wscript //B //Nologo "%~dp0iniciar-oculto.vbs" "%~dp0." "%CMD_SERVIDOR%"
) else (
  REM  pacote antigo sem o lancador: volta ao jeito de antes, com janela.
  start "OrcaPRO App" /min cmd /c "node server\static.js"
)
ping 127.0.0.1 -n 3 >nul
:abrir
start "" "http://localhost:%PORT_APP%/index.html?v=%RANDOM%%RANDOM%"
echo.
echo OrcaPRO IA aberto no navegador. Esta janela fecha sozinha.
echo (Para desligar o sistema depois, use o Fechar-OrcaPRO.bat.)
timeout /t 4 >nul
