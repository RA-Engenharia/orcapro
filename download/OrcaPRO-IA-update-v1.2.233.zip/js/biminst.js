/* =====================================================================
 * biminst.js — INSTALAÇÕES do modelador BIM (fase B5, motor puro, Node-testável)
 *
 * Pedido do Rogério (08/10/2026, PLANO-BIM-MODELADOR.md §3 B5): tubos por
 * sistema, material e diâmetro, desenhados por pontos com INCLINAÇÃO; as
 * CONEXÕES saem sozinhas nos encontros; aparelhos e ralos com ponto de
 * ligação; eletrodutos, caixas e dutos com o mesmo jeito de traçar; e o
 * QUANTITATIVO por sistema, material e DN ligado à SINAPI pelo mapa.
 *
 * Como o resto do editor (js/bimedit.js), tudo é LISTA DE OPERAÇÕES:
 *   {op:'trecho', id, sistema, material, dn, p1:{x,y,z}, p2:{x,y,z},
 *    aplicacao?, pn?, classe?, iso?, larg?, alt?, bitola?}
 *   {op:'peca', id, peca, sistema, material?, dn?, x, y, z, rotY?, alturaPiso?}
 *   {op:'instAlterar', id, ...campos}   (troca DN, material, aplicação…)
 *   mover / apagar com o id de um trecho ou peça (o BimEdit repassa).
 * As CONEXÕES não são operações: são DEDUZIDAS da geometria a cada replay
 * (rede()) — apagar um trecho tira o joelho junto.
 *
 * Convenção = a do viewer: metros, Y para cima. DN em milímetros.
 *
 * ⚠ SINAPI: o código de cada tubo/conexão/peça vem SÓ da tabela gerada
 *   (js/biminstsinapi.js, tools/gerar-biminst-sinapi.js), que só tem código
 *   que o MAPA (data/sinapi-familias-mapa.json) classificou como instalação
 *   e que está na base. Sem chave na tabela = "pendente", com o motivo —
 *   nunca a composição "parecida" (outro DN, outra aplicação, outro material).
 *
 * ⚠ CORES POR SISTEMA (convenção RA, documentada aqui e na tela):
 *   água fria AZUL · água quente VERMELHO · esgoto MARROM · ventilação
 *   marrom claro (família do esgoto) · pluvial VERDE · eletroduto AMARELO ·
 *   caixa elétrica LARANJA · duto de ar CINZA-AZULADO · frigorígeno CIANO ·
 *   dreno de condensado AZUL-CLARO · incêndio VERMELHO-ESCURO (IT 17 5.16.5) · fluido industrial MARROM-ESCURO.
 * ===================================================================== */
(function (global) {
  "use strict";

  function num(v, d) { var n = Number(v); return isFinite(n) ? n : d; }
  function r4(v) { return Math.round(v * 10000) / 10000; }
  function r2(v) { return Math.round(v * 100) / 100; }
  function txt(v) { return v == null ? "" : String(v); }
  function arr(a) { return Array.isArray(a) ? a : []; }
  function copia(o) { return JSON.parse(JSON.stringify(o)); }
  function dep(nome, arquivo) {
    if (global[nome]) return global[nome];
    if (typeof require === "function") { try { return require(arquivo); } catch (e) {} }
    return null;
  }

  /* ---------------------------------------------------------- SISTEMAS
   * gravidade: o tubo DESCE no sentido do traço (p1 → p2) pela inclinação.
   * grupo: que aplicações valem (água, esgoto, pluvial, elétrica, ar). */
  var SISTEMAS = {
    agua_fria:   { nome: "Água fria", abrev: "AF", cor: "#1E6FD9", grupo: "agua", gravidade: false, materiais: ["pvc_soldavel", "ppr", "cpvc", "cobre"], material: "pvc_soldavel" },
    agua_quente: { nome: "Água quente", abrev: "AQ", cor: "#D93025", grupo: "agua", gravidade: false, materiais: ["ppr", "cpvc", "cobre"], material: "ppr" },
    esgoto:      { nome: "Esgoto", abrev: "ES", cor: "#7B4A2A", grupo: "esgoto", gravidade: true, materiais: ["pvc_esgoto", "pvc_serie_r", "pvc_esgoto_enterrado"], material: "pvc_esgoto" },
    ventilacao:  { nome: "Ventilação", abrev: "VE", cor: "#B08A6E", grupo: "ventilacao", gravidade: false, materiais: ["pvc_esgoto", "pvc_serie_r"], material: "pvc_esgoto" },
    pluvial:     { nome: "Pluvial", abrev: "AP", cor: "#2E9E44", grupo: "pluvial", gravidade: true, materiais: ["pvc_serie_r", "pvc_esgoto", "pvc_esgoto_enterrado"], material: "pvc_serie_r" },   /* Casa 487 (F9): coletor pluvial enterrado acima do DN 150 da série R = PVC ocre NBR 7362 (DN 200) */
    eletrica:    { nome: "Elétrica (eletroduto)", abrev: "EL", cor: "#F2B600", grupo: "eletrica", gravidade: false, materiais: ["elet_corrugado_ref", "elet_corrugado", "elet_roscavel", "elet_soldavel"], material: "elet_corrugado_ref" },
    ar:          { nome: "Ar-condicionado (duto)", abrev: "AR", cor: "#7F95A8", grupo: "ar", gravidade: false, materiais: ["duto_chapa", "duto_flex"], material: "duto_chapa" },
    /* C1b climatização (17/10/2026, docs/hidro/PATCH-BIMINST-CLIMA.md): cobre frigorígeno e dreno de condensado.
       frigorigeno: as DUAS linhas (líquido e sucção) são trechos do MESMO sistema, com o campo "linha" ("liquido" | "succao");
       dreno: escoa por gravidade (p1 → p2 desce), ou recalcado pela bomba de dreno (aplicacao "bomba"). O duto de ar é o sistema "ar" (já existia). */
    frigorigeno: { nome: "Frigorígeno (cobre)", abrev: "FR", cor: "#0FA3A3", grupo: "frigorigeno", gravidade: false, materiais: ["cobre_frigorigeno"], material: "cobre_frigorigeno" },
    dreno:       { nome: "Dreno de condensado", abrev: "DR", cor: "#5DADE2", grupo: "dreno", gravidade: true, materiais: ["pvc_soldavel", "pvc_esgoto"], material: "pvc_soldavel" },
    /* F3 incêndio (17/10/2026, docs/hidro/PATCH-BIMINST-INCENDIO.md): rede de hidrantes/mangotinhos e de chuveiros automáticos.
       Tubulação aparente VERMELHA (IT 17 5.16.5), cor distinta do vermelho da água quente. Pressurizada: sem gravidade. */
    incendio:    { nome: "Incêndio (hidrantes e chuveiros)", abrev: "IN", cor: "#C62828", grupo: "incendio", gravidade: false, materiais: ["aco_galvanizado", "aco_preto", "cobre"], material: "aco_galvanizado" },
    /* Fase 5 industrial (17/10/2026, docs/hidro/PATCH-BIMINST-INDUSTRIAL.md): rede de fluido industrial (ar comprimido, vapor, condensado, óleo
       térmico, água gelada/industrial, gás). Um sistema só; o FLUIDO e a SÉRIE vão no trecho. Pressurizada. */
    industrial:  { nome: "Fluidos industriais", abrev: "IND", cor: "#6D4C41", grupo: "industrial", gravidade: false, materiais: ["aco_carbono", "inox", "cobre", "pead"], material: "aco_carbono" },
    /* F3 gás (27/10/2026, Casa 487): rede de GÁS COMBUSTÍVEL (GLP/GN) dimensionada pela NBR 15526 (js/hidgasrede.js). Trecho de cobre embutido, pressurizado.
       grupo "industrial": herda as aplicações (linha/ramal) e o resto do tratamento do tubo pressurizado sem editar as tabelas de outros sistemas.
       COR: o desenho usa AMARELO-ESCURO por legibilidade (sobre meio-tom cinza); a PINTURA da tubulação aparente (abrigo, ponto) segue a NBR 6493
       (gases liquefeitos = cor-de-alumínio; gás não liquefeito = amarelo-segurança) — fonte secundária, a conferir no exemplar licenciado. */
    gas:         { nome: "Gás combustível (GLP)", abrev: "GAS", cor: "#C9A400", grupo: "industrial", gravidade: false, materiais: ["cobre"], material: "cobre" },
    /* P12: a bandeja de cabos (eletrocalha) — cor OLIVA (família do amarelo da elétrica, mais escura) */
    bandeja:     { nome: "Eletrocalha (bandeja de cabos)", abrev: "EC", cor: "#8A7F1F", grupo: "bandeja", gravidade: false, materiais: ["eletrocalha"], material: "eletrocalha" }
  };
  var COR_CAIXA_ELETRICA = "#F57C00";
  /* PADRÃO DE APRESENTAÇÃO DE INSTALAÇÕES (17/10/2026, js/biminstpadrao.js): a cor, a pena e o tipo de linha de cada
     sistema vêm da convenção usual de mercado levantada em dados-fonte/hidro/apresentacao/padrao-instalacoes.json
     (js GERADO: js/biminstpadraodados.js). As cores escritas acima ficam só de RESERVA, para o motor não quebrar sem
     o arquivo gerado (o teste test-biminstpadrao confere que, com ele, cada sistema sai com a cor do padrão). */
  (function () {
    var PD = dep("BimInstPadraoDados", "./biminstpadraodados.js"), ps = PD && PD.sistemas;
    if (!ps) return;
    Object.keys(ps).forEach(function (k) {
      if (!SISTEMAS[k]) return;
      /* P8 (revisão da junção, 18/10/2026): a cor do PADRÃO só com a prévia ?previa=hidro — sem ela, a cor do master (a
         de reserva acima). Getter: a prévia é lida na hora (BimPrevia); no Node (sem BimPrevia) vale o padrão. */
      var reserva = SISTEMAS[k].cor, padrao = ps[k].cor;
      try {
        Object.defineProperty(SISTEMAS[k], "cor", { enumerable: true, configurable: true,
          get: function () { return previaHidro() ? padrao : reserva; },
          set: function (v) { if (v === padrao) return; padrao = v; reserva = v; } });   /* reaplicar o padrão (BimInstPadrao.aplicar) não apaga a cor do master */
      } catch (eDP) { SISTEMAS[k].cor = padrao; }
      SISTEMAS[k].linha = { pena: ps[k].pena, mm: ps[k].mm, padrao: ps[k].padrao };
    });
  })();
  /* P8 (revisão da junção, 18/10/2026, decisão da coordenação): o que mudou nas INSTALAÇÕES do BIM geral (cor do padrão,
     rótulo da planta, luva na ponta da conexão de esgoto) fica atrás da prévia ?previa=hidro. Sem BimPrevia (Node, testes
     dos motores) vale o comportamento novo. Lido no máximo a cada 250 ms (a cor é lida milhares de vezes por reconstrução). */
  var _ph = { t: -1e9, v: true };
  function previaHidro() {
    var P = global.BimPrevia; if (!P || typeof P.hidro !== "function") return true;
    var ag = Date.now(); if (ag - _ph.t < 250) return _ph.v;   // hid:ok intervalo de releitura da prévia (ms)
    var v = true; try { v = !!P.hidro(); } catch (e) { v = true; }
    _ph = { t: ag, v: v };
    return v;
  }

  /* ---------------------------------------------------------- MATERIAIS
   * dns = DIÂMETROS NOMINAIS COMERCIAIS (mm). FONTE: a norma do produto
   * (citada em cada um) e, para não haver DN sem composição, a SINAPI 06/2026
   * (data/sinapi-MG-analitico.json): tools/test-bim-b5.js reprova se um DN
   * desta tabela não tiver TUBO na SINAPI para aquele material. DN que a
   * norma tem e a SINAPI não (ex.: eletroduto DN 50) fica FORA da lista — sem
   * fonte de preço segura, não se oferece.
   * flexivel: curva no próprio tubo — não gera joelho nem luva.
   * secao 'retangular': o duto tem largura × altura (m) e é orçado em m². */
  var MATERIAIS = {
    pvc_soldavel: { nome: "PVC soldável (marrom)", norma: "ABNT NBR 5648", dns: [20, 25, 32, 40, 50, 60, 75, 85, 110], dn: 25 },
    pvc_esgoto:   { nome: "PVC esgoto série normal", norma: "ABNT NBR 5688", dns: [40, 50, 75, 100, 150], dn: 100 },
    pvc_serie_r:  { nome: "PVC série reforçada (R)", norma: "ABNT NBR 5688", dns: [40, 50, 75, 100, 150], dn: 100 },
    /* hidro (17/10/2026): PVC-U ocre de parede maciça para rede coletora e ramal predial ENTERRADOS, NBR 7362:2025 (cancela a 9063),
       Tabela 2 — DN 100 a 1000, SN ≥ 3,5/4,0 kN/m²; Di pelo HidNormas (materiais.diametro_interno). semSinapi: a base tem os INSUMOS
       "TUBO COLETOR DE ESGOTO PVC, JEI (NBR 7362)", mas nenhuma composição foi classificada no mapa (data/sinapi-familias-mapa.json)
       → pendente, nunca a parecida. */
    pvc_esgoto_enterrado: { nome: "PVC ocre enterrado (coletor/ramal predial)", norma: "ABNT NBR 7362:2025", dns: [100, 150, 200, 250, 300, 350, 400, 450, 500, 630, 710, 800, 900, 1000], dn: 150, semSinapi: true },
    ppr:          { nome: "PPR (polipropileno)", norma: "ABNT NBR 15813", dns: [20, 25, 32, 40, 50, 63, 75, 90, 110], dn: 25, pns: ["12", "20", "25"], pn: "25" },
    cpvc:         { nome: "CPVC", norma: "ABNT NBR 15884", dns: [15, 22, 28, 35, 42, 54, 73, 89, 114], dn: 22 },
    cobre:        { nome: "Cobre rígido", norma: "ABNT NBR 13206", dns: [15, 22, 28, 35, 42, 54, 66, 79, 104], dn: 22, classes: ["E", "A"], classe: "E", isos: ["sem", "com"], iso: "sem" },
    elet_corrugado_ref: { nome: "Eletroduto PVC flexível corrugado reforçado", norma: "ABNT NBR 15465", dns: [20, 25, 32], dn: 25, flexivel: true },
    elet_corrugado:     { nome: "Eletroduto PVC flexível corrugado", norma: "ABNT NBR 15465", dns: [20, 25, 32], dn: 25, flexivel: true },
    elet_roscavel:      { nome: "Eletroduto PVC rígido roscável", norma: "ABNT NBR 15465", dns: [20, 25, 32, 40], dn: 25 },
    elet_soldavel:      { nome: "Eletroduto PVC rígido soldável (aparente)", norma: "ABNT NBR 15465", dns: [20, 25, 32], dn: 25 },
    /* C1b: tubo de cobre recozido em rolo para refrigeração, medidas em POLEGADA convertidas a mm (catálogos Daikin, Springer Midea,
       Elgin e Gree: 1/4, 3/8, 1/2, 5/8, 3/4, 7/8). tolDn: o catálogo escreve 6,35/6,4 e 9,52/9,53/9,5 para a mesma bitola — o DN do trecho
       casa com a lista dentro de 0,1 mm. semSinapi: a SINAPI 06/2026 NÃO tem composição de tubo de cobre para refrigeração — pendente de
       propósito (nunca a parecida: o "cobre" de água, NBR 13206, é outro produto). A linha frigorígena é SEMPRE isolada. */
    cobre_frigorigeno: { nome: "Tubo de cobre para refrigeração (rolo)", norma: "ABNT NBR 7541", dns: [6.35, 9.52, 12.7, 15.88, 19.05, 22.22], dn: 9.52, tolDn: 0.1,
                         flexivel: true, semSinapi: true, isos: ["com"], iso: "com" },
    /* F3 incêndio: IT 17 5.16.13 — tubos de aço NBR 5580 / 5587 / 5590. semSinapi: nenhuma composição de tubo de aço de incêndio foi
       classificada no mapa (data/sinapi-familias-mapa.json): fica pendente de propósito, nunca a parecida. O DN mínimo (65; 50 em
       galvanizado e 54 em cobre só nos tipos 1 e 2, IT 17 5.16.1/5.16.2) quem verifica é o hidinc, não o biminst. */
    aco_galvanizado: { nome: "Aço galvanizado (incêndio)", norma: "ABNT NBR 5580", dns: [25, 32, 40, 50, 65, 80, 100, 125, 150], dn: 65, semSinapi: true },
    aco_preto:       { nome: "Aço carbono preto (incêndio)", norma: "ABNT NBR 5580 / 5590", dns: [25, 32, 40, 50, 65, 80, 100, 125, 150], dn: 65, semSinapi: true },
    /* Fase 5 industrial: DN e Di vêm do HidNormas (ind.tubo.<material>); aqui só o rótulo. semSinapi: nenhuma composição de tubo industrial
       foi classificada no mapa → pendente, nunca a parecida. */
    aco_carbono: { nome: "Aço carbono (ASME B36.10)", norma: "ASME B36.10 / ABNT NBR 5590", dns: [15, 20, 25, 32, 40, 50, 65, 80, 100, 125, 150, 200, 250, 300], dn: 50, semSinapi: true },
    inox:        { nome: "Aço inox (ASME B36.19)", norma: "ASME B36.19", dns: [15, 20, 25, 32, 40, 50, 65, 80, 100, 125, 150, 200, 250, 300], dn: 50, semSinapi: true },
    pead:        { nome: "PEAD PE 100", norma: "ABNT NBR 15561", dns: [20, 25, 32, 40, 63, 90, 110, 160, 180, 200, 225, 250, 280, 315], dn: 63, semSinapi: true },
    duto_chapa: { nome: "Duto retangular de chapa galvanizada", norma: "ABNT NBR 16401 / SMACNA", secao: "retangular", dns: [], dn: 0, bitolas: ["26", "24", "22"], bitola: "24", isos: ["sem", "colada"], iso: "sem" },
    duto_flex:  { nome: "Duto flexível circular de alumínio isolado", norma: "SINAPI 06/2026 (diâmetros 4\" a 14\")", dns: [109, 131, 161, 185, 209, 263, 314, 364], dn: 161, flexivel: true },
    /* P12: eletrocalha — orçada em METRO ("inclusive emenda e fixação"); as larguras e a
       altura única (50 mm) são as da SINAPI 06/2026. O "dn" do trecho é a LARGURA em mm
       (é o que decide redução e tê); fora da lista = aviso e pendente na SINAPI. */
    eletrocalha: { nome: "Eletrocalha lisa ou perfurada de aço galvanizado", norma: "SINAPI 06/2026 (larguras 50 a 800 mm, altura 50 mm)", secao: "retangular", unidadeQto: "m",
                   dns: [], dn: 0, larguras: [50, 75, 100, 125, 150, 200, 250, 300, 400, 500, 600, 700, 800], alturas: [50], larg: 0.10, alt: 0.05 }
  };

  /* --------------------------------------------------------- APLICAÇÕES
   * O que a SINAPI separa: o mesmo tubo de 25 mm tem composição diferente em
   * ramal, em ramal de distribuição, em prumada e em reservação (o rendimento
   * da mão de obra muda). A automática: vertical = prumada (ou parede, no
   * eletroduto); horizontal = ramal (ou laje). O usuário troca.
   * ramal_ventilacao NÃO EXISTE na SINAPI 06/2026: fica pendente de propósito
   * (orçar com a composição de ramal de ESGOTO seria escolher "a parecida"). */
  var APLICACOES = {
    agua:       { ramal: "Ramal ou sub-ramal", distribuicao: "Ramal de distribuição", prumada: "Prumada", reservacao: "Reservação (barrilete)" },
    esgoto:     { ramal: "Ramal de descarga / de esgoto", prumada: "Tubo de queda (prumada)", subcoletor: "Subcoletor aéreo" },
    ventilacao: { prumada: "Coluna de ventilação", ramal_ventilacao: "Ramal de ventilação" },
    pluvial:    { ramal: "Condutor horizontal (ramal)", prumada: "Condutor vertical" },
    eletrica:   { laje: "Embutido na laje", parede: "Embutido na parede", forro: "Sobre o forro", aparente: "Aparente", piso: "Embutido no piso" },   /* piso: a alimentação da ligação elétrica "pelo piso" (js/eletilum.js) */
    ar:         { ar: "Rede de ar-condicionado" },
    frigorigeno: { parede: "Embutido na parede", forro: "Sobre o forro", laje: "Embutido na laje", aparente: "Aparente (canaleta)" },
    dreno:       { parede: "Embutido na parede", forro: "Sobre o forro", laje: "Embutido na laje", aparente: "Aparente", bomba: "Recalcado (bomba de dreno)" },
    industrial: { linha: "Linha de distribuição", ramal: "Ramal de consumo", dreno: "Dreno / condensado", suspiro: "Suspiro / alívio" },
    incendio:   { prumada: "Prumada (coluna de incêndio)", ramal: "Ramal / barrilete", chuveiros: "Rede de chuveiros (subramais)" },
    bandeja:    { bandeja: "Bandeja de cabos" }
  };

  /* -------------------------------------------- INCLINAÇÃO MÍNIMA (%)
   * Esgoto, ABNT NBR 8160:1999: 2% até DN 75 e 1% a partir de DN 100.
   * Pluvial, ABNT NBR 10844:1989: condutor horizontal com no mínimo 0,5%.
   * É o valor que o traço sugere e abaixo do qual o trecho leva AVISO —
   * quem decide o projeto é o engenheiro. */
  function inclinacaoMinima(sistema, dn) {
    /* C1b: o dreno de condensado NÃO tem número escrito aqui — vem do HidNormas (cl.dreno.inclinacao_minima); sem a chave, 0 (o ClimRede.dreno verifica e diz "pendente") */
    if (sistema === "dreno") { var HN = dep("HidNormas", "./hidnormas.js"), vd = null; try { vd = HN && HN.valor ? HN.valor("cl.dreno.inclinacao_minima") : null; } catch (eN) { vd = null; } return vd == null || !isFinite(Number(vd)) ? 0 : Number(vd); }
    if (sistema === "esgoto") return num(dn, 100) <= 75 ? 2 : 1;
    if (sistema === "pluvial") return 0.5;
    return 0;
  }
  /* a inclinação está ABAIXO DA MÍNIMA? A comparação é ≥ NO ARREDONDAMENTO EM QUE ELA É MOSTRADA (o rótulo da planta e o
     Verificar sistemas: 1 casa, "i=1,0%"). Print 11 do Rogério (17/10/2026): "ø100 i=1,0%" saía VERMELHO num trecho e verde
     no outro, "ø50 i=2,0%" vermelho — o traço tinha 0,9996 % (cota arredondada a 0,1 mm) e a regra comparava o número cru
     com 1 − 1e-6. O que aparece como 1,0 % não pode estar abaixo de 1 %: uma regra só para o rótulo, o aviso do trecho e
     o filtro de aviso. casas = as do rótulo (padrão 1). */
  var CASAS_INCLINACAO = 1;
  function abaixoDaMinima(sistema, dn, inclinacao, casas) {
    if (inclinacao == null || !isFinite(+inclinacao)) return false;
    var im = inclinacaoMinima(sistema, dn); if (!(im > 0)) return false;
    var f = Math.pow(10, casas == null ? CASAS_INCLINACAO : casas);
    return Math.round(+inclinacao * f + 1e-9) / f < im - 1e-9;
  }

  /* ---------------------------------------------------------------- PEÇAS
   * Ralos e caixas: peças com ponto de LIGAÇÃO (hub): um cilindro vertical
   * de captura — o tubo que termina dentro dele está ligado, sem conexão a
   * mais (a peça tem as entradas e a saída dela). Medidas = as da descrição
   * SINAPI (4" = 101,6 mm). */
  var PECAS = {
    ralo_sifonado:  { nome: "Ralo sifonado", sistemas: ["esgoto", "pluvial"], dns: ["100x40"], dn: "100x40", material: "pvc", ifc: "IFCWASTETERMINAL", forma: "cil", r: 0.05, h: 0.12, prof: 0.45, captura: 0.09 },
    ralo_seco:      { nome: "Ralo seco", sistemas: ["esgoto"], dns: ["100x40"], dn: "100x40", material: "pvc", ifc: "IFCWASTETERMINAL", forma: "cil", r: 0.05, h: 0.12, prof: 0.45, captura: 0.09 },
    caixa_sifonada: { nome: "Caixa sifonada", sistemas: ["esgoto", "pluvial"], dns: ["100x100x50", "150x185x75"], dn: "150x185x75", material: "pvc", ifc: "IFCWASTETERMINAL", forma: "cil", r: 0.075, h: 0.185, prof: 0.6, captura: 0.12 },
    caixa_4x2:      { nome: "Caixa 4×2 (parede)", sistemas: ["eletrica"], dns: ["-"], dn: "-", material: "pvc", materiais: ["pvc", "metalica"], ifc: "IFCJUNCTIONBOX", forma: "caixa", w: 0.1016, hh: 0.0508, d: 0.05, captura: 0.08 },
    caixa_4x4:      { nome: "Caixa 4×4 (parede)", sistemas: ["eletrica"], dns: ["-"], dn: "-", material: "pvc", materiais: ["pvc", "metalica"], ifc: "IFCJUNCTIONBOX", forma: "caixa", w: 0.1016, hh: 0.1016, d: 0.05, captura: 0.09 },
    caixa_octogonal:{ nome: "Caixa octogonal 4×4 (laje)", sistemas: ["eletrica"], dns: ["-"], dn: "-", material: "pvc", materiais: ["pvc", "metalica"], ifc: "IFCJUNCTIONBOX", forma: "cil", r: 0.0508, h: 0.05, prof: 0.0, captura: 0.09 },
    /* F3 incêndio: medidas de DESENHO (símbolo no 3D), não de projeto — o abrigo real sai da família/catálogo; o extintor não se liga a tubo.
       Sem composição SINAPI no mapa → pendente (peça com semTabela, ver itemPeca). */
    hidrante_abrigo:     { nome: "Hidrante com abrigo", sistemas: ["incendio"], dns: ["65"], dn: "65", material: "aco", ifc: "IFCFIRESUPPRESSIONTERMINAL", forma: "caixa", w: 0.75, hh: 0.90, d: 0.30, captura: 0.20, semSinapi: true },
    extintor:            { nome: "Extintor portátil", sistemas: ["incendio"], dns: ["-"], dn: "-", material: "aco", ifc: "IFCFIRESUPPRESSIONTERMINAL", forma: "cil", r: 0.09, h: 0.55, prof: 0, captura: 0, semSinapi: true },
    chuveiro_automatico: { nome: "Chuveiro automático (sprinkler)", sistemas: ["incendio"], dns: ["15", "20"], dn: "15", material: "latao", ifc: "IFCFIRESUPPRESSIONTERMINAL", forma: "cil", r: 0.03, h: 0.06, prof: 0, captura: 0.04, semSinapi: true },
    /* Fase 5 industrial: medidas de DESENHO (símbolo no 3D), não de projeto; a lira real é o balanço (perna_m) da op sobre o tubo. */
    lira_expansao:    { nome: "Lira de dilatação (U)", sistemas: ["industrial"], dns: ["*"], dn: "*", material: "aco", ifc: "IFCPIPEFITTING", forma: "caixa", w: 1, hh: 1, d: 0.1, captura: 0.05, semSinapi: true },
    purgador:         { nome: "Purgador de vapor", sistemas: ["industrial"], dns: ["15", "20", "25"], dn: "15", material: "aco", ifc: "IFCVALVE", forma: "caixa", w: 0.12, hh: 0.10, d: 0.10, captura: 0.05, semSinapi: true },
    valvula_bloqueio: { nome: "Válvula de bloqueio", sistemas: ["industrial"], dns: ["*"], dn: "*", material: "aco", ifc: "IFCVALVE", forma: "caixa", w: 0.15, hh: 0.15, d: 0.10, captura: 0.05, semSinapi: true },
    reservatorio_ar:  { nome: "Reservatório de ar comprimido", sistemas: ["industrial"], dns: ["*"], dn: "*", material: "aco", ifc: "IFCTANK", forma: "cil", r: 0.30, h: 1.40, prof: 0, captura: 0.10, semSinapi: true },
    /* TERMINAL DE VENTILAÇÃO (js/hidambiente.js + js/hidventgeo.js, 18/10/2026): o produto da ficha (Amanco 11849 / Tigre
       59502719 no DN 50) no topo da coluna de ventilação — y = o topo do tubo, que entra na bolsa (prof = a bolsa, C da ficha);
       r = metade do chapéu (B). A ponta do tubo dentro da bolsa liga na peça (não é ponta solta) */
    terminal_ventilacao: { nome: "Terminal de ventilação", sistemas: ["ventilacao"], dns: ["50", "75", "100"], dn: "50", material: "pvc_esgoto", ifc: "IFCPIPEFITTING", forma: "cil", r: 0.033, h: 0.069, prof: 0.031, captura: 0.04 },   /* SINAPI 104348/104351/104356 (tools/gerar-biminst-sinapi.js SUBSTITUTOS, 20/10/2026) */
    /* PROJETO INTELIGENTE (js/hidrede.js + js/hidcigeo.js): CAIXA DE INSPEÇÃO da rede enterrada = o PRODUTO da ficha (corpo PVC
       DN300 + prolongadores + tampa com porta-tampa; a forma sai do js/hidcigeo.js). r = metade do Ø do CORPO da ficha (Amanco
       Wavin FTC000003 p.9, A = 332 mm — test-hid-ci confere contra os dados gerados); a PROFUNDIDADE é da instância (profVariavel:
       a op leva `prof`, do tampo ao fundo). ⚠ A NBR 8160 pede caixa cilíndrica de Ø interno ≥ 0,60 m: o js/hidrede.js deixa a
       PENDÊNCIA rede.caixa_diametro (DN300 = peça de inspeção). Sem composição SINAPI mapeada: pendente. */
    /* PENDÊNCIAS FINAIS (18/10/2026): o PADRÃO passou a ser a CAIXA DE 0,60 m (tipoCaixa "alvenaria" — tijolo maciço — ou
       "premoldado", tampa "concreto" ou "ferro"; dn "600"), com a composição SINAPI real pela profundidade e o 3D da caixa dela
       (js/hidcigeo.js + js/hidcidados.js). O produto de PVC DN300 ficou como DISPOSITIVO de inspeção (tipoCaixa "pvc300", dn
       "300"): a 8160 só o aceita fora da rede enterrada — na enterrada, o js/hides.js reprova com o Corrigir. */
    /* N23 (25/10/2026): também no PLUVIAL enterrado — a caixa de areia de ALVENARIA (0,60 m, profundidade da instância) na mudança de
       direção da linha enterrada (NBR 10844 5.7.4; o js/hidap.js conta caixa_inspecao como dispositivo de inspeção). A caixa de areia de
       PVC DN300 (hid-caixa-areia) tem a entrada no topo: em série, a 2ª ficaria 0,42 m abaixo do terreno, sem tampa à vista. */
    caixa_inspecao:      { nome: "Caixa de inspeção", sistemas: ["esgoto", "pluvial"], dns: ["600", "300"], dn: "600", material: "pvc_esgoto", ifc: "IFCDISTRIBUTIONCHAMBERELEMENT", forma: "cil", r: 0.30, h: 0.06, prof: 0.60, captura: 0.28, profVariavel: true,
                           tipos: { alvenaria: "Caixa de alvenaria 0,60 m (tijolo maciço)", premoldado: "Caixa pré-moldada de concreto 0,60 m", pvc300: "Dispositivo de inspeção de PVC Ø 300 (só fora da rede enterrada)" },
                           tampas: { concreto: "Tampa de concreto", ferro: "Tampa de ferro fundido" } },
    registro_recalque:   { nome: "Registro de recalque (passeio)", sistemas: ["incendio"], dns: ["65"], dn: "65", material: "aco", ifc: "IFCVALVE", forma: "caixa", w: 0.40, hh: 0.40, d: 0.30, captura: 0.15, semSinapi: true }
  };
  /* caixa de parede: a SINAPI separa ALTA (2,00 m do piso), MÉDIA (1,30 m) e
     BAIXA (0,30 m) — vale a mais próxima da altura em que a caixa foi posta */
  var ALTURAS_CAIXA = { baixa: 0.30, media: 1.30, alta: 2.00 };
  function alturaCaixa(alturaPiso) {
    var a = num(alturaPiso, 0.30), melhor = "baixa", d0 = Infinity;
    Object.keys(ALTURAS_CAIXA).forEach(function (k) { var d = Math.abs(ALTURAS_CAIXA[k] - a); if (d < d0) { d0 = d; melhor = k; } });
    return melhor;
  }

  var NOMES_CONEXAO = { joelho90: "Joelho 90°", joelho45: "Joelho 45°", te: "Tê", te_reducao: "Tê de redução", juncao: "Junção simples", luva: "Luva", reducao: "Redução", cruzeta: "Cruzeta",
                        uniao: "União", te_inspecao: "Tê de inspeção",
                        /* 27/10/2026 (frente 1b): os tipos do catálogo dos fabricantes que o motor passa a deduzir ou a reconhecer (js/biminstportas.js
                           tem as portas de cada um) */
                        curva90: "Curva 90° longa", curva90_curta: "Curva 90° curta", curva45: "Curva 45° longa", curva45_curta: "Curva 45° curta",
                        curva_pe_coluna: "Curva de pé de coluna", curva_transposicao: "Curva de transposição",
                        joelho90_reducao: "Joelho 90° de redução", joelho90_bolsa_curta: "Joelho 90° com bolsa curta", joelho90_anel_labial: "Joelho 90° com anel labial",
                        joelho90_az_anel: "Joelho 90° com anel de vedação", joelho90_visita: "Joelho 90° com visita", joelho45_misto: "Joelho 45° misto",
                        te_bucha: "Tê com bucha de latão", te_rosca: "Tê com rosca", te_transicao: "Tê de transição",
                        juncao_reducao: "Junção de redução", juncao_dupla: "Junção dupla", juncao_invertida: "Junção invertida",
                        luva_correr: "Luva de correr", luva_reducao: "Luva de redução", luva_rosca: "Luva com rosca", luva_bucha: "Luva com bucha de latão",
                        uniao_mista: "União mista", uniao_flangeada: "União flangeada", transicao: "Peça de transição",
                        adaptador: "Adaptador soldável curto", adaptador_caixa: "Adaptador para caixa d'água (flange)", adaptador_anel_labial: "Adaptador com anel labial",
                        bucha: "Bucha de redução", bucha_longa: "Bucha de redução longa", joelho_bucha: "Joelho 90° com bucha de latão", joelho_rosca: "Joelho 90° com rosca",
                        cap: "Cap", plug: "Plug", terminal_ventilacao: "Terminal de ventilação" };
  /* PENDÊNCIAS FINAIS (18/10/2026): a PEÇA EM LINHA escolhida pelo projetista num nó de dois tubos alinhados e de mesmo
     DN (no lugar da luva que a rede deduziria): a UNIÃO (água: desmontar sem cortar — bomba, aquecedor, hidrômetro) e o
     TÊ DE INSPEÇÃO (esgoto/pluvial/ventilação aparente: NBR 8160 4.2.5.5, "tubulação aparente … com inspeção"). Grava-se
     na PONTA do trecho (pecaIni em p1, pecaFim em p2); o nó vira a peça se algum ramo dele a pede. */
  var PECAS_LINHA = { uniao: ["agua"], te_inspecao: ["esgoto", "ventilacao", "pluvial"] };
  /* a peça em linha só nos materiais que a fabricam e, no tê de inspeção, só nos DN que EXISTEM (decisão da coordenação,
     18/10/2026, noite: o DN 50 não existe nas linhas Tigre/Amanco/Krona): a cota da ficha (js/biminstgeodados.js), uma
     composição SINAPI da peça ou uma referência de mercado — nada disso, o nó fica com a luva e o aviso */
  /* ===== FRENTE 3 (27/10/2026) — CONEXÃO MANUAL: bloco isolado ===================================================================
     O projetista clica num NÓ (Componentes > Conexão manual) e escolhe um tipo de HidPortas; fica gravado como peça FORÇADA na ponta do trecho
     (pecaIni/pecaFim, o mesmo campo da união/tê de inspeção, agora aceitando qualquer tipo). decidir() a honra SE ela serve ao nó
     (nº de bocas, deflexão e DN no catálogo do material — conferirPortas e conexaoNoCatalogo); senão mantém a dedução e avisa o porquê. */
  var GRUPOS_FORCA = { agua: 1, esgoto: 1, ventilacao: 1, pluvial: 1 };
  function tipoForcavel(tipo, grupo) {
    var HP = dep("HidPortas", "./biminstportas.js");
    return typeof tipo === "string" && !!GRUPOS_FORCA[grupo] && !!HP && !!HP.info(tipo);
  }
  var PECAS_LINHA_MAT = { uniao: { pvc_soldavel: 1, cpvc: 1 }, te_inspecao: { pvc_esgoto: 1, pvc_serie_r: 1 } };
  function pecaLinhaExiste(tipo, material, dn) {
    if (!PECAS_LINHA_MAT[tipo] || !PECAS_LINHA_MAT[tipo][material]) return false;
    if (tipo !== "te_inspecao") return true;
    var GD = dep("HidGeoDados", "./biminstgeodados.js"), T = tabela(), k = txt(dn);
    if (GD && GD.conexoes && GD.conexoes[material] && GD.conexoes[material].te_inspecao && GD.conexoes[material].te_inspecao[k]) return true;
    if (T && T.chaves && Object.keys(T.chaves).some(function (c) { var p = c.split("|"); return p[0] === "te_inspecao" && p[1] === material && p[3] === k; })) return true;
    var PM = global.HidPrecoMercado || null;
    return !!(PM && PM.ref && material === "pvc_esgoto" && PM.ref("te_inspecao_esgoto|" + k));
  }
  function nomeConexao(tipo, material) {
    if (material === "eletrocalha") return { joelho90: "Curva 90° de eletrocalha", te: "Tê 90° de eletrocalha", reducao: "Redução de eletrocalha" }[tipo] || (NOMES_CONEXAO[tipo] || tipo) + " de eletrocalha";   /* P12 */
    if (/^elet_/.test(material || "") && (tipo === "joelho90" || tipo === "joelho45")) return tipo === "joelho90" ? "Curva 90°" : "Curva 135° (desvio de 45°)";
    /* a redução do ESGOTO e do PLUVIAL é a EXCÊNTRICA (geratriz superior alinhada — regra RA de 20/10/2026, js/biminstgeo.js); na água fica "Redução" */
    if (tipo === "reducao" && (material === "pvc_esgoto" || material === "pvc_serie_r" || material === "pvc_esgoto_enterrado")) return "Redução excêntrica";
    return NOMES_CONEXAO[tipo] || tipo;
  }

  /* ================================================================ TRECHO */
  var TOL = 0.02;            /* 2 cm: pontas mais perto que isto são o MESMO nó */
  var FACE_TOL = 0.01;       /* 1 cm: ponto de ligação a menos disto da face de trás do aparelho é ponto de PAREDE */
  var SOBE_TOMADA = 0.7;     /* bim:geo a ventilação sai do esgoto PARA CIMA (componente vertical da direção ≥ cos 45°) */
  var EPS_FLUXO = 1e-4;      /* bim:geo diferença de inclinação que já diz quem desce (m/m) */
  var TOL_CONECTOR = 0.03;   /* ponto de ligação de aparelho */

  function pt(p) { return p && isFinite(Number(p.x)) && isFinite(Number(p.y)) && isFinite(Number(p.z)) ? { x: Number(p.x), y: Number(p.y), z: Number(p.z) } : null; }
  function dist(a, b) { var dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z; return Math.sqrt(dx * dx + dy * dy + dz * dz); }

  /* a geometria de um trecho reto: comprimento REAL (no eixo, com a
     inclinação), comprimento em planta, desnível (p1 − p2: positivo = desce
     no sentido do traço) e a inclinação em % sobre o comprimento em planta */
  function geometria(p1, p2) {
    var dx = p2.x - p1.x, dy = p2.y - p1.y, dz = p2.z - p1.z;
    var L = Math.sqrt(dx * dx + dy * dy + dz * dz), Lh = Math.sqrt(dx * dx + dz * dz);
    return { comprimento: L, comprimentoH: Lh, desnivel: p1.y - p2.y,
             inclinacao: Lh > 1e-6 ? (p1.y - p2.y) / Lh * 100 : null,
             vertical: L > 0 && Lh <= 0.05 * L };
  }

  function grupoDe(sistema) { return (SISTEMAS[sistema] || {}).grupo || ""; }
  function aplicacaoAuto(sistema, vertical) {
    var g = grupoDe(sistema);
    if (g === "agua") return vertical ? "prumada" : "ramal";
    if (g === "esgoto") return vertical ? "prumada" : "ramal";
    if (g === "ventilacao") return vertical ? "prumada" : "ramal_ventilacao";
    if (g === "pluvial") return vertical ? "prumada" : "ramal";
    if (g === "eletrica") return vertical ? "parede" : "laje";
    if (g === "ar") return "ar";
    if (g === "incendio") return vertical ? "prumada" : "ramal";
    if (g === "industrial") return vertical ? "ramal" : "linha";
    if (g === "frigorigeno" || g === "dreno") return vertical ? "parede" : "forro";
    if (g === "bandeja") return "bandeja";
    return "";
  }

  /* normaliza um trecho (op ou estado): devolve null se não serve */
  /* distância de um ponto ao segmento a–b (m), em 3D (N23: o passante está no tubo?) */
  function distSeg(q, a, b) {
    var ux = b.x - a.x, uy = b.y - a.y, uz = b.z - a.z, L2 = ux * ux + uy * uy + uz * uz;
    var s = L2 > 0 ? ((num(q.x, 0) - a.x) * ux + (num(q.y, 0) - a.y) * uy + (num(q.z, 0) - a.z) * uz) / L2 : 0; s = Math.max(0, Math.min(1, s));
    var dx = a.x + ux * s - num(q.x, 0), dy = a.y + uy * s - num(q.y, 0), dz = a.z + uz * s - num(q.z, 0);
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }
  function normTrecho(o) {
    var p1 = pt(o.p1), p2 = pt(o.p2), s = SISTEMAS[o.sistema];
    if (!p1 || !p2 || !s) return null;
    var mat = s.materiais.indexOf(o.material) >= 0 ? o.material : s.material, M = MATERIAIS[mat];
    var g = geometria(p1, p2);
    if (!(g.comprimento > 0.005)) return null;
    var t = { id: o.id, sistema: o.sistema, material: mat, p1: p1, p2: p2 };
    if (M.secao === "retangular") {
      t.larg = num(o.larg, M.larg || 0.40); t.alt = num(o.alt, M.alt || 0.25);
      if (!(t.larg > 0.02) || !(t.alt > 0.02)) return null;
      t.dn = 0;
      if (M.bitolas) { t.bitola = M.bitolas.indexOf(txt(o.bitola)) >= 0 ? txt(o.bitola) : M.bitola; t.iso = M.isos.indexOf(txt(o.iso)) >= 0 ? txt(o.iso) : M.iso; }
      if (M.larguras) t.dn = Math.round(t.larg * 1000);   /* P12: eletrocalha — a largura em mm faz as vezes de DN */
    } else {
      var dn = num(o.dn, M.dn);
      if (!(dn > 0)) return null;
      if (M.tolDn) for (var iD = 0; iD < M.dns.length; iD++) if (Math.abs(M.dns[iD] - dn) <= M.tolDn) { dn = M.dns[iD]; break; }   /* C1b: 9,53 do catálogo = 9,52 da lista */
      t.dn = dn;                          /* DN fora da lista comercial NÃO é recusado: fica com aviso e pendente na SINAPI */
    }
    if (M.pns) t.pn = M.pns.indexOf(txt(o.pn)) >= 0 ? txt(o.pn) : M.pn;
    if (M.classes) t.classe = M.classes.indexOf(txt(o.classe)) >= 0 ? txt(o.classe) : M.classe;
    if (M.isos && !M.secao) t.iso = M.isos.indexOf(txt(o.iso)) >= 0 ? txt(o.iso) : M.iso;
    if (o.serie != null && o.serie !== "") t.serie = txt(o.serie);   /* fase 5: série do tubo industrial ("40", "80", "10S", "SDR11") */
    if (o.linha === "liquido" || o.linha === "succao") t.linha = o.linha;   /* C1b: qual das duas linhas frigorígenas */
    /* QUALIDADE VISUAL 2: a ponta que CONTINUA fora do que está modelado (a prumada que segue para o pavimento de
       cima/baixo, o ramal que sai para a rede pública) — declarada pelo projetista, não é ponta solta */
    if (o.continua === "p1" || o.continua === "p2" || o.continua === "ambos") t.continua = o.continua;
    /* REVISÃO H5 (21/10/2026): o trecho de água quente que corre FORA do ambiente aquecido (o entreforro do js/hidaqtraco.js) leva o
       ISOLAMENTO TÉRMICO (NBR 5626:2020 6.12.3) — vai ao levantamento (ISOLAMENTO_AQ) */
    if (o.isolamento === true && o.sistema === "agua_quente") t.isolamento = true;
    /* N23 EMBUTIDO (26/10/2026): o tubo APARENTE por escolha (a opção "Instalação aparente" do aparelho/ambiente — área técnica, reforma):
       o auditor não o acusa de "aparente sem motivo" (js/biminstembutido.js) */
    if (o.aparente === true) t.aparente = true;
    /* N23 (24/10/2026): os PASSANTES que o traçado lançou onde o tubo atravessa uma laje (HidCriterios.lancarPassantes) — a laje e o
       ponto da travessia; vão ao levantamento (PASSANTE_LAJE) e o auditor aceita a travessia com eles. Lista de objetos (a nuvem aceita) */
    if (Array.isArray(o.passantes) && o.passantes.length) {
      var psL = o.passantes.filter(function (q) { return q && q.laje != null && q.laje !== "" && isFinite(num(q.x, NaN)) && isFinite(num(q.z, NaN)); }).slice(0, 12)   // hid:ok até 12 lajes por tubo
        .map(function (q) { return { laje: txt(q.laje).slice(0, 80), x: r4(num(q.x, 0)), y: r4(num(q.y, 0)), z: r4(num(q.z, 0)) }; })
        /* ⚠ só o passante que está NO tubo: o registro que divide o trecho copia os campos para a metade "b" (o passante ia aos dois
           pedaços — orçado em dobro) e o tubo movido deixa de passar no furo (sai do orçamento e o alerta volta) */
        .filter(function (q) { return t.p1 && t.p2 && distSeg(q, t.p1, t.p2) <= num(t.dn, 0) / 2000 + TOL; });   // hid:ok DN mm → raio em m
      if (psL.length) t.passantes = psL;
    }
    /* CONECTIVIDADE (frente A, 19/10/2026): a tomada da ventilação diz em QUAL tubo de esgoto ela liga (o tê só nele); as esperas de
       projeto do prédio e da piscina ficam marcadas (a R-E2 as permite: viram pendência no motor delas) */
    if (o.tomada != null && o.tomada !== "" && t.continua) t.tomada = txt(o.tomada).slice(0, 120);
    if (t.continua && o.predio != null && o.predio !== "") t.predio = txt(o.predio).slice(0, 120);
    if (t.continua && o.piscLinha != null && o.piscLinha !== "") t.piscLinha = txt(o.piscLinha).slice(0, 120);
    /* FRENTE H8 (21/10/2026): as SAÍDAS LIVRES da caixa d'água (js/hidbarrilete.js) — extravasor e limpeza (descarga livre e visível),
       a ventilação do barrilete, a espera do alimentador da boia e o respiro do boiler: extremidade aberta que a R-E2 permite */
    if (t.continua && o.saidaLivre != null && o.saidaLivre !== "") t.saidaLivre = txt(o.saidaLivre).slice(0, 120);
    /* QUALIDADE VISUAL 1 (juntas, 17/10/2026): como esta ponta do tubo encontra a PONTA de uma conexão de esgoto —
       "luva" (padrão: luva de verdade, no quantitativo), "bolsa" (a bolsa do próprio tubo) ou "invertida" (luva contra
       o fluxo: aviso com o motivo). Ausente = luva. juntaIni vale para p1, juntaFim para p2. */
    if (JUNTAS[o.juntaIni]) t.juntaIni = o.juntaIni;
    /* REDUÇÃO EXCÊNTRICA de esgoto (paridade, 18/10/2026): no trecho de JUSANTE (o DN maior), a geratriz reta — "superior"
       (padrão, ausente) ou "inferior" (o projetista girou com Espaço) */
    if (o.excentrica === "inferior" || o.excentrica === "superior") t.excentrica = o.excentrica;
    if (JUNTAS[o.juntaFim]) t.juntaFim = o.juntaFim;
    if (o.juntaMotivo) t.juntaMotivo = txt(o.juntaMotivo).slice(0, 200);
    /* PENDÊNCIAS FINAIS: a peça em linha na ponta (união / tê de inspeção), só no grupo de sistema que a usa */
    ["pecaIni", "pecaFim"].forEach(function (kp) { var pl = PECAS_LINHA[o[kp]]; if (pl && pl.indexOf(s.grupo) >= 0) t[kp] = o[kp]; else if (!pl && tipoForcavel(o[kp], s.grupo)) t[kp] = o[kp]; });   /* frente 3: conexão manual (qualquer tipo de HidPortas) */
    camposObra(o, t);   /* FLUIDEZ: comentários e fase da instância */
    if (s.grupo === "esgoto" && (o.redeParte === "coletor" || o.redeParte === "saida")) t.redeParte = o.redeParte;   /* o coletor e a saída da rede externa (js/hidrede.js): o HidES os trata como coletor mesmo sem tubo de queda */
    var apls = APLICACOES[s.grupo] || {};
    t.aplicacaoAuto = !(o.aplicacao && apls[o.aplicacao]);
    t.aplicacao = t.aplicacaoAuto ? aplicacaoAuto(o.sistema, g.vertical) : o.aplicacao;
    t.comprimento = r4(g.comprimento); t.comprimentoH = r4(g.comprimentoH); t.desnivel = r4(g.desnivel);
    t.inclinacao = g.inclinacao == null ? null : r4(g.inclinacao); t.vertical = g.vertical;
    t.diametro = M.secao === "retangular" ? 0 : t.dn / 1000;     /* m, para o desenho */
    t.avisos = [];
    if (o.dnPendente) t.avisos.push("DN pendente: o catálogo/dimensionamento não deu o diâmetro; usado o padrão do material (DN " + t.dn + "), conferir");   /* C1b */
    if (M.larguras && (M.larguras.indexOf(t.dn) < 0 || M.alturas.indexOf(Math.round(t.alt * 1000)) < 0)) t.avisos.push("eletrocalha " + Math.round(t.larg * 1000) + " × " + Math.round(t.alt * 1000) + " mm fora das medidas da SINAPI (largura " + M.larguras.join(", ") + " mm; altura " + M.alturas.join(", ") + " mm): pendente");
    if (!M.secao && M.dns.indexOf(t.dn) < 0) t.avisos.push("DN " + t.dn + " não é bitola comercial de " + M.nome + " (" + M.dns.join(", ") + ")");
    if (s.gravidade && !g.vertical) {
      var im = inclinacaoMinima(o.sistema, t.dn);
      if (t.inclinacao < -1e-6) t.avisos.push("o trecho SOBE no sentido do escoamento (" + fmtPct(-t.inclinacao) + "): esgoto e pluvial descem de p1 para p2");
      else if (abaixoDaMinima(o.sistema, t.dn, t.inclinacao)) t.avisos.push("inclinação " + fmtPct(t.inclinacao) + " abaixo da mínima de " + fmtPct(im) + " (" + (o.sistema === "esgoto" ? "NBR 8160" : (o.sistema === "dreno" ? "norma do dreno de condensado (HidNormas)" : "NBR 10844")) + ")");
    }
    /* ramal de ventilação: a SINAPI não separa — a composição da aplicação irmã de maior custo, com a observação no item (tools/gerar-biminst-sinapi.js IRMAS, 20/10/2026); o aviso "fica pendente" saiu */
    return t;
  }
  function fmtPct(v) { return String(r2(v)).replace(".", ",") + "%"; }

  /* ------------------------------------------------------------- TRAÇAR
   * pontos (cliques em planta: {x, z}) → pontos 3D com a cota de cada um.
   * Sistema por gravidade: cada ponto desce inclinacao% do comprimento em
   * PLANTA desde o anterior; a última cota é a COTA DE SAÍDA. Os outros
   * ficam na cota inicial (horizontal). */
  function tracar(pontos, o) {
    o = o || {};
    var y = num(o.cotaInicial, 0), i = num(o.inclinacao, 0) / 100, out = [], trechos = [], Ltot = 0;
    arr(pontos).forEach(function (p, k) {
      var q = { x: num(p.x, 0), z: num(p.z, 0), y: y };
      if (k > 0) {
        var a = out[k - 1], Lh = Math.sqrt((q.x - a.x) * (q.x - a.x) + (q.z - a.z) * (q.z - a.z));
        y = a.y - i * Lh; q.y = r4(y);
        var L = Math.sqrt(Lh * Lh + (a.y - q.y) * (a.y - q.y));
        trechos.push({ p1: a, p2: q, comprimento: r4(L), comprimentoH: r4(Lh), desnivel: r4(a.y - q.y) });
        Ltot += L;
      } else q.y = r4(y);
      out.push(q);
    });
    return { pontos: out, trechos: trechos, cotaInicial: r4(num(o.cotaInicial, 0)), cotaSaida: out.length ? out[out.length - 1].y : r4(num(o.cotaInicial, 0)),
             desnivel: out.length ? r4(out[0].y - out[out.length - 1].y) : 0, comprimento: r4(Ltot) };
  }

  /* ------------------------------------------------------------- PEÇA */
  /* FLUIDEZ — PROPRIEDADES COMPLETAS (17/10/2026): comentários e fase da instância (tubo e peça), editados em
     Propriedades por instAlterar (um Ctrl+Z cada). Ausente/vazio = sem o campo: o estado das obras antigas fica igual. */
  function camposObra(o, alvo) {
    if (o.nome) alvo.nome = txt(o.nome).slice(0, 40);   /* F2 (Casa 487): o NOME da caixa/peça (CI-01, CG-01, CP-01…), renomeável por instAlterar */
    if (o.comentarios) alvo.comentarios = txt(o.comentarios).slice(0, 300);
    if (o.faseCriada) alvo.faseCriada = txt(o.faseCriada).slice(0, 40);
    if (o.faseDemolida && o.faseDemolida !== "Nenhum") alvo.faseDemolida = txt(o.faseDemolida).slice(0, 40);
  }
  function normPeca(o) {
    var P = PECAS[o.peca]; if (!P) return null;
    var x = num(o.x, NaN), y = num(o.y, NaN), z = num(o.z, NaN);
    if (!isFinite(x) || !isFinite(y) || !isFinite(z)) return null;
    var sis = P.sistemas.indexOf(o.sistema) >= 0 ? o.sistema : P.sistemas[0];
    var mat = P.materiais ? (P.materiais.indexOf(o.material) >= 0 ? o.material : P.material) : P.material;
    var dn = P.dns.indexOf(txt(o.dn)) >= 0 ? txt(o.dn) : P.dn;
    var k = { id: o.id, peca: o.peca, sistema: sis, material: mat, dn: dn, x: x, y: y, z: z, rotY: num(o.rotY, 0) };
    if (o.peca === "extintor" && txt(o.capacidade)) k.capacidade = txt(o.capacidade).slice(0, 40);   /* capacidade extintora calculada pelo Hidro (ex.: "3-A:20-B:C"); o incendio a le */
    if (P.sistemas[0] === "eletrica") {
      k.alturaPiso = num(o.alturaPiso, null);
      /* LIGAÇÃO ELÉTRICA (21/10/2026, js/eletilum.js): o ponto de luz do ambiente com forro é a caixa octogonal SOBRE o forro */
      k.aplicacao = o.peca === "caixa_octogonal" ? (o.aplicacao === "forro" ? "forro" : "laje") : alturaCaixa(k.alturaPiso);
    } else k.aplicacao = sis;                         /* ralo/caixa sifonada: a SINAPI separa esgoto × pluvial */
    /* o cilindro de captura (ver PECAS): do topo da peça até a saída */
    var R = P.captura, prof = P.forma === "cil" ? (P.prof || 0) : 0.06;
    if (P.profVariavel && isFinite(num(o.prof, NaN)) && num(o.prof, 0) > 0) prof = num(o.prof, prof);   /* caixa de inspeção: a profundidade é da instância */
    if (P.profVariavel) k.prof = r4(prof);
    if (P.tipos) {   /* a caixa de inspeção: o tipo (alvenaria/pré-moldada/dispositivo de PVC) e a tampa; o tamanho segue o tipo */
      k.tipoCaixa = P.tipos[o.tipoCaixa] ? o.tipoCaixa : "alvenaria";
      k.tampa = k.tipoCaixa === "pvc300" ? "pvc" : (o.tampa === "ferro" ? "ferro" : "concreto");
      k.dn = k.tipoCaixa === "pvc300" ? "300" : "600";
    }
    camposObra(o, k);   /* FLUIDEZ: comentários e fase da instância */
    k.hub = { x: x, z: z, yTop: y + (P.forma === "caixa" ? 0.06 : 0.02), yBot: y - prof - 0.02, r: R };
    return k;
  }

  /* ===================================================== APLICAR OPS
   * O BimEdit chama aplicarOp(estado, op) para toda op que ele não conhece
   * (e para mover/apagar de id que não é dele). Devolve true se tratou. */
  function novoEstado() { return { trechos: {}, ordemT: [], pecas: {}, ordemP: [], acessorios: {}, ordemAc: [], nomesSis: {} }; }
  function aplicarOp(est, o) {
    if (!est || !o || !o.op) return false;
    if (!est.acessorios) { est.acessorios = {}; est.ordemAc = []; est.nomesSis = {}; }
    /* P12: acessório no tubo (divide o trecho) e o nome do sistema */
    if (o.op === "acessorio") return aplicarAcessorio(est, o);
    /* LIGAÇÃO ELÉTRICA DA ILUMINAÇÃO (21/10/2026, js/eletilum.js; contrato docs/eletrica/CONTRATO-ILUMINACAO.md): o REGISTRO do
       ambiente (comandos, regra dos interruptores, caminho, circuito, fiação por trecho). Só dados: as peças são trechos, peças e
       famílias comuns. Apagar com o id do registro tira o registro (as peças ficam, editáveis). */
    if (o.op === "ligEletrica" && o.id != null) {
      if (!est.ligacoes) { est.ligacoes = {}; est.ordemLig = []; }
      est.ligacoes[o.id] = copia(o);
      if (est.ordemLig.indexOf(o.id) < 0) est.ordemLig.push(o.id);
      return true;
    }
    if (o.op === "apagar" && o.id != null && est.ligacoes && est.ligacoes[o.id]) { delete est.ligacoes[o.id]; est.ordemLig.splice(est.ordemLig.indexOf(o.id), 1); return true; }
    if (o.op === "instSistema" && o.id != null) {
      if (!est.trechos[o.id]) return false;
      var nm = txt(o.nome).trim().slice(0, 60);
      if (nm) est.nomesSis[o.id] = nm; else delete est.nomesSis[o.id];
      return true;
    }
    if (est.acessorios[o.id] && o.id != null) {
      if (o.op === "instAlterar") {
        var ac0 = copia(est.acessorios[o.id]);
        if (o.tipoId !== undefined) ac0.tipoId = txt(o.tipoId);
        /* Casa 487 (F9): o DN do acessório acompanha o do tubo quando o dimensionamento o muda (registro de pressão do chuveiro DN 20 -> 25); só valor positivo */
        if (o.dn !== undefined && isFinite(Number(o.dn)) && Number(o.dn) > 0) ac0.dn = Number(o.dn);
        /* APOIAR EM… (js/bimapoiar.js): o registro anda na vertical junto com o tubo em que está (dy em metros, soma na cota do centro) */
        if (o.dy !== undefined && isFinite(Number(o.dy)) && ac0.centro) ac0.centro = { x: ac0.centro.x, y: Math.round((ac0.centro.y + Number(o.dy)) * 1e6) / 1e6, z: ac0.centro.z };
        if (o.giro !== undefined) { var gA = ((num(o.giro, 0) % 360) + 360) % 360; if (gA) ac0.giro = gA; else delete ac0.giro; }   /* COLOCAÇÃO (js/biminstcolocar.js): Espaço gira o volante em torno do tubo */
        if (!normAcessorio(ac0)) return false;
        est.acessorios[o.id] = ac0; return true;
      }
      if (o.op === "apagar") return apagarAcessorio(est, o.id);
      return false;   /* mover um acessório: tire e ponha de novo (ele vive no eixo do tubo) */
    }
    if (o.op === "trecho" && o.id != null) {
      var t = normTrecho(o); if (!t) return false;
      if (est.pecas[o.id]) return false;
      est.trechos[o.id] = copia(o);
      if (est.ordemT.indexOf(o.id) < 0) est.ordemT.push(o.id);
      return true;
    }
    if (o.op === "peca" && o.id != null) {
      if (!normPeca(o) || est.trechos[o.id]) return false;
      est.pecas[o.id] = copia(o);
      if (est.ordemP.indexOf(o.id) < 0) est.ordemP.push(o.id);
      return true;
    }
    if (o.op === "instAlterar" && o.id != null) {
      var alvo = est.trechos[o.id] || est.pecas[o.id]; if (!alvo) return false;
      var novo = copia(alvo);
      ["sistema", "material", "dn", "aplicacao", "pn", "classe", "iso", "larg", "alt", "bitola", "serie", "peca", "alturaPiso", "rotY", "continua", "juntaIni", "juntaFim", "juntaMotivo", "excentrica", "comentarios", "nome", "faseCriada", "faseDemolida", "pecaIni", "pecaFim", "tipoCaixa", "tampa", "prof"].forEach(function (k) { if (o[k] !== undefined) novo[k] = o[k]; });
      if (o.continua === "") delete novo.continua;
      if (o.pecaIni === "") delete novo.pecaIni;
      if (o.pecaFim === "") delete novo.pecaFim;
      if (o.aplicacao === "") delete novo.aplicacao;     /* volta para a automática */
      if (est.trechos[o.id]) { if (!normTrecho(novo)) return false; est.trechos[o.id] = novo; }
      else { if (!normPeca(novo)) return false; est.pecas[o.id] = novo; }
      return true;
    }
    if (o.op === "mover" && o.id != null) {
      var mx = num(o.cx, NaN), mz = num(o.cz, NaN); if (!isFinite(mx) || !isFinite(mz)) return false;
      if (est.trechos[o.id]) {
        var tr = est.trechos[o.id], cxm = (tr.p1.x + tr.p2.x) / 2, czm = (tr.p1.z + tr.p2.z) / 2, dx = mx - cxm, dz = mz - czm;
        tr.p1 = { x: r4(tr.p1.x + dx), y: tr.p1.y, z: r4(tr.p1.z + dz) }; tr.p2 = { x: r4(tr.p2.x + dx), y: tr.p2.y, z: r4(tr.p2.z + dz) };
        return true;
      }
      if (est.pecas[o.id]) { est.pecas[o.id].x = r4(mx); est.pecas[o.id].z = r4(mz); return true; }
      return false;
    }
    if (o.op === "apagar" && o.id != null) {
      if (est.trechos[o.id]) {
        /* 27/10/2026 (Casa 487, "kf78-ch-rp"): apagar o tubo que o registro divide deixava o registro SOLTO no modelo (trecho/novoId que já não
           existem) — o traçado seguinte recusava a operação e o cômodo inteiro ficava sem tubo. O registro ligado a um tubo apagado sai junto
           (sem emendar: as duas metades vão embora; quem quer o tubo inteiro apaga o registro primeiro, como a limpeza dos kits faz) */
        arr(est.ordemAc).slice().forEach(function (idA) { var a = est.acessorios[idA]; if (a && (String(a.trecho) === String(o.id) || (a.novoId != null && String(a.novoId) === String(o.id)))) { delete est.acessorios[idA]; est.ordemAc.splice(est.ordemAc.indexOf(idA), 1); } });
        delete est.trechos[o.id]; est.ordemT.splice(est.ordemT.indexOf(o.id), 1); return true;
      }
      if (est.pecas[o.id]) { delete est.pecas[o.id]; est.ordemP.splice(est.ordemP.indexOf(o.id), 1); return true; }
      return false;
    }
    return false;
  }
  /* o estado fechado que vai no `instalacoes` do BimEdit.aplicar */
  function fechar(est) {
    if (!est) return { trechos: [], pecas: [] };
    var out = {
      trechos: est.ordemT.map(function (id) { return normTrecho(est.trechos[id]); }).filter(Boolean),
      pecas: est.ordemP.map(function (id) { return normPeca(est.pecas[id]); }).filter(Boolean)
    };
    /* P12: só quando há — o estado das obras sem acessório fica byte a byte o de antes */
    var acs = arr(est.ordemAc).map(function (id) { return normAcessorio(est.acessorios[id]); }).filter(Boolean);
    if (acs.length) out.acessorios = acs;
    if (est.nomesSis && Object.keys(est.nomesSis).length) out.nomesSistema = copia(est.nomesSis);
    /* ligação elétrica: só quando há (o estado das obras sem ela fica byte a byte o de antes) */
    if (est.ordemLig && est.ordemLig.length) out.ligacoes = est.ordemLig.map(function (id) { var r = copia(est.ligacoes[id]); delete r.op; return r; });
    return out;
  }
  /* sanear: shape válido de uma op de instalação (storage corrompido não derruba o replay) */
  function opValida(o) {
    if (!o) return false;
    function fin(v) { return typeof v === "number" && isFinite(v); }
    function p3(p) { return !!p && fin(p.x) && fin(p.y) && fin(p.z); }
    if (o.op === "trecho") return o.id != null && !!SISTEMAS[o.sistema] && p3(o.p1) && p3(o.p2) && (o.dn == null || fin(o.dn));
    if (o.op === "peca") return o.id != null && !!PECAS[o.peca] && fin(o.x) && fin(o.y) && fin(o.z);
    if (o.op === "instAlterar") return o.id != null;
    /* P12 */
    if (o.op === "acessorio") return o.id != null && typeof o.famId === "string" && !!ACESSORIO_DA_FAM[o.famId] && fin(o.x) && fin(o.y) && fin(o.z) &&
      (o.trecho == null ? true : o.novoId != null) && (o.comprimento == null || fin(o.comprimento)) && (o.giro == null || fin(o.giro));
    if (o.op === "instSistema") return o.id != null && typeof o.nome === "string";
    if (o.op === "ligEletrica") return o.id != null && typeof o.amb === "string" && Array.isArray(o.comandos);
    return false;
  }

  /* ============================================ CONECTORES DE APARELHO
   * Família com `conectores: [{ id, sistema, dn, x, y, z, nome }]` — o
   * js/familia.js avalia (x/y/z/dn podem ser FÓRMULA dos parâmetros, como os
   * sólidos) e devolve em `avaliado.conectores`, no sistema LOCAL. Aqui vão ao
   * mundo pelo mesmo giro do viewer (three: x' = x·cosθ + z·sinθ;
   * z' = −x·sinθ + z·cosθ) — o teste confere contra a matriz do three. */
  function conectoresDe(av, inst) {
    var out = [];
    if (!av) return out;
    var rot = num(inst && inst.rotY, 0), c = Math.cos(rot), s = Math.sin(rot), cx = av.caixa;
    /* QUALIDADE VISUAL 2 (17/10/2026): ponto NA FACE DE TRÁS do aparelho (convenção do js/familia.js:
       Z local para fora da parede) = ponto de PAREDE — `parede` é a normal, no mundo, que entra na
       parede. O traçado chega nele por dentro da parede (desce/sobe embutido e sai por um toco
       perpendicular); sem isto a descida corria na face e passava por dentro da coluna do lavatório
       e da caixa acoplada. Ponto fora da face (saída de piso da bacia, válvula da pia) não ganha nada. */
    var temFace = cx && isFinite(cx.z0) && isFinite(cx.z1) && cx.z1 - cx.z0 > FACE_TOL * 2;
    /* peça EM LINHA (luva, registro, conexão importada): tem ponto também na face da FRENTE — não é de parede */
    if (temFace && arr(av.conectores).some(function (k) { return k && Math.abs(num(k.z, 0) - cx.z1) <= FACE_TOL; })) temFace = false;
    /* FRENTE H7: a família que DECLARA a face da parede (js/familia.js faceParede — a churrasqueira com o chapéu atrás do fundo) */
    var z0F = temFace && av.faceParede != null && isFinite(Number(av.faceParede)) ? Number(av.faceParede) : (cx ? cx.z0 : 0);
    arr(av.conectores).forEach(function (k, i) {
      if (!k || !SISTEMAS[k.sistema]) return;
      var lx = num(k.x, 0), ly = num(k.y, 0), lz = num(k.z, 0);
      var o = { id: (inst && inst.id != null ? inst.id : "") + ":" + (k.id || ("c" + i)), famInst: inst ? inst.id : null, nome: txt(k.nome) || SISTEMAS[k.sistema].nome,
                 sistema: k.sistema, dn: num(k.dn, 0),
                 x: r4(num(inst && inst.x, 0) + lx * c + lz * s), y: r4(num(inst && inst.y, 0) + ly), z: r4(num(inst && inst.z, 0) - lx * s + lz * c) };
      /* d = quanto o ponto está À FRENTE da face de trás do corpo (a louça encosta na parede pelo corpo): o eixo embutido
         se mede da face da parede, e todos os pontos da mesma parede caem na mesma linha */
      if (temFace && Math.abs(lz - z0F) <= FACE_TOL) o.parede = { x: r4(-s), z: r4(-c), d: r4(Math.max(0, lz - z0F)) };
      /* ENTRADA E SAÍDA ASSERTIVAS (27/10/2026, frente 1b-ii): o que a família DECLARA no conector (js/familia.js repassa) segue para o mundo —
         papel (entrada | saida | respiro | succao | recalque), porta, opcional (sem tubo não é desconexão), bidirecional e `rosca` (bitola do ponto).
         `dirTubo` = para onde o tubo sai da peça, no MUNDO (o `dir` local girado como o ponto); `rotY` guarda o giro para a reserva (Z local = fora da parede). */
      if (k.papel) o.papel = txt(k.papel);
      if (k.porta) o.porta = txt(k.porta);
      if (k.opcional === true) o.opcional = true;
      if (k.bidirecional === true || k.bidirecional === false) o.bidirecional = k.bidirecional;
      if (k.rosca) o.rosca = txt(k.rosca);
      if (k.dir && typeof k.dir === "object") { var dx0 = num(k.dir.x, 0), dy0 = num(k.dir.y, 0), dz0 = num(k.dir.z, 0); o.dirTubo = { x: r4(dx0 * c + dz0 * s), y: r4(dy0), z: r4(-dx0 * s + dz0 * c) }; }
      o.rotY = rot;
      out.push(o);
    });
    return out;
  }
  /* QUALIDADE VISUAL 2: o VOLUME de cada família colocada (a caixa envolvente do tipo, girada com a
     instância) — o traçado nunca passa por dentro de uma louça ou equipamento. Formato da caixa girada
     do js/hidrota.js: centro (cx, cz), eixo u = X local no mundo, meias medidas hl (X) e hw (Z), cotas
     y0..y1. Família que fica ABAIXO do piso (ralo, caixa sifonada, caixa de gordura enterrada) não entra:
     o tubo chega nela por dentro, é a função dela. */
  function volumesFamilias(estado, avaliarFam) {
    var out = [];
    arr(estado && estado.familias).forEach(function (fi) {
      var av = typeof avaliarFam === "function" ? avaliarFam(fi.famId, fi.tipoId, fi.inst) : null, b = av && (av.caixaObstaculo || av.caixa);   /* revisão H5: sem as peças rentes à parede */
      if (!b || ![b.x0, b.x1, b.y0, b.y1, b.z0, b.z1].every(isFinite) || b.y1 <= TOL) return;   /* tudo abaixo da origem (só a tampa/grelha no piso) = enterrada */
      var rot = num(fi.rotY, 0), c = Math.cos(rot), s = Math.sin(rot), mx = (b.x0 + b.x1) / 2, mz = (b.z0 + b.z1) / 2;
      out.push({ id: fi.id, famId: fi.famId, cx: r4(num(fi.x, 0) + mx * c + mz * s), cz: r4(num(fi.z, 0) - mx * s + mz * c), ux: c, uz: -s,
                 hl: r4((b.x1 - b.x0) / 2), hw: r4((b.z1 - b.z0) / 2), y0: r4(num(fi.y, 0) + b.y0), y1: r4(num(fi.y, 0) + b.y1) });
    });
    return out;
  }
  /* o segmento p-q (3D) entra no volume v (caixa girada acima)? `encolher` tira uma casca das faces (o
     tubo que só ENCOSTA na face, como o toco que chega no ponto da parede, não é travessia) */
  function cortaVolume(v, p, q, encolher) {
    var e = num(encolher, 0), t0 = 0, t1 = 1;
    function loc(a) { var dx = a.x - v.cx, dz = a.z - v.cz; return { u: dx * v.ux + dz * v.uz, w: -dx * v.uz + dz * v.ux, y: a.y }; }
    var A = loc(p), Bq = loc(q), lim = [["u", -v.hl + e, v.hl - e], ["w", -v.hw + e, v.hw - e], ["y", v.y0 + e, v.y1 - e]];
    for (var i = 0; i < 3; i++) {
      var k = lim[i][0], lo = lim[i][1], hi = lim[i][2], a = A[k], d = Bq[k] - a;
      if (!(hi > lo)) return false;
      if (Math.abs(d) < 1e-12) { if (a <= lo || a >= hi) return false; continue; }
      var ta = (lo - a) / d, tb = (hi - a) / d; if (ta > tb) { var tt = ta; ta = tb; tb = tt; }
      if (ta > t0) t0 = ta; if (tb < t1) t1 = tb; if (t0 >= t1) return false;
    }
    return true;
  }
  /* o TUBO (eixo p-q, raio r) entra no volume v? A ponta que chega num ponto de ligação DAQUELE aparelho
     (`pontos`) recua o raio + a casca: o toco que encosta no ponto da face não é travessia; o resto do tubo
     conta com o raio (a vertical colada na face, metade dentro da coluna do lavatório, É travessia). */
  function tuboEmVolume(v, p, q, r, pontos, casca) {
    var e = num(casca, 0.002), rr = Math.max(0, num(r, 0)), a = { x: p.x, y: p.y, z: p.z }, b = { x: q.x, y: q.y, z: q.z };
    var L = dist(a, b); if (!(L > 1e-9)) return false;
    function perto(x) { return arr(pontos).some(function (k) { return dist(k, x) <= TOL_CONECTOR; }); }
    var u = { x: (b.x - a.x) / L, y: (b.y - a.y) / L, z: (b.z - a.z) / L }, ra = perto(a) ? rr + e : 0, rb = perto(b) ? rr + e : 0;
    if (ra + rb >= L) return false;
    var a2 = { x: a.x + u.x * ra, y: a.y + u.y * ra, z: a.z + u.z * ra }, b2 = { x: b.x - u.x * rb, y: b.y - u.y * rb, z: b.z - u.z * rb };
    return cortaVolume(v, a2, b2, e - rr);
  }
  /* ====================================================== TROCAR O DN (Propriedades, em um clique)
   * Pedido do Rogério (17/10/2026): "clico na conexão, mudo para 100 e as conexões embutidas já trocam". A conexão é
   * DEDUZIDA da geometria e do DN dos trechos (rede): trocar o DN de um TRECHO já troca as conexões das pontas (e a
   * redução entra sozinha onde o vizinho ficou diferente; no ponto da louça o DN do aparelho fica e entra a redução).
   * Trocar o DN de uma CONEXÃO = trocar os trechos ligados nela (cada um até a próxima conexão). Tudo numa lista de
   * ops que vai num lote só (um Ctrl+Z desfaz). Regras:
   *   · DN fora da lista comercial do material de algum trecho → NÃO aplica, diz qual e a lista;
   *   · esgoto/pluvial: a inclinação mínima é a do DN NOVO (a maior entre a regra do modelador e a tabela do
   *     HidNormas). Trecho que ficou abaixo dela tem a ponta de JUSANTE abaixada e o que vem depois desce junto (a
   *     jusante inteira, mantendo as inclinações dela; o ramal que chega no nó só ganha queda) — com aviso de quanto.
   * alvos = ids de trechos e/ou de conexões (os "cx…" da rede atual). Devolve { ok, erro, ops, avisos, trechos }. */
  function declMinDn(sistema, dn) {
    var i = inclinacaoMinima(sistema, dn);
    if (sistema !== "esgoto") return i;
    var N = dep("HidNormas", "./hidnormas.js");
    try {
      var t = N && N.tabela ? N.tabela("es.declividade_minima") : null;
      var l = t && t.linhas ? t.linhas.filter(function (x) { return x.dn_max === "*" || Number(x.dn_max) >= dn; })
        .sort(function (a, b) { return (a.dn_max === "*" ? Infinity : Number(a.dn_max)) - (b.dn_max === "*" ? Infinity : Number(b.dn_max)); })[0] : null;
      if (l && isFinite(Number(l.declividade_pct))) i = Math.max(i, Number(l.declividade_pct));
    } catch (e) {}
    return i;
  }
  function opDoTrecho(t) {
    var o = { op: "trecho", id: t.id, sistema: t.sistema, material: t.material, dn: t.dn, p1: { x: t.p1.x, y: t.p1.y, z: t.p1.z }, p2: { x: t.p2.x, y: t.p2.y, z: t.p2.z } };
    ["pn", "classe", "iso", "serie", "linha", "continua", "larg", "alt", "bitola", "pecaIni", "pecaFim"].forEach(function (k) { if (t[k] != null && t[k] !== "") o[k] = t[k]; });
    if (!t.aplicacaoAuto && t.aplicacao) o.aplicacao = t.aplicacao;
    return o;
  }
  /* DESLOCAMENTO INICIAL/FINAL (Propriedades, 17/10/2026): a cota de UMA ponta do trecho muda; as pontas dos outros
     trechos do mesmo sistema que estavam NAQUELE nó vão junto (a ligação não se desfaz). y = cota absoluta. */
  function moverCota(estado, id, ponta, y) {
    var ins = (estado && estado.instalacoes) || { trechos: [] }, t0 = arr(ins.trechos).filter(function (t) { return t.id === id; })[0];
    if (!t0 || (ponta !== "p1" && ponta !== "p2") || !isFinite(Number(y))) return { ok: false, erro: "Trecho ou cota inválida.", ops: [] };
    var P = t0[ponta], ops = [];
    arr(ins.trechos).forEach(function (t) {
      if (t.sistema !== t0.sistema) return;
      var o = null;
      ["p1", "p2"].forEach(function (k) { if (dist(t[k], P) <= TOL) { o = o || opDoTrecho(t); o[k] = { x: t[k].x, y: r4(Number(y)), z: t[k].z }; } });
      if (o) ops.push(o);
    });
    var ruins = ops.filter(function (o) { return !normTrecho(o); });
    if (ruins.length) return { ok: false, erro: "A cota nova deixa o trecho " + ruins[0].id + " sem comprimento.", ops: [] };
    return { ok: true, ops: ops };
  }
  /* DIVIDIR o tubo no ponto P (a ligação que chega no MEIO dele): dois trechos com o nó em P — a conexão (tê ou junção)
     fica no nó. As pontas que "continuam fora do modelo" ficam com o pedaço certo. */
  function dividirTrecho(estado, id, P) {
    var t = arr(estado && estado.instalacoes && estado.instalacoes.trechos).filter(function (x) { return x.id === id; })[0]; if (!t || !P) return [];
    var L2 = Math.pow(t.p2.x - t.p1.x, 2) + Math.pow(t.p2.y - t.p1.y, 2) + Math.pow(t.p2.z - t.p1.z, 2); if (!(L2 > 0)) return [];
    var s = ((P.x - t.p1.x) * (t.p2.x - t.p1.x) + (P.y - t.p1.y) * (t.p2.y - t.p1.y) + (P.z - t.p1.z) * (t.p2.z - t.p1.z)) / L2;
    if (!(s > 0.001 && s < 0.999)) return [];
    var J = { x: r4(t.p1.x + (t.p2.x - t.p1.x) * s), y: r4(t.p1.y + (t.p2.y - t.p1.y) * s), z: r4(t.p1.z + (t.p2.z - t.p1.z) * s) };
    var o1 = opDoTrecho(t), o2 = opDoTrecho(t); o1.p2 = J; o2.p1 = J; o2.id = id + "b";
    delete o1.continua; delete o2.continua;
    delete o1.pecaFim; delete o2.pecaIni;   /* a peça em linha fica na ponta de origem (o nó novo do meio é outro) */
    if (t.continua === "p1" || t.continua === "ambos") o1.continua = "p1";
    if (t.continua === "p2" || t.continua === "ambos") o2.continua = "p2";
    return [o1, o2];
  }
  function trocarDn(estado, avaliarFam, alvos, dnNovo) {
    var dn = num(dnNovo, NaN);
    if (!(dn > 0)) return { ok: false, erro: "DN inválido.", ops: [], avisos: [] };
    var ins = (estado && estado.instalacoes) || { trechos: [] }, porId = {}, ids = [], avisos = [];
    arr(ins.trechos).forEach(function (t) { porId[t.id] = t; });
    var R = null;
    arr(alvos).forEach(function (a) {
      a = txt(a).replace(/^edit:/, "");
      if (porId[a]) { if (ids.indexOf(a) < 0) ids.push(a); return; }
      if (!R) R = rede(estado, avaliarFam);
      var c = R.conexoes.filter(function (x) { return x.id === a; })[0];
      if (c) arr(c.ramos).forEach(function (id) { if (porId[id] && ids.indexOf(id) < 0) ids.push(id); });
    });
    if (!ids.length) return { ok: false, erro: "Nada para trocar: selecione um tubo ou uma conexão.", ops: [], avisos: [] };
    /* o DN tem de existir no material de TODOS os trechos */
    for (var i = 0; i < ids.length; i++) {
      var t = porId[ids[i]], M = MATERIAIS[t.material];
      if (!M || M.secao) return { ok: false, erro: "O trecho " + t.id + " não tem diâmetro (seção retangular).", ops: [], avisos: [] };
      if (arr(M.dns).length && M.dns.indexOf(dn) < 0) return { ok: false, erro: "DN " + dn + " não existe em " + M.nome + " (" + M.dns.join(", ") + "): nada foi trocado.", ops: [], avisos: [] };
    }
    /* geometria de trabalho: cópia dos trechos (o abaixamento da jusante mexe nos pontos) */
    var G = {}; arr(ins.trechos).forEach(function (t) { G[t.id] = { t: t, p1: { x: t.p1.x, y: t.p1.y, z: t.p1.z }, p2: { x: t.p2.x, y: t.p2.y, z: t.p2.z }, mudou: false, dn: t.dn }; });
    ids.forEach(function (id) { G[id].dn = dn; });
    function perto(a, b) { return dist(a, b) <= TOL; }
    function horiz(g) { return Math.sqrt(Math.pow(g.p2.x - g.p1.x, 2) + Math.pow(g.p2.z - g.p1.z, 2)) > TOL; }
    /* abaixa o nó P de `d` e a jusante inteira dele (mesmo sistema) */
    function abaixar(P, d, sis, visto, pular) {
      var k = r4(P.x) + "," + r4(P.y) + "," + r4(P.z); if (visto[k]) return; visto[k] = 1;
      var P0 = { x: P.x, y: P.y, z: P.z };
      Object.keys(G).forEach(function (id) {
        var g = G[id]; if (g.t.sistema !== sis || id === pular) return;
        if (!horiz(g)) {
          /* vertical: o nó no MEIO dela (junção no tubo de queda) só escorrega; a ponta de cima (a descida) encurta */
          var cima = g.p1.y >= g.p2.y ? "p1" : "p2";
          if (perto(g[cima], P0)) { g[cima].y = r4(g[cima].y - d); g.mudou = true; }
          return;
        }
        if (perto(g.p1, P0)) {   /* a jusante: desce inteira */
          g.p1.y = r4(g.p1.y - d); var p2 = { x: g.p2.x, y: g.p2.y, z: g.p2.z }; g.p2.y = r4(g.p2.y - d); g.mudou = true;
          abaixar(p2, d, sis, visto, null);
        } else if (perto(g.p2, P0)) { g.p2.y = r4(g.p2.y - d); g.mudou = true; }   /* o ramal que CHEGA no nó: só ganha queda */
      });
    }
    ids.forEach(function (id) {
      var g = G[id], t = g.t, S = SISTEMAS[t.sistema]; if (!S || !S.gravidade || !horiz(g)) return;
      var L = Math.sqrt(Math.pow(g.p2.x - g.p1.x, 2) + Math.pow(g.p2.z - g.p1.z, 2)), imin = declMinDn(t.sistema, dn), queda = g.p1.y - g.p2.y, precisa = imin / 100 * L;
      if (queda >= precisa - 1e-6) return;
      var d = Math.ceil((precisa - queda) * 10000 - 1e-6) / 10000, P2 = { x: g.p2.x, y: g.p2.y, z: g.p2.z };   /* 0,1 mm, para cima */
      abaixar(P2, d, t.sistema, {}, id);
      g.p2.y = r4(g.p2.y - d); g.mudou = true;
      avisos.push("trecho " + t.id + ": a inclinação mínima do DN " + dn + " é " + String(imin).replace(".", ",") + "% — a ponta de jusante e o que vem depois desceram " + String(Math.round(d * 1000) / 10).replace(".", ",") + " cm");
    });
    var ops = [];
    Object.keys(G).forEach(function (id) {
      var g = G[id];
      if (g.mudou) { var o = opDoTrecho(g.t); o.dn = g.dn; o.p1 = g.p1; o.p2 = g.p2; ops.push(o); }
      else if (ids.indexOf(id) >= 0 && g.t.dn !== dn) ops.push({ op: "instAlterar", id: id, dn: dn });
    });
    if (!ops.length) avisos.push("o DN já era " + dn + ": nada a trocar");
    return { ok: true, ops: ops, avisos: avisos, trechos: ids };
  }
  /* todos os conectores das famílias colocadas (avaliarFam = o mesmo do viewer) */
  function conectoresDoEstado(estado, avaliarFam) {
    var out = [];
    arr(estado && estado.familias).forEach(function (fi) {
      var av = typeof avaliarFam === "function" ? avaliarFam(fi.famId, fi.tipoId, fi.inst) : null;
      if (!av || !arr(av.conectores).length) return;
      conectoresDe(av, fi).forEach(function (k) { out.push(k); });
    });
    return out;
  }

  /* ========================================================== A REDE
   * Acha os NÓS (pontas que se tocam, ponta no meio de outro trecho, ponto
   * de aparelho, peça) e decide a CONEXÃO de cada um pela geometria e pelo
   * DN. Nada aqui é gravado: é deduzido a cada replay.
   * ---------------------------------------------------------------- */
  function unit(a, b) { var dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, L = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1; return { x: dx / L, y: dy / L, z: dz / L }; }
  function dot(a, b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
  function grau(c) { return Math.acos(Math.max(-1, Math.min(1, c))) * 180 / Math.PI; }
  /* desvio entre dois ramos que SAEM do nó: 0° = alinhados (seguem reto) */
  function desvio(d1, d2) { return grau(-dot(d1, d2)); }
  /* distância de q ao INTERIOR do segmento a-b (null se a projeção cai nas pontas) */
  function noInterior(q, a, b) {
    var ab = { x: b.x - a.x, y: b.y - a.y, z: b.z - a.z }, L2 = dot(ab, ab); if (!(L2 > 0)) return null;
    var t = ((q.x - a.x) * ab.x + (q.y - a.y) * ab.y + (q.z - a.z) * ab.z) / L2, L = Math.sqrt(L2);
    if (t * L <= TOL || (1 - t) * L <= TOL) return null;
    var p = { x: a.x + ab.x * t, y: a.y + ab.y * t, z: a.z + ab.z * t };
    return dist(p, q);
  }
  function dentroHub(q, h) {
    var dx = q.x - h.x, dz = q.z - h.z;
    return Math.sqrt(dx * dx + dz * dz) <= h.r + 1e-9 && q.y <= h.yTop + 1e-9 && q.y >= h.yBot - 1e-9;
  }

  /* 27/10/2026 (frente 1b): a peça existe no catálogo do fabricante para o material e a chave de DN ("100x50", "100")? Vale a cota lida
     (HidGeoDados.conexoes) ou só a presença da ficha com as letras ainda não lidas (conexoesBrutas): o produto EXISTE, mesmo sem cota. */
  function conexaoNoCatalogo(material, tipo, chave) {
    var GD = dep("HidGeoDados", "./biminstgeodados.js"), k = txt(chave);
    if (!GD) return false;
    /* M7 (frente 1c): a peça SEM COTA (a ficha lista, sem tabela dimensional) também existe no catálogo — a junção de redução 75×50 (Amanco 11705) é assim */
    return ["conexoes", "conexoesBrutas"].some(function (q) { var m = GD[q] && GD[q][material]; return !!(m && m[tipo] && m[tipo][k]); }) ||
           arr(GD.semCota).some(function (r) { return !!r && r.material === material && r.tipo === tipo && txt(r.dn) === k; });
  }
  function vet(d) { return d && d.length === 3 ? { x: +d[0], y: +d[1], z: +d[2] } : d; }
  /* ⚠ CONFERÊNCIA DE PORTAS (frente 1b, 27/10/2026): a peça escolhida tem as bocas que o nó tem? (a) o nº de ramos ligados = o nº de bocas
     que ligam tubo (js/biminstportas.js: a tampa nunca; a rosca de aparelho só com o conector do aparelho); (b) nas peças de 2 bocas não
     lineares, o desvio medido bate com a deflexão da peça (45° ± 10, 90° ± 10 — a mesma janela do motor). no = { tipo, ramos:[{dir,...}],
     conector: bool }. Devolve { ok, itens: [{ tipo: "contagem"|"deflexao"|"invertida", texto }] }. Sem HidPortas ou tipo sem porta: ok (não afirma). */
  function conferirPortas(no) {
    var HP = dep("HidPortas", "./biminstportas.js"), itens = [];
    if (!HP || !no || !no.tipo || !HP.info(no.tipo)) return { ok: true, itens: itens, semDados: true };
    var inf = HP.info(no.tipo), ps = inf.portas, nome = nomeConexao(no.tipo, no.material), ramos = arr(no.ramos);
    var ligam = ps.filter(function (p) { return p.papel !== "tampa" && (p.papel !== "ponto" || no.conector); });
    var ids = ligam.map(function (p) { return p.id; }).join(", ");
    var tem = ramos.length + (no.conector ? 1 : 0);   /* o conector do aparelho é uma boca ligada (a rosca `ponto`, ou a boca da redução) */
    if (tem !== ligam.length) itens.push({ tipo: "contagem", texto: nome + ": o nó tem " + tem + " bocas ligadas, mas a peça tem " + ligam.length + " que ligam tubo (portas " + ids + ")" });
    if (inf.naoDeduzir) itens.push({ tipo: "invertida", texto: nome + ": ramal contra o fluxo — uso só em ventilação, nunca deduzida automaticamente; confira" });
    if (ps.length === 2 && ramos.length === 2 && ramos[0].dir && ramos[1].dir) {
      var defl = HP.deflexao(no.tipo), dv = desvio(vet(ramos[0].dir), vet(ramos[1].dir));
      if (defl > 1 && Math.abs(dv - defl) > 10) itens.push({ tipo: "deflexao", texto: nome + ": o desvio medido no nó é " + Math.round(dv) + "°, mas a deflexão entre as portas " + ps[0].id + " e " + ps[1].id + " da peça é " + Math.round(defl) + "°" });
    }
    return { ok: !itens.length, itens: itens };
  }

  /* ===== FRENTE 3 — a peça forçada no nó (ver o bloco acima) ===== */
  function forcadaDoNo(ramos, sistema) {
    var g = grupoDe(sistema), M0 = MATERIAIS[(ramos[0] || {}).material] || {};
    if (!GRUPOS_FORCA[g] || M0.larguras || M0.flexivel) return null;
    for (var i = 0; i < ramos.length; i++) { var pl = ramos[i].pecaLinha; if (pl && !PECAS_LINHA[pl] && tipoForcavel(pl, g)) return pl; }
    return null;
  }
  function decidirForcada(tipo, ramos, sistema, conector, avisos) {
    var av0 = [], base = decidirBase(ramos, sistema, conector, av0), HP = dep("HidPortas", "./biminstportas.js");
    var maior = ramos.slice().sort(function (a, b) { return b.dn - a.dn; })[0], dnM = Math.round(maior.dn), dnm = Math.round(Math.min.apply(null, ramos.map(function (r) { return r.dn; })));
    var nome = nomeConexao(tipo, maior.material), mat = maior.material, motivo = null, aviso = [];
    var chave = dnM === dnm ? txt(dnM) : dnM + "x" + dnm;
    var cf = conferirPortas({ tipo: tipo, material: mat, ramos: ramos, conector: !!conector });
    cf.itens.forEach(function (it) {
      if (it.tipo === "invertida") aviso.push(it.texto);
      else if (!motivo) {
        if (it.tipo === "deflexao") {
          var dv = ramos.length === 2 ? Math.round(desvio(vet(ramos[0].dir), vet(ramos[1].dir))) : null, df = HP.deflexao(tipo);
          motivo = nome + " não serve num nó de " + (dv == null ? "?" : dv) + "°: a peça muda a direção em " + Math.round(df) + "°";
        } else motivo = it.texto;
      }
    });
    if (!motivo && !conexaoNoCatalogo(mat, tipo, chave)) motivo = nome + " DN " + chave.replace("x", " × ") + " não existe no catálogo de " + ((MATERIAIS[mat] || {}).nome || mat);
    if (motivo) {
      av0.forEach(function (t) { avisos.push(t); });
      avisos.push("conexão escolhida não aplicada — " + motivo + ". Ficou a conexão automática" + (base.length ? " (" + nomeConexao(base[0].tipo, base[0].material) + ")" : "") + "; use \"Voltar ao automático\" ou escolha outra peça");
      return base;
    }
    av0.forEach(function (t) { if (/^transição de material/.test(t)) avisos.push(t); });
    aviso.forEach(function (t) { avisos.push(t); });
    return [{ tipo: tipo, sistema: sistema, material: mat, aplicacao: maior.aplicacao, dn: dnM, dn2: dnM === dnm ? 0 : dnm, forcada: true }];
  }
  /* decide a conexão de UM nó de UM sistema. ramos = [{trecho, dir, dn, material, aplicacao, passante}] */
  function decidir(ramos, sistema, conector, avisos) {
    var forca = forcadaDoNo(ramos, sistema);
    if (forca) return decidirForcada(forca, ramos, sistema, conector, avisos);   /* frente 3: peça forçada pelo projetista */
    var out = decidirBase(ramos, sistema, conector, avisos);
    /* frente 1b: a peça escolhida tem as bocas (e a deflexão) que o nó tem? Eletrocalha/flexível não têm portas aqui. */
    var M0 = MATERIAIS[ramos[0].material] || {};
    if (ramos.length >= 2 && out.length && !M0.larguras && !M0.flexivel) {
      var pr = out.filter(function (c) { return c.tipo !== "reducao"; })[0] || out[0];
      var jaDesvio = avisos.some(function (t) { return /^mudança de direção de/.test(t); });
      conferirPortas({ tipo: pr.tipo, material: pr.material, ramos: ramos, conector: !!conector }).itens.forEach(function (it) {
        if (it.tipo === "deflexao" && jaDesvio) return;   /* o aviso de "fora de 45°/90°" já diz */
        avisos.push(it.texto);
      });
    }
    return out;
  }
  function decidirBase(ramos, sistema, conector, avisos) {
    var out = [];
    var mat = ramos[0].material, M = MATERIAIS[mat] || {};
    var mats = {}; ramos.forEach(function (r) { mats[r.material] = 1; });
    if (Object.keys(mats).length > 1) avisos.push("transição de material no nó (" + Object.keys(mats).map(function (k) { return MATERIAIS[k] ? MATERIAIS[k].nome : k; }).join(" × ") + "): a peça de transição não é deduzida — orce à parte");
    /* a aplicação da conexão = a do ramo de MAIOR DN (empate: o primeiro) */
    var maior = ramos.slice().sort(function (a, b) { return b.dn - a.dn; })[0];
    function cx(tipo, dn, dn2, extra) {
      var o = { tipo: tipo, sistema: sistema, material: maior.material, aplicacao: maior.aplicacao, dn: dn, dn2: dn2 || 0 };
      if (extra) Object.keys(extra).forEach(function (k) { o[k] = extra[k]; });
      /* 27/10/2026 (barrilete/colunas em DN 50, decisão do Rogério): a coluna DN 50 reduz na derivação para o DN do ramal (50 → 20) e a SINAPI NÃO tem a
         redução 50 × 20 — só as vizinhas (50 × 25, 50 × 32, 32 × 20, 25 × 20…). Sem composição para o par, a redução sai em SÉRIE por um DN intermediário em que as DUAS metades
         têm composição (cada peça é uma composição SINAPI real, nada inventado); sem intermediário, fica como era (pendente). */
      if (tipo === "reducao" && dn2 && !flexOuSemTabela(maior.material)) {
        var itT = { peca: "reducao", sistema: sistema, material: o.material, aplicacao: o.aplicacao, dn: dn, dn2: dn2 };
        if (sinapiDe(itT).status !== "ok") {
          var dnsM = arr((MATERIAIS[o.material] || {}).dns).filter(function (d) { return d < dn - 0.5 && d > dn2 + 0.5; }).sort(function (a, b) { return b - a; });
          for (var iK = 0; iK < dnsM.length; iK++) {
            var kk = dnsM[iK], a1 = { peca: "reducao", sistema: sistema, material: o.material, aplicacao: o.aplicacao, dn: dn, dn2: kk }, a2 = { peca: "reducao", sistema: sistema, material: o.material, aplicacao: o.aplicacao, dn: kk, dn2: dn2 };
            if (sinapiDe(a1).status === "ok" && sinapiDe(a2).status === "ok") {
              var o1 = {}, o2 = {}; Object.keys(o).forEach(function (q) { o1[q] = o[q]; o2[q] = o[q]; });
              o1.dn2 = kk; o2.dn = kk; o1.serie = o2.serie = dn + "x" + kk + "x" + dn2;
              out.push(o1); out.push(o2); return;
            }
          }
        }
      }
      out.push(o);
    }
    if (M.larguras) return decidirBandeja(ramos, sistema, conector, avisos, out, cx);   /* P12: eletrocalha */
    var flex = !!M.flexivel;
    var n = ramos.length;
    if (n === 1) {
      if (conector) {
        if (!flex && conector.dn > 0 && Math.abs(conector.dn - ramos[0].dn) > 0.5) {
          /* aparelho com DN diferente do tubo: a redução entra (o maior x o menor) */
          cx("reducao", Math.max(conector.dn, ramos[0].dn), Math.min(conector.dn, ramos[0].dn));
        }
      }
      return out;
    }
    if (flex) {
      if (n >= 3) avisos.push("derivação de " + (M.nome || "tubo flexível") + " sem caixa: ponha uma caixa de passagem no ponto");
      return out;                                                  /* a curva é o próprio tubo */
    }
    if (n === 2) {
      var a = ramos[0], b = ramos[1], dv = desvio(a.dir, b.dir), dnM = Math.max(a.dn, b.dn), dnm = Math.min(a.dn, b.dn);
      if (dv < 10) {
        /* PENDÊNCIAS FINAIS: a peça em linha pedida pelo projetista (união / tê de inspeção) no lugar da luva */
        var pl0 = [a.pecaLinha, b.pecaLinha].filter(function (x) { return PECAS_LINHA[x] && PECAS_LINHA[x].indexOf(grupoDe(sistema)) >= 0; })[0];
        if (pl0 && !pecaLinhaExiste(pl0, mat, dnM)) { avisos.push(NOMES_CONEXAO[pl0] + " DN " + dnM + " de " + (M.nome || mat) + " não existe no catálogo dos fabricantes: ficou a luva (escolha outro DN ou outra peça)"); pl0 = null; }
        if (pl0 && Math.abs(a.dn - b.dn) < 0.5) { cx(pl0, dnM, 0, { forcada: true }); return out; }   /* frente 3: "(escolhida)" na Propriedade do nó */
        if (pl0) avisos.push(NOMES_CONEXAO[pl0] + " pedida num nó com DN " + dnm + " × " + dnM + ": a peça é de um DN só — ficou a redução (confira)");
        /* ⚠ REDUÇÃO CONTRA O FLUXO (frente 1b, 27/10/2026): no esgoto/pluvial o DN não pode diminuir a jusante (NBR 8160) — se o trecho de
           DN maior é o MONTANTE (o que desce para o nó; a mesma lógica de jusante da junção: a que mais desce, senão a que COMEÇA no nó), avisa.
           A redução continua deduzida: não se esconde o defeito do traçado. */
        if ((sistema === "esgoto" || sistema === "pluvial") && Math.abs(a.dn - b.dn) >= 0.5) {
          var dyA = a.dir.y - b.dir.y, jusA = Math.abs(dyA) > EPS_FLUXO ? (dyA < 0 ? a : b) : (a.jus && !b.jus ? a : (b.jus && !a.jus ? b : null));
          var monA = jusA ? (jusA === a ? b : a) : null;
          if (jusA && monA.dn > jusA.dn + 0.5)
            avisos.push("o diâmetro diminui no sentido do escoamento (trecho " + monA.trecho + " DN " + monA.dn + " → trecho " + jusA.trecho + " DN " + jusA.dn + "): na rede de " + SISTEMAS[sistema].nome.toLowerCase() + " o DN não pode reduzir a jusante — corrija");
        }
        if (Math.abs(a.dn - b.dn) < 0.5) cx("luva", dnM); else cx("reducao", dnM, dnm);
        return out;
      }
      var tipo;
      if (dv <= 67.5) tipo = "joelho45"; else tipo = "joelho90";
      if (!((dv >= 35 && dv <= 55) || (dv >= 80 && dv <= 100))) avisos.push("mudança de direção de " + Math.round(dv) + "°: fora de 45°/90° — conexão de " + (tipo === "joelho45" ? "45°" : "90°") + " assumida, confira o traçado");
      if (tipo === "joelho90" && (sistema === "esgoto" || sistema === "pluvial") && !a.vertical && !b.vertical)
        avisos.push("joelho de 90° no trecho horizontal de " + SISTEMAS[sistema].nome.toLowerCase() + ": a NBR 8160 pede, no horizontal, peças de ângulo central até 45° — confira");
      /* ⚠ BASE DO TUBO DE QUEDA (frente 1b, 27/10/2026): a mudança vertical ↔ horizontal de 90° no esgoto/pluvial é CURVA de raio longo
         (curva90), não joelho — o joelho de raio curto na base do tubo de queda trava o escoamento. Só se a curva existe no catálogo do
         material e do DN; senão fica o joelho e o aviso. Na água continua joelho. */
      if (tipo === "joelho90" && (sistema === "esgoto" || sistema === "pluvial") && !!a.vertical !== !!b.vertical) {
        if (!conexaoNoCatalogo(maior.material, "curva90", dnM)) avisos.push("curva de raio longo DN " + dnM + " não está no catálogo do material: ficou joelho 90°");
        else {
          /* ⚠ A CURVA LONGA CABE? a perna da curva de raio longo é ~3× a do joelho (DN 100: 344 mm × 111 mm, cotas do produto): um trecho
             curto (a descida de 20–30 cm do aparelho, o toco do ramal) não a comporta — as bolsas se sobreporiam. Cada ramo tem de ter
             pelo menos a perna da curva; senão fica o joelho e o aviso diz por quê. Sem o comprimento (nó sintético) vale a regra. */
          var HGc2 = dep("HidGeo", "./biminstgeo.js"), cc2 = null; try { cc2 = HGc2 && HGc2.cotasConexao ? HGc2.cotasConexao(maior.material, "curva90", dnM) : null; } catch (eC2) { cc2 = null; }
          var perna = cc2 && cc2.z > 0 ? cc2.z / 1000 : 0;
          var curto = perna > 0 && [a, b].filter(function (r) { return isFinite(r.comprimento) && r.comprimento + 1e-6 < perna; })[0];
          if (curto) avisos.push("curva de raio longo DN " + dnM + " não cabe no trecho " + curto.trecho + " (" + Math.round(curto.comprimento * 100) + " cm < perna da curva " + Math.round(perna * 100) + " cm): ficou joelho 90°");
          else tipo = "curva90";
        }
      }
      cx(tipo, dnM);
      if (Math.abs(a.dn - b.dn) >= 0.5) cx("reducao", dnM, dnm);
      return out;
    }
    if (n === 3) {
      /* o par MAIS alinhado é a linha principal; o terceiro é a derivação */
      var par = null, best = 999;
      for (var i = 0; i < 3; i++) for (var j = i + 1; j < 3; j++) { var d = desvio(ramos[i].dir, ramos[j].dir); if (d < best) { best = d; par = [i, j]; } }
      var ia = par[0], ib = par[1], ic = 3 - ia - ib, ra = ramos[ia], rb = ramos[ib], rc = ramos[ic];
      if (best > 15) avisos.push("nó de três trechos sem dois alinhados (o mais próximo desvia " + Math.round(best) + "°): tê assumido, confira o traçado");
      var dnRun = Math.max(ra.dn, rb.dn);
      if (Math.abs(ra.dn - rb.dn) >= 0.5) cx("reducao", dnRun, Math.min(ra.dn, rb.dn));
      /* ângulo da derivação com a linha principal: ~90° = tê; ~45° = junção (esgoto/pluvial/ventilação) */
      var cosb = Math.abs(dot(rc.dir, ra.dir)), beta = grau(cosb);   /* 0..90 */
      var gravidade = sistema === "esgoto" || sistema === "pluvial" || sistema === "ventilacao";
      var ehJuncao = gravidade && beta >= 25 && beta <= 65;
      /* ⚠ JUNÇÃO SÓ A FAVOR DO FLUXO (frente A, 19/10/2026 — D-06 do diagnóstico): antes o |cos| fazia a derivação a 135°
         (entrando CONTRA o escoamento) virar "junção 45°" calada. Jusante da linha principal: a que DESCE do nó (geometria);
         em nível, a que COMEÇA no nó (p1 → p2 é o sentido do escoamento). O esgoto da derivação chega no nó no sentido −rc.dir:
         a favor do fluxo, ele aponta para a jusante (cos > 0) */
      if (ehJuncao && (sistema === "esgoto" || sistema === "pluvial")) {
        var dyR = ra.dir.y - rb.dir.y, jusR = Math.abs(dyR) > EPS_FLUXO ? (dyR < 0 ? ra : rb) : (ra.jus && !rb.jus ? ra : (rb.jus && !ra.jus ? rb : null));
        if (jusR && !rc.jus && dot(rc.dir, jusR.dir) > 0) {
          avisos.push("derivação de " + SISTEMAS[sistema].nome.toLowerCase() + " (trecho " + rc.trecho + ") entra CONTRA o fluxo da linha principal (a " + Math.round(180 - grau(Math.abs(dot(rc.dir, jusR.dir)))) + "° do escoamento): a junção de 45° só liga a favor do fluxo (NBR 8160) — refaça a ligação no sentido do escoamento; nenhuma conexão foi deduzida");
          return out;
        }
      }
      if (!gravidade && beta < 70) avisos.push("derivação a " + Math.round(beta) + "° da linha: na água e na elétrica o tê é de 90° — confira");
      var dnB = rc.dn;
      if (dnB > dnRun + 0.5) { cx(ehJuncao ? "juncao" : "te", dnB); cx("reducao", dnB, dnRun); }
      else if (dnB < dnRun - 0.5) {
        /* ⚠ JUNÇÃO DE REDUÇÃO (frente 1b, 27/10/2026): derivação de DN menor que a linha, no esgoto/pluvial/ventilação, é UMA peça
           (juncao_reducao DN "linha x derivação") quando o catálogo do fabricante a tem; sem ela fica a junção do DN da linha e o aviso
           (a redução entra à parte, no orçamento da junção composta). O tê de redução segue como sempre. */
        if (ehJuncao) {
          var chJ = txt(dnRun) + "x" + txt(dnB);
          if (conexaoNoCatalogo(maior.material, "juncao_reducao", chJ)) cx("juncao_reducao", dnRun, dnB);
          else { cx("juncao", dnRun, dnB); avisos.push("junção de redução DN " + dnRun + "x" + dnB + " não existe no catálogo: ficou a junção simples DN " + dnRun + " (a redução do ramal NÃO é contada à parte — orce-a)"); }
        } else cx("te_reducao", dnRun, dnB);
      }
      else cx(ehJuncao ? "juncao" : "te", dnRun);
      return out;
    }
    if (n === 4) {
      avisos.push("nó com quatro trechos (cruzeta): a SINAPI 06/2026 não tem cruzeta nesta tabela — desdobre em dois tês ou orce à parte");
      cx("cruzeta", maior.dn);
      return out;
    }
    avisos.push("nó com " + n + " trechos: desdobre a ligação — nenhuma conexão foi deduzida");
    return out;
  }

  /* ================================================================ PONTO DE ÁGUA, REGISTRO ROSCÁVEL, RESERVATÓRIO, TERMINAL
   * (27/10/2026, frente 1b-ii — decisões D1 a D4 da coordenação). Estas peças são deduzidas SÓ NA CONTAGEM (soQto, como a luva da ponta):
   * o 3D do ponto de água as desenha pelo MESMO resultado (ligacao.pontoAgua, js/biminstui.js) e as outras não têm peça própria na tela.
   *   D1  ponto de água de aparelho, tubo de PVC soldável: o tubo chega PARALELO à saída do ponto (|cos| > cos 45° com o eixo da saída) →
   *       ADAPTADOR soldável curto; senão → JOELHO 90° com BUCHA DE LATÃO. A bitola da rosca é a que o conector da família declara; senão a tabela
   *       RA (dados-fonte/hidro/pecas/rosca-ponto.json, "prática RA", confirmada pelo Rogério 27/10). A rosca adotada vira PREMISSA. CPVC/PPR:
   *       a peça de transição do material, se o catálogo tem ficha; senão aviso. Válvula/equipamento (sem rosca de aparelho): nada.
   *   D2  registro/válvula ROSCÁVEL em tubo soldável: 2 adaptadores (DN do tubo × rosca da tabela do catálogo para o DN).
   *   D3  tubo soldável ligado a porta de reservatório: ADAPTADOR COM FLANGE para caixa d'água, uma por porta (menos a da boia, que tem a torneira).
   *   D4  a ponta MAIS ALTA de um trecho vertical de ventilação: TERMINAL DE VENTILAÇÃO do DN, se o catálogo o tem. */
  var COS45 = Math.SQRT1_2;   // bim:geo cos 45°
  var NOMES_PONTO = { joelho_bucha: "Joelho 90° soldável com bucha de latão", luva_bucha: "Luva soldável com bucha de latão", adaptador: "Adaptador soldável curto com rosca", adaptador_caixa: "Adaptador soldável com flange para caixa d'água",
                      terminal_ventilacao: "Terminal de ventilação", transicao: "Peça de transição para rosca", joelho90_transicao: "Joelho 90° de transição para rosca" };
  function roscaNum(r) {
    var n = 0; txt(r).replace(/"/g, "").trim().split(/\s+/).forEach(function (p) { var m = p.split("/"); n += m.length === 2 ? Number(m[0]) / Number(m[1]) : Number(m[0]); });
    return isFinite(n) ? n : 0;
  }
  /* o DN nominal (mm) de cada bitola de rosca em polegada (NBR 5626: DN 15 = 1/2″, DN 20 = 3/4″ … DN 100 = 4″) — a torneira "DN 15" é a de rosca 1/2″ */
  var DN_DA_ROSCA = { "1/2": 15, "3/4": 20, "1": 25, "1 1/4": 32, "1 1/2": 40, "2": 50, "2 1/2": 65, "3": 80, "4": 100 };   // hid:ok DN nominal × polegada (NBR 5626)
  function dnDaRosca(r) { return DN_DA_ROSCA[txt(r).replace(/"/g, "").replace(/\s+/g, " ").trim()] || 0; }
  /* M3 (frente 1c): o ponto de água sem rosca (torneira longa, termostático, boia, aquecedor, bomba…) fica visível: a pendência diz qual aparelho e o que falta */
  function textoPontoSemRosca(p) {
    var HF = dep("HidFamilias", "./hidfamilias.js"), F = HF && HF.porId ? HF.porId(p.famId) : null;
    return "ponto de " + ((F && F.nome) || txt(p.famId) || "aparelho") + " (" + txt(p.famInst) + ") sem rosca padrão — peça de ligação a definir (nem a família nem a tabela RA declaram a bitola)";
  }
  /* as chaves "DNxROSCA" do tipo no catálogo do material (cotas lidas, letras brutas e peças sem cota) */
  function chavesDoCatalogo(material, tipo) {
    var GD = dep("HidGeoDados", "./biminstgeodados.js"), out = {};
    if (!GD) return [];
    ["conexoes", "conexoesBrutas"].forEach(function (q) { var m = GD[q] && GD[q][material]; if (m && m[tipo]) Object.keys(m[tipo]).forEach(function (k) { out[k] = 1; }); });
    arr(GD.semCota).forEach(function (r) { if (r && r.material === material && r.tipo === tipo && r.dn != null) out[txt(r.dn)] = 1; });
    return Object.keys(out);
  }
  /* a chave do catálogo para (DN do tubo, rosca): exata; senão a de MESMO DN com a rosca mais próxima (exata = false); senão null */
  function pecaDoCatalogo(material, tipo, dn, rosca) {
    var ks = chavesDoCatalogo(material, tipo).filter(function (k) { return k.split("x")[0] === txt(dn); });
    if (!ks.length) return null;
    var want = txt(dn) + "x" + txt(rosca);
    if (rosca != null && ks.indexOf(want) >= 0) return { chave: want, rosca: txt(rosca), exata: true };
    /* FRENTE 1c: sem a rosca exata, a MAIS PRÓXIMA ACIMA (rosca maior serve ao metal menor com a bucha; a menor não encaixa) — só sem nenhuma acima vai a mais próxima abaixo */
    var alvo = roscaNum(rosca), rn = function (k) { return roscaNum(k.split("x")[1]); };
    var acima = ks.filter(function (k) { return rn(k) >= alvo - 1e-9; }).sort(function (a, b) { return rn(a) - rn(b); }), abaixo = ks.filter(function (k) { return rn(k) < alvo - 1e-9; }).sort(function (a, b) { return rn(b) - rn(a); });
    var melhor = (acima.length ? acima : abaixo)[0];
    return { chave: melhor, rosca: melhor.split("x")[1] || "", exata: rosca == null };
  }
  function roscaPontoTabela() { var PC = dep("HidPecas", "./hidpecas.js"); return PC && PC.roscaPonto ? PC.roscaPonto() : null; }
  /* o aparelho do conector na tabela RA: pela família; senão pelo nome do tipo escolhido (torneira/misturador "para lavatório", "para tanque"…) */
  function aparelhoDaFamilia(T, fi) {
    if (!T || !fi) return null;
    if (T.familias && T.familias[fi.famId]) return T.familias[fi.famId];
    var HF = dep("HidFamilias", "./hidfamilias.js"), F = HF && HF.porId ? HF.porId(fi.famId) : null, tp = F ? arr(F.tipos).filter(function (x) { return x.id === fi.tipoId; })[0] : null, nome = tp ? txt(tp.nome) : "";
    var achou = null; arr(T.porNomeDoTipo).forEach(function (r) { if (!achou && new RegExp(r.re, "i").test(nome)) achou = r.aparelho; });
    return achou;
  }
  /* B5 (frente 1c): o CPVC com o tubo perpendicular também é joelho de transição (a SINAPI tem 89640/89644/89645); sem ficha no catálogo, a decisão cai na peça reta (abaixo) */
  var TIPO_TRANSICAO = { ppr: { reto: "transicao", curva: "joelho90_transicao" }, cpvc: { reto: "transicao", curva: "joelho90_transicao" } };
  /* decide o ponto de água do conector `con` onde chega o ramo `ramo` (um tubo). Devolve null (nada a deduzir) ou
     { semRosca } | { semTransicao, avisos } | { tipo, material, dn, rosca, chave, saida:[x,y,z], paralelo, premissa, avisos:[], semFicha } */
  function pontoAguaDe(con, ramo, estado) {
    var mat = ramo.material; if (mat !== "pvc_soldavel" && mat !== "ppr" && mat !== "cpvc") return null;
    var fi = arr(estado && estado.familias).filter(function (f) { return String(f.id) === String(con.famInst); })[0];
    if (!fi || con.origem === "acessorio" || !/^agua_/.test(con.sistema)) return null;
    /* A3 (frente 1c): a família de categoria `acessorio_tubo` (registro de pressão/gaveta, misturador DBC, união) NÃO é ponto de utilização — o registro de passagem não tem
       rosca de aparelho, e antes ganhava um joelho com bucha em CADA face e a premissa "rosca do ponto de água (chuveiro)" no memorial */
    var HFa = dep("HidFamilias", "./hidfamilias.js"), Fa = HFa && HFa.porId ? HFa.porId(fi.famId) : null;
    if (Fa && Fa.categoria === "acessorio_tubo") return null;
    var T = roscaPontoTabela(), sem = T && T.semPontoDeRosca ? arr(T.semPontoDeRosca.familias) : [];
    if (sem.indexOf(fi.famId) >= 0) return null;                                    /* válvula de descarga, mictório…: a rosca é do acessório */
    if (RESERV_FAM.test(fi.famId)) return null;                                     /* reservatório: adaptador com flange (D3) */
    var rosca = con.rosca ? txt(con.rosca) : null, origem = rosca ? "declarada pela família" : "", ap = null;
    if (!rosca) {
      ap = aparelhoDaFamilia(T, fi);
      if (ap && T.aparelhos && T.aparelhos[ap]) { rosca = txt(T.aparelhos[ap].rosca); origem = "tabela RA (" + T.aparelhos[ap].nome + "), " + txt(T.meta && T.meta.fonte); }
    }
    if (!rosca) return { semRosca: true, famId: fi.famId };                         /* sem rosca declarada nem na tabela: não se inventa */
    /* o eixo de saída: para onde o TUBO sai do ponto (a declaração da família, girada); sem ela, a normal da parede; sem ela, o giro da instância (Z local = fora da parede) */
    var w = con.dirTubo ? [con.dirTubo.x, con.dirTubo.y, con.dirTubo.z] : (con.parede ? [con.parede.x, 0, con.parede.z] : [-Math.sin(num(con.rotY, 0)), 0, -Math.cos(num(con.rotY, 0))]);
    var cosT = Math.abs(w[0] * ramo.dir.x + w[1] * ramo.dir.y + w[2] * ramo.dir.z), paralelo = cosT > COS45;
    var avisos = [], dn = txt(Math.round(num(ramo.dn, 0)));
    var o = { material: mat, dn: dn, saida: [-w[0], -w[1], -w[2]], paralelo: paralelo, avisos: avisos, rosca: rosca };
    if (mat === "pvc_soldavel") {
      /* A4 (frente 1c, decisão da coordenação): o ponto de utilização recebe o engate, o braço do chuveiro ou a torneira numa rosca FÊMEA. O adaptador soldável curto tem rosca MACHO
         (a SINAPI o chama "para registro"): o tubo que chega PARALELO à saída leva a LUVA SOLDÁVEL COM BUCHA DE LATÃO; o PERPENDICULAR continua o joelho com bucha. */
      o.tipo = paralelo ? "luva_bucha" : "joelho_bucha";
      var pc = pecaDoCatalogo(mat, o.tipo, dn, rosca);
      if (pc) { o.chave = pc.chave; o.rosca = pc.rosca; if (!pc.exata) avisos.push("ponto de água: " + NOMES_PONTO[o.tipo].toLowerCase() + " " + dn + " × " + rosca + "\" não existe no catálogo; usada a de mesmo DN mais próxima (" + pc.chave.replace("x", " × ") + "\") — confira a rosca do metal"); }
      else { o.chave = dn + "x" + rosca; o.semFicha = true; avisos.push("ponto de água: " + NOMES_PONTO[o.tipo].toLowerCase() + " DN " + dn + " não existe no catálogo dos fabricantes — a peça fica na lista sem ficha; confira o diâmetro do tubo"); }
    } else {
      var t0 = TIPO_TRANSICAO[mat][paralelo ? "reto" : "curva"], pc2 = pecaDoCatalogo(mat, t0, dn, rosca);
      if (!pc2 && t0 !== "transicao") { t0 = "transicao"; pc2 = pecaDoCatalogo(mat, t0, dn, rosca); }
      if (!pc2) return { semTransicao: true, material: mat, dn: dn, avisos: ["ponto de água em " + (MATERIAIS[mat] || {}).nome + ": peça de transição sem ficha — conferir"] };
      o.tipo = t0; o.chave = pc2.chave; o.rosca = pc2.rosca;
      if (!pc2.exata) avisos.push("ponto de água em " + (MATERIAIS[mat] || {}).nome + ": transição " + dn + " × " + rosca + "\" não existe no catálogo; usada " + pc2.chave.replace("x", " × ") + "\" — confira a rosca do metal");
    }
    o.premissa = "rosca do ponto de água " + (ap ? "(" + ap.replace(/_/g, " ") + ") " : "") + fi.id + " (" + fi.famId + "): " + o.rosca + "\" — " + (origem || "prática RA") + (o.rosca !== rosca ? "; pedida " + rosca + "\", usada a do catálogo" : "") + (/conferir/i.test(origem) ? "" : ". Conferir com o metal escolhido");
    return o;
  }
  /* a conexão "só na contagem" que o ponto produz (mesmo formato de uma conexão da rede) */
  function itemExtra(tipo, base, extra) {
    var c = { tipo: tipo, nome: NOMES_PONTO[tipo] || nomeConexao(tipo, base.material), sistema: base.sistema, material: base.material, aplicacao: base.aplicacao, dn: base.dn, dn2: base.dn2 || 0, soQto: true, extra: true };
    Object.keys(extra || {}).forEach(function (k) { c[k] = extra[k]; });
    return c;
  }
  var RESERV_FAM = /(^|-)(caixa-dagua|cisterna|reservatorio|tanque-ret-agua|tanque-cil-agua)/;
  /* o adaptador com flange que o Traçar do barrilete JÁ põe nos serviços da caixa (js/hidbarrilete.js orcamentoCaixa, rótulo "Barrilete · adaptador com flange DN …") */
  function incluidoNaCaixa(fi, dn, cid, pool) {
    /* M6 (frente 1c): o adaptador "incluso" casa pela PORTA/FURO, não pelo DN do rótulo. O barrilete põe nos serviços da caixa 1 adaptador por furo (saída, 2ª saída, extravasor, limpeza) e SOMA no
       mesmo serviço os de mesmo código (mesmo DN: viram UM serviço com fator = nº de furos e o rótulo do 1º). Então: o pool é a lista dos serviços "Barrilete · adaptador com flange DN …" da
       INSTÂNCIA (qualquer DN); cada porta ligada consome 1 (o serviço de DN igual primeiro, senão o primeiro com saldo) — 1 adaptador por furo, nunca 2, mesmo que o DN do tubo tenha sido trocado
       depois do barrilete (aí o aviso diz que o serviço da caixa ficou em outro DN). A porta que passa do saldo (furo a mais, posto à mão) é cobrada à parte. */
    if (!{ saida: 1, saida2: 1, extravasor: 1, limpeza: 1 }[cid]) return null;
    var k = txt(fi && fi.id);
    if (pool[k] == null) pool[k] = arr(fi && fi.servicos).filter(function (s) { return txt(s.rotulo).indexOf("Barrilete · adaptador com flange DN ") === 0; })
      .map(function (s) { var m = /flange DN (\d+)/.exec(txt(s.rotulo)); return { s: s, rest: num(s.fator, 1), dn: m ? m[1] : "" }; });
    var L = pool[k], pick = L.filter(function (x) { return x.rest >= 1 - 1e-9 && x.dn === txt(dn); })[0] || L.filter(function (x) { return x.rest >= 1 - 1e-9; })[0];
    if (!pick) return null;
    pick.rest--;
    return { rotulo: pick.s.rotulo, codigo: pick.s.codigo, dnServico: pick.dn, diverge: pick.dn !== txt(dn) };
  }

  function rede(estado, avaliarFam) {
    var inst = (estado && estado.instalacoes) || { trechos: [], pecas: [] };
    var trechos = arr(inst.trechos), pecas = arr(inst.pecas), acessorios = arr(inst.acessorios);
    var conectores = conectoresDoEstado(estado, avaliarFam);
    /* P12: as duas faces de cada acessório (registro, válvula) são pontos de ligação do tubo */
    acessorios.forEach(function (a) { a.conectores.forEach(function (k) { conectores.push(k); }); });
    /* ⚠ 25/10/2026: o QUADRO de distribuição (família com mep.peca "quadro") recebe os eletrodutos dos circuitos pela face
       (o "Circuitos e quadro" chega com cada um num ponto do topo da caixa — um eletroduto por circuito); a família só tem
       o conector do alimentador, e o Verificar das instalações dava cada eletroduto que chega no quadro como PONTA SOLTA
       (projeto exemplo: 9 erros). A ponta elétrica DENTRO da caixa do quadro (2 cm de folga) está ligada a ele. */
    var quadros = [];
    arr(estado && estado.familias).forEach(function (f) {
      if (!f || !/quadro/i.test(String(f.famId || "")) || typeof avaliarFam !== "function") return;
      var av = null; try { av = avaliarFam(f.famId, f.tipoId, f.inst || {}); } catch (eQ) { av = null; }
      if (av && av.mep && av.mep.peca === "quadro" && av.caixa && isFinite(av.caixa.x0)) quadros.push({ id: String(f.id), x: +f.x || 0, y: +f.y || 0, z: +f.z || 0, r: +f.rotY || 0, c: av.caixa });
    });
    function quadroEm(P) {
      for (var i = 0; i < quadros.length; i++) {
        var q = quadros[i], dx = P.x - q.x, dz = P.z - q.z, lx = dx * Math.cos(q.r) - dz * Math.sin(q.r), lz = dx * Math.sin(q.r) + dz * Math.cos(q.r), ly = P.y - q.y, f = 0.02;
        if (lx >= q.c.x0 - f && lx <= q.c.x1 + f && ly >= q.c.y0 - f && ly <= q.c.y1 + f && lz >= q.c.z0 - f && lz <= q.c.z1 + f) return q;
      }
      return null;
    }
    /* 1) as pontas */
    var pontas = [];
    trechos.forEach(function (t) {
      pontas.push({ t: t, lado: 0, p: t.p1, dir: unit(t.p1, t.p2) });
      pontas.push({ t: t, lado: 1, p: t.p2, dir: unit(t.p2, t.p1) });
    });
    /* 2) agrupa as pontas que se tocam (varredura por x: o(n log n) no caso comum) */
    var ord = pontas.map(function (_, i) { return i; }).sort(function (a, b) { return pontas[a].p.x - pontas[b].p.x; });
    var grupo = new Array(pontas.length), nos = [];
    ord.forEach(function (i, k) {
      if (grupo[i] != null) return;
      var g = nos.length; nos.push({ pontas: [i] }); grupo[i] = g;
      for (var m = k + 1; m < ord.length; m++) {
        var j = ord[m]; if (pontas[j].p.x - pontas[i].p.x > TOL) break;
        if (grupo[j] == null && dist(pontas[i].p, pontas[j].p) <= TOL) { grupo[j] = g; nos[g].pontas.push(j); }
      }
    });
    var conexoes = [], ligacoes = [], livres = [], continuacoes = [], avisosRede = [], usadosCon = {}, ligPeca = {}, nosRamos = [], juntas = [], luvasQto = [], extrasQto = [], pontosSemRosca = [], poolIncl = {};
    var porIdT = {}; trechos.forEach(function (t) { porIdT[t.id] = t; });
    /* A2: há outro tubo/ponta/conector da ventilação PERTO no prolongamento do trecho na ponta P, ou o esgoto encosta nela? (a regra de esperaPermitida) */
    function tvPerto(tc, P) {
      var q = dist(tc.p1, P) <= TOL ? tc.p2 : tc.p1;
      function enc(e) { var de = dist(e, P); if (de > PERTO_ESPERA || dist(e, q) <= TOL) return false; if (de <= TOL) return true; var u = unit(q, P), w = unit(P, e); return u.x * w.x + u.y * w.y + u.z * w.z >= ALINHADO_ESPERA; }
      var perto = trechos.some(function (o) {
        if (o.id === tc.id) return false;
        if (o.sistema === tc.sistema) { if (enc(o.p1) || enc(o.p2)) return true; var d = noInterior(P, o.p1, o.p2); return d != null && d <= PERTO_ESPERA; }
        if (o.sistema === "esgoto") { if (dist(o.p1, P) <= TOL || dist(o.p2, P) <= TOL) return true; var de = noInterior(P, o.p1, o.p2); return de != null && de <= TOL; }
        return false;
      });
      return perto || conectores.some(function (c) { return !usadosCon[c.id] && c.sistema === tc.sistema && enc(c); });
    }
    nos.forEach(function (no, k) {
      var p0 = pontas[no.pontas[0]].p, P = { x: 0, y: 0, z: 0 };
      no.pontas.forEach(function (i) { P.x += pontas[i].p.x; P.y += pontas[i].p.y; P.z += pontas[i].p.z; });
      P.x /= no.pontas.length; P.y /= no.pontas.length; P.z /= no.pontas.length;
      /* ramos por sistema (sistemas diferentes no mesmo ponto NÃO se ligam) */
      var porSis = {};
      no.pontas.forEach(function (i) {
        var pa = pontas[i], s = pa.t.sistema;
        (porSis[s] = porSis[s] || []).push({ trecho: pa.t.id, dir: pa.dir, dn: pa.t.dn || 0, material: pa.t.material, aplicacao: pa.t.aplicacao, vertical: pa.t.vertical, comprimento: pa.t.comprimento,
                                             lado: pa.lado, jus: pa.lado === 0, junta: pa.lado === 0 ? pa.t.juntaIni : pa.t.juntaFim, juntaMotivo: pa.t.juntaMotivo,
                                             pecaLinha: pa.lado === 0 ? pa.t.pecaIni : pa.t.pecaFim });
      });
      /* ponta caindo no MEIO de outro trecho do mesmo sistema: ele passa pelo nó (dois ramos) */
      trechos.forEach(function (t) {
        if (!porSis[t.sistema]) return;
        if (porSis[t.sistema].some(function (r) { return r.trecho === t.id; })) return;
        var d = noInterior(P, t.p1, t.p2);
        if (d != null && d <= TOL) {
          porSis[t.sistema].push({ trecho: t.id, dir: unit(t.p1, t.p2), dn: t.dn || 0, material: t.material, aplicacao: t.aplicacao, vertical: t.vertical, comprimento: t.comprimento, passante: true, jus: true });
          porSis[t.sistema].push({ trecho: t.id, dir: unit(t.p2, t.p1), dn: t.dn || 0, material: t.material, aplicacao: t.aplicacao, vertical: t.vertical, comprimento: t.comprimento, passante: true, jus: false });
        }
      });
      /* a ventilação que SAI DO MEIO de um ramal de esgoto, marcada "continua" (o tê da ventilação do ambiente,
         js/hidambiente.js — correção do Rogério, 18/10/2026): o ramal passa pelo nó e a derivação é a ventilação — o tê
         aparece no 3D e no quantitativo (antes a ponta só "continuava" e o tê não era contado) */
      if (porSis.ventilacao && porSis.ventilacao.length === 1 && Object.keys(porSis).length === 1) {
        var rv0 = porSis.ventilacao[0], tv0 = porIdT[rv0.trecho];
        var cand0 = tv0 && (tv0.continua === "ambos" || tv0.continua === (rv0.lado === 0 ? "p1" : "p2")) ? trechos.filter(function (t) { if (t.sistema !== "esgoto") return false; var d = noInterior(P, t.p1, t.p2); return d != null && d <= TOL; }) : [];
        /* ⚠ (frente A, 19/10/2026 — D-07 a): o tê só nasce no tubo de esgoto da TOMADA (o motor do ambiente grava qual é) ou, sem
           essa marca (tomada à mão, modelo antigo), num esgoto DEITADO com a ventilação SAINDO PARA CIMA dele (NBR 8160 4.3.16 b:
           acima do eixo). Antes, a ponta "continua" de ventilação que encostasse em QUALQUER esgoto (o tubo de queda, a descida de
           um aparelho, com a ventilação descendo) virava tê — as "conexões para baixo e para cima" vistas ao vivo */
        /* ⚠ (revisão adversarial, 20/10/2026) a tomada marcada nunca vira tê com a ventilação DESCENDO do esgoto: antes a marca bastava e a
           ventilação editada para baixo continuava tê — a "conexão para baixo" que a regra proíbe. Deitada vale: é a perna que o
           arrastar cria no pé da ventilação que ficou de pé (js/biminstarr.js, tools/test-bim-alinhar-inst.js) */
        var tes0 = tv0 && tv0.tomada && rv0.dir.y > -EPS_FLUXO ? cand0.filter(function (t) { return String(t.id) === String(tv0.tomada); })[0] || null : null;
        /* no tubo de queda (vertical) a coluna de ventilação liga subindo em aclive (NBR 8160 4.3.14 b — js/hidpredio.js); no esgoto
           deitado, só saindo PARA CIMA (acima do eixo). Ventilação que DESCE até o esgoto nunca é tomada */
        if (!tes0 && rv0.dir.y > EPS_FLUXO) tes0 = cand0.filter(function (t) { var dh = Math.sqrt(Math.pow(t.p2.x - t.p1.x, 2) + Math.pow(t.p2.z - t.p1.z, 2)); return Math.abs(t.p2.y - t.p1.y) >= dh || rv0.dir.y >= SOBE_TOMADA; })[0] || null;
        if (tes0) {
          porSis.esgoto = [{ trecho: tes0.id, dir: unit(tes0.p1, tes0.p2), dn: tes0.dn || 0, material: tes0.material, aplicacao: tes0.aplicacao, vertical: tes0.vertical, passante: true, jus: true },
                           { trecho: tes0.id, dir: unit(tes0.p2, tes0.p1), dn: tes0.dn || 0, material: tes0.material, aplicacao: tes0.aplicacao, vertical: tes0.vertical, passante: true, jus: false }, rv0];
          delete porSis.ventilacao;
        }
      }
      var sisNo = Object.keys(porSis);
      /* JUNÇÃO esgoto × ventilação declarada (PROJETO INTELIGENTE etapa 3, js/hidpredio.js): o ventilador primário que sai do
         topo do tubo de queda — toda ponta de ventilação no nó marcada "continua" (segue na peça de junção) não é "misturado" */
      var juncaoEV = sisNo.length === 2 && porSis.esgoto && porSis.ventilacao && porSis.ventilacao.every(function (r) { var tt = porIdT[r.trecho]; return !r.passante && tt && (tt.continua === "ambos" || tt.continua === (r.lado === 0 ? "p1" : "p2")); });
      if (sisNo.length > 1 && !juncaoEV) avisosRede.push({ x: r4(P.x), y: r4(P.y), z: r4(P.z), texto: "sistemas diferentes se tocam no mesmo ponto (" + sisNo.map(function (s) { return SISTEMAS[s].nome; }).join(" × ") + "): não se ligam" });
      sisNo.forEach(function (s) {
        var ramos = porSis[s], av = [];
        nosRamos.push(ramos.map(function (r) { return r.trecho; }));   /* P12: quem está ligado a quem (nome/numeração de sistema) */
        /* peça (ralo, caixa) com o nó dentro do cilindro de captura: ligado, sem conexão */
        var pc = null; pecas.forEach(function (q) { if (!pc && q.sistema === s && dentroHub(P, q.hub)) pc = q; });
        if (!pc) pecas.forEach(function (q) { if (!pc && dentroHub(P, q.hub) && q.sistema !== s) av.push("tubo de " + SISTEMAS[s].nome.toLowerCase() + " terminando em " + PECAS[q.peca].nome.toLowerCase() + " de " + SISTEMAS[q.sistema].nome.toLowerCase()); });
        if (pc) {
          ramos.forEach(function (r) { ligacoes.push({ trecho: r.trecho, alvo: pc.id, tipo: "peca", x: r4(P.x), y: r4(P.y), z: r4(P.z) }); });
          ligPeca[pc.id] = (ligPeca[pc.id] || 0) + ramos.length;
          /* LIGAÇÃO ELÉTRICA (21/10/2026): o DISPOSITIVO (luminária, interruptor, tomada) cujo ponto está DENTRO da caixa elétrica
             em que o eletroduto chega está ligado por ela — a caixa é o ponto dele (antes ficava "ponto sem tubo") */
          if (grupoDe(s) === "eletrica") conectores.forEach(function (c) { if (!usadosCon[c.id] && c.sistema === s && dentroHub(c, pc.hub)) { usadosCon[c.id] = 1; ligacoes.push({ trecho: ramos[0].trecho, alvo: c.id, famInst: c.famInst, tipo: "aparelho", pelaCaixa: pc.id, x: c.x, y: c.y, z: c.z }); } });
          return;
        }
        var con = null;
        if (ramos.length === 1) conectores.forEach(function (c) { if (!con && !usadosCon[c.id] && dist(c, P) <= TOL_CONECTOR) con = c; });
        if (con && con.sistema !== s) { av.push("tubo de " + SISTEMAS[s].nome.toLowerCase() + " no ponto de " + SISTEMAS[con.sistema].nome.toLowerCase() + " do aparelho"); con = null; }
        var ligCon = null;
        if (con) { usadosCon[con.id] = 1; ligCon = { trecho: ramos[0].trecho, alvo: con.id, famInst: con.famInst, tipo: con.origem === "acessorio" ? "acessorio" : "aparelho", x: con.x, y: con.y, z: con.z }; ligacoes.push(ligCon); }
        var cxs = decidir(ramos, s, con, av);
        /* D1 / D3 (27/10/2026, frente 1b-ii): o ponto de água do aparelho e o adaptador com flange do reservatório — só na contagem; o 3D lê ligCon.pontoAgua */
        if (con && ramos.length === 1 && con.origem !== "acessorio" && /^agua_/.test(s)) {
          var fiC = arr(estado && estado.familias).filter(function (f) { return String(f.id) === String(con.famInst); })[0], cidC = txt(con.id).split(":").slice(1).join(":");
          var baseC = { sistema: s, material: ramos[0].material, aplicacao: ramos[0].aplicacao, dn: ramos[0].dn }, exC = { id: "pa:" + con.id, ramos: [ramos[0].trecho], x: r4(P.x), y: r4(P.y), z: r4(P.z) };
          if (fiC && RESERV_FAM.test(fiC.famId)) {
            if (ramos[0].material === "pvc_soldavel" && !/^(entrada|alimentacao)/.test(cidC) && con.porta !== "alimentacao") {
              var pcR = pecaDoCatalogo("pvc_soldavel", "adaptador_caixa", txt(Math.round(num(ramos[0].dn, 0))), null);
              if (pcR) {
                var incl = incluidoNaCaixa(fiC, txt(Math.round(num(ramos[0].dn, 0))), cidC, poolIncl);
                exC.id = "ac:" + con.id; exC.dn2 = pcR.rosca;
                if (incl && incl.diverge) av.push("o serviço da caixa " + fiC.id + " tem o adaptador com flange DN " + incl.dnServico + " e o tubo desta porta está em DN " + baseC.dn + " — refaça o Montar barrilete para o serviço acompanhar o tubo (o orçamento não cobra o adaptador duas vezes)");
                /* o adaptador com flange é SEMPRE reservação, qualquer que seja a aplicação do tubo que chega (a SINAPI só o tem em reservação) */
                extrasQto.push(itemExtra("adaptador_caixa", Object.assign({}, baseC, { aplicacao: "reservacao" }), Object.assign(exC, incl ? { incluso: "já contado nos serviços da caixa " + fiC.id + " (\"" + txt(incl.rotulo) + "\", SINAPI " + txt(incl.codigo) + "): a lista mostra a peça, o orçamento não a soma outra vez", inclusoCodigo: txt(incl.codigo) } : {})));
              } else av.push("adaptador com flange DN " + baseC.dn + " (reservatório " + fiC.id + ") não existe no catálogo dos fabricantes — confira o diâmetro do tubo");
            } else if (ramos[0].material === "pvc_soldavel" && (/^(entrada|alimentacao)/.test(cidC) || con.porta === "alimentacao")) {
              /* M5 (frente 1c): a ENTRADA do reservatório (a torneira de boia) também leva o adaptador soldável curto × rosca da boia — o orçamento da caixa (barrilete) só traz a boia e a fita;
                 contado AQUI, uma vez por entrada ligada (a rede e o barrilete passam pelo mesmo nó). A bitola da boia = a de referência do DN do tubo (NBR 5648), a mesma do barrilete. */
              var dnBo = txt(Math.round(num(ramos[0].dn, 0))), pcB = pecaDoCatalogo("pvc_soldavel", "adaptador", dnBo, BITOLA_REF.pvc_soldavel[dnBo] || null);
              if (pcB) {
                exC.id = "ab:" + con.id; exC.dn2 = pcB.rosca; exC.chave = pcB.chave;
                exC.premissa = "adaptador soldável curto × rosca da torneira de boia de " + fiC.id + ": DN " + dnBo + " × " + pcB.rosca + "\" — a bitola da boia é a de referência do DN (NBR 5648); conferir com a boia escolhida";
                extrasQto.push(itemExtra("adaptador", Object.assign({}, baseC, { aplicacao: "reservacao" }), exC));
              } else av.push("adaptador soldável × rosca da torneira de boia DN " + dnBo + " (reservatório " + fiC.id + ") não existe no catálogo dos fabricantes — confira o diâmetro do tubo");
            }
          } else {
            var paD = pontoAguaDe(con, ramos[0], estado);
            if (paD && paD.semRosca) pontosSemRosca.push({ famInst: con.famInst, famId: paD.famId, conector: con.id, x: r4(P.x), y: r4(P.y), z: r4(P.z) });
            else if (paD && paD.semTransicao) paD.avisos.forEach(function (t) { av.push(t); });
            else if (paD) {
              paD.avisos.forEach(function (t) { av.push(t); });
              /* M1 (frente 1c): a peça do ponto (luva/joelho com bucha DN do tubo × rosca) JÁ faz a transição do tubo ao aparelho: a redução que o conector pediria (torneira DN 15 em tubo 25 →
                 "redução 25×15", que nem existe em PVC soldável) não entra — só quando o DN do conector cabe na bitola da rosca adotada */
              cxs = cxs.filter(function (c) { return !(c.tipo === "reducao" && num(con.dn, 0) > 0 && num(con.dn, 0) <= dnDaRosca(paD.rosca)); });
              if (ligCon) ligCon.pontoAgua = { tipo: paD.tipo, material: paD.material, dn: Number(paD.dn), rosca: paD.rosca, chave: paD.chave, saida: paD.saida, paralelo: paD.paralelo, semFicha: !!paD.semFicha };
              exC.dn2 = paD.rosca; exC.premissa = paD.premissa; exC.chave = paD.chave; exC.semFicha = !!paD.semFicha;
              extrasQto.push(itemExtra(paD.tipo, baseC, exC));
            }
          }
        }
        /* QV1: a luva onde a conexão entrega PONTA. Decisão da coordenação (18/10/2026, noite): a luva faltava no ORÇAMENTO —
           correção de erro de quantitativo, vale para TODOS; sem a prévia hidro ela entra SÓ na contagem (luvasQto: qto e
           orçamento), sem peça no 3D, sem junta no tubo e sem aviso — a geometria nova segue atrás da prévia (P8) */
        var soQto = null;
        if (previaHidro()) juntasDaPonta(cxs, ramos, s, av).forEach(function (j) { juntas.push(j); });
        else { var cq = cxs.slice(); juntasDaPonta(cq, ramos, s, []); soQto = cq.slice(cxs.length); }
        var qdE = ramos.length === 1 && !con && grupoDe(s) === "eletrica" ? quadroEm(P) : null;
        if (qdE) ligacoes.push({ trecho: ramos[0].trecho, alvo: qdE.id + ":quadro", famInst: qdE.id, tipo: "aparelho", x: r4(P.x), y: r4(P.y), z: r4(P.z) });
        else if (ramos.length === 1 && !con) {
          var tc = porIdT[ramos[0].trecho], ponta = tc && tc.continua ? (dist(tc.p1, P) <= TOL ? "p1" : (dist(tc.p2, P) <= TOL ? "p2" : "")) : "";
          if (ponta && (tc.continua === "ambos" || tc.continua === ponta)) continuacoes.push({ trecho: ramos[0].trecho, ponta: ponta, x: r4(P.x), y: r4(P.y), z: r4(P.z) });
          else {
            /* D4 (27/10/2026): a ponta MAIS ALTA de um trecho VERTICAL de ventilação (o prolongamento acima da cobertura) fecha com o TERMINAL DE VENTILAÇÃO do DN,
               se o catálogo do material o tem; senão fica ponta solta e o aviso diz por quê. Esgoto e água NÃO ganham cap: ponta livre deles é desconexão. */
            /* A2 (frente 1c, revisão adversarial): o terminal SÓ fecha onde a ponta é espera permitida — a MESMA regra de esperaPermitida (conectividade): nenhum outro
               tubo, ponta ou conector da ventilação PERTO no prolongamento (um tubo que parou 5 cm antes da coluna continua ponta solta, nunca "terminal") e a ponta
               não encosta em esgoto. Antes, toda ponta vertical de ventilação deixada solta virava terminal cobrado e sumia de pontasLivres. */
            var tvD = s === "ventilacao" && ramos[0].vertical && ramos[0].dir.y < -0.5 && !tvPerto(tc, P), fechou = false;
            if (tvD) {
              var dnTv = txt(Math.round(num(ramos[0].dn, 0))), pcT = pecaDoCatalogo(ramos[0].material, "terminal_ventilacao", dnTv, null);
              if (pcT) {
                fechou = true;
                extrasQto.push(itemExtra("terminal_ventilacao", { sistema: s, material: ramos[0].material, aplicacao: "ventilacao", dn: Number(dnTv) }, { id: "tv:" + ramos[0].trecho + ":" + (dist(tc.p1, P) <= TOL ? "p1" : "p2"), ramos: [ramos[0].trecho], x: r4(P.x), y: r4(P.y), z: r4(P.z) }));
              } else av.push("ponta de ventilação sem terminal: o terminal de ventilação DN " + dnTv + " de " + ((MATERIAIS[ramos[0].material] || {}).nome || ramos[0].material) + " não existe no catálogo — escolha outro DN/material ou orce à parte");
            }
            if (!fechou) livres.push({ trecho: ramos[0].trecho, x: r4(P.x), y: r4(P.y), z: r4(P.z) });
          }
        }
        cxs.forEach(function (c, m) {
          c.id = "cx" + k + (sisNo.length > 1 ? s.slice(0, 2) : "") + (cxs.length > 1 ? "-" + m : "");
          c.x = r4(P.x); c.y = r4(P.y); c.z = r4(P.z);
          c.ramos = ramos.map(function (r) { return r.trecho; }).filter(function (v, i2, a2) { return a2.indexOf(v) === i2; });
          c.nome = nomeConexao(c.tipo, c.material);
          conexoes.push(c);
        });
        (soQto || []).forEach(function (c, m) {
          c.id = "cx" + k + (sisNo.length > 1 ? s.slice(0, 2) : "") + "-lq" + m; c.soQto = true;
          c.x = r4(P.x); c.y = r4(P.y); c.z = r4(P.z); c.ramos = [c.juntaDe]; c.nome = nomeConexao(c.tipo, c.material);
          luvasQto.push(c);
        });
        av.forEach(function (a) { avisosRede.push({ x: r4(P.x), y: r4(P.y), z: r4(P.z), texto: a }); });
      });
    });
    /* D2 (27/10/2026, frente 1b-ii): registro/válvula ROSCÁVEL (variante `rosca: true`) em tubo de PVC SOLDÁVEL → 2 adaptadores soldável × rosca (um por face),
       DN do tubo × a rosca que o catálogo dá para o DN; sem peça nesse DN, a do DN mais próximo e o aviso. Variante soldável: nada. */
    var porIdTr = {}; trechos.forEach(function (t) { porIdTr[t.id] = t; });
    acessorios.forEach(function (a) {
      var Aa = ACESSORIOS[a.acessorio], Va = Aa && Aa.variantes[a.variante];
      if (!Va || !Va.rosca || a.material !== "pvc_soldavel") return;
      /* M4 (frente 1c): só a face com TUBO ligado leva adaptador (acessório solto, sem tubo, não gera nenhum); a válvula de pé com crivo tem 1 só rosca ligada (o crivo fica na água) */
      var facesA = [["ad1", a.a, a.id + ":e"], ["ad2", a.b, a.id + ":s"]].filter(function (f) { return usadosCon[f[2]]; });
      if (a.variante === "pe_crivo") facesA = facesA.slice(0, 1);
      if (!facesA.length) return;
      /* a rosca do registro = a bitola de referência do DN (BITOLA_REF, NBR 5648: 25 → 3/4", 50 → 1 1/2"…), que é a rosca do registro de latão/PVC do DN */
      var dnA = txt(Math.round(num(a.dn, 0))), pcA = pecaDoCatalogo("pvc_soldavel", "adaptador", dnA, BITOLA_REF.pvc_soldavel[dnA] || null), nota = null;
      if (!pcA) {
        var dnsA = chavesDoCatalogo("pvc_soldavel", "adaptador").map(function (k) { return k.split("x")[0]; }).filter(function (v, i, q) { return q.indexOf(v) === i; })
          .sort(function (x, y) { return Math.abs(Number(x) - num(a.dn, 0)) - Math.abs(Number(y) - num(a.dn, 0)); });
        if (dnsA.length) { pcA = pecaDoCatalogo("pvc_soldavel", "adaptador", dnsA[0], null); nota = "o adaptador soldável × rosca DN " + dnA + " não existe no catálogo; usado o de DN " + dnsA[0] + " (mais próximo) — confira"; }
      }
      if (!pcA) { avisosRede.push({ x: a.centro.x, y: a.centro.y, z: a.centro.z, texto: Aa.nome.toLowerCase() + " " + a.id + ": adaptadores soldável × rosca DN " + dnA + " sem peça no catálogo — orce à parte" }); return; }
      if (nota) avisosRede.push({ x: a.centro.x, y: a.centro.y, z: a.centro.z, texto: Aa.nome.toLowerCase() + " " + a.id + ": " + nota });
      var tA = a.trecho != null ? porIdTr[a.trecho] : null, baseA = { sistema: a.sistema, material: "pvc_soldavel", aplicacao: (tA && tA.aplicacao) || aplicacaoAuto(a.sistema, !!a.vertical), dn: num(a.dn, 0) };
      facesA.forEach(function (f) {
        extrasQto.push(itemExtra("adaptador", baseA, { id: a.id + ":" + f[0], ramos: [], x: f[1].x, y: f[1].y, z: f[1].z, dn2: pcA.rosca, chave: pcA.chave,
          premissa: "adaptadores do " + Aa.nome.toLowerCase() + " " + a.id + " (" + Va.rot + "): DN " + dnA + " × " + pcA.rosca + "\" — a rosca do catálogo para o DN do tubo; conferir com o registro escolhido" }));
      });
    });
    /* pontos de aparelho sem tubo: o projeto ainda não ligou aquele aparelho */
    /* D5 (27/10/2026, frente 1b-ii): a porta que a família declara `opcional` (ventilação do reservatório, bocas extras da caixa sifonada) sem tubo NÃO é
       desconexão nem pendência — só a porta opcional LIGADA entra na rede (usadosCon), como as outras */
    var semLigacao = conectores.filter(function (c) { return !usadosCon[c.id] && !c.opcional; });
    /* QUALIDADE VISUAL 2: o que a vista de problemas MARCA no 3D — o ponto sem tubo de um sistema que o
       projeto nem traçou (água quente do lavatório numa casa sem aquecimento, o ponto do aparelho antes de
       qualquer tubo) é estado do projeto, não defeito: fica na lista, sem marca vermelha em cima da louça */
    var emUso = {}; trechos.forEach(function (t) { emUso[t.sistema] = 1; });
    var marcar = semLigacao.filter(function (c) { return emUso[c.sistema]; });
    /* ⚠ PRIORIDADE 21/10/2026: o CORPO da caixa sifonada / do ralo acompanha a cota da tubulação ligada e o PROLONGADOR enche até o
       porta-grelha no piso (js/biminstgeo.js corpoPeca — a mesma conta do 3D, do orçamento e da conferência da laje) */
    var HGc = dep("HidGeo", "./biminstgeo.js");
    if (HGc && HGc.corpoPeca) {
      var porIdR = {}; trechos.forEach(function (t) { porIdR[t.id] = t; });
      pecas.forEach(function (q) {
        if (!/^(ralo_|caixa_sifonada)/.test(q.peca)) return;
        var lig = ligacoes.filter(function (l) { return l.tipo === "peca" && l.alvo === q.id; }).map(function (l) {
          var t = porIdR[l.trecho]; if (!t) return null;
          var e = dist(t.p1, l) <= dist(t.p2, l) ? t.p1 : t.p2, f = e === t.p1 ? t.p2 : t.p1;
          return { trecho: t.id, dn: t.dn, ponto: e, dir: [f.x - e.x, f.y - e.y, f.z - e.z] };
        }).filter(Boolean);
        try { var cp = HGc.corpoPeca(q, lig); if (cp) q.corpo = { base: r4(cp.base), baseCatalogo: r4(cp.baseCatalogo), prolongador: r4(cp.prolongador), diam: cp.diam, porTrecho: cp.porTrecho }; } catch (eCp) {}
      });
    }
    return { trechos: trechos, pecas: pecas, conectores: conectores, conexoes: conexoes, ligacoes: ligacoes, pontasLivres: livres, continuacoes: continuacoes,
             conectoresLivres: semLigacao, conectoresMarcar: marcar, ligacoesPeca: ligPeca, avisos: avisosRede, acessorios: acessorios, nosRamos: nosRamos, juntas: juntas, luvasQto: luvasQto, extrasQto: extrasQto, pontosSemRosca: pontosSemRosca };
  }

  /* ================================================ JUNTAS NA PONTA (QV1, pedido do Rogério, 17/10/2026)
   * Joelho, tê e junção de esgoto saem de fábrica com PONTA a jusante (desenho cotado da ficha). O tubo que segue
   * NÃO tem de ter bolsa ("às vezes você já usou a bolsa, está com um pedaço de cano"): o PADRÃO é uma LUVA de
   * verdade — conexão no quantitativo — com a bolsa recebendo o que vem de montante. Por junta (no trecho que sai):
   *   "luva" (padrão) · "bolsa" (bolsa do próprio tubo: a luva some) · "invertida" (luva contra o fluxo: aviso).
   * Quem diz se a conexão tem ponta é a geometria (js/biminstgeo.js, HidGeo.temPonta); sem ela, nada muda.
   * Jusante = o trecho que COMEÇA no nó (o esgoto escoa de p1 para p2), com pelo menos um que chega. */
  var JUNTAS = { luva: "Luva (padrão)", bolsa: "Bolsa do próprio tubo", invertida: "Luva invertida (contra o fluxo)" };
  function juntasDaPonta(cxs, ramos, sistema, avisos) {
    var HG = dep("HidGeo", "./biminstgeo.js"), out = [];
    if (!HG || !HG.temPonta || !SISTEMAS[sistema] || !SISTEMAS[sistema].gravidade && sistema !== "ventilacao") return out;
    var princ = cxs.filter(function (c) { return c.tipo !== "reducao" && c.tipo !== "luva"; })[0];
    /* PARIDADE (18/10/2026): a redução EXCÊNTRICA de esgoto (o produto) tem PONTA no lado maior: sozinha no nó, ela também
       entrega ponta — a luva só entra se o trecho de jusante é o do DN maior */
    var soRed = !princ && cxs.length === 1 && cxs[0].tipo === "reducao" ? cxs[0] : null;
    if (soRed) princ = soRed;
    if (!princ || !HG.temPonta(princ.material, princ.tipo, princ.dn)) return out;
    var jus = ramos.filter(function (r) { return !r.passante && r.lado === 0; }), mon = ramos.filter(function (r) { return !r.passante && r.lado === 1; });
    if (jus.length !== 1 || !mon.length) return out;
    if (soRed && Math.abs((+jus[0].dn || 0) - (+soRed.dn || 0)) > 0.5) return out;
    var r = jus[0], j = JUNTAS[r.junta] ? r.junta : "luva";
    out.push({ trecho: r.trecho, lado: 0, junta: j, dn: r.dn, material: r.material, principal: princ.tipo });
    if (j === "bolsa") return out;
    cxs.push({ tipo: "luva", sistema: sistema, material: r.material, aplicacao: r.aplicacao || princ.aplicacao, dn: r.dn, dn2: 0,
               juntaDe: r.trecho, juntaLado: 0, invertida: j === "invertida" });
    if (j === "invertida") avisos.push("luva INVERTIDA (contra o fluxo) entre a ponta da conexão (" + nomeConexao(princ.tipo, princ.material).toLowerCase() + ") e o trecho " + r.trecho +
      (r.juntaMotivo ? " — motivo registrado: " + r.juntaMotivo : ": confirme o motivo (Propriedades da junta)"));
    return out;
  }

  /* ========================================================= SINAPI
   * O item (tubo, conexão ou peça) → a composição da tabela gerada, ou
   * "pendente" com o motivo. Desempate DECLARADO quando a chave tem mais de
   * uma: (1) os extras do item (PN do PPR; classe e isolamento do cobre;
   * bitola e isolamento do duto) têm de bater — no TUBO; na conexão o PN é
   * ignorado (a conexão de PPR é PN 25 e serve ao tubo PN 20); (2) a
   * variante: redução entre dois tubos = LUVA de redução, depois bucha
   * curta, depois longa; luva comum antes da "passante"; (3) o menor código.
   * Quantas alternativas havia vai junto (a tela mostra). */
  var VAR_PREF = { "": 0, luva: 1, curta: 2, longa: 3, passante: 4, curva: 1, cotovelo: 2 };   /* P12: eletrocalha — a curva horizontal antes do cotovelo */
  function tabela() { return dep("BimInstSinapi", "./biminstsinapi.js"); }
  /* a aplicação na chave leva o SISTEMA ("esgoto:ramal" × "pluvial:ramal"):
     o mesmo tubo série R tem composição no pluvial e não no esgoto. A
     ventilação usa a do esgoto ("prumada de esgoto sanitário OU ventilação").
     Ralo, caixa sifonada e caixa elétrica já são separados pela peça. */
  var GRUPO_TABELA = { agua: "agua", esgoto: "esgoto", ventilacao: "esgoto", pluvial: "pluvial", eletrica: "eletrica" };
  /* FRENTE 1c (27/10/2026): a bucha, a bucha longa e a luva de redução são a MESMA composição SINAPI da redução (o gerador já as classifica como `reducao`,
     BUCHA DE REDUÇÃO e LUVA DE REDUÇÃO); a junção de redução idem com a junção. A rosca em polegada normaliza "1.1/4" → "1 1/4" (a SINAPI escreve de um jeito,
     o catálogo de outro). O ADAPTADOR COM FLANGE é SEMPRE reservação, seja qual for a aplicação do tubo que chega (a SINAPI só tem o flange em reservação). */
  var APELIDO_CHAVE = { juncao_reducao: "juncao", bucha: "reducao", bucha_longa: "reducao", luva_reducao: "reducao" };
  function chaveSinapi(item) {
    var dn2k = item.dn2 ? txt(item.dn2).replace(/\./g, " ").replace(/\s+/g, " ").trim() : "";
    var dnk = item.peca === "tubo" && item.material === "duto_chapa" ? "-" : txt(item.dn) + (dn2k ? "x" + dn2k : "");
    var ap = item.peca === "adaptador_caixa" ? "reservacao" : item.aplicacao, gt = GRUPO_TABELA[grupoDe(item.sistema)];
    if (!PECAS[item.peca] && !ACESSORIOS[item.peca] && !DISPOSITIVOS[item.peca] && gt) ap = gt + ":" + ap;
    /* ⚠ a SINAPI chama a junção de redução de "JUNÇÃO SIMPLES … DN 100 X 50 MM": é a MESMA peça, na chave "juncao" com o DN composto
       (a tabela já a tem). Sem este apelido a junção de redução deduzida (frente 1b, 27/10/2026) saía "pendente" do orçamento. */
    return [APELIDO_CHAVE[item.peca] || item.peca, item.material, ap, dnk].join("|");
  }
  function rotuloItem(item) {
    if (ACESSORIOS[item.peca] || DISPOSITIVOS[item.peca]) return rotuloP12(item);   /* P12 */
    if (item.peca === "cabo") return "Cabo de cobre flexível isolado " + String(item.dn).replace(".", ",") + " mm² " + (item.material === "cobre_450_750" ? "450/750 V" : item.material) + ", circuitos terminais";   /* ligação elétrica */
    var M = MATERIAIS[item.material], P = PECAS[item.peca];
    if (P && item.nome) return item.nome + (SISTEMAS[item.sistema] ? " — " + SISTEMAS[item.sistema].nome.toLowerCase() : "");   /* pendências finais: a caixa de inspeção pelo tipo */
    if (item.peca === "tubo") return (M ?(M.secao === "retangular" ? M.nome + " " + Math.round(item.larg * 100) + "×" + Math.round(item.alt * 100) + " cm" : M.nome + " DN " + item.dn) : item.material) + aplRot(item);
    if (P) return P.nome + (item.dn && item.dn !== "-" ? " " + item.dn : "") + (item.material === "metalica" ? " metálica" : "") + (item.aplicacao && P.sistemas[0] === "eletrica" && item.peca !== "caixa_octogonal" ? " (" + item.aplicacao + ")" : "") + (P.sistemas[0] !== "eletrica" ? " — " + SISTEMAS[item.sistema].nome.toLowerCase() : "");
    return nomeConexao(item.peca, item.material) + " " + (M ? M.nome : item.material) + " DN " + item.dn + (item.dn2 ? " × " + item.dn2 : "") + aplRot(item);
  }
  function aplRot(item) {
    var g = grupoDe(item.sistema), a = (APLICACOES[g] || {})[item.aplicacao];
    return a ? " — " + a.toLowerCase() + " (" + (SISTEMAS[item.sistema] ? SISTEMAS[item.sistema].nome.toLowerCase() : "") + ")" : "";
  }
  var SUBSTITUTO_SINAPI = { curva90: "joelho90", curva45: "joelho45" };
  /* B3 (frente 1c): o sufixo da referência de mercado é o do SISTEMA da curva (o pluvial série R não é o esgoto série normal) */
  /* FRENTE 1g (27/10/2026): a chave "<tipo>|<material>|<DN[xDN2]>" é a que a tabela de insumos (js/biminstsinapi.js, `insumos`) e a referência de mercado das
     peças sem composição usam. A curva de ESGOTO/PLUVIAL segue com o id da coleta ("curva90_esgoto|150"); a curva soldável de ÁGUA (PVC soldável, CPVC) NUNCA pega o
     preço de curva de esgoto (colisão B3 apontada pela coleta): usa a chave genérica, que só existe se alguém coletar o preço dela. */
  var MAT_ESGOTO_CURVA = { pvc_esgoto: 1, pvc_serie_r: 1, pvc_esgoto_enterrado: 1 };
  function dnChave(item) { var dn2k = item.dn2 ? txt(item.dn2).replace(/\./g, " ").replace(/\s+/g, " ").trim() : ""; return txt(item.dn) + (dn2k ? "x" + dn2k : ""); }
  function chaveMat(item) { return [item.peca, item.material, dnChave(item)].join("|"); }
  function idMercadoCurva(item) {
    if (item.material && !MAT_ESGOTO_CURVA[item.material]) return chaveMat(item);
    return item.peca + "_" + (item.sistema === "pluvial" ? "pluvial" : "esgoto") + "|" + txt(item.dn);
  }
  /* a MÃO DE OBRA da composição SINAPI da peça ANÁLOGA (escolhida pelo gerador: mesmo material, DN igual ou o imediatamente acima, mesma aplicação) para o item que
     leva insumo ou referência de mercado. null = o item não está na lista; { falta: true } = está, mas não há composição análoga (pendência visível) */
  function moAnalogaDe(item) {
    var T = tabela(); if (!T || !T.insumos || !item || !item.peca || !item.material) return null;
    var e = T.insumos[chaveMat(item)]; if (!e) return null;
    var gt = GRUPO_TABELA[grupoDe(item.sistema)], m = e.mo ? e.mo[gt + ":" + item.aplicacao] : null;
    if (!m) return { falta: true, texto: "instalação sem composição análoga (a SINAPI não tem peça análoga de DN igual ou acima em " + gt + ":" + item.aplicacao + ")" };
    return { codigo: m[0], descricao: m[1], observacao: m[2], texto: "mão de obra da composição " + m[0] + " (" + m[2] + ")" };
  }
  /* FRENTE 1g: o INSUMO SINAPI exato (material) + a MO da composição análoga — "ok" com `insumo: true` e `moDe`; sem análoga, só o material e `moFalta` */
  function insumoDe(item, T, rot, k) {
    var e = T.insumos ? T.insumos[chaveMat(item)] : null; if (!e || !e.i) return null;
    var mo = moAnalogaDe(item), r = { status: "ok", chave: k, rotulo: rot, codigo: e.i[0], unidade: e.i[1], descricao: e.i[2], alternativas: 0, insumo: true }, tx = "material: insumo SINAPI " + e.i[0];
    if (mo && !mo.falta) { r.moDe = { codigo: mo.codigo, descricao: mo.descricao, observacao: mo.observacao }; r.observacao = tx + "; instalação: " + mo.texto; }
    else { r.moFalta = true; r.observacao = tx + "; PENDÊNCIA: " + (mo ? mo.texto : "instalação sem composição análoga") + " — só o material entra no orçamento"; }
    return r;
  }
  function flexOuSemTabela(mat) { var Mm = MATERIAIS[mat] || {}; return !!(Mm.flexivel || Mm.semSinapi || Mm.secao || /^duto_/.test(mat)); }
  function sinapiDe(item) {
    var T = tabela(), k = chaveSinapi(item), rot = rotuloItem(item);
    if (!T || !T.chaves) return { status: "pendente", chave: k, rotulo: rot, motivo: "a tabela SINAPI das instalações (js/biminstsinapi.js) não carregou" };
    var c = arr(T.chaves[k]).slice(), substDe = null;
    if (item.semTabela) return { status: "pendente", chave: k, rotulo: rot, motivo: item.semTabela };   /* P12: o item já sabe que não tem chave (bitola de rosca, altura da eletrocalha…) */
    /* ⚠ SUBSTITUTO DECLARADO (frente 1b, 27/10/2026; corrigido na 1c): a SINAPI TEM a curva longa 90° de esgoto série normal DN 40–100 (89730, 89735/89804,
       89743/89808, 89750/89812/89853 — lista explícita do gerador) e a curva 45°/90° soldável de água: essas chaves casam ACIMA, com o código próprio.
       O joelho do mesmo ângulo, DN e aplicação só vale ONDE NÃO HÁ curva na SINAPI (DN 150 longa, curva 45° de esgoto, curva soldável sem composição no DN) — e o item
       sai com a observação dizendo isso (o preço do fabricante da curva pode ser maior). Para voltar ao "pendente", esvazie SUBSTITUTO_SINAPI. */
    /* D8 (27/10/2026, frente 1b-ii): ANTES do substituto, a referência de MERCADO da curva longa (dados-fonte/hidro/precos-mercado, id "curva90_esgoto|<DN>"),
       se existir: a curva usa o preço dela e não o do joelho. Sem mercado, o substituto declarado continua (a decisão de dinheiro é do Rogério). */
    var mercadoCurva = SUBSTITUTO_SINAPI[item.peca] ? refMercado({ mercado: idMercadoCurva(item) }) : null;
    if (!c.length && SUBSTITUTO_SINAPI[item.peca] && !mercadoCurva) {
      var it2 = {}; Object.keys(item).forEach(function (q) { it2[q] = item[q]; }); it2.peca = SUBSTITUTO_SINAPI[item.peca];
      var k2 = chaveSinapi(it2), c2 = arr(T.chaves[k2]).slice();
      if (c2.length) { c = c2; substDe = SUBSTITUTO_SINAPI[item.peca]; }
    }
    var ext = item.peca === "tubo" ? ["pn", "classe", "iso", "bitola"] : (EXTRAS_P12[item.peca] || []);
    ext.forEach(function (e) { if (item[e] != null && item[e] !== "") c = c.filter(function (x) { return !x[3] || x[3][e] == null || x[3][e] === txt(item[e]); }); });
    /* FRENTE 1g: sem composição exata (e sem a chave filtrada por extras), o INSUMO SINAPI exato da lista conferida (material) + a MO da composição análoga */
    if (!c.length && !arr(T.chaves[k]).length) { var insR = insumoDe(item, T, rot, k); if (insR) return insR; }
    if (!c.length) {
      var porque = arr(T.chaves[k]).length ? " com " + ext.filter(function (e) { return item[e]; }).map(function (e) { return e.toUpperCase() + " " + item[e]; }).join(", ") : "";
      return { status: "pendente", chave: k, rotulo: rot, motivo: "sem composição SINAPI (" + (T.fonte ? T.fonte.mes : "") + ") para " + rot + porque + " — pendente (nunca a parecida)" };
    }
    c.sort(function (a, b) { var va = VAR_PREF[(a[3] && a[3]["var"]) || ""], vb = VAR_PREF[(b[3] && b[3]["var"]) || ""]; return (va - vb) || (Number(a[0]) - Number(b[0])); });
    var M = dep("SinapiMapa", "./sinapimapa.js"), cod = c[0][0];
    if (M && M.classeDe) {
      var cl = M.classeDe(cod);
      if (cl !== "instalacao_trecho" && cl !== "instalacao_peca") return { status: "pendente", chave: k, rotulo: rot, motivo: "o código " + cod + " não está no mapa de instalações — pendente" };
    }
    /* a observação do substituto / da aplicação irmã (tools/gerar-biminst-sinapi.js: ORÇAMENTO 100%) vai com o item */
    var r0 = { status: "ok", chave: k, rotulo: rot, codigo: cod, unidade: c[0][1], descricao: c[0][2], alternativas: c.length - 1 };
    if (c[0][3] && c[0][3].obs) r0.observacao = c[0][3].obs;
    if (substDe) { r0.substituto = substDe; r0.observacao = (r0.observacao ? r0.observacao + " · " : "") + "a SINAPI não tem a " + nomeConexao(item.peca, item.material).toLowerCase() + ": vale a composição do " + nomeConexao(substDe, item.material).toLowerCase() + " (peça equivalente de mesmo ângulo) — confira o preço do fabricante"; }
    return r0;
  }

  /* quantidade do TUBO na unidade da composição: m (eixo, real) ou m² (duto retangular: perímetro × comprimento) */
  function quantidadeTrecho(t) {
    var M = MATERIAIS[t.material] || {};
    if (M.unidadeQto === "m") return { unidade: "m", quantidade: r4(t.comprimento) };   /* P12: eletrocalha em metro */
    if (M.secao === "retangular") return { unidade: "m2", quantidade: r4(2 * (t.larg + t.alt) * t.comprimento) };
    return { unidade: "m", quantidade: r4(t.comprimento) };
  }
  function itemTrecho(t) {
    var it = { peca: "tubo", sistema: t.sistema, material: t.material, aplicacao: t.aplicacao, dn: t.material === "duto_chapa" ? "-" : t.dn, pn: t.pn, classe: t.classe, iso: t.iso, bitola: t.bitola, larg: t.larg, alt: t.alt };
    var M = MATERIAIS[t.material] || {};
    if (t.sistema === "incendio" || t.sistema === "industrial") it.semTabela = "a SINAPI 06/2026 não tem composição mapeada para tubulação de " + (t.sistema === "industrial" ? "fluido industrial" : "incêndio") + " — pendente (nunca a parecida: a de água é outro produto)";   /* F3 incêndio */
    if (M.semSinapi) it.semTabela = "a SINAPI 06/2026 não tem composição de " + M.nome.toLowerCase() + " — pendente (nunca a parecida: outro material, outro produto)";
    if (M.alturas && M.alturas.indexOf(Math.round(t.alt * 1000)) < 0) it.semTabela = "a SINAPI 06/2026 só tem eletrocalha de altura " + M.alturas.join(", ") + " mm (esta tem " + Math.round(t.alt * 1000) + " mm) — pendente (nunca a parecida)";
    return it;
  }
  function itemConexao(c) {
    var M = MATERIAIS[c.material] || {};
    if (M.semSinapi) return { peca: c.tipo, sistema: c.sistema, material: c.material, aplicacao: c.aplicacao, dn: c.dn, dn2: c.dn2, semTabela: "a SINAPI 06/2026 não tem composição de conexão de " + M.nome.toLowerCase() + " — pendente" };
    if (/^duto_/.test(c.material)) return { peca: c.tipo, sistema: c.sistema, material: c.material, aplicacao: c.aplicacao, dn: c.dn, dn2: c.dn2, semTabela: "conexão de duto é orçada em m² de chapa (SINAPI \"curva, redução ou tê\"): a área depende do raio e do comprimento da peça — informe no orçamento" };
    var it = { peca: c.tipo, sistema: c.sistema, material: c.material, aplicacao: c.aplicacao, dn: c.dn, dn2: c.dn2, nomeMat: M.nome };
    if (M.larguras && c.aplicacao === "vertical") it.semTabela = "curva/tê VERTICAL de eletrocalha: a SINAPI 06/2026 só tem as peças horizontais — pendente (orce à parte)";
    /* PENDÊNCIAS FINAIS: o tê de inspeção de ESGOTO não tem composição SINAPI (só o do pluvial série R): a referência de mercado */
    if (c.tipo === "te_inspecao" && c.material === "pvc_esgoto") it.mercado = "te_inspecao_esgoto|" + c.dn;
    if (SUBSTITUTO_SINAPI[c.tipo]) it.mercado = idMercadoCurva(it);   /* D8: a curva longa, a referência de mercado antes do substituto */
    else if (!it.mercado) it.mercado = chaveMat(it);   /* FRENTE 1g: cap, luva de correr, redução, tê, junção, união mista, transição… coletados em dados-fonte/hidro/precos-mercado */
    return it;
  }
  /* ISOLAMENTO TÉRMICO DA ÁGUA QUENTE (revisão H5, 21/10/2026): o insumo SINAPI "TUBO DE ESPUMA DE POLIETILENO EXPANDIDO FLEXIVEL
     PARA ISOLAMENTO TERMICO DE TUBULACAO DE AR CONDICIONADO, AGUA QUENTE, DN <bitola>, E= 10 MM" (SINAPI 06/2026, conferido na base
     local data/sinapi-MG-2026-06.json) pela bitola do tubo (BITOLA_REF); o metro de isolamento por metro de tubo = o coeficiente
     do isolamento na composição SINAPI 97329 (tubo de cobre com isolamento: 1,022727 m/m — data/sinapi-MG-analitico.json). Só
     fornecimento (insumo): a colocação do tubo de espuma acompanha a montagem do tubo */
  var ISOLAMENTO_AQ = { insumos: { "1/2": "39712", "3/4": "39715", "1": "39714", "1 1/4": "39708", "1 1/2": "39707" }, coeficiente: 1.022727, coefFonte: "SINAPI 97329 (insumo de isolamento por metro de tubo)",
    descricao: "Tubo de espuma de polietileno expandido flexível para isolamento térmico de água quente, E = 10 mm" };   // hid:ok códigos e coeficiente da SINAPI conferidos (fonte acima)
  /* N23 (24/10/2026): PASSANTE na laje (o furo previsto na fôrma: o tubo-camisa fixado na laje antes da concretagem) — as composições
     SINAPI MG 06/2026 "PASSANTE TIPO TUBO COM DIÂMETRO DE X MM, FIXADO EM LAJE, PARA PASSAGEM DE TUBULAÇÕES COM NO MÁXIMO Y MM DE
     DIÂMETRO. AF_09/2023" (data/sinapi-MG-2026-06.json; tools/test-hid-n23-pressao.js confere código e descrição na base). Vale a de
     menor camisa que passa o diâmetro EXTERNO do tubo; acima de 100 mm a SINAPI não tem: pendência com o motivo (nunca a parecida). */
  var PASSANTE_LAJE = [[32, "90453", 40], [40, "104783", 50], [50, "90454", 75], [75, "90455", 100], [100, "104784", 150]];   // hid:ok [DE máximo do tubo (mm), código SINAPI, Ø da camisa (mm)] — da descrição da composição
  function passanteDe(deMm) {
    var l = PASSANTE_LAJE.filter(function (x) { return deMm <= x[0] + 1e-6; })[0];   // hid:ok tolerância numérica
    if (!l) return { status: "pendente", chave: "passante|" + deMm, rotulo: "Passante na laje para tubo DN " + deMm, motivo: "passante na laje para tubo DN " + deMm + ": a SINAPI 06/2026 só tem passante tipo tubo até tubulação de 100 mm — pendente (nunca a parecida)" };
    var d = "PASSANTE TIPO TUBO COM DIÂMETRO DE " + l[2] + " MM, FIXADO EM LAJE, PARA PASSAGEM DE TUBULAÇÕES COM NO MÁXIMO " + l[0] + " MM DE DIÂMETRO. AF_09/2023";
    return { status: "ok", chave: "passante|" + l[0], rotulo: "Passante na laje Ø " + l[2] + " mm (tubo até " + l[0] + " mm)", codigo: l[1], unidade: "UN", descricao: d, alternativas: 0 };
  }
  /* ⚠ o "diâmetro" da tubulação na descrição SINAPI é o DN (a SINAPI designa os tubos de PVC pelo DN: "TUBO PVC … ESGOTO PREDIAL, DN 100
     MM", de DE 101,6) — a camisa de 150 mm passa o DE do DN 100 com folga; por isso a escolha é pelo DN do trecho */
  function dnPassante(t) { return num(t.dn, 0); }
  /* ⚠ PRIORIDADE 21/10/2026 — o PROLONGADOR da caixa sifonada / do ralo (o corpo desce até a cota da tubulação: js/biminstgeo.js
     corpoPeca). Insumos SINAPI 06/2026 conferidos na base local data/sinapi-MG-2026-06.json: 11735 "PROLONGAMENTO / PROLONGADOR PARA
     CAIXA SIFONADA, PVC, 100 MM X 200 MM (NBR 5688)", 11737 "... 150 MM X 150 MM", 11738 "... 150 MM X 200 MM". Comprimento comercial
     de 200 mm (Tigre, Catálogo Predial 2025, p.29: "Prolongamento para Caixa Sifonada 100 x 200"; cortado na medida). Acima de 200 mm:
     EMENDA de peças (n = ⌈altura / 200 mm⌉, com aviso). Só fornecimento (insumo): a composição da caixa/ralo já paga a instalação —
     sem cobrança dupla. O ralo Ø 100 usa o prolongador Ø 100 (encaixe a conferir no catálogo do ralo). Ø 250: sem insumo → pendente. */
  var PROLONGADOR_CS = { classes: [100, 150, 250], insumos: { "100": [[0.2, "11735", "100 MM X 200 MM"]], "150": [[0.15, "11737", "150 MM X 150 MM"], [0.2, "11738", "150 MM X 200 MM"]] }, comercial: 0.2,   // hid:ok códigos e medidas comerciais da SINAPI/Tigre conferidos (fonte acima)
    descricao: "Prolongamento / prolongador para caixa sifonada, PVC (NBR 5688), cortado na medida" };
  function prolongadorDe(k) {
    var c = k && k.corpo, L = c ? num(c.prolongador, 0) : 0; if (!(L > 0)) return null;
    var cls = PROLONGADOR_CS.classes.slice().sort(function (a, b) { return Math.abs(a - num(c.diam, 0)) - Math.abs(b - num(c.diam, 0)); })[0], ls = PROLONGADOR_CS.insumos[String(cls)];
    var n = Math.ceil(L / PROLONGADOR_CS.comercial - 1e-6), it = { peca: "prolongador_cs", sistema: k.sistema, material: "pvc_esgoto", aplicacao: k.sistema, dn: String(cls) };
    if (!ls) return { item: it, n: n, comprimento: L, sinapi: { status: "pendente", chave: "prolongador|" + cls, rotulo: "Prolongador Ø " + cls, motivo: "prolongador da caixa Ø " + cls + ": sem insumo SINAPI 06/2026 (só Ø 100 e Ø 150) — pendente" } };
    var esc = n === 1 ? (ls.filter(function (x) { return L <= x[0] + 1e-6; })[0] || ls[ls.length - 1]) : ls[ls.length - 1];
    return { item: it, n: n, comprimento: L, emenda: n > 1, sinapi: { status: "ok", chave: "prolongador|" + cls + "|" + esc[1], rotulo: "Prolongador para caixa sifonada Ø " + cls + " (" + esc[2] + ")", codigo: esc[1], unidade: "UN", descricao: "PROLONGAMENTO / PROLONGADOR PARA CAIXA SIFONADA, PVC, " + esc[2] + " (NBR 5688)", insumo: true, alternativas: 0,
      observacao: (n > 1 ? n + " peças emendadas" : "1 peça") + " para " + Math.round(L * 1000) + " mm (corpo na cota da tubulação; " + PROLONGADOR_CS.descricao + ")" } };
  }
  function isolamentoDe(t) {
    var b = (BITOLA_REF[t.material] || {})[t.dn], cod = b ? ISOLAMENTO_AQ.insumos[b] : null;
    if (!cod) return { status: "pendente", chave: "isolamento|" + t.material + "|" + t.dn, rotulo: "Isolamento térmico DN " + t.dn, motivo: "isolamento térmico do tubo " + t.material + " DN " + t.dn + ": sem a bitola do insumo SINAPI — pendente" };
    return { status: "ok", chave: "isolamento|" + b, rotulo: ISOLAMENTO_AQ.descricao + ", DN " + b + "\"", codigo: cod, unidade: "M", descricao: ISOLAMENTO_AQ.descricao + ", DN " + b + "\"", insumo: true, alternativas: 0,
             observacao: "metro de isolamento = metro de tubo × " + ISOLAMENTO_AQ.coeficiente + " (" + ISOLAMENTO_AQ.coefFonte + ")" };
  }
  /* REFERÊNCIA DE MERCADO (pendências finais, 18/10/2026; js/hidprecomercado.js, só no grupo "hidro" da prévia): o item SEM
     composição SINAPI que tem preço público levantado (o maior de 3 lojas) — sem o módulo carregado, nada muda (pendente) */
  function refMercado(it) {
    var PM = global.HidPrecoMercado || null;
    if (it && it.mercadoDireto) return it.mercadoDireto;   /* extintor do Hidro: o preco da familia inc-extintor (extintorDoHidro) */
    if (!PM || !it) return null;
    if (it.mercadoSoma) return PM.soma(it.mercadoSoma, it.mercadoRotulo);
    return it.mercado && PM.ref ? PM.ref(it.mercado) : null;
  }
  /* EXTINTOR DO HIDRO no orcamento (27/10/2026, regra RA: 100 % orcado): a peca "extintor" nao tem composicao SINAPI (semSinapi), mas o extintor lancado
     pelo Hidro e po ABC com a capacidade gravada na peca (js/hidinc.js, opPeca). Orca com o MESMO preco da familia inc-extintor do tipo correspondente
     (abc4 = 2-A:20-B:C; abc6-3a = 3-A; abc-40b = classe B >= 40-B); projeto antigo, sem capacidade, e o abc4 (2-A:20-B:C, IT 16 Tabela 1).
     Uma linha por extintor; o que tem familia inc-extintor no mesmo ponto conta so uma vez (extintorDuplicado). */
  function tipoExtintorDe(cap) {
    var mA = /(\d+)\s*-\s*A/i.exec(txt(cap)), mB = /(\d+)\s*-\s*B/i.exec(txt(cap)), a = mA ? Number(mA[1]) : 2, b = mB ? Number(mB[1]) : 20;
    return b >= 40 ? "abc-40b" : (a >= 3 ? "abc6-3a" : "abc4");
  }
  function extintorDoHidro(k, avaliarFam, it) {
    var tipo = tipoExtintorDe(k.capacidade), av = null;
    try { av = typeof avaliarFam === "function" ? avaliarFam("inc-extintor", tipo, {}) : null; } catch (e) { av = null; }
    var v = av && av.valores ? av.valores : null, pu = v ? num(v.Preco_unitario, 0) : 0;
    if (!v || !(pu > 0)) return;                       /* sem a familia carregada: continua pendente (nunca inventa preco) */
    it.nome = "Extintor portátil de pó ABC (Hidro) — " + tipo + " " + (txt(v.Capacidade_extintora) || "");
    it.chaveExtra = tipo;
    var fonte = txt(v.Fonte_preco) + (txt(v.Data_preco) ? " (" + txt(v.Data_preco) + ")" : "");
    it.mercadoDireto = { id: txt(v.Peca_catalogo) || ("INC-EXT-" + tipo), valor: pu, unidade: "un", texto: fonte, data: txt(v.Data_preco), url: "", provisorio: v.Preco_provisorio === true,
      motivo: txt(v.Motivo_preco), criterio: "mesmo preço da família inc-extintor (" + tipo + "): maior preço público lido, fornecimento sem montagem" + (k.capacidade ? "" : "; peça sem capacidade gravada (projeto antigo): 2-A:20-B:C") };
  }
  /* a peca do Hidro e a familia inc-extintor no mesmo ponto (<= 0,5 m na planta, mesmo piso) sao UM extintor: orca-se so a familia */
  function extintorDuplicado(k, estado) {
    return arr(estado && estado.familias).some(function (f) {
      return f && /inc-extintor/.test(txt(f.famId)) && Math.abs(num(f.x, 0) - k.x) <= 0.5 && Math.abs(num(f.z, 0) - k.z) <= 0.5 && Math.abs(num(f.y, 0) - k.y) <= 2.5;
    });
  }
  function itemPeca(k, avaliarFam) {
    var it = { peca: k.peca, sistema: k.sistema, material: k.material, aplicacao: k.aplicacao, dn: k.dn };
    /* PENDÊNCIAS FINAIS: a caixa de inspeção pela profundidade (a composição real, mais a tampa) ou o dispositivo de PVC
       (sem SINAPI: a soma das referências de mercado) — js/hidcigeo.js (só no grupo "hidro"); sem ele, pendente */
    if (k.peca === "caixa_inspecao") {
      var CI = dep("HidCI", "./hidcigeo.js"), oc = CI && CI.orcamento ? CI.orcamento(k) : null;
      if (!oc) { it.semTabela = "caixa de inspeção: o motor da caixa (js/hidcigeo.js) não carregou — pendente"; return it; }
      it.nome = oc.nome; it.chaveExtra = oc.chaveExtra;
      if (oc.composicoes) it.composicoes = oc.composicoes;
      if (oc.semTabela) it.semTabela = oc.semTabela;
      if (oc.mercadoSoma) { it.mercadoSoma = oc.mercadoSoma; it.mercadoRotulo = oc.mercadoRotulo; }
      return it;
    }
    if ((PECAS[k.peca] || {}).semSinapi) it.semTabela = "a SINAPI 06/2026 não tem composição mapeada para " + PECAS[k.peca].nome.toLowerCase() + " — pendente (nunca a parecida)";   /* F3 incêndio */
    if (k.peca === "extintor") extintorDoHidro(k, avaliarFam, it);
    return it;
  }

  /* ===================================================== QUANTITATIVO
   * Por sistema, material e DN: metros de tubo (eixo real), número de
   * conexões por tipo, peças — cada grupo com a composição (ou pendente). */
  function qto(estado, avaliarFam) {
    var R = rede(estado, avaliarFam);
    var tubos = {}, ordT = [], cxs = {}, ordC = [], pcs = {}, ordP = [], porSis = {}, prol = {}, ordPl = [];
    function sis(s) { return porSis[s] || (porSis[s] = { sistema: s, nome: SISTEMAS[s].nome, cor: SISTEMAS[s].cor, metros: 0, conexoes: 0, pecas: 0 }); }
    R.trechos.forEach(function (t) {
      var it = itemTrecho(t), q = quantidadeTrecho(t);
      var k = [t.sistema, t.material, t.material === "duto_chapa" ? r2(t.larg) + "x" + r2(t.alt) : t.dn, t.aplicacao, t.pn || "", t.classe || "", t.iso || "", t.bitola || ""].join("|");
      var g = tubos[k];
      if (!g) { g = tubos[k] = { sistema: t.sistema, material: t.material, dn: t.dn, larg: t.larg, alt: t.alt, aplicacao: t.aplicacao, pn: t.pn, classe: t.classe, iso: t.iso, bitola: t.bitola, n: 0, metros: 0, quantidade: 0, unidade: q.unidade, trechos: [], sinapi: sinapiDe(it) }; ordT.push(k); }
      g.n++; g.metros = r4(g.metros + t.comprimento); g.quantidade = r4(g.quantidade + q.quantidade); g.trechos.push(t.id);
      sis(t.sistema).metros = r4(sis(t.sistema).metros + t.comprimento);
    });
    R.conexoes.concat(arr(R.luvasQto), arr(R.extrasQto)).forEach(function (c) {   /* + a luva na ponta e o ponto de água/adaptador/terminal (só contagem, sem a prévia) */
      var k = [c.sistema, c.material, c.tipo, c.dn, c.dn2 || "", c.aplicacao, c.incluso ? "incl" : ""].join("|");
      var g = cxs[k];
      if (!g) {
        var it = itemConexao(c);
        g = cxs[k] = { tipo: c.tipo, nome: c.nome, sistema: c.sistema, material: c.material, dn: c.dn, dn2: c.dn2, aplicacao: c.aplicacao, n: 0, ids: [],
                       sinapi: c.incluso ? { status: "ok", chave: chaveSinapi(it), rotulo: rotuloItem(it), codigo: c.inclusoCodigo, unidade: "UN", descricao: "orçado nos serviços da caixa d'água (Barrilete)", alternativas: 0, incluso: true, observacao: c.incluso } : (it.semTabela ? { status: "pendente", chave: chaveSinapi(it), rotulo: rotuloItem(it), motivo: it.semTabela } : sinapiDe(it)) };
        if (c.premissa) g.premissa = c.premissa;
        if (c.incluso) g.incluso = c.incluso;
        if (c.chave) g.chave = c.chave;
        if (g.sinapi.status !== "ok") { var rmC = refMercado(it); if (rmC) { g.mercado = rmC; var moC = moAnalogaDe(it); if (moC) { if (moC.falta) g.moFalta = moC.texto; else g.moDe = moC; } } }
        if (g.sinapi.status === "ok" && g.sinapi.moDe) g.moDe = g.sinapi.moDe;
        if (g.sinapi.status === "ok" && g.sinapi.moFalta) g.moFalta = g.sinapi.observacao;
        ordC.push(k);
      }
      g.n++; g.ids.push(c.id); sis(c.sistema).conexoes++;
    });
    R.pecas.forEach(function (p) {
      if (p.peca === "extintor" && extintorDuplicado(p, estado)) return;   /* a familia inc-extintor no mesmo ponto ja conta */
      var itp = itemPeca(p, avaliarFam), k = [p.peca, p.sistema, p.material, p.dn, p.aplicacao, itp.chaveExtra || ""].join("|");
      var g = pcs[k];
      if (!g) {
        g = pcs[k] = { peca: p.peca, nome: itp.nome || PECAS[p.peca].nome, sistema: p.sistema, material: p.material, dn: p.dn, aplicacao: p.aplicacao, n: 0, ids: [], sinapi: itp.composicoes ? itp.composicoes[0] : sinapiDe(itp) };
        if (itp.composicoes) g.composicoes = itp.composicoes;   /* a caixa de inspeção: a caixa e a tampa (de ferro) */
        if (g.sinapi.status !== "ok") { var rmP = refMercado(itp); if (rmP) g.mercado = rmP; }
        ordP.push(k);
      }
      g.n++; g.ids.push(p.id); sis(p.sistema).pecas++;
      /* o PROLONGADOR da caixa/ralo baixado até a cota da tubulação: grupo próprio por insumo (n peças por caixa) */
      var pl = prolongadorDe(p);
      if (pl) { var kp = pl.sinapi.chave, gp = prol[kp]; if (!gp) { gp = prol[kp] = { peca: "prolongador_cs", nome: pl.sinapi.rotulo, sistema: p.sistema, dn: pl.item.dn, n: 0, quantidade: 0, unidade: "UN", ids: [], comprimentos: [], emendas: 0, sinapi: pl.sinapi }; ordPl.push(kp); }
        gp.n++; gp.quantidade += pl.n; gp.ids.push(p.id); gp.comprimentos.push(r4(pl.comprimento)); if (pl.emenda) gp.emendas++; }
    });
    /* REVISÃO H5: o isolamento térmico da água quente fora do ambiente aquecido, por bitola */
    var isos = {}, ordI = [];
    R.trechos.forEach(function (t) {
      if (!t.isolamento) return;
      var sp = isolamentoDe(t), k = sp.chave, g = isos[k];
      if (!g) { g = isos[k] = { sistema: t.sistema, material: t.material, dn: t.dn, n: 0, metros: 0, quantidade: 0, unidade: "m", coeficiente: ISOLAMENTO_AQ.coeficiente, trechos: [], sinapi: sp }; ordI.push(k); }
      g.n++; g.metros = r4(g.metros + t.comprimento); g.quantidade = r4(g.metros * ISOLAMENTO_AQ.coeficiente); g.trechos.push(t.id);
    });
    /* N23: os PASSANTES na laje que o traçado lançou (um por travessia), pelo DN do tubo */
    var pss = {}, ordPs = [];
    R.trechos.forEach(function (t) {
      arr(t.passantes).forEach(function (q) {
        var sp = passanteDe(dnPassante(t)), k = sp.chave, g = pss[k];
        if (!g) { g = pss[k] = { peca: "passante_laje", nome: sp.rotulo, sistema: t.sistema, dn: t.dn, n: 0, quantidade: 0, unidade: "UN", ids: [], lajes: [], sinapi: sp }; ordPs.push(k); }
        g.n++; g.quantidade++; g.ids.push(t.id); if (g.lajes.indexOf(q.laje) < 0) g.lajes.push(q.laje);
      });
    });
    /* N23 EMBUTIDO (26/10/2026): o RASGO e o CHUMBAMENTO do tubo embutido em ALVENARIA (js/biminstembutido.js rasgos: o comprimento que
       corre dentro da parede de alvenaria — não drywall, não o enchimento levantado em volta do tubo), pela SINAPI do DN */
    var rsg = {}, ordR = [], HEq = dep("HidEmbutido", "./biminstembutido.js");
    if (HEq && HEq.rasgos) { try { HEq.rasgos(estado, avaliarFam).forEach(function (r) { r.linhas.forEach(function (sp) {
      var k = sp.chave + "|" + r.dn, g = rsg[k];
      if (!g) { g = rsg[k] = { peca: "rasgo_alvenaria", nome: sp.rotulo || sp.chave, sistema: r.sistema, dn: r.dn, n: 0, metros: 0, quantidade: 0, unidade: "m", ids: [], sinapi: sp }; ordR.push(k); }
      g.n++; g.metros = r4(g.metros + r.metros); g.quantidade = g.metros; g.ids.push(r.id);
    }); }); } catch (eR) {} }
    /* P12: acessórios de tubo (registro, válvula) e dispositivos elétricos (família com `mep`) */
    var acs = {}, ordA = [], dsp = {}, ordD = [];
    arr(R.acessorios).forEach(function (a) {
      var it = itemAcessorio(a), k = [a.acessorio, a.sistema, it.material, it.aplicacao, it.dn].join("|");
      var g = acs[k];
      if (!g) { g = acs[k] = { acessorio: a.acessorio, nome: ACESSORIOS[a.acessorio].nome, variante: a.variante, sistema: a.sistema, dn: a.dn, material: it.material, aplicacao: it.aplicacao, dnSinapi: it.dn, n: 0, ids: [], sinapi: sinapiDe(it) }; if (g.sinapi.status !== "ok") { var rmA = refMercado(it); if (rmA) g.mercado = rmA; } ordA.push(k); }
      g.n++; g.ids.push(a.id); sis(a.sistema).pecas++;
    });
    dispositivosDo(estado, avaliarFam).forEach(function (d) {
      var it = d.item, k = [it.peca, it.material, it.aplicacao, it.dn, it.placa || "", it.corrente || "", it.composicoes ? it.composicoes.map(function (c) { return c.codigo; }).join("+") : ""].join("|");
      var g = dsp[k];
      if (!g) { g = dsp[k] = { peca: it.peca, nome: DISPOSITIVOS[it.peca].nome, material: it.material, aplicacao: it.aplicacao, dn: it.dn, placa: it.placa, corrente: it.corrente, n: 0, ids: [], sinapi: it.composicoes ? it.composicoes[0] : sinapiDe(it), rotulo: rotuloP12(it) }; if (it.composicoes) g.composicoes = it.composicoes; ordD.push(k); }
      g.n++; g.ids.push(d.id);
    });
    /* LIGAÇÃO ELÉTRICA (21/10/2026, js/eletilum.js): o CABO da fiação lógica, por seção, em metro (comprimento de AGORA dos trechos ×
       número de condutores do registro). Sem o motor da ligação ou sem registro: lista vazia (o resto fica igual) */
    /* ⚠ com o projeto dos circuitos no quadro, o cabo é DELE (js/elecircuitos.js cuidaDoCabo, integração n23): aqui fica vazio */
    var ECc = dep("EleCircuitos", "./elecircuitos.js"), caboDoProjeto = !!(ECc && ECc.cuidaDoCabo && ECc.cuidaDoCabo(estado, avaliarFam));
    var EI = dep("EletIlum", "./eletilum.js"), cabos = !caboDoProjeto && EI && EI.cabos ? EI.cabos(estado).map(function (g) {
      var it = { peca: "cabo", sistema: "", material: g.material, aplicacao: "terminal", dn: String(g.secao) };
      g.sinapi = sinapiDe(it); g.rotulo = rotuloItem(it); g.unidade = "m"; g.quantidade = g.metros; return g;
    }) : [];
    return {
      cabos: cabos, caboDoProjeto: caboDoProjeto,
      acessorios: ordA.map(function (k) { return acs[k]; }),
      dispositivos: ordD.map(function (k) { return dsp[k]; }),
      isolamentos: ordI.map(function (k) { return isos[k]; }),
      passantes: ordPs.map(function (k) { return pss[k]; }),
      rasgos: ordR.map(function (k) { return rsg[k]; }),
      prolongadores: ordPl.map(function (k) { return prol[k]; }),
      tubos: ordT.map(function (k) { return tubos[k]; }),
      conexoes: ordC.map(function (k) { return cxs[k]; }),
      /* as PREMISSAS que a dedução assumiu (a rosca do ponto de água, a rosca do adaptador do registro): vão para a lista de material e o memorial */
      premissas: ordC.map(function (k) { return cxs[k]; }).filter(function (g) { return g.premissa; }).map(function (g) { return { item: g.nome + " " + g.dn + (g.dn2 ? " × " + g.dn2 + "\"" : ""), valor: g.premissa, n: g.n }; }),
      /* M3 (frente 1c): o ponto de água sem rosca padrão NÃO some do total em silêncio — vira pendência visível (orçamento, lista de material, planilha, memorial) */
      pontosSemRosca: arr(R.pontosSemRosca).map(function (p) { var o = {}; Object.keys(p).forEach(function (k) { o[k] = p[k]; }); o.texto = textoPontoSemRosca(p); return o; }),
      pecas: ordP.map(function (k) { return pcs[k]; }),
      porSistema: Object.keys(porSis).map(function (k) { return porSis[k]; }),
      ligacoes: R.ligacoes.length, pontasLivres: R.pontasLivres.length, conectoresLivres: R.conectoresLivres.length,
      avisos: R.avisos.map(function (a) { return a.texto; }).concat(R.trechos.reduce(function (acc, t) { return acc.concat(t.avisos.map(function (a) { return "trecho " + t.id + ": " + a; })); }, []))
        .concat(arr(R.acessorios).reduce(function (acc, a) { return acc.concat(a.avisos.map(function (x) { return ACESSORIOS[a.acessorio].nome.toLowerCase() + " " + a.id + ": " + x; })); }, [])),
      rede: R
    };
  }

  /* ============================================= PARA O ORÇAMENTO DO MODELO
   * Uma linha por TRECHO, CONEXÃO e PEÇA (o "elemento" do js/orcmodelo.js:
   * de que peça do modelo a quantidade veio). Código só da tabela; sem ele,
   * a linha é PENDENTE com o motivo e entra em "Fora do orçamento". */
  function servicosOrc(estado, avaliarFam) {
    var R = rede(estado, avaliarFam), out = [];
    function linha(id, it, q, un, sp) {
      var o = { id: id, rotulo: sp.rotulo || rotuloItem(it), unidade: un, quantidade: q };
      if (sp.status === "ok") { o.codigo = sp.codigo; o.descricao = sp.descricao; o.alternativas = sp.alternativas; if (sp.observacao) o.observacao = sp.observacao;
        if (sp.moDe) o.moDe = sp.moDe; if (sp.moFalta) o.moFalta = sp.observacao; }   /* FRENTE 1g: insumo + MO da composição análoga */
      else {
        o.codigo = ""; o.motivo = sp.motivo;
        var rm = refMercado(it); if (rm) { o.referenciaMercado = rm; var moL = moAnalogaDe(it); if (moL) { if (moL.falta) o.moFalta = moL.texto; else o.moDe = moL; } }   /* pendências finais: o preço de varejo levantado, nunca "a cotar"; 1g: + a MO análoga */
      }
      out.push(o);
    }
    R.trechos.forEach(function (t) { var it = itemTrecho(t), q = quantidadeTrecho(t); linha(t.id, it, q.quantidade, q.unidade, sinapiDe(it));
      if (t.isolamento) linha(t.id, it, r4(t.comprimento * ISOLAMENTO_AQ.coeficiente), "m", isolamentoDe(t));   /* revisão H5: o isolamento térmico da AQ */
      arr(t.passantes).forEach(function () { linha(t.id, { peca: "passante_laje", sistema: t.sistema, material: t.material, dn: t.dn }, 1, "un", passanteDe(dnPassante(t))); });   /* N23: o passante de cada travessia de laje */
    });
    /* N23 EMBUTIDO: o rasgo e o chumbamento do trecho embutido em alvenaria (o metro que corre dentro dela), pela SINAPI do DN */
    var HEo = dep("HidEmbutido", "./biminstembutido.js");
    if (HEo && HEo.rasgos) { try { HEo.rasgos(estado, avaliarFam).forEach(function (r) { r.linhas.forEach(function (sp) { linha(r.id, { peca: "rasgo_alvenaria", sistema: r.sistema, material: r.material, dn: r.dn }, r.metros, "m", sp); }); }); } catch (eO) {} }
    R.conexoes.concat(arr(R.luvasQto), arr(R.extrasQto)).forEach(function (c) {
      if (c.incluso) return;   /* o adaptador com flange que os serviços da caixa já orçam (js/hidbarrilete.js): não soma duas vezes */
      var it = itemConexao(c);
      linha(c.id, it, 1, "un", it.semTabela ? { status: "pendente", rotulo: rotuloItem(it), motivo: it.semTabela } : sinapiDe(it));
    });
    /* M3 (frente 1c): uma linha PENDENTE por ponto de água sem rosca padrão (peça de ligação a definir) — nunca "a cotar" calado */
    arr(R.pontosSemRosca).forEach(function (p) { out.push({ id: txt(p.famInst) + ":" + txt(p.conector), rotulo: "Peça de ligação do ponto de água (" + txt(p.famId) + ")", unidade: "un", quantidade: 1, codigo: "", motivo: textoPontoSemRosca(p) }); });
    R.pecas.forEach(function (p) {
      if (p.peca === "extintor" && extintorDuplicado(p, estado)) return;   /* a familia inc-extintor no mesmo ponto ja conta */
      var it = itemPeca(p, avaliarFam);
      /* a peça com MAIS de uma composição (a caixa de inspeção: a caixa + a tampa de ferro, ou o poço + a tampa) */
      if (it.composicoes) { it.composicoes.forEach(function (cp) { linha(p.id, it, cp.qtd != null ? cp.qtd : 1, cp.unidadeQto || "un", cp); }); return; }   /* o PV: acréscimo e chaminé em metro */
      linha(p.id, it, 1, "un", sinapiDe(it));
      var pl = prolongadorDe(p); if (pl) linha(p.id, pl.item, pl.n, "un", pl.sinapi);   /* o prolongador da caixa/ralo baixado (só fornecimento) */
    });
    /* P12: cada registro/válvula e cada dispositivo (tomada, interruptor, luminária, quadro) é 1 UN */
    arr(R.acessorios).forEach(function (a) { var it = itemAcessorio(a); linha(a.id, it, 1, "un", sinapiDe(it)); });
    dispositivosDo(estado, avaliarFam).forEach(function (d) {
      if (d.item.composicoes) { d.item.composicoes.forEach(function (cp) { linha(d.id, d.item, cp.qtd != null ? cp.qtd : 1, "un", cp); }); return; }   /* a placa sem composição única (integração n23) */
      linha(d.id, d.item, 1, "un", sinapiDe(d.item));
    });
    /* LIGAÇÃO ELÉTRICA: o cabo de cada trecho de eletroduto da ligação (metros de cabo = comprimento × condutores) */
    var trPorId = {}; R.trechos.forEach(function (t) { trPorId[t.id] = t; });
    /* ⚠ com o projeto dos circuitos, o cabo vem do js/elecircuitos.js (servicosOrc) — somar aqui também cobrava o fio duas vezes */
    var ECo = dep("EleCircuitos", "./elecircuitos.js");
    if (!(ECo && ECo.cuidaDoCabo && ECo.cuidaDoCabo(estado, avaliarFam))) arr(estado && estado.instalacoes && estado.instalacoes.ligacoes).forEach(function (rg) {
      Object.keys(rg.fiacao || {}).forEach(function (tid) {
        var t = trPorId[tid], f = rg.fiacao[tid]; if (!t || !f || !(num(f.n, 0) > 0)) return;
        var it = { peca: "cabo", sistema: "", material: "cobre_450_750", aplicacao: "terminal", dn: String(num(rg.secao, 1.5)) };
        linha(tid, it, r4(t.comprimento * num(f.n, 0)), "m", sinapiDe(it));
      });
    });
    return out;
  }

  /* ========================================================= PLANTA 2D
   * O que a planta técnica desenha por cima do modelo: o EIXO de cada
   * trecho na cor do sistema (acima do plano de corte: tracejado, como o
   * que passa no forro), as conexões, as peças e o rótulo (DN e, nos de
   * gravidade, a inclinação). Coordenadas da planta = (x, z) do mundo
   * (js/bim.js vista2d: telaX = x, telaY = z). */
  function planta(estado, o) {
    o = o || {};
    var inst = (estado && estado.instalacoes) || { trechos: [], pecas: [] };
    var y0 = num(o.yFundo, -Infinity), yc = num(o.yCorte, Infinity), y1 = num(o.yTopo, yc + 3);
    var out = { linhas: [], simbolos: [], textos: [] };
    /* LIGAÇÃO ELÉTRICA (21/10/2026, js/eletilum.js): o número de condutores do trecho entra no rótulo ("EL Ø20 · 3#1,5") */
    var fiacaoT = {}, ligs = arr(inst.ligacoes);
    ligs.forEach(function (rg) { Object.keys(rg.fiacao || {}).forEach(function (tid) { fiacaoT[tid] = rg.fiacao[tid].n + "#" + String(num(rg.secao, 1.5)).replace(".", ","); }); });
    arr(inst.trechos).forEach(function (t) {
      var lo = Math.min(t.p1.y, t.p2.y), hi = Math.max(t.p1.y, t.p2.y);
      if (hi < y0 - 1e-6 || lo > y1 + 1e-6) return;
      var S = SISTEMAS[t.sistema], acima = lo > yc + 1e-6;
      var M = MATERIAIS[t.material] || {};
      var larg = M.secao === "retangular" ? t.larg : t.diametro;
      if (t.vertical) { out.simbolos.push({ tipo: "prumada", x: r4(t.p1.x), y: r4(t.p1.z), r: r4(Math.max(larg, 0.05) / 2 + 0.02), cor: S.cor, id: t.id }); }
      else out.linhas.push({ seg: [r4(t.p1.x), r4(t.p1.z), r4(t.p2.x), r4(t.p2.z)], cor: S.cor, tracejado: acima, largura: r4(larg), sistema: t.sistema, id: t.id });
      if (!t.vertical && t.comprimentoH >= 0.6) {
        var rot = M.secao === "retangular" ? Math.round(t.larg * 100) + "×" + Math.round(t.alt * 100) : (S.abrev + " Ø" + t.dn);
        if (S.gravidade && t.inclinacao != null) rot += " i=" + fmtPct(t.inclinacao);
        /* PADRÃO DE APRESENTAÇÃO (js/biminstpadrao.js): o conteúdo e o formato do rótulo de tubo do padrão (DN; no
           esgoto e no pluvial, a inclinação) — sem o padrão carregado, fica o rótulo acima */
        var PADR = dep("BimInstPadrao", "./biminstpadrao.js");
        if (PADR && PADR.pronto && PADR.pronto() && M.secao !== "retangular" && previaHidro()) {   /* P8: sem a prévia hidro, o rótulo do master */ var rp = PADR.rotuloTrecho({ sistema: t.sistema, dn: t.dn, inclinacao: S.gravidade ? t.inclinacao : null }); if (rp) rot = rp; }
        if (fiacaoT[t.id]) rot += " · " + fiacaoT[t.id];
        var ang = Math.atan2(t.p2.z - t.p1.z, t.p2.x - t.p1.x) * 180 / Math.PI;
        if (ang > 90) ang -= 180; if (ang < -90) ang += 180;
        out.textos.push({ x: r4((t.p1.x + t.p2.x) / 2), y: r4((t.p1.z + t.p2.z) / 2), t: rot, cor: S.cor, rot: r2(ang) });
      }
    });
    arr(inst.pecas).forEach(function (p) {
      if (p.y < y0 - 1e-6 || p.y > y1 + 1e-6) return;
      var P = PECAS[p.peca];
      out.simbolos.push({ tipo: P.forma === "caixa" ? "caixa" : "ralo", x: r4(p.x), y: r4(p.z), r: r4(P.forma === "caixa" ? P.w / 2 : P.r), cor: P.sistemas[0] === "eletrica" ? COR_CAIXA_ELETRICA : SISTEMAS[p.sistema].cor, id: p.id });
    });
    if (o.rede) arr(o.rede.conexoes).forEach(function (c) {
      if (c.y < y0 - 1e-6 || c.y > y1 + 1e-6) return;
      out.simbolos.push({ tipo: "conexao", x: c.x, y: c.z, r: r4(Math.max(c.dn, 20) / 2000 + 0.015), cor: SISTEMAS[c.sistema].cor, id: c.id });
    });
    /* P12: o registro/válvula no eixo — a "gravata" (dois triângulos opostos pelo vértice), na cor do sistema */
    arr(inst.acessorios).forEach(function (a) {
      if (a.centro.y < y0 - 1e-6 || a.centro.y > y1 + 1e-6) return;
      simboloAcessorio(a).forEach(function (sg) { out.linhas.push({ seg: sg, cor: SISTEMAS[a.sistema].cor, tracejado: false, largura: 0, sistema: a.sistema, id: a.id }); });
    });
    /* LIGAÇÃO ELÉTRICA: o símbolo do interruptor (S, S3w paralelo, S4w intermediário; um por módulo) ao lado da placa, e o
       circuito/comando de cada luminária ("C1·a") — a convenção do projeto elétrico em planta */
    if (ligs.length) {
      var letra = {}; ligs.forEach(function (rg) { arr(rg.comandos).forEach(function (k, i) { letra[k.id] = (rg.circuito || "") + "·" + String.fromCharCode(97 + i); }); });
      var SIMB = { simples: "S", paralelo: "S3w", intermediario: "S4w" };
      arr(estado && estado.familias).forEach(function (f) {
        var I = f.inst || {}, yf = num(f.y, 0); if (yf < y0 - 3 || yf > y1 + 1e-6) return;
        if (I.Comandos && I.Esquemas) {
          var th = num(f.rotY, 0), s = txt(I.Esquemas).split(",").map(function (e) { return SIMB[e.trim()] || "S"; }).join("+");
          var cs = txt(I.Comandos).split(",").map(function (k) { return (letra[k.trim()] || "").split("·")[1] || ""; }).join("");
          out.textos.push({ x: r4(num(f.x, 0) + Math.sin(th) * 0.2), y: r4(num(f.z, 0) + Math.cos(th) * 0.2), t: s + (cs ? " " + cs : ""), cor: COR_CAIXA_ELETRICA, rot: 0, id: f.id, livre: true });
        } else if (I.Comando && letra[I.Comando]) out.textos.push({ x: r4(num(f.x, 0) + 0.18), y: r4(num(f.z, 0) - 0.18), t: letra[I.Comando], cor: COR_CAIXA_ELETRICA, rot: 0, id: f.id, livre: true });
      });
    }
    /* P12: LEGENDA de tubulação por sistema e DN (só quando pedida: a planta de sempre fica igual) */
    if (o.legenda) legendaNaPlanta(estado, out);
    return out;
  }

  /* =====================================================================
   * P12 — INSTALAÇÕES II (plano do BIM §4 P12, 09/10/2026)
   *
   * A) ACESSÓRIOS DE TUBO (registro de gaveta, de esfera, de pressão e
   *    válvula de retenção): colocado NUM TUBO, ele DIVIDE o
   *    trecho (BreakCurve) — o tubo some debaixo do corpo do acessório e as
   *    duas metades ficam ligadas nas faces dele (dois pontos de ligação).
   *    É UMA op (desfazer devolve o tubo inteiro; apagar o registro emenda):
   *      {op:'acessorio', id, famId, tipoId, trecho, novoId, x, y, z, comprimento}
   *    famId = a família RA (js/familiasra.js, com os conectores); tipoId =
   *    a VARIANTE (bruto, com acabamento, soldável, roscável…); comprimento =
   *    face a face, medido pela tela nos conectores da família avaliada.
   *    DISPOSITIVOS (tomada, interruptor, luminária, quadro) são famílias
   *    colocadas como as outras, com `mep: {peca}` e o ponto de ligação do
   *    eletroduto; aqui só se tira o item SINAPI delas.
   * B) ELETROCALHA (sistema "bandeja"): mesmas regras de traçado; conexões
   *    pela SINAPI (curva/tê horizontal 90°, redução; a emenda está no metro).
   *    verificar(): pontas soltas, pontos sem tubo, sistemas misturados,
   *    inclinação abaixo da mínima — os avisos que a B5 já gerava, numa lista.
   *    sistemas(): os trechos ligados formam um SISTEMA, numerado por tipo
   *    (AF-1, AF-2…), com nome automático ("Água fria 1") ou o do usuário
   *    (op {op:'instSistema', id:<trecho>, nome}).
   * C) legenda() por sistema e DN, tabelaPecas() — a tabela de peças MEP
   *    local (a da P5 — js/bimtabela.js — a substitui quando existir).
   *
   * ⚠ SINAPI: só pela tabela gerada (tools/gerar-biminst-sinapi.js). O
   *   registro de latão/bronze é ROSCÁVEL e a SINAPI o dá em POLEGADA: o DN
   *   do tubo vira a bitola de rosca pela tabela BITOLA_REF (a "referência"
   *   do tubo soldável, ABNT NBR 5648). Material sem tabela = pendente, com
   *   o motivo — nunca a bitola "parecida". Os adaptadores soldável × rosca
   *   não são deduzidos: aviso "orce à parte".
   * ===================================================================== */
  var ACESSORIOS = {
    /* PENDÊNCIAS FINAIS (18/10/2026, decisão da coordenação): EMBUTIDO na parede (ramal de banheiro/cozinha) = registro de
       BASE DE LATÃO com acabamento cromado (o 3D mostra a base + o acabamento; a SINAPI é a do latão); APARENTE (barrilete,
       cavalete, casa de máquinas, piscina, pressurizador) = registro de ESFERA de PVC soldável. O registro de GAVETA de PVC
       soldável SAIU do catálogo (decisão da coordenação, 18/10/2026, noite): o produto não existe nas linhas Tigre/Amanco/Krona
       — sem produto e sem preço inventados. Estado antigo com esse tipo cai no primeiro tipo (bruto, latão) na normalização. */
    registro_gaveta:  { nome: "Registro de gaveta", fam: "ra-registro-gaveta", ifc: "IFCVALVE", pre: "ISOLATING", sistemas: ["agua_fria", "agua_quente"],
                        variantes: { bruto: { material: "latao", aplicacao: "bruto", rosca: true, rot: "bruto, latão roscável" },
                                     acabamento: { material: "latao", aplicacao: "acabamento", rosca: true, rot: "latão roscável, com acabamento e canopla cromados" } } },
    registro_esfera:  { nome: "Registro de esfera", fam: "ra-registro-esfera", ifc: "IFCVALVE", pre: "ISOLATING", sistemas: ["agua_fria", "agua_quente"],
                        variantes: { soldavel: { material: "pvc_soldavel", aplicacao: "volante", rosca: false, rot: "PVC soldável, com volante" },
                                     roscavel: { material: "pvc_roscavel", aplicacao: "volante", rosca: true, rot: "PVC roscável, com volante" },
                                     borboleta: { material: "pvc_roscavel", aplicacao: "borboleta", rosca: true, rot: "PVC roscável, com borboleta" } } },
    registro_pressao: { nome: "Registro de pressão", fam: "ra-registro-pressao", ifc: "IFCVALVE", pre: "REGULATING", sistemas: ["agua_fria", "agua_quente"],
                        variantes: { soldavel: { material: "pvc_soldavel", aplicacao: "volante", rosca: false, rot: "PVC soldável, volante simples" },
                                     roscavel: { material: "pvc_roscavel", aplicacao: "volante", rosca: true, rot: "PVC roscável, volante simples" },
                                     bruto: { material: "latao", aplicacao: "bruto", rosca: true, rot: "bruto, latão roscável" },
                                     acabamento: { material: "latao", aplicacao: "acabamento", rosca: true, rot: "latão roscável, com acabamento e canopla cromados" } } },
    valvula_retencao: { nome: "Válvula de retenção", fam: "ra-valvula-retencao", ifc: "IFCVALVE", pre: "CHECK", sistemas: ["agua_fria", "agua_quente"],
                        variantes: { bronze: { material: "bronze", aplicacao: "auto", rosca: true, rot: "de bronze, roscável (horizontal ou vertical pelo tubo)" },
                                     pe_crivo: { material: "bronze", aplicacao: "pe_crivo", rosca: true, rot: "de pé com crivo, de bronze, roscável" },
                                     /* PRESSURIZAÇÃO (js/hidpressao.js): no tubo de PVC soldável, a retenção de PVC soldável (o desenho é o do registro de PVC, sem castelo) */
                                     pvc: { material: "pvc_soldavel", aplicacao: "auto", rosca: false, rot: "de PVC soldável (horizontal ou vertical pelo tubo)", semSinapi: true, mercado: "retencao_pvc" } } }
  };
  /* EMBUTIDO × APARENTE (pendências finais, 18/10/2026): o ramal/sub-ramal de água (o do banheiro e da cozinha) corre
     embutido na parede; distribuição, prumada e reservação (barrilete, cavalete, casa de máquinas) são aparentes */
  function embutidoNaParede(t) {
    if (!t || grupoDe(t.sistema) !== "agua") return false;
    var ap = t.aplicacao || aplicacaoAuto(t.sistema, !!t.vertical);
    return ap === "ramal";
  }
  /* o TIPO do registro/válvula quando o projetista não escolheu: a regra acima, no material do tubo */
  function varianteAuto(acessorio, t) {
    var A = ACESSORIOS[acessorio]; if (!A) return null;
    var emb = embutidoNaParede(t), pvc = !!t && t.material === "pvc_soldavel", v;
    if (acessorio === "registro_gaveta") v = emb ? "acabamento" : "bruto";
    else if (acessorio === "registro_pressao") v = emb ? "acabamento" : (pvc ? "soldavel" : "bruto");
    else if (acessorio === "registro_esfera") v = pvc ? "soldavel" : "roscavel";
    else if (acessorio === "valvula_retencao") v = pvc ? "pvc" : "bronze";
    return A.variantes[v] ? v : Object.keys(A.variantes)[0];
  }
  var ACESSORIO_DA_FAM = {};
  Object.keys(ACESSORIOS).forEach(function (k) { ACESSORIO_DA_FAM[ACESSORIOS[k].fam] = k; });
  /* EQUIVALÊNCIA (27/10/2026, Lote 1a das famílias do Hidro): no MENU fica só a `hid-registro-*` (os tipos do catálogo: Docol, Tigre…); o motor a reconhece como o
     MESMO acessório do `ra-registro-*` — divide o trecho, entra na tabela P12/SINAPI e leva a perda de carga do acessório. É TABELA de equivalência, não refatoração:
     a variante (SINAPI, desenho no tubo) sai do lugar do tubo (varianteAuto) e o tipo do catálogo vai em `produto`, só como identificação do produto. */
  var EQUIV_HID = { "hid-registro-gaveta": "registro_gaveta", "hid-registro-pressao": "registro_pressao", "hid-registro-esfera": "registro_esfera" };
  Object.keys(EQUIV_HID).forEach(function (f) { ACESSORIO_DA_FAM[f] = EQUIV_HID[f]; });
  /* bitola de rosca do adaptador para o DN do tubo (mm → polegada).
     FONTE: ABNT NBR 5648 (tubo de PVC soldável — DN × referência). Os outros
     materiais ficam sem equivalência de propósito (pendente com o motivo). */
  /* FRENTE H5 (21/10/2026): a ÁGUA QUENTE do Traçar automaticamente (js/hidaqtraco.js) é PPR e o registro de gaveta de latão
     dela pedia a bitola — sem a linha o orçamento saía PENDENTE. PPR (ABNT NBR 15813): a correspondência DN × rosca dos adaptadores
     dos fabricantes (Tigre/Amanco: DN 20 × 1/2", 25 × 3/4", 32 × 1", …) — a mesma série de diâmetros externos do PVC soldável até
     DN 50; CPVC (ABNT NBR 15884, Aquatherm): 15 × 1/2", 22 × 3/4", 28 × 1", 35 × 1 1/4", 42 × 1 1/2", 54 × 2". */
  var BITOLA_REF = { pvc_soldavel: { 20: "1/2", 25: "3/4", 32: "1", 40: "1 1/4", 50: "1 1/2", 60: "2", 75: "2 1/2", 85: "3", 110: "4" },
    ppr: { 20: "1/2", 25: "3/4", 32: "1", 40: "1 1/4", 50: "1 1/2", 63: "2", 75: "2 1/2", 90: "3", 110: "4" },
    cpvc: { 15: "1/2", 22: "3/4", 28: "1", 35: "1 1/4", 42: "1 1/2", 54: "2" } };
  /* dispositivos = famílias com `mep: {peca}`; a categoria do Revit e a classe IFC
     (a do IMPORTADOR do Revit — revit-ifc, IFCCategoryUtil.cs, lido em 09/10/2026) */
  var DISPOSITIVOS = {
    tomada:      { nome: "Tomada", categoria: "Dispositivos elétricos", ifc: "IFCOUTLET", pre: "POWEROUTLET" },
    interruptor: { nome: "Interruptor", categoria: "Dispositivos elétricos", ifc: "IFCSWITCHINGDEVICE", pre: "TOGGLESWITCH" },
    luminaria:   { nome: "Luminária", categoria: "Luminárias", ifc: "IFCLIGHTFIXTURE", pre: "POINTSOURCE" },
    quadro:      { nome: "Quadro de distribuição", categoria: "Equipamento elétrico", ifc: "IFCELECTRICDISTRIBUTIONBOARD", pre: "DISTRIBUTIONBOARD" }
  };
  /* extras que escolhem entre composições da MESMA chave (como PN/classe no tubo) */
  var EXTRAS_P12 = { tomada: ["placa"], interruptor: ["placa"], quadro: ["corrente"] };
  var ACESSORIO_MIN = 0.04, ACESSORIO_MAX = 0.6, ACESSORIO_PADRAO = 0.06;
  function r6(v) { return Math.round(v * 1e6) / 1e6; }
  function p6(p) { return { x: r6(p.x), y: r6(p.y), z: r6(p.z) }; }
  function soma(p, u, s) { return { x: p.x + u.x * s, y: p.y + u.y * s, z: p.z + u.z * s }; }

  /* o acessório gravado → o acessório "fechado" (faces, conectores, avisos) */
  function normAcessorio(o) {
    if (!o) return null;
    var k = ACESSORIO_DA_FAM[o.famId], A = ACESSORIOS[k]; if (!A) return null;
    var c = pt(o.centro), d = pt(o.dir); if (!c || !d) return null;
    var Ld = Math.sqrt(d.x * d.x + d.y * d.y + d.z * d.z); if (!(Ld > 1e-9)) return null;
    d = { x: d.x / Ld, y: d.y / Ld, z: d.z / Ld };
    var L = num(o.comprimento, ACESSORIO_PADRAO); if (!(L >= ACESSORIO_MIN - 1e-9 && L <= ACESSORIO_MAX + 1e-9)) return null;
    var S = SISTEMAS[o.sistema]; if (!S) return null;
    var variante = A.variantes[o.tipoId] ? o.tipoId : Object.keys(A.variantes)[0], V = A.variantes[variante];
    var a = p6(soma(c, d, -L / 2)), b = p6(soma(c, d, L / 2)), dn = num(o.dn, 0);
    var out = { id: o.id, famId: o.famId, tipoId: o.tipoId, produto: o.produto != null ? txt(o.produto) : undefined, acessorio: k, variante: variante, nome: A.nome, sistema: o.sistema, material: o.material, dn: dn,
                centro: p6(c), dir: p6(d), comprimento: r4(L), a: a, b: b, vertical: Math.abs(d.y) > 0.95, trecho: o.trecho != null ? o.trecho : null, novoId: o.novoId != null ? o.novoId : null, avisos: [] };
    if (num(o.giro, 0) % 360) out.giro = ((num(o.giro, 0) % 360) + 360) % 360;   /* COLOCAÇÃO: giro do castelo/volante em torno do eixo (graus); 0 = o padrão */
    var nm = A.nome.toLowerCase();
    out.conectores = [{ id: o.id + ":e", famInst: o.id, origem: "acessorio", nome: A.nome + " (face 1)", sistema: o.sistema, dn: dn, x: a.x, y: a.y, z: a.z },
                      { id: o.id + ":s", famInst: o.id, origem: "acessorio", nome: A.nome + " (face 2)", sistema: o.sistema, dn: dn, x: b.x, y: b.y, z: b.z }];
    if (A.sistemas.indexOf(o.sistema) < 0) out.avisos.push(nm + " num tubo de " + S.nome.toLowerCase() + ": confira (o acessório é de água)");
    /* 27/10/2026 (D2): em tubo de PVC soldável os 2 adaptadores soldável × rosca JÁ são deduzidos (rede); nos outros materiais continua "orce à parte" */
    if (V.rosca && MATERIAIS[o.material] && !MATERIAIS[o.material].flexivel && o.material !== "pvc_soldavel") out.avisos.push("adaptadores soldável × rosca nas duas faces não são deduzidos — orce à parte");
    return out;
  }
  /* coloca o acessório; com `trecho`, DIVIDE o trecho: [p1, face 1] fica com o
     id dele e [face 2, p2] nasce com `novoId` (o resto igual: material, DN,
     aplicação; a inclinação continua a mesma porque as faces estão no eixo) */
  function aplicarAcessorio(est, o) {
    var k = ACESSORIO_DA_FAM[o.famId], A = ACESSORIOS[k]; if (!A || o.id == null) return false;
    if (est.acessorios[o.id] || est.trechos[o.id] || est.pecas[o.id]) return false;
    var L = num(o.comprimento, ACESSORIO_PADRAO), P = pt(o);
    if (!P || !(L >= ACESSORIO_MIN && L <= ACESSORIO_MAX)) return false;
    var reg = { id: o.id, famId: o.famId, tipoId: txt(o.tipoId), comprimento: r4(L) };
    if (o.produto != null && txt(o.produto)) reg.produto = txt(o.produto);   /* o tipo do CATÁLOGO (hid-registro-*): identificação do produto, não muda a variante */
    if (num(o.giro, 0) % 360) reg.giro = ((num(o.giro, 0) % 360) + 360) % 360;   /* COLOCAÇÃO (js/biminstcolocar.js) */
    if (o.trecho != null) {
      var t = est.trechos[o.trecho];
      if (!t || o.novoId == null || est.trechos[o.novoId] || est.pecas[o.novoId] || est.acessorios[o.novoId]) return false;
      var n = normTrecho(t); if (!n) return false;
      var M = MATERIAIS[n.material] || {};
      if (M.secao || M.flexivel || A.sistemas.indexOf(n.sistema) < 0) return false;   /* registro é de tubo rígido de água */
      var u = unit(n.p1, n.p2), s = (P.x - n.p1.x) * u.x + (P.y - n.p1.y) * u.y + (P.z - n.p1.z) * u.z;
      var q = soma(n.p1, u, s);
      if (dist(q, P) > 0.05) return false;                                    /* o ponto não está no eixo do tubo */
      if (s - L / 2 < TOL || s + L / 2 > n.comprimento - TOL) return false;   /* não cabe: precisa sobrar tubo dos dois lados */
      var fa = p6(soma(n.p1, u, s - L / 2)), fb = p6(soma(n.p1, u, s + L / 2));
      var novo = copia(t); novo.id = o.novoId; novo.p1 = fb; novo.p2 = copia(t.p2);
      t.p2 = fa;
      est.trechos[o.novoId] = novo;
      est.ordemT.splice(est.ordemT.indexOf(o.trecho) + 1, 0, o.novoId);
      reg.trecho = o.trecho; reg.novoId = o.novoId; reg.centro = p6(q); reg.dir = p6(u);
      reg.sistema = n.sistema; reg.material = n.material; reg.dn = n.dn;
    } else {
      var sis = A.sistemas.indexOf(o.sistema) >= 0 ? o.sistema : A.sistemas[0], S = SISTEMAS[sis];
      var d = pt(o.dir) || { x: 1, y: 0, z: 0 };
      reg.sistema = sis; reg.material = S.materiais.indexOf(o.material) >= 0 ? o.material : S.material;
      reg.dn = num(o.dn, MATERIAIS[reg.material].dn); reg.centro = p6(P); reg.dir = d;
    }
    if (!normAcessorio(reg)) return false;
    est.acessorios[o.id] = reg; est.ordemAc.push(o.id);
    return true;
  }
  /* apagar o acessório EMENDA o tubo (se as duas metades continuam onde ele as deixou) */
  function apagarAcessorio(est, id) {
    var a = normAcessorio(est.acessorios[id]);
    delete est.acessorios[id]; est.ordemAc.splice(est.ordemAc.indexOf(id), 1);
    if (!a) return true;
    var t = a.trecho != null ? est.trechos[a.trecho] : null, nv = a.novoId != null ? est.trechos[a.novoId] : null;
    if (t && nv && pt(t.p2) && pt(nv.p1) && dist(pt(t.p2), a.a) <= TOL && dist(pt(nv.p1), a.b) <= TOL) {
      t.p2 = copia(nv.p2);
      delete est.trechos[a.novoId]; est.ordemT.splice(est.ordemT.indexOf(a.novoId), 1);
    }
    return true;
  }

  /* --------------------------------------------- conexões da ELETROCALHA
   * A SINAPI 06/2026 tem curva/cotovelo HORIZONTAL 90°, tê horizontal 90° e
   * redução, todos por largura (altura 50 mm). A emenda entre dois trechos
   * em linha já está no metro ("inclusive emenda e fixação"): nada é
   * deduzido ali. Curva vertical: sai a peça, pendente (não há composição). */
  function decidirBandeja(ramos, sistema, conector, avisos, out, cx) {
    var n = ramos.length; if (n < 2) return out;
    var dns = ramos.map(function (r) { return r.dn; }), dnM = Math.max.apply(null, dns);
    var horiz = ramos.every(function (r) { return Math.abs(r.dir.y) < 0.1; }), apl = horiz ? "horizontal" : "vertical";
    function reducoes(base) { ramos.forEach(function (r) { if (r.dn < base - 0.5) cx("reducao", base, r.dn, { aplicacao: "horizontal" }); }); }
    if (n === 2) {
      var dv = desvio(ramos[0].dir, ramos[1].dir);
      if (dv < 10) { reducoes(dnM); return out; }
      if (!(dv >= 80 && dv <= 100)) avisos.push("eletrocalha muda de direção em " + Math.round(dv) + "°: a SINAPI só tem curva de 90° — confira o traçado");
      if (!horiz) avisos.push("curva VERTICAL de eletrocalha: a SINAPI 06/2026 não tem a peça — pendente");
      cx("joelho90", dnM, 0, { aplicacao: apl }); reducoes(dnM);
      return out;
    }
    if (n === 3) {
      if (!horiz) avisos.push("tê VERTICAL de eletrocalha: a SINAPI 06/2026 não tem a peça — pendente");
      cx("te", dnM, 0, { aplicacao: apl }); reducoes(dnM);
      return out;
    }
    avisos.push("nó com " + n + " eletrocalhas: a SINAPI 06/2026 não tem cruzeta de eletrocalha — desdobre em dois tês");
    return out;
  }

  /* o item SINAPI de um acessório e de um dispositivo */
  function itemAcessorio(a) {
    var A = ACESSORIOS[a.acessorio], V = A.variantes[a.variante];
    var it = { peca: a.acessorio, sistema: a.sistema, material: V.material, aplicacao: V.aplicacao === "auto" ? (a.vertical ? "vertical" : "horizontal") : V.aplicacao, dn: "", variante: a.variante, dnTubo: a.dn };
    if (V.rosca) {
      var b = (BITOLA_REF[a.material] || {})[a.dn];
      it.dn = b || ("DN " + a.dn);
      if (!b) it.semTabela = A.nome + " " + V.rot + ": a bitola de rosca para o tubo " + ((MATERIAIS[a.material] || {}).nome || a.material) + " DN " + a.dn + " não está tabelada (BITOLA_REF: PVC soldável, PPR e CPVC) — pendente";
    } else {
      it.dn = String(a.dn);
      if (a.material !== V.material) it.semTabela = A.nome + " " + V.rot + " no tubo de " + ((MATERIAIS[a.material] || {}).nome || a.material) + ": não casa — troque o tipo do registro (pendente)";
      else if (V.semSinapi) it.semTabela = "a SINAPI 06/2026 não tem composição de " + A.nome.toLowerCase() + " " + V.rot.replace(/\s*\(.*\)$/, "") + " — pendente (nunca a parecida)";
    }
    if (V.mercado) it.mercado = V.mercado + "|" + a.dn;   /* a referência de mercado (js/hidprecomercado.js) quando não há SINAPI */
    return it;
  }
  function inteiro(v, d) { var n = Math.round(num(v, d)); return isFinite(n) ? n : d; }
  function itemDispositivo(av) {
    var mp = av && av.mep, v = (av && av.valores) || {};
    if (!mp || !DISPOSITIVOS[mp.peca]) return null;
    var p = mp.peca, it = { peca: p, sistema: "eletrica", material: "", aplicacao: "", dn: "" };
    if (p === "tomada") { it.material = "2pt" + inteiro(v.Corrente_A, 10) + "a"; it.aplicacao = alturaCaixa(num(v.Altura_montagem, 0.3)); it.dn = String(inteiro(v.Modulos, 1)); it.placa = v.Placa === false ? "sem" : "com"; }
    else if (p === "interruptor") { it.material = txt(v.Tipo_interruptor).toLowerCase(); it.aplicacao = "10a"; it.dn = String(inteiro(v.Modulos, 1)); it.placa = v.Placa === false ? "sem" : "com"; }
    else if (p === "luminaria") { it.material = txt(v.Modelo); it.aplicacao = txt(v.Instalacao); it.dn = txt(v.Potencia_W) || "-"; }
    else if (p === "quadro") { it.material = txt(v.Material_quadro); it.aplicacao = txt(v.Instalacao); it.dn = String(inteiro(v.Disjuntores, 0)); if (txt(v.Corrente)) it.corrente = txt(v.Corrente); }
    return it;
  }
  /* a família colocada que é DISPOSITIVO MEP (orçada por aqui). Família com
     serviço próprio (o usuário escolheu a composição) segue pelo caminho da família. */
  function familiaMep(av, f) {
    if (f && arr(f.servicos).length) return null;
    return itemDispositivo(av);
  }
  function dispositivosDo(estado, avaliarFam) {
    var out = [];
    if (typeof avaliarFam !== "function") return out;
    arr(estado && estado.familias).forEach(function (f) {
      var av = avaliarFam(f.famId, f.tipoId, f.inst), it = familiaMep(av, f);
      if (it && it.peca === "interruptor") { var cps = composInterruptor(it, f); if (cps) it.composicoes = cps; }
      if (it) out.push({ id: f.id, item: it, av: av, inst: f });
    });
    return out;
  }
  /* ⚠ ORÇAMENTO 100 % (integração n23, 23/10/2026): a placa que a SINAPI MG 06/2026 não tem como composição ÚNICA — o
     intermediário de 2 ou 3 módulos (o four-way de vários comandos) e a placa MISTA (o geral em paralelo e os spots simples) —
     saía PENDENTE, R$ 0 no orçamento. Agora: a combinação exata quando ela existe na SINAPI (simples + paralelo, chave em ordem alfabética: 91957, 91963,
     91965, 91973, 91971 — conferidas na base) e, sem ela, a SOMA dos módulos que existem: 1 módulo "incluindo suporte e placa" +
     os demais "sem suporte e sem placa", cada um pela composição SINAPI do seu esquema. Nunca a parecida: cada parcela é o módulo
     que está na placa. Os esquemas vêm do parâmetro Esquemas (contrato da iluminação), senão do Tipo_interruptor repetido. */
  var INT_COMBO = { "paralelo1+simples1": ["91957", "91956", "INTERRUPTOR SIMPLES (1 MÓDULO) COM INTERRUPTOR PARALELO (1 MÓDULO)"], "paralelo2+simples1": ["91963", "91962", "INTERRUPTOR SIMPLES (1 MÓDULO) COM INTERRUPTOR PARALELO (2 MÓDULOS)"],
    "paralelo1+simples2": ["91965", "91964", "INTERRUPTOR SIMPLES (2 MÓDULOS) COM INTERRUPTOR PARALELO (1 MÓDULO)"], "paralelo2+simples2": ["91973", "91972", "INTERRUPTOR SIMPLES (2 MÓDULOS) COM INTERRUPTOR PARALELO (2 MÓDULOS)"],
    "paralelo1+simples3": ["91971", "91970", "INTERRUPTOR SIMPLES (3 MÓDULOS) COM INTERRUPTOR PARALELO (1 MÓDULO)"] };
  function composInterruptor(it, f) {
    if (sinapiDe(it).status === "ok") return null;
    var T = tabela(); if (!T || !T.chaves) return null;
    var nMod = Math.max(1, num(it.dn, 1)), esq = txt(f && f.inst && f.inst.Esquemas).split(",").map(function (s) { return s.trim().toLowerCase(); }).filter(Boolean);
    if (esq.length !== nMod) { if (it.material === "misto") return null; esq = []; for (var i = 0; i < nMod; i++) esq.push(it.material); }
    var com = it.placa !== "sem", conta = {};
    esq.forEach(function (e) { conta[e] = (conta[e] || 0) + 1; });
    function cod(chave, placa) { var c = arr(T.chaves[chave]).filter(function (x) { return x[3] && x[3].placa === placa; })[0]; return c || null; }
    function linhaDe(c, qtd, obs) { return { status: "ok", codigo: c[0], unidade: c[1], descricao: c[2], rotulo: rotuloP12(it), alternativas: 0, qtd: qtd, observacao: obs }; }
    var kc = Object.keys(conta).sort().map(function (k) { return k + conta[k]; }).join("+"), ex = INT_COMBO[kc];
    if (ex) {
      return [{ status: "ok", codigo: ex[com ? 0 : 1], unidade: "UN", descricao: ex[2] + ", 10A/250V, " + (com ? "INCLUINDO SUPORTE E PLACA" : "SEM SUPORTE E SEM PLACA") + " - FORNECIMENTO E INSTALAÇÃO. AF_03/2023", rotulo: rotuloP12(it), alternativas: 0, qtd: 1,
               observacao: "placa " + esq.join(" + ") + ": a composição SINAPI da combinação (integração n23)" }];
    }
    var out = [], primeira = true, falta = null;
    esq.forEach(function (e) {
      if (falta) return;
      var c = cod("interruptor|" + e + "|10a|1", primeira && com ? "com" : "sem");
      if (!c) { falta = e; return; }
      var ja = out.filter(function (x) { return x.codigo === c[0]; })[0];   /* o mesmo módulo duas vezes = UMA linha com 2 (sem linha repetida no orçamento) */
      if (ja) ja.qtd += 1;
      else out.push(linhaDe(c, 1, "placa de " + nMod + " módulos (" + esq.join(" + ") + ") sem composição SINAPI única: orçada pela soma dos módulos — 1 com suporte e placa, os outros sem (integração n23)"));
      primeira = false;
    });
    return falta ? null : out;
  }
  function rotuloP12(it) {
    var A = ACESSORIOS[it.peca];
    if (A) {
      var V = A.variantes[it.variante] || {};
      return A.nome + " " + (V.rot || it.material) + " " + (V.rosca ? it.dn + (/^DN/.test(it.dn) ? "" : "\"") : "DN " + it.dn) + (it.aplicacao === "vertical" || it.aplicacao === "horizontal" ? " (" + it.aplicacao + ")" : "");
    }
    if (it.peca === "tomada") return "Tomada 2P+T " + it.material.replace(/^2pt|a$/g, "") + " A, " + it.dn + (it.dn === "1" ? " módulo" : " módulos") + ", " + ({ baixa: "baixa (0,30 m)", media: "média (1,30 m)", alta: "alta (2,00 m)" }[it.aplicacao] || it.aplicacao) + (it.placa === "sem" ? ", sem placa" : ", com suporte e placa");
    if (it.peca === "interruptor") return "Interruptor " + it.material + ", " + it.dn + (it.dn === "1" ? " módulo" : " módulos") + (it.placa === "sem" ? ", sem placa" : ", com suporte e placa");
    if (it.peca === "luminaria") return "Luminária " + it.material.replace(/_/g, " ") + " de " + it.aplicacao + (it.dn && it.dn !== "-" ? ", " + it.dn + " W" : "");
    if (it.peca === "quadro") return "Quadro de distribuição " + it.material.replace(/_/g, " ") + (it.aplicacao && it.aplicacao !== "qdl" ? " de " + it.aplicacao : "") + ", " + it.dn + " disjuntores" + (it.corrente ? " " + it.corrente : "");
    return it.peca;
  }

  /* ================================================ SISTEMAS (nome e número)
   * Trechos ligados (nó comum, peça, acessório no meio) = UM sistema. Aparelho
   * não junta (a caixa d'água separa a alimentação da distribuição). Número
   * por tipo, na ordem do modelo; nome do usuário (instSistema) vence. */
  function sistemas(estado, avaliarFam, R) {
    R = R || rede(estado, avaliarFam);
    var pai = {};
    function f(x) { while (pai[x] !== x) { pai[x] = pai[pai[x]]; x = pai[x]; } return x; }
    function u(a, b) { if (pai[a] == null || pai[b] == null) return; var ra = f(a), rb = f(b); if (ra !== rb) pai[rb] = ra; }
    R.trechos.forEach(function (t) { pai[t.id] = t.id; });
    arr(R.nosRamos).forEach(function (l) { for (var i = 1; i < l.length; i++) u(l[0], l[i]); });
    var porAlvo = {};
    R.ligacoes.forEach(function (lg) { if (lg.tipo === "acessorio" || lg.tipo === "peca") { var k = lg.tipo === "peca" ? "k:" + lg.alvo : "a:" + lg.famInst; (porAlvo[k] = porAlvo[k] || []).push(lg.trecho); } });
    Object.keys(porAlvo).forEach(function (k) { var l = porAlvo[k]; for (var i = 1; i < l.length; i++) u(l[0], l[i]); });
    var nomes = (estado && estado.instalacoes && estado.instalacoes.nomesSistema) || {};
    var comp = {}, ordem = [], porTipo = {}, porTrecho = {};
    R.trechos.forEach(function (t) {
      var r = f(t.id);
      if (!comp[r]) { porTipo[t.sistema] = (porTipo[t.sistema] || 0) + 1; var S = SISTEMAS[t.sistema]; comp[r] = { sistema: t.sistema, n: porTipo[t.sistema], codigo: S.abrev + "-" + porTipo[t.sistema], nomeAuto: S.nome + " " + porTipo[t.sistema], nome: null, trechos: [], metros: 0, acessorios: [], pecas: [] }; ordem.push(r); }
      comp[r].trechos.push(t.id); comp[r].metros = r4(comp[r].metros + t.comprimento);
      if (!comp[r].nome && nomes[t.id]) comp[r].nome = txt(nomes[t.id]);
      porTrecho[t.id] = comp[r];
    });
    var lista = ordem.map(function (r) { var c = comp[r]; if (!c.nome) c.nome = c.nomeAuto; return c; });
    arr(R.acessorios).forEach(function (a) { var c = porTrecho[a.trecho] || porTrecho[a.novoId]; if (c) c.acessorios.push(a.id); });
    R.ligacoes.forEach(function (lg) { if (lg.tipo === "peca" && porTrecho[lg.trecho] && porTrecho[lg.trecho].pecas.indexOf(lg.alvo) < 0) porTrecho[lg.trecho].pecas.push(lg.alvo); });
    return { lista: lista, porTrecho: porTrecho, de: function (id) { return porTrecho[id] || null; } };
  }

  /* ================================================ VERIFICAR SISTEMAS
   * "Verificar sistemas" + "Mostrar desconexões", para obra pequena:
   * cada item com o tipo, a gravidade, o texto, o ponto e as peças. */
  var TIPOS_VERIF = { ponta: "Ponta solta", conector: "Ponto de ligação sem tubo", misturado: "Sistemas misturados", inclinacao: "Inclinação", bitola: "Medida fora da tabela", rede: "Traçado", acessorio: "Acessório" };
  /* ================================================ CONECTIVIDADE: "nenhuma peça desconectada" (frente A, 19/10/2026)
   * Pedido do Rogério: a marca "continua" (espera) NÃO pode esconder ponta solta. Antes, toda ponta marcada "continua" saía
   * do verificador — e a descida da válvula de descarga começava no ar, abaixo da válvula, sem ninguém acusar (D-02 do
   * docs/hidro/DIAGNOSTICO-2026-10-19.md). Regra R-E2 (docs/hidro/PADROES-PROJETO-RA.md): extremidade aberta SÓ em
   *   · ventilação: a ponta de CIMA de um trecho que sobe (o terminal acima da cobertura);
   *   · esgoto/pluvial: a ponta de JUSANTE (a mais baixa) — o lançamento na rede pública/fossa ou a espera para a rede;
   *   · água: a ponta de CIMA de um trecho que sobe (a espera do barrilete/coluna de alimentação);
   *   · as esperas de projeto do prédio (js/hidpredio.js) e da piscina (js/hidpiscinarede.js), que já viram pendência lá.
   * Qualquer outra ponta "continua" é ponta SOLTA. E a espera que fica a menos de PERTO_ESPERA de outra ponta ou de um ponto
   * de aparelho do MESMO sistema também é solta: é tubo que devia encostar e não encosta (o caso da válvula). */
  var PERTO_ESPERA = 0.15;   /* bim:geo distância em que uma "espera" é, na verdade, um tubo que não encostou */
  var ALINHADO_ESPERA = 0.9;   /* bim:geo o ponto fica no PROLONGAMENTO do tubo (cos ≥ 0,9): é o tubo que devia chegar até ele */
  var SIS_CONECT = { esgoto: 1, pluvial: 1, ventilacao: 1, agua_fria: 1, agua_quente: 1 };
  function esperaPermitida(t, ponta, R) {
    if (!t || !SIS_CONECT[t.sistema]) return "fora do hidrossanitário";
    var p = t[ponta], q = t[ponta === "p1" ? "p2" : "p1"]; if (!p || !q) return null;
    var dy = p.y - q.y, dh = Math.sqrt((p.x - q.x) * (p.x - q.x) + (p.z - q.z) * (p.z - q.z)), sobe = dy > dh;
    /* tubo que devia encostar: outra ponta ou ponto de aparelho livre do mesmo sistema logo ali, no PROLONGAMENTO do tubo
       (a outra ponta do PRÓPRIO trecho — o nó dele — não conta) */
    function enc(e) { var de = dist(e, p); if (de > PERTO_ESPERA || dist(e, q) <= TOL) return false; if (de <= TOL) return true; var u = unit(q, p), w = unit(p, e); return u.x * w.x + u.y * w.y + u.z * w.z >= ALINHADO_ESPERA; }
    var perto = R && (arr(R.trechos).some(function (o) { return o.id !== t.id && o.sistema === t.sistema && (enc(o.p1) || enc(o.p2)); }) ||
      arr(R.conectoresLivres).some(function (c) { return c.sistema === t.sistema && enc(c); }));
    if (perto) return null;
    if (t.predio || t.piscLinha) return "espera de projeto (" + (t.predio ? "prédio" : "piscina") + ")";
    if (t.saidaLivre) return "saída livre (" + t.saidaLivre + ")";
    /* ⚠ (revisão adversarial, 20/10/2026) a ponta "continua" de ventilação ENCOSTADA no meio de um esgoto é a tomada que NÃO virou tê
       (a ventilação desce dele, ou sai deitada): é desconexão, nunca terminal — antes a ventilação que descia do esgoto tinha a ponta
       de cima no esgoto e passava como "terminal", e o cartão dizia "Pronto" */
    if (t.sistema === "ventilacao" && R && arr(R.trechos).some(function (o) { if (o.sistema !== "esgoto" || !o.p1 || !o.p2) return false; var d = noInterior(p, o.p1, o.p2); return d != null && d <= TOL; })) return null;
    if (t.sistema === "ventilacao") return sobe ? "terminal da ventilação" : null;
    if (t.sistema === "esgoto" || t.sistema === "pluvial") return dy < -EPS_ESPERA || (Math.abs(dy) <= EPS_ESPERA && ponta === "p2") ? "espera de jusante (lançamento)" : null;
    /* água: a alimentação vem de cima (barrilete/coluna) — a espera é o ponto MAIS ALTO da rede ligada a ela (o barrilete curto
       sob a laje é deitado), ou a ÚNICA ponta aberta da rede (a espera do kit por onde o ramal vai chegar: a lateral do
       chuveiro). Rede com duas pontas abertas: a que não é a de cima está solta */
    var topo = R && R._topoAgua ? R._topoAgua(t) : null, nAb = R && R._abertas ? R._abertas(t) : 0;
    if (topo == null) return sobe ? "espera de alimentação (barrilete/coluna)" : null;
    return p.y >= topo - EPS_ESPERA ? "espera de alimentação (barrilete/coluna)" : (nAb === 1 ? "espera de alimentação do kit (o ramal chega por ela)" : null);
  }
  var EPS_ESPERA = 1e-4;   /* bim:geo cota igual (m) */
  /* as pontas soltas da rede, com as "continua" que não são espera permitida — { soltas[], esperas[] } */
  function conectividade(estado, avaliarFam, R0) {
    var R = R0 || rede(estado, avaliarFam), Rbase = R, porId = {}, soltas = [], esperas = [];
    arr(R.trechos).forEach(function (t) { porId[t.id] = t; });
    /* as redes ligadas (mesmo sistema): nós da rede + o que passa por dentro de acessório/família (registro, válvula) */
    var pai = {};
    function acha(x) { while (pai[x] != null && pai[x] !== x) x = pai[x]; return x; }
    function une(a, b) { if (!porId[a] || !porId[b] || porId[a].sistema !== porId[b].sistema) return; var ra = acha(a), rb = acha(b); if (ra !== rb) pai[ra] = rb; }
    arr(R.trechos).forEach(function (t) { pai[t.id] = t.id; });
    arr(R.nosRamos).forEach(function (l) { for (var i = 1; i < l.length; i++) une(l[0], l[i]); });
    var porFam = {}; arr(R.ligacoes).forEach(function (l) { if (l.famInst == null) return; var k = l.famInst + "|" + (porId[l.trecho] || {}).sistema; if (porFam[k]) une(porFam[k], l.trecho); else porFam[k] = l.trecho; });
    var topo = {};
    arr(R.trechos).forEach(function (t) { var r = acha(t.id), y = Math.max(t.p1.y, t.p2.y); if (topo[r] == null || y > topo[r]) topo[r] = y; });
    var abertas = {}; arr(R.pontasLivres).concat(arr(R.continuacoes)).forEach(function (c) { if (!porId[c.trecho]) return; var r = acha(c.trecho); abertas[r] = (abertas[r] || 0) + 1; });
    R = Object.create(R); R._topoAgua = function (t) { return topo[acha(t.id)]; }; R._abertas = function (t) { return abertas[acha(t.id)] || 0; };
    R.pontasLivres.forEach(function (p) { var t = porId[p.trecho]; soltas.push({ trecho: p.trecho, sistema: t ? t.sistema : null, x: p.x, y: p.y, z: p.z, motivo: "ponta solta" }); });
    arr(R.continuacoes).forEach(function (c) {
      var t = porId[c.trecho], m = esperaPermitida(t, c.ponta, R);
      if (m) esperas.push({ trecho: c.trecho, sistema: t ? t.sistema : null, ponta: c.ponta, x: c.x, y: c.y, z: c.z, motivo: m });
      else soltas.push({ trecho: c.trecho, sistema: t ? t.sistema : null, ponta: c.ponta, x: c.x, y: c.y, z: c.z, motivo: "ponta marcada \"continua\" que não é espera permitida (só terminal de ventilação, lançamento do esgoto e espera de alimentação)", continua: true });
    });
    return { soltas: soltas, esperas: esperas, rede: Rbase };
  }

  function verificar(estado, avaliarFam) {
    var R = rede(estado, avaliarFam), S = sistemas(estado, avaliarFam, R), itens = [];
    function add(tipo, grav, texto, p, ids) { itens.push({ tipo: tipo, rotuloTipo: TIPOS_VERIF[tipo], gravidade: grav, texto: texto, x: p ? r4(p.x) : null, y: p ? r4(p.y) : null, z: p ? r4(p.z) : null, ids: ids || [] }); }
    /* ⚠ ponta solta é ERRO (frente A, 19/10/2026): a "continua" que não é espera permitida entra aqui também (conectividade) */
    conectividade(estado, avaliarFam, R).soltas.forEach(function (p) { var c = S.de(p.trecho); add("ponta", "erro", "ponta solta do trecho " + p.trecho + (c ? " (" + c.codigo + " — " + c.nome + ")" : "") + (p.continua ? " — marcada \"continua\", mas não é espera permitida" : ""), p, [p.trecho]); });
    R.conectoresLivres.forEach(function (k) { add("conector", "aviso", (k.origem === "acessorio" ? k.nome.toLowerCase() + " " + k.famInst : "ponto \"" + k.nome + "\" de " + k.famInst) + " sem tubo (" + SISTEMAS[k.sistema].nome.toLowerCase() + ")", k, [k.famInst]); });
    R.avisos.forEach(function (a) { var mist = /sistemas diferentes|terminando em|no ponto de/.test(a.texto); add(mist ? "misturado" : "rede", mist ? "erro" : "aviso", a.texto, a, []); });
    R.trechos.forEach(function (t) {
      t.avisos.forEach(function (a) {
        var tp = /abaixo da mínima|SOBE/.test(a) ? "inclinacao" : (/bitola comercial|fora das medidas/.test(a) ? "bitola" : "rede");
        add(tp, tp === "inclinacao" ? "erro" : "aviso", "trecho " + t.id + ": " + a, { x: (t.p1.x + t.p2.x) / 2, y: (t.p1.y + t.p2.y) / 2, z: (t.p1.z + t.p2.z) / 2 }, [t.id]);
      });
    });
    arr(R.acessorios).forEach(function (a) { a.avisos.forEach(function (x) { add("acessorio", "aviso", a.nome.toLowerCase() + " " + a.id + ": " + x, a.centro, [a.id]); }); });
    var resumo = {}; Object.keys(TIPOS_VERIF).forEach(function (k) { resumo[k] = 0; });
    itens.forEach(function (i) { resumo[i.tipo]++; });
    return { itens: itens, resumo: resumo, total: itens.length, erros: itens.filter(function (i) { return i.gravidade === "erro"; }).length, sistemas: S.lista, rede: R };
  }

  /* ================================================ TUBOS / ELETRODUTOS PARALELOS
   * A partir de um trecho, segue a linha (nós de 2 trechos do mesmo sistema,
   * sem derivação) e devolve n cópias deslocadas EM PLANTA, com os cantos em
   * esquadria — os joelhos das cópias saem sozinhos no replay. */
  function paralelos(estado, trechoId, o) {
    o = o || {};
    var n = Math.max(1, Math.min(10, Math.round(num(o.n, 1)))), esp = num(o.espacamento, 0.15), lado = num(o.lado, 1) < 0 ? -1 : 1;
    if (!(esp >= 0.02 && esp <= 3)) return { ok: false, motivo: "espaçamento entre 0,02 e 3 m" };
    var ts = arr(estado && estado.instalacoes && estado.instalacoes.trechos), por = {};
    ts.forEach(function (t) { por[t.id] = t; });
    var t0 = por[trechoId]; if (!t0) return { ok: false, motivo: "trecho " + trechoId + " não existe" };
    if (t0.vertical || t0.comprimentoH < 0.01) return { ok: false, motivo: "trecho vertical: paralelos são em planta (desloque a prumada à mão)" };
    function toca(p, excl) { return ts.filter(function (t) { if (t.id === excl) return false; if (dist(t.p1, p) <= TOL || dist(t.p2, p) <= TOL) return true; var d = noInterior(p, t.p1, t.p2); return d != null && d <= TOL; }); }
    function seguir(t, ponta, vistos) {
      var cadeia = [];
      for (var g = 0; g < 500; g++) {
        var viz = toca(ponta, t.id);
        if (viz.length !== 1) break;
        var v = viz[0];
        if (vistos[v.id] || v.sistema !== t0.sistema || v.vertical || v.comprimentoH < 0.01) break;
        var inicio = dist(v.p1, ponta) <= TOL, fim = dist(v.p2, ponta) <= TOL; if (!inicio && !fim) break;
        vistos[v.id] = 1;
        var outra = inicio ? v.p2 : v.p1;
        cadeia.push({ t: v, de: ponta, ate: outra });
        t = v; ponta = outra;
      }
      return cadeia;
    }
    var vistos = {}; vistos[t0.id] = 1;
    var tras = seguir(t0, t0.p1, vistos), frente = seguir(t0, t0.p2, vistos);
    var segs = tras.reverse().map(function (s) { return { t: s.t, a: s.ate, b: s.de }; }).concat([{ t: t0, a: t0.p1, b: t0.p2 }]).concat(frente.map(function (s) { return { t: s.t, a: s.de, b: s.ate }; }));
    var pts = [segs[0].a].concat(segs.map(function (s) { return s.b; }));
    var nrm = segs.map(function (s) { var dx = s.b.x - s.a.x, dz = s.b.z - s.a.z, L = Math.sqrt(dx * dx + dz * dz) || 1; return { x: -dz / L, z: dx / L }; });
    var copias = [], avisos = [];
    for (var k = 1; k <= n; k++) {
      var d = k * esp * lado, q = pts.map(function (p, i) {
        var n1 = nrm[Math.max(0, i - 1)], n2 = nrm[Math.min(nrm.length - 1, i)];
        var mx = n1.x + n2.x, mz = n1.z + n2.z, Lm = Math.sqrt(mx * mx + mz * mz);
        if (Lm < 1e-6) { mx = n1.x; mz = n1.z; Lm = 1; }
        mx /= Lm; mz /= Lm;
        var c = mx * n1.x + mz * n1.z; if (c < 0.25) { c = 0.25; if (k === 1) avisos.push("canto muito fechado no ponto " + (i + 1) + ": a esquadria foi limitada"); }
        return { x: r4(p.x + mx * d / c), y: p.y, z: r4(p.z + mz * d / c) };
      });
      copias.push(segs.map(function (s, i) { return { de: s.t.id, p1: q[i], p2: q[i + 1] }; }));
    }
    return { ok: true, cadeia: segs.map(function (s) { return s.t.id; }), copias: copias, avisos: avisos };
  }

  /* ================================================ LEGENDA e TABELA DE PEÇAS */
  function tamanhoTrecho(t) { var M = MATERIAIS[t.material] || {}; return M.secao === "retangular" ? Math.round(t.larg * 1000) + "×" + Math.round(t.alt * 1000) : "Ø" + t.dn; }
  function legenda(estado) {
    var por = {}, ordem = [];
    arr(estado && estado.instalacoes && estado.instalacoes.trechos).forEach(function (t) {
      var S = SISTEMAS[t.sistema]; if (!S) return;
      if (!por[t.sistema]) { por[t.sistema] = { sistema: t.sistema, nome: S.nome, abrev: S.abrev, cor: S.cor, tamanhos: [], metros: 0 }; ordem.push(t.sistema); }
      var g = por[t.sistema], tm = tamanhoTrecho(t);
      if (g.tamanhos.indexOf(tm) < 0) g.tamanhos.push(tm);
      g.metros = r4(g.metros + t.comprimento);
    });
    var chaves = Object.keys(SISTEMAS);
    return ordem.sort(function (a, b) { return chaves.indexOf(a) - chaves.indexOf(b); }).map(function (k) {
      por[k].tamanhos.sort(function (a, b) { return parseFloat(a.replace(/^Ø/, "")) - parseFloat(b.replace(/^Ø/, "")); });
      return por[k];
    });
  }
  function legendaNaPlanta(estado, out) {
    var L = legenda(estado); if (!L.length) return;
    var xs = [], ys = [];
    out.linhas.forEach(function (l) { xs.push(l.seg[0], l.seg[2]); ys.push(l.seg[1], l.seg[3]); });
    out.simbolos.forEach(function (m) { xs.push(m.x); ys.push(m.y); });
    if (!xs.length) return;
    var x0 = r4(Math.max.apply(null, xs) + 0.8), y0 = r4(Math.min.apply(null, ys)), passo = 0.45;
    out.textos.push({ x: r4(x0 + 1.4), y: y0, t: "LEGENDA — TUBULAÇÃO", cor: "#333333", rot: 0, legenda: true });
    L.forEach(function (g, i) {
      var y = r4(y0 + passo * (i + 1)), tx = g.abrev + " — " + g.nome + ": " + g.tamanhos.join(", ");
      out.linhas.push({ seg: [x0, y, r4(x0 + 0.6), y], cor: g.cor, tracejado: false, largura: 0, sistema: g.sistema, id: "leg:" + g.sistema, legenda: true });
      out.textos.push({ x: r4(x0 + 0.75 + tx.length * 0.0275), y: r4(y + 0.12), t: tx, cor: g.cor, rot: 0, legenda: true });
    });
    out.legenda = L;
  }
  /* a gravata do registro na planta: dois triângulos opostos pelo vértice */
  function simboloAcessorio(a) {
    var ux = a.dir.x, uz = a.dir.z, Lu = Math.sqrt(ux * ux + uz * uz);
    var c = a.centro;
    if (Lu < 1e-6) { var r = Math.max(a.comprimento / 2, 0.05); return [[r4(c.x - r), r4(c.z - r), r4(c.x + r), r4(c.z + r)], [r4(c.x - r), r4(c.z + r), r4(c.x + r), r4(c.z - r)]]; }
    ux /= Lu; uz /= Lu;
    var h = Math.max(a.comprimento / 2, 0.06), w = Math.max(h * 0.8, 0.05), nx = -uz, nz = ux;
    var A1 = [c.x - ux * h + nx * w, c.z - uz * h + nz * w], A2 = [c.x - ux * h - nx * w, c.z - uz * h - nz * w];
    var B1 = [c.x + ux * h + nx * w, c.z + uz * h + nz * w], B2 = [c.x + ux * h - nx * w, c.z + uz * h - nz * w];
    function sg(p, q) { return [r4(p[0]), r4(p[1]), r4(q[0]), r4(q[1])]; }
    return [sg(A1, A2), sg(A1, B2), sg(A2, B1), sg(B1, B2)];
  }
  /* a categoria do Revit (PTB, exportlayers-ifc-IAI.txt do Revit 2027) de cada peça */
  function categoriaRevit(tipo, sistema, material) {
    var g = grupoDe(sistema), M = MATERIAIS[material] || {};
    if (tipo === "trecho") return g === "eletrica" ? "Conduites" : (g === "bandeja" ? "Bandejas de cabos" : (g === "ar" ? (M.flexivel ? "Dutos flexíveis" : "Dutos") : (M.flexivel ? "Tubulação flexível" : "Tubulação")));
    if (tipo === "conexao") return g === "eletrica" ? "Conexões do conduite" : (g === "bandeja" ? "Conexões da bandeja de cabos" : (g === "ar" ? "Conexões de duto" : "Conexões de tubo"));
    if (tipo === "acessorio") return "Acessórios do tubo";
    return null;
  }
  function tabelaPecas(estado, avaliarFam) {
    var R = rede(estado, avaliarFam), S = sistemas(estado, avaliarFam, R), cod = {}, linhas = [];
    servicosOrc(estado, avaliarFam).forEach(function (l) { cod[l.id] = l; });
    function sit(id) { var l = cod[id]; return l ? { codigo: l.codigo || "", situacao: l.codigo ? "ok" : "pendente", motivo: l.motivo || "", unidade: l.unidade, quantidade: l.quantidade } : { codigo: "", situacao: "—", motivo: "", unidade: "", quantidade: null }; }
    function sisDe(tid) { var c = S.de(tid); return c ? c.codigo + " " + c.nome : ""; }
    R.trechos.forEach(function (t) {
      var M = MATERIAIS[t.material] || {}, s0 = sit(t.id);
      linhas.push({ id: t.id, categoria: categoriaRevit("trecho", t.sistema, t.material), tipo: M.nome, sistema: SISTEMAS[t.sistema].nome, nomeSistema: sisDe(t.id), tamanho: tamanhoTrecho(t),
                    comprimento: t.comprimento, quantidade: s0.quantidade, unidade: s0.unidade, codigo: s0.codigo, situacao: s0.situacao, motivo: s0.motivo });
    });
    R.conexoes.forEach(function (c) {
      var s0 = sit(c.id);
      linhas.push({ id: c.id, categoria: categoriaRevit("conexao", c.sistema, c.material), tipo: c.nome, sistema: SISTEMAS[c.sistema].nome, nomeSistema: sisDe(arr(c.ramos)[0]), tamanho: c.dn + (c.dn2 ? " × " + c.dn2 : ""),
                    comprimento: null, quantidade: 1, unidade: "un", codigo: s0.codigo, situacao: s0.situacao, motivo: s0.motivo });
    });
    arr(R.acessorios).forEach(function (a) {
      var s0 = sit(a.id), V = ACESSORIOS[a.acessorio].variantes[a.variante];
      linhas.push({ id: a.id, categoria: "Acessórios do tubo", tipo: a.nome + " — " + V.rot, sistema: SISTEMAS[a.sistema].nome, nomeSistema: sisDe(a.trecho || a.novoId), tamanho: "DN " + a.dn,
                    comprimento: a.comprimento, quantidade: 1, unidade: "un", codigo: s0.codigo, situacao: s0.situacao, motivo: s0.motivo });
    });
    R.pecas.forEach(function (k) {
      var s0 = sit(k.id), P = PECAS[k.peca];
      linhas.push({ id: k.id, categoria: P.sistemas[0] === "eletrica" ? "Dispositivos elétricos" : "Peças hidrossanitárias", tipo: P.nome + (k.nome ? " " + k.nome : ""), sistema: SISTEMAS[k.sistema].nome, nomeSistema: "", tamanho: k.dn,
                    comprimento: null, quantidade: 1, unidade: "un", codigo: s0.codigo, situacao: s0.situacao, motivo: s0.motivo });
    });
    dispositivosDo(estado, avaliarFam).forEach(function (d) {
      var s0 = sit(d.id), D = DISPOSITIVOS[d.item.peca];
      linhas.push({ id: d.id, categoria: D.categoria, tipo: (d.av && d.av.tipo ? d.av.tipo.nome : D.nome), sistema: "Elétrica", nomeSistema: "", tamanho: d.item.dn,
                    comprimento: null, quantidade: 1, unidade: "un", codigo: s0.codigo, situacao: s0.situacao, motivo: s0.motivo });
    });
    var ORD = ["Tubulação", "Tubulação flexível", "Conexões de tubo", "Acessórios do tubo", "Peças hidrossanitárias", "Conduites", "Conexões do conduite", "Bandejas de cabos", "Conexões da bandeja de cabos", "Dispositivos elétricos", "Luminárias", "Equipamento elétrico", "Dutos", "Dutos flexíveis", "Conexões de duto"];
    linhas.sort(function (a, b) { return (ORD.indexOf(a.categoria) - ORD.indexOf(b.categoria)) || (a.nomeSistema < b.nomeSistema ? -1 : (a.nomeSistema > b.nomeSistema ? 1 : 0)); });
    return { linhas: linhas, sistemas: S.lista, colunas: ["Categoria", "Tipo", "Sistema", "Nome do sistema", "Tamanho", "Comprimento (m)", "Quantidade", "Unidade", "Código SINAPI", "Situação"] };
  }

  /* ================================================ PEÇAS PARA O REGISTRO (js/bimparam.js)
   * Trechos, conexões e acessórios como peças do registro de parâmetros, já com
   * os valores de categoria usuais (Tubulação, Conexões de
   * tubo, Acessórios do tubo, Conduites, Conexões do conduite, Bandejas de
   * cabos, Conexões da bandeja de cabos). Duto de ar e ralo/caixa ficam na tela
   * da B5 (não estão na P12). */
  var CAT_REGISTRO = { agua: "tubo", esgoto: "tubo", ventilacao: "tubo", pluvial: "tubo", eletrica: "eletroduto", bandeja: "bandeja" };
  var CAT_REGISTRO_CX = { tubo: "conexao_tubo", eletroduto: "conexao_eletroduto", bandeja: "conexao_bandeja" };
  function pecasRegistro(estado, avaliarFam) {
    var inst = estado && estado.instalacoes; if (!inst || !(arr(inst.trechos).length || arr(inst.acessorios).length)) return [];
    var R = rede(estado, avaliarFam), S = sistemas(estado, avaliarFam, R), cod = {}, out = [];
    servicosOrc(estado, avaliarFam).forEach(function (l) { cod[l.id] = l; });
    function base(id, sistema, tid) {
      var Sx = SISTEMAS[sistema] || {}, c = S.de(tid), l = cod[id] || {};
      return { id: id, sistemaNome: Sx.nome || "", sistemaAbrev: Sx.abrev || "", nomeSistema: c ? c.nome : "", codigoSistema: c ? c.codigo : "",
               trechoSistema: c ? tid : null, codigo: l.codigo || "", situacao: l.codigo ? "ok" : "pendente", motivo: l.motivo || "", rotuloSinapi: l.rotulo || "" };
    }
    R.trechos.forEach(function (t) {
      var cat = CAT_REGISTRO[grupoDe(t.sistema)]; if (!cat) return;
      var M = MATERIAIS[t.material] || {}, e = base(t.id, t.sistema, t.id), apl = (APLICACOES[grupoDe(t.sistema)] || {})[t.aplicacao];
      e._mep = { tipoId: "mep:" + t.material + (M.secao === "retangular" ? "" : ":" + t.dn), tipoNome: M.nome + " " + tamanhoTrecho(t), familia: cat === "tubo" ? "Tipos de tubos" : (cat === "eletroduto" ? "Eletroduto" : "Eletrocalha") };
      e.comprimento = t.comprimento; e.comprimentoH = t.comprimentoH; e.desnivel = t.desnivel; e.inclinacao = t.inclinacao;
      e.elevIni = t.p1.y; e.elevFim = t.p2.y; e.dn = M.secao === "retangular" ? null : t.dn; e.tamanho = tamanhoTrecho(t);
      e.largura = M.secao === "retangular" ? t.larg : null; e.altura = M.secao === "retangular" ? t.alt : null;
      e.material = M.nome || t.material; e.segmento = (M.nome || t.material) + (M.norma ? " — " + M.norma : ""); e.aplicacao = apl || t.aplicacao || "";
      e.avisos = t.avisos.slice();
      out.push({ id: String(t.id), categoria: cat, el: e });
    });
    R.conexoes.forEach(function (c) {
      var catT = CAT_REGISTRO[grupoDe(c.sistema)]; if (!catT) return;
      var e = base(c.id, c.sistema, arr(c.ramos)[0]);
      e._mep = { tipoId: "mep:" + c.tipo + ":" + c.material, tipoNome: c.nome, familia: c.nome };
      e.dn = c.dn; e.tamanho = c.dn + (c.dn2 ? " × " + c.dn2 : ""); e.angulo = /^(joelho|curva)90/.test(c.tipo) ? 90 : (/^(joelho|curva)45/.test(c.tipo) ? 45 : null);
      e.tipoConexao = c.nome; e.ramos = arr(c.ramos).join(", "); e.elevIni = c.y; e.avisos = [];
      out.push({ id: String(c.id), categoria: CAT_REGISTRO_CX[catT], el: e });
    });
    arr(R.acessorios).forEach(function (a) {
      var e = base(a.id, a.sistema, a.trecho != null ? a.trecho : a.novoId), V = ACESSORIOS[a.acessorio].variantes[a.variante];
      e._mep = { tipoId: a.famId + "|" + a.variante, tipoNome: V.rot, familia: a.nome };
      e.dn = a.dn; e.tamanho = "DN " + a.dn; e.faceAFace = a.comprimento; e.variante = V.rot; e.elevIni = a.centro.y; e.avisos = a.avisos.slice();
      e.trechos = [a.trecho, a.novoId].filter(function (x) { return x != null; }).join(" | ");
      out.push({ id: String(a.id), categoria: "acessorio_tubo", el: e });
    });
    return out;
  }

  var BimInst = {
    VERSAO: 1,
    SISTEMAS: SISTEMAS, MATERIAIS: MATERIAIS, APLICACOES: APLICACOES, PECAS: PECAS, ALTURAS_CAIXA: ALTURAS_CAIXA,
    COR_CAIXA_ELETRICA: COR_CAIXA_ELETRICA, NOMES_CONEXAO: NOMES_CONEXAO, TOL: TOL, TOL_CONECTOR: TOL_CONECTOR,
    inclinacaoMinima: inclinacaoMinima, abaixoDaMinima: abaixoDaMinima, CASAS_INCLINACAO: CASAS_INCLINACAO, geometria: geometria, tracar: tracar, aplicacaoAuto: aplicacaoAuto, alturaCaixa: alturaCaixa,
    normTrecho: normTrecho, normPeca: normPeca, JUNTAS: JUNTAS, juntasDaPonta: juntasDaPonta, novoEstado: novoEstado, aplicarOp: aplicarOp, fechar: fechar, opValida: opValida,
    conectoresDe: conectoresDe, conectoresDoEstado: conectoresDoEstado, volumesFamilias: volumesFamilias, cortaVolume: cortaVolume, trocarDn: trocarDn, declMinDn: declMinDn, opDoTrecho: opDoTrecho, moverCota: moverCota, dividirTrecho: dividirTrecho, tuboEmVolume: tuboEmVolume, FACE_TOL: FACE_TOL, rede: rede, decidir: decidir, desvio: desvio, conferirPortas: conferirPortas, conexaoNoCatalogo: conexaoNoCatalogo,
    chaveSinapi: chaveSinapi, chaveMat: chaveMat, moAnalogaDe: moAnalogaDe, sinapiDe: sinapiDe, idMercadoCurvaDe: idMercadoCurva, rotuloItem: rotuloItem, nomeConexao: nomeConexao,
    quantidadeTrecho: quantidadeTrecho, qto: qto, servicosOrc: servicosOrc, planta: planta,
    /* P12 */
    ACESSORIOS: ACESSORIOS, ACESSORIO_DA_FAM: ACESSORIO_DA_FAM, DISPOSITIVOS: DISPOSITIVOS, BITOLA_REF: BITOLA_REF, TIPOS_VERIF: TIPOS_VERIF,
    ACESSORIO_MIN: ACESSORIO_MIN, ACESSORIO_MAX: ACESSORIO_MAX, ACESSORIO_PADRAO: ACESSORIO_PADRAO,
    normAcessorio: normAcessorio, itemAcessorio: itemAcessorio, itemDispositivo: itemDispositivo, familiaMep: familiaMep, dispositivosDo: dispositivosDo,
    /* pendências finais (18/10/2026): peça em linha (união / tê de inspeção), o tipo do registro pelo lugar, referência de mercado */
    PASSANTE_LAJE: PASSANTE_LAJE, passanteDe: passanteDe,
    PECAS_LINHA: PECAS_LINHA, pecaLinhaExiste: pecaLinhaExiste, embutidoNaParede: embutidoNaParede, varianteAuto: varianteAuto, refMercado: refMercado, itemPeca: itemPeca, itemConexao: itemConexao,
    pecasRegistro: pecasRegistro, CAT_REGISTRO: CAT_REGISTRO,
    sistemas: sistemas, verificar: verificar, conectividade: conectividade, esperaPermitida: esperaPermitida, paralelos: paralelos, legenda: legenda, tabelaPecas: tabelaPecas, categoriaRevit: categoriaRevit, simboloAcessorio: simboloAcessorio,
    /* ops que este motor recebe do BimEdit */
    ehOp: function (op) { return op === "trecho" || op === "peca" || op === "instAlterar" || op === "acessorio" || op === "instSistema" || op === "ligEletrica"; }
  };
  global.BimInst = BimInst;
  if (typeof module !== "undefined" && module.exports) module.exports = BimInst;
})(typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this));
