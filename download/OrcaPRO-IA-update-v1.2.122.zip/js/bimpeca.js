/* =====================================================================
 * bimpeca.js — DO ELEMENTO DO MODELO PARA A PEÇA QUE SE COMPRA.
 *
 * O QUE ESTE ARQUIVO RESOLVE
 * O IFC exportado do Revit já traz, em cada peça, o nome da FAMÍLIA que o
 * projetista usou: "ESG_Serie Normal_Joelho 45_90:Standard",
 * "UT_Bacia com caixa acoplada", "VLV_Registro de gaveta:3/4"".
 * O banco de insumos fala outra língua: "JOELHO 45 GRAUS, PVC, SOLDÁVEL,
 * DN 20 MM", "BACIA SANITARIA (VASO) COM CAIXA ACOPLADA...". Este módulo é a
 * tradução entre os dois — e, principalmente, é onde ele se RECUSA a traduzir
 * quando não tem certeza.
 *
 * ⚠ POR QUE ELE É PURO (sem DOM, sem Store, sem web-ifc)
 * O `js/bim.js` é módulo ES que o Node não consegue exigir, então nada dentro
 * dele entra no gate. Um casador que decide o que o cliente vai COMPRAR não
 * pode ser código sem teste. Aqui a lista de candidatos chega por parâmetro e
 * o arquivo roda em Node — é o mesmo padrão de `js/bimtubo.js`.
 *
 * ⚠ A ARMADILHA CENTRAL, MEDIDA E NÃO SUPOSTA
 * Casar por sobreposição de palavras ACHA A FAMÍLIA E ERRA A PEÇA. Medido na
 * base MG contra o nome real do Revit:
 *
 *     "Tubo PVC Soldavel Agua Fria DN 25"
 *        → TUBO PVC SOLDAVEL DE 20 MM   R$  4,16   \
 *        → TUBO PVC SOLDAVEL DE 25 MM   R$  4,69    |  MESMO score.
 *        → TUBO PVC SOLDAVEL DE 32 MM   R$ 10,12    |  4,2x de preço
 *        → TUBO PVC SOLDAVEL DE 50 MM   R$ 17,43   /   entre eles.
 *
 * O token que decide — "25" — é justamente o que os casadores desta casa
 * descartam por ter menos de 3 letras. Então aqui a BITOLA NÃO É PONTO: é
 * VETO. Divergiu, o candidato cai e o veredito nunca é "ok".
 * É a lição de [[analogas-acerta-o-alvo-errado]]: a doutrina de nunca inventar
 * código protege contra invenção, e NÃO protege contra acertar o alvo errado.
 *
 * ⚠ O QUE ESTE MÓDULO NUNCA FAZ
 *   · não escolhe sozinho quando há empate — devolve a lista e o motivo;
 *   · não inventa código, preço nem unidade;
 *   · não transforma peça sem família em item "ok" (o `e.nome` do app é um
 *     rótulo genérico — "Louça/terminal" — igual para dezenas de peças
 *     diferentes; casar por ele é casar por nada).
 * ===================================================================== */
(function (global) {
  "use strict";

  /* ---------------------------------------------------------------
   * 1. LIMPEZA DO NOME DA FAMÍLIA
   * ------------------------------------------------------------- */

  /* Prefixos de disciplina que o projetista usa como convenção de nome.
     Não são vocabulário — são etiqueta de pasta. Entram na DISCIPLINA e saem
     dos termos, senão "AF" e "ESG" viram palavra buscada na base. */
  var PREFIXO_DISC = {
    ESG: 'esgoto', AF: 'agua-fria', AQ: 'agua-quente', PLUV: 'pluvial',
    AN: 'esgoto', UT: 'louca-metal', USO: 'louca-metal', RES: 'reservatorio',
    VLV: 'registro', INC: 'incendio', GAS: 'gas', DRE: 'drenagem', HID: 'hidraulica'
  };

  /* Palavras que o Revit acrescenta e não descrevem a peça. "Standard" é o
     nome do tipo quando o projetista não deu nome; "Var." idem. */
  var RUIDO = {
    standard: 1, 'var': 1, padrao: 1, default: 1, tipo: 1, tipos: 1, generico: 1,
    generica: 1, mep: 1, shared: 1, num: 1, novo: 1, nova: 1, m: 1, basic: 1,
    wall: 1, floor: 1, roof: 1, family: 1, type: 1, sem: 1, com: 1, de: 1, da: 1,
    do: 1, para: 1, e: 1, ou: 1, no: 1, na: 1, em: 1, a: 1, o: 1, as: 1, os: 1
  };

  function semAcento(s) {
    return String(s == null ? '' : s)
      .replace(/[àáâãäå]/gi, 'a').replace(/[èéêë]/gi, 'e').replace(/[ìíîï]/gi, 'i')
      .replace(/[òóôõö]/gi, 'o').replace(/[ùúûü]/gi, 'u').replace(/[ç]/gi, 'c')
      .replace(/[ñ]/gi, 'n');
  }
  function norm(s) { return semAcento(s).toLowerCase().replace(/\s+/g, ' ').trim(); }

  /* ===================================================================
   * TUBO SE COMPRA EM BARRA, NÃO EM METRO.
   *
   * O modelo publica comprimento; a loja vende barra inteira. Somar
   * 47,30 m e mandar isso para a compra faz a pessoa converter de cabeça —
   * e é aí que entra o erro que ninguém confere. A conta é uma divisão, mas
   * o ARREDONDAMENTO é a parte que decide dinheiro: 47,30 / 6 = 7,88 barras,
   * e não existe comprar 0,88 de barra. Sempre PARA CIMA.
   *
   * ⚠ O metro exato continua ao lado da barra, de propósito. Quem confere o
   *   projeto precisa do número do modelo; quem compra precisa da barra. Um
   *   substituindo o outro deixa metade das duas pessoas sem a referência
   *   que usa — o mesmo motivo pelo qual a tela mostra descrição E família.
   *
   * ⚠ SÓ SEGMENTO, e só medido em metro. Conexão se compra por unidade;
   *   dividir contagem de joelho por 6 é pedido que ninguém consegue atender.
   * =================================================================== */
  var BARRA_M = 6;
  var SEGMENTO = { IFCFLOWSEGMENT: 1, IFCPIPESEGMENT: 1, IFCDUCTSEGMENT: 1 };
  function ehSegmento(tipo) { return !!SEGMENTO[String(tipo || '').toUpperCase()]; }
  /* ⚠ E O ARREDONDAMENTO PARA CIMA TEM DE TOLERAR O RUÍDO DA SOMA, senão ele
     compra barra a mais. `p.quantidade` não é número digitado: é soma de
     floats vindos do IFC, e ela passa POR CIMA do múltiplo. Dez trechos de
     1,80 m somam 18.000000000000004, e o `Math.ceil` cru transforma 18 m em
     QUATRO barras em vez de três — em toda linha cujo total cai exatamente
     num múltiplo de 6.
     Medido, não suposto: uma varredura por somas que ultrapassam o múltiplo
     achou o caso em segundos, com trechos que qualquer projeto tem
     (10 × 1,80 m, 14 × 1,2857 m, 11 × 3,8182 m).
     A folga é de 1e-9 BARRA — seis nanômetros de tubo. Sobra de longe para o
     ruído do double e não alcança excesso nenhum de verdade: 6,01 m continua
     pedindo 2 barras, e 18,001 m continua pedindo 4. */
  var FOLGA_BARRA = 1e-9;
  function barrasDe(metros) {
    var m = Number(metros);
    if (!isFinite(m) || m <= 0) return 0;
    return Math.ceil(m / BARRA_M - FOLGA_BARRA);
  }

  /* "ESG_Serie Normal_Joelho 45_90:Standard" -> { esquerda, direita, prefixo } */
  function partir(familia) {
    var t = String(familia == null ? '' : familia).trim();
    var i = t.indexOf(':');
    var esq = i >= 0 ? t.slice(0, i) : t;
    var dir = i >= 0 ? t.slice(i + 1) : '';
    /* ⚠ quando as duas metades são iguais, o Revit só repetiu o nome da
       família no tipo. Contar duas vezes inflaria o score de qualquer termo. */
    if (norm(dir) === norm(esq)) dir = '';
    var pre = '';
    var m = /^([A-Za-z]{2,5})_/.exec(esq);
    if (m && PREFIXO_DISC[m[1].toUpperCase()]) pre = m[1].toUpperCase();
    return { esquerda: esq, direita: dir, prefixo: pre };
  }

  /* ---------------------------------------------------------------
   * 2. DIMENSÃO — o veto
   * ------------------------------------------------------------- */

  /* ⚠ ORDEM IMPORTA. "150x150x50" tem de ser lido como um trio ANTES de o
     leitor de milímetros achar três números soltos; e `Ø3/4" (25mm)` traz a
     mesma bitola escrita duas vezes, em unidades diferentes — ler as duas e
     tratá-las como equivalentes é o que faz o veto não reprovar o candidato
     certo. */
  function dimsDe(texto) {
    var t = ' ' + semAcento(String(texto == null ? '' : texto)).toLowerCase()
      .replace(/[Øø]/g, ' ') + ' ';
    var d = { dn: [], pol: [], mm: [], trio: [], graus: [], litros: [] };

    /* ⚠ CADA REGRA CONSOME O QUE LEU. `String.replace` devolve string nova e
       NÃO altera a original — a primeira versão deste bloco descartava o
       retorno, então toda regra lia o texto inteiro de novo. Efeito medido:
       `Ø3/4" (25mm)` saía com polegada [0,75 e 4] (o "4" do denominador,
       relido pela regra de polegada inteira) e `1 1/2"` saía [0,5; 1,5; 2].
       Bitola INVENTADA é pior que bitola faltando: ela VETA o candidato
       certo, e o sintoma seria "não achei" num item que estava lá. */
    function comer(re, fn) { t = t.replace(re, function () { fn.apply(null, arguments); return ' '; }); }

    /* ⚠ "DN 100 X 50 MM" É UMA REDUÇÃO, e as bitolas dela são 100 e 50 —
       não um trio de medidas de caixa. Sem esta separação, o
       `JOELHO PVC COM VISITA, 90 GRAUS, DN 100 X 50 MM` aparecia em 1º lugar,
       com 100% e sem divergência declarada, numa busca por joelho DN 50: a
       regra do trio comia os dois números antes de a regra de bitola vê-los,
       o veto não tinha o que comparar e a peça errada subia com cara de
       conferida. Reduções são justamente as peças em que errar custa mais. */
    /* ⚠ "50 X 50" NÃO É REDUÇÃO — é a MESMA bitola escrita duas vezes, e foi
       assim que o casador perdeu a peça certa. A SINAPI escreve o tê reto como
       `TE SANITARIO, PVC, DN 50 X 50 MM, SERIE NORMAL`: dois números porque o
       tê tem duas saídas, as duas de 50 mm. Marcando isso como redução, a
       guarda "peça reta não é redução" (compararDims, logo abaixo) reprovava
       justamente o item CERTO.
       Medido no projeto hidrossanitário real, no tê 50×50 do print: o
       `7097 TE SANITARIO, PVC, DN 50 X 50 MM` empatava em pontos com CAP e
       LUVA (9 de 13,6) e caía de 66% para 6% — sumia da lista. O usuário via
       seis candidatos e nenhum deles era um tê; o melhor colocado era um CAP.
       Redução é quando as bitolas DIFEREM. */
    function marcarReducao(vals) {
      var vistos = {}, n = 0;
      for (var i = 0; i < vals.length; i++) { if (!vistos[vals[i]]) { vistos[vals[i]] = 1; n++; } }
      if (n > 1) d.reducaoTexto = true;
    }
    comer(/\bdn\s*(\d+)\s*x\s*(\d+)(?:\s*x\s*(\d+))?\s*mm\b/g, function (m, a, b, c) {
      var vs = [a, b, c].filter(Boolean).map(function (x) { return parseInt(x, 10); });
      vs.forEach(function (x) { d.dn.push(x); });
      marcarReducao(vs);
    });
    /* e "100 X 50 MM" sem o DN na frente é o mesmo caso */
    comer(/(\d+)\s*x\s*(\d+)(?:\s*x\s*(\d+))?\s*mm\b/g, function (m, a, b, c) {
      var vs2 = [a, b, c].filter(Boolean).map(function (x) { return parseInt(x, 10); });
      vs2.forEach(function (x) { d.mm.push(x); });
      marcarReducao(vs2);
    });

    /* trio 150x150x50 / 90x90 / 0.80 x 2.10 — ANTES dos leitores de número
       solto, senão 150x150x50 viraria três milimetragens */
    comer(/(\d+(?:[.,]\d+)?)\s*x\s*(\d+(?:[.,]\d+)?)(?:\s*x\s*(\d+(?:[.,]\d+)?))?/g, function (m, a, b, c) {
      var v = [a, b, c].filter(Boolean).map(function (x) { return parseFloat(String(x).replace(',', '.')); });
      d.trio.push(v.join('x'));
    });

    /* polegada, da forma mais específica para a mais geral */
    comer(/(\d+)\s+(\d+)\s*\/\s*(\d+)\s*"/g, function (m, i, nn, dd) { d.pol.push(parseInt(i, 10) + parseInt(nn, 10) / parseInt(dd, 10)); });
    comer(/(\d+)\s*\/\s*(\d+)\s*"/g, function (m, nn, dd) { d.pol.push(parseInt(nn, 10) / parseInt(dd, 10)); });
    comer(/(\d+)\s*"/g, function (m, nn) { d.pol.push(parseInt(nn, 10)); });

    comer(/\bdn\s*(\d+)/g, function (m, nn) { d.dn.push(parseInt(nn, 10)); });
    comer(/(\d+(?:[.,]\d+)?)\s*mm\b/g, function (m, nn) { d.mm.push(Math.round(parseFloat(String(nn).replace(',', '.')))); });
    /* ⚠ "90º" NÃO É "90°", e a diferença custou o casamento de TODOS os
       joelhos. O Revit escreve o ângulo com o indicador ordinal masculino
       (U+00BA, "90º"); esta regra só conhecia o SÍMBOLO DE GRAU (U+00B0,
       "90°") e a palavra "GRAUS", que é a forma da SINAPI. Os dois desenham
       igual na tela e são caracteres diferentes.
       Efeito medido no print de 09/09/2026: a peça "Joelho 90º 100mm" saía
       com `graus: []`, o candidato "JOELHO ... 90 GRAUS" com `[90]` e o
       "45 GRAUS" com `[45]` — e `compararDims` PULA a grandeza que só um lado
       declara. Sem nada para comparar, 45 e 90 empatavam em 59% e a peça ia
       para "pendente". A família não salva: ela se chama `Joelho 45_90`, que
       é o nome do grupo, e de propósito não vira medida nenhuma. */
    comer(/(\d+)\s*(?:graus|grau|[°º])/g, function (m, nn) { d.graus.push(parseInt(nn, 10)); });
    comer(/(\d+(?:[.,]\d+)?)\s*(?:l|litros?)\b/g, function (m, nn) { d.litros.push(Math.round(parseFloat(String(nn).replace(',', '.')))); });

    /* DN e mm são a mesma grandeza no vocabulário de tubo: unificar evita que
       "DN 100" e "100 MM" sejam lidos como bitolas diferentes e vetem um ao
       outro. Polegada fica separada porque a conversão é aproximada e virar
       número quebrado aqui produziria falso "diverge". */
    var bit = {};
    d.dn.concat(d.mm).forEach(function (v) { if (v > 0) bit[v] = 1; });
    d.bitola = Object.keys(bit).map(Number).sort(function (a, b) { return a - b; });
    d.pol = d.pol.filter(function (v) { return v > 0 && v <= 24; })
      .sort(function (a, b) { return a - b; });
    d.trio = d.trio.filter(function (v, i, arr) { return arr.indexOf(v) === i; });
    d.graus = d.graus.filter(function (v, i, arr) { return arr.indexOf(v) === i; }).sort();
    d.litros = d.litros.filter(function (v, i, arr) { return arr.indexOf(v) === i; }).sort();
    d.vazio = !d.bitola.length && !d.pol.length && !d.trio.length && !d.graus.length && !d.litros.length;
    return d;
  }

  /* Compara a dimensão do modelo com a do insumo.
     'confere'  — falam da mesma medida
     'diverge'  — falam de medidas diferentes  -> VETO
     'muda'     — um dos dois não declara medida -> não veta, mas não confirma */
  function compararDims(a, b) {
    if (!a || !b || a.vazio || b.vazio) return 'muda';
    /* ⚠ PEÇA RETA NÃO É REDUÇÃO, mesmo compartilhando uma das bitolas.
       `JOELHO ... DN 100 X 50 MM` tem 50 entre as suas medidas e, sem esta
       regra, "confere" com um joelho reto DN 50 — e é outra peça, outro
       preço, outra função. O contrário também vale: pedir uma redução e
       receber uma peça reta. */
    var aRed = !!a.reducaoTexto || (a.bitola || []).length > 1;
    var bRed = !!b.reducaoTexto || (b.bitola || []).length > 1;
    if (aRed !== bRed) return 'diverge';
    /* ⚠ CADA GRANDEZA DECIDE SOZINHA. A primeira versão acumulava
       `houveIgual` GLOBALMENTE sobre as cinco grandezas: bastava UMA concordar
       para o veredito ser "confere", mesmo com a bitola declarada nos dois
       lados e DIVERGENTE.
       Reproduzido com a família real do modelo: `ESG_Serie Normal_Curva 90°
       Curta` com bitola 50 (medida na geometria) contra
       `CURVA 90 GRAUS, PVC, SERIE NORMAL, ESGOTO, DN 100 MM` devolvia
       "confere" → status "ok" → o painel PRÉ-MARCAVA a curva DN 100
       (R$ 29,35) numa rede DN 50 (R$ 9,68). O grau 90 casou e mascarou
       50 × 100. Trinta e sete peças, três vezes o preço — exatamente o
       defeito que o cabeçalho deste arquivo diz existir para não cometer.
       Agora: uma grandeza que os DOIS lados declaram e que diverge REPROVA,
       não importa quantas outras concordem. */
    var grandezas = ['bitola', 'pol', 'trio', 'graus', 'litros'];
    var houveComum = false, todasIguais = true;
    for (var i = 0; i < grandezas.length; i++) {
      var g = grandezas[i], A = a[g] || [], B = b[g] || [];
      if (!A.length || !B.length) continue;
      houveComum = true;
      var igualNesta = false;
      for (var x = 0; x < A.length; x++) {
        for (var y = 0; y < B.length; y++) {
          if (g === 'pol') { if (Math.abs(A[x] - B[y]) < 0.01) igualNesta = true; }
          else if (String(A[x]) === String(B[y])) igualNesta = true;
        }
      }
      if (!igualNesta) todasIguais = false;
    }
    if (!houveComum) return 'muda';
    return todasIguais ? 'confere' : 'diverge';
  }

  /* ---------------------------------------------------------------
   * 2b. UNIDADE — o outro veto, e o que faltava
   *
   * ⚠ O ANEL DE BORRACHA NO LUGAR DO TUBO.
   * Medido no modelo real contra a base real: das 23 linhas que o painel
   * pré-marcava, CINCO apontavam para a junta em vez da peça —
   * `Tipos de tubos:PLUV_Tubo Serie Reforcada` (80 peças, 80 m) ficava com
   * `ANEL BORRACHA, DN 100 MM, PARA TUBO SERIE REFORCADA` [UN, R$ 3,52],
   * enquanto o tubo certo (`TUBO PVC SERIE R DN 100 MM` [M, R$ 31,52]) caía
   * para terceiro. O anel ganha porque a descrição dele CONTÉM o nome do tubo.
   * A bitola confere nos dois — o veto de medida não tem como pegar.
   *
   * O que separa os dois é a UNIDADE: o modelo mediu METRO, o anel se vende
   * por UNIDADE. Pedir 80 m de anel de borracha é um pedido que ninguém
   * consegue atender, e o preço sai 9x errado para baixo.
   * ------------------------------------------------------------- */
  var GRANDEZA_UN = {
    m: 'comprimento', ml: 'comprimento', cm: 'comprimento', mm: 'comprimento',
    m2: 'area', 'm²': 'area', m3: 'volume', 'm³': 'volume',
    un: 'contagem', und: 'contagem', 'un.': 'contagem', pc: 'contagem', pç: 'contagem',
    cj: 'contagem', par: 'contagem', kg: 'massa', t: 'massa', l: 'volume', h: 'tempo'
  };
  function grandezaDaUnidade(u) {
    var k = norm(u).replace(/[.\s]/g, '');
    return GRANDEZA_UN[k] || GRANDEZA_UN[k.replace('2', '²').replace('3', '³')] || '';
  }
  /* 'confere' | 'diverge' | 'muda' (um dos lados não declara) */
  /* tubo/duto se compra por METRO; conexao, louca e registro por UNIDADE.
     E do produto, nao do arquivo — vale mesmo quando o IFC nao mediu. */
  function ehSegmento(tipo) {
    return /^IFC(PIPESEGMENT|DUCTSEGMENT|FLOWSEGMENT|CABLESEGMENT|CABLECARRIERSEGMENT)/.test(String(tipo || '').toUpperCase());
  }
  function compararUnidade(uPeca, uItem) {
    var a = grandezaDaUnidade(uPeca), b = grandezaDaUnidade(uItem);
    if (!a || !b) return 'muda';
    return a === b ? 'confere' : 'diverge';
  }

  /* ---------------------------------------------------------------
   * 2b. O SUBSTANTIVO DA PEÇA — o que ela É. E ele é VETO.
   *
   * ⚠ A LIÇÃO QUE FALTAVA. Este arquivo já dizia que a bitola não é ponto, é
   *   veto. Faltava dizer o mesmo do NOME DA PEÇA, e o buraco era grande:
   *   medido no projeto real, um "Tê 50 × 50" de esgoto trazia os termos
   *   `serie, normal, juncao, esgoto, tigre` — todos genéricos — e os seis
   *   melhores candidatos eram CAP, LUVA, TERMINAL DE VENTILAÇÃO, TUBO e
   *   ANEL. Nenhum era um tê. Pior: com a bitola conferindo, uma
   *   `LUVA SIMPLES DN 100` chegou a ser PRÉ-MARCADA para uma "Junção Simples
   *   100 × 100", com o veredito "nome e medida conferem".
   *
   * ⚠ POR QUE O SCORE SOZINHO NUNCA IA RESOLVER. "tê" tem duas letras e o
   *   filtro de termos descarta o que tem menos de três — a palavra que
   *   DECIDE era justamente a que não entrava. E acrescentá-la aos termos
   *   seria pior: o pré-filtro casa por substring, e "te" está dentro de
   *   "TErminal" e "TE de inspeção". Por isso o tipo viaja como sinal
   *   ESTRUTURADO, comparado por palavra inteira, e não como mais um token.
   *
   * ⚠ O SUBSTANTIVO É O DA ESQUERDA. A SINAPI começa a descrição pela peça:
   *   "TE SANITARIO DE REDUCAO" é um TÊ, "JUNCAO SIMPLES DE REDUCAO" é uma
   *   JUNÇÃO, "BUCHA DE REDUCAO" é uma BUCHA — as três contêm "redução", e
   *   quem manda é quem aparece primeiro. Por isso vence a POSIÇÃO no texto,
   *   não a ordem desta lista.
   *
   * ⚠ E TÊ NÃO É JUNÇÃO. São peças diferentes (o tê sanitário deriva a 90°, a
   *   junção simples a 45°), preços diferentes, e a família do Revit costuma
   *   chamar as duas de `Te_Juncao`. Juntá-las aqui para "facilitar" traria
   *   de volta exatamente o erro que este bloco existe para impedir.
   * ------------------------------------------------------------- */
  var TIPO_PECA = [
    ['te',        /\bte\b|\btes\b/],
    ['juncao',    /\bjuncao\b|\bjuncoes\b/],
    ['joelho',    /\bjoelho\b|\bcotovelo\b/],
    ['curva',     /\bcurva\b/],
    ['luva',      /\bluva\b/],
    ['cap',       /\bcap\b|\btampao\b|\bplugue?\b/],
    ['bucha',     /\bbucha\b/],
    ['reducao',   /\breducao\b/],
    ['adaptador', /\badaptador\b/],
    ['tubo',      /\btubo\b|\beletroduto\b/],
    ['terminal',  /\bterminal\b/],
    ['anel',      /\banel\b/],
    ['sifao',     /\bsifao\b/],
    ['ralo',      /\bralo\b/],
    ['caixa',     /\bcaixa\b/],
    ['registro',  /\bregistro\b/],
    ['valvula',   /\bvalvula\b/],
    ['torneira',  /\btorneira\b/],
    ['bacia',     /\bbacia\b|\bvaso sanitario\b/],
    ['lavatorio', /\blavatorio\b/],
    ['pia',       /\bpia\b/],
    ['tanque',    /\btanque\b/],
    ['chuveiro',  /\bchuveiro\b/],
    ['cruzeta',   /\bcruzeta\b/],
    ['nipple',    /\bnipple\b|\bniple\b/],
    ['flange',    /\bflange\b/],
    ['uniao',     /\buniao\b/],
    ['calha',     /\bcalha\b/]
  ];
  /* devolve o substantivo mais à ESQUERDA, ou '' quando o texto não nomeia
     nenhuma peça conhecida — e '' NUNCA veta: silêncio não é divergência */
  function tipoPecaDe(texto) {
    var t = ' ' + norm(texto).replace(/[_\-.,;:/()\[\]"]/g, ' ') + ' ';
    var achado = '', pos = Infinity, n = 0, vistos = {};
    for (var i = 0; i < TIPO_PECA.length; i++) {
      var m = TIPO_PECA[i][1].exec(t);
      if (!m) continue;
      if (!vistos[TIPO_PECA[i][0]]) { vistos[TIPO_PECA[i][0]] = 1; n++; }
      if (m.index < pos) { pos = m.index; achado = TIPO_PECA[i][0]; }
    }
    return { tipo: achado, quantos: n };
  }
  /* ⚠ DUAS LEITURAS DO MESMO DICIONÁRIO, e a diferença não é preciosismo.
     · Na DESCRIÇÃO (nome de mercado, dos dois lados) vence o mais à esquerda:
       a SINAPI escreve a peça primeiro e o resto é qualificação —
       "TE SANITARIO DE REDUCAO" é um tê, não uma redução.
     · Na FAMÍLIA do Revit, não. Ela é ETIQUETA DE PASTA e frequentemente
       nomeia DUAS peças de uma vez: a família real do projeto se chama
       `ESG_Serie Normal_Te_Juncao` e cobre tê E junção. Ler a da esquerda ali
       carimbaria "tê" numa junção e o veto passaria a reprovar o item CERTO —
       trocando um casamento ruim por um errado, que é pior. Então da família
       só se aceita o tipo quando ela nomeia UMA peça só. */
  function tipoDaDescricao(texto) { return tipoPecaDe(texto).tipo; }
  function tipoDaFamilia(texto) {
    var r = tipoPecaDe(texto);
    return r.quantos === 1 ? r.tipo : '';
  }
  function compararTipoPeca(a, b) {
    if (!a || !b) return 'muda';
    return a === b ? 'confere' : 'diverge';
  }

  /* ---------------------------------------------------------------
   * 2c. A SÉRIE — e ela também é VETO.
   *
   * ⚠ A PALAVRA "SERIE" ESTAVA FAZENDO O CONTRÁRIO DO QUE DEVIA. A peça diz
   *   "Esgoto Série Normal"; a base de MG tem só dois joelhos 90° DN 100 de
   *   esgoto:
   *       3520  JOELHO PVC, SOLDAVEL, PB, 90 GRAUS, DN 100 MM   R$  9,33
   *      20157  JOELHO, PVC SERIE R, 90 GRAUS, DN 100 MM        R$ 21,80
   *   O certo é o primeiro — a série normal, que a SINAPI escreve como
   *   "SOLDAVEL, PB" e não com a palavra "normal". O casador punha o SÉRIE R
   *   na frente (59% contra 39%) porque ele compartilha o token "serie" com a
   *   peça. Ou seja: a palavra que deveria SEPARAR as duas séries era o ponto
   *   que as APROXIMAVA, e a escolha saía 2,3× mais cara.
   *
   * ⚠ SÉRIE R É SÉRIE REFORÇADA — o mesmo produto com dois nomes. Tratá-las
   *   como séries diferentes deixaria a peça pendente sem motivo.
   *
   * ⚠ E QUEM NÃO DECLARA NÃO DIVERGE: "SOLDAVEL, PB" não nomeia série, então
   *   vale 'muda' e continua na disputa. É o que faz o item certo sobreviver
   *   justamente no caso que motivou este bloco.
   * ------------------------------------------------------------- */
  function serieDe(texto) {
    var t = ' ' + norm(texto).replace(/[_\-.,;:/()\[\]"]/g, ' ') + ' ';
    if (/\bserie\s+refor/.test(t) || /\bserie\s+r\b/.test(t)) return 'reforcada';
    if (/\bserie\s+normal\b/.test(t)) return 'normal';
    return '';
  }
  function compararSerie(a, b) {
    if (!a || !b) return 'muda';
    return a === b ? 'confere' : 'diverge';
  }
  function rotuloSerie(s) { return s === 'reforcada' ? 'série reforçada (R)' : s === 'normal' ? 'série normal' : '?'; }
  /* como o tipo aparece no recado ao usuário — o recado tem de dizer QUAL é a
     peça de cada lado, senão vira "não confere" genérico, que a pessoa lê como
     formalidade e ignora */
  var ROTULO_TIPO = {
    te: 'um tê', juncao: 'uma junção', joelho: 'um joelho', curva: 'uma curva',
    luva: 'uma luva', cap: 'um cap', bucha: 'uma bucha', reducao: 'uma redução',
    adaptador: 'um adaptador', tubo: 'um tubo', terminal: 'um terminal',
    anel: 'um anel', sifao: 'um sifão', ralo: 'um ralo', caixa: 'uma caixa',
    registro: 'um registro', valvula: 'uma válvula', torneira: 'uma torneira',
    bacia: 'uma bacia', lavatorio: 'um lavatório', pia: 'uma pia',
    tanque: 'um tanque', chuveiro: 'um chuveiro', cruzeta: 'uma cruzeta',
    nipple: 'um nipple', flange: 'um flange', uniao: 'uma união', calha: 'uma calha'
  };
  function rotuloTipo(t) { return ROTULO_TIPO[t] || ('"' + (t || '?') + '"'); }

  /* ---------------------------------------------------------------
   * 2b-bis. GRUPO DE COMPRA — tubo, conexão, louça, registro.
   *
   * ⚠ É O RECORTE DE QUEM COMPRA, não o de quem modela. O `tipoPeca` separa
   *   tê de junção porque isso decide o ITEM; para achar a linha numa lista de
   *   182, o que serve é o balcão: tubo se compra por barra, conexão por
   *   unidade, louça por peça, registro por bitola. Pedido de 09/09/2026:
   *   "separa os itens por filtros de tubos, conexões etc".
   *
   * ⚠ E ELE TEM DUAS FONTES, nesta ordem: o substantivo (que vem da descrição,
   *   e é o que a pessoa lê) e, sem ele, a CLASSE IFC — que existe mesmo em
   *   modelo sem descrição nenhuma. Sem a segunda, o filtro nasceria vazio
   *   justamente nos modelos que mais precisam dele.
   * ------------------------------------------------------------- */
  var GRUPO_DO_TIPO = {
    tubo: 'tubos',
    te: 'conexoes', juncao: 'conexoes', joelho: 'conexoes', curva: 'conexoes',
    luva: 'conexoes', cap: 'conexoes', bucha: 'conexoes', reducao: 'conexoes',
    adaptador: 'conexoes', cruzeta: 'conexoes', nipple: 'conexoes',
    flange: 'conexoes', uniao: 'conexoes', anel: 'conexoes',
    registro: 'registros', valvula: 'registros',
    bacia: 'loucas', lavatorio: 'loucas', pia: 'loucas', tanque: 'loucas',
    chuveiro: 'loucas', torneira: 'loucas', sifao: 'loucas',
    ralo: 'caixas', caixa: 'caixas', terminal: 'caixas', calha: 'calhas'
  };
  var GRUPO_DA_CLASSE = {
    IFCFLOWSEGMENT: 'tubos', IFCPIPESEGMENT: 'tubos', IFCDUCTSEGMENT: 'tubos',
    IFCCABLECARRIERSEGMENT: 'tubos',
    IFCFLOWFITTING: 'conexoes', IFCPIPEFITTING: 'conexoes', IFCDUCTFITTING: 'conexoes',
    IFCFLOWCONTROLLER: 'registros', IFCVALVE: 'registros',
    IFCFLOWTERMINAL: 'loucas', IFCSANITARYTERMINAL: 'loucas',
    IFCWALL: 'alvenaria', IFCWALLSTANDARDCASE: 'alvenaria', IFCSLAB: 'alvenaria',
    IFCBEAM: 'estrutura', IFCCOLUMN: 'estrutura', IFCFOOTING: 'estrutura'
  };
  var ROTULO_GRUPO = {
    tubos: 'Tubos', conexoes: 'Conexões', registros: 'Registros e válvulas',
    loucas: 'Louças e metais', caixas: 'Caixas e ralos', calhas: 'Calhas',
    alvenaria: 'Alvenaria e lajes', estrutura: 'Estrutura', outros: 'Outros'
  };
  function grupoDeCompra(peca) {
    if (!peca) return 'outros';
    var g = GRUPO_DO_TIPO[peca.tipoPeca];
    if (g) return g;
    return GRUPO_DA_CLASSE[String(peca.tipo || '').toUpperCase()] || 'outros';
  }
  function rotuloGrupo(g) { return ROTULO_GRUPO[g] || 'Outros'; }

  /* ---------------------------------------------------------------
   * 3. TERMOS
   * ------------------------------------------------------------- */
  function termosDe(familia, extra) {
    var p = partir(familia);
    var bruto = (p.esquerda + ' ' + p.direita + ' ' + (extra || ''));
    /* tira o prefixo de disciplina do texto — ele já virou disciplina */
    if (p.prefixo) bruto = bruto.replace(new RegExp('\\b' + p.prefixo + '_', 'gi'), ' ');
    bruto = bruto.replace(/\bAN_/gi, ' ');
    var toks = norm(bruto).replace(/[_\-.,;:/()\[\]"]/g, ' ').split(/\s+/);
    var vistos = {}, out = [];
    for (var i = 0; i < toks.length; i++) {
      var t = toks[i];
      if (!t || t.length < 3) continue;      // "45", "90", "dn" saem daqui: são DIMENSÃO
      /* ⚠ MEDIDA COMPOSTA NAO E PALAVRA. O filtro abaixo so descartava numero
         PURO, entao "150x150x50", "4x2" e "300mm" viravam termo de busca — e
         a base escreve "150 X 150 X 50", com espaco, entao o token nunca casa.
         Medido: 176 de 435 familias das tres fixtures tinham termo com digito.
         A `CAIXA SIFONADA ... DN 150 X 150 X 50 MM` existia na base e a peca
         saia pendente. Medida ja e lida por `dimsDe`; aqui ela so atrapalha. */
      if (/\d/.test(t) && /^[\d.,x]+(mm|cm|m)?$/i.test(t)) continue;
      if (RUIDO[t]) continue;
      if (/^\d+$/.test(t)) continue;         // número puro é medida, não palavra
      if (vistos[t]) continue;
      vistos[t] = 1; out.push(t);
    }
    return out;
  }

  /* ---------------------------------------------------------------
   * 4. DISCIPLINA — três sinais, em ordem de autoridade
   * ------------------------------------------------------------- */
  var POR_CLASSE = {
    IFCPIPESEGMENT: 'hidraulica', IFCPIPEFITTING: 'hidraulica', IFCFLOWSEGMENT: 'hidraulica',
    IFCFLOWFITTING: 'hidraulica', IFCFLOWTERMINAL: 'hidraulica', IFCFLOWCONTROLLER: 'hidraulica',
    IFCSANITARYTERMINAL: 'hidraulica', IFCVALVE: 'hidraulica',
    IFCCABLECARRIERSEGMENT: 'eletrica', IFCCABLESEGMENT: 'eletrica', IFCLIGHTFIXTURE: 'eletrica',
    IFCOUTLET: 'eletrica', IFCSWITCHINGDEVICE: 'eletrica', IFCELECTRICDISTRIBUTIONPOINT: 'eletrica',
    IFCJUNCTIONBOX: 'eletrica', IFCPROTECTIVEDEVICE: 'eletrica',
    IFCWALL: 'arquitetura', IFCWALLSTANDARDCASE: 'arquitetura', IFCSLAB: 'arquitetura',
    IFCDOOR: 'arquitetura', IFCWINDOW: 'arquitetura', IFCCOVERING: 'arquitetura',
    IFCRAILING: 'arquitetura', IFCSTAIR: 'arquitetura', IFCROOF: 'arquitetura',
    IFCPLATE: 'arquitetura', IFCFURNISHINGELEMENT: 'arquitetura',
    IFCBEAM: 'estrutura', IFCCOLUMN: 'estrutura', IFCFOOTING: 'estrutura',
    IFCPILE: 'estrutura', IFCMEMBER: 'estrutura', IFCREINFORCINGBAR: 'estrutura'
  };

  /* ⚠ O SISTEMA É O SINAL MAIS FORTE, e não a heurística sobre o nome.
     Num projeto hidrossanitário real o projetista já escreveu, no IfcSystem,
     "Esgoto - Geral", "Água fria - Distribuição", "Esgoto - Gordura",
     "Esgoto - Ventilação". Isso é classificação de quem desenhou; qualquer
     regra nossa sobre o nome da família é palpite ao lado disso. */
  function subsistemaDe(sistemaIfc) {
    var s = norm(sistemaIfc);
    if (!s) return '';
    if (/agua\s*fria|af\b/.test(s)) return 'agua-fria';
    if (/agua\s*quente/.test(s)) return 'agua-quente';
    if (/gordura/.test(s)) return 'esgoto-gordura';
    if (/ventila/.test(s)) return 'esgoto-ventilacao';
    if (/sabao|secundari/.test(s)) return 'esgoto-secundario';
    if (/esgoto|sanitar/.test(s)) return 'esgoto';
    if (/pluvial|chuva|drenagem/.test(s)) return 'pluvial';
    if (/incendio|hidrante|sprinkler/.test(s)) return 'incendio';
    if (/gas\b/.test(s)) return 'gas';
    if (/eletric|energia|iluminac|tomada/.test(s)) return 'eletrica';
    return '';
  }

  function disciplinaDe(el) {
    var sub = subsistemaDe(el.sistemaIfc);
    if (sub) return { disciplina: sub === 'eletrica' ? 'eletrica' : 'hidraulica', subsistema: sub, origem: 'sistema-do-projeto' };
    var pre = partir(el.familia).prefixo;
    if (pre && PREFIXO_DISC[pre]) {
      var d = PREFIXO_DISC[pre];
      var disc = (d === 'eletrica') ? 'eletrica' : 'hidraulica';
      return { disciplina: disc, subsistema: d, origem: 'prefixo-da-familia' };
    }
    var porCls = POR_CLASSE[String(el.tipo || '').toUpperCase()];
    if (porCls) return { disciplina: porCls, subsistema: '', origem: 'classe-ifc' };
    return { disciplina: '', subsistema: '', origem: 'nao-classificado' };
  }

  /* ---------------------------------------------------------------
   * 5. LEVANTAR — agrupa os elementos em peças compráveis
   * ------------------------------------------------------------- */
  function levantar(elementos, opc) {
    opc = opc || {};
    var porChave = {}, ordem = [];
    var semFamilia = 0, total = 0;

    (elementos || []).forEach(function (e) {
      if (!e) return;
      var n = e.n || 1;
      total += n;
      var fam = String(e.familia || '').trim();
      var temFamilia = !!fam;
      if (!temFamilia) { semFamilia += n; }
      /* ⚠ A DESCRIÇÃO É O NOME DE MERCADO, e a família é o nome da PASTA.
         O projetista batiza a família pela convenção do escritório
         ("AF_Soldavel_Tubo", "ESG_Serie Normal_Luva Simples:Standard") e
         escreve o nome comercial no campo Descrição do tipo, que é de onde a
         biblioteca do fabricante já vem preenchida ("Tubo PVC soldável água
         fria DN 25 mm"). A base de preços fala a segunda língua, não a
         primeira — então quando a descrição existe ela é a melhor evidência
         que este arquivo tem, e até a v1.2.x ela era JOGADA FORA na leitura
         do IFC. Ela ENTRA nos termos; nunca substitui a família, porque a
         família é o que o engenheiro reconhece ao conferir a linha. */
      var descr = String(e.descricao || '').trim();
      var disc = disciplinaDe(e);
      if (opc.disciplina && disc.disciplina !== opc.disciplina) return;
      if (opc.subsistema && disc.subsistema !== opc.subsistema) return;

      /* ⚠ a chave inclui o SISTEMA: o mesmo joelho em água fria e em esgoto
         são compras diferentes (soldável x série normal), e juntá-los
         entregaria uma linha só que não dá para comprar. */
      /* ⚠ a bitola entra na CHAVE junto com o sistema: luva DN 50 e luva
         DN 100 sao compras diferentes, e a mesma conexao em agua fria
         (soldavel) e em esgoto (serie normal) tambem. Juntar qualquer um dos
         dois pares daria uma linha de requisicao que ninguem consegue pedir. */
      var par = (e.bitolaPar && e.bitolaPar.length) ? e.bitolaPar.join('x') : '';
      /* ⚠ A FUSÃO PELA DESCRIÇÃO NÃO ACONTECE AQUI — ela é um SEGUNDO PASSO,
         depois deste laço (procure `fundirPorDescricao`). Tentei primeiro
         trocar esta chave pela descrição e o resultado foi o oposto do
         pedido: num modelo real só PARTE das instâncias traz o campo
         preenchido (é o que o bloco logo abaixo trata), então a chave por
         descrição punha as instâncias com o campo numa linha e as sem o campo
         em outra — dividindo justamente o grupo que era para juntar. Quatro
         asserts do `test-bimpeca` caíram e foi assim que apareceu.
         Agrupar por família primeiro deixa a descrição ser RESOLVIDA para o
         grupo inteiro; só então vale fundir por ela. */
      /* ⚠ O QUE ENTRA NA CHAVE É O SUBSISTEMA, NÃO O NOME DO RAMAL.
         O sistema entrou aqui por um motivo certo: o mesmo joelho em água fria
         e em esgoto são compras diferentes (soldável × série normal). Só que o
         que carrega essa informação é a DISCIPLINA — e o Revit numera os
         ramais, então o texto do sistema vem "Esgoto - Ramal 1", "Esgoto -
         Ramal 2", "Esgoto - Ramal 3". Pôr esse texto na chave fragmenta a
         MESMA peça por ramal.
         Medido no print de 09/09/2026: três linhas de `Tipos de tubos:ESG_Tubo
         Série Normal`, DN 40, com 0,05 m + 0,03 m + 0,05 m — e cada uma
         arredondando para UMA BARRA de 6 m. Treze centímetros de tubo pedindo
         TRÊS barras, porque o arredondamento acontece por linha. O número do
         ramal não muda o que se compra; a disciplina muda.
         ⚠ Sem subsistema classificado cai no texto cru, que é o comportamento
         de antes: melhor fragmentar do que juntar água fria com esgoto. */
      var chaveSis = disc.subsistema || String(e.sistemaIfc || '');
      var chave = String(e.tipo || '?') + '|' + (fam || '(sem familia)') + '|' + chaveSis +
                  (e.bitolaMm > 0 ? '|DN' + e.bitolaMm : '') + (par ? '|RED' + par : '');
      var p = porChave[chave];
      if (!p) {
        var pt = partir(fam);
        /* ⚠ A BITOLA MEDIDA NA GEOMETRIA VALE MAIS QUE O NOME.
         * Medido no modelo hidrossanitario real: 106 de 119 familias ficavam
         * ambiguas so porque o Revit escreve "Luva Simples serie normal" sem
         * dizer o DN — e a base tem a mesma luva em 40/50/75/100/150 mm, com
         * 5x de diferenca de preco entre elas. O raio do IfcCircleProfileDef
         * traz exatamente os DN comerciais. Sem isto o casador acerta a
         * familia e erra a peca, que e o defeito que este modulo existe para
         * nao cometer. Ela ENTRA nas dims, e o veto passa a morder. */
        var dims = dimsDe(fam);
        if (e.bitolaMm > 0) {
          if (dims.bitola.indexOf(e.bitolaMm) < 0) dims.bitola.push(e.bitolaMm);
          dims.bitola.sort(function (a, b) { return a - b; });
          dims.vazio = false;
          dims.bitolaMedida = e.bitolaMm;
        }
        /* ⚠ A MEDIDA DA DESCRIÇÃO SÓ PREENCHE O VAZIO — nunca discute com a
           geometria nem com a topologia. Este arquivo já registra que bitola
           INVENTADA é pior que bitola faltando: ela VETA o candidato certo, e
           o sintoma vira "não achei" num item que estava na base. Texto livre
           do projetista é a fonte mais fraca das três, então ele só é ouvido
           onde não há nenhuma outra — e a redução fica de fora de propósito,
           porque o par dela mora fora de `dims` e uma descrição dizendo
           "DN 100" numa bucha 100x50 poria a peça errada de volta. */
        if (dims.vazio && !par && descr) {
          var dDescr = dimsDe(descr);
          if (!dDescr.vazio) { dims = dDescr; dims.deDescricao = true; }
        }
        /* ⚠ E ELA TAMBÉM COMPLETA GRANDEZA A GRANDEZA, não só o vazio total.
           A peça do print tinha bitola 100 medida na geometria — logo `dims`
           NÃO estava vazio — e por isso o ângulo que só a descrição traz
           ("Joelho 90º") era descartado. Resultado: com `graus: []` de um
           lado, o veto não tinha o que comparar e o joelho de 45 empatava com
           o de 90, os dois a 59%, tudo pendente.
           A regra continua sendo a de sempre: a descrição só é ouvida ONDE
           NÃO HÁ outra fonte. Grandeza que a família ou a geometria já
           declararam não é tocada — em especial a BITOLA, que a geometria
           mede e o texto livre não desmente. E a redução segue fora. */
        if (!par && descr) {
          var dC = dimsDe(descr);
          ['graus', 'litros', 'pol', 'trio'].forEach(function (g) {
            if (!dims[g].length && dC[g].length) {
              dims[g] = dC[g].slice();
              dims.vazio = false;
              (dims.deDescricaoEm = dims.deDescricaoEm || []).push(g);
            }
          });
          /* bitola só quando NEM a geometria NEM o nome da família a trazem */
          if (!dims.bitola.length && dC.bitola.length) {
            dims.bitola = dC.bitola.slice();
            dims.vazio = false;
            (dims.deDescricaoEm = dims.deDescricaoEm || []).push('bitola');
          }
        }
        p = porChave[chave] = {
          chave: chave, familia: fam, temFamilia: temFamilia,
          descricao: descr, descricaoFonte: descr ? String(e.descricaoFonte || '') : '',
          /* o que a peça É. Da descrição quando há; da família só quando ela
             nomeia UMA peça só (ver tipoDaFamilia). '' = desconhecido, e
             desconhecido nunca veta. */
          tipoPeca: descr ? tipoDaDescricao(descr) : tipoDaFamilia(fam),
          /* a serie vem da descricao e, sem ela, do nome da familia — que
             aqui NAO e ambiguo: `ESG_Serie Normal_...` nomeia a serie uma vez so */
          serie: serieDe(descr || fam),
          tipo: String(e.tipo || ''), rotulo: String(e.nome || ''),
          sistemaIfc: String(e.sistemaIfc || ''),
          disciplina: disc.disciplina, subsistema: disc.subsistema, origemDisciplina: disc.origem,
          termos: termosDe(fam, descr), dims: dims, bitolaMm: e.bitolaMm || 0,
          /* ⚠ o PAR da reducao viaja separado da bitola unica, e nunca entra
             no veto: comparar "reducao 100x50" como se fosse DN 100 poria a
             peca errada de volta pela porta dos fundos. */
          bitolaPar: par ? e.bitolaPar.slice() : null,
          fonteBitola: e.fonteBitola || (e.bitolaMm > 0 ? 'geometria' : ''),
          nomeCurto: pt.esquerda, variante: pt.direita,
          n: 0, quantidade: 0, unidade: '', fonteQtd: 'contagem', uids: []
        };
        ordem.push(chave);
      }
      p.n += n;
      /* ⚠ O QUE FOI FUNDIDO TEM DE APARECER. Agrupar pela descrição junta
         famílias e sistemas diferentes numa linha só — que é o pedido — mas
         a FAMÍLIA é como o engenheiro acha a peça de volta no Revit. Some-la
         em silêncio troca um problema (linha repetida) por outro pior (linha
         que ninguém consegue rastrear). Guardamos os nomes vistos; a tela
         mostra quantos são e a planilha lista. */
      if (!p._famVistas) p._famVistas = {};
      if (fam) p._famVistas[fam] = 1;
      if (!p._sisVistos) p._sisVistos = {};
      if (e.sistemaIfc) p._sisVistos[String(e.sistemaIfc)] = 1;
      /* ⚠ A DESCRIÇÃO PODE CHEGAR NO SEGUNDO ELEMENTO. A peça nasce do
         primeiro que aparece, e num modelo real é normal que só parte das
         instâncias traga o campo preenchido. Se a peça nasceu sem descrição e
         ela chega depois, os termos e a medida TÊM de ser refeitos — senão o
         casamento usaria o vocabulário pobre por acidente de ordem de
         leitura, e a mesma peça daria resultado diferente conforme o IFC
         fosse exportado em outra ordem. */
      if (descr) {
        p.nComDescricao = (p.nComDescricao || 0) + n;
        if (!p._descrVistas) p._descrVistas = {};
        p._descrVistas[descr] = 1;
        if (!p.descricao) {
          p.descricao = descr;
          p.descricaoFonte = String(e.descricaoFonte || '');
          p.termos = termosDe(p.familia, descr);
          /* a descrição manda: quando ela chega, o tipo vem dela e não do
             palpite da família — senão a ordem de leitura do IFC decidiria
             qual peça o casador acha que é */
          p.tipoPeca = tipoDaDescricao(descr);
          p.serie = serieDe(descr) || p.serie;
          if (p.dims.vazio && !p.bitolaPar) {
            var dTarde = dimsDe(descr);
            if (!dTarde.vazio) { dTarde.deDescricao = true; p.dims = dTarde; }
          }
          /* ⚠ MESMO COMPLEMENTO DO CAMINHO DE CIMA. Se ficasse só lá, a peça
             cujo primeiro elemento veio sem descrição perderia o ângulo — e o
             mesmo IFC daria casamento diferente conforme a ordem de leitura,
             que é justamente o que este bloco existe para impedir. */
          if (!p.bitolaPar) {
            var dT2 = dimsDe(descr);
            ['graus', 'litros', 'pol', 'trio', 'bitola'].forEach(function (g) {
              if (!p.dims[g].length && dT2[g].length) {
                p.dims[g] = dT2[g].slice();
                p.dims.vazio = false;
                (p.dims.deDescricaoEm = p.dims.deDescricaoEm || []).push(g);
              }
            });
          }
        }
      } else {
        p.nSemDescricao = (p.nSemDescricao || 0) + n;
      }
      /* ⚠ SOMA PARCIAL ROTULADA COMO MEDIDA E PIOR QUE SEM MEDIDA.
         Isto acumulava so quem trouxe quantidade e carimbava o total como
         "medido no IFC". Dez tubos de 3 m com sete medidos davam
         "10 pc · 21,00 m medidos no IFC" — são 30 m, pede-se 21, e a linha
         e internamente contraditoria (dez pecas, vinte e um metros) sem que o
         comprador tenha por que desconfiar. Mistura de medido e nao-medido na
         mesma familia e o caso NORMAL: o comprimento mora ora em
         BaseQuantities, ora no pset. Agora contamos os dois lados e a
         procedencia diz a verdade. */
      if (e.quantidade > 0 && e.unidade) {
        p.quantidade += e.quantidade; p.unidade = e.unidade;
        p.nMedidos = (p.nMedidos || 0) + n;
        if (p.fonteQtd !== 'parcial') p.fonteQtd = e.fonteQtd || 'ifc';
      } else {
        p.nSemMedida = (p.nSemMedida || 0) + n;
      }
      if (e.uid && p.uids.length < 200) p.uids.push(e.uid);
    });

    /* ===================================================================
     * SEGUNDO PASSO — MESMA DESCRIÇÃO E MESMA BITOLA VIRAM UMA LINHA SÓ.
     *
     * O PROBLEMA. O primeiro passo identifica a peça pela FAMÍLIA do Revit.
     * Quando o projetista modela o mesmo produto com duas famílias, ou
     * espalha o mesmo tubo por "Água Fria 1" e "Água Fria 3", a compra sai
     * com "Tubo PVC soldável DN 25mm" repetido em três linhas e quem pede
     * tem de somar de cabeça. Somar de cabeça é onde nasce o pedido errado.
     *
     * ⚠ POR QUE ISSO NÃO DESFAZ A TRAVA DO SISTEMA (a do bloco lá em cima).
     *   A trava existe porque joelho de água fria é soldável e o de esgoto é
     *   série normal: mesma palavra, compra diferente. Mas quem separa os
     *   dois é justamente a DESCRIÇÃO — "Joelho PVC soldável" e "Joelho PVC
     *   série normal" são textos diferentes e continuam em linhas
     *   diferentes. Descrição igual em sistemas diferentes é o mesmo produto
     *   em dois trechos da rede, e aí juntar é o certo. Sem descrição não se
     *   funde nada, e é por isso que o bloco 5 do teste continua verde.
     *
     * ⚠ A BITOLA E O PAR DE REDUÇÃO ENTRAM NA CHAVE DA FUSÃO. Descrição igual
     *   com DN diferente é compra diferente, e há descrição que não escreve o
     *   DN ("Tubo PVC soldável", sem mais). Fundir por texto só juntaria 25 e
     *   50 numa linha — exatamente o erro que este arquivo inteiro existe
     *   para não cometer.
     *
     * ⚠ E A FUSÃO É ANTES DA FINALIZAÇÃO, não depois. Depois, o grupo sem
     *   medida já virou `quantidade = contagem` com unidade "un": somar isso
     *   com o irmão medido em "m" daria metro + unidade no mesmo número.
     *   Fundindo cru, o `nSemMedida` viaja junto e a finalização marca
     *   `parcial` — que é a verdade: parte medida, parte não.
     * =================================================================== */
    function fundirPorDescricao() {
      var alvo = {}, sobrevivem = [];
      ordem.forEach(function (k) {
        var p = porChave[k];
        if (!p) return;
        var d = p.descricao ? norm(p.descricao) : '';
        if (!d) { sobrevivem.push(k); return; }
        var ck = d + (p.bitolaMm > 0 ? '|DN' + p.bitolaMm : '') +
                 (p.bitolaPar ? '|RED' + p.bitolaPar.join('x') : '');
        var dono = alvo[ck];
        if (!dono) { alvo[ck] = p; sobrevivem.push(k); return; }
        /* ⚠ UNIDADES DIFERENTES NÃO SE SOMAM, e aqui a saída é NÃO FUNDIR.
           Metro com metro quadrado no mesmo número é um total que não existe.
           É raro (mesma descrição e mesmo DN medidos em unidades diferentes),
           mas o caso raro é exatamente onde um total silenciosamente errado
           passaria — a linha fica separada e visível. */
        if (p.unidade && dono.unidade && p.unidade !== dono.unidade) { sobrevivem.push(k); return; }
        /* funde p DENTRO de dono */
        var donoTinhaMedida = dono.quantidade > 0;
        dono.n += p.n;
        dono.quantidade += p.quantidade;
        if (!dono.unidade && p.unidade) dono.unidade = p.unidade;
        /* a procedência acompanha quem trouxe a medida */
        if (!donoTinhaMedida && p.quantidade > 0) dono.fonteQtd = p.fonteQtd;
        dono.nMedidos = (dono.nMedidos || 0) + (p.nMedidos || 0);
        dono.nSemMedida = (dono.nSemMedida || 0) + (p.nSemMedida || 0);
        dono.nComDescricao = (dono.nComDescricao || 0) + (p.nComDescricao || 0);
        dono.nSemDescricao = (dono.nSemDescricao || 0) + (p.nSemDescricao || 0);
        ['_descrVistas', '_famVistas', '_sisVistos'].forEach(function (m) {
          if (!p[m]) return;
          if (!dono[m]) dono[m] = {};
          Object.keys(p[m]).forEach(function (x) { dono[m][x] = 1; });
        });
        (p.uids || []).forEach(function (u) { if (dono.uids.length < 200) dono.uids.push(u); });
        dono.fundidas = (dono.fundidas || 1) + 1;
        porChave[k] = null;
      });
      ordem = sobrevivem;
    }
    fundirPorDescricao();

    var pecas = ordem.map(function (k) {
      var p = porChave[k];
      /* ⚠ DESCRIÇÕES DIFERENTES DENTRO DA MESMA PEÇA NÃO SE ESCOLHEM SOZINHAS.
         A chave já junta o que decide a compra (tipo, família, sistema,
         bitola). Se dentro disso o projetista escreveu nomes comerciais
         diferentes, é ele que está inconsistente — e a linha vai comprar por
         UM deles. Isso vai DITO, para a tela poder mostrar; escolher em
         silêncio é a receita de comprar a peça errada com cara de conferida. */
      /* o grupo de compra sai do tipo (que ja pode ter vindo da descricao)
         e, sem ele, da classe IFC — calculado aqui, com a peca pronta */
      p.grupo = grupoDeCompra(p);
      var vistas = p._descrVistas ? Object.keys(p._descrVistas) : [];
      p.descricaoVariantes = vistas.length;
      if (vistas.length > 1) p.descricaoOutras = vistas.slice(0, 6);
      delete p._descrVistas;
      /* sem medida do IFC, a quantidade é a CONTAGEM — e isso vai dito, não
         suposto: peça contada e peça medida não valem o mesmo numa compra */
      if (!(p.quantidade > 0)) { p.quantidade = p.n; p.unidade = p.unidade || 'un'; p.fonteQtd = 'contagem'; }
      else if (p.nSemMedida > 0) {
        /* ⚠ PARTE MEDIDA, PARTE NAO. Nao da para somar contagem com metro, e
           nao da para chamar o total de "medido": ele esta INCOMPLETO, e o
           pedido sairia curto. A peca declara isso e quem consome decide —
           a tela mostra o aviso, e o status nunca vira "ok". */
        p.fonteQtd = 'parcial';
        p.faltamMedida = p.nSemMedida;
      }
      /* o que a chave por descrição reuniu, dito em número e em nome */
      var fams = p._famVistas ? Object.keys(p._famVistas) : [];
      var siss = p._sisVistos ? Object.keys(p._sisVistos) : [];
      p.familiasReunidas = fams.length;
      if (fams.length > 1) p.familiasOutras = fams.slice(0, 6);
      p.sistemasReunidos = siss.length;
      if (siss.length > 1) p.sistemasOutros = siss.slice(0, 6);
      delete p._famVistas; delete p._sisVistos;
      /* ⚠ BARRA SÓ DEPOIS DA SOMA FECHADA, e só sobre metro de verdade.
         Calcular por elemento e somar barras daria 1+1+1 = 3 barras para três
         tubos de 2 m que cabem em uma — o erro clássico de arredondar antes
         de somar, e ele infla a compra em até 6 m por linha.
         ⚠ E não sai barra de total INCOMPLETO (`parcial`): ali o metro já é
         menor que a obra, e uma barra arredondada para cima em cima de um
         número curto tem cara de conferido sendo chute. A tela mostra o aviso
         de incompleto; barra, só quando o total é o total. */
      if (ehSegmento(p.tipo) && p.unidade === 'm' && p.fonteQtd !== 'parcial' && p.quantidade > 0) {
        p.barraM = BARRA_M;
        p.barras = barrasDe(p.quantidade);
      }
      return p;
    }).sort(function (a, b) { return b.n - a.n || a.familia.localeCompare(b.familia); });

    return {
      pecas: pecas,
      resumo: {
        elementos: total, pecas: pecas.length, semFamilia: semFamilia,
        porContagem: pecas.filter(function (p) { return p.fonteQtd === 'contagem'; }).length,
        semDisciplina: pecas.filter(function (p) { return !p.disciplina; }).length,
        /* ⚠ CONTADOR DA FUSÃO, pelo mesmo motivo do `comDescricao` logo
           abaixo: sem ele, um modelo em que nada se funde é indistinguível de
           um recurso que não está funcionando. Com ele a tela consegue dizer
           "7 linhas a menos porque a descrição repetia". */
        linhasFundidas: pecas.filter(function (p) { return p.familiasReunidas > 1 || p.sistemasReunidos > 1; }).length,
        barraM: BARRA_M,
        /* metro e barra somados por fora, para o cabeçalho da compra */
        metrosTubo: pecas.reduce(function (s, p) { return s + (p.barras ? p.quantidade : 0); }, 0),
        barrasTubo: pecas.reduce(function (s, p) { return s + (p.barras || 0); }, 0),
        /* ⚠ ESTE NÚMERO É O QUE IMPEDE O RECURSO DE SER INERTE EM SILÊNCIO.
           Ler a Descrição só ajuda se o modelo a tiver preenchida, e isso
           varia por escritório e por biblioteca de família. Sem contador, um
           modelo sem descrição nenhuma se comporta exatamente como antes e
           ninguém descobre por que o casamento não melhorou. Com ele, a tela
           diz "0 de 182 peças trouxeram descrição" e a resposta está dada. */
        comDescricao: pecas.filter(function (p) { return !!p.descricao; }).length,
        descricaoDivergente: pecas.filter(function (p) { return p.descricaoVariantes > 1; }).length
      }
    };
  }

  /* ---------------------------------------------------------------
   * 6. CASAR — e, principalmente, recusar
   * ------------------------------------------------------------- */
  var MIN_CONF = 30;

  /* ⚠ TERMO RARO VALE MAIS QUE TERMO COMUM, e a diferença não é teórica:
     na base de MG "pvc" aparece em 19,3% dos insumos e "joelho" em 1,9%.
     Contando os dois igual, um CAP e um TUBO empatavam com um JOELHO por
     compartilharem "serie" e "normal" — seis insumos diferentes, todos a 67%,
     e a peça certa perdida no meio. O peso vem de FORA (quem tem a base
     calcula uma vez, com `pesosDe`); sem ele tudo pesa 1 e o comportamento é
     o de antes, o que mantém o motor utilizável sem base carregada. */
  function pesoDeTermo(peso, t) {
    if (!peso) return 1;
    var df = peso[t];
    if (!(df > 0)) return 1.6;             // termo que nem existe na base: distintivo
    var p = Math.log((peso._n || 1000) / df);
    return p < 0.2 ? 0.2 : (p > 3 ? 3 : p);
  }

  function pontuar(peca, item, sinonimos, peso) {
    var descr = String(item.descricao || '');
    var alvo = norm(descr).replace(/[_\-.,;:/()\[\]"]/g, ' ');
    var toksAlvo = {};
    alvo.split(/\s+/).forEach(function (t) { if (t.length >= 3) toksAlvo[t] = 1; });

    function pesoDe(t) { return pesoDeTermo(peso, t); }
    var achou = 0, tot = 0, viaSinonimo = 0;
    peca.termos.forEach(function (t) { tot += pesoDe(t); });
    if (!tot) tot = 1;
    peca.termos.forEach(function (t) {
      if (toksAlvo[t]) { achou += pesoDe(t); return; }
      /* ⚠ SINÔNIMO É SEGUNDA TENTATIVA, nunca substituição — e por PALAVRA
         INTEIRA. Trocar antes de tentar o termo original foi o que já fez
         "vaso" virar outra coisa nesta base. */
      var sin = sinonimos && sinonimos[t];
      if (!sin) return;
      var arr = Array.isArray(sin) ? sin : [sin];
      for (var i = 0; i < arr.length; i++) {
        var s = norm(arr[i]);
        if (toksAlvo[s] || new RegExp('\\b' + s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b').test(alvo)) { achou += pesoDe(t); viaSinonimo++; return; }
      }
    });

    var conf = Math.round((achou / tot) * 100);
    var dimAlvo = dimsDe(descr);
    var dim = compararDims(peca.dims, dimAlvo);
    /* a dimensão não SOMA ponto; ela só reprova. Somar faria o candidato
       errado subir por ter mais números na descrição. */
    if (dim === 'diverge') conf = Math.max(0, conf - 60);
    /* ⚠ E A UNIDADE REPROVA MAIS FORTE QUE A MEDIDA. Tubo medido em METRO
       contra anel vendido por UNIDADE não é um candidato pior — é outra
       coisa. O desconto é maior que o da medida porque aqui não há dúvida:
       a grandeza é incompatível, não apenas diferente. */
    /* ⚠ SÓ VETA QUANDO A UNIDADE FOI MEDIDA, NÃO QUANDO NÓS A INVENTAMOS.
       Sem medida no IFC, `levantar` usa a CONTAGEM e carimba 'un' — que é um
       preenchimento nosso, não um fato do modelo. Vetar por ele reprovava o
       candidato CERTO: um tubo sem `Length` no arquivo virava 'un' e o
       `TUBO PVC ... [M]` da base era eliminado, deixando a peça pendente com
       o item exato disponível. Medido: o placar caiu de 1.161 para 175 peças
       casadas até esta guarda entrar. */
    /* ⚠ E QUANDO A QUANTIDADE É CONTAGEM, A GRANDEZA VEM DO TIPO.
       Um tubo sem `Length` no IFC cai na contagem e ganha 'un' de
       preenchimento; sem esta linha o veto desligava e o ANEL DE BORRACHA
       [UN] voltava a ganhar do TUBO [M] — o defeito exato que este bloco
       existe para fechar, só que reaparecendo pela porta dos fundos num
       arquivo mal exportado. Tubo se compra por METRO sempre, tenha o
       arquivo medido ou não: isso é do produto, não do IFC. */
    var uPeca = peca.unidade;
    if (peca.fonteQtd === 'contagem' && ehSegmento(peca.tipo)) uPeca = 'm';
    var uni = (peca.fonteQtd === 'contagem' && !ehSegmento(peca.tipo))
      ? 'muda' : compararUnidade(uPeca, item.unidade);
    if (uni === 'diverge') conf = Math.max(0, conf - 80);
    return { conf: conf, achou: achou, tot: tot, viaSinonimo: viaSinonimo, dim: dim, uni: uni, dimAlvo: dimAlvo };
  }

  /* ⚠ "TEM ALGUMA MEDIDA" NAO E "TEM A BITOLA".
     `dims.vazio` era falso para uma peca que so trouxe o ANGULO no nome
     ("Curva 90°"), e o guarda deixava passar: bitola nenhuma dos dois lados,
     graca ao grau que casou, e o veredito saia "ok". Numa peca de rede a
     bitola e a medida que decide a compra; sem ela nao ha confirmacao
     possivel. Para peca que NAO e de rede (porta, piso, louca) a bitola nao e
     o discriminante, e ai vale a medida que houver. */
  function ehDeRede(tipo) { return /^IFC(PIPE|FLOW|DUCT|VALVE)/.test(String(tipo || '').toUpperCase()); }
  function semBitolaUtil(peca) {
    var d = peca.dims || {};
    if (peca.bitolaPar && peca.bitolaPar.length > 1) return false;   // reducao tem o par
    if (ehDeRede(peca.tipo)) return !((d.bitola || []).length || (d.pol || []).length);
    return !!d.vazio;
  }

  function casar(peca, candidatos, opc) {
    opc = opc || {};
    var sin = opc.sinonimos || null;
    var lista = (candidatos || []).map(function (c) {
      var item = c.item || c;
      var p = pontuar(peca, item, sin, opc.peso || null);
      return {
        item: item, fonte: c.fonte || item.fonte || '',
        conf: p.conf, dim: p.dim, uni: p.uni, achou: p.achou, de: p.tot, viaSinonimo: p.viaSinonimo,
        tipoPeca: compararTipoPeca(peca.tipoPeca, tipoDaDescricao(item.descricao)),
        serie: compararSerie(peca.serie, serieDe(item.descricao))
      };
    }).filter(function (c) { return c.conf > 0; })
      .sort(function (a, b) {
        /* ⚠ O SUBSTANTIVO VEM ANTES DO SCORE, e é a única chave que passa na
           frente dele. Medido no tê 50×50 do projeto real: uma
           `JUNCAO SIMPLES, PVC, 45 GRAUS, DN 50 X 50` marcava 88% contra 66%
           do `TE SANITARIO, PVC, DN 50 X 50` — as duas com a bitola
           conferindo — porque a família do Revit se chama `Te_Juncao` e a
           palavra "juncao" entrava nos termos. Deixar o score decidir aí é
           comprar junção de 45° no lugar de tê de 90°, com cara de conferido.
           Peça de OUTRO tipo perde para peça do tipo certo, sempre; quando o
           tipo é desconhecido dos dois lados o valor é 'muda' e a ordem é
           exatamente a de antes. */
        /* ⚠ QUEM DIVERGE CAI — TODOS OS VETOS NA MESMA BALANÇA, E ANTES DO
           SCORE. A versão anterior empilhava um `if` por veto, em ordem fixa
           (tipo, série, score, unidade, medida), e isso põe um veto a mandar
           no outro: bastou a série entrar acima da medida para um
           `JOELHO ... 90 GRAUS, DN 100 X 50 MM, SERIE NORMAL` (uma REDUÇÃO,
           R$ 22,81) subir na frente do `JOELHO ... 90 GRAUS, DN 100 MM`
           (R$ 9,33) numa busca por joelho reto de 45° — a palavra "SERIE
           NORMAL" pesando mais que a medida errada. Medido aqui, não suposto.
           A regra honesta é a que este arquivo já usa para a bitola: divergiu,
           o candidato cai. Contar as divergências trata os quatro vetos como
           iguais e não cria hierarquia entre eles; depois o score decide, e só
           então quantas confirmações cada um traz. */
        var ord = { confere: 0, muda: 1, diverge: 2 };
        function vetos(c) {
          var n = 0;
          if (c.tipoPeca === 'diverge') n++;
          if (c.serie === 'diverge') n++;
          if (c.uni === 'diverge') n++;
          if (c.dim === 'diverge') n++;
          return n;
        }
        /* ⚠ E O VETO SÓ MANDA ENTRE QUEM ESTÁ ACIMA DO MÍNIMO DE CONFIANÇA.
           Sem este degrau, "não declarar nada" virava vantagem: no tê 50×50 um
           ADITIVO IMPERMEABILIZANTE e um ADITIVO SUPERPLASTIFICANTE, ambos a
           22% e sem tipo nem medida declarados (zero vetos), subiam acima da
           junção, do cap e da luva de 66% — que ao menos são conexões da mesma
           bitola e série, e são o que a pessoa quer ver como alternativa.
           Medido aqui. Abaixo do mínimo, quem decide é o score e mais nada. */
        var fracoA = a.conf < MIN_CONF ? 1 : 0, fracoB = b.conf < MIN_CONF ? 1 : 0;
        if (fracoA !== fracoB) return fracoA - fracoB;
        var va = vetos(a), vb = vetos(b);
        if (va !== vb) return va - vb;
        if (b.conf !== a.conf) return b.conf - a.conf;
        /* empate no score: quem CONFIRMA mais passa na frente de quem não
           declara. Unidade e medida seguem valendo mais que o resto — é a
           unidade que separa o anel [UN] do tubo [M]. */
        if (ord[a.uni] !== ord[b.uni]) return ord[a.uni] - ord[b.uni];
        if (ord[a.dim] !== ord[b.dim]) return ord[a.dim] - ord[b.dim];
        if (ord[a.tipoPeca] !== ord[b.tipoPeca]) return ord[a.tipoPeca] - ord[b.tipoPeca];
        return (ord[a.serie] - ord[b.serie]);
      });

    var acima = lista.filter(function (c) { return c.conf >= MIN_CONF; });
    var status = 'pendente', porque = '';

    /* ⚠ SEM FAMÍLIA MAS COM DESCRIÇÃO NÃO É "SEM NOME". Esta guarda recusava
       pela AUSÊNCIA de vocabulário: o `rotulo` do app ("Louça/terminal") é
       igual para dezenas de peças, então casar por ele é casar por nada. A
       descrição do modelo é vocabulário de verdade — é o nome comercial que a
       base entende. Manter a recusa aqui apagaria justamente o caso que a
       leitura da descrição existe para resolver, e o sintoma seria uma peça
       nomeada na tela saindo "pendente" sem motivo visível. */
    if (!peca.temFamilia && !peca.descricao) {
      status = 'pendente';
      porque = 'a peça não traz nome de família no modelo — só o rótulo genérico do tipo, que é igual para dezenas de peças diferentes';
    } else if (!acima.length) {
      status = 'pendente';
      porque = 'nenhum insumo da base ficou acima do mínimo de confiança';
    } else {
      var topo = acima[0];
      /* ⚠ EMPATE SÓ CONTA ENTRE PEÇAS DO MESMO TIPO. Sem isto o recado passou
         a mentir na direção contrária: no tê 50×50, com o tipo já resolvido, a
         tela dizia "6 insumos empatam em 66%" — mas os outros cinco eram CAP,
         LUVA, TUBO e TERMINAL, que o tipo já mandou para o fim da lista e que
         ninguém está considerando. Empate é entre quem disputa. */
      var empatados = acima.filter(function (c) {
        return c.conf === topo.conf && c.tipoPeca === topo.tipoPeca;
      });
      /* ⚠ TIPO DIFERENTE NUNCA VIRA "ok", e isso vem ANTES da unidade e da
         medida: se o candidato nem é a mesma peça, o resto não importa.
         Medido no print do projeto real: uma `LUVA SIMPLES, PVC, SOLDAVEL,
         DN 100` estava PRÉ-MARCADA para a "Junção Simples 100 × 100mm" com o
         veredito "nome e medida conferem" — a bitola conferia, a palavra
         "simples" era comum às duas, e nada dizia que luva não é junção. */
      if (topo.tipoPeca === 'diverge') {
        status = 'ambiguo';
        porque = 'o melhor candidato é ' + rotuloTipo(tipoDaDescricao(topo.item.descricao)) +
                 ' e o modelo pede ' + rotuloTipo(peca.tipoPeca) +
                 ' — confira na lista ou busque o item na base';
      } else if (topo.serie === 'diverge') {
        /* ⚠ SÉRIE ERRADA NÃO VIRA "ok". Série normal e série reforçada (R) são
           o mesmo desenho de peça em espessura e preço diferentes — no joelho
           90° DN 100 de esgoto, R$ 9,33 contra R$ 21,80. Deixar passar como
           conferido é a peça certa pelo preço errado, 2,3× para cima. */
        status = 'ambiguo';
        porque = 'o melhor candidato é ' + rotuloSerie(serieDe(topo.item.descricao)) +
                 ' e o modelo pede ' + rotuloSerie(peca.serie) +
                 ' — confira na lista ou busque o item na base';
      } else if (topo.uni === 'diverge') {
        /* ⚠ UNIDADE INCOMPATÍVEL VEM ANTES DE TUDO. É o caso do anel de
           borracha [UN] no lugar do tubo [M], em que a bitola confere nos dois
           e só a grandeza denuncia — medido no modelo real, cinco das 23
           linhas pré-marcadas apontavam para a junta e não para a peça. */
        status = 'ambiguo';
        porque = 'o melhor candidato é vendido em ' + (topo.item.unidade || '?') +
                 ' e o modelo mediu em ' + (peca.unidade || '?') + ' — são coisas diferentes';
      } else if (topo.dim === 'diverge') {
        status = 'ambiguo';
        porque = 'o melhor candidato tem outra bitola/medida — a do modelo é ' + resumoDim(peca.dims, peca.bitolaPar);
      } else if (empatados.length > 1) {
        status = 'ambiguo';
        porque = empatados.length + ' insumos empatam em ' + topo.conf + '%' +
          (empatados.some(function (c) { return c.dim === 'muda'; }) ? ' e nenhum declara a medida que decidiria' : '');
      } else if (semBitolaUtil(peca)) {
        /* o modelo não disse a medida. Um único candidato forte ainda é uma
           escolha honesta, mas ela não pode passar como confirmada. */
        status = 'ambiguo';
        porque = 'não dá para confirmar a bitola: o modelo não a traz para esta peça';
      } else if (topo.dim === 'muda') {
        status = 'ambiguo';
        porque = 'o insumo não declara a medida que o modelo traz (' + resumoDim(peca.dims, peca.bitolaPar) + ')';
      } else {
        status = 'ok';
        porque = 'nome e medida conferem (' + resumoDim(peca.dims, peca.bitolaPar) + ')';
        /* ⚠ QUANDO A DESCRIÇÃO FOI A PROVA, ISSO VAI DITO. Um "ok" decidido
           por texto livre do projetista não vale o mesmo que um decidido pela
           geometria, e quem confere a requisição precisa saber de onde veio a
           evidência para poder discordar. Sem esta linha, os dois casos
           chegam à tela com a mesma cara. */
        if (peca.descricao && !peca.temFamilia) porque += ' — nome vindo da Descrição do modelo, que é a única que esta peça traz';
        else if (peca.dims && peca.dims.deDescricao) porque += ' — a medida veio da Descrição do modelo, não da geometria';
      }
    }
    return { candidatos: lista.slice(0, opc.max || 8), status: status, porque: porque, empate: acima.length ? acima.filter(function (c) { return c.conf === acima[0].conf && c.tipoPeca === acima[0].tipoPeca; }).length : 0 };
  }

  function resumoDim(d, par) {
    if (par && par.length > 1) return 'reducao ' + par.join(' x ') + ' mm';
    if (!d || d.vazio) return 'sem medida';
    var p = [];
    if (d.bitola.length) p.push('DN ' + d.bitola.join('/'));
    if (d.pol.length) p.push(d.pol.map(function (v) { return polTexto(v); }).join('/') + '"');
    if (d.trio.length) p.push(d.trio.join(' '));
    if (d.graus.length) p.push(d.graus.join('/') + '°');
    if (d.litros.length) p.push(d.litros.join('/') + ' L');
    return p.join(' · ');
  }
  function polTexto(v) {
    var i = Math.floor(v), f = v - i;
    var fr = { 0.25: '1/4', 0.5: '1/2', 0.75: '3/4', 0.125: '1/8', 0.375: '3/8', 0.625: '5/8' };
    var k = null;
    for (var kk in fr) if (Math.abs(f - parseFloat(kk)) < 0.01) k = fr[kk];
    if (!k) return String(Math.round(v * 100) / 100);
    return (i ? i + ' ' : '') + k;
  }

  /* ---------------------------------------------------------------
   * 6b. BITOLA DAS CONEXÕES, PELA TOPOLOGIA DA REDE
   *
   * A bitola do TUBO vem da geometria (o raio do perfil circular). A da
   * CONEXÃO não vem: o Revit exporta joelho, luva e tê como malha facetada,
   * sem perfil. Medido no projeto hidrossanitário real: 1.725 tubos com
   * bitola, 4.201 conexões sem — e sem bitola a conexão fica ambígua contra
   * a base, porque a mesma luva existe em 40/50/75/100/150 mm.
   *
   * MAS A REDE SABE. Um fato do arquivo real, já medido quando se fez a
   * numeração dos ramais: TUBO NUNCA É VIZINHO DE TUBO — entre dois tubos há
   * sempre uma conexão. Então a conexão está, por construção, encostada em
   * tubos cuja bitola nós conhecemos.
   *
   * ⚠ E AQUI MORA O PERIGO DESTE ARQUIVO INTEIRO: REDUÇÃO.
   * Bucha de redução, tê de redução e redução excêntrica ligam bitolas
   * DIFERENTES — é a função delas. Dar um DN único a uma redução é pedir a
   * peça errada na loja, e ela chegaria com cara de conferida. Por isso:
   *   · vizinhança com UM valor  -> bitola resolvida;
   *   · vizinhança com DOIS ou mais -> é transição: guarda o PAR e NUNCA
   *     vira bitola única;
   *   · e o par NÃO se propaga adiante — quem está depois da redução tem a
   *     bitola do lado dele, não a mistura dos dois.
   *
   * ⚠ E A PROCEDÊNCIA VIAJA. Bitola medida na geometria e bitola deduzida da
   * vizinhança não valem o mesmo, e quem compra precisa saber de qual das
   * duas veio o número. `fonteBitola` diz: 'geometria' | 'topologia' | ''.
   * ------------------------------------------------------------- */
  var SALTOS_MAX = 4;   /* teto de propagação: rede real tem ciclo, e um laço
                           sem freio andaria para sempre. Quatro saltos já
                           alcançam a conexão mais distante de um tubo nos
                           arranjos que aparecem no arquivo real. */

  /* ⚠ A PEÇA QUE DIZ, NO NOME, QUE MUDA DE BITOLA — NUNCA RECEBE DN ÚNICO.
   *
   * Esta lista não é enfeite: ela veio de uma medição que reprovou a primeira
   * versão deste algoritmo. Rodando no projeto hidrossanitário real, 111
   * reduções ganharam DN ÚNICO — `AF_Soldavel_Te_Reducao` (59 peças) saiu como
   * "DN 25", `Reducao Excentrica` (19) como "DN 50", buchas de redução (33)
   * como "DN 40". Cada uma dessas compraria a peça errada, com cara de
   * conferida.
   *
   * A CAUSA: a propagação decidia "valor único" pelo que já era conhecido
   * NAQUELA onda. Uma redução com um lado ainda desconhecido parece
   * inequívoca — e é justamente a peça em que os dois lados diferem por
   * definição. Vizinhança incompleta não é vizinhança concordante.
   *
   * O nome que o projetista escreveu é evidência tão boa quanto a rede, e
   * chega antes dela. */
  var DIZ_TRANSICAO = /reduc|reduç|bucha\s*de\s*red|adaptador|te[_\s-]*reduc|luva\s*de\s*red/i;

  /* ⚠ E TERMINAL NÃO TEM BITOLA DE COMPRA. Uma bacia sanitária se compra pelo
   * modelo, não por DN; a caixa d'água, por litro. A rede acusou a bacia como
   * "25x100" (água fria de um lado, esgoto do outro) e a caixa como
   * "25x32x50x60" — verdade sobre as ligações, e irrelevante para o pedido.
   * Deixar isso virar bitola só põe ruído no casamento. */
  function ehTerminal(tipo) { return /TERMINAL$/.test(String(tipo || '').toUpperCase()); }

  function bitolasPorTopologia(elementos, topo) {
    topo = topo || {};
    var portaDe = topo.portaDe || {}, ligacao = topo.ligacao || {}, portasDe = topo.portasDe || {};
    var porUid = {}, semTopo = 0;

    (elementos || []).forEach(function (e) {
      if (!e || !e.uid) return;
      porUid[e.uid] = {
        uid: e.uid, tipo: e.tipo || '', familia: e.familia || '',
        mm: e.bitolaMm > 0 ? [e.bitolaMm] : [],
        fonte: e.bitolaMm > 0 ? 'geometria' : '',
        saltos: e.bitolaMm > 0 ? 0 : -1,
        reducao: false,
        parcial: false,
        declaraTransicao: DIZ_TRANSICAO.test(e.familia || ''),
        /* terminal fica de fora da propagação: bacia se compra por modelo,
           caixa d'água por litro — bitola ali é ruído no casamento */
        foraDaBitola: ehTerminal(e.tipo)
      };
      if (!portasDe[e.uid]) semTopo++;
    });

    function vizinhos(uid) {
      var ps = portasDe[uid] || [], out = [];
      for (var i = 0; i < ps.length; i++) {
        var outra = ligacao[ps[i]];
        if (outra == null) continue;
        var alvo = portaDe[outra];
        if (alvo && alvo !== uid) out.push(alvo);
      }
      return out;
    }

    /* ondas: na 1ª só quem tem bitola de GEOMETRIA semeia; nas seguintes,
       quem já resolveu na onda anterior. Reduções não semeiam nunca. */
    var mudou = true, onda = 0;
    while (mudou && onda < SALTOS_MAX) {
      mudou = false; onda++;
      Object.keys(porUid).forEach(function (uid) {
        var r = porUid[uid];
        if (r.foraDaBitola) return;                // terminal nao entra
        /* ⚠ A TRANSIÇÃO CONTINUA COLETANDO ATÉ ESTABILIZAR.
           Ela congelava na primeira onda: uma bucha entre um tubo já medido e
           um joelho que só resolveria na onda seguinte saía como
           "redução 50" em vez de "redução 100 x 50". Ficava segura — nunca
           virava DN único — mas a linha da requisição dizia menos do que a
           rede sabia, e é justamente na redução que o comprador precisa dos
           dois lados para pedir a peça certa. */
        if (r.fonte && !(r.reducao && r.parcial)) return;
        var vals = {};
        vizinhos(uid).forEach(function (v) {
          var n = porUid[v];
          /* ⚠ só herda de vizinho com bitola ÚNICA e de onda anterior.
             Herdar de uma redução espalharia a mistura 100/50 rede afora. */
          if (!n || !n.fonte || n.reducao || n.mm.length !== 1) return;
          if (n.saltos >= onda) return;
          vals[n.mm[0]] = 1;
        });
        var lista = Object.keys(vals).map(Number).sort(function (a, b) { return a - b; });
        if (!lista.length) return;
        /* quando ja e transicao parcial, so muda se a rede acrescentou lado */
        if (r.reducao && r.parcial) {
          var novos = {};
          r.mm.concat(lista).forEach(function (x) { novos[x] = 1; });
          var uniao = Object.keys(novos).map(Number).sort(function (a, b) { return a - b; });
          if (uniao.length > r.mm.length) {
            r.mm = uniao; r.saltos = onda; mudou = true;
            if (uniao.length > 1) r.parcial = false;   // achou o outro lado
          }
          return;
        }
        if (lista.length > 1) {
          /* transição medida: guarda o par e PARA. Não é bitola única, e não
             semeia — quem está depois da redução tem a bitola do lado dele,
             não a mistura dos dois. */
          r.mm = lista; r.fonte = 'topologia'; r.reducao = true; r.saltos = onda; mudou = true;
          return;
        }
        /* ⚠ UM VALOR SÓ NÃO BASTA quando a peça declara que muda de bitola.
           Ver DIZ_TRANSICAO: 111 reduções saíram com DN único na primeira
           versão porque o outro lado ainda não tinha resolvido. */
        if (r.declaraTransicao) {
          r.mm = lista; r.fonte = 'topologia'; r.reducao = true; r.parcial = true;
          r.saltos = onda; mudou = true;
          return;
        }
        r.mm = lista; r.fonte = 'topologia'; r.saltos = onda; mudou = true;
      });
    }

    var res = { geometria: 0, topologia: 0, reducao: 0, reducaoParcial: 0, terminal: 0, semBitola: 0, semTopologia: semTopo, ondas: onda };
    Object.keys(porUid).forEach(function (u) {
      var r = porUid[u];
      if (r.fonte === 'geometria') res.geometria++;
      else if (r.reducao) { res.topologia++; res.reducao++; if (r.parcial) res.reducaoParcial++; }
      else if (r.fonte === 'topologia') res.topologia++;
      else if (r.foraDaBitola) res.terminal++;
      else res.semBitola++;
    });
    return { porUid: porUid, resumo: res };
  }

  /* Aplica o resultado da topologia sobre a lista de elementos, para o
     `levantar` receber a bitola já resolvida.
     ⚠ A REDUÇÃO NÃO GANHA `bitolaMm`: ela ganha `bitolaPar`, que entra na
     chave de agrupamento e na descrição, e NUNCA no veto de bitola única —
     senão "redução 100x50" seria comparada como se fosse uma peça DN 100. */
  function aplicarTopologia(elementos, mapa) {
    (elementos || []).forEach(function (e) {
      var r = mapa && mapa.porUid && mapa.porUid[e.uid];
      if (!r || !r.fonte) return;
      e.fonteBitola = r.fonte;
      if (r.reducao) { e.bitolaPar = r.mm.slice(); e.bitolaMm = 0; }
      else if (!(e.bitolaMm > 0)) e.bitolaMm = r.mm[0];
    });
    return elementos;
  }

  /* ---------------------------------------------------------------
   * 7. ADAPTADOR PARA A REQUISIÇÃO
   * ------------------------------------------------------------- */

  /* ⚠ TEXTO DO IFC VIRANDO FÓRMULA. A descrição sai do nome que o projetista
     digitou no Revit e pode começar com `=`, `+`, `-` ou `@` — no Excel isso
     vira fórmula, e o item chega ao fornecedor como #NOME?. Mesmo cuidado que
     `js/bimtuboxls.js` já toma na planilha de tubos. */
  function seguro(t) {
    var s = String(t == null ? '' : t).replace(/[\r\n\t]+/g, ' ').trim();
    return /^[=+\-@]/.test(s) ? "'" + s : s;
  }

  /* `escolhas` = { <chave da peça>: item escolhido (ou null para pendente) }.
     Quem escolhe é a pessoa na tela; este adaptador só formata. */
  function paraRequisicao(pecas, escolhas) {
    escolhas = escolhas || {};
    var itens = [], pendentes = 0;
    (pecas || []).forEach(function (p) {
      var it = escolhas[p.chave];
      var temItem = !!(it && it.codigo);
      if (!temItem) pendentes++;
      /* ⚠ NA LINHA PENDENTE, QUEM LÊ É O FORNECEDOR — e ele não conhece a
         convenção de pasta do escritório. "AF_Soldavel_Tubo" não se cota;
         "Tubo PVC soldável água fria DN 25 mm" se cota. Por isso a descrição
         do modelo (nome de mercado) vem na frente da família quando existe.
         A família NÃO se perde: ela viaja em `origemBim.familia`, que é o que
         o engenheiro usa para achar a peça de volta no Revit. */
      var descr = temItem ? it.descricao : (p.descricao || p.familia || p.rotulo || 'peça do modelo');
      /* ⚠ O PAR DA REDUCAO TEM DE VIR JUNTO. Esta linha chamava `resumoDim`
         SEM o segundo argumento — e a reducao guarda o par FORA de `dims`, de
         proposito. Resultado: o painel mostrava "reducao 25 x 32 mm" e a linha
         que o comprador le saia como "AF_Soldavel_Bucha de Reducao Longa",
         pelada. Trinta e tres buchas para pedir sem saber de qual para qual —
         na peca que este arquivo declara ser a mais cara de errar. */
      var medida = resumoDim(p.dims, p.bitolaPar);
      /* ⚠ A BARRA TEM DE ATRAVESSAR PARA A REQUISIÇÃO — ela parava no painel.
         O painel do BIM mostrava "26,00 m = 5 barras", e o item gerado saía
         só com "26 m": quem abre a requisição no ERP, que é onde a compra
         acontece, voltava a converter de cabeça. É o defeito de sempre nesta
         base — o conserto que para no segundo consumidor —, e aqui ele
         apagava justamente o número que o recurso existe para dar.
         ⚠ E ela entra no TEXTO, não na quantidade: `precoRef` da base é por
         METRO. Trocar 26 m por 5 barras multiplicaria o valor da linha por
         um número errado, e requisição dispara aprovação por VALOR. */
      var barraTxt = (p.barras > 0) ? (' · ' + p.barras + ' barra' + (p.barras > 1 ? 's' : '') +
                                       ' de ' + (p.barraM || BARRA_M) + ' m') : '';
      itens.push({
        codigo: temItem ? String(it.codigo) : '',
        /* a medida entra na descrição da linha pendente: sem ela, "Luva
           Simples" no papel do comprador não diz qual comprar */
        descricao: seguro(descr + (!temItem && medida !== 'sem medida' ? ' — ' + medida : '') + barraTxt),
        unidade: (temItem && it.unidade) || p.unidade || 'un',
        quantidade: p.quantidade,
        /* ⚠ SEM PREÇO CHUTADO. A pendente vai com 0 e o consumidor tem de
           dizer que o total é PARCIAL — requisição dispara aprovação por
           VALOR, e um total subestimado pode passar por baixo do limite de
           quem precisava aprovar. */
        precoRef: temItem ? (Number(it.custoUnitario) || 0) : 0,
        categoria: 'MAT',
        fonte: temItem ? (it.fonte || '') : '',
        pendente: !temItem,
        origemBim: {
          chave: p.chave, familia: p.familia, tipo: p.tipo,
          sistema: p.sistemaIfc || '', subsistema: p.subsistema || '',
          bitolaMm: p.bitolaMm || 0, bitolaPar: p.bitolaPar || null,
          fonteBitola: p.fonteBitola || '', fonteQtd: p.fonteQtd,
          faltamMedida: p.faltamMedida || 0, pecas: p.n,
          /* ⚠ O QUE A FUSAO REUNIU VIAJA JUNTO — e `familia` acima passou a
             ser só a PRIMEIRA delas. Quando a linha reúne duas famílias do
             Revit para o mesmo produto comercial, quem lê a requisição depois
             (sem reabrir o IFC) precisa das outras para achar a peça de volta.
             A gaveta e a planilha já mostram; aqui faltava, e uma linha que
             ninguém rastreia é o preço alto de resolver a linha repetida.
             ⚠ CAMPOS NOVOS, nunca no lugar de `familia`/`sistema`: quem já lê
             os antigos continua lendo. */
          /* a barra também em campo próprio: o texto serve para quem LÊ, o
             campo serve para quem for somar barra por obra depois sem ter de
             despedaçar a descrição com regex */
          barras: p.barras || 0, barraM: p.barras ? (p.barraM || BARRA_M) : 0,
          familiasReunidas: p.familiasReunidas || 1,
          familias: (p.familiasOutras && p.familiasOutras.length) ? p.familiasOutras.slice() : null,
          sistemas: (p.sistemasOutros && p.sistemasOutros.length) ? p.sistemasOutros.slice() : null,
          /* a descrição do modelo viaja junto mesmo quando o item casou: é ela
             que permite conferir DEPOIS se o insumo escolhido é o que o
             projeto pedia, sem reabrir o IFC */
          descricao: p.descricao || '', descricaoFonte: p.descricaoFonte || ''
        }
      });
    });
    return {
      itens: itens,
      pendentes: pendentes,
      /* o valor que a tela mostra tem de vir com esta ressalva junto */
      totalParcial: pendentes > 0
    };
  }

  /* Pré-preenche o formulário de insumo próprio a partir da peça.
     ⚠ NÃO inventa preço: o campo vai vazio e quem digita é o usuário. */
  function paraInsumoProprio(peca) {
    var medida = resumoDim(peca.dims, peca.bitolaPar);
    return {
      /* mesmo motivo da linha de requisição: o insumo próprio nasce com o nome
         de mercado quando o modelo o traz — é ele que vai ser cotado depois */
      descricao: seguro((peca.descricao || peca.familia) + (medida !== 'sem medida' ? ' — ' + medida : '')),
      unidade: peca.unidade || 'un',
      categoria: 'MAT',
      preco: 0,
      origemBim: { chave: peca.chave, familia: peca.familia, tipo: peca.tipo, bitolaMm: peca.bitolaMm || 0,
                   descricao: peca.descricao || '' }
    };
  }

  /* Frequencia de cada termo na base. Quem tem a lista calcula UMA vez e
     passa em `opc.peso` — fica aqui para nao existirem duas contagens
     diferentes dando pesos diferentes ao mesmo termo. */
  function pesosDe(itens) {
    var df = { _n: (itens || []).length || 1 };
    (itens || []).forEach(function (x) {
      var it = x.item || x, vis = {};
      norm(String(it.descricao || '')).replace(/[^a-z0-9]+/g, ' ').split(' ').forEach(function (t) {
        if (t.length < 3 || vis[t]) return;
        vis[t] = 1; df[t] = (df[t] || 0) + 1;
      });
    });
    return df;
  }

  var BimPeca = {
    levantar: levantar,
    casar: casar,
    paraRequisicao: paraRequisicao,
    paraInsumoProprio: paraInsumoProprio,
    bitolasPorTopologia: bitolasPorTopologia,
    aplicarTopologia: aplicarTopologia,
    seguro: seguro,
    dimsDe: dimsDe,
    pesosDe: pesosDe,
    termosDe: termosDe,
    compararDims: compararDims,
    compararUnidade: compararUnidade,
    grandezaDaUnidade: grandezaDaUnidade,
    disciplinaDe: disciplinaDe,
    subsistemaDe: subsistemaDe,
    partir: partir,
    resumoDim: resumoDim,
    MIN_CONF: MIN_CONF,
    /* expostos para a fiação (tela e planilha usam o MESMO número) e para o
       gate poder sondar a conta da barra sem montar um levantamento inteiro */
    BARRA_M: BARRA_M,
    barrasDe: barrasDe,
    /* o substantivo da peca, exposto para o gate sondar a leitura sem
       montar levantamento — e para a tela poder dizer o que achou */
    grupoDeCompra: grupoDeCompra,
    rotuloGrupo: rotuloGrupo,
    tipoDaDescricao: tipoDaDescricao,
    tipoDaFamilia: tipoDaFamilia,
    rotuloTipo: rotuloTipo,
    ehSegmento: ehSegmento
  };

  global.BimPeca = BimPeca;
  if (typeof module !== "undefined" && module.exports) module.exports = BimPeca;
})(typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this));
