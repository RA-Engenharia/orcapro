/* =====================================================================
 * importador.js — AGENTE IMPORTADOR de planilhas (PURO, Node-testável).
 * "Analisa a planilha independente do formato e traz pra dentro já como
 *  etapas + itens." Recebe a MATRIZ 2D (a UI extrai do Excel/CSV) e DETECTA
 *  a estrutura — não assume layout.
 *
 * Endurecido por revisão adversarial (v1.1.41):
 *  - norm() remove pontuação → casa "Quant.", "P. Unit", "Un." nos sinônimos;
 *  - custos por MAGNITUDE (total≈unit×qtd≥unit) — fix do ops (f8ca422) preservado;
 *  - QUANTIDADE detectada DEPOIS dos custos (coluna numérica restante, mesmo com
 *    centavos) → não é mais roubada pela heurística de "moeda";
 *  - num() decide milhar/decimal por COLUNA (dotMode): coluna com vírgula → ponto=milhar
 *    ("1.234"→1234, planilha BR); coluna só com pontos → ponto=decimal ("0.750"→0,75);
 *    trata parênteses contábeis "(500,00)" como negativo;
 *  - txt() nunca devolve "[object Object]" (célula de fórmula com erro → "");
 *  - pareceIndice() reconhece numeração/hierarquia ("1,1.1,2,4,5"), não só 1,2,3;
 *  - confiança HONESTA: sem cabeçalho → baixa + aviso (força mapeamento manual).
 *  - NUNCA inventa código SINAPI.
 * ===================================================================== */
(function (global) {
  "use strict";

  /* v1.2.83 — "fonte"/"banco" SAÍRAM dos sinônimos de código e viraram papel
     próprio. Na planilha real de um cliente (Dois Córregos) o cabeçalho era
     Item · Fonte · Código · Descrição…: a coluna "Fonte" (SINAPI/vazio) era
     tomada como CÓDIGO e a coluna "Código" de verdade ficava sem papel — os
     189 itens entravam sem código, inclusive os 60 que eram SINAPI legítimos.
     "item" também ganhou papel (numeração hierárquica), para o código da
     etapa (3.1, 9.2) não se perder. */
  var HDR = {
    codigo: ["codigo", "cod", "referencia", "ref", "codigo sinapi", "cod sinapi", "item sinapi", "codigo do servico", "codigo da composicao", "code"],
    fonte: ["fonte", "banco", "base", "tabela", "origem", "banco de dados", "fonte de preco", "referencia de preco"],
    item: ["item", "n", "no", "num", "numero", "ordem", "seq"],
    descricao: ["descricao", "servico", "servicos", "discriminacao", "descriminacao", "especificacao", "atividade", "insumo", "composicao", "descricao dos servicos", "descricao do servico", "description", "service"],
    unidade: ["un", "und", "unid", "unidade", "medida", "um"],
    quantidade: ["qtd", "qtde", "quant", "quantidade", "qty", "quantity"],
    custoUnit: ["unitario", "unit", "preco unit", "preco unitario", "valor unit", "valor unitario", "custo unit", "custo unitario", "p unit", "punit", "vlr unit", "r$ unit", "unit price", "unit cost", "price"],
    custoTotal: ["total", "valor total", "custo total", "preco total", "vlr total", "subtotal", "amount"]
  };
  /* Nomes de banco de preço que uma coluna "Fonte" costuma trazer. Serve para
     DEDUZIR o papel fonte pelo conteúdo quando o cabeçalho não diz. */
  var FONTES_CONHECIDAS = ["sinapi", "sicro", "sudecap", "seinfra", "setop", "orse", "iopes", "cpos", "cdhu", "fde", "emop", "sbc", "siurb", "agetop", "goinfra", "sedop", "cehop", "deinfra", "der", "propria", "proprio", "cotacao", "composicao propria", "mercado"];
  var UNID = { "m2": 1, "m²": 1, "m3": 1, "m³": 1, "m": 1, "ml": 1, "kg": 1, "un": 1, "und": 1, "unid": 1, "pc": 1, "vb": 1, "cj": 1, "l": 1, "t": 1, "h": 1, "dia": 1, "mes": 1, "gl": 1, "pt": 1, "cx": 1, "par": 1, "km": 1, "ha": 1 };
  var UNID_NORM = { "m2": "m²", "m²": "m²", "m3": "m³", "m³": "m³", "und": "un", "unid": "un", "ml": "m" };
  /* v1.1.234 — as grafias de total que apareciam em planilha REAL e passavam:
     "SUB-TOTAL" (a norm troca o hífen por espaço → "sub total"), "TOTAL:",
     "VALOR TOTAL", "CUSTO TOTAL DA OBRA". Cada uma virava ITEM com o valor do
     subtotal — a obra somava em DOBRO. */
  var TOTAL_KW = ["total", "subtotal", "sub total", "total geral", "totais", "valor total",
                  "custo total", "custo total da obra", "valor global", "bdi", "resumo"];

  // minúsculo, sem acento, SEM pontuação (. - _ / viram espaço) → casa "Quant."/"P. Unit"/"Un."
  function norm(s) {
    s = String(s == null ? "" : s).toLowerCase();
    try { s = s.normalize("NFD").replace(/[̀-ͯ]/g, ""); } catch (e) {}
    return s.replace(/[.\-_/:]+/g, " ").replace(/\s+/g, " ").trim(); // ":" idem — "TOTAL:" é total (v1.1.234)
  }
  var HDR_N = {}; (function () { for (var r in HDR) { HDR_N[r] = HDR[r].map(function (x) { return norm(x); }); } })();

  // valor primitivo; célula de fórmula com erro ({result:{error}}) → "" (nunca "[object Object]")
  function txt(v) {
    if (v == null) return "";
    if (typeof v === "object") {
      if (v.result != null) return typeof v.result === "object" ? "" : String(v.result);
      if (v.text != null) return String(v.text);
      if (v.richText) return v.richText.map(function (t) { return t.text; }).join("");
      if (v.hyperlink != null && v.text != null) return String(v.text);
      return "";
    }
    return String(v);
  }

  // Número. dotMode: 'mil'(ponto=milhar) | 'dec'(ponto=decimal) | undefined(heurística BR).
  // BR (1.234,56), US (1,234.56) e parênteses contábeis "(500,00)" = negativo.
  function num(v, dotMode) {
    if (typeof v === "number") return isFinite(v) ? v : NaN;
    if (v && typeof v === "object") return (v.result != null && typeof v.result !== "object") ? num(v.result, dotMode) : NaN;
    if (v == null) return NaN;
    var raw = String(v);
    // negativo SÓ quando o '-' é o prefixo do número (após R$/espaço) ou tudo entre parênteses;
    // hífen interno ("87-495", "100 - 200", "1-1/2") NÃO é negativo.
    var neg = /\(\s*[\d.,]+\s*\)/.test(raw) || /^\s*(r\$)?\s*-\s*[\d.,]/i.test(raw);
    var s = raw.replace(/[^\d.,]/g, "");
    if (!s) return NaN;
    var hasC = s.indexOf(",") > -1, hasD = s.indexOf(".") > -1;
    if (hasC && hasD) { if (s.lastIndexOf(",") > s.lastIndexOf(".")) s = s.replace(/\./g, "").replace(",", "."); else s = s.replace(/,/g, ""); }
    else if (hasC) { var pc = s.split(","); s = pc.slice(0, -1).join("") + "." + pc[pc.length - 1]; }
    else if (hasD) {
      var pd = s.split(".");
      if (pd.length > 2) s = (dotMode === "dec") ? (pd.slice(0, -1).join("") + "." + pd[pd.length - 1]) : pd.join("");  // 2+ pontos sem vírgula = milhar: 1.234.567 → 1234567 (US só se dotMode='dec')
      else if (pd[1] && pd[1].length === 3) {
        // ambíguo (1 ponto, 3 díg): "1.234" (milhar BR) vs "0.750" (decimal) → dotMode/heurística decide.
        if (dotMode === "dec") { /* decimal: mantém */ }
        else if (dotMode === "mil" && pd[0] !== "0" && pd[0] !== "") s = pd.join("");  // guard de zero-à-esquerda também no 'mil': 0.750→0,75 (não 750)
        else if (dotMode !== "mil" && pd[0] !== "0" && pd[0] !== "") s = pd.join("");
      }
      // fração de 1-2 dígitos (10.5 / 12.34) → SEMPRE decimal (não ambíguo); dotMode não interfere.
    }
    var n = parseFloat(s);
    if (isNaN(n)) return NaN;
    return neg ? -Math.abs(n) : n;
  }
  function ehCodSinapi(v) { var s = txt(v).trim(); return /^\d{5,8}$/.test(s) ? s : null; }
  /* v1.2.83 — CÓDIGO DE QUALQUER BASE, não só SINAPI. Até aqui `ehCodSinapi`
     era o único reconhecedor, e a planilha do cliente com CPOS (02.06.020),
     FDE/Sabesp (C.04.000.064086) ou SBC (003247) perdia TODOS os códigos —
     o agente orçamentista não tinha por onde casar. Regras:
       · hierarquia de etapa/item (1, 1.1, 3.2.1) NÃO é código;
       · decimal curto (52,42 · 12.5) é quantidade, não código;
       · 1–2 dígitos puros é numeração, não código;
       · o resto (dígitos ≥3, ou com letra/separador) é código CRU — quem diz
         de que base ele é, é a coluna Fonte ou o orçamentista (js/orcamentista.js).
     `pesoCodigo` gradua a certeza para a DETECÇÃO de coluna: 5–8 dígitos ou
     formato com separador/letra pesam 1; 3–4 dígitos puros pesam 0,35 (pode
     ser quantidade inteira — a coluna de quantidade continua ganhando). */
  var RE_HIER = /^\d{1,2}(\.\d{1,2}){0,3}\.?$/;
  function ehCodigo(v) {
    var s = txt(v).trim();
    if (/^\d+\.0+$/.test(s)) s = s.replace(/\.0+$/, "");         // célula numérica: 101567.0
    if (!s || s.length > 24 || /\s/.test(s) || !/\d/.test(s)) return null;
    if (RE_HIER.test(s)) return null;
    if (/^\d{1,2}$/.test(s)) return null;
    if (/^\d+[.,]\d{1,2}$/.test(s)) return null;                 // 52,42 · 12.5 → quantidade
    if (/^\d{1,3}\.\d{3}$/.test(s)) return null;                 // 1.234 / 0.750 → número
    if (/^[\d.,]+$/.test(s) && /,/.test(s)) return null;        // vírgula = número BR
    return s;
  }
  function pesoCodigo(v) {
    var s = ehCodigo(v); if (!s) return 0;
    if (/^\d{5,8}$/.test(s)) return 1;
    if (/^\d+\.\d{3,4}$/.test(s)) return 0.2;                    // 4114.620: pode ser CPOS mal digitado OU quantidade
    if (/[A-Za-z]/.test(s) || /[.\-\/]/.test(s)) return 1;
    return 0.35;
  }
  /* Normaliza o código cru: tira ".0" de célula numérica, espaços, e conserta
     o CPOS digitado sem os pontos certos (4114.620 → 41.14.620, 411.0.112 →
     41.10.112): 7 dígitos com ponto em posição errada é sempre CPOS. Não
     inventa dígito — só reposiciona separador. */
  function normCodigo(s) {
    s = String(s == null ? "" : s).trim().replace(/\s+/g, "");
    if (/^\d+\.0+$/.test(s)) s = s.replace(/\.0+$/, "");
    if (/\./.test(s) && /^[\d.]+$/.test(s)) {
      var dig = s.replace(/\./g, "");
      if (dig.length === 7 && !/^\d{2}\.\d{2}\.\d{3}$/.test(s)) s = dig.slice(0, 2) + "." + dig.slice(2, 4) + "." + dig.slice(4);
    }
    return s;
  }
  function ehFonteConhecida(v) { var k = norm(v); return !!k && FONTES_CONHECIDAS.indexOf(k) > -1; }
  function ehUnid(v) { return !!UNID[norm(v)]; }
  function normUnid(v) { var k = norm(v); return UNID_NORM[k] || (UNID[k] ? k : txt(v).trim()); }
  function ehMoeda(v) { var t = txt(v); return /r\$/i.test(t) || (/\d/.test(t) && /[.,]\d{2}\b/.test(t) && !ehUnid(v)); }
  function ehNum(v) { return !isNaN(num(v)); }

  // coluna de numeração/hierarquia: maioria ^\d+(\.\d+)*$ e (tem N.N OU inteiro crescente passo ~1)
  function pareceIndice(vals) {
    var strs = vals.map(function (v) { return txt(v).trim(); }).filter(function (s) { return s !== ""; });
    if (strs.length < 3) return false;
    if (strs.filter(function (s) { return /^\d+(\.\d+)*$/.test(s); }).length / strs.length < 0.8) return false;
    var comPonto = strs.filter(function (s) { return s.indexOf(".") > -1; });
    if (comPonto.length) {
      // distingue HIERARQUIA (1,1.1,2,2.1 ou 1.1,1.2,1.3) de DECIMAIS (1.5,2.5,3.75 = quantidade):
      if (comPonto.length < strs.length) return true;                          // mistura inteiro+pontuado = hierarquia
      var lid = comPonto.map(function (s) { return s.split(".")[0]; }), repete = false;
      for (var j = 1; j < lid.length; j++) if (lid.indexOf(lid[j]) !== j) repete = true;
      return repete;                                                           // mesmo líder = hierarquia; líderes distintos = decimal
    }
    var ns = strs.map(function (s) { return parseInt(s, 10); }).filter(function (n) { return !isNaN(n); });
    if (ns.length < 3 || ns[0] > 2) return false;                              // numeração começa em 0/1/2
    for (var i = 1; i < ns.length; i++) if (ns[i] < ns[i - 1]) return false;   // monotônica (lacuna ok: 1,2,4,5)
    return true;
  }

  function achaHdr(h) {
    if (!h) return null;
    var words = h.split(" ");
    for (var role in HDR_N) {
      var syn = HDR_N[role];
      for (var k = 0; k < syn.length; k++) {
        var sy = syn[k];
        if (h === sy) return role;
        if (sy.indexOf(" ") > -1) { if (h.indexOf(sy) > -1) return role; }
        else if (words.indexOf(sy) > -1) return role;
      }
    }
    return null;
  }
  function acharCabecalho(linhas, nCols) {
    var melhor = -1, melhorScore = 1, lim = Math.min(linhas.length, 15);
    for (var i = 0; i < lim; i++) {
      var sc = 0;
      for (var c = 0; c < nCols; c++) { var h = norm(txt(linhas[i][c])); if (h && achaHdr(h)) sc++; }
      if (sc > melhorScore) { melhorScore = sc; melhor = i; }
    }
    return melhor;
  }

  // valor com EXATAMENTE 2 casas decimais (cara de preço R$)
  function ehDois(v) { var m = txt(v).match(/[.,](\d+)\s*$/); return m ? m[1].length === 2 : false; }
  function fracDois(vals) { var n = 0, ok = 0; vals.forEach(function (v) { if (txt(v).trim() === "") return; n++; if (ehDois(v)) ok++; }); return n ? ok / n : 0; }
  // Acha (qtd, unit, total) pela RELAÇÃO total ≈ qtd×unit entre colunas numéricas livres — robusto
  // p/ planilha SEM cabeçalho (não depende de magnitude, que troca qtd↔custo em material barato).
  // Só devolve se conseguir desambiguar qtd×unit (preço = mais casas-de-2-decimais); senão null
  // (deixa o magnitude/reorder decidir). Preserva o comportamento do ops nos casos que ele já cobre.
  function acharPorRelacao(stat, usado) {
    var cand = stat.filter(function (s) { return !usado(s.c) && s.f.numero > 0.6 && s.f.cod < 0.3 && !pareceIndice(s.vals); });
    if (cand.length < 3) return null;
    for (var ci = 0; ci < cand.length; ci++) {
      var C = cand[ci];
      for (var ai = 0; ai < cand.length; ai++) {
        if (ai === ci) continue;
        for (var bi = ai + 1; bi < cand.length; bi++) {
          if (bi === ci) continue;
          var A = cand[ai], B = cand[bi], nr = Math.min(A.vals.length, B.vals.length, C.vals.length), tot = 0, hit = 0;
          for (var r = 0; r < nr; r++) {
            var av = num(A.vals[r]), bv = num(B.vals[r]), cv = num(C.vals[r]);
            if (!(av > 0 && bv > 0 && cv > 0)) continue; tot++;
            if (Math.abs(av * bv - cv) <= Math.max(0.02, cv * 0.02)) hit++;
          }
          if (tot >= 3 && hit / tot >= 0.6) {
            var fa = fracDois(A.vals), fb = fracDois(B.vals);
            if (Math.abs(fa - fb) > 0.15) { var u = fa > fb ? A : B, q = fa > fb ? B : A; return { total: C.c, unit: u.c, qtd: q.c }; }
            return null; // relação achada, mas qtd×unit ambíguos → magnitude/reorder decide
          }
        }
      }
    }
    return null;
  }

  function detectarColunas(linhas, headerIdx, nCols) {
    var roles = { codigo: null, fonte: null, item: null, descricao: null, unidade: null, quantidade: null, custoUnit: null, custoTotal: null }, fonte = {};
    var hdr = headerIdx >= 0 ? linhas[headerIdx] : null;
    var sample = [], start = headerIdx >= 0 ? headerIdx + 1 : 0;
    for (var i = start; i < linhas.length && sample.length < 50; i++) sample.push(linhas[i]);
    var stat = [];
    for (var c = 0; c < nCols; c++) {
      var vals = sample.map(function (r) { return r[c]; }).filter(function (v) { return txt(v).trim() !== ""; });
      var n = vals.length || 1, cod = 0, unid = 0, moeda = 0, numero = 0, texto = 0, totLen = 0, fonteK = 0;
      vals.forEach(function (v) {
        var s = txt(v).trim();
        cod += pesoCodigo(v);
        if (ehUnid(v)) unid++;
        if (ehMoeda(v)) moeda++;
        if (ehNum(v)) numero++;
        if (ehFonteConhecida(v)) fonteK++;
        if (s && isNaN(num(v)) && !ehUnid(v)) { texto++; totLen += s.length; }
      });
      stat.push({ c: c, h: hdr ? norm(txt(hdr[c])) : "", n: n, vals: vals,
        f: { cod: cod / n, unid: unid / n, moeda: moeda / n, numero: numero / n, texto: texto / n, fonteK: fonteK / n }, avgLen: texto ? totLen / texto : 0 });
    }
    function usado(c) { for (var r in roles) if (roles[r] === c) return true; return false; }
    /* 1) cabeçalho manda — mas cabeçalho REPETIDO se resolve pelo conteúdo.
       v1.2.83 — a tabela sintética da prefeitura (SBC) traz "Serviço" e
       "Descrição do Serviço" lado a lado: as duas casam `descricao`, a
       primeira (que é o CÓDIGO) ficava com o papel e a descrição de verdade
       virava quantidade. Agora cada papel recebe a coluna cujo conteúdo
       mais parece com ele; a que sobra cai na dedução por conteúdo. */
    var reiv = {};
    stat.forEach(function (s) { var role = achaHdr(s.h); if (role) (reiv[role] = reiv[role] || []).push(s); });
    var afinidade = {
      codigo: function (s) { return s.f.cod; }, fonte: function (s) { return s.f.fonteK + s.f.texto * 0.1; }, item: function (s) { return pareceIndice(s.vals) ? 1 : 0; },
      descricao: function (s) { return s.f.texto + Math.min(1, s.avgLen / 40); }, unidade: function (s) { return s.f.unid; },
      quantidade: function (s) { return s.f.numero; }, custoUnit: function (s) { return s.f.moeda + s.f.numero * 0.5; }, custoTotal: function (s) { return s.f.moeda + s.f.numero * 0.5; }
    };
    for (var role in reiv) {
      var cands = reiv[role].filter(function (s) { return !usado(s.c); });
      if (!cands.length) continue;
      if (cands.length > 1) cands.sort(function (a, b) { return afinidade[role](b) - afinidade[role](a); });
      roles[role] = cands[0].c; fonte[role] = "cabecalho";
      /* a coluna preterida de "descricao" que é cheia de código vira código (caso SBC) */
      for (var k = 1; k < cands.length; k++) {
        if (role === "descricao" && roles.codigo == null && cands[k].f.cod >= 0.5) { roles.codigo = cands[k].c; fonte.codigo = "cabecalho"; }
      }
    }
    function assign(role, scorer, min) { if (roles[role] != null) return; var best = null, bs = 0; stat.forEach(function (s) { if (usado(s.c)) return; var v = scorer(s); if (v > bs) { bs = v; best = s; } }); if (best && bs >= (min || 0.5)) { roles[role] = best.c; fonte[role] = "conteudo"; } }
    assign("fonte", function (s) { return s.f.fonteK; }, 0.3);
    assign("codigo", function (s) { return s.f.cod; }, 0.5);
    assign("unidade", function (s) { return s.f.unid; }, 0.4);
    assign("item", function (s) { return (s.f.cod < 0.3 && pareceIndice(s.vals)) ? 1 : 0; }, 0.5);
    // 2a) RELAÇÃO total≈qtd×unit — só se NENHUM dos 3 papéis veio do cabeçalho (evita o swap por magnitude
    // em planilha de material sem cabeçalho: preço baixo × qtd grande faria soma(qtd)>soma(unit)).
    if (roles.quantidade == null && roles.custoUnit == null && roles.custoTotal == null) {
      var rel = acharPorRelacao(stat, usado);
      if (rel) { roles.custoTotal = rel.total; roles.custoUnit = rel.unit; roles.quantidade = rel.qtd; fonte.custoTotal = fonte.custoUnit = fonte.quantidade = "relacao"; }
    }
    // 2b) CUSTOS por MAGNITUDE (fix do ops f8ca422 — preservado): maior soma = total, 2ª = unit.
    var moedaCols = stat.filter(function (s) { return !usado(s.c) && s.f.moeda >= 0.4; });
    moedaCols.forEach(function (s) { s._soma = s.vals.reduce(function (a, v) { var x = num(v); return a + (isFinite(x) && x > 0 ? x : 0); }, 0); });
    moedaCols.sort(function (a, b) { return b._soma - a._soma; });
    // há uma 3ª coluna numérica de valor além das 2 de moeda? (indica que existe TOTAL de verdade)
    var terceiraNum = moedaCols.length >= 2 && stat.some(function (s) { return !usado(s.c) && s.c !== moedaCols[0].c && s.c !== moedaCols[1].c && s.f.numero > 0.6 && s.f.cod < 0.4 && !pareceIndice(s.vals); });
    if (roles.custoTotal == null && roles.custoUnit == null && roles.quantidade == null && moedaCols.length === 2 && !terceiraNum) {
      // 2 colunas de valor SEM total → qtd + unit (layout comum cód/desc/un/qtd/preço), NÃO unit+total.
      // unit = mais casas-de-2-decimais (preço tem centavos consistentes); empate → posição (qtd à esquerda).
      var esq = moedaCols[0].c < moedaCols[1].c ? moedaCols[0] : moedaCols[1], dir = esq === moedaCols[0] ? moedaCols[1] : moedaCols[0];
      var fe = fracDois(esq.vals), fd = fracDois(dir.vals), uC, qC;
      if (Math.abs(fe - fd) > 0.15) { uC = fe > fd ? esq : dir; qC = fe > fd ? dir : esq; } else { qC = esq; uC = dir; }
      roles.quantidade = qC.c; fonte.quantidade = "conteudo";
      roles.custoUnit = uC.c; fonte.custoUnit = "conteudo";
    } else if (roles.custoTotal == null && roles.custoUnit == null && moedaCols.length >= 2) {
      roles.custoTotal = moedaCols[0].c; fonte.custoTotal = "conteudo";
      roles.custoUnit = moedaCols[1].c; fonte.custoUnit = "conteudo";
    } else {
      if (roles.custoUnit == null && moedaCols.length) { var mu = moedaCols[moedaCols.length - 1]; if (mu.c !== roles.custoTotal) { roles.custoUnit = mu.c; fonte.custoUnit = "conteudo"; } }
      if (roles.custoTotal == null && moedaCols.length) { var mt = moedaCols[0]; if (mt.c !== roles.custoUnit) { roles.custoTotal = mt.c; fonte.custoTotal = "conteudo"; } }
    }
    // 3) QUANTIDADE — DEPOIS dos custos: coluna numérica restante (pode ter centavos), não código/índice.
    //    (correção adversarial: a coluna de quantidade com centavos NÃO é mais roubada pelo custo.)
    assign("quantidade", function (s) { return (s.f.numero > 0.5 && s.f.cod < 0.4 && !pareceIndice(s.vals)) ? s.f.numero : 0; }, 0.4);
    if (roles.descricao == null) { var bD = null, bl = 0; stat.forEach(function (s) { if (usado(s.c)) return; if (s.f.texto >= 0.4 && s.avgLen > bl) { bl = s.avgLen; bD = s; } }); if (bD) { roles.descricao = bD.c; fonte.descricao = "conteudo"; } }
    roles._fonte = fonte;
    return roles;
  }

  function ehTotal(desc) { var nd = norm(desc); if (!nd) return false; for (var i = 0; i < TOTAL_KW.length; i++) { if (nd === TOTAL_KW[i] || nd.indexOf(TOTAL_KW[i] + " ") === 0) return true; } return false; }
  // Linha-de-etapa com nº hierárquico + NOME no MESMO campo (ex.: "1.0 Serviços preliminares"
  // na coluna "Item"), sem coluna de descrição/código própria — comum em export analítico.
  // Retorna { codigo, nome } ou null. Exige LETRA no nome (não confunde com número/moeda) e
  // ignora se o texto for um total/subtotal.
  function etapaEmbutida(row) {
    if (!row) return null;
    for (var c = 0; c < row.length; c++) {
      var s = txt(row[c]).trim();
      var m = /^(\d{1,3}(?:\.\d{1,3}){0,3})\.?\s+(.+\S)$/.exec(s);
      if (m && /[A-Za-zÀ-ÿ]/.test(m[2]) && !ehTotal(m[2])) return { codigo: m[1], nome: m[2].trim() };
    }
    return null;
  }
  function classificar(row, cols) {
    var desc = cols.descricao != null ? txt(row[cols.descricao]).trim() : "";
    if (ehTotal(desc)) return "ignorar";
    var temCod = cols.codigo != null && !!ehCodigo(row[cols.codigo]);
    var temQtd = cols.quantidade != null && num(row[cols.quantidade]) > 0;
    var temUnit = cols.custoUnit != null && num(row[cols.custoUnit]) > 0;
    var temTot = cols.custoTotal != null && num(row[cols.custoTotal]) > 0;
    /* v1.1.234 — linha de ETAPA que carrega o subtotal do grupo: descrição sem
       código, sem quantidade e sem unitário, SÓ com o total. Virava "item
       fantasma" de R$ 0 e roubava o lugar da etapa — a estrutura inteira do
       orçamento importado se perdia, e o subtotal ainda arriscava dupla soma.
       ⚠ SÓ vale quando a planilha TEM colunas de qtd/unitário e a linha as
       deixou vazias — na planilha de verba (Descrição + Total apenas), toda
       linha é assim e todas são ITENS, não etapas. */
    var planTemDetalhe = cols.quantidade != null || cols.custoUnit != null;
    if (desc && !temCod && !temQtd && !temUnit && temTot && planTemDetalhe) return "etapa";
    // item real precisa de descrição OU código (linha só-com-valor-perdido não vira item fantasma)
    if ((desc || temCod) && (temCod || temUnit || temTot || temQtd)) return "item";
    if (desc) return "etapa";                    // etapa clássica: nome na coluna de descrição
    if (etapaEmbutida(row)) return "etapa";      // etapa "1.0 Nome" embutida na coluna "Item" (caso Luiz)
    return "ignorar";
  }
  function codigoEtapaDe(row, cols) {
    /* v1.2.83 — a numeração da etapa mora na coluna "Item" quando ela existe
       (3.0, 3.1, 9.2); só na falta dela cai na coluna de código. */
    var cs = [cols.item, cols.codigo];
    for (var k = 0; k < cs.length; k++) {
      if (cs[k] == null) continue;
      var s = txt(row[cs[k]]).trim();
      if (/^\d{1,2}(\.\d{1,2})*\.?$/.test(s) && !ehCodigo(row[cs[k]])) return s.replace(/\.$/, "");
    }
    return "";
  }
  function numeroItemDe(row, cols) {
    if (cols.item == null) return "";
    var s = txt(row[cols.item]).trim();
    return /^\d{1,3}(\.\d{1,3})*\.?$/.test(s) ? s.replace(/\.$/, "") : "";
  }
  // 'mil' se a coluna usa vírgula decimal (ponto=milhar); 'dec' se só pontos (ponto=decimal, ex.: 0.750)
  function dotModeCol(linhas, start, col) {
    if (col == null) return undefined;
    var vir = false, pon = false;
    for (var i = start; i < linhas.length; i++) { var s = txt(linhas[i][col]); if (s.indexOf(",") > -1) vir = true; else if (s.indexOf(".") > -1) pon = true; }
    return vir ? "mil" : (pon ? "dec" : undefined);
  }

  var Importador = {
    /* Abas de um workbook do SheetJS → [{nome, matriz}], de A1 até a ÚLTIMA
     * CÉLULA QUE EXISTE — não até a dimensão gravada no arquivo.
     * ⚠ A DIMENSÃO GRAVADA MENTE: uma planilha completa real, de outro programa de orçamento, escreve
     *   <dimension ref="A1:A94"> numa aba que vai até a coluna J. Confiando
     *   nela, o SheetJS entregava UMA coluna — item sem código, sem banco, sem
     *   preço, e a planilha "não reconhecida". Começar em A1 mantém cada
     *   coluna no índice dela. Puro: o XLSX vem de quem chama (no app,
     *   js/vendor/xlsx.full.min.js; no teste, o mesmo arquivo). */
    abasDoSheetJS: function (XLSX, wb) {
      return ((wb && wb.SheetNames) || []).map(function (nm) {
        var ws = wb.Sheets[nm] || {}, maxR = -1, maxC = -1;
        for (var k in ws) {
          if (!Object.prototype.hasOwnProperty.call(ws, k) || k.charAt(0) === "!") continue;
          var c = XLSX.utils.decode_cell(k);
          if (c.r > maxR) maxR = c.r;
          if (c.c > maxC) maxC = c.c;
        }
        if (maxR < 0) return { nome: String(nm), matriz: [] };
        return { nome: String(nm), matriz: XLSX.utils.sheet_to_json(ws, { header: 1, blankrows: true, defval: "", range: { s: { r: 0, c: 0 }, e: { r: maxR, c: maxC } } }) };
      }).filter(function (a) { return a.matriz.length; });
    },

    _num: num, _txt: txt, _norm: norm, _ehCodSinapi: ehCodSinapi, _ehCodigo: ehCodigo, _normCodigo: normCodigo, _ehMoeda: ehMoeda, _pareceIndice: pareceIndice, _detectarColunas: detectarColunas, _acharCabecalho: acharCabecalho, _etapaEmbutida: etapaEmbutida,
    ROLES: ["codigo", "fonte", "item", "descricao", "unidade", "quantidade", "custoUnit", "custoTotal"],

    /* v1.2.83 — METADADOS DO CABEÇALHO DA TABELA. A planilha oficial de uma
       base (ex.: composição sintética da prefeitura) diz nas primeiras linhas
       "Data Base: MAIO/26" e "Custo Unitário com BDI 20,81%". Quem importa
       essa tabela como base precisa saber os dois: a competência (para não
       misturar mês) e, principalmente, se o PREÇO JÁ TEM BDI — aplicar BDI
       de novo em cima é orçar com BDI dobrado. Devolve { competencia:"2026-05",
       bdiIncluso: 20.81 } (null quando não encontra). Nunca inventa. */
    metaCabecalho: function (matriz) {
      var out = { competencia: null, bdiIncluso: null, rotulo: "" };
      var MESES = { jan: "01", fev: "02", mar: "03", abr: "04", mai: "05", jun: "06", jul: "07", ago: "08", set: "09", out: "10", nov: "11", dez: "12" };
      var lim = Math.min((matriz || []).length, 15);
      for (var i = 0; i < lim; i++) {
        var row = matriz[i] || [];
        for (var c = 0; c < row.length; c++) {
          var s = txt(row[c]).trim(); if (!s) continue;
          var ns = norm(s);
          if (!out.rotulo && /composicao|tabela|referencia|boletim/.test(ns) && s.length > 12) out.rotulo = s.slice(0, 120);
          var mb = ns.match(/(?:data ?base|competencia|referencia|mes)(?:\s+de|\s+da|\s+do)?\s+([a-z]{3})[a-z]*\s*(\d{2,4})\b/);
          if (mb && MESES[mb[1]] && !out.competencia) { var ano = mb[2].length === 2 ? "20" + mb[2] : mb[2]; out.competencia = ano + "-" + MESES[mb[1]]; }
          var mn = ns.match(/(?:data ?base|competencia|referencia)\D{0,12}(\d{2})\s*[\/ ]\s*(\d{4})/);
          if (mn && !out.competencia) out.competencia = mn[2] + "-" + mn[1];
          var mbdi = s.match(/com\s+bdi\s*(?:de)?\s*(\d{1,2}(?:[.,]\d{1,2})?)\s*%/i);
          if (mbdi && out.bdiIncluso == null) out.bdiIncluso = parseFloat(mbdi[1].replace(",", "."));
          if (/sem\s+bdi/i.test(s) && out.bdiIncluso == null) out.bdiIncluso = 0;
        }
      }
      return out;
    },

    analisar: function (matriz, opts) {
      opts = opts || {};
      var avisos = [];
      var linhas = (matriz || []).filter(function (r) { return r && r.some(function (c) { return txt(c).trim() !== ""; }); });
      if (!linhas.length) return { erro: "vazia", etapas: [], colunas: {}, confianca: 0, avisos: ["Planilha sem dados legíveis."], resumo: { etapas: 0, itens: 0, ignoradas: 0 } };
      var nCols = 0; linhas.forEach(function (r) { if (r.length > nCols) nCols = r.length; });
      var headerIdx = opts.headerRow != null ? opts.headerRow : acharCabecalho(linhas, nCols);
      var cols = opts.colunas || detectarColunas(linhas, headerIdx, nCols);
      var fonte = cols._fonte || {};
      if (cols.descricao == null) avisos.push("Não identifiquei a coluna de descrição — ajuste no mapeamento.");
      if (cols.quantidade == null && cols.custoUnit == null && cols.custoTotal == null) avisos.push("Não identifiquei quantidade nem valores — ajuste no mapeamento.");

      var start = headerIdx >= 0 ? headerIdx + 1 : 0;
      var dmQ = dotModeCol(linhas, start, cols.quantidade), dmU = dotModeCol(linhas, start, cols.custoUnit), dmT = dotModeCol(linhas, start, cols.custoTotal);
      var etapas = [], atual = null, nItens = 0, nEtapas = 0, nIgn = 0, semQtd = 0, semCusto = 0;
      for (var i = start; i < linhas.length; i++) {
        var row = linhas[i], cls = classificar(row, cols);
        if (cls === "ignorar") { nIgn++; continue; }
        var desc = cols.descricao != null ? txt(row[cols.descricao]).trim() : "";
        if (cls === "etapa") { var _emb = desc ? null : etapaEmbutida(row); atual = { nome: desc || (_emb && _emb.nome) || ("Etapa " + (nEtapas + 1)), codigo: codigoEtapaDe(row, cols) || (_emb && _emb.codigo) || "", itens: [] }; etapas.push(atual); nEtapas++; continue; }
        if (!atual) { atual = { nome: "Serviços", codigo: "", itens: [] }; etapas.push(atual); nEtapas++; }
        var qtd = cols.quantidade != null ? num(row[cols.quantidade], dmQ) : NaN;
        var unit = cols.custoUnit != null ? num(row[cols.custoUnit], dmU) : NaN;
        var tot = cols.custoTotal != null ? num(row[cols.custoTotal], dmT) : NaN;
        if (!(unit > 0) && tot > 0 && qtd > 0) unit = tot / qtd;
        if (!(qtd > 0) && tot > 0 && unit > 0) qtd = tot / unit;
        /* v1.1.234 — planilha só com Descrição + Valor Total (orçamento por
           verba, comum em proposta de terceiro): sem esta linha, TODOS os
           itens importavam a R$ 0,00 e o valor da obra sumia. Item de verba:
           quantidade 1, unitário = o total. */
        if (!(unit > 0) && tot > 0 && !(qtd > 0)) { qtd = 1; unit = tot; }
        if (!(qtd > 0)) { qtd = 1; semQtd++; }
        if (!(unit >= 0) || isNaN(unit)) unit = 0;
        if (!(unit > 0)) semCusto++;
        var codCru = cols.codigo != null ? (ehCodigo(row[cols.codigo]) || "") : "";
        var fonteLinha = cols.fonte != null ? txt(row[cols.fonte]).trim().toUpperCase() : "";
        var itemNovo = {
          codigo: codCru ? normCodigo(codCru) : "",
          descricao: desc || "(sem descrição)",
          unidade: cols.unidade != null ? normUnid(row[cols.unidade]) : "un",
          quantidade: Math.round(qtd * 10000) / 10000,
          custoUnitario: Math.round(unit * 100) / 100
        };
        /* v1.2.83 — o que a planilha DIZ sobre a origem viaja com o item: a
           coluna Fonte (SINAPI/CPOS/…), o número do item (9.2.14) e o código
           como veio escrito (antes da normalização). É a matéria-prima do
           orçamentista — sem isso ele teria de adivinhar a base. */
        if (fonteLinha) itemNovo.fonte = fonteLinha;
        if (codCru && itemNovo.codigo !== codCru) itemNovo.codigoOriginal = codCru;
        var numItem = numeroItemDe(row, cols); if (numItem) itemNovo.numero = numItem;
        atual.itens.push(itemNovo);
        nItens++;
      }
      /* v1.2.83 — HIERARQUIA: "3.0 FUNDAÇÃO E ESTRUTURA" seguida de "3.1
         FUNDAÇÃO" e "3.2 ESTRUTURA". A etapa-mãe não tem item (só título) e
         era descartada abaixo; a filha entrava solta e a estrutura da planilha
         se perdia. Cada etapa com código de 2+ níveis carrega o nome da mãe
         (`pai`) — quem monta o orçamento decide se vira sub etapa. */
      for (var ei = 0; ei < etapas.length; ei++) {
        var cod = String(etapas[ei].codigo || ""), partes = cod.split(".").filter(function (p) { return p !== ""; });
        if (partes.length < 2) continue;
        var prefixo = partes.slice(0, -1).join(".");
        for (var pj = ei - 1; pj >= 0; pj--) {
          var cp = String(etapas[pj].codigo || "").replace(/\.0+$/, "");
          if (cp === prefixo || cp === prefixo + ".0") { etapas[ei].pai = etapas[pj].nome; etapas[ei].paiCodigo = etapas[pj].codigo; break; }
        }
      }
      etapas = etapas.filter(function (e) { return e.itens.length; });

      // confiança HONESTA — reflete a qualidade da detecção (não só "preencheu os slots")
      var conf = 0;
      if (cols.descricao != null) conf += 0.35;
      if (cols.quantidade != null) conf += 0.2;
      if (cols.custoUnit != null || cols.custoTotal != null) conf += 0.2;
      if (cols.codigo != null) conf += 0.1;
      if (nItens > 0) conf += 0.15;
      var porConteudo = ["descricao", "quantidade", "custoUnit", "custoTotal"].filter(function (r) { return cols[r] != null && fonte[r] === "conteudo"; }).length;
      if (headerIdx < 0) { conf *= 0.55; avisos.push("Não reconheci uma linha de cabeçalho — deduzi as colunas pelo conteúdo. ⚠️ Revise o mapeamento antes de importar."); }
      else if (porConteudo > 0) { conf *= 0.82; avisos.push("Algumas colunas foram deduzidas pelo conteúdo (cabeçalho parcial) — confira o mapeamento."); }
      if (!nItens) avisos.push("Nenhum item reconhecido — confira o mapeamento das colunas.");
      if (semCusto && nItens) avisos.push(semCusto + " item(ns) sem custo na planilha — o Orçamentista casa o código/descrição nas bases escolhidas e precifica; o que não casar fica pendente ou vira composição própria.");

      return {
        etapas: etapas, colunas: cols, headerRow: headerIdx,
        confianca: Math.round(Math.min(1, conf) * 100) / 100,
        resumo: { etapas: etapas.length, itens: nItens, ignoradas: nIgn, semQtd: semQtd, semCusto: semCusto },
        avisos: avisos
      };
    }
  };

  global.Importador = Importador;
  if (typeof module !== "undefined" && module.exports) module.exports = Importador;
})(typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this));
