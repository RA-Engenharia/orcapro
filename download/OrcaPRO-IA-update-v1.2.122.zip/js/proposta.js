/* =====================================================================
 * proposta.js — Gerador de Proposta Comercial (impressão/PDF via navegador)
 * Sem dependência externa: monta HTML pronto p/ "Imprimir → Salvar PDF".
 * Identidade RA Engenharia (navy/aço), marca d'água nas internas, placeholders.
 * Conteúdo conforme padrão A.7: capa, apresentação, escopo, incluso/excluso,
 * premissas, metodologia, resumo financeiro, condições, responsabilidades,
 * garantias, assinatura.
 * ===================================================================== */
(function (global) {
  "use strict";

  var Proposta = {

    /* Botão [GERAR PROPOSTA] só habilita se passar nesta validação. */
    validar: function (orc) {
      var faltando = [];
      if (!orc.cliente || !Util.naoVazio(orc.cliente.nome)) faltando.push("Cliente vinculado");
      var totais = Orcamento.totais(orc);
      if (totais.qtdItens < 1) faltando.push("Ao menos 1 item no escopo");
      // ZERO não é preço: orçamento com item sem custo não vira proposta —
      // o usuário cota (planilha ou detalhamento do insumo) e preenche antes.
      var semPreco = Orcamento.itensSemPreco ? Orcamento.itensSemPreco(orc) : [];
      if (semPreco.length) {
        faltando.push("Preço em " + semPreco.length + " item(ns): " +
          semPreco.slice(0, 3).map(function (i) { return i.numero + (i.codigo ? " (" + i.codigo + ")" : ""); }).join(", ") +
          (semPreco.length > 3 ? "…" : ""));
      }
      /* v1.1.232 — QUANTIDADE PENDENTE bloqueia igual ao preco zerado. O item
         trazido sem metragem (fluxo do memorial) passava por aqui valendo R$ 0:
         a proposta saia com o servico LISTADO no escopo e valendo nada — o
         cliente aceitava um preco que nao continha aquele servico. */
      var semQtd = Orcamento.itensSemQuantidade ? Orcamento.itensSemQuantidade(orc) : [];
      if (semQtd.length) {
        faltando.push("Quantidade em " + semQtd.length + " item(ns): " +
          semQtd.slice(0, 3).map(function (x) { return (x.item.codigo || x.item.descricao.slice(0, 18)); }).join(", ") +
          (semQtd.length > 3 ? "…" : "") + " — use o botao Calcular na linha");
      }
      /* ⚠ TUDO OPCIONAL = PROPOSTA DE R$ 0,00 (revisão de 13/09/2026). Desde
         que o papel imprime o escopo contratado (`_totalDoPapel`), marcar como
         adicional opcional TODAS as etapas com valor fazia a capa sair com
         "Valor total R$ 0,00", o resumo com "VALOR TOTAL DA PROPOSTA R$ 0,00 ·
         100%" e o WhatsApp sem a linha de valor — e `validar` dizia ok. Pelo
         fluxo do app (addEtapa → addItem → marcarEtapaOpcional nas duas).
         Recusa com o caminho: não há proposta sem escopo contratado. */
      var temOpcV = Util.arr(orc.etapas).some(function (e) { return e && e.opcional; });
      var semEscopo = temOpcV && totais.qtdItens >= 1 && !(Util.num(totais.precoObrigatorio) > 0) && Util.num(totais.precoOpcional) > 0;
      if (semEscopo) {
        faltando.push("Escopo contratado: todas as etapas com valor estão marcadas como adicional opcional, e a proposta sairia com valor total R$ 0,00 — desmarque “opcional” nas etapas que fazem parte do serviço contratado");
      }
      Orcamento.garantirComercial(orc);
      if (!Util.naoVazio(orc.comercial.condicoesPagamento)) faltando.push("Condições de pagamento");
      var r = { ok: faltando.length === 0, faltando: faltando };
      /* o caminho dessa pendência é a planilha, não "⚙ Dados" (ver app.js gerarProposta) */
      if (semEscopo) r.escopoTodoOpcional = true;
      return r;
    },

    /* Converte texto multilinha em <li> (cada linha = um item). */
    _lista: function (txt) {
      return String(txt || "").split(/\r?\n/).filter(function (l) { return l.trim(); })
        .map(function (l) { return "<li>" + Util.esc(l.trim().replace(/;$/, "")) + "</li>"; }).join("");
    },

    /* Campo de texto "1 item por linha" com rótulo em negrito: UMA linha sai
       como o parágrafo de sempre ("<b>Premissas:</b> texto"); várias, como
       lista. Todo texto passa por Util.esc (o campo pode ter vindo da IA). */
    _paragrafoOuLista: function (rotulo, txt) {
      var linhas = String(txt || "").split(/\r?\n/).filter(function (l) { return l.trim(); });
      if (linhas.length <= 1) return '<p><b>' + Util.esc(rotulo) + '</b> ' + Util.esc(String(linhas[0] || "").trim()) + '</p>';
      return '<p><b>' + Util.esc(rotulo) + '</b></p><ul>' + this._lista(txt) + '</ul>';
    },

    /* =================================================================
       AS PREMISSAS DE PRAZO A CARGO DO CONTRATANTE (planejador 3A, D1)

       A tarefa sem preço com `resp:"cliente"` e a caixa "Mostrar na proposta"
       marcada (`proposta:true`) é uma obrigação DELE que segura o nosso
       prazo: aprovação de projeto, liberação de área, escolha de acabamento.

       ⚠ POR QUE ELA VAI NA PROPOSTA, E POR QUE SÓ ELA. O prazo que o cliente
         assina já conta com esses dias. Se a aprovação atrasa duas semanas, a
         obra atrasa duas semanas — e sem esta tabela a conversa vira "a
         construtora estourou o prazo". A tarefa da CONSTRUTORA (resp
         "construtora") não entra: ela é problema nosso, e listá-la na
         proposta seria entregar o nosso planejamento interno.

       ⚠ O GANTT DA PROPOSTA CONTINUA SEM AS LINHAS T (decisão k2 do desenho
         EXTRAS): o desenho do cliente é limpo — sem folga, sem setas e sem
         caminho crítico —, e uma linha tracejada sem explicação no meio dele
         levanta a pergunta errada. O vão sem barra é explicado por esta
         tabela, em palavras.

       Devolve `[]` quando não há nenhuma: a proposta de quem não usa tarefa
       sem preço não ganha um caractere. */
    premissasDoContratante: function (r) {
      var out = [];
      if (!r || !r.extras || !r.extras.length) return out;
      r.extras.forEach(function (x) {
        if (!x || x.resp !== "cliente" || x.proposta !== true) return;
        out.push({ numero: String(x.numero == null ? "" : x.numero), nome: String(x.nome == null ? "" : x.nome),
          prazoDias: x.marco ? 0 : Util.num(x.duracao), marco: !!x.marco,
          inicio: (x.dataInicio && x.dataInicio.toLocaleDateString) ? x.dataInicio.toLocaleDateString("pt-BR") : "",
          fim: (x.dataFim && x.dataFim.toLocaleDateString) ? x.dataFim.toLocaleDateString("pt-BR") : "" });
      });
      return out;
    },
    FRASE_PREMISSAS: "Atraso nestas premissas desloca o cronograma na mesma medida.",

    /* =================================================================
       O RODAPÉ ‡ DAS FRENTES EM CALENDÁRIO PRÓPRIO (planejador 3A, D10)

       ⚠ O PRAZO DA PROPOSTA CONTINUA EM DIAS ÚTEIS DA OBRA. É a régua em que
         as etapas se somam, é a que está no contrato e é a que a medição usa.
         A frente que trabalha 7×7 tem OUTRA contagem de dias: dizer "12 dias"
         numa etapa que ocupa 9 dias úteis da obra, sem explicar, faz o
         cliente concluir que a conta está errada — e dizer só "9" esconde que
         a equipe vai estar lá no sábado e no domingo.
       Devolve `[]` sem calendário atribuído. */
    rodapeCalendarios: function (r) {
      var C = r && r.calendarios, out = [];
      if (!C || !(C.usados || []).length) return out;
      var porCal = {}, nomes = {}, dias = {};
      (C.lista || []).forEach(function (c) {
        if (!c || c.id == null) return;
        var k = String(c.id), d = 0;
        nomes[k] = String(c.nome || k);
        (c.h || []).forEach(function (h) { if (h > 0) d++; });
        dias[k] = d;
      });
      function junta(no, rotulo) {
        if (!no || !no.calendarioId) return;
        var k = String(no.calendarioId);
        if (!porCal[k]) porCal[k] = [];
        porCal[k].push({ rotulo: rotulo, dias: no.duracaoFrente,
          de: (no.dataInicioFrente && no.dataInicioFrente.toLocaleDateString) ? no.dataInicioFrente.toLocaleDateString("pt-BR") : "",
          ate: (no.dataUltimoDia && no.dataUltimoDia.toLocaleDateString) ? no.dataUltimoDia.toLocaleDateString("pt-BR") : "" });
      }
      (r.etapas || []).forEach(function (e, i) { junta(e, "etapa " + (i + 1)); });
      (C.usados || []).forEach(function (id) {
        var k = String(id), itens = porCal[k] || [];
        if (!itens.length) return;
        out.push({ id: k, nome: nomes[k] || k, diasPorSemana: dias[k] || 0, frentes: itens });
      });
      return out;
    },
    _rodapeCalHTML: function (r) {
      var lista = this.rodapeCalendarios(r);
      if (!lista.length) return "";
      var linhas = lista.map(function (c) {
        return '<b>‡ ' + Util.esc(c.nome) + '</b>' + (c.diasPorSemana ? ' — ' + c.diasPorSemana + ' dia' + (c.diasPorSemana === 1 ? '' : 's') + ' por semana' : '') + ': ' +
          c.frentes.map(function (f) {
            return Util.esc(f.rotulo) + ' (' + (f.dias != null ? f.dias + ' dia' + (f.dias === 1 ? '' : 's') + ' de trabalho' : '') +
              (f.de && f.ate ? ', de ' + Util.esc(f.de) + ' a ' + Util.esc(f.ate) : '') + ')';
          }).join(' · ') + '.';
      }).join('<br>');
      return '<p class="nota"><b>Frentes em regime próprio:</b> os prazos acima estão em <b>dias úteis da obra</b> — ' +
        'é a régua do contrato e da medição. Onde há <b>‡</b>, a frente trabalha no calendário dela:<br>' + linhas + '</p>';
    },
    _premissasHTML: function (r) {
      var lista = this.premissasDoContratante(r);
      if (!lista.length) return "";
      var linhas = lista.map(function (p) {
        return '<tr><td>' + Util.esc(p.numero) + '</td><td>' + Util.esc(p.nome) + '</td>' +
          '<td class="r">' + (p.marco ? 'na data' : p.prazoDias + ' d') + '</td>' +
          '<td class="r">' + Util.esc(p.fim) + '</td></tr>';
      }).join("");
      return '<h3 style="margin:14px 0 6px">Premissas de prazo a cargo do contratante</h3>' +
        '<table class="prop-tbl"><thead><tr><th>Nº</th><th>Premissa</th><th class="r">Prazo</th><th class="r">Até</th></tr></thead>' +
        '<tbody>' + linhas + '</tbody></table>' +
        '<p class="nota"><b>' + Util.esc(this.FRASE_PREMISSAS) + '</b> ' +
        'Estas linhas não têm preço nesta proposta: elas ocupam prazo e dependem do contratante.</p>';
    },

    /* Cronograma para a PROPOSTA: o Gantt em versão de cliente (UI._gantt com
       `limpo`) mais um quadro de etapa/prazo/entrega.

       ⚠ NÃO É O MESMO GRÁFICO DA ABA. Aqui somem folga, setas de precedência e
       caminho crítico: "folga de 3 dias" impressa numa proposta é um convite a
       negociar prazo em cima da reserva que absorve chuva e atraso de material.
       O que o cliente precisa saber é quando cada frente começa e termina.

       ⚠ E NÃO INVENTA CRONOGRAMA. Sem o módulo, sem etapas ou sem UI (o
       documento também é montado fora da tela), devolve vazio e a proposta sai
       como antes — com uma seção a menos, não com um gráfico falso. */
    _cronograma: function (orc) {
      if (typeof Cronograma === "undefined" || !Cronograma.estimar) return "";
      if (typeof UI === "undefined" || !UI._gantt) return "";
      if (!(orc.etapas || []).length) return "";
      var r;
      try { r = Cronograma.estimar(orc); } catch (e) { return ""; }
      if (!r || !r.etapas.length || !r.totalDias) return "";
      var etsOrc = orc.etapas || [];   /* sem Util.arr: esta função também roda com Util mínimo (tools/test-cronopdf.js) */
      var linhas = r.etapas.map(function (e, i) {
        /* a etapa opcional sai MARCADA também no quadro de prazos: é "0 d"
           quando fica fora do prazo, e sem a marca o cliente lê um serviço
           que não dura nada. Casado POR ÍNDICE (`r.etapas` é 1:1 com
           `orc.etapas`, ver Cronograma.estimar) — nunca por nome. */
        return '<tr><td>' + Util.esc(((e.codigo ? e.codigo + " " : "") + (e.nome || "")).trim()) +
          (etsOrc[i] && etsOrc[i].opcional ? ' <i>(adicional opcional)</i>' : '') + '</td>' +
          '<td>' + Util.esc(e.categoriaNome || "") + '</td>' +
          '<td class="r">' + (e.marco ? "marco" : e.duracao + " d") + '</td>' +
          '<td class="r">' + e.dataInicio.toLocaleDateString("pt-BR") + '</td>' +
          '<td class="r">' + e.dataFim.toLocaleDateString("pt-BR") + '</td></tr>';
      }).join("");
      var nFer = ((r.feriados || {}).noPeriodo || []).length;
      var cats = {}, leg = "";
      r.etapas.forEach(function (e) {
        if (cats[e.categoria]) return; cats[e.categoria] = 1;
        leg += '<span style="margin-right:14px;white-space:nowrap"><i style="display:inline-block;width:11px;height:11px;border-radius:3px;background:' +
          Util.esc(e.cor || "#94a3b8") + ';margin-right:5px;vertical-align:-1px"></i>' + Util.esc(e.categoriaNome || e.categoria) + '</span>';
      });
      return '<p>A execução está prevista em <b>' + r.totalDias + ' dias úteis</b> (aproximadamente <b>' +
          r.totalSemanas + ' semanas</b>), com início em <b>' + r.dataInicio.toLocaleDateString("pt-BR") +
          '</b> e conclusão prevista para <b>' + r.dataFim.toLocaleDateString("pt-BR") + '</b>.</p>' +
        UI._gantt(r, { limpo: true }) +
        '<div class="nota" style="margin:6px 0 10px">' + leg + '</div>' +
        '<table class="prop-tbl"><thead><tr><th>Etapa</th><th>Frente</th><th class="r">Prazo</th>' +
        '<th class="r">Início</th><th class="r">Término</th></tr></thead><tbody>' + linhas + '</tbody></table>' +
        /* planejador 3A: as duas seções novas nascem VAZIAS quando o
           orçamento não tem tarefa do contratante nem calendário próprio —
           a proposta de sempre sai byte a byte igual */
        this._premissasHTML(r) +
        this._desembolso(orc, r) +
        /* ⚠ Esta é a data que o cliente lê como PROMESSA. A frase acompanha o
           que o cálculo fez de verdade: com o desconto ligado diz quantos
           feriados saíram; desligado, avisa que a data ainda vai se deslocar. */
        '<p class="nota">Prazos em dias úteis (' + (r.params.diasUteisSemana || 5) + ' dias por semana), contados a partir da ' +
        'liberação da obra' +
        (r.params.descontarFeriados === false
          ? ' e <b>sem desconto de feriados</b>'
          : (nFer ? ', já descontados <b>' + nFer + ' feriado' + (nFer === 1 ? '' : 's') + '</b> do período' : ', com os feriados nacionais descontados')) +
        '. O cronograma pode ser reajustado em função de ' +
        'condições climáticas, liberação de frentes de serviço e fornecimento de materiais.</p>' +
        this._rodapeCalHTML(r);
    },

    /* Cronograma físico-financeiro: quanto sai por mês, seguindo o Gantt.
       ⚠ Este é o número que o cliente leva para o financeiro dele. Ele SÓ pode
       sair da duração real de cada etapa — a régua antiga do app fatiava o
       valor pela ordem das etapas e punha dinheiro em mês sem serviço. Sem
       Gantt calculável, a seção some: melhor não ter do que ter errado. */
    _desembolso: function (orc, r) {
      if (typeof Cronograma === "undefined" || !Cronograma.periodos) return "";
      var sint, per;
      try {
        sint = Orcamento.sintetico(orc);
        if (!sint || sint.length !== r.etapas.length) return "";
        var vmap = {};
        r.etapas.forEach(function (e, i) { vmap[e.id] = sint[i].precoVenda || 0; });
        per = Cronograma.periodos(r, { valores: vmap });
      } catch (e) { return ""; }
      if (!per || !per.lista.length || !per.total) return "";
      var linhas = per.lista.map(function (p) {
        return '<tr><td>' + Util.esc(p.rotulo) + '</td>' +
          '<td class="r">' + Util.fmtMoeda(p.valor) + '</td>' +
          '<td class="r">' + Util.fmtPct(p.pct, 1) + '</td>' +
          '<td class="r">' + Util.fmtPct(p.acumPct, 1) + '</td></tr>';
      }).join("");
      /* ⚠ A CURVA CONTINUA COM OS ADICIONAIS DENTRO (mudar a distribuição de
         quem já recebeu proposta é decisão pendente — ver
         `cronogramaParaModelo`), mas agora o TOTAL dela não fica calado ao
         lado de um "Valor total" menor: a mesma frase que o modelo imprime
         (js/proptpl.js, `tabelaCronograma`). Sem etapa opcional, nada. */
      var notaOpc = "";
      try {
        var TP = _totalDoPapel(orc, Orcamento.totais(orc));
        if (TP.adicionais > 0) {
          notaOpc = '<p class="nota">Este cronograma de desembolso inclui os <b>adicionais opcionais</b> (' +
            Util.fmtMoeda(TP.adicionais) + '). Sem eles, o valor total da proposta é <b>' + Util.fmtMoeda(TP.total) + '</b>.</p>';
        }
      } catch (eO) { notaOpc = ""; }
      return '<h3 style="margin-top:16px">Cronograma físico-financeiro</h3>' +
        '<table class="prop-tbl"><thead><tr><th>Mês</th><th class="r">Previsão de desembolso</th>' +
        '<th class="r">% do mês</th><th class="r">% acumulado</th></tr></thead><tbody>' + linhas + '</tbody>' +
        '<tfoot><tr><td>TOTAL</td><td class="r">' + Util.fmtMoeda(per.total) + '</td>' +
        '<td class="r">100,0%</td><td class="r"></td></tr></tfoot></table>' +
        '<p class="nota">Distribuição estimada a partir da duração de cada etapa no cronograma acima. ' +
        'A medição e o faturamento seguem as condições comerciais desta proposta.</p>' + notaOpc;
    },

    /* Gera o documento completo (innerHTML do container de impressão). */
    gerarHTML: function (orc, usuario) {
      var c = Orcamento.garantirComercial(orc);
      var t = Orcamento.totais(orc);
      var sint = Orcamento.sintetico(orc);
      var marca = CONFIG.marca;
      var emp = (typeof Empresa !== "undefined") ? Empresa.dados() : null;
      // White-label: o documento é da EMPRESA DO CLIENTE — nunca cai no fabricante.
      var empresa = (emp && emp.nome) || (usuario && usuario.empresa) || "Sua Empresa";
      var logoHTML = (typeof Empresa !== "undefined") ? Empresa.logoHTML(80) : '<div class="logo-ph">[LOGO ' + Util.esc(empresa) + ']</div>';
      var hoje = new Date().toLocaleDateString("pt-BR");
      function hoje2ISO() { return Util.agoraISO(); }

      /* ⚠ O "VALOR TOTAL" DESTE PAPEL É O DO ESCOPO CONTRATADO — ver
         `_totalDoPapel`. As etapas opcionais saem SEPARADAS (escopo, resumo)
         e rotuladas como adicionais; sem nenhuma, `sintObr` é o `sint`
         inteiro, o peso é o de sempre e o documento sai byte a byte igual. */
      var TP = _totalDoPapel(orc, t);
      var sintObr = TP.temOpc ? sint.filter(function (s) { return !s.opcional; }) : sint;
      var sintOpc = TP.temOpc ? sint.filter(function (s) { return s.opcional; }) : [];
      var linhasSint = sintObr.map(function (s) {
        /* peso sobre o total QUE A FOLHA IMPRIME: com adicional, `s.peso` é
           sobre o total com opcionais e a coluna não fecharia 100% */
        var peso = TP.temOpc ? (TP.total > 0 ? (Util.num(s.precoVenda) / TP.total) * 100 : 0) : s.peso;
        return '<tr><td>' + Util.esc(s.codigo) + '</td><td>' + Util.esc(s.nome) + '</td>' +
          '<td class="r">' + Util.fmtMoeda(s.precoVenda) + '</td>' +
          '<td class="r">' + Util.fmtPct(peso, 1) + '</td></tr>';
      }).join("");

      var apresentacao = Util.naoVazio(c.apresentacao) ? Util.esc(c.apresentacao) :
        'A <b>' + Util.esc(empresa) + '</b> atua em projetos e execução de obras de engenharia e ' +
        'arquitetura, comprometida com qualidade técnica, transparência e cumprimento de prazos. ' +
        'Apresentamos a seguir nossa proposta para o empreendimento em referência.';

      // ---- Páginas ----
      var P = [];
      /* Numeração das seções por CONTADOR, não por número escrito à mão: o
         Cronograma só entra quando há cronograma para mostrar, e com número
         fixo a proposta pularia do "4." para o "6." na cara do cliente. */
      var nSec = 0;
      function sc(titulo) { nSec++; return nSec + ". " + titulo; }

      // 1) CAPA
      P.push(
        '<section class="pg capa">' +
          '<div class="capa-top">' + logoHTML + '</div>' +
          '<div class="capa-mid">' +
            '<div class="kicker">PROPOSTA COMERCIAL</div>' +
            '<h1>' + Util.esc(orc.nome) + '</h1>' +
            '<div class="capa-obra">' + Util.esc(orc.obra && orc.obra.nome ? orc.obra.nome : "Obra a definir") + '</div>' +
          '</div>' +
          '<div class="capa-info">' +
            row("Cliente", orc.cliente.nome) +
            row("Proposta nº", orc.numero) +
            row("Data", hoje) +
            /* a data vence a frase: "15 dias corridos" não diz ao cliente
               até quando ele pode aceitar (ver Proposta.validade) */
            row("Validade", (function () { var v = Proposta.validade(orc, hoje2ISO()); return v.temData ? v.texto.replace(/^Válida até /, "") : v.frase; })()) +
            /* ⚠ A CAPA É A PÁGINA QUE O CLIENTE DECORA. Ela imprimia
               `precoVenda` (adicionais DENTRO) enquanto o resto do papel os
               excluía — ver o roteiro no Resumo Financeiro. A linha dos
               adicionais vem ANTES do "Valor total" de propósito: o CSS da
               capa (`.ci-row:last-child b`) destaca a última linha, e o
               destaque é do valor contratado. */
            (TP.adicionais > 0 ? rowRaw("Adicionais opcionais", Util.fmtMoeda(TP.adicionais) +
              ' <span style="font-weight:400;font-size:9pt">(não incluídos no valor total)</span>') : '') +
            rowRaw("Valor total", '<b style="color:var(--p-verde)">' + Util.fmtMoeda(TP.total) + '</b>') +
          '</div>' +
          '<div class="capa-rod">' + Util.esc(empresa) +
            (emp && Util.naoVazio(emp.cnpj) ? ' · CNPJ ' + Util.esc(emp.cnpj) : '') +
            (emp && Util.naoVazio(emp.endereco) ? ' · ' + Util.esc(emp.endereco) : (emp && Util.naoVazio(emp.cidade) ? ' · ' + Util.esc(emp.cidade) : '')) +
            ((typeof Empresa !== "undefined" && Empresa.creditoTexto && Empresa.creditoTexto()) ? ' · ' + Util.esc(Empresa.creditoTexto()) : '') + '</div>' +
        '</section>');

      // 2) APRESENTAÇÃO
      P.push(pg(sc("Apresentação"), '<p>' + apresentacao + '</p>' +
        '<p>Esta proposta foi elaborada com base nas informações disponibilizadas e em composições de ' +
        'custos referenciadas ' + (Orcamento.basesUsadas(orc).length > 1 ? 'nas bases de preços' : 'na base de preços') + ' <b>' + Util.esc(Orcamento.basesUsadasTexto(orc)) + '</b>, ' +
        'acrescidas de BDI de <b>' + Util.fmtPct(t.bdiPercentual) + '</b>.</p>'));

      // 3) ENTENDIMENTO DO ESCOPO
      function liEscopo(s) { return '<li><b>' + Util.esc(s.codigo) + '</b> — ' + Util.esc(s.nome) + ' (' + s.qtdItens + ' itens)</li>'; }
      var escopoLi = sintObr.map(liEscopo).join("");
      var escopoOpcLi = sintOpc.map(liEscopo).join("");
      /* "contempla as seguintes etapas" com a opcional na lista é a proposta
         dizendo que o escopo a inclui — e três seções depois, que não */
      P.push(pg(sc("Entendimento do Escopo"),
        '<p>O escopo dos serviços contempla as seguintes etapas:</p><ul>' + (escopoLi || '<li>—</li>') + '</ul>' +
        (escopoOpcLi ? '<p>Orçadas à parte, como <b>adicionais opcionais</b> (não incluídas no valor total):</p><ul>' + escopoOpcLi + '</ul>' : '')));

      // 4) INCLUSO / EXCLUSO
      P.push(pg(sc("Está Incluso / Não Está Incluso"),
        '<div class="cols"><div><h3>' + (typeof Icones !== 'undefined' ? Icones.get('check', 15) : '') + ' Incluso</h3><ul>' + this._lista(c.incluso) + '</ul></div>' +
        '<div><h3>' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + ' Não incluso</h3><ul>' + this._lista(c.excluso) + '</ul></div></div>'));

      // 5) PREMISSAS E METODOLOGIA
      /* ⚠ CAMPO VAZIO = O TEXTO FIXO DE SEMPRE, BYTE A BYTE. `premissas`,
         `metodologia`, `respContratada` e `respContratante` viraram campos do
         orçamento (editáveis à mão e pela IA — js/iaedit.js). Os literais
         abaixo NÃO podem ser mexidos nem "unificados" com
         Orcamento.TEXTOS_PADRAO_PROPOSTA: é por eles que a proposta de todo
         orçamento que já existe sai idêntica à do master b8907ef
         (tools/test-proposta-campos-texto.js compara as duas no mesmo relógio).
         Preenchido: uma linha sai como parágrafo; várias, como lista. */
      P.push(pg(sc("Premissas e Metodologia"),
        (Util.naoVazio(c.premissas) ? this._paragrafoOuLista("Premissas:", c.premissas) :
        '<p><b>Premissas:</b> condições normais de trabalho e acesso à obra; fornecimento de água e energia ' +
        'pelo contratante durante a execução; quantitativos sujeitos a confirmação em projeto executivo.</p>') +
        (Util.naoVazio(c.metodologia) ? this._paragrafoOuLista("Metodologia:", c.metodologia) :
        '<p><b>Metodologia:</b> execução por etapas com medição mensal, controle de qualidade e ' +
        'acompanhamento técnico responsável, seguindo normas técnicas vigentes (ABNT).</p>') +
        '<p><b>' + (Orcamento.basesUsadas(orc).length > 1 ? 'Bases de preços:' : 'Base de preços:') + '</b> ' + Util.esc(Orcamento.basesUsadasTexto(orc)) +
        ', regime <b>' + Util.esc(Orcamento.regimeDe ? Orcamento.regimeDe(orc) : (orc.desonerado ? 'desonerado' : 'onerado')) + '</b>, ' +
        'BDI conforme metodologia do Acórdão TCU nº 2.622/2013.</p>'));

      // 5b) CRONOGRAMA DE EXECUÇÃO (só quando há como calcular)
      var cronoHTML = this._cronograma(orc);
      if (cronoHTML) P.push(pg(sc("Cronograma de Execução"), cronoHTML));

      /* ⚠ O VALOR TOTAL NÃO SOMA O QUE A PROPOSTA DECLARA NÃO INCLUSO
         (consertado em 13/09/2026 — era a "divergência conhecida" de 11/09).
         Roteiro do defeito: a proposta CLÁSSICA (esta) listava a etapa
         marcada como opcional como linha normal do Resumo Financeiro e
         fechava a capa e o "VALOR TOTAL DA PROPOSTA" com `precoVenda` —
         adicionais DENTRO —, enquanto a proposta POR MODELO
         (`blocosParaModelo` + js/proptpl.js) já imprimia `precoObrigatorio`
         com os adicionais num bloco à parte, e o próprio botão que marca a
         etapa promete "sai fora do valor total" (js/app.js, data-opc-etapa).
         Numa obra de demonstração montada de ponta a ponta (galpão, 16
         etapas, 13 a 16 opcionais) a capa e o resumo disseram R$ 534.516,58
         e a seção "Não incluso" da MESMA proposta excluía as etapas
         opcionais: o contrato era R$ 504.501,10. O cliente decora a capa.
         O decidido: o total impresso é o do escopo contratado
         (`precoObrigatorio`); os adicionais saem numa tabela própria, com o
         subtotal deles e a frase "não incluídos". O "Custo direto de
         referência" acompanha — com o custo dos adicionais dentro ele não
         seria a referência DAQUELE total.
         ⚠ SEM ETAPA OPCIONAL, NADA MUDA: `_totalDoPapel` devolve o próprio
         `precoVenda` (e não o `precoObrigatorio`, que é arredondado a 2 casas
         e no modo "nenhum" poderia virar 1 centavo no papel) —
         tools/test-proposta-total-opcional.js compara com o master byte a
         byte. */
      var custoRef = t.custoDireto;
      if (TP.temOpc) {
        try { custoRef = Math.round((Util.num(t.custoDireto) - Util.num(Orcamento.calcular(orc).custoOpcional)) * 100) / 100; }
        catch (eCR) { custoRef = t.custoDireto; }
      }
      var tabOpc = "";
      if (sintOpc.length) {
        tabOpc = '<h3 style="margin-top:16px">Adicionais opcionais</h3>' +
          '<p class="nota">Etapas orçadas à parte, <b>não incluídas no valor total acima</b>.</p>' +
          '<table class="prop-tbl"><thead><tr><th>Etapa</th><th>Descrição</th><th class="r">Valor</th></tr></thead><tbody>' +
          sintOpc.map(function (s) {
            return '<tr><td>' + Util.esc(s.codigo) + '</td><td>' + Util.esc(s.nome) + '</td>' +
              '<td class="r">' + Util.fmtMoeda(s.precoVenda) + '</td></tr>';
          }).join("") + '</tbody>' +
          '<tfoot><tr><td colspan="2">TOTAL DOS ADICIONAIS OPCIONAIS</td><td class="r">' + Util.fmtMoeda(TP.adicionais) + '</td></tr></tfoot></table>';
      }
      // 6) RESUMO FINANCEIRO
      P.push(pg(sc("Resumo Financeiro"),
        '<table class="prop-tbl"><thead><tr><th>Etapa</th><th>Descrição</th><th class="r">Valor</th><th class="r">Peso</th></tr></thead>' +
        '<tbody>' + (linhasSint || '<tr><td colspan="4">—</td></tr>') + '</tbody>' +
        '<tfoot><tr><td colspan="2">VALOR TOTAL DA PROPOSTA</td><td class="r">' + Util.fmtMoeda(TP.total) + '</td><td class="r">100%</td></tr></tfoot></table>' +
        tabOpc +
        '<p class="nota">Valores com BDI de ' + Util.fmtPct(t.bdiPercentual) + ' incluso. Custo direto de referência: ' + Util.fmtMoeda(custoRef) + '.</p>'));

      // 7) CONDIÇÕES COMERCIAIS
      P.push(pg(sc("Condições Comerciais"),
        bloco("Forma de pagamento", c.condicoesPagamento) +
        bloco("Prazo de execução", c.prazoExecucao) +
        bloco("Validade da proposta", c.validadeProposta)));

      // 8) RESPONSABILIDADES — ⚠ vazio = os literais de sempre (ver seção 5)
      P.push(pg(sc("Responsabilidades"),
        '<div class="cols"><div><h3>Contratada</h3><ul>' +
          (Util.naoVazio(c.respContratada) ? this._lista(c.respContratada) :
          '<li>Execução dos serviços conforme escopo e normas técnicas;</li>' +
          '<li>Fornecimento de mão de obra e EPIs da equipe;</li>' +
          '<li>Responsável técnico com ART/RRT.</li>') + '</ul></div>' +
        '<div><h3>Contratante</h3><ul>' +
          (Util.naoVazio(c.respContratante) ? this._lista(c.respContratante) :
          '<li>Liberação da obra e acessos;</li>' +
          '<li>Fornecimento de água e energia;</li>' +
          '<li>Aprovação de projetos e licenças.</li>') + '</ul></div></div>'));

      // 9) GARANTIAS
      P.push(pg(sc("Garantias"), '<p>' + Util.esc(c.garantia) + '</p>'));

      // 10) ASSINATURA
      P.push(pg(sc("Aceite e Assinatura"),
        '<p>Declaramos estar de acordo com os termos, valores e condições desta proposta comercial.</p>' +
        '<div class="assinaturas">' +
          '<div class="assin"><div class="linha-assin"></div>' + Util.esc(empresa) + '<br><span>Contratada</span></div>' +
          '<div class="assin"><div class="linha-assin"></div>' + Util.esc(orc.cliente.nome) + '<br><span>Contratante</span></div>' +
        '</div>' +
        '<p class="nota mt">' + Util.esc(orc.obra && orc.obra.local ? orc.obra.local : "Local") + ', ' + hoje + '.</p>'));

      return P.join("");
    }
  };

  function row(k, v) { return '<div class="ci-row"><span>' + Util.esc(k) + '</span><b>' + Util.esc(v) + '</b></div>'; }
  function rowRaw(k, v) { return '<div class="ci-row"><span>' + Util.esc(k) + '</span><b>' + v + '</b></div>'; }
  function bloco(titulo, txt) { return '<div class="bloco"><h3>' + Util.esc(titulo) + '</h3><p>' + Util.esc(txt) + '</p></div>'; }

  /* =====================================================================
   * O TOTAL QUE VAI PARA O CLIENTE — uma regra para todo papel deste arquivo
   *
   * ⚠ `precoVenda` INCLUI AS ETAPAS OPCIONAIS (js/orcamento.js, `calcular`:
   *   "etapa opcional é separação de papel, não de conta"). O número que o
   *   cliente lê como preço é o do escopo contratado, `precoObrigatorio`; os
   *   adicionais são `precoOpcional`, impressos à parte. Capa, resumo,
   *   desembolso e WhatsApp perguntam AQUI — o defeito de 13/09/2026 foi
   *   justamente um consumidor (a capa) ficar para trás quando o corpo
   *   passou a separar.
   * ⚠ SEM ETAPA OPCIONAL DEVOLVE O PRÓPRIO `precoVenda`, não o
   *   `precoObrigatorio`: este sai arredondado a 2 casas por diferença e, no
   *   arredondamento "nenhum", pode diferir de `precoVenda` no terceiro
   *   decimal — o que mudaria um centavo em papel já entregue.
   * ⚠ "Tem opcional" é a MARCA na etapa (o que `calcular` também lê), não o
   *   valor: etapa opcional ainda vazia continua sendo opcional.
   * ===================================================================== */
  function _totalDoPapel(orc, t) {
    t = t || {};
    var ets = (orc && Array.isArray(orc.etapas)) ? orc.etapas : [];
    var temOpc = ets.filter(function (e) { return e && e.opcional; }).length > 0;
    if (!temOpc) return { temOpc: false, total: t.precoVenda, adicionais: 0 };
    return {
      temOpc: true,
      total: Util.num(t.precoObrigatorio != null ? t.precoObrigatorio : t.precoVenda),
      adicionais: Util.num(t.precoOpcional)
    };
  }
  function pg(titulo, corpo) {
    // White-label: marca d'água e rodapé são da EMPRESA DO CLIENTE (configurável em ⚙ Empresa)
    var temEmp = typeof Empresa !== "undefined";
    var wm = temEmp && Empresa.marcaDaguaTexto ? Empresa.marcaDaguaTexto() : "";
    var rod = (temEmp && Empresa.nomeDoc && Empresa.nomeDoc()) || "";
    var cred = temEmp && Empresa.creditoTexto ? Empresa.creditoTexto() : "";
    if (cred) rod = rod ? rod + " · " + cred : cred;
    return '<section class="pg interna">' + (wm ? '<div class="wm">' + Util.esc(wm) + '</div>' : '') +
      '<h2 class="pg-tit">' + Util.esc(titulo) + '</h2>' + corpo +
      (rod ? '<div class="pg-rod">' + Util.esc(rod) + '</div>' : '') + '</section>';
  }


  /* =====================================================================
   * O ORÇAMENTO ALIMENTANDO O MODELO DE PROPOSTA
   *
   * "Modelos de Proposta" nasceu para a carpintaria e só era lido por ela:
   * quem monta orçamento SINAPI desenhava o modelo, dava um nome, e ele nunca
   * aparecia na hora de gerar. Aqui o orçamento passa a montar o MESMO
   * contrato de dados que `carpintariaui.js` monta — o motor não muda.
   *
   * ⚠ O QUE VAI PARA O PAPEL É PREÇO DE VENDA, NUNCA CUSTO. Cada linha
   *   calculada carrega `precoTotal` (com BDI, é o que o cliente paga) ao
   *   lado de `custoTotal` (a conta interna). Trocar um pelo outro entrega a
   *   margem da empresa dentro do documento comercial dela. Aqui só
   *   `precoUnit`/`precoTotal` atravessam, e `auditar` abaixo é a segunda
   *   trava — a primeira é esta função nunca ler o campo errado.
   *
   * ⚠ E O MOTOR NÃO SOMA. `total` vem de `Orcamento.totais()` (o
   *   `precoObrigatorio`; ver `blocosParaModelo` e `_totalDoPapel`), a
   *   mesma conta da tela, do Excel e do laudo. Somar de novo aqui criaria um
   *   quarto número para a mesma pergunta — e é o do papel que o cliente
   *   confere.
   *
   * ⚠ OS GRUPOS SÃO AS ETAPAS. É a estrutura que o orçamento realmente tem;
   *   o par "Material / Mão de obra" da carpintaria não descreve uma obra por
   *   etapas. Item solto (sem etapa) cai num grupo sem nome, que o motor
   *   desenha sem cabeçalho.
   * =================================================================== */
  /* =====================================================================
   * O CICLO COMERCIAL DA PROPOSTA — enviada, aceita, recusada
   *
   * POR QUE EXISTE. O app sabia dizer se o GESTOR aprovou o orçamento, e não
   * sabia dizer se ele foi ao CLIENTE. `propostaEm` estava no schema desde o
   * começo — é até apagado ao copiar e ao revisar, para a cópia não nascer
   * "já enviada" — mas nenhuma linha do sistema gravava. O painel, sem esse
   * dado, media conversão pela aprovação interna (ver `indicadoresCarteira`).
   *
   * ⚠ FUNÇÕES PURAS: recebem `quando` por parâmetro e devolvem o orçamento
   *   alterado, sem gravar. Quem grava é a tela — do contrário não dá para
   *   testar fora do navegador.
   * ⚠ O HISTÓRICO É APPEND-ONLY. "Reenviei dia 20 porque o cliente pediu
   *   outra versão" é informação de venda; sobrescrever a data anterior
   *   apagaria o tempo de resposta real do cliente.
   * ===================================================================== */
  Proposta.CANAIS = [
    { id: "whatsapp", nome: "WhatsApp" },
    { id: "email", nome: "E-mail" },
    { id: "impresso", nome: "Impressa / em mãos" },
    { id: "reuniao", nome: "Apresentada em reunião" },
    { id: "outro", nome: "Outro" }
  ];
  Proposta.RESPOSTAS = [
    { id: "aceita", nome: "Aceita — fechamos", cor: "#16a34a" },
    { id: "recusada", nome: "Recusada", cor: "#dc2626" },
    { id: "sem_resposta", nome: "Ainda sem resposta", cor: "#ea580c" }
  ];

  Proposta.enviada = function (orc) { return Util.naoVazio(orc && orc.propostaEm); };

  /* rascunho → enviada → aceita | recusada */
  Proposta.estadoComercial = function (orc) {
    if (!Proposta.enviada(orc)) return "rascunho";
    var r = String(((orc && orc.propostaResposta) || {}).estado || "");
    return (r === "aceita" || r === "recusada") ? r : "enviada";
  };

  Proposta.registrarEnvio = function (orc, dados) {
    if (!orc) return null;
    var d = dados || {};
    var quando = String(d.quando || Util.agoraISO());
    orc.propostaEm = quando;
    orc.propostaCanal = String(d.canal || "outro");
    orc.propostaPor = String(d.por || "");
    /* reenviar zera a resposta anterior: a proposta que está com o cliente é
       a nova, e manter "recusada" ali faria o funil contar uma venda perdida
       que já voltou para a mesa */
    if (orc.propostaResposta) delete orc.propostaResposta;
    orc.propostaHistorico = Util.arr(orc.propostaHistorico);
    orc.propostaHistorico.push({ acao: "enviada", em: quando, canal: orc.propostaCanal, por: orc.propostaPor });
    return orc;
  };

  Proposta.registrarResposta = function (orc, dados) {
    if (!orc) return null;
    var d = dados || {};
    var est = String(d.estado || "");
    if (!Proposta.RESPOSTAS.filter(function (r) { return r.id === est; }).length) return null;
    if (!Proposta.enviada(orc)) return null;      /* resposta sem envio não existe */
    var quando = String(d.quando || Util.agoraISO());
    if (est === "sem_resposta") delete orc.propostaResposta;
    else orc.propostaResposta = { estado: est, em: quando, motivo: String(d.motivo || ""), por: String(d.por || "") };
    orc.propostaHistorico = Util.arr(orc.propostaHistorico);
    orc.propostaHistorico.push({ acao: est, em: quando, motivo: String(d.motivo || ""), por: String(d.por || "") });
    return orc;
  };

  /* =====================================================================
   * MANDAR PELO WHATSAPP — o canal em que a proposta realmente vai
   *
   * ⚠ O PDF NÃO VAI NO LINK. `wa.me` abre a conversa com um texto; o arquivo
   *   quem anexa é a pessoa, no aparelho dela. Prometer "envio automático com
   *   anexo" seria mentira — aqui o trabalho que se poupa é achar o contato,
   *   escrever o texto e não errar o valor nem a validade.
   * ⚠ E O NÚMERO É O DO CLIENTE, não o da empresa: sai do cadastro
   *   (`clientes.telefone`) ou do contato digitado no orçamento.
   * ===================================================================== */
  function _soDigitos(v) { return String(v == null ? "" : v).replace(/\D/g, ""); }
  Proposta.telefoneCliente = function (orc, cadastro) {
    var n = _soDigitos((cadastro && (cadastro.telefone || cadastro.celular)) || "");
    if (!n) n = _soDigitos((orc && orc.cliente && orc.cliente.contato) || "");
    if (n.length < 10) return "";
    return n.length <= 11 ? "55" + n : n;
  };

  /* o texto que abre a conversa: quem, o quê, quanto e até quando */
  Proposta.textoWhatsApp = function (orc, empresa, hojeISO) {
    var t = {};
    try { t = Orcamento.totais(orc); } catch (e) {}
    var v = Proposta.validade(orc, hojeISO);
    var quem = Util.naoVazio(orc && orc.cliente && orc.cliente.nome) ? String(orc.cliente.nome).split(/\s+/)[0] : "";
    var linhas = [];
    linhas.push((quem ? "Olá, " + quem + "! " : "Olá! ") + "Segue a nossa proposta"
      + (Util.naoVazio(orc && orc.nome) ? " para " + orc.nome : "") + ".");
    if (Util.naoVazio(orc && orc.numero)) linhas.push("Proposta " + orc.numero + ".");
    /* o valor da mensagem é o MESMO da capa do PDF que vai anexado: com
       adicional, o do escopo contratado, e os adicionais numa linha à parte */
    var TP = _totalDoPapel(orc, t);
    if (TP.total) linhas.push("Valor: " + Util.fmtMoeda(TP.total) + ".");
    /* "fora desse valor" sem linha de valor antes (tudo marcado opcional) era
       uma frase apontando para nada — ali os adicionais vão ditos à parte */
    if (TP.adicionais > 0) linhas.push((TP.total ? "Adicionais opcionais, fora desse valor: " : "Adicionais opcionais, orçados à parte: ") + Util.fmtMoeda(TP.adicionais) + ".");
    if (v.temData) linhas.push(v.texto.replace(/ —.*$/, "") + ".");
    var c = (orc && orc.comercial) || {};
    if (Util.naoVazio(c.prazoExecucao)) linhas.push("Prazo: " + String(c.prazoExecucao).trim().replace(/\.$/, "") + ".");
    linhas.push("O PDF vai anexado aqui. Qualquer dúvida é só chamar.");
    if (empresa && Util.naoVazio(empresa.nome)) linhas.push(String(empresa.nome));
    return linhas.join("\n");
  };

  Proposta.linkWhatsApp = function (numero, texto) {
    var n = _soDigitos(numero);
    if (!n) return "";
    return "https://wa.me/" + n + (texto ? "?text=" + encodeURIComponent(texto) : "");
  };

  /* a cobrança de quem sumiu: mesma conversa, outro assunto */
  Proposta.textoFollowUp = function (orc, hojeISO) {
    var v = Proposta.validade(orc, hojeISO);
    var quem = Util.naoVazio(orc && orc.cliente && orc.cliente.nome) ? String(orc.cliente.nome).split(/\s+/)[0] : "";
    var l = [(quem ? "Olá, " + quem + "! " : "Olá! ") + "Passando para saber se conseguiu ver a proposta"
      + (Util.naoVazio(orc && orc.numero) ? " " + orc.numero : "") + "."];
    if (v.temData && !v.vencida) l.push("Ela vale até " + v.ateBR + ".");
    else if (v.temData && v.vencida) l.push("A validade dela venceu em " + v.ateBR + ", mas consigo revalidar os preços se ainda tiver interesse.");
    l.push("Posso ajustar alguma coisa para facilitar?");
    return l.join("\n");
  };

  /* dias desde o envio, para a tela cobrar quem sumiu */
  Proposta.diasDesdeEnvio = function (orc, hojeISO) {
    if (!Proposta.enviada(orc)) return null;
    var a = new Date(String(orc.propostaEm).slice(0, 10) + "T12:00:00");
    var b = new Date(String(hojeISO || Util.agoraISO()).slice(0, 10) + "T12:00:00");
    if (isNaN(a.getTime()) || isNaN(b.getTime())) return null;
    return Math.round((b - a) / 86400000);
  };

  /* =====================================================================
   * VALIDADE COM DATA — e não só a frase
   *
   * A base de contagem é o dia do ENVIO quando ele existe; antes disso, hoje.
   * É o que faz a data impressa continuar verdadeira depois: uma proposta
   * enviada em 03/09 com 15 dias vence em 18/09, e reimprimi-la em outubro
   * não pode "renovar" o prazo sozinha.
   * ===================================================================== */
  function _somaDias(iso, n) {
    var d = new Date(String(iso).slice(0, 10) + "T12:00:00");
    if (isNaN(d.getTime())) return "";
    d.setDate(d.getDate() + n);
    return d.toISOString().slice(0, 10);
  }
  function _difDias(aISO, bISO) {
    var a = new Date(String(aISO).slice(0, 10) + "T12:00:00");
    var b = new Date(String(bISO).slice(0, 10) + "T12:00:00");
    if (isNaN(a.getTime()) || isNaN(b.getTime())) return null;
    return Math.round((b - a) / 86400000);
  }
  function _br(iso) {
    var s = String(iso || "").slice(0, 10);
    return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s.slice(8, 10) + "/" + s.slice(5, 7) + "/" + s.slice(0, 4) : "";
  }
  Proposta.dataBR = _br;

  Proposta.validade = function (orc, hojeISO) {
    var c = (orc && orc.comercial) || {};
    var hoje = String(hojeISO || Util.agoraISO()).slice(0, 10);
    var dias = Util.num(c.validadeDias);
    var frase = Util.naoVazio(c.validadeProposta) ? String(c.validadeProposta).trim().replace(/\.$/, "") : "";
    if (!(dias > 0)) {
      /* sem o número não há data: devolve a frase e diz que não há data */
      return { temData: false, dias: 0, frase: frase, vencida: false,
        texto: frase ? "Validade desta proposta: " + frase + "." : "" };
    }
    var base = Proposta.enviada(orc) ? String(orc.propostaEm).slice(0, 10) : hoje;
    var ate = _somaDias(base, dias);
    var faltam = _difDias(hoje, ate);
    var vencida = faltam !== null && faltam < 0;
    var texto = "Válida até " + _br(ate)
      + (vencida ? " — VENCIDA"
        : (faltam === 0 ? " — vence hoje"
          : (faltam !== null && faltam <= 3 ? " (vence em " + faltam + " dia" + (faltam === 1 ? "" : "s") + ")" : "")));
    return { temData: true, dias: dias, baseISO: base, ateISO: ate, ateBR: _br(ate),
      faltam: faltam, vencida: vencida, frase: frase, texto: texto };
  };

  /* =====================================================================
   * O CRONOGRAMA QUE VAI PARA O PAPEL
   *
   * ⚠ CALCULADO AQUI, DESENHADO LÁ. `Orcamento.cronograma` é a mesma conta da
   *   aba Cronograma e do Excel; o motor do modelo (js/proptpl.js) tem regra
   *   escrita de não fazer conta de dinheiro. Refazer a distribuição no
   *   desenho criaria um segundo cronograma para a mesma obra — e seria o do
   *   papel que o cliente cobraria.
   * ⚠ SÓ PREÇO DE VENDA: `Orcamento.cronograma` distribui `precoVenda`.
   *
   * ⚠ E `precoVenda` INCLUI AS ETAPAS OPCIONAIS, enquanto o "Valor total" que
   *   o mesmo papel imprime é o `precoObrigatorio` (ver `blocosParaModelo`).
   *   Num orçamento com adicional, a tabela de desembolso somava mais que o
   *   total da folha — medido em 11/09/2026: "Valor total R$ 110,00" e, duas
   *   páginas depois, uma curva de caixa de R$ 220,00, sem nada explicando.
   *   NÃO se mexeu na distribuição (mudar a curva de quem já recebeu proposta
   *   é decisão do Rogério, e está em pendências): o desenho passou a
   *   RECEBER a separação — `opcional` por etapa, `totalOpcional` e
   *   `totalObrigatorio` — e imprime a linha honesta embaixo da tabela.
   *   Sem etapa opcional, `totalOpcional` é 0 e o papel sai igual ao de antes.
   *
   * ⚠ O `opcional` é casado POR ÍNDICE com `orc.etapas`: `Orcamento.cronograma`
   *   monta as linhas a partir de `sintetico(orc)`, que é um `map` sobre
   *   `orc.etapas` (mesma ordem, mesmo tamanho, nos dois ramos da função).
   *   Casar por NOME seria ligar por semelhança — duas etapas com o mesmo nome
   *   marcariam a errada. E não se acrescentou campo no retorno de
   *   `Orcamento.cronograma`: ele é comparado com o do master na régua de
   *   paridade, e campo novo ali vira "diferença" no dia da publicação.
   * ===================================================================== */
  Proposta.cronogramaParaModelo = function (orc, meses) {
    var c;
    /* ⚠ SÓ PASSA O 2º ARGUMENTO QUANDO ALGUÉM PEDIU O NÚMERO — e isto é
     * dinheiro com data (12/09/2026).
     *
     * `Orcamento.cronograma(orc, n)` com `n` preenchido trava o nº de COLUNAS
     * em `n` e ACUMULA na última tudo que passar dela (`estouro`). Sem o
     * argumento, a régua é o próprio Gantt — e a trava manual da pessoa
     * continua valendo, porque a conta lá dentro é
     * `(mesesPedido || orc.cronogramaMesesManual) ? meses : nG`.
     *
     * Passar `orc.cronogramaMeses` aqui parecia inofensivo, e não é: aquele
     * campo é DERIVADO e regravado a cada abertura. Quando ele passou a
     * guardar o prazo da FROTA (a régua que o aparelho na versão anterior
     * enxerga), a tela seguiu desenhando o Gantt certo — 9 colunas, estouro 0 —
     * e a PROPOSTA saiu com 6, empilhando R$ 262.300,00 de maio e junho de 2027
     * numa coluna de março. Medido em 400 orçamentos: 113 de 314 piorariam,
     * pior caso R$ 1.325.731,00 numa coluna que antes tinha R$ 0.
     *
     * É o defeito da memória "conserto que para no segundo consumidor": o
     * engenheiro confere uma tabela e o cliente recebe outra, calado. E o
     * cliente planeja o caixa dele pelo "Mês 6" que leu aqui. */
    try { c = Orcamento.cronograma(orc, meses || undefined); }
    catch (e) { return null; }
    if (!c || !Util.arr(c.etapas).length) return null;
    var etsOrc = Util.arr(orc && orc.etapas);
    var tOpc = 0, tObr = 0;
    try { var tt = Orcamento.totais(orc); tOpc = Util.num(tt.precoOpcional); tObr = Util.num(tt.precoObrigatorio != null ? tt.precoObrigatorio : tt.precoVenda); }
    catch (e2) { tOpc = 0; tObr = Util.num(c.total); }
    /* PLANEJADOR 3A (D1 e D10): as premissas do contratante e o rodapé ‡
       viajam JUNTO com o cronograma, porque é na página de cronograma do
       modelo que eles fazem sentido.
       ⚠ ELES NÃO ENTRAM NA CONTA. `meses`, `total`, `totaisMes`, `acumPct`
         e `etapas` continuam vindo inteiros de `Orcamento.cronograma` — a
         tarefa sem preço não tem valor (D2) e o prazo contratual continua
         sendo o das etapas. Os dois campos abaixo são TEXTO ao lado.
       ⚠ CHAVE NOVA SÓ NASCE COM DADO (a regra I2 da espec, e aqui ela é
         dinheiro): orçamento sem tarefa do contratante e sem calendário
         próprio devolve o payload de hoje, CHAVE POR CHAVE — uma
         `premissas: []` a mais já seria "a proposta de quem não usa a função
         mudou", e este payload é comparado com o do master na paridade. */
    var premissas = [], rodapeCal = [];
    try {
      if (typeof Cronograma !== "undefined" && Cronograma.estimar) {
        var rP = Cronograma.estimar(orc);
        premissas = Proposta.premissasDoContratante(rP);
        rodapeCal = Proposta.rodapeCalendarios(rP);
      }
    } catch (e3) { premissas = []; rodapeCal = []; }
    var saida = {
      meses: c.meses,
      total: Util.num(c.total),
      /* o que a tabela está somando (`total`) × o que a folha fecha (`totalObrigatorio`) */
      totalOpcional: tOpc,
      totalObrigatorio: tObr,
      totaisMes: Util.arr(c.totaisMes).map(function (v) { return Util.num(v); }),
      acumPct: Util.arr(c.acumPct).map(function (v) { return Util.num(v); }),
      etapas: Util.arr(c.etapas).map(function (e, i) {
        var tot = Util.num(e.total);
        return {
          codigo: e.codigo || "", nome: e.nome || "", total: tot,
          opcional: !!(etsOrc[i] && etsOrc[i].opcional),
          meses: Util.arr(e.meses).map(function (v) { return Util.num(v); }),
          /* a barra do papel é o percentual DA ETAPA em cada mês */
          pcts: Util.arr(e.meses).map(function (v) { return tot ? (Util.num(v) / tot) * 100 : 0; })
        };
      })
    };
    if (premissas.length) { saida.premissas = premissas; saida.fraseDasPremissas = Proposta.FRASE_PREMISSAS; }
    if (rodapeCal.length) saida.rodapeCalendarios = rodapeCal;
    return saida;
  };

  Proposta.blocosParaModelo = function (orc) {
    var linhas = Orcamento.linhas(orc) || [];
    var t = Orcamento.totais(orc);
    var ordem = [], porEtapa = {};
    linhas.forEach(function (L) {
      var nome = String(L.etapaNome || "").trim();
      var chave = String(L.etapaId || nome || "");
      if (!porEtapa[chave]) { porEtapa[chave] = { nome: nome, linhas: [], opcional: !!L.opcional }; ordem.push(chave); }
      porEtapa[chave].linhas.push({
        descricao: L.descricao || L.codigo || "",
        unidade: L.unidade || "",
        qtd: Util.num(L.quantidade),
        /* o motor escreve `l.total`; o unitário viaja para quem quiser conferir */
        unitario: Util.num(L.precoUnit),
        total: Util.num(L.precoTotal)
      });
    });
    /* ⚠ O TOTAL DA PROPOSTA É O OBRIGATÓRIO. As etapas marcadas como
       opcionais saem em `opcionais`, num bloco à parte com o próprio subtotal
       — somá-las no total faria o cliente ler como preço fechado um serviço
       que ele ainda vai decidir se quer. Sem nenhuma etapa opcional,
       `precoObrigatorio === precoVenda` e nada muda (ver Orcamento.calcular).

       ⚠ OS TRÊS NÚMEROS FECHAM: `total` + `totalOpcional` === `totalComOpcionais`
       ao centavo, nos dois modos de incidência de BDI e em qualquer
       arredondamento — o obrigatório sai POR DIFERENÇA em `Orcamento.calcular`.
       E cada um deles é a soma das MESMAS etapas do sintético, que é o que o
       cronograma, a linha de base e o `valoresEAP` leem.
       Roteiro do defeito que isto impede (achado na Fase 4A, consertado em
       11/09/2026): com o BDI no preço "final", `precoOpcional` somava o
       precoTotal das LINHAS da etapa opcional — que nesse modo é CUSTO, sem
       BDI. Duas etapas de R$ 100 com BDI de 10%, a segunda opcional, saíam no
       papel do cliente como "Valor total R$ 120" e "Adicionais R$ 100": o BDI
       da opcional cobrado dentro do obrigatório, e o adicional vendido sem BDI
       nenhum. O certo é R$ 110 e R$ 110. */
    var todos = ordem.map(function (k) { return porEtapa[k]; });
    return {
      grupos: todos.filter(function (g) { return !g.opcional; }),
      opcionais: todos.filter(function (g) { return g.opcional; }),
      total: Util.num(t.precoObrigatorio != null ? t.precoObrigatorio : t.precoVenda),
      totalOpcional: Util.num(t.precoOpcional),
      totalComOpcionais: Util.num(t.precoVenda)
    };
  };

  /* as condições comerciais que o modelo escreve, com os nomes que ele espera */
  Proposta.comercialParaModelo = function (orc) {
    var c = (orc && orc.comercial) || {};
    return {
      condicoesPagamento: c.condicoesPagamento || "",
      prazoExecucao: c.prazoExecucao || "",
      garantia: c.garantia || "",
      /* o bloco "Escopo em texto" pode ler a lista daqui (usarComercial) */
      incluso: c.incluso || "",
      excluso: c.excluso || ""
    };
  };

  /* =====================================================================
   * A AUDITORIA — a última chance antes de o papel abrir
   *
   * Mesma régua da carpintaria: palavra proibida, e o NÚMERO do custo escrito
   * no formato em que o documento escreveria dinheiro. Um custo pode coincidir
   * com um preço legítimo (o custo de um item batendo com a venda de outro),
   * então só acusa quando o número aparece E não é nenhum dos valores que o
   * documento DEVE mostrar.
   * =================================================================== */
  Proposta.PALAVRAS_PROIBIDAS = [
    "custo direto", "custo unit", "margem de", "lucro", "bdi de", "preço de compra"
  ];

  function _achatar(s) {
    /* ⚠ o espaço do "R$" é DURO (U+00A0) em `Util.fmtMoeda`: comparar texto
       cru deixaria passar o mesmo valor escrito com espaço comum */
    return String(s == null ? "" : s).replace(/\u00a0/g, " ").replace(/\s+/g, " ");
  }

  Proposta.auditar = function (html, orc) {
    var achados = [];
    var h = _achatar(html), baixo = h.toLowerCase();
    Proposta.PALAVRAS_PROIBIDAS.forEach(function (w) {
      if (baixo.indexOf(w) > -1) achados.push({ tipo: "palavra", achado: w });
    });

    var t = Orcamento.totais(orc);
    var b = Proposta.blocosParaModelo(orc);
    var legitimos = {};
    legitimos[_achatar(Util.fmtMoeda(b.total))] = 1;
    /* ⚠ OS ADICIONAIS TAMBÉM SÃO LEGÍTIMOS. Etapa marcada como opcional sai de
       `grupos` e entra em `opcionais`; esquecer o segundo bloco aqui faria a
       auditoria acusar de "custo vazado" justamente o preço que o documento
       precisa mostrar — e travaria a proposta por um defeito do auditor. */
    b.grupos.concat(b.opcionais || []).forEach(function (g) {
      g.linhas.forEach(function (l) {
        legitimos[_achatar(Util.fmtMoeda(l.total))] = 1;
        legitimos[_achatar(Util.fmtMoeda(l.unitario))] = 1;
      });
    });
    if (Util.num(b.totalOpcional) > 0) legitimos[_achatar(Util.fmtMoeda(b.totalOpcional))] = 1;

    var suspeitos = [];
    if (t.custoDireto > 0) suspeitos.push({ v: t.custoDireto, o: "o custo direto da obra" });
    if (t.bdiValor > 0) suspeitos.push({ v: t.bdiValor, o: "o valor do BDI" });
    (Orcamento.linhas(orc) || []).forEach(function (L) {
      if (Util.num(L.custoTotal) > 0) suspeitos.push({ v: Util.num(L.custoTotal), o: "o custo de " + (L.descricao || "um item") });
    });

    suspeitos.forEach(function (s) {
      var fmt = _achatar(Util.fmtMoeda(s.v));
      if (h.indexOf(fmt) < 0) return;
      if (legitimos[fmt]) return;          /* coincide com um valor que o papel deve mostrar */
      achados.push({ tipo: "numero", achado: Util.fmtMoeda(s.v), motivo: s.o });
    });
    return achados;
  };

  /* =====================================================================
   * O CLIENTE DO ORÇAMENTO NÃO TEM ID — e por isso o casamento é EXATO
   *
   * ⚠ `orc.cliente` é objeto embutido (`{nome, doc, contato}`), sem vínculo
   *   com a entidade `clientes`. O modelo, por outro lado, guarda `paraCliente`
   *   com o ID. Para o "modelo deste cliente" funcionar aqui, alguém tem de
   *   ligar os dois — e o único jeito honesto é NOME IGUAL, normalizado.
   *
   * ⚠ SEMELHANÇA NÃO ENTRA, e ambiguidade também não: dois cadastros com o
   *   mesmo nome devolvem vazio, e a tela cai no modelo padrão. Sugerir o
   *   desenho do cliente errado é o tipo de erro que aparece na frente dele.
   * =================================================================== */
  Proposta.clienteIdDoOrcamento = function (orc) {
    var nome = String(((orc && orc.cliente) || {}).nome || "").trim().toLowerCase();
    if (!nome) return "";
    var achados = [];
    try {
      var eid = Auth.empresaId();
      (Store.listar(eid, "clientes") || []).forEach(function (c) {
        var n = String((c && (c.nome || c.razaoSocial)) || "").trim().toLowerCase();
        if (n && n === nome) achados.push(c.id);
      });
    } catch (e) { return ""; }
    return achados.length === 1 ? achados[0] : "";
  };

  global.Proposta = Proposta;
})(window);
