'use strict';
/* ---- PONTE DO ASSINADOR DIGITAL (ICP-Brasil) ---------------------------------
 * O OrçaPRO não assina sozinho: quem assina é um programa local separado (o
 * assinador), que pede ao WINDOWS a assinatura com o certificado instalado na
 * máquina. A chave privada nunca passa por aqui, e nenhuma senha de
 * certificado é guardada pelo app.
 *
 * Como o servidor acha o assinador: o próprio assinador, ao ser instalado,
 * grava `%LOCALAPPDATA%\RA-Assinador\instalacao.json` com
 * `{ "python": "<python.exe>", "script": "<ra_assinador.py>", "versao": "x" }`.
 * `ORCAPRO_ASSINADOR_JSON` aponta outro registro (as suítes usam um assinador
 * de mentira, para provar a ponte sem certificado nem Python).
 *
 * ⚠ execFile, NUNCA shell: o texto da autorização e o nome do signatário vêm
 * da tela e viram argumentos. Com shell, aspas no texto viravam comando.
 * ⚠ windowsHide em todo filho (o gate reprova console piscando no cliente).
 * ⚠ Um pedido por vez (trinco): duas assinaturas ao mesmo tempo disputam o
 * mesmo certificado e a mesma pasta temporária.
 */
var fs = require('fs');
var os = require('os');
var path = require('path');
var crypto = require('crypto');
var execFile = require('child_process').execFile;

var TIMEOUT_MS = 180 * 1000;     // memorial de 171 páginas assina em ~3 s; prancha A1 com 6 folhas, ~5 s
var MAX_PDF = 80 * 1024 * 1024;  // pasta da obra real: maior PDF medido 10,3 MB
var ocupado = false;

function arquivoRegistro() {
  if (process.env.ORCAPRO_ASSINADOR_JSON) return process.env.ORCAPRO_ASSINADOR_JSON;
  var base = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
  return path.join(base, 'RA-Assinador', 'instalacao.json');
}

function lerRegistro() {
  var arq = arquivoRegistro();
  var reg;
  try { reg = JSON.parse(fs.readFileSync(arq, 'utf8')); }
  catch (e) { return { ok: false, motivo: 'o assinador digital não está instalado neste computador (sem ' + arq + ').' }; }
  if (!reg || !reg.python || !reg.script) return { ok: false, motivo: 'o registro do assinador está incompleto (' + arq + ').' };
  if (!fs.existsSync(reg.python)) return { ok: false, motivo: 'o Python do assinador não está mais em ' + reg.python + '.' };
  if (!fs.existsSync(reg.script)) return { ok: false, motivo: 'o assinador não está mais em ' + reg.script + '.' };
  return { ok: true, python: reg.python, script: reg.script, versao: String(reg.versao || '') };
}

/* Roda o assinador e devolve o JSON que ele imprime. stderr é só diagnóstico
   (as bibliotecas de PDF avisam por lá); a resposta é SEMPRE o stdout. */
function rodar(reg, args, cb) {
  execFile(reg.python, [reg.script].concat(args), {
    windowsHide: true, timeout: TIMEOUT_MS, maxBuffer: 16 * 1024 * 1024,
    env: Object.assign({}, process.env, { PYTHONIOENCODING: 'utf-8' })
  }, function (err, so, se) {
    var saida = String(so || '');
    var dados = null;
    try { dados = JSON.parse(saida); } catch (e) {}
    cb({
      codigo: err ? (typeof err.code === 'number' ? err.code : -1) : 0,
      matou: !!(err && err.killed),
      dados: dados,
      erro: String(se || '').split(/\r?\n/).filter(function (l) {
        return l && !/NOT subset|Multiple definitions|too wide for container/.test(l);   // ruído conhecido das bibliotecas
      }).slice(-6).join('\n')
    });
  });
}

function status(cb) {
  var reg = lerRegistro();
  if (!reg.ok) return cb({ instalado: false, motivo: reg.motivo });
  rodar(reg, ['versao'], function (r) {
    if (r.matou) return cb({ instalado: false, motivo: 'o assinador não respondeu a tempo.' });
    if (!r.dados || !r.dados.versao) return cb({ instalado: false, motivo: 'o assinador não respondeu como esperado. ' + r.erro });
    cb({ instalado: true, versao: r.dados.versao });
  });
}

function certificados(cb) {
  var reg = lerRegistro();
  if (!reg.ok) return cb({ ok: false, codigo: 'sem-assinador', erro: reg.motivo });
  rodar(reg, ['certificados', '--json'], function (r) {
    if (r.matou) return cb({ ok: false, codigo: 'demorou', erro: 'O assinador não respondeu a tempo.' });
    if (!Array.isArray(r.dados)) return cb({ ok: false, codigo: 'falhou', erro: 'O assinador não listou os certificados. ' + r.erro });
    cb({ ok: true, certificados: r.dados });
  });
}

function tmpDir() {
  var d = path.join(os.tmpdir(), 'orcapro-assinador-' + crypto.randomBytes(6).toString('hex'));
  fs.mkdirSync(d, { recursive: true });
  return d;
}
function limpar(d) { try { fs.rmSync(d, { recursive: true, force: true }); } catch (e) {} }

function texto(v, max) { return String(v == null ? '' : v).replace(/[\r\n\t]+/g, ' ').slice(0, max || 300); }

/* opcoes: { cert, ancora, paginas:'todas'|'', pagina, razao,
             manuscrita: <Buffer png>|null, manuscritaAncora, autorizacao } */
function assinar(pdf, opcoes, cb) {
  if (!Buffer.isBuffer(pdf) || pdf.length < 8 || pdf.slice(0, 5).toString('latin1') !== '%PDF-') {
    return cb({ ok: false, codigo: 'nao-pdf', erro: 'O arquivo enviado não é um PDF.' });
  }
  if (pdf.length > MAX_PDF) return cb({ ok: false, codigo: 'grande', erro: 'PDF grande demais para assinar por aqui.' });
  var reg = lerRegistro();
  if (!reg.ok) return cb({ ok: false, codigo: 'sem-assinador', erro: reg.motivo });
  if (ocupado) return cb({ ok: false, codigo: 'ocupado', erro: 'Já há uma assinatura em andamento. Espere terminar.' });
  opcoes = opcoes || {};
  if (opcoes.manuscrita && !(texto(opcoes.autorizacao).trim() && texto(opcoes.manuscritaAncora).trim())) {
    return cb({ ok: false, codigo: 'sem-autorizacao', erro: 'Assinatura manuscrita só com o registro de quem autorizou e o nome debaixo da linha.' });
  }
  ocupado = true;
  var dir = tmpDir();
  var entrada = path.join(dir, 'entrada.pdf');
  var saida = path.join(dir, 'assinado.pdf');
  var args = ['assinar', entrada, '--sim', '--json', '--forcar', '--saida', saida];
  try {
    fs.writeFileSync(entrada, pdf);
    if (opcoes.cert) args.push('--cert', texto(opcoes.cert, 60));
    if (opcoes.ancora) args.push('--ancora', texto(opcoes.ancora, 160));
    if (opcoes.paginas === 'todas') args.push('--paginas', 'todas');
    else if (opcoes.pagina) args.push('--pagina', texto(opcoes.pagina, 10));
    if (opcoes.razao) args.push('--razao', texto(opcoes.razao, 120));
    if (opcoes.manuscrita) {
      var png = path.join(dir, 'manuscrita.png');
      fs.writeFileSync(png, opcoes.manuscrita);
      args.push('--manuscrita', png, '--manuscrita-ancora', texto(opcoes.manuscritaAncora, 160),
        '--autorizacao', texto(opcoes.autorizacao, 400));
    }
  } catch (e) {
    ocupado = false; limpar(dir);
    return cb({ ok: false, codigo: 'temp', erro: 'Não consegui preparar o arquivo temporário: ' + e.message });
  }
  rodar(reg, args, function (r) {
    var resp;
    try {
      var item = Array.isArray(r.dados) ? r.dados[0] : null;
      if (r.matou) resp = { ok: false, codigo: 'demorou', erro: 'O assinador passou de ' + (TIMEOUT_MS / 1000) + ' s e foi interrompido.' };
      else if (!item) resp = { ok: false, codigo: 'falhou', erro: 'O assinador não respondeu como esperado. ' + r.erro };
      else if (item.status !== 'assinado') resp = { ok: false, codigo: 'recusado', erro: item.erro || item.motivo || 'O assinador recusou.' };
      else {
        var bytes = fs.readFileSync(saida);
        resp = { ok: true, pdf: bytes, sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
          certificado: item.certificado || '', assinaturas: item.assinaturas || [], manuscrita: item.manuscrita || [] };
      }
    } catch (e) {
      resp = { ok: false, codigo: 'falhou', erro: 'Falha ao ler o PDF assinado: ' + e.message };
    }
    ocupado = false; limpar(dir);
    cb(resp);
  });
}

function verificar(pdf, cb) {
  if (!Buffer.isBuffer(pdf) || pdf.slice(0, 5).toString('latin1') !== '%PDF-') return cb({ ok: false, codigo: 'nao-pdf', erro: 'O arquivo enviado não é um PDF.' });
  var reg = lerRegistro();
  if (!reg.ok) return cb({ ok: false, codigo: 'sem-assinador', erro: reg.motivo });
  var dir = tmpDir();
  var arq = path.join(dir, 'conferir.pdf');
  try { fs.writeFileSync(arq, pdf); } catch (e) { limpar(dir); return cb({ ok: false, codigo: 'temp', erro: e.message }); }
  rodar(reg, ['verificar', arq, '--json'], function (r) {
    limpar(dir);
    var item = Array.isArray(r.dados) ? r.dados[0] : null;
    if (r.matou) return cb({ ok: false, codigo: 'demorou', erro: 'A verificação passou do tempo.' });
    if (!item) return cb({ ok: false, codigo: 'falhou', erro: 'O assinador não respondeu como esperado. ' + r.erro });
    if (item.erro) return cb({ ok: false, codigo: 'falhou', erro: item.erro });
    cb({ ok: true, assinaturas: item.assinaturas || [] });
  });
}

module.exports = { status: status, certificados: certificados, assinar: assinar, verificar: verificar,
  _lerRegistro: lerRegistro, _ocupado: function () { return ocupado; } };
