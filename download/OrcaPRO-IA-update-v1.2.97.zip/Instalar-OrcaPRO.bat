@echo off
chcp 65001 >nul
title Instalar OrcaPRO IA
cd /d "%~dp0"
echo(
echo  ================================================================
echo     OrcaPRO IA  -  Instalacao automatica
echo  ================================================================
echo(
echo  [1/4] Verificando o Node.js...
if exist "%~dp0runtime\node.exe" set "PATH=%~dp0runtime;%PATH%"
where node >nul 2>nul
if errorlevel 1 (
  echo        Node nao encontrado - vou baixar e preparar ^(precisa de internet^)...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalador\baixar-node.ps1"
  if exist "%~dp0runtime\node.exe" set "PATH=%~dp0runtime;%PATH%"
)
where node >nul 2>nul
if errorlevel 1 (
  echo(
  echo  [ERRO] Nao consegui preparar o Node.js.
  echo         Verifique a internet e rode este arquivo de novo,
  echo         ou instale o Node LTS em https://nodejs.org e rode de novo.
  echo(
  pause
  exit /b 1
)
echo        Node OK.
echo(
echo  [2/4] Base SINAPI do seu estado...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalador\escolher-base.ps1"
echo(
echo  [3/4] Criando atalho na Area de Trabalho...
powershell -NoProfile -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut([IO.Path]::Combine([Environment]::GetFolderPath('Desktop'),'OrcaPRO IA.lnk')); $s.TargetPath='%~dp0Iniciar-OrcaPRO.bat'; $s.WorkingDirectory='%~dp0'; $s.Description='OrcaPRO IA - Do orcamento a entrega da obra'; $s.Save()" 2>nul
echo        Atalho "OrcaPRO IA" criado.
echo(
echo  [4/4] Tudo pronto! Abrindo o guia de boas-vindas e o OrcaPRO IA...
start "" "%~dp0Bem-vindo.html"
timeout /t 1 >nul
call "%~dp0Iniciar-OrcaPRO.bat"
exit /b 0
