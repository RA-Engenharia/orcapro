/* =====================================================================
 * execucao.js — "Agente de Execução" (Fase A do BIM 2D→obra real)
 *
 * O CÉREBRO de canteiro: pega cada item do orçamento (código SINAPI + qtd),
 * lê os COEFICIENTES DE MÃO-DE-OBRA reais do analítico SINAPI (horas-homem por
 * profissão: pedreiro, servente, eletricista, encanador, pintor, carpinteiro,
 * armador...), e responde as perguntas do dono da obra:
 *   - quanto tempo leva cada etapa?  (duração = Hh ÷ (equipe × jornada))
 *   - quantas pessoas de cada profissão preciso p/ bater a data de entrega?
 *   - quanto REALMENTE custa cada etapa (custo/dia real dos meus colaboradores)?
 *   - o simulado de execução FECHA com o orçamento executivo? senão, ONDE ajusta?
 *
 * Grounded, NÃO inventa: produtividade = Hh do SINAPI; custo/dia = colaborador
 * real (RH do app), com fallback honesto no custo-hora do próprio SINAPI.
 * Lógica pura/testável (Node). Depende de window.Analitico e window.Cronograma
 * quando presentes (injetáveis nos testes via Execucao._deps).
 * ===================================================================== */
(function (global) {
  "use strict";

  /* chave de unidade tolerante a grafia ("H", "h", "hora"). Delega ao helper
     central quando existe; senão resolve sozinho — este módulo é testado
     isolado. Sem isso o extrator de horas-homem comparava a string crua "H" e
     uma base em minúscula zeraria a mão de obra SEM erro na tela. */
  function unKeyEx(u) {
    if (typeof Util !== "undefined" && Util.unidadeChave) return Util.unidadeChave(u);
    var s = String(u == null ? "" : u).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")
      .replace(/[^a-z0-9]/g, "");
    return (s === "hora" || s === "hr") ? "h" : s;
  }

  /* ⚠ RÉPLICA FIEL DE `Util.parseNum` (js/util.js). Este módulo é puro — o
     gate o roda em Node, onde `Util` não existe — então a regra vem copiada.
     ⚠ E CÓPIA APODRECE CALADA: as duas versões curtas que existiam neste
     projeto erram em direções OPOSTAS, e as duas já moveram dinheiro:
     `replace(/\./g,"")` lê "1234.56" como 123456 (×100); tratar o ponto só
     quando há vírgula lê "1.850.000" como 1,85 (÷1.000.000).
     A paridade com o `Util.parseNum` real é cobrada em tools/test-numbr.js. */
  function num(v) {
    if (typeof v === "number") return isFinite(v) ? v : 0;
    if (v == null) return 0;
    var s = String(v).trim();
    if (!s) return 0;
    s = s.replace(/[^0-9.,\-]/g, "");
    if (!s) return 0;
    var temV = s.indexOf(",") > -1, temP = s.indexOf(".") > -1;
    if (temV && temP) {
      if (s.lastIndexOf(",") > s.lastIndexOf(".")) s = s.replace(/\./g, "").replace(",", ".");
      else s = s.replace(/,/g, "");
    } else if (temV) {
      s = (s.match(/,/g) || []).length > 1 ? s.replace(/,/g, "") : s.replace(",", ".");
    } else if (temP && (s.match(/\./g) || []).length > 1) {
      if (/^-?\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, "");
      else { var iP = s.lastIndexOf("."); s = s.slice(0, iP).replace(/\./g, "") + "." + s.slice(iP + 1); }
    } else if (temP && /^-?\d{1,3}(\.\d{3})+$/.test(s) && !/^-?0\./.test(s)) {
      s = s.replace(/\./g, "");
    }
    var n = parseFloat(s);
    return isFinite(n) ? n : 0;
  }
  function fix(s) { return (typeof Util !== "undefined" && Util.fixEnc) ? Util.fixEnc(String(s == null ? "" : s)) : String(s == null ? "" : s); }
  function norm(s) { return fix(s).toUpperCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/\s+/g, " ").trim(); }

  // Mesmo critério do analitico.js: linha de hora-homem com encargos é MO pura.
  var RE_MO = / COM ENCARGOS COMPLEMENTARES| COM ENCARGOS SOCIAIS|\(HORISTA\)|\(MENSALISTA\)/;
  function ehMoPura(txt) { return RE_MO.test(norm(txt)); }

  // Profissão = texto antes de " COM ENCARGOS"/"(HORISTA)". Ex.: "PEDREIRO COM
  // ENCARGOS COMPLEMENTARES" -> "PEDREIRO".
  function profDe(desc) {
    var d = norm(desc);
    d = d.replace(/ COM ENCARGOS.*$/, "").replace(/\(HORISTA\)|\(MENSALISTA\)/g, "").replace(/\s+/g, " ").trim();
    return d || "MAO DE OBRA";
  }

  // Sinônimos p/ casar a FUNÇÃO livre do colaborador com a PROFISSÃO do SINAPI.
  var SINONIMOS = [
    ["SERVENTE", ["SERVENTE", "AJUDANTE", "AUXILIAR", "PEAO", "PEÃO", "MEIO OFICIAL", "MEIO-OFICIAL"]],
    ["PEDREIRO", ["PEDREIRO"]],
    ["ELETRICISTA", ["ELETRICISTA", "ELETROTECNICO"]],
    ["ENCANADOR OU BOMBEIRO HIDRAULICO", ["ENCANADOR", "BOMBEIRO", "HIDRAULICO", "HIDRAULICA"]],
    ["PINTOR", ["PINTOR"]],
    ["CARPINTEIRO DE FORMAS", ["CARPINTEIRO", "CARPINTARIA"]],
    ["ARMADOR", ["ARMADOR", "FERREIRO", "FERRAGEM"]],
    ["MONTADOR DE ESTRUTURAS METALICAS", ["MONTADOR", "SERRALHEIRO"]],
    ["SOLDADOR", ["SOLDADOR"]],
    ["OPERADOR DE BETONEIRA", ["BETONEIRA"]],
    ["ENCARREGADO GERAL", ["ENCARREGADO", "MESTRE", "MESTRE DE OBRAS"]],
    ["ENGENHEIRO CIVIL", ["ENGENHEIRO", "ENGENHEIRA"]],
    ["VIDRACEIRO", ["VIDRACEIRO", "VIDRO"]],
    ["GESSEIRO", ["GESSEIRO", "GESSO"]],
    // "ASSENTADOR" cru sai daqui: na base SINAPI real as linhas "ASSENTADOR ..." são de TUBOS/MANILHAS
    // (tubulação, outro ofício) — um azulejista cruzaria com elas. Mantém só as formas de revestimento.
    ["AZULEJISTA", ["AZULEJISTA", "LADRILHISTA", "LADRILHEIRO", "ASSENTADOR DE CERAMICA", "ASSENTADOR DE PISO", "ASSENTADOR DE PORCELANATO", "ASSENTADOR DE REVESTIMENTO", "ASSENTADOR DE AZULEJO"]],
    ["TELHADISTA", ["TELHADISTA", "TELHADO", "COBERTURA"]],
    ["JARDINEIRO", ["JARDINEIRO", "JARDIM", "PAISAG"]]
  ];
  // Pessoal de ESCRITÓRIO/gestão nunca casa profissão de CAMPO (senão contamina o custo de obra).
  var OFFICE = /ADMINISTRAT|FINANCEIR|ESCRITORI|COMPRAS|RECURSOS HUMAN|\bRH\b|CONTABIL|CONTADOR|COMERCIAL|VENDAS|SECRETARI|ESTAGIARI|RECEPC|ALMOXARIF|GERENTE|DIRETOR|ANALISTA|TECNICO DE SEGURANC|ADVOGAD|ASSISTENTE SOCIAL|MOTORISTA|VIGIA|PORTEIR|COZINHEIR/;
  // Tokens "largos" que sozinhos casam demais — exigem 2º termo em comum com a profissão.
  var LARGO = /^(OPERADOR|AUXILIAR|AJUDANTE|MONTADOR|OFICIAL|ASSENTADOR)$/;
  // Normaliza o TIER (nível) de uma função/profissão livre p/ o match não cruzar níveis diferentes.
  // Aplicado NOS DOIS lados (função do colaborador E profissão SINAPI) — senão fica assimétrico: o
  // colapso só na função deixa a profissão SINAPI "AUXILIAR DE ELETRICISTA" ser casada pelo oficial
  // "Eletricista" (via LARGO) e cobrada com a diária cara do oficial.
  function canonTier(s) {
    // AUXILIAR/ajudante/servente/meio-oficial/peão (inclusive "... DE <ofício>" e abrev. AUX/AJUD/SERV) = SERVENTE.
    // "meio-oficial" tem grafias de "metade": MEIO/MEIA/1-2/½ + OFICIAL — todas são servente-tier.
    s = s.replace(/^((MEI[OA]|1\/2|½)[\s-]*OFICIAL|AJUDANTE|AJUD|AUXILIAR|AUX|SERVENTE|SERV|PEAO)\b.*/, "SERVENTE");
    // supervisor "encarregado/mestre/chefe/supervisor/líder [de <ofício>]" = ENCARREGADO GERAL — tier de
    // supervisão NÃO empresta (nem toma) o custo do ofício ("chefe de pedreiro" ≠ pedreiro).
    s = s.replace(/^(ENCARREGADO|MESTRE|CONTRA[\s-]*MESTRE|CHEFE|SUPERVISOR|LIDER|ENCARR)\b.*/, "ENCARREGADO GERAL");
    if (s === "OFICIAL") s = "PEDREIRO"; // "OFICIAL" isolado = oficial de campo (pedreiro-tier)
    return s;
  }
  // pontuação de match entre função-colaborador e profissão-SINAPI
  function scoreMatch(funcaoColab, profSinapi) {
    var f = norm(funcaoColab), p = norm(profSinapi);
    if (!f) return 0;
    if (OFFICE.test(f)) return 0; // administrativo/financeiro/motorista/vigia etc. -> nunca é MO de campo
    f = canonTier(f); p = canonTier(p); // normaliza o tier nos DOIS lados (função e profissão)
    if (f === p) return 100;
    var p0 = p.split(" ")[0], reTok = new RegExp("(^| )" + p0.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "( |$)");
    // token DIRETO: a função tem a 1ª palavra da profissão como palavra inteira (não substring solta)
    if (p.indexOf(f) >= 0 || (p0.length >= 4 && reTok.test(f))) {
      if (LARGO.test(p0)) { // "operador/auxiliar de X": exige o X (2º termo) também em comum
        var resto = p.split(" ").slice(1).filter(function (w) { return w.length >= 4 && w !== "COM"; });
        var comum = resto.some(function (w) { return f.indexOf(w) >= 0; });
        return comum ? 60 : 0;
      }
      return 60;
    }
    // via sinônimos (a função e a profissão caem no mesmo grupo)
    for (var i = 0; i < SINONIMOS.length; i++) {
      var grpProf = norm(SINONIMOS[i][0]), kws = SINONIMOS[i][1];
      var profNoGrupo = (p.indexOf(grpProf.split(" ")[0]) >= 0);
      var funcNoGrupo = kws.some(function (k) { return f.indexOf(norm(k)) >= 0; });
      var profKwNoGrupo = kws.some(function (k) { return p.indexOf(norm(k)) >= 0; });
      if (funcNoGrupo && (profNoGrupo || profKwNoGrupo)) return 40;
    }
    return 0;
  }

  /* ================= FOLHAS DE REDE (cronograma executivo, espec 1.5) =================
   * A duração por Hh SINAPI existia só por ETAPA: o Hh de cada item era somado
   * e jogado fora (simular). O cronograma executivo detalha o prazo pelas
   * subetapas da planilha, então a mesma conta precisa sair também por FOLHA.
   *
   * ⚠ CONTRATO DE IDS (fixo, é o mesmo do motor do cronograma, espec 1.1) —
   * é por ele que sub.duracoes[folhaId] casa com a folha desenhada no Gantt:
   *   - subetapa COM item ............ id = sub.id
   *   - itens soltos de uma etapa que TAMBÉM tem subetapa com item
   *                                    id = etapa.id + "~g" ("Serviços gerais da etapa")
   *   - etapa sem subetapa com item .. NÃO tem folha separada: a própria etapa é a
   *     folha de rede, e a duração dela continua em duracoes[etapa.id]. Por isso
   *     `folhas` sai VAZIA — se saísse [{id: etapa.id}], o envio gravaria o id da
   *     ETAPA no mapa das SUBETAPAS e a mesma duração passaria a ter dois donos.
   * Subetapa vazia não vira folha (a planilha não lhe dá número); item com
   * subEtapaId que não existe mais é solto (a mesma regra de Orcamento.calcular).
   * Ordem: soltos primeiro, depois as subetapas na ordem de e.subetapas — a
   * ordem canônica de e.itens. Quem casa folha usa o ID, nunca a posição.
   * ================================================================================= */
  function folhasDe(e) {
    var subs = Array.isArray(e && e.subetapas) ? e.subetapas : [], valido = {}, nItens = {}, nSoltos = 0;
    subs.forEach(function (s) { if (s && s.id) { valido[s.id] = true; nItens[s.id] = 0; } });
    (e.itens || []).forEach(function (it) {
      var sid = it && it.subEtapaId;
      if (sid && valido[sid]) nItens[sid]++; else nSoltos++;
    });
    var lista = [], porId = {}, soltos = null;
    function nova(id, nome, tipo) {
      return { id: id, nome: nome, tipo: tipo, prof: {}, homensDiaEstim: 0, nComQtd: 0, nExatos: 0, nSemBaseMO: 0 };
    }
    subs.forEach(function (s) {
      if (!s || !s.id || !nItens[s.id] || porId[s.id]) return;
      porId[s.id] = nova(s.id, s.nome || "Sub etapa", "subetapa");
      lista.push(porId[s.id]);
    });
    if (!lista.length) return null; // etapa sem subetapa com item: ela mesma é a folha
    if (nSoltos > 0) { soltos = nova(e.id + "~g", "Serviços gerais da etapa", "soltos"); lista.unshift(soltos); }
    return { lista: lista, de: function (it) { var sid = it && it.subEtapaId; return (sid && valido[sid]) ? porId[sid] : soltos; } };
  }
  /* Acumula UM item na folha dele com a MESMA triagem que simular faz na etapa:
     Hh SINAPI quando o item tem coeficiente; senão MO-R$ ÷ diária de referência;
     com custoMO 0, "sem base de MO". Acumuladores PRÓPRIOS da folha — nenhum
     objeto é compartilhado com a etapa, senão o laço de equipe/custo da etapa
     (que escreve em prof[P]) vazaria para dentro da folha. */
  function acumFolha(f, it, q, r, diariaRef) {
    if (!f) return;
    if (q > 0) { f.nComQtd++; if (r.exato) f.nExatos++; }
    if (r.exato) {
      for (var p in r.prof) { var s = f.prof[p] || (f.prof[p] = { hh: 0, custoHora: 0 }); s.hh += r.prof[p].hh; if (!s.custoHora) s.custoHora = r.prof[p].custoHora; }
    } else if (q > 0) {
      var moR = num(it.custoMO) * q;
      if (moR > 0) f.homensDiaEstim += moR / diariaRef; else f.nSemBaseMO++;
    }
  }
  /* ⚠ A MESMA FÓRMULA DA ETAPA (passo 2 e 4 do simular), aplicada à SOMA da folha:
     max(1, ceil(max(max_P ΣHh_P ÷ jornada, homensDiaEstim))). A crítica de
     produto mediu o porquê: somar o máximo de cada item (em vez do máximo da
     soma) dá um prazo maior para o mesmo serviço, e duas telas rotuladas
     "SINAPI" discordariam. `homensDia` = o valor dentro do ceil (a profissão
     gargalo com 1 pessoa). `duracao` aplica o mesmo fator de prazo-alvo da
     etapa — sem data de entrega, fator 1 e duracao === duracaoNatural.
     `exato` = toda a duração vem de Hh SINAPI (nenhum item com quantidade
     entrou pela MO-R$ nem ficou sem base). */
  function fecharFolha(f, jorn, fator) {
    var maxHD = 0;
    for (var p in f.prof) { var hd = f.prof[p].hh / jorn; f.prof[p].homensDia = hd; if (hd > maxHD) maxHD = hd; }
    if (f.homensDiaEstim > maxHD) maxHD = f.homensDiaEstim;
    f.homensDia = maxHD;
    f.temBaseMO = maxHD > 0;
    f.duracaoNatural = f.temBaseMO ? Math.max(1, Math.ceil(maxHD)) : 0;
    f.duracao = f.temBaseMO ? Math.max(1, Math.round(f.duracaoNatural * fator)) : 0;
    f.exato = f.nComQtd > 0 && f.nExatos === f.nComQtd;
  }
  /* Mapa gravável. ⚠ Um objeto que a nuvem devolveu como [] ("a forma no disco
     decide se sincroniza") aceita chave de texto na memória e a PERDE no
     JSON.stringify — a duração enviada sumiria no próximo salvar, sem erro.
     Aqui array vira objeto (levando o que tinha) antes de receber chave. */
  function mapaObj(o) {
    if (o && typeof o === "object" && !Array.isArray(o)) return o;
    var n = {};
    if (Array.isArray(o)) for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) n[k] = o[k];
    return n;
  }
  var MOTIVO_SUBETAPAS = "duração vem das subetapas";
  var MOTIVO_SEM_BASE = "não estimável (sem base de mão de obra)";

  /* ================= COMPOSIÇÃO PRÓPRIA (13/09/2026) =================
   * ⚠ ROTEIRO DO DEFEITO. O `hhDoItem` só procurava o código no ANALÍTICO
   * SINAPI. A composição própria mora em outra base (`Bases` "PROPRIA", o
   * blob do IndexedDB que o criador grava em `_propriaGravar`), e o criador
   * só aceita insumo REAL: a mão de obra entra com o código do SINAPI
   * (88278 montador, 88316 servente…), em hora, com coeficiente. Ou seja, a
   * hora-homem ESTÁ no orçamento — só não era lida. MEDIDO na obra de
   * demonstração (galpão 18×9, R$ 504 mil): o histograma mostrava pico de
   * 10,68 pessoas com 77,3% das equipe-dias FORA, porque a estrutura
   * metálica (RA-EM-01, 31% do custo) e o canteiro eram composições
   * próprias; a mesma conta lendo a própria dava 16,69. Pelo fluxo do app
   * (criar → gravar → lançar), a própria com 88278 × 0,0731927 h/kg saía
   * `{prof:{}, exato:false}` e o histograma a mandava "baixar a base da UF".
   *
   * ⚠ O CRITÉRIO É O MESMO DO ANALÍTICO, de propósito: linha em hora COM
   * "COM ENCARGOS…/(HORISTA)/(MENSALISTA)" (RE_MO acima). MEDIDO nos backups
   * da RA (121 composições próprias distintas): 182 de 190 linhas de mão de
   * obra passam nele; as que não passam são "CURSO DE CAPACITAÇÃO… HORISTA"
   * (hora de curso, não de canteiro — o analítico também não as conta).
   * Insumo de MO que alguém digitou sem código SINAPI NÃO vira hora-homem:
   * não há produtividade medida atrás dele, e inventar Hh é o que este módulo
   * promete não fazer.
   *
   * ⚠ ANALÍTICO PRIMEIRO. O criador recusa código próprio igual a código
   * oficial (ComposicaoPropria.validar → existeOficial), então consultar a
   * própria só quando o analítico não tem o código não muda NENHUM item
   * SINAPI — e a Execução e o histograma (que não recebem `baseFonte`)
   * decidem igual.
   *
   * ⚠ LIDO POR CLOSURE, NUNCA POR `this`: o histograma recebe o provedor
   * solto em alguns caminhos (tools/test-histograma.js, bloco 1), e aí o
   * `this` é o `opc` — `this._P()` lançaria no 1º serviço. */
  function propriaDe() {
    var d = Execucao._deps;
    if (d && d.Propria) return d.Propria;
    if (typeof Bases !== "undefined" && Bases && typeof Bases.obter === "function") {
      /* ⚠ SÓ HÁ BASE PRÓPRIA PARA CONSULTAR SE ELA ESTÁ REGISTRADA (revisão 3,
         13/09/2026). Devolver o provedor sempre que `Bases` existe — e ele
         existe em TODO navegador — fazia `propriaConsultada` ser true numa
         máquina sem composição própria nenhuma, e o histograma mandava
         "restaure o backup que tem a base própria ou entre na conta da nuvem"
         por causa de item IOPES, ORSE, SETOP, SUDECAP, SEINFRA e até de um
         insumo SINAPI (medido em 7 dos 12 orçamentos reais sem própria). */
      var temP = (typeof Bases.extras === "function")
        ? Bases.extras().some(function (b) { return b && String(b.fonte).toUpperCase() === "PROPRIA"; })
        : true;
      if (!temP) return null;
      return { obter: function (cod) { return Bases.obter("PROPRIA", String(cod)); } };
    }
    return null;
  }
  // linha que é SUB-COMPOSIÇÃO (e não material): o criador grava "COMPOSICAO"
  // (vindo da referência analítica) ou "COMPOSICAO AUXILIAR" (vindo da busca)
  function ehComposicao(ins) { return /COMPOSI/.test(norm(ins && ins.tipo)) || /COMPOSI/.test(norm(ins && ins.categoria)); }
  /* Proporção de mão de obra de uma composição (analítico ou própria), para
     o item que NÃO traz a separação MO/MAT/EQ. ⚠ O SINAPI sintético não
     publica a separação: 0 de 12.815 itens de MG têm o campo (medido no
     _prodMO de js/gestao.js, que usa a mesma régua via Analitico.quebra) —
     pelo fluxo do app o item lançado nasce com custoMO 0 e a aba dizia "MO
     total orçada: R$ 0,00" para uma obra de 75 itens com hora-homem. A
     proporção é da base e o custo é o do orçamento: não inventa número. */
  function razaoMO(comp) {
    if (!comp) return 0;
    var mo = num(comp.custoMO), t = mo + num(comp.custoMAT) + num(comp.custoEQ);
    return (t > 0 && mo > 0) ? mo / t : 0;
  }

  var Execucao = {
    DEFAULTS: {
      jornadaH: 8,            // horas por dia de trabalho
      diasUteisSemana: 5,
      diasUteisMes: 22,       // divisor p/ converter salário MENSAL em custo/dia
      paralelismo: 0.15,      // sobreposição entre etapas (mesmo do Cronograma)
      toleranciaPct: 5,       // faixa "dentro do orçado" (±%)
      dataInicio: null,       // "AAAA-MM-DD" (default: hoje)
      dataEntrega: null,      // "AAAA-MM-DD" (se dado: dimensiona equipe p/ caber)
      encargosPct: 68,        // encargos patronais CLT (%) — MESMO default da Folha (gestao.js calcFolha) p/ os módulos concordarem; onera a diária p/ comparar com SINAPI (onerado)
      diariaMin: 150,         // piso de diária quando a base não tem preço da profissão (custo-hora<=0)
      coberturaMin: 55,       // abaixo disso a reconciliação é rotulada "parcial" (não confiável)
      colaboradores: []       // [{funcao, remuneracao, unidadeRem, tipoContrato, status}]
    },
    _deps: { Analitico: null, Cronograma: null, Propria: null }, // injetável em teste (Propria = {obter(codigo)}; padrão: Bases "PROPRIA")
    _A: function () { return this._deps.Analitico || global.Analitico || null; },
    _C: function () { return this._deps.Cronograma || global.Cronograma || null; },
    profDe: profDe, ehMoPura: ehMoPura, _score: scoreMatch,
    // textos do `detalhe` do envio em modo executivo — a fiação compara por eles, nunca por cópia
    MOTIVO_SUBETAPAS: MOTIVO_SUBETAPAS, MOTIVO_SEM_BASE: MOTIVO_SEM_BASE,

    // Horas-homem por profissão de UM item (recursa nas sub-composições não-MO,
    // multiplicando coeficientes). Retorna {prof:{HH,custoHora}}, exato:bool,
    // origem: "analitico" | "propria" | null (onde a composição foi LIDA) e
    // propriaConsultada: bool (havia base própria para procurar — é o que
    // separa "não está na máquina" de "não está na base analítica").
    hhDoItem: function (item, A) {
      A = A || this._A();
      var qtd = num(item.quantidade), acc = {}, exato = false, origem = null;
      var P = propriaDe();
      /* ⚠ item de OUTRA base declarada (SETOP, ORSE, SICRO…) não é procurado na
         própria: código homônimo daria a hora-homem de outro serviço, e a frase
         do histograma ("nem na base própria") falaria de uma base que nunca foi
         a dele. Sem declaração (o serviço do cronograma não carrega a base) ou
         declarada PRÓPRIA, procura — é o que dá para saber. */
      var bfItem = norm(item && (item.baseFonte || item.origem));
      if (bfItem && !/^PROPRI/.test(bfItem)) P = null;
      function soma(ins, mult) {
        var p = profDe(ins.descricao), s = acc[p] || (acc[p] = { hh: 0, custoHora: 0 });
        s.hh += num(ins.coeficiente) * mult;
        if (!s.custoHora) s.custoHora = num(ins.custoUnitario);
        exato = true;
      }
      function rec(cod, mult, trilha) {
        var comp = A.obter(String(cod)); if (!comp || !comp.insumos) return;
        comp.insumos.forEach(function (ins) {
          var coef = num(ins.coeficiente);
          // comparacao crua com "H" quebraria com "h" (SICRO/SETOP) e o agente
          // dimensionaria equipe e prazo com ZERO hora-homem, sem erro na tela
          if (unKeyEx(ins.unidade) === "h" && ehMoPura(ins.descricao)) {
            soma(ins, mult);
          } else if (ins.tipo === "COMPOSICAO" && !ehMoPura(ins.descricao) && A.tem(ins.codigo) && !trilha[ins.codigo]) {
            trilha[ins.codigo] = 1; rec(ins.codigo, mult * coef, trilha); delete trilha[ins.codigo];
          }
        });
      }
      /* a PRÓPRIA: MO do SINAPI dentro dela conta; sub-composição SINAPI desce
         no analítico (a mesma recursão de cima, que traz o operador de uma CHP);
         sub-composição PRÓPRIA desce na própria. ⚠ Sub-composição de OUTRA base
         (SETOP, SICRO…) NÃO desce no analítico SINAPI: código numérico homônimo
         de outra base daria a hora-homem de outro serviço. A trilha usa "P:"
         para a própria e o código cru para o analítico — são espaços de nome
         diferentes, e um ciclo própria→própria não trava a aba. */
      function recP(comp, mult, trilha) {
        (Array.isArray(comp.insumos) ? comp.insumos : []).forEach(function (ins) {
          if (!ins) return;
          var coef = num(ins.coeficiente);
          if (unKeyEx(ins.unidade) === "h" && ehMoPura(ins.descricao)) { soma(ins, mult); return; }
          if (!ehComposicao(ins) || ehMoPura(ins.descricao) || !(coef > 0) || ins.codigo == null) return;
          var cod = String(ins.codigo), f = norm(ins.fonte);
          if (f === "PROPRIA") {
            var sub = P && P.obter(cod);
            if (sub && Array.isArray(sub.insumos) && !trilha["P:" + cod]) { trilha["P:" + cod] = 1; recP(sub, mult * coef, trilha); delete trilha["P:" + cod]; }
          } else if ((!f || f.indexOf("SINAPI") === 0) && A && A.tem && A.tem(cod) && !trilha[cod]) {
            trilha[cod] = 1; rec(cod, mult * coef, trilha); delete trilha[cod];
          }
        });
      }
      if (A && item.codigo != null && A.tem && A.tem(item.codigo)) {
        origem = "analitico";
        rec(item.codigo, qtd, {});
      } else if (P && item.codigo != null && String(item.codigo) !== "") {
        var cp = null;
        try { cp = P.obter(String(item.codigo)); } catch (eP) { cp = null; }
        if (cp && Array.isArray(cp.insumos)) {
          origem = "propria";
          var tr = {}; tr["P:" + String(item.codigo)] = 1;
          recP(cp, qtd, tr);
        }
      }
      return { prof: acc, exato: exato, origem: origem, propriaConsultada: !!P };
    },

    /* R$ de mão de obra orçada POR UNIDADE do item. Item que traz a separação
       (custoMO/MAT/EQ > 0) usa o que traz — exatamente a conta de antes. Item
       sem separação usa a proporção da composição que o hhDoItem leu (ver
       razaoMO). Devolve {valor, derivado}. */
    _moUnit: function (it, r, A) {
      var mo = num(it.custoMO);
      if (mo + num(it.custoMAT) + num(it.custoEQ) > 0) return { valor: mo, derivado: false };
      var comp = null;
      try {
        if (r && r.origem === "analitico" && A && A.obter) comp = A.obter(String(it.codigo));
        else if (r && r.origem === "propria") { var P = propriaDe(); comp = P ? P.obter(String(it.codigo)) : null; }
      } catch (e) { comp = null; }
      var rz = razaoMO(comp);
      return rz > 0 ? { valor: num(it.custoUnitario) * rz, derivado: true } : { valor: 0, derivado: false };
    },

    // custo/dia de uma profissão a partir dos colaboradores reais; fallback = custo-hora SINAPI × jornada.
    // Onera a diária de CLT pelos ENCARGOS PATRONAIS antes de comparar com a MO do SINAPI (que já é
    // ONERADA "COM ENCARGOS COMPLEMENTARES") — senão compara bruto (colab) com onerado (SINAPI) e a
    // "folga" mostrada é só o encargo que a empresa AINDA vai pagar. Diarista/autônomo/PJ pagam cheio.
    custoDiaProf: function (prof, custoHoraSinapi, params) {
      var col = params.colaboradores || [], jorn = num(params.jornadaH) || 8, divMes = num(params.diasUteisMes) || 22;
      var encFat = 1 + (num(params.encargosPct) || 0) / 100, valores = [], comEncargo = false;
      col.forEach(function (c) {
        if (c.status && c.status !== "ativo") return;
        var sc = scoreMatch(c.funcao, prof); if (sc < 40) return;
        var rem = num(c.remuneracao) || num(c.salario), u = String(c.unidadeRem || "mensal").toLowerCase(), dia; // demo/legado grava 'salario' (mensal)
        if (u === "diaria" || u === "diária") dia = rem;
        else if (u === "hora") dia = rem * jorn;
        else dia = rem / divMes; // mensal
        if (dia <= 0) return;
        // Onera SÓ o que é folha CLT (salário bruto). A diária de um diarista/autônomo/PJ JÁ é o custo
        // cheio da empresa. tipoContrato manda; sem ele, infere pela unidade (mensal=CLT presumido).
        var tc = String(c.tipoContrato || "").toLowerCase(), onera;
        if (/clt|mensal|efetiv|registrad/.test(tc)) onera = true;
        else if (/diarist|autonom|\bpj\b|empreit|terceir|avuls|hora/.test(tc)) onera = false;
        else onera = (u !== "diaria" && u !== "diária" && u !== "hora"); // sem tipoContrato: só mensal onera
        if (encFat > 1 && onera) { dia *= encFat; comEncargo = true; }
        valores.push(dia);
      });
      if (valores.length) {
        var media = valores.reduce(function (a, b) { return a + b; }, 0) / valores.length;
        return { valor: media, fonte: "real", n: valores.length, comEncargo: comEncargo };
      }
      var v = (num(custoHoraSinapi) || 0) * jorn;
      if (v <= 0) v = num(params.diariaMin) || 150; // profissão sem preço na base -> piso (senão MO deflaciona a 0)
      return { valor: v, fonte: "sinapi", n: 0 };
    },

    // Simulação completa. Retorna etapas com equipe por profissão, duração, custo,
    // + totais + reconciliação com o orçamento.
    simular: function (orc, override) {
      var self = this, C = this._C(), A = this._A();
      var params = {}; for (var k in this.DEFAULTS) params[k] = this.DEFAULTS[k];
      if (orc && orc.execucao && orc.execucao.params) for (k in orc.execucao.params) if (orc.execucao.params[k] != null) params[k] = orc.execucao.params[k];
      if (override) for (k in override) if (override[k] != null) params[k] = override[k];
      /* ⚠ O MESMO REGIME DO CRONOGRAMA (Cronograma.diasSemanaEfetivo): a aba
         Execução aceitava 1 a 7, as datas saíam de `addDiasUteis` (que só
         conhece 5, 6 e 7) e o `prazoSemanas` dividia pelo número digitado —
         o "conserto que para no segundo consumidor". Sem o Cronograma
         injetado (testes antigos), fica como era. */
      if (C && C.diasSemanaEfetivo) params.diasUteisSemana = C.diasSemanaEfetivo(params.diasUteisSemana);
      var jorn = num(params.jornadaH) || 8;

      // diária de referência p/ converter MO-R$ estimada em homens-dia (servente real ou fallback)
      var diariaRef = self.custoDiaProf("SERVENTE", 0, params).valor || 220;

      /* ⚠ ETAPA OPCIONAL FORA DO PRAZO — A DECISÃO É DO CRONOGRAMA (13/09/2026).
         A aba Cronograma tem "contar opcionais no prazo" e grava
         `orc.cronograma.params.opcionaisNoPrazo = false`; o motor dela tira a
         etapa opcional da rede. A Execução ignorava e empilhava as opcionais
         na cascata: MEDIDO na obra de demonstração, as 4 opcionais somavam 19
         dos 146 dias úteis e empurravam a entrega para 02/03/2027, enquanto o
         Cronograma da mesma obra não as contava. É a mesma regra dos feriados
         logo abaixo: duas telas dando datas diferentes para a mesma obra é
         pior que as duas errarem igual. Só `=== false` desliga — o padrão do
         motor do cronograma é LIGADO (js/cronograma.js, DEFAULTS). A etapa
         continua com equipe, duração e custo (se contratada, é isso que ela
         pede); só não entra na cascata nem nas datas. */
      var cpO = (orc && orc.cronograma && orc.cronograma.params) || {};
      var opcFora = cpO.opcionaisNoPrazo === false;
      var moDerivadoTot = 0, nMODerivado = 0;

      // 1) por etapa: agrega Hh por profissão (exato) + MO-R$ estimada (fallback honesto) +
      //    marca itens de base estadual/própria SEM custo de MO (GOINFRA/SEINFRA só têm preço total).
      var etapas = (orc.etapas || []).map(function (e) {
        var prof = {}, moEstimR = 0, hdEstim = 0, custoDireto = 0, nComQtd = 0, nExatos = 0, orcadoMOExato = 0, custoSemBaseMO = 0, nSemBaseMO = 0;
        var fl = folhasDe(e); // null = etapa sem subetapa com item (ela mesma é a folha)
        (e.itens || []).forEach(function (it) {
          var q = num(it.quantidade);
          custoDireto += q * num(it.custoUnitario);
          var r = self.hhDoItem(it, A);
          /* MO orçada: a do item quando ele traz a separação (a conta de sempre);
             senão a proporção da composição lida (ver _moUnit). */
          var mu = (q > 0) ? self._moUnit(it, r, A) : { valor: 0, derivado: false };
          if (q > 0 && mu.derivado && !it.qtdPendente) { moDerivadoTot += q * mu.valor; nMODerivado++; }
          if (q > 0) { nComQtd++; if (r.exato) { nExatos++; orcadoMOExato += q * mu.valor; } } // MO orçada só da porção com Hh
          if (r.exato) {
            for (var p in r.prof) { var s = prof[p] || (prof[p] = { hh: 0, custoHora: 0 }); s.hh += r.prof[p].hh; if (!s.custoHora) s.custoHora = r.prof[p].custoHora; }
          } else if (q > 0) {
            // item sem coeficiente SINAPI: MO estimada = o PRÓPRIO custoMO do orçamento (R$).
            // NÃO fabrica homem-hora p/ material/verba puros. Se custoMO=0 (base estadual GOINFRA/
            // SEINFRA, que só grava preço total) NÃO dá p/ estimar MO -> marca "sem base de MO" em
            // vez de colapsar o prazo a 1 dia e mostrar equipe em branco como se fosse verdade.
            var moR = num(it.custoMO) * q;
            if (moR > 0) { moEstimR += moR; hdEstim += moR / diariaRef; }
            else { custoSemBaseMO += q * num(it.custoUnitario); nSemBaseMO++; }
          }
          // aditivo: o MESMO r do item vai para a folha dele; nada acima muda
          if (fl) acumFolha(fl.de(it), it, q, r, diariaRef);
        });
        var catO = (C && C.classificar) ? C.classificar((e.itens && e.itens[0] && e.itens[0].descricao) || e.nome) : null;
        return {
          id: e.id, codigo: e.codigo, nome: e.nome,
          categoria: catO ? catO.id : "outros", cor: catO ? catO.cor : "#94a3b8",
          prof: prof, moEstimR: moEstimR, homensDiaEstim: hdEstim, custoDireto: custoDireto,
          nComQtd: nComQtd, nExatos: nExatos, orcadoMOExato: orcadoMOExato,
          custoSemBaseMO: custoSemBaseMO, nSemBaseMO: nSemBaseMO,
          folhas: fl ? fl.lista : [], // espec 1.5 — campo NOVO; [] = a etapa é a própria folha
          opcional: !!e.opcional, foraDoPrazo: opcFora && !!e.opcional // ver o ⚠ da etapa opcional acima
        };
      });

      // 2) homens-dia por profissão + duração natural. Etapa SEM base de MO (nem Hh, nem MO-R$)
      //    é NÃO-ESTIMÁVEL: duração 0 (não colapsa o prazo p/ 1 dia, e some da conta com aviso).
      etapas.forEach(function (et) {
        var maxHomDia = 0;
        for (var p in et.prof) { var hd = et.prof[p].hh / jorn; et.prof[p].homensDia = hd; if (hd > maxHomDia) maxHomDia = hd; }
        if (et.homensDiaEstim > maxHomDia) maxHomDia = et.homensDiaEstim;
        et.temBaseMO = maxHomDia > 0; // tem produtividade (SINAPI) OU MO-R$ estimada?
        et.duracaoNatural = et.temBaseMO ? Math.max(1, Math.ceil(maxHomDia)) : 0;
      });

      // 3) sequência natural (cascata c/ paralelismo) -> prazo natural
      /* ⚠ `prev` é a etapa anterior QUE ESTÁ NO PRAZO. Sem opcional fora, é
         exatamente etapas[i-1] — a conta de sempre (a paridade com o master em
         tools/test-execucao-folhas.js cobra). A opcional fora fica sem _ini/_fim
         e a seguinte encosta na anterior a ela, como o elo padrão do Cronograma. */
      function sequencia(dursKey) {
        var t = 0, prev = null;
        etapas.forEach(function (et) {
          if (et.foraDoPrazo) { et._ini = null; et._fim = null; return; }
          var dur = et[dursKey];
          if (!prev) et._ini = 0; else { var ov = Math.floor((num(params.paralelismo) || 0) * prev[dursKey]); et._ini = Math.max(0, prev._ini + prev[dursKey] - ov); }
          et._fim = et._ini + dur; if (et._fim > t) t = et._fim;
          prev = et;
        });
        return t;
      }
      var prazoNatural = sequencia("duracaoNatural");

      // 4) alvo de prazo? dimensiona equipe por profissão p/ caber (fator por etapa)
      var prazoAlvo = null;
      if (params.dataInicio && params.dataEntrega && C && C.addDiasUteis) {
        prazoAlvo = self._diasUteisEntre(params.dataInicio, params.dataEntrega, params.diasUteisSemana, C);
      }
      var modo = prazoAlvo && prazoAlvo > 0 ? "prazo" : "equipe";
      // duração-alvo por etapa: se há prazoAlvo, comprime proporcional à duração natural
      var fatorGlobal = (modo === "prazo" && prazoNatural > 0) ? Math.min(1, prazoAlvo / prazoNatural) : 1;
      // folhas: mesma fórmula e mesmo fator da etapa (só leem jorn/fatorGlobal; não entram na cascata da etapa)
      etapas.forEach(function (et) { et.folhas.forEach(function (f) { fecharFolha(f, jorn, fatorGlobal); }); });

      etapas.forEach(function (et) {
        var durAlvo = et.temBaseMO ? Math.max(1, Math.round(et.duracaoNatural * fatorGlobal)) : 0;
        et.duracao = durAlvo;
        et.equipe = {}; et.custoMO = 0; et.custoMOReal = 0; et.orcadoMOReal = 0; et.custoMORealSemBase = 0;
        var div = durAlvo || 1; // guarda: etapa não-estimável não entra neste loop (prof vazio), mas evita /0
        for (var p in et.prof) {
          var s = et.prof[p];
          var q = Math.max(1, Math.ceil(s.homensDia / div)); // pessoas dessa profissão p/ caber
          var cd = self.custoDiaProf(p, s.custoHora, params);
          s.equipe = q; s.custoDia = cd.valor; s.fonteCusto = cd.fonte; s.comEncargo = !!cd.comEncargo;
          s.custo = s.homensDia * cd.valor;                 // custo pelo CONTEÚDO de trabalho (equipe eficiente)
          s.orcadoProf = s.hh * (num(s.custoHora) || 0);    // MO orçada (SINAPI onerado) desta profissão
          et.equipe[p] = q; et.custoMO += s.custo;
          // RECONCILIAÇÃO só sobre a profissão com DIÁRIA REAL E com orçado-SINAPI > 0. No fallback SINAPI
          // custo≡orçado (tautologia). E se a linha de MO do SINAPI tem custoUnitario=0 (14 linhas na base
          // MG real, ex.: MONTADOR DE FÔRMAS), orcadoProf=0 e somar só o custo real inflaria o desvio e
          // inverteria o veredito — então fica FORA de ambos (rastreado à parte como "sem base p/ comparar").
          if (cd.fonte === "real") {
            if (s.orcadoProf > 0) { et.custoMOReal += s.custo; et.orcadoMOReal += s.orcadoProf; }
            else { et.custoMORealSemBase += s.custo; }
          }
        }
        // parcela ESTIMADA (itens sem SINAPI mas com custoMO): custo = MO-R$ da própria base (não subvaloriza)
        if (et.moEstimR > 0) {
          et.equipeEstim = Math.max(1, Math.ceil(et.homensDiaEstim / div));
          et.custoMOEstim = et.moEstimR;
          et.custoMO += et.custoMOEstim;
        }
      });
      var prazoFinal = sequencia("duracao");

      // datas
      var ini = params.dataInicio ? new Date(params.dataInicio + "T00:00:00") : new Date();
      /* ⚠ OS MESMOS FERIADOS DO CRONOGRAMA. Duas telas do mesmo app dando
         datas diferentes para a mesma obra e pior que as duas errarem igual:
         quem compara acha que uma delas esta com defeito e nao sabe qual. Os
         parametros de feriado moram no cronograma do orcamento — a Execucao
         nao tem interruptor proprio, ela segue o que foi decidido la. */
      var ferE = (C && C._feriadosDe) ? C._feriadosDe(self._paramsFeriado(orc), ini, prazoFinal) : { mapa: {} };
      if (C && C.addDiasUteis) {
        var giroE = 0;
        while (C.diaUtil && !C.diaUtil(ini, params.diasUteisSemana, ferE.mapa) && giroE++ < 40) ini.setDate(ini.getDate() + 1);
        etapas.forEach(function (et) {
          // opcional fora do prazo não tem data: inventar uma seria pôr no calendário o que o Cronograma tirou
          if (et.foraDoPrazo) { et.dataInicio = null; et.dataFim = null; return; }
          et.dataInicio = C.addDiasUteis(ini, et._ini, params.diasUteisSemana, ferE.mapa); et.dataFim = C.addDiasUteis(ini, et._fim, params.diasUteisSemana, ferE.mapa);
        });
      }

      // 5) equipe de PICO + custos. Separa: EXATO (profissões SINAPI), REAL (só profissões com
      //    diária cadastrada — base da reconciliação) e SEM-BASE (itens estaduais sem custoMO).
      var equipePico = {}, custoMOTotal = 0, custoMOExato = 0, orcadoMOExato = 0, custoMOReal = 0, orcadoMOReal = 0, custoMORealSemBaseTot = 0;
      var coberturaN = 0, coberturaTot = 0, houveEncargo = false, nEtapasComBase = 0, nEtapasSemBase = 0, custoSemBaseMOTot = 0;
      etapas.forEach(function (et) {
        custoMOTotal += et.custoMO; coberturaN += et.nExatos; coberturaTot += et.nComQtd; orcadoMOExato += et.orcadoMOExato;
        custoMOReal += et.custoMOReal || 0; orcadoMOReal += et.orcadoMOReal || 0; custoSemBaseMOTot += et.custoSemBaseMO || 0; custoMORealSemBaseTot += et.custoMORealSemBase || 0;
        if (et.temBaseMO) nEtapasComBase++; else nEtapasSemBase++;
        for (var p in et.prof) { custoMOExato += et.prof[p].custo || 0; if (et.prof[p].comEncargo) houveEncargo = true; }
        for (var pp in et.equipe) equipePico[pp] = Math.max(equipePico[pp] || 0, et.equipe[pp]);
        if (et.equipeEstim) equipePico["equipe geral (estimada)"] = Math.max(equipePico["equipe geral (estimada)"] || 0, et.equipeEstim);
      });

      /* 5b) PICO SIMULTÂNEO DE VERDADE.
         ⚠ `equipePico` é o MAIOR número de cada profissão em ALGUMA etapa — e a
         tela o rotulava "máximo simultâneo no canteiro". MEDIDO na obra de
         demonstração: 23 profissões com "1×" cada, que nunca estiveram juntas
         (com sobreposição 0 as etapas vêm uma depois da outra; a maior etapa
         tinha 13). Quem dimensiona vestiário e refeitório por esse número
         pede 23 vagas para 13 pessoas. `equipePico` fica como está (a lista de
         profissões que a obra pede); o simultâneo é contado aqui, dia a dia da
         cascata: o pico só pode começar no início de alguma etapa, então basta
         medir nesses dias. Etapa fora do prazo (opcional) e não estimável não
         estão na linha do tempo e não entram. */
      var picoSimultaneo = null;
      etapas.forEach(function (et0) {
        if (et0.foraDoPrazo || !(et0.duracao > 0) || et0._ini == null) return;
        var k = et0._ini, n = 0, comp = {}, nomes = [];
        etapas.forEach(function (et) {
          if (et.foraDoPrazo || !(et.duracao > 0) || et._ini == null || !(et._ini <= k && k < et._fim)) return;
          nomes.push(et.nome);
          for (var p in et.equipe) { n += et.equipe[p]; comp[p] = (comp[p] || 0) + et.equipe[p]; }
          if (et.equipeEstim) { n += et.equipeEstim; comp["equipe geral (estimada)"] = (comp["equipe geral (estimada)"] || 0) + et.equipeEstim; }
        });
        if (!picoSimultaneo || n > picoSimultaneo.pessoas) {
          picoSimultaneo = { pessoas: n, dia: k, etapas: nomes, equipe: comp,
            data: (C && C.addDiasUteis) ? C.addDiasUteis(ini, k, params.diasUteisSemana, ferE.mapa) : null };
        }
      });

      // 6) reconciliação SÓ sobre a porção com DIÁRIA REAL (real×orçado-SINAPI da mesma profissão).
      //    Sem colaborador que case a profissão, o custo cai no fallback SINAPI (custo≡orçado) e o
      //    "0% dentro do orçado" seria SINAPI comparado consigo mesmo — mentira verde. status "sem-base".
      var temDiariaReal = orcadoMOReal > 0;
      var reconConfiavel = temDiariaReal;
      var tol = num(params.toleranciaPct) || 5;
      var desvio = reconConfiavel ? (custoMOReal - orcadoMOReal) : 0;
      var desvioPct = reconConfiavel ? (desvio / orcadoMOReal) * 100 : 0;
      var status = !reconConfiavel ? "sem-base" : (Math.abs(desvioPct) <= tol ? "dentro" : (desvioPct > 0 ? "acima" : "abaixo"));
      // cobertura da RECONCILIAÇÃO = quanto da MO-SINAPI tem diária real (NÃO arredonda antes do corte)
      /* ⚠ ESTE NÚMERO PASSA DE 100, E ISSO NÃO É DEFEITO NOVO (revisão 3,
         13/09/2026). As duas pontas são réguas DIFERENTES: `orcadoMOReal` é
         Hh × custo-hora da linha de MO do SINAPI, e `orcadoMOExato` é quantidade
         × MO do PREÇO do item (o custoMO dele, ou a proporção da composição —
         `_moUnit`). A revisão viu 100,1% num orçamento real; o master já dava
         até 576% no corpus gerado de tools/test-execucao-folhas.js.
         NÃO foi cortado em 100 de propósito: a única tela que o escreve (js/ui.js,
         "Cobre só X% do custo de MO-SINAPI") só aparece com `coberturaBaixa`,
         ou seja, abaixo de `coberturaMin` (55) — acima disso ele nunca chega ao
         usuário, e cortar mudaria 16 casos da paridade sem mudar uma tela.
         O bloco 4b daquela suíte escreve o 105,47 esperado. */
      var reconCobPct = orcadoMOExato > 0 ? (orcadoMOReal / orcadoMOExato) * 100 : 0;
      var coberturaBaixa = reconConfiavel && reconCobPct < (num(params.coberturaMin) || 55);
      var semBaseMO = nEtapasComBase === 0;             // NENHUMA etapa dimensionável (100% estadual/sem MO)
      var coberturaPct = coberturaTot > 0 ? Math.round(coberturaN / coberturaTot * 100) : 0; // % itens com Hh SINAPI
      // orçado total (todos os itens) só p/ exibição de contexto
      var orcadoMOTotal = 0;
      if (typeof Orcamento !== "undefined" && Orcamento.totais) { try { orcadoMOTotal = num(Orcamento.totais(orc).mo); } catch (e) {} }
      if (!orcadoMOTotal) { (orc.etapas || []).forEach(function (e) { (e.itens || []).forEach(function (it) { orcadoMOTotal += num(it.custoMO) * num(it.quantidade); }); }); }
      /* + a MO dos itens que não trazem separação, pela proporção da composição
         (ver _moUnit). Eles entram com custoMO 0 nas duas somas acima, então
         não há conta em dobro. Sai à parte em `orcadoMODerivado` para a tela
         dizer de onde veio o número. */
      orcadoMOTotal += moDerivadoTot;

      var entregaInvalida = !!(params.dataEntrega && (!prazoAlvo || prazoAlvo <= 0));
      var metaAtingida = (modo !== "prazo" || semBaseMO) ? null : (prazoFinal <= prazoAlvo + 0.5);
      var ranking = etapas.slice().sort(function (a, b) { return b.custoMO - a.custoMO; }).slice(0, 5)
        .map(function (e) { return { nome: e.nome, custoMO: Math.round(e.custoMO), duracao: e.duracao }; });

      var sugestoes = [];
      if (semBaseMO) {
        sugestoes.push("Este orçamento não tem coeficientes de mão-de-obra (base estadual GOINFRA/SEINFRA/própria, ou itens sem custo de MO). O agente não consegue dimensionar equipe nem prazo por aqui — use itens com composição SINAPI, ou informe a produtividade manualmente. Os valores abaixo NÃO são uma estimativa de obra.");
      } else if (!reconConfiavel) {
        if (orcadoMOExato > 0) sugestoes.push("Há itens SINAPI, mas nenhuma DIÁRIA REAL cadastrada no RH que case as profissões — o custo simulado usou a própria referência SINAPI (comparar SINAPI × SINAPI daria sempre 0%). Cadastre sua equipe em RH para checar custo real × orçado.");
        else sugestoes.push("Nenhum item com composição SINAPI para reconciliar o custo de MO — a base é própria/estadual. O prazo/equipe abaixo saem das quantidades e da MO-R$ do orçamento; para checar custo × orçado, use itens SINAPI + equipe no RH.");
      } else if (status === "acima") {
        sugestoes.push("A mão-de-obra com diária real está " + desvioPct.toFixed(1) + "% ACIMA do orçado (na porção reconciliável). Foque nas etapas de maior custo (abaixo).");
        sugestoes.push("Opções: renegociar a diária das profissões mais caras, aumentar produtividade, ou repassar o excedente ao BDI/contrato.");
      } else if (status === "abaixo") {
        sugestoes.push("A MO com diária real está " + Math.abs(desvioPct).toFixed(1) + "% ABAIXO do orçado" + (houveEncargo ? " (já com os encargos patronais de " + (num(params.encargosPct) || 0) + "% aplicados às suas diárias CLT)." : ". ⚠ Confira se as diárias no RH já incluem os encargos — senão a folga pode ser só o encargo a pagar."));
        sugestoes.push("Se a folga for real, dá pra adiantar o prazo (mais frentes) ou guardar como contingência.");
      } else {
        sugestoes.push("A MO com diária real fecha DENTRO do orçado (desvio " + desvioPct.toFixed(1) + "%, na porção reconciliável). Coerente com o previsto.");
      }
      if (coberturaBaixa) sugestoes.push("⚠ Reconciliação PARCIAL: só " + Math.round(reconCobPct) + "% do custo de MO-SINAPI tem diária real cadastrada. O veredito vale só p/ essa parte — cadastre as demais profissões no RH.");
      if (custoMORealSemBaseTot > 0) sugestoes.push("⚠ Algumas profissões têm diária real cadastrada mas a linha de MO do SINAPI vem sem preço (custo-hora 0) — R$ " + Math.round(custoMORealSemBaseTot) + " de custo real ficaram FORA do veredito por não haver orçado-SINAPI p/ comparar.");
      if (nEtapasSemBase > 0 && !semBaseMO) sugestoes.push("⚠ " + nEtapasSemBase + " etapa(s) de base estadual sem coeficiente de MO NÃO entram no prazo nem na equipe (aparecem como “não estimável”). O prazo/equipe cobrem só o restante.");
      if (entregaInvalida) sugestoes.push("⚠ Data de entrega inválida (anterior ao início) — ignorada; mostrando o prazo natural da obra.");
      else if (modo === "prazo" && !semBaseMO) {
        if (metaAtingida) { if (prazoNatural > prazoAlvo) sugestoes.push("Para bater a entrega, a equipe foi reforçada (veja a equipe de pico). Sem reforço, a obra levaria ~" + prazoNatural + " dias úteis."); }
        else sugestoes.push("⚠ A data de entrega NÃO é alcançável com este dimensionamento: o mínimo é ~" + prazoFinal + " dias úteis (você pediu " + prazoAlvo + "). Reveja o escopo, o paralelismo, ou a data.");
      }

      /* RECADOS NOVOS (13/09/2026) — numa chave própria, e não em `sugestoes`,
         porque o texto de `sugestoes` é cobrado bit a bit contra o master em
         tools/test-execucao-folhas.js (a trava das 38 instalações). A tela
         mostra os dois.
         ⚠ O PRIMEIRO É O QUE FALTAVA: sem entrega desejada, cada profissão
         entra com UMA pessoa por etapa e as etapas vêm em fila. MEDIDO na obra
         de demonstração: 146 dias úteis na aba Execução contra 62 no
         Cronograma da mesma obra — e o número saía como "o prazo", sem dizer
         a premissa. O revisor leu como defeito de conta; é premissa calada. */
      var recados = [], nOpcFora = 0, diasOpcFora = 0;
      etapas.forEach(function (et) { if (et.foraDoPrazo) { nOpcFora++; diasOpcFora += num(et.duracao); } });
      if (modo === "equipe" && !semBaseMO) {
        recados.push("Este prazo usa a equipe MÍNIMA: 1 pessoa de cada profissão em cada etapa, e as etapas uma depois da outra (sobreposição de " + Math.round((num(params.paralelismo) || 0) * 100) + "%). Não é o prazo do Cronograma. Para o agente dizer quantas pessoas de cada profissão cabem numa data, preencha “Entrega desejada” e clique em Recalcular.");
      }
      if (nOpcFora > 0) {
        recados.push(nOpcFora + " etapa(s) opcional(is) ficaram FORA do prazo, como no Cronograma (lá, “contar opcionais no prazo” está desligado). Se forem contratadas, pedem mais ~" + diasOpcFora + " dia(s) útil(eis) de trabalho com a equipe mínima.");
      }
      if (nMODerivado > 0) {
        recados.push("A MO orçada de " + nMODerivado + " item(ns) saiu da PROPORÇÃO de mão de obra da composição (R$ " + Math.round(moDerivadoTot) + "): a base de preços desses itens não separa mão de obra de material, e a proporção vem da composição analítica ou própria que foi lida.");
      }

      return {
        picoSimultaneo: picoSimultaneo, recados: recados,
        orcadoMODerivado: moDerivadoTot, nItensMODerivado: nMODerivado,
        etapas: etapas, params: params, modo: modo, metaAtingida: metaAtingida, entregaInvalida: entregaInvalida,
        prazoNatural: prazoNatural, prazoAlvo: prazoAlvo, prazoDias: prazoFinal,
        prazoSemanas: Math.max(1, Math.ceil(prazoFinal / (num(params.diasUteisSemana) || 5))),
        dataInicio: ini, dataFim: (C && C.addDiasUteis) ? C.addDiasUteis(ini, prazoFinal, params.diasUteisSemana, ferE.mapa) : null,
        equipePico: equipePico,
        custoMOSimulado: custoMOTotal, orcadoMO: orcadoMOTotal,
        custoMOExato: custoMOExato, orcadoMOExato: orcadoMOExato,
        custoMOReal: custoMOReal, orcadoMOReal: orcadoMOReal, temDiariaReal: temDiariaReal,
        reconConfiavel: reconConfiavel, coberturaBaixa: coberturaBaixa, reconCobPct: reconCobPct,
        semBaseMO: semBaseMO, nEtapasSemBase: nEtapasSemBase, custoSemBaseMO: custoSemBaseMOTot, custoMORealSemBase: custoMORealSemBaseTot,
        desvio: desvio, desvioPct: desvioPct, status: status, tolerancia: tol,
        rankingCusto: ranking, sugestoes: sugestoes,
        cobertura: { exatos: coberturaN, total: coberturaTot, pct: coberturaPct }
      };
    },

    // Aplica as durações do agente no objeto cronograma COM PROVENIÊNCIA (Node-testável).
    // Só grava etapa fundamentada (temBaseMO && duracao>0) e marca em duracoesAgente. Se uma etapa
    // antes gravada pelo agente virou "não estimável", REMOVE o valor stale (senão ressurgiria como
    // override "editado" falso no Gantt/Curva-S/Excel/proposta). Edição MANUAL do usuário (não marcada
    // em duracoesAgente) é preservada. Retorna {enviadas, puladas}.
    //
    // opts.rede === true (cronograma executivo, espec 1.5): ver _aplicarRede.
    // ⚠ Sem opts.rede === true o caminho é o de ANTES, linha por linha, e devolve
    // o MESMO objeto {enviadas, puladas} — tools/test-execucao-folhas.js compara
    // contra a cópia do master b8907ef. Qualquer valor diferente de `true`
    // (inclusive "true" em texto) fica no caminho antigo: na dúvida, não muda data.
    aplicarNoCronograma: function (cron, etapas, opts) {
      /* ⚠ planejador 1A (§2.10): a etapa com rede digitada ou com escolha
         pendente não recebe a duração por aqui — vai em `travadas` com o
         motivo. Sem nenhuma trava, o caminho e o retorno de sempre. */
      var Cr = (typeof global !== "undefined" && global.Cronograma) ? global.Cronograma : null, travadas = [];
      if (Cr && typeof Cr.travaGravador === "function" && cron && typeof cron === "object") {
        var soltas = [];
        (etapas || []).forEach(function (et) {
          var mt = et ? Cr.travaGravador(cron, et.id, "etapa", (opts && opts.orc) || null) : null;
          if (mt) travadas.push({ etapaId: et.id, motivo: mt }); else soltas.push(et);
        });
        if (travadas.length) {
          var rT = this.aplicarNoCronograma(cron, soltas, opts);
          rT.puladas += travadas.length;
          rT.travadas = travadas;
          return rT;
        }
      }
      if (opts && opts.rede === true) return this._aplicarRede(cron, etapas);
      cron.duracoes = cron.duracoes || {};
      cron.duracoesAgente = cron.duracoesAgente || {};
      cron.iaMotivos = cron.iaMotivos || {};
      var nEnv = 0, lista = etapas || [];
      lista.forEach(function (et) {
        if (et.temBaseMO && num(et.duracao) > 0) {
          cron.duracoes[et.id] = et.duracao; cron.duracoesAgente[et.id] = "exec";
          if (cron.iaMotivos[et.id]) delete cron.iaMotivos[et.id]; // a duração deste agente substitui o motivo antigo da IA
          nEnv++;
        } else if (cron.duracoesAgente[et.id] === "exec") {
          // só remove o que ESTE agente (exec) gravou e ficou stale. NÃO toca em edição manual do
          // usuário (sem marca) nem em estimativa da IA (marca "ia") — a IA consegue estimar etapa estadual.
          delete cron.duracoes[et.id]; delete cron.duracoesAgente[et.id];
          if (cron.iaMotivos[et.id]) delete cron.iaMotivos[et.id];
        }
      });
      return { enviadas: nEnv, puladas: lista.length - nEnv };
    },

    /* MODO EXECUTIVO — a duração da etapa COM folhas é o vão da rede interna
     * (Cronograma.materializar grava duracoes[etapa] com a marca "subetapas").
     * Gravar o Hh da ETAPA ali seria sobrescrito no próximo persistir, e o
     * toast "N etapas aplicadas" contaria um número que não chega à tela — o
     * defeito que a crítica de compatibilidade achou. Por isso:
     *   - etapa COM folhas: NÃO toca no mapa de etapa; vai em `puladas` com o
     *     motivo "duração vem das subetapas", e cada folha é gravada no mapa
     *     cron.sub (nunca em cron.duracoes — invariante I3);
     *   - etapa SEM folhas (é a própria folha): a regra de hoje, no mapa de etapa.
     * Regra por folha:
     *   - com base (temBaseMO e duração > 0): grava sub.duracoes[id] e
     *     sub.agente[id] = "exec" e apaga sub.iaMotivos[id] — SE a casa estiver
     *     vazia ou já for do "exec";
     *   - ⚠ duração que a PESSOA digitou (sem marca) ou que veio da IA ("ia",
     *     que no fluxo novo passou pelo diff que a pessoa aprovou) NÃO é
     *     sobrescrita: vai em `folhasPreservadas` com o motivo. É aqui que isto
     *     diverge do mapa de etapa (onde o envio sobrescreve tudo desde antes):
     *     no mapa novo não há comportamento antigo a manter, e sobrescrever a
     *     decisão de alguém sem desfazer é a perda que não se recupera — deixar
     *     de aplicar se recupera limpando a edição e enviando de novo;
     *   - sem base: apaga só o que o PRÓPRIO "exec" gravou (valor velho); manual
     *     e "ia" ficam — a mesma limpeza de hoje.
     * Devolve contagens VERDADEIRAS para o toast:
     *   {enviadas, puladas, folhasEnviadas, folhasPuladas, folhasPreservadas,
     *    detalhe:[{id, tipo:"etapa"|"folha", etapaId, motivo, dias?}]}
     * com enviadas + puladas === nº de etapas e folhasEnviadas + folhasPuladas +
     * folhasPreservadas === nº de folhas. */
    _aplicarRede: function (cron, etapas) {
      cron.duracoes = mapaObj(cron.duracoes);
      cron.duracoesAgente = mapaObj(cron.duracoesAgente);
      cron.iaMotivos = mapaObj(cron.iaMotivos);
      var sub = cron.sub = mapaObj(cron.sub);
      sub.duracoes = mapaObj(sub.duracoes);
      sub.agente = mapaObj(sub.agente);
      if (sub.iaMotivos != null) sub.iaMotivos = mapaObj(sub.iaMotivos);
      var res = { enviadas: 0, puladas: 0, folhasEnviadas: 0, folhasPuladas: 0, folhasPreservadas: 0, detalhe: [] };
      (etapas || []).forEach(function (et) {
        var folhas = (Array.isArray(et.folhas) ? et.folhas : []).filter(function (f) { return f && f.id && f.id !== et.id; });
        if (folhas.length) {
          res.puladas++;
          res.detalhe.push({ id: et.id, tipo: "etapa", etapaId: et.id, motivo: MOTIVO_SUBETAPAS });
          folhas.forEach(function (f) {
            var dias = num(f.duracao != null ? f.duracao : f.duracaoNatural);
            var marca = sub.agente[f.id], temValor = num(sub.duracoes[f.id]) > 0;
            if (f.temBaseMO && dias > 0) {
              if (temValor && marca !== "exec") {
                res.folhasPreservadas++;
                res.detalhe.push({ id: f.id, tipo: "folha", etapaId: et.id, dias: num(sub.duracoes[f.id]),
                  motivo: marca === "ia" ? "definida pela IA" : (marca ? "definida por outra fonte (" + marca + ")" : "definida por você") });
                return;
              }
              sub.duracoes[f.id] = dias; sub.agente[f.id] = "exec";
              if (sub.iaMotivos && sub.iaMotivos[f.id]) delete sub.iaMotivos[f.id];
              res.folhasEnviadas++;
            } else {
              if (marca === "exec") {
                delete sub.duracoes[f.id]; delete sub.agente[f.id];
                if (sub.iaMotivos && sub.iaMotivos[f.id]) delete sub.iaMotivos[f.id];
              }
              res.folhasPuladas++;
              res.detalhe.push({ id: f.id, tipo: "folha", etapaId: et.id, motivo: MOTIVO_SEM_BASE });
            }
          });
          return;
        }
        // etapa sem folhas: exatamente a regra do caminho antigo, no mapa de etapa
        if (et.temBaseMO && num(et.duracao) > 0) {
          cron.duracoes[et.id] = et.duracao; cron.duracoesAgente[et.id] = "exec";
          if (cron.iaMotivos[et.id]) delete cron.iaMotivos[et.id];
          res.enviadas++;
        } else {
          if (cron.duracoesAgente[et.id] === "exec") {
            delete cron.duracoes[et.id]; delete cron.duracoesAgente[et.id];
            if (cron.iaMotivos[et.id]) delete cron.iaMotivos[et.id];
          }
          res.puladas++;
          res.detalhe.push({ id: et.id, tipo: "etapa", etapaId: et.id, motivo: MOTIVO_SEM_BASE });
        }
      });
      return res;
    },

    /* os parametros de feriado vivem no cronograma do orcamento; a Execucao
       so os le. Sem cronograma gravado, valem os DEFAULTS (desconto ligado). */
    _paramsFeriado: function (orc) {
      var cp = (orc && orc.cronograma && orc.cronograma.params) || {};
      return {
        diasUteisSemana: cp.diasUteisSemana || 5,
        descontarFeriados: cp.descontarFeriados !== false,
        feriadosFacultativos: cp.feriadosFacultativos !== false,
        feriadosExtras: cp.feriadosExtras || null
      };
    },

    _diasUteisEntre: function (ini, fim, diasSemana, C) {
      var a = new Date(ini + "T00:00:00"), b = new Date(fim + "T00:00:00"); if (b <= a) return 0;
      var n = 0, d = new Date(a.getTime());
      while (d < b) { d.setDate(d.getDate() + 1); var wd = d.getDay(); if (diasSemana >= 7) n++; else if (diasSemana === 6) { if (wd !== 0) n++; } else { if (wd !== 0 && wd !== 6) n++; } }
      return n;
    }
  };

  global.Execucao = Execucao;
  if (typeof module !== "undefined" && module.exports) module.exports = Execucao;
})(typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this));
