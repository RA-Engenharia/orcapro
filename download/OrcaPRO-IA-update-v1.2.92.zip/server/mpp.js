/* =====================================================================
 * mpp.js — PONTE .mpp: quem gera o arquivo é o MS Project DO CLIENTE.
 *
 * POR QUE EXISTE. O cliente pede o cronograma "em Project". O que o app sabe
 * escrever é MSPDI (`js/msproject.js`) — XML, que o Project abre, mas que o
 * duplo clique manda para o navegador e que só aparece no seletor de arquivos
 * depois de trocar o filtro para "Todos os arquivos". Gerar `.mpp` em
 * JavaScript é impossível: o formato é binário, fechado, e a referência do
 * assunto (MPXJ) diz na própria FAQ que não escreve MPP. O único escritor sem
 * o Project instalado é comercial (Aspose.Tasks, licença OEM).
 *
 * O CAMINHO QUE FUNCIONA, e foi MEDIDO nesta máquina em 11/09/2026: dirigir o
 * Project instalado por COM — FileNew → Tasks.Add → Duration → TaskDependencies
 * → FileSaveAs — e reabrir o arquivo pelo próprio Project. Saiu um .mpp de
 * 263.680 bytes com assinatura OLE, que reabriu com as 23 tarefas, a hierarquia
 * e os 11 elos do XML de origem. Nada disso passa pelo assistente de importação
 * (o modal que já matou a tentativa de ABRIR o XML por COM, em 03/09).
 *
 * ⚠ A REDE VEM DO XML, NÃO DAQUI. Este arquivo NÃO recalcula nada: lê o MSPDI
 *   que `js/msproject.js` gerou e manda o Project montar o MESMO cronograma.
 *   Recalcular aqui criaria duas verdades — a do PDF que o cliente recebeu e a
 *   do Project — e a do contratante é a que ele lê.
 *
 * ⚠ O QUE ATRAVESSA A PONTE, ITEM A ITEM (12/09/2026). Até esta revisão só
 *   atravessavam nome, hierarquia, duração, marco, restrição, elo e calendário
 *   — e o cabeçalho dizia "o MESMO cronograma", o que era falso: o .mpp saía
 *   com R$ 0,00 de custo, 0 h de trabalho, nenhum recurso, nenhuma barra de
 *   base e nenhum percentual, justamente o que o XML enriquecido acabara de
 *   ganhar. Medido no .mpp reaberto pelo Project: soma de TODOS os Cost = 0,00.
 *   Hoje atravessam também, cada um com o seu contador conferido na releitura:
 *     · dinheiro   — <FixedCost> do XML  -> Task.FixedCost (o Cost é derivado)
 *     · trabalho   — <Resources>/<Assignments> -> Resources.Add + Assignments.Add
 *     · linha base — <Baseline>          -> Task.BaselineStart/Finish/Duration/Cost/Work
 *     · avanço     — <PercentComplete> e irmãos + <StatusDate> do projeto
 *     · moeda      — <CurrencySymbol>/<CurrencyCode>
 *   O que NÃO atravessa, e a resposta da rota DIZ (campo `faltou`): <Notes>,
 *   <Deadline>, <WBS>/<OutlineNumber> e <TotalSlack> — nenhum deles muda data
 *   nem dinheiro, mas prometer o que não vai é o defeito que este ⚠ conserta.
 *
 * ⚠ TRÊS COISAS QUE O COM FAZ AO CONTRÁRIO DO QUE A INTUIÇÃO DIZ — todas
 *   MEDIDAS aqui em 12/09/2026, com o arquivo reaberto para conferir:
 *   1. `BaselineSave()` NÃO serve para nós: ele grava o plano de HOJE como
 *      linha de base, e a nossa base é a promessa ANTIGA (congelada em outro
 *      calendário). Gravar as duas iguais apagaria justamente o desvio que a
 *      barra cinza existe para mostrar. `Task.BaselineStart/Finish/Duration/
 *      Cost/Work` aceitam escrita direta, sem BaselineSave — e persistem no
 *      arquivo (conferido na releitura: BLStart 24/08, BLCost 9999,99).
 *   2. A ORDEM das escritas importa: gravar a ALOCAÇÃO depois do avanço ZERA o
 *      PercentComplete (medido: escrevi 40, criei a alocação, e a releitura
 *      devolveu 0). Recurso primeiro, avanço por último.
 *   3. `Project.TaskDependencies.Count` devolve 0 mesmo com elos no arquivo, e
 *      `Task.TaskDependencies` conta os DOIS LADOS (2 elos viram 4). Quem conta
 *      certo é só a dependência cujo `To` é a própria tarefa.
 *
 * ⚠ CONTRATO COM A TELA — ESCRITO AQUI PORQUE A FIAÇÃO É DE OUTRA FRENTE.
 *   Enquanto ninguém ligar isto, o motor está pronto e o produto NÃO tem o
 *   recurso: é a cicatriz da memória `motor-puro-nao-cobre-a-fiacao` (gate
 *   verde, 52 asserts, recurso inteiro inerte no navegador). O que a tela
 *   precisa fazer, na ordem:
 *     1. `GET /__mpp/status` → { temProject, automacao, aberto, semJanela,
 *        verificou, motivo, versao }. O botão ".mpp" só aparece com
 *        `temProject && automacao === 'ok'`. Com `verificou === false` o texto
 *        é "não consegui verificar", NUNCA "não tem MS Project" — ninguém mediu.
 *        O `motivo` é o que a tela mostra quando o botão não aparece.
 *     2. o XML tem de ser gerado COM as opções, senão o .mpp sai vazio de
 *        dinheiro e de gente:
 *          MSProject.gerarXML(orc, r, { detalhe: Dx.detalhe, custos: true,
 *            recursos: <provedor de Hh>, base: <CronoPlan.congelarBase>,
 *            avanco: { dataStatus, porNo }, restricoes: true, relato: rel })
 *        `rel` existe para a tela dizer o que entrou e o que ficou de fora —
 *        ele não muda um byte do arquivo, e sem lê-lo a tela promete o que o
 *        arquivo não tem.
 *     3. `POST /__mpp/gerar` com esse XML no corpo → 200 com o binário, ou
 *        4xx/5xx com { codigo, erro, detalhe }. O `erro` já vem em português e
 *        pronto para a pessoa: é ele que vai à tela, não o `codigo`.
 *        Cabeçalhos: `X-Mpp-Tarefas`, e `X-Mpp-Conferido` / `X-Mpp-Faltou`
 *        percent-encoded (JSON.parse(decodeURIComponent(...))) — os números
 *        MEDIDOS dentro do arquivo e a lista do que a ponte não leva.
 *
 * ⚠ DUAS RÉGUAS PARA A MESMA GRANDEZA, e elas se cruzam exatamente aqui:
 *     MSPDI `LinkLag`  → DÉCIMOS DE MINUTO (1 dia útil de 8 h = 4800)
 *     COM `Task.Duration` / `TaskDependency.Lag` → MINUTOS (1 dia = 480)
 *   Passar o número do XML cru para o COM dá 10 dias onde havia 1 — e ninguém
 *   vê: o arquivo abre, nenhum erro aparece, só as datas mudam. A conversão
 *   mora SÓ em `planoDoXML`, e passa por dias.
 *
 * ⚠ SÓ WINDOWS POWERSHELL 5.1. No pwsh 7 (PowerShell Core, .NET) o MESMO
 *   objeto COM aceita todas as ESCRITAS e devolve VAZIO em toda LEITURA
 *   (Version, Projects.Count, ActiveProject). Medido lado a lado, mesma
 *   máquina, mesmo minuto: no 5.1 `Projects.Count` = 1; no pwsh 7 o mesmo
 *   FileNew tinha funcionado e o `Count` vinha 0. Uma tentativa anterior
 *   concluiu "FileNew não cria documento" por causa disso — quem mentiu foi a
 *   leitura, não a escrita. Por isso o script CONFERE `$app.Version` antes de
 *   continuar e aborta se vier vazio, em vez de gerar um arquivo vazio calado.
 *   O `powershell` que o Node acha nesta máquina é o 5.1 (medido:
 *   5.1.26100.9168, Desktop, C:\WINDOWS\System32\WindowsPowerShell\v1.0).
 *
 * ⚠ NUNCA `taskkill /IM WINPROJ.EXE`. Isso fecharia o Project em que o cliente
 *   está trabalhando, possivelmente com arquivo não salvo — é a mesma régua do
 *   "nunca taskkill genérico em node", num alvo pior.
 *   COMO O "MEU PID" É IDENTIFICADO, e por que a regra é mais estreita do que
 *   parece: não existe API que diga "o WINPROJ que este New-Object subiu". O
 *   que há é o DELTA — a lista de WINPROJ antes e depois. E o `New-Object` leva
 *   segundos para voltar (3,3 s medidos): se o cliente der duplo clique num
 *   .mpp DENTRO dessa janela, o processo dele entra no delta e seria morto com
 *   -Force, sem salvar. Medido em bancada: janela de 0,7 s bastou para o
 *   intruso entrar na lista. Por isso a regra aqui é
 *     `New-Object sobe EXATAMENTE UM WINPROJ; se o delta tiver 2 ou mais,
 *      alguém entrou no meio — então NÃO SE MATA NINGUÉM`,
 *   e o script devolve `intruso`, que o Node traduz em português. Um WINPROJ
 *   nosso pendurado custa memória; o Project do cliente morto custa o trabalho
 *   dele. O snapshot do "antes" é tirado NA LINHA anterior ao New-Object, para
 *   a janela ser a menor possível.
 * ===================================================================== */
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');

const MIN_DIA = 480;                 // 8 h de jornada — a mesma que o MSPDI declara
const DEC_POR_DIA = MIN_DIA * 10;    // décimos de minuto num dia útil

/* TEMPOS. Medidos nesta máquina (Project 16.0.20326.20132) com o cronograma
   real de 23 tarefas, 10 resumos, 11 elos e 1 feriado: a sonda levou 3,3 s e o
   ciclo inteiro — subir o Project, montar, salvar, fechar, REABRIR e contar —
   levou 18,4 s. Os tetos abaixo são muitas vezes isso de propósito: um PC de
   obra é mais lento que este, e estourar o tempo por pouco entregaria "o
   Project não respondeu" a quem só precisava esperar.
   ⚠ Teto existe porque `BaselineSave()` sem argumentos JÁ pendurou o processo
   aqui: sem tempo-limite, um COM travado deixaria o servidor local do cliente
   segurando a requisição para sempre. */
const MS_SONDA = 90000;
const MS_CONVERTER = 300000;
const MS_RECONTAR = 180000;
/* A sonda SOBE UM WINPROJ para saber se a automação responde. Guardar a
   resposta evita subir um processo a cada vez que a tela pergunta se o botão
   aparece. O que NÃO é guardado: se o Project está aberto agora — isso muda de
   minuto a minuto e é conferido em toda chamada. */
const CACHE_MS = 10 * 60 * 1000;

const ASSINATURA_OLE = [0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1];

/* ---------------------------------------------------------------------
   MSPDI -> plano (o que o PowerShell recebe)
   --------------------------------------------------------------------- */
function tag(bloco, nome) {
  const m = new RegExp('<' + nome + '>([\\s\\S]*?)</' + nome + '>').exec(bloco);
  return m ? m[1] : null;
}
function num(bloco, nome, padrao) {
  const v = tag(bloco, nome);
  return v == null || v === '' ? padrao : Number(v);
}
function desescapa(s) {
  return String(s == null ? '' : s).replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&');
}
// PT{h}H{m}M{s}S -> minutos (a unidade do COM)
function isoParaMin(s) {
  if (!s) return 0;
  const m = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/.exec(s);
  if (!m) return 0;
  return (Number(m[1] || 0) * 60) + Number(m[2] || 0) + Math.round(Number(m[3] || 0) / 60);
}

/* ⚠ O BLOCO ESCALAR DA TAREFA TERMINA NO PRIMEIRO FILHO COMPOSTO. Dentro de um
   mesmo <Task> o XML enriquecido tem <Duration> DUAS vezes: a da tarefa e a de
   dentro de <Baseline> (js/msproject.js, `linhaBase`). Como `tag()` devolve a
   PRIMEIRA ocorrência, procurar no bloco inteiro só funciona enquanto o
   escritor puser a duração da tarefa antes da base — um acoplamento por ORDEM
   entre dois arquivos, que nenhum assert via (a contagem de tarefas continua
   certa, e é tudo que a ponte conferia). Trocada a ordem lá, a ponte mandaria
   a duração da LINHA DE BASE para o Project: medido, 4800 min viraram 480.
   Cortar aqui fecha isso sem depender do escritor. */
/* ⚠ REMOVE os filhos compostos em vez de CORTAR no primeiro deles. Cortar
   também depende da ordem: a primeira tentativa fatiava o bloco no `<Baseline>`
   e, com a duração da tarefa escrita DEPOIS da base, o leitor passou a devolver
   ZERO minuto — trocar um acoplamento de ordem por outro. Removendo os
   sub-blocos, o que sobra são só os campos da própria tarefa, em qualquer
   ordem. (Baseline pode repetir: Baseline1..10 são as reprogramações.) */
function escalares(bloco) {
  return String(bloco)
    .replace(/<Baseline>[\s\S]*?<\/Baseline>/g, '')
    .replace(/<PredecessorLink>[\s\S]*?<\/PredecessorLink>/g, '')
    .replace(/<ExtendedAttribute>[\s\S]*?<\/ExtendedAttribute>/g, '');
}
// "2026-09-08T08:00:00" -> ele mesmo; vazio/ausente -> null
function inst(bloco, nome) {
  const v = tag(bloco, nome);
  return /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(String(v || '')) ? v : null;
}

/* Lê o MSPDI e devolve o plano que o conversor executa. NÃO recalcula nada:
   o que sai daqui é o que está no XML. */
function planoDoXML(xml) {
  xml = String(xml == null ? '' : xml);
  const cabeca = xml.split('<Tasks>')[0];
  const plano = {
    nome: desescapa(tag(cabeca, 'Name') || ''),
    titulo: desescapa(tag(cabeca, 'Title') || ''),
    inicio: tag(cabeca, 'StartDate') || null,
    minutosPorDia: num(cabeca, 'MinutesPerDay', MIN_DIA),
    diasUteisSemana: Math.round(num(cabeca, 'MinutesPerWeek', MIN_DIA * 5) / (num(cabeca, 'MinutesPerDay', MIN_DIA) || MIN_DIA)),
    semana: [false, false, false, false, false, false, false],   // índice 0 = domingo
    excecoes: [],
    tarefas: [],
    links: [],
    // --- o que o XML enriquecido trouxe (vazio = o XML não tinha) ---
    moeda: tag(cabeca, 'CurrencySymbol') ? { simbolo: desescapa(tag(cabeca, 'CurrencySymbol')), codigo: tag(cabeca, 'CurrencyCode') || '' } : null,
    dataStatus: inst(cabeca, 'StatusDate'),
    recursos: [],
    alocacoes: []
  };

  const calBloco = (/<Calendars>[\s\S]*?<\/Calendars>/.exec(xml) || [''])[0];
  (calBloco.match(/<WeekDay>[\s\S]*?<\/WeekDay>/g) || []).forEach(function (w) {
    const tipo = num(w, 'DayType', 0);            // 1 = domingo … 7 = sábado
    if (tipo >= 1 && tipo <= 7) plano.semana[tipo - 1] = num(w, 'DayWorking', 0) === 1;
  });
  /* ⚠ O FERIADO PRECISA ENTRAR NO CALENDÁRIO, não só nas datas. Sem a exceção,
     o Project recalcula a rede pela semana dele (que só conhece sábado e
     domingo) e devolve datas ANTERIORES às que o cliente recebeu em PDF. É a
     mesma cicatriz do comentário ⚠ de js/msproject.js:41 — e o controle
     negativo "sem-feriado" a reproduziu: a entrega andou 2 dias para trás. */
  (calBloco.match(/<Exception>[\s\S]*?<\/Exception>/g) || []).forEach(function (e) {
    const de = tag(e, 'FromDate');
    if (!de) return;
    plano.excecoes.push({ de: de, nome: desescapa(tag(e, 'Name') || 'Feriado') });
  });

  const blocoTarefas = (/<Tasks>[\s\S]*<\/Tasks>/.exec(xml) || [''])[0];
  (blocoTarefas.match(/<Task>[\s\S]*?<\/Task>/g) || []).forEach(function (b) {
    const e = escalares(b);                     // ⚠ ver o comentário de `escalares`
    const uid = num(e, 'UID', null);
    /* ⚠ A LINHA DE BASE SE ESCOLHE PELO `<Number>`, NUNCA PELA POSIÇÃO. Até
       20/09/2026 esta linha pegava o PRIMEIRO `<Baseline>` do documento, o que
       só funcionava enquanto existisse um só. Com o planejador o XML passou a
       emitir 0 = a base ATIVA, 1 = a CONTRATUAL (pelo selo) e 2 a 10 = as
       demais — e "a primeira do documento" viraria uma aposta na ordem de
       outro arquivo, o mesmo acoplamento que o comentário de `escalares` já
       teve de desfazer duas vezes. A que atravessa a ponte é a 0: é a que o
       Project mostra como "Linha de Base" e a única que o COM escreve daqui
       (`Task.BaselineStart` e irmãs). As 1 a 10 não atravessam, e a resposta
       da rota DIZ isso em `faltou` — escrever `Baseline1Start` sem nunca ter
       aberto o resultado no Project real seria prometer o que não foi medido
       (pendência declarada, §6.4 da espec do planejador). */
    const bases = b.match(/<Baseline>[\s\S]*?<\/Baseline>/g) || [];
    let bl = null, blOutras = 0;
    bases.forEach(function (bb) {
      const n = num(bb, 'Number', 0);
      if (n === 0) { if (!bl) bl = bb; } else blOutras++;
    });
    plano.tarefas.push({
      uid: uid,
      nome: desescapa(tag(e, 'Name') || ''),
      nivel: num(e, 'OutlineLevel', 1),
      minutos: isoParaMin(tag(e, 'Duration')),
      marco: num(e, 'Milestone', 0) === 1,
      resumo: num(e, 'Summary', 0) === 1,
      restricaoTipo: num(e, 'ConstraintType', 0),
      restricaoData: tag(e, 'ConstraintDate'),
      /* ⚠ O INSTANTE DECLARADO É A RÉGUA DA CONFERÊNCIA FINAL, e para o MARCO
         ele também é escrita: uma tarefa de duração zero o Project ancora no
         INSTANTE em que a predecessora termina (17 h do dia D) em vez da manhã
         seguinte (8 h do dia D+1), que é onde o MSPDI a põe. O instante de rede
         é o mesmo; a DATA que a pessoa lê, não — e a data de entrega é a mais
         lida de um cronograma. Medido: PDF 23/02, Project 22/02. */
      inicio: inst(e, 'Start'),
      fim: inst(e, 'Finish'),
      custoFixo: tag(e, 'FixedCost') == null ? null : Number(tag(e, 'FixedCost')),
      pct: tag(e, 'PercentComplete') == null ? null : num(e, 'PercentComplete', 0),
      pctFisico: tag(e, 'PhysicalPercentComplete') == null ? null : num(e, 'PhysicalPercentComplete', 0),
      inicioReal: inst(e, 'ActualStart'),
      fimReal: inst(e, 'ActualFinish'),
      basesExtras: blOutras,
      base: bl ? {
        inicio: inst(bl, 'Start'), fim: inst(bl, 'Finish'),
        minutos: isoParaMin(tag(bl, 'Duration')),
        trabalho: isoParaMin(tag(bl, 'Work')),
        custo: tag(bl, 'Cost') == null ? null : Number(tag(bl, 'Cost'))
      } : null
    });
    (b.match(/<PredecessorLink>[\s\S]*?<\/PredecessorLink>/g) || []).forEach(function (l) {
      const dec = num(l, 'LinkLag', 0);
      plano.links.push({
        de: num(l, 'PredecessorUID', null),
        para: uid,
        // MSPDI: 0=TT 1=TI 2=IT 3=II | COM pjTaskLinkType: 0=FF 1=FS 2=SF 3=SS — mesma numeração
        tipo: num(l, 'Type', 1),
        /* ⚠ décimos de minuto → dias → minutos do COM. Não encurte esta conta:
           mandar `dec` cru para o COM daria 4800 MINUTOS (10 dias) onde há 1
           dia útil, e a cura do concreto viraria dez dias de espera. */
        dias: dec / DEC_POR_DIA,
        minutos: Math.round(dec / 10)
      });
    });
  });

  /* RECURSOS E ALOCAÇÕES — o histograma de mão de obra do Project. Sem eles o
     Gráfico de Recursos, o Uso dos Recursos e o Planejador de Equipe abrem
     VAZIOS, que é o que o .mpp entregava até 12/09/2026.
     ⚠ `Resource.Type` NÃO é tocado no COM: lá o recurso novo nasce 0 e 0 é
     TRABALHO — o inverso do MSPDI, onde 1 é trabalho. Pôr 1 no COM transforma
     em material e o custo despenca sem erro nenhum (medido em 11/09). Por isso
     o `<Type>` do XML é lido e IGNORADO de propósito. */
  const blocoRec = (/<Resources>[\s\S]*?<\/Resources>/.exec(xml) || [''])[0];
  (blocoRec.match(/<Resource>[\s\S]*?<\/Resource>/g) || []).forEach(function (b) {
    const nome = desescapa(tag(b, 'Name') || '');
    if (!nome) return;
    plano.recursos.push({ uid: num(b, 'UID', null), nome: nome, maxUnidades: num(b, 'MaxUnits', 1) });
  });
  const blocoAloc = (/<Assignments>[\s\S]*?<\/Assignments>/.exec(xml) || [''])[0];
  (blocoAloc.match(/<Assignment>[\s\S]*?<\/Assignment>/g) || []).forEach(function (b) {
    plano.alocacoes.push({
      tarefaUID: num(b, 'TaskUID', null), recursoUID: num(b, 'ResourceUID', null),
      unidades: num(b, 'Units', 1),
      // ⚠ MINUTOS: no COM `Assignment.Work` é minuto (medido: 7200 = 120 h)
      minutos: isoParaMin(tag(b, 'Work'))
    });
  });
  return plano;
}

/* ---------------------------------------------------------------------
   OS TRÊS SCRIPTS DE POWERSHELL
   ---------------------------------------------------------------------
   ⚠ ELES NASCEM AQUI, NUM ARQUIVO TEMPORÁRIO, e não num .ps1 ao lado. Motivo:
     um .ps1 solto precisa viajar no pacote do cliente e pode chegar desatualizado
     em relação a este módulo — e um conversor de uma versão com um módulo de
     outra é exatamente o tipo de divergência que ninguém percebe até o arquivo
     sair errado.

   ⚠ O ARQUIVO É GRAVADO COM BOM UTF-8 (EF BB BF) E O TEXTO É ASCII PURO — são
     duas defesas para a mesma cicatriz. Sem BOM, o Windows PowerShell 5.1 lê
     acento e travessão como Latin-1 e o script NEM COMPILA ("Token inesperado"):
     é o mesmo defeito que calou o instalador do plugin do Revit. O texto em
     ASCII garante que ele continue compilando mesmo que alguém, um dia, grave
     sem o BOM. Quem fala com o usuário é o Node, em português; o PowerShell só
     devolve código e número.

   ⚠ SEM CRASE NO TEXTO: a crase é o escape do PowerShell e o delimitador do
     template literal do JavaScript. Uma só quebraria os dois lados. */

const PS_SONDA = `param([Parameter(Mandatory=$true)][string]$Saida)
$ErrorActionPreference = 'Continue'
$r = [ordered]@{ shell=''; edicao=''; clsid=''; exe=''; existeExe=$false; versaoExe=''; abertos=0; janelas=0; intruso=0; com='nao-tentado'; versaoCom=''; erro='' }
$r.shell = [string]$PSVersionTable.PSVersion
$r.edicao = [string]$PSVersionTable.PSEdition
try {
  $c = (Get-ItemProperty -LiteralPath 'HKLM:\\SOFTWARE\\Classes\\MSProject.Application\\CLSID' -ErrorAction SilentlyContinue).'(default)'
  if ($c) {
    $r.clsid = [string]$c
    $e = (Get-ItemProperty -LiteralPath ('HKLM:\\SOFTWARE\\Classes\\CLSID\\' + $c + '\\LocalServer32') -ErrorAction SilentlyContinue).'(default)'
    if ($e) {
      # LocalServer32 pode vir com aspas e com argumento (/automation): fica so o caminho
      $e = ([string]$e).Trim()
      if ($e.StartsWith('"')) { $e = $e.Substring(1); $i = $e.IndexOf('"'); if ($i -ge 0) { $e = $e.Substring(0, $i) } }
      else { $m = [regex]::Match($e, '(?i)^(.*?\\.exe)'); if ($m.Success) { $e = $m.Groups[1].Value } }
      $r.exe = $e
    }
  }
} catch { $r.erro = 'registro: ' + $_.Exception.Message }
if ($r.exe) {
  try {
    $r.existeExe = [bool](Test-Path -LiteralPath $r.exe)
    if ($r.existeExe) { $r.versaoExe = [string](Get-Item -LiteralPath $r.exe).VersionInfo.FileVersion }
  } catch {}
}
$abertosAgora = @(Get-Process WINPROJ -ErrorAction SilentlyContinue | Select-Object -Expand Id)
$r.abertos = $abertosAgora.Count
# ATENCAO: quantos desses WINPROJ tem JANELA. "Feche o Project" e parede quando nao
# ha janela para fechar - e a ponte FABRICA esse estado (a sonda sobe um WINPROJ
# invisivel; se o Node morrer no meio, ele sobra). O Node usa este numero para dizer
# "sobrou um MS Project em segundo plano" em vez de mandar fechar o que nao existe.
foreach ($pr in @(Get-Process WINPROJ -ErrorAction SilentlyContinue)) { if ($pr.MainWindowHandle -ne 0) { $r.janelas = $r.janelas + 1 } }
# ATENCAO: so toca no COM com o Project FECHADO. Com uma instancia do usuario no ar,
# New-Object pode se anexar a ela e o Quit fecharia o arquivo dele, talvez nao salvo.
if ($r.existeExe -and $r.abertos -eq 0 -and $r.edicao -ne 'Core') {
  $app = $null; $meus = @()
  try {
    # ATENCAO: o snapshot vem NA LINHA anterior ao New-Object. Ver o cabecalho do mpp.js:
    # a janela entre os dois e onde um WINPROJ do usuario pode entrar no delta.
    $antes = @(Get-Process WINPROJ -ErrorAction SilentlyContinue | Select-Object -Expand Id)
    $app = New-Object -ComObject MSProject.Application
    $meus = @(@(Get-Process WINPROJ -ErrorAction SilentlyContinue | Select-Object -Expand Id) | Where-Object { $antes -notcontains $_ })
    ($meus -join ',') | Set-Content -LiteralPath ($Saida + '.pid') -Encoding ASCII
    try { $app.Visible = $false } catch {}
    try { $app.DisplayAlerts = $false } catch {}
    $v = [string]$app.Version
    # ATENCAO: Version vazio com o objeto vivo = shell cego (pwsh 7). Ver o cabecalho do mpp.js.
    if ($v) { $r.com = 'ok'; $r.versaoCom = $v } else { $r.com = 'cego' }
  } catch {
    $r.com = 'falhou'
    $r.erro = $_.Exception.Message
  } finally {
    if ($app) { try { $app.Quit(0) | Out-Null } catch {} }
    Start-Sleep -Milliseconds 900
    # ATENCAO: New-Object sobe EXATAMENTE UM WINPROJ. Dois ou mais no delta = alguem
    # entrou na janela; nesse caso nao se mata NINGUEM. Ver o cabecalho do mpp.js.
    if (@($meus).Count -eq 1) {
      foreach ($q in @(Get-Process WINPROJ -ErrorAction SilentlyContinue | Select-Object -Expand Id)) {
        if ($meus -contains $q) { Stop-Process -Id $q -Force -ErrorAction SilentlyContinue }
      }
    } elseif (@($meus).Count -gt 1) { $r.intruso = @($meus).Count }
  }
}
($r | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $Saida -Encoding UTF8
exit 0
`;

const PS_CONVERTER = `param(
  [Parameter(Mandatory=$true)][string]$Plano,
  [Parameter(Mandatory=$true)][string]$Saida,
  [Parameter(Mandatory=$true)][string]$Res
)
$ErrorActionPreference = 'Continue'
# ATENCAO: contadores em variavel simples, nao em propriedade de hashtable.
# O JSON so e montado no fim, em Gravar.
$erro = ''; $falhas = 0; $tPedidas = 0; $tCriadas = 0; $ePedidos = 0; $eFeitos = 0; $nExc = 0; $bytes = 0
$cPedidos = 0; $cFeitos = 0; $rPedidos = 0; $rFeitos = 0; $aPedidas = 0; $aFeitas = 0
$bPedidas = 0; $bFeitas = 0; $vPedidos = 0; $vFeitos = 0; $intruso = 0
function Gravar($codigo) {
  $o = [ordered]@{ falhas=$script:falhas; tarefasPedidas=$script:tPedidas; tarefasCriadas=$script:tCriadas;
                   elosPedidos=$script:ePedidos; elosFeitos=$script:eFeitos; excecoes=$script:nExc;
                   custosPedidos=$script:cPedidos; custosFeitos=$script:cFeitos;
                   recursosPedidos=$script:rPedidos; recursosFeitos=$script:rFeitos;
                   alocPedidas=$script:aPedidas; alocFeitas=$script:aFeitas;
                   basesPedidas=$script:bPedidas; basesFeitas=$script:bFeitas;
                   avancosPedidos=$script:vPedidos; avancosFeitos=$script:vFeitos;
                   intruso=$script:intruso; bytes=$script:bytes; erro=$script:erro }
  ($o | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $Res -Encoding UTF8
  exit $codigo
}
if ($PSVersionTable.PSEdition -eq 'Core') { $erro = 'shell-core'; Gravar 4 }
$j = Get-Content -LiteralPath $Plano -Raw -Encoding UTF8 | ConvertFrom-Json
if (Test-Path -LiteralPath $Saida) { Remove-Item -LiteralPath $Saida -Force }
if (@(Get-Process WINPROJ -ErrorAction SilentlyContinue).Count -gt 0) { $erro = 'project-aberto'; Gravar 3 }

$app = $null; $meus = @()
function Passo($nome, $bloco) {
  try { & $bloco } catch { $script:falhas = $script:falhas + 1; $script:erro = $nome + ': ' + $_.Exception.Message }
}
# ATENCAO: o nome NAO pode ser "Data". "data" e PALAVRA RESERVADA do PowerShell
# (a secao "data { }"), e o script inteiro para de COMPILAR com "Bloco de
# instrucao ausente na secao Data" - oito vezes, uma por chamada. O Node entao
# recebe um res.json que nunca foi escrito e responde "o MS Project nao chegou a
# gravar o arquivo", sem dizer por que. Custou uma rodada inteira para achar.
function ComoData($s) { return [datetime]::ParseExact([string]$s, 'yyyy-MM-ddTHH:mm:ss', $null) }
try {
  # ATENCAO: snapshot NA LINHA anterior ao New-Object - ver o cabecalho do mpp.js
  $antes = @(Get-Process WINPROJ -ErrorAction SilentlyContinue | Select-Object -Expand Id)
  $app = New-Object -ComObject MSProject.Application
  $meus = @(@(Get-Process WINPROJ -ErrorAction SilentlyContinue | Select-Object -Expand Id) | Where-Object { $antes -notcontains $_ })
  ($meus -join ',') | Set-Content -LiteralPath ($Res + '.pid') -Encoding ASCII
  $app.Visible = $false
  $app.DisplayAlerts = $false
  if (-not $app.Version) { $erro = 'com-cego'; Gravar 5 }

  $null = $app.FileNew()
  $p = $app.ActiveProject
  if ($null -eq $p) { $erro = 'sem-projeto'; Gravar 6 }

  # ATENCAO: sem isto a tarefa nasce MANUAL e o vinculo nao reprograma nada.
  Passo 'manual-padrao' { $p.NewTasksCreatedAsManual = $false }
  Passo 'inicio' { if ($j.inicio) { $p.ProjectStart = ComoData $j.inicio } }
  # ATENCAO: MOEDA ANTES DE QUALQUER DINHEIRO. O projeto novo nasce sem moeda e o
  # Project imprime cifrao de DOLAR num orcamento em real (medido: uma taxa de 700
  # voltou como "$700.00"). Depois de definida, a leitura voltou "R$0.00/hr".
  if ($j.moeda) {
    Passo 'moeda' { $p.CurrencySymbol = [string]$j.moeda.simbolo; if ($j.moeda.codigo) { $p.CurrencyCode = [string]$j.moeda.codigo } }
  }

  # ---- calendario: a MESMA semana do app + os feriados como excecao ----
  # ATENCAO: $p.Calendar JA E o objeto Calendar. BaseCalendars.Item($p.Calendar)
  #   devolve DISP_E_TYPEMISMATCH 0x80020005 (o Item quer o NOME).
  # ATENCAO: o dia util do calendario padrao desta maquina comeca as 9:00 e o XML
  #   declara 8:00. Sem reescrever o turno sai o MESMO dia com o relogio uma hora
  #   adiante: 08:00 no PDF, 09:00 no Project.
  $cal = $null
  Passo 'calendario' { $script:cal = $p.Calendar }
  if ($cal) {
    for ($i = 1; $i -le 7; $i++) {
      $util = [bool]$j.semana[$i-1]
      $idx = $i
      Passo ('dia-' + $i) {
        $wd = $cal.Weekdays.Item($idx)
        $wd.Working = $util
        if ($util) { $wd.Shift1.Start = '08:00'; $wd.Shift1.Finish = '12:00'; $wd.Shift2.Start = '13:00'; $wd.Shift2.Finish = '17:00' }
      }
    }
    foreach ($e in @($j.excecoes)) {
      $d = [datetime]::ParseExact(([string]$e.de).Substring(0,10), 'yyyy-MM-dd', $null)
      $nm = [string]$e.nome
      Passo ('feriado-' + $e.de) { $null = $cal.Exceptions.Add(7, $d, $d, 1, $nm); $script:nExc = $script:nExc + 1 }   # 7 = pjDaily
    }
  }

  # ---- 1a passada: SO nome e hierarquia, na ordem do XML ----
  # ATENCAO: nada de duracao aqui. Indentar a proxima transforma a anterior em
  #   RESUMO e DESCARTA a duracao dela.
  $mapa = @{}
  $nivelAnterior = 1
  foreach ($t in @($j.tarefas)) {
    $tPedidas = $tPedidas + 1
    $tk = $p.Tasks.Add($t.nome)
    $alvo = [int]$t.nivel
    if ($alvo -gt $nivelAnterior) { for ($k = $nivelAnterior; $k -lt $alvo; $k++) { $null = $tk.OutlineIndent() } }
    elseif ($alvo -lt $nivelAnterior) { for ($k = $alvo; $k -lt $nivelAnterior; $k++) { $null = $tk.OutlineOutdent() } }
    $nivelAnterior = $alvo
    $mapa[[string]$t.uid] = $tk
  }
  try { $tCriadas = [int]$p.Tasks.Count } catch {}

  # ---- 2a passada: duracao e restricao ----
  foreach ($t in @($j.tarefas)) {
    $tk = $mapa[[string]$t.uid]
    if ($null -eq $tk) { $falhas = $falhas + 1; $erro = 'tarefa-sumiu-' + $t.uid; continue }
    Passo ('manual-' + $t.uid) { $tk.Manual = $false }
    if ($tk.Summary) { continue }   # resumo: o Project calcula do filho
    $min = [int]$t.minutos
    # ATENCAO: MINUTOS aqui (o COM conta assim). No MSPDI o mesmo numero e em decimos.
    Passo ('duracao-' + $t.uid) { $tk.Duration = $min }
    if ([int]$t.restricaoTipo -ne 0 -and $t.restricaoData) {
      $rd = ComoData $t.restricaoData
      $rt = [int]$t.restricaoTipo
      Passo ('restricao-' + $t.uid) { $tk.ConstraintType = $rt; $tk.ConstraintDate = $rd }
    }
  }


  # ---- 3a passada: ligacoes ----
  foreach ($l in @($j.links)) {
    $ePedidos = $ePedidos + 1
    $de = $mapa[[string]$l.de]; $para = $mapa[[string]$l.para]
    if ($null -eq $de -or $null -eq $para) { $falhas = $falhas + 1; $erro = 'elo-sem-tarefa'; continue }
    $tipo = [int]$l.tipo
    $lag = [int]$l.minutos
    Passo ('elo-' + $l.de + '-' + $l.para) { $null = $para.TaskDependencies.Add($de, $tipo, $lag); $script:eFeitos = $script:eFeitos + 1 }
  }

  # ---- 4a passada: o MARCO recebe a DATA do XML ----
  # ATENCAO: DEPOIS dos elos, senao o elo reprograma o que acabou de ser escrito.
  # ATENCAO: so a tarefa de duracao ZERO. O Project ancora o marco no INSTANTE em
  #   que a predecessora termina (17h do dia D) e o MSPDI o poe na manha seguinte
  #   (8h do dia D+1). O instante de rede e o mesmo; a DATA que a pessoa le, nao -
  #   medido: PDF 23/02, Project 22/02. Escrever o Start cria ConstraintType 4
  #   sozinho (medido), que e justamente o que segura a data do PDF.
  foreach ($t in @($j.tarefas)) {
    if ([int]$t.minutos -ne 0 -or -not $t.inicio) { continue }
    $tk = $mapa[[string]$t.uid]
    if ($null -eq $tk) { continue }
    if ($tk.Summary) { continue }
    $ini = ComoData $t.inicio
    Passo ('marco-' + $t.uid) { $tk.Start = $ini }
  }

  # ---- 5a passada: DINHEIRO ----
  # ATENCAO: FixedCost, nunca Cost. No COM o Cost e DERIVADO (medido: FixedCost
  #   1234,56 -> Cost 1234,56) e escrever nos dois somaria duas vezes. O numero e
  #   o preco de VENDA que o XML traz em <FixedCost> - custo direto nao sai do app.
  foreach ($t in @($j.tarefas)) {
    if ($null -eq $t.custoFixo) { continue }
    $tk = $mapa[[string]$t.uid]
    if ($null -eq $tk -or $tk.Summary) { continue }
    $cPedidos = $cPedidos + 1
    $v = [double]$t.custoFixo
    Passo ('custo-' + $t.uid) { $tk.FixedCost = $v; $script:cFeitos = $script:cFeitos + 1 }
  }

  # ---- 6a passada: RECURSOS E ALOCACOES ----
  # ATENCAO: NAO SE TOCA EM Resource.Type. No COM o recurso novo nasce 0 e 0 e
  #   TRABALHO - o inverso do MSPDI, onde 1 e trabalho. Pondo 1 aqui ele vira
  #   MATERIAL, MaxUnits passa a recusar valor e o custo despenca sem erro nenhum.
  # ATENCAO: EffortDriven FALSE na tarefa que recebe gente, senao acrescentar um
  #   pedreiro DENTRO do Project encurta a tarefa e o cronograma deixa de bater
  #   com o PDF que o cliente recebeu.
  $recs = @{}
  foreach ($rr in @($j.recursos)) {
    $rPedidos = $rPedidos + 1
    $nm = [string]$rr.nome
    $mx = [double]$rr.maxUnidades
    Passo ('recurso-' + $rr.uid) {
      $novo = $p.Resources.Add($nm)
      try { $novo.MaxUnits = $mx } catch {}
      try { $novo.StandardRate = 0 } catch {}
      $script:recs[[string]$rr.uid] = $novo
      $script:rFeitos = $script:rFeitos + 1
    }
  }
  foreach ($al in @($j.alocacoes)) {
    $aPedidas = $aPedidas + 1
    $tk = $mapa[[string]$al.tarefaUID]
    $rc = $recs[[string]$al.recursoUID]
    if ($null -eq $tk -or $null -eq $rc) { $falhas = $falhas + 1; $erro = 'aloc-sem-par'; continue }
    $un = [double]$al.unidades
    $mn = [int]$al.minutos
    Passo ('aloc-' + $al.tarefaUID + '-' + $al.recursoUID) {
      try { $tk.EffortDriven = $false } catch {}
      $asg = $tk.Assignments.Add($tk.ID, $rc.ID)
      try { $asg.Units = $un } catch {}
      $asg.Work = $mn
      $script:aFeitas = $script:aFeitas + 1
    }
  }

  # ---- 7a passada: LINHA DE BASE ----
  # ATENCAO: NADA de BaselineSave. Ele grava o plano de HOJE como base, e a nossa
  #   base e a promessa ANTIGA, congelada em outro calendario - as duas barras
  #   sairiam iguais e o desvio, que e a razao de a base existir, sumiria. Os
  #   campos Baseline* aceitam escrita direta e persistem (medido na releitura).
  #   Alem disso BaselineSave() sem argumentos JA PENDUROU o processo aqui.
  foreach ($t in @($j.tarefas)) {
    if ($null -eq $t.base -or -not $t.base.inicio) { continue }
    $tk = $mapa[[string]$t.uid]
    if ($null -eq $tk) { continue }
    $bPedidas = $bPedidas + 1
    $bi = ComoData $t.base.inicio
    $bf = $null; if ($t.base.fim) { $bf = ComoData $t.base.fim }
    $bd = [int]$t.base.minutos
    $bw = [int]$t.base.trabalho
    $bc = $t.base.custo
    Passo ('base-' + $t.uid) {
      $tk.BaselineStart = $bi
      if ($bf) { $tk.BaselineFinish = $bf }
      try { $tk.BaselineDuration = $bd } catch {}
      if ($bw -gt 0) { try { $tk.BaselineWork = $bw } catch {} }
      if ($null -ne $bc) { try { $tk.BaselineCost = [double]$bc } catch {} }
      $script:bFeitas = $script:bFeitas + 1
    }
  }

  # ---- 8a passada: AVANCO (por ULTIMO) ----
  # ATENCAO: a ORDEM aqui nao e estilo. Gravar a alocacao DEPOIS do avanco ZERA o
  #   PercentComplete: medido - escrevi 40, criei a alocacao, e a releitura do
  #   arquivo devolveu 0. Recurso primeiro, avanco por ultimo.
  if ($j.dataStatus) { Passo 'data-status' { $p.StatusDate = ComoData $j.dataStatus } }
  foreach ($t in @($j.tarefas)) {
    if ($null -eq $t.pct -and $null -eq $t.pctFisico -and -not $t.inicioReal) { continue }
    $tk = $mapa[[string]$t.uid]
    if ($null -eq $tk -or $tk.Summary) { continue }
    $vPedidos = $vPedidos + 1
    $pc = $t.pct; $pf = $t.pctFisico
    $ir = $null; if ($t.inicioReal) { $ir = ComoData $t.inicioReal }
    $fr = $null; if ($t.fimReal) { $fr = ComoData $t.fimReal }
    Passo ('avanco-' + $t.uid) {
      if ($null -ne $ir) { $tk.ActualStart = $ir }
      if ($null -ne $fr) { $tk.ActualFinish = $fr }
      if ($null -ne $pc) { $tk.PercentComplete = [int]$pc }
      if ($null -ne $pf) { try { $tk.PhysicalPercentComplete = [int]$pf } catch {} }
      $script:vFeitos = $script:vFeitos + 1
    }
  }

  Passo 'salvar' { $null = $app.FileSaveAs($Saida) }
} catch {
  $falhas = $falhas + 1
  $erro = 'geral: ' + $_.Exception.Message
} finally {
  if ($app) { try { $app.FileCloseEx(0) | Out-Null } catch {}; try { $app.Quit(0) | Out-Null } catch {} }
  Start-Sleep -Milliseconds 1200
  # ATENCAO: so os PIDs que ESTE script criou. Nunca taskkill /IM WINPROJ.EXE.
  # ATENCAO: New-Object sobe EXATAMENTE UM WINPROJ. Delta com 2 ou mais = alguem
  #   abriu o Project na janela do New-Object; ai nao se mata NINGUEM, porque um
  #   deles e o arquivo do cliente, talvez nao salvo. Ver o cabecalho do mpp.js.
  if (@($meus).Count -eq 1) {
    foreach ($q in @(Get-Process WINPROJ -ErrorAction SilentlyContinue | Select-Object -Expand Id)) {
      if ($meus -contains $q) { Stop-Process -Id $q -Force -ErrorAction SilentlyContinue }
    }
  } elseif (@($meus).Count -gt 1) { $intruso = @($meus).Count }
}
if (Test-Path -LiteralPath $Saida) { $bytes = (Get-Item -LiteralPath $Saida).Length }
if ($bytes -le 0) { if (-not $erro) { $erro = 'nao-gerou' }; Gravar 7 }
Gravar 0
`;

/* ⚠ O LEITOR NÃO COMPARTILHA CONSTANTE COM O ESCRITOR: aqui sai o que o
   PROJECT diz que tem no arquivo, num processo NOVO. Se os dois lados usassem
   o mesmo número, um erro passaria nos dois e a conferência seria enfeite. */
const PS_RECONTAR = `param(
  [Parameter(Mandatory=$true)][string]$Arquivo,
  [Parameter(Mandatory=$true)][string]$Res
)
$ErrorActionPreference = 'Continue'
$r = [ordered]@{ tarefas=-1; resumos=0; elos=0; excecoes=0; recursos=0; alocacoes=0;
                 custoTotal=0; trabalho=0; bases=0; avancos=0; intruso=0; linhas=@(); erro='' }
function Gravar($codigo) { ($r | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $Res -Encoding UTF8; exit $codigo }
function Txt($d) { try { return ([datetime]$d).ToString('yyyy-MM-ddTHH:mm:ss') } catch { return '' } }
if ($PSVersionTable.PSEdition -eq 'Core') { $r.erro = 'shell-core'; Gravar 4 }
if (-not (Test-Path -LiteralPath $Arquivo)) { $r.erro = 'sem-arquivo'; Gravar 2 }
if (@(Get-Process WINPROJ -ErrorAction SilentlyContinue).Count -gt 0) { $r.erro = 'project-aberto'; Gravar 3 }
$app = $null; $meus = @()
try {
  # ATENCAO: snapshot NA LINHA anterior ao New-Object - ver o cabecalho do mpp.js
  $antes = @(Get-Process WINPROJ -ErrorAction SilentlyContinue | Select-Object -Expand Id)
  $app = New-Object -ComObject MSProject.Application
  $meus = @(@(Get-Process WINPROJ -ErrorAction SilentlyContinue | Select-Object -Expand Id) | Where-Object { $antes -notcontains $_ })
  ($meus -join ',') | Set-Content -LiteralPath ($Res + '.pid') -Encoding ASCII
  $app.Visible = $false
  $app.DisplayAlerts = $false
  if (-not $app.Version) { $r.erro = 'com-cego'; Gravar 5 }
  $null = $app.FileOpenEx((Get-Item -LiteralPath $Arquivo).FullName, $true)   # ReadOnly
  $p = $app.ActiveProject
  if ($null -eq $p) { $r.erro = 'nao-abriu'; Gravar 6 }
  $n = 0; $s = 0; $elos = 0; $aloc = 0; $custo = 0.0; $trab = 0; $bases = 0; $av = 0
  $linhas = New-Object System.Collections.ArrayList
  foreach ($t in $p.Tasks) {
    if ($t -eq $null) { continue }
    $n++
    if ($t.Summary) { $s++ }
    # ATENCAO: Task.TaskDependencies traz os DOIS LADOS (2 elos viram 4), e
    #   Project.TaskDependencies.Count devolve 0 mesmo com elos no arquivo (os dois
    #   medidos). Quem conta certo e so a dependencia cujo To e a propria tarefa.
    foreach ($dep in @($t.TaskDependencies)) { if ($dep.To.UniqueID -eq $t.UniqueID) { $elos = $elos + 1 } }
    try { $aloc = $aloc + @($t.Assignments).Count } catch {}
    try { $custo = $custo + [double]$t.FixedCost } catch {}
    try { $trab = $trab + [double]$t.Work } catch {}
    $bi = Txt $t.BaselineStart
    if ($bi) { $bases = $bases + 1 }
    try { if ([int]$t.PercentComplete -gt 0 -or [int]$t.PhysicalPercentComplete -gt 0) { $av = $av + 1 } } catch {}
    # ATENCAO: as DATAS de cada tarefa voltam para o Node conferir contra o XML.
    #   Contar tarefas nao e conferir cronograma: um .mpp com TODAS as datas
    #   erradas passa na contagem (medido: 7 de 8 tarefas fora, ate cinco meses).
    $null = $linhas.Add([ordered]@{ id=[int]$t.ID; nome=[string]$t.Name;
      inicio=(Txt $t.Start); fim=(Txt $t.Finish); dur=[int]$t.Duration; resumo=[bool]$t.Summary })
  }
  $r.tarefas = $n
  $r.resumos = $s
  $r.elos = $elos
  $r.alocacoes = $aloc
  $r.custoTotal = [math]::Round($custo, 2)
  $r.trabalho = $trab
  $r.bases = $bases
  $r.avancos = $av
  $r.linhas = @($linhas)
  try { $r.recursos = [int]$p.Resources.Count } catch {}
  try { $r.excecoes = [int]$p.Calendar.Exceptions.Count } catch {}
  try { $app.FileCloseEx(0) | Out-Null } catch {}
} catch {
  $r.erro = $_.Exception.Message
} finally {
  if ($app) { try { $app.Quit(0) | Out-Null } catch {} }
  Start-Sleep -Milliseconds 900
  # ATENCAO: delta com 2 ou mais = intruso na janela; nao se mata ninguem.
  if (@($meus).Count -eq 1) {
    foreach ($q in @(Get-Process WINPROJ -ErrorAction SilentlyContinue | Select-Object -Expand Id)) {
      if ($meus -contains $q) { Stop-Process -Id $q -Force -ErrorAction SilentlyContinue }
    }
  } elseif (@($meus).Count -gt 1) { $r.intruso = @($meus).Count }
}
Gravar 0
`;

/* ---------------------------------------------------------------------
   Execução
   --------------------------------------------------------------------- */
/* ⚠ `windowsHide: true` EM TODO PROCESSO FILHO, como em server/static.js: sem
   ele cada chamada abre uma janela de console na cara do cliente, e a janela
   nova ROUBA O FOCO de quem está digitando. */
function rodarPS(arquivoPs, args, ms, cb) {
  execFile('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', arquivoPs].concat(args),
    { maxBuffer: 1024 * 1024 * 8, windowsHide: true, timeout: ms },
    function (err, so, se) {
      const codigo = err && typeof err.code === 'number' ? err.code : (err ? -1 : 0);
      cb(null, { codigo: codigo, matou: !!(err && err.killed), saida: String(so || ''), erro: String(se || '') });
    });
}
// grava o .ps1 com BOM UTF-8 — ver o ⚠ dos scripts acima
function gravarPS(destino, texto) { fs.writeFileSync(destino, '\ufeff' + texto, 'utf8'); }
/* ⚠ O 5.1 grava JSON COM BOM (`Set-Content -Encoding UTF8`) e o JSON.parse do
   Node quebra no primeiro caractere. A ponte tem duas travessias com régua
   invertida — esta é a de volta. */
function lerJson(arquivo) {
  let t = fs.readFileSync(arquivo, 'utf8');
  if (t.charCodeAt(0) === 0xFEFF) t = t.slice(1);
  return JSON.parse(t);
}
/* Mata SÓ os PIDs que os nossos scripts anotaram, e só se ainda forem WINPROJ
   (PID é reciclado pelo Windows; matar por número cru um dia acerta outro
   programa). Usado quando o tempo estoura e o `finally` do script não roda.
   ⚠ DUAS PROVAS, NÃO UMA. `ProcessName -eq 'WINPROJ'` também dá verdadeiro para
   o Project do CLIENTE: se o PID foi reciclado num WINPROJ novo (ou se o delta
   adotou um intruso), a checagem de nome sozinha autoriza matar o arquivo dele.
   Por isso exige-se TAMBÉM que o processo tenha nascido depois de `desde` — o
   instante em que esta ponte começou. Um WINPROJ mais velho que isso não é
   nosso, e fica vivo. */
function matarPidsAnotados(arquivoPid, desde, cb) {
  if (typeof desde === 'function') { cb = desde; desde = 0; }
  let ids = [];
  try {
    ids = String(fs.readFileSync(arquivoPid, 'utf8')).split(',')
      .map(function (s) { return s.trim(); })
      .filter(function (s) { return /^\d{1,10}$/.test(s); });   // só dígito entra no comando
  } catch (e) {}
  if (!ids.length) return cb();
  /* ticks do .NET do instante em que a ponte começou — RELÓGIO UTC (`desde` é
     epoch, que é UTC por definição).
     ⚠ OS DOIS LADOS DA COMPARAÇÃO TÊM DE ESTAR NO MESMO FUSO, e este é o roteiro
     do defeito que ficou vivo até 12/09/2026: `$p.StartTime` do PowerShell vem em
     hora LOCAL e `$lim` era montado em UTC, sem conversão nenhuma. No Brasil
     (UTC-3) um WINPROJ nascido AGORA aparece 3 h ATRÁS do limite, o `-ge` dá
     falso e esta rede de segurança NUNCA DISPAROU — o WINPROJ que a ponte deixou
     pendurado ficava vivo para sempre, e a tela do cliente passava a dizer "o MS
     Project está aberto neste computador" por causa do processo dela mesma.
     Medido com um WINPROJ subido pelo mesmo caminho da sonda: $lim 13:24:49 (UTC)
     contra StartTime 10:24:50 (local) — sobreviveu. Só em GMT+0 os dois
     referenciais coincidiam, e nenhuma das instalações está em GMT+0.
     ⚠ E o assert que só conferisse "a função foi chamada" passaria nos dois
     mundos. A prova é subir um WINPROJ e exigir que ELE MORRA. */
  const ticks = desde ? String(Math.round(desde) * 10000 + 621355968000000000) : '0';
  const cmd = "$limUtc = [datetime]" + ticks + "; foreach ($i in @(" + ids.join(',') + ")) { " +
    "$p = Get-Process -Id $i -ErrorAction SilentlyContinue; " +
    "if (-not $p -or $p.ProcessName -ne 'WINPROJ') { continue }; " +
    /* ⚠ StartTime pode estourar (processo de outro usuário, processo que morreu
       entre o Get-Process e a leitura). Nesse caso NÃO se mata: não dá para
       provar que é nosso, e matar por palpite acerta o arquivo do cliente. */
    "$nasceuUtc = $null; try { $nasceuUtc = $p.StartTime.ToUniversalTime() } catch {}; " +
    "if ($limUtc.Ticks -eq 0 -or ($null -ne $nasceuUtc -and $nasceuUtc -ge $limUtc)) " +
    "{ Stop-Process -Id $i -Force -ErrorAction SilentlyContinue } }";
  execFile('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', cmd],
    { windowsHide: true, timeout: 20000 }, function () { cb(); });
}
/* ⚠ ESTA FUNÇÃO ESTOURA, E QUEM A CHAMA TEM DE ESTAR PREPARADO. `mkdirSync`
   falha com o disco cheio (ENOSPC — já aconteceu nesta base, 0 byte livre), com
   o %TEMP% apagado por faxineiro de disco, com antivírus e com permissão. Antes
   de 12/09/2026 as duas chamadas ficavam FORA de qualquer try: a exceção subia
   pelo `req.on('end')` da rota — callback assíncrono, fora do try/catch do
   createServer — e o servidor do cliente MORRIA. Medido por HTTP real: o POST
   levou ECONNRESET e o GET /index.html seguinte, ECONNREFUSED. O app inteiro
   caiu por causa de uma pasta temporária. Toda chamada daqui para baixo está
   dentro de try, e o recado diz o que aconteceu. */
function pastaTemp() {
  const d = path.join(os.tmpdir(), 'orcapro-mpp-' + process.pid + '-' + Date.now() + '-' + Math.floor(Math.random() * 1e6));
  fs.mkdirSync(d, { recursive: true });
  return d;
}
function apagarPasta(d) { try { fs.rmSync(d, { recursive: true, force: true }); } catch (e) {} }

/* ---------------------------------------------------------------------
   DESCOBERTA — registro + WINPROJ.EXE no disco + COM de verdade
   --------------------------------------------------------------------- */
let cacheSonda = null;      // { em, com, versaoCom, erro }
let sondaNoAr = null;       // coalescência: uma sonda por vez, nunca duas WINPROJ juntas
let cacheAbertos = null;    // { em, aberto } — a contagem de WINPROJ, ver contarAbertos
let contagemNoAr = null;    // coalescência da contagem: um powershell por vez

function descobrir(cb) {
  if (process.platform !== 'win32') {
    return cb({
      temProject: false, versao: null, automacao: 'indisponivel',
      motivo: 'O MS Project só existe no Windows, e este computador é ' + process.platform + '.',
      aberto: false
    });
  }
  let dir = null;
  try { dir = pastaTemp(); } catch (e) {
    /* ⚠ a mesma honestidade que já existia quatro linhas abaixo para o
       `gravarPS` — e aqui ela impede o servidor de morrer.
       ⚠ `verificou:false` NÃO É DETALHE. Sem ele, "não consegui medir" chega ao
       cliente como "o MS Project não está instalado neste computador" — uma
       afirmação sobre a máquina dele que ninguém apurou. Recado que mente é
       pior que recado nenhum, e este mentiria com todas as letras. */
    return cb({ temProject: false, verificou: false, versao: null, automacao: 'indisponivel', aberto: false,
      motivo: 'não consegui criar a pasta temporária da verificação (' + (e && e.message) + ').' });
  }
  const arqPs = path.join(dir, 'sonda.ps1');
  const arqRes = path.join(dir, 'sonda.json');
  function terminar(r) { apagarPasta(dir); cb(r); }
  try { gravarPS(arqPs, PS_SONDA); } catch (e) {
    return terminar({ temProject: false, verificou: false, versao: null, automacao: 'indisponivel', aberto: false,
      motivo: 'não consegui preparar a verificação: ' + e.message });
  }
  const comecou = Date.now();
  rodarPS(arqPs, ['-Saida', arqRes], MS_SONDA, function (_e, res) {
    let s = null;
    try { s = lerJson(arqRes); } catch (e) {}
    if (!s) {
      /* ⚠ Não dá para dizer "não tem Project" quando o que falhou foi a
         verificação: seria afirmar o que não se mediu. Diz o que aconteceu. */
      const pid = arqRes + '.pid';
      return matarPidsAnotados(pid, comecou, function () {
        terminar({ temProject: false, verificou: false, versao: null, automacao: 'indisponivel', aberto: false,
          motivo: res.matou ? 'a verificação passou de ' + Math.round(MS_SONDA / 1000) + ' s sem responder e foi interrompida.'
                            : 'a verificação não respondeu (PowerShell saiu com ' + res.codigo + ').' });
      });
    }
    /* ⚠ ANTES de `terminar()` apagar a pasta: o `.pid` é a única lista de quem
       ESTA sonda subiu, e sem ela a pergunta seguinte acusa o WINPROJ nosso de
       ser o do usuário. Ver contarAbertos. */
    anotarMeusWinproj(arqRes + '.pid');
    const temProject = !!s.existeExe;
    const aberto = Number(s.abertos || 0) > 0;
    /* ⚠ ABERTO SEM JANELA É OUTRO RECADO. "Feche o Project" vira parede quando
       não há janela para fechar — e a própria ponte fabrica esse estado (a sonda
       sobe um WINPROJ invisível; se o Node morrer no meio, ele sobra). Com o
       número de janelas dá para dizer o que a pessoa precisa fazer de verdade. */
    const semJanela = aberto && Number(s.janelas || 0) === 0;
    /* a versão do EXE vem primeiro porque é a build instalada
       (16.0.20326.20132) e existe mesmo quando o COM não responde; o COM
       devolve só a família ("16.0"). */
    const versao = String(s.versaoExe || s.versaoCom || '') || null;
    let automacao = 'indisponivel', motivo = '';
    if (!temProject) {
      motivo = s.clsid ? 'o registro aponta o MS Project em ' + (s.exe || '(sem caminho)') + ', mas o arquivo não está lá.'
                       : 'não achei o MS Project no registro deste computador.';
    } else if (aberto) {
      /* O COM não é tocado com o Project aberto — e "não medi" nunca vira
         "está tudo bem": o motivo diz exatamente o que falta. */
      motivo = semJanela
        ? 'sobrou um MS Project rodando em segundo plano neste computador, sem janela (Gerenciador de Tarefas → WINPROJ.EXE); enquanto ele estiver lá eu não mexo.'
        : 'o MS Project está aberto neste computador; feche-o para que eu possa usar a automação sem mexer no seu arquivo.';
    } else if (s.com === 'ok') {
      automacao = 'ok';
      motivo = 'MS Project ' + (versao || '?') + ' respondeu à automação neste computador.';
    } else if (s.com === 'cego') {
      motivo = 'o MS Project abriu, mas devolveu vazio em toda leitura (PowerShell ' + s.shell + ' ' + s.edicao + ') — a automação não pode ser conferida por aqui.';
    } else {
      motivo = 'o MS Project está instalado, mas não respondeu à automação' + (s.erro ? ': ' + String(s.erro).slice(0, 200) : '.');
    }
    /* só o resultado do COM é guardado — "aberto" é conferido toda vez */
    if (temProject && !aberto) cacheSonda = { em: Date.now(), com: s.com, versao: versao, motivo: motivo, automacao: automacao };
    terminar({ temProject: temProject, versao: versao, automacao: automacao, motivo: motivo, aberto: aberto,
      semJanela: semJanela, exe: s.exe || '', shell: s.shell + ' ' + s.edicao });
  });
}

/* Estado da ponte.
   ⚠ A PARTE QUE ENVELHECE E A PARTE QUE NÃO ENVELHECEM SÃO DIFERENTES: se a
   automação responde nesta máquina é propriedade do computador (vale por
   `CACHE_MS`); se o Project está aberto AGORA muda de minuto a minuto e é
   perguntado em TODA chamada, inclusive na do caminho guardado.
   ⚠ TRÊS PRAZOS, NÃO DOIS, e o recado tem de dizer a verdade sobre cada um:
     · `CACHE_MS` (10 min) — a resposta do COM, propriedade da máquina.
     · `CACHE_ABERTOS_MS` (1,5 s) — a contagem de WINPROJ para QUEM SÓ PERGUNTA.
       Existe porque, sem ela, cada pedido subia um powershell.exe: 60 pedidos
       quentes = 60 processos, medido. Ver contarAbertos.
     · nenhum — para quem vai ENCOSTAR no COM. `gerar` passa `agora:true` e paga
       a sua própria contagem, sem cache e sem carona. Foi o que esta linha já
       prometia ("nunca reaproveita o «não está aberto»") e agora é `agora` que
       cumpre a promessa; antes do cache curto ela era verdadeira de graça.
   `forcar` existe para quem quiser refazer a medição do COM do zero. */
/* ⚠ O TRY COBRE A CHAMADA, NUNCA A ENTREGA — e esta distinção foi descoberta
   pelo controle negativo, não pela leitura. A primeira versão envolvia
   `descobrir(soltarFila)` inteiro num try; como o `soltarFila` chama os
   callbacks LÁ DENTRO, qualquer erro de QUEM CONSOME a resposta era engolido
   pelo módulo, em silêncio, e o processo seguia como se nada tivesse
   acontecido. Foi assim que uma suíte inteira passou verde com a guarda
   sabotada. Agora: erro ANTES da entrega vira resposta honesta; erro DEPOIS é
   relançado, porque não é nosso para esconder. */
function sondar(fn, entregar) {
  let entregue = false;
  const uma = function (r) { if (entregue) return; entregue = true; entregar(r); };
  try { fn(uma); } catch (e) {
    if (entregue) throw e;
    uma({ temProject: false, verificou: false, versao: null, automacao: 'indisponivel', aberto: false,
      motivo: 'a verificação do MS Project falhou neste computador (' + (e && e.message) + ').' });
  }
}

function status(opts, cb) {
  if (typeof opts === 'function') { cb = opts; opts = null; }
  opts = opts || {};
  const ganchos = opts.ganchos || {};
  if (ganchos.descobrir) return sondar(ganchos.descobrir, cb);
  if (!opts.forcar && cacheSonda && (Date.now() - cacheSonda.em) < CACHE_MS) {
    /* o COM já foi medido há pouco; falta saber se o Project está aberto AGORA.
       ⚠ `opts.agora` é quem vai ENCOSTAR no COM (o `gerar`): ele não aceita
       contagem reaproveitada, nem a de 1,5 s atrás. Ver contarAbertos. */
    return contarAbertos(!!opts.agora, function (aberto) {
      if (aberto) {
        return cb({ temProject: true, versao: cacheSonda.versao, automacao: 'indisponivel', aberto: true,
          motivo: 'o MS Project está aberto neste computador; feche-o para que eu possa usar a automação sem mexer no seu arquivo.' });
      }
      cb({ temProject: true, versao: cacheSonda.versao, automacao: cacheSonda.automacao, motivo: cacheSonda.motivo, aberto: false });
    });
  }
  /* uma sonda por vez: dez perguntas seguidas não podem virar dez WINPROJ */
  if (sondaNoAr) { sondaNoAr.push(cb); return; }
  sondaNoAr = [cb];
  /* ⚠ QUALQUER exceção antes da resposta tem de esvaziar a fila. A coalescência
     é a defesa que impede dez perguntas virarem dez WINPROJ — e era também a
     armadilha: com `descobrir` estourando (TEMP quebrado), `sondaNoAr` ficava
     `[cb]` para SEMPRE e o GET /__mpp/status nunca mais respondia, nem depois de
     o disco voltar. Medido antes do conserto: respondeu = false. */
  sondar(descobrir, function (r) {
    const fila = sondaNoAr; sondaNoAr = null;
    if (fila) fila.forEach(function (f) { f(r); });
  });
}
/* ⚠ OS WINPROJ QUE A PRÓPRIA PONTE SUBIU NÃO CONTAM COMO "o Project está aberto".
 *
 * ROTEIRO DO DEFEITO (medido em 12/09/2026, tools/e2e-cronograma-pro.js):
 * a sonda sobe UM WINPROJ invisível por ~3 s para saber se a automação responde,
 * e o mata no fim. Mas `Stop-Process` não tira o processo da tabela na mesma
 * hora. Duas perguntas seguidas de status — e "seguidas" aqui é a tela e o
 * servidor perguntando quase junto — faziam a segunda ver o WINPROJ da primeira
 * e responder "o MS Project está aberto neste computador; feche-o". Com o
 * usuário sem NADA aberto. Recado que mente é pior que recado nenhum, e este
 * mandava fechar uma janela que não existe — trava sem porta.
 *
 * O trinco `sondaNoAr` já impedia dez perguntas virarem dez WINPROJ; ele não
 * alcança este caso, porque a primeira sonda JÁ TERMINOU (e cacheou) quando a
 * segunda pergunta chega pelo caminho do cache, que só conta processos.
 *
 * Aqui a ponte anota os PIDs que ela mesma subiu e os desconta por uma janela
 * curta. Passada a janela, um WINPROJ nosso que não morreu É um problema de
 * verdade — e aí ele volta a contar, com o recado de "sobrou em segundo plano". */
const GRACA_MEUS_MS = 45000;
let meusWinproj = [];   // [{ pid, em }]
function anotarMeusWinproj(arquivoPid) {
  try {
    const ids = String(fs.readFileSync(arquivoPid, 'utf8')).split(',')
      .map(function (s) { return s.trim(); })
      .filter(function (s) { return /^\d{1,10}$/.test(s); });
    const agora = Date.now();
    ids.forEach(function (p) { meusWinproj.push({ pid: p, em: agora }); });
  } catch (e) { /* sem arquivo = a sonda não chegou a subir nada */ }
  const corte = Date.now() - GRACA_MEUS_MS;
  meusWinproj = meusWinproj.filter(function (x) { return x.em > corte; });
}
/* ⚠ A REGRA MORA AQUI, NUM LUGAR SÓ. `contarAbertos` mede os processos e o
   teste injeta a lista — os dois chamam ESTA função. Duas cópias da mesma
   régua é o defeito que apodrece calado (memória "réplica de parser apodrece"):
   uma delas seria "simplificada" e o teste continuaria verde sobre a outra. */
function abertoDeOutrem(vivos) {
  const corte = Date.now() - GRACA_MEUS_MS, meus = {};
  meusWinproj.forEach(function (x) { if (x.em > corte) meus[x.pid] = true; });
  return (vivos || []).map(String).filter(function (p) { return !meus[p]; }).length > 0;
}
/* ⚠ UMA CONTAGEM POR VEZ, E ELA VALE POR UM INSTANTE.
 *
 * ROTEIRO DO DEFEITO (medido em 12/09/2026, contando o PID REAL de cada filho):
 * o trinco `sondaNoAr` coalesce a SONDA — a parte cara, que sobe WINPROJ. Só que
 * o caminho do CACHE, que é o normal depois da primeira medição, não passa por
 * ele: cai aqui, e aqui não havia trinco nenhum. 60 GET /__mpp/status quentes
 * viraram 60 powershell.exe DISTINTOS, 60 vivos ao mesmo tempo, 4,4 s. A tela
 * pergunta o estado a cada abertura da aba e o servidor repergunta; com o app
 * aberto o dia inteiro no canteiro isso é uma enxurrada de processos na máquina
 * do cliente. Pior: o comentário da rota em server/static.js AFIRMAVA que "a
 * repetição não vira uma fila de processos" — comentário é o que a próxima
 * sessão obedece, e este mandava confiar numa defesa que não existia.
 *
 * Duas defesas, e as duas precisam existir:
 *  · COALESCÊNCIA — quem chega durante uma medição no ar compartilha a resposta
 *    dela em vez de abrir a sua.
 *  · CACHE CURTO — sem ele, rajadas SEQUENCIAIS (a tela repergunta a cada troca
 *    de aba) voltariam a ser um processo por rajada. Curto de propósito: este é
 *    justamente o dado que NÃO pode envelhecer, porque é ele que impede o COM de
 *    encostar no arquivo aberto do cliente. Vale por um instante, não por minutos.
 *
 * ⚠ QUEM VAI TOCAR NO COM NÃO USA O CACHE. `gerar` pede `agora:true` e paga o seu
 * próprio powershell — é uma vez por clique, e a promessa escrita lá em cima ("o
 * `gerar` nunca reaproveita o «não está aberto»") tem de continuar verdadeira.
 * A defesa final continua sendo o próprio PS_CONVERTER, que recusa sozinho.
 *
 * ⚠ A FILA TEM DE SOBREVIVER A ERRO — mesma cicatriz do `sondaNoAr`: fila
 * pendurada = GET /__mpp/status que não responde NUNCA MAIS. Por isso a entrega é
 * única e o `execFile` está dentro de try (ele estoura SÍNCRONO quando falta
 * descritor de processo, e aí ninguém soltaria a fila).
 * ⚠ E O TRY COBRE A CHAMADA, NUNCA A ENTREGA — a mesma distinção que o controle
 * negativo do `sondar` descobriu: o callback do `execFile` roda depois, fora
 * deste try, então erro de QUEM CONSOME a resposta sobe, em vez de ser engolido
 * pelo módulo em silêncio. Foi assim que uma suíte inteira passou verde com a
 * guarda sabotada. */
const CACHE_ABERTOS_MS = 1500;
function contarAbertos(agora, cb) {
  if (typeof agora === 'function') { cb = agora; agora = false; }
  if (process.platform !== 'win32') return cb(false);
  if (!agora) {
    if (cacheAbertos && (Date.now() - cacheAbertos.em) < CACHE_ABERTOS_MS) return cb(cacheAbertos.aberto);
    if (contagemNoAr) { contagemNoAr.push(cb); return; }
    contagemNoAr = [cb];
  }
  let entregue = false;
  const entregar = function (aberto) {
    if (entregue) return;
    entregue = true;
    cacheAbertos = { em: Date.now(), aberto: aberto };
    if (agora) return cb(aberto);
    /* ⚠ a fila sai de cena ANTES de ser servida: um callback que pergunte de
       novo lá dentro tem de abrir a sua própria medição, não entrar numa fila
       que já está sendo esvaziada. */
    const fila = contagemNoAr; contagemNoAr = null;
    if (fila) fila.forEach(function (f) { f(aberto); });
  };
  try {
    execFile('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command',
      "@(Get-Process WINPROJ -ErrorAction SilentlyContinue | Select-Object -Expand Id) -join ','"],
      { windowsHide: true, timeout: 20000 }, function (err, so) {
        if (err) return entregar(false);   // não consegui contar: quem decide de verdade é o script, que recusa sozinho
        const vivos = String(so || '').trim().split(',')
          .map(function (s) { return s.trim(); })
          .filter(function (s) { return /^\d{1,10}$/.test(s); });
        entregar(abertoDeOutrem(vivos));
      });
  } catch (e) { entregar(false); }
}

/* ---------------------------------------------------------------------
   GERAR
   --------------------------------------------------------------------- */
const RECADO_XML = 'Baixe o arquivo XML — o Project abre XML direto.';

/* ⚠ O QUE A PONTE NÃO LEVA — dito em português, com nome, porque a tela repete
   este texto. Recado que mente é pior que recado nenhum, e "gera o cronograma
   no Project" faz o leitor supor que vai TUDO. Nenhum destes muda data nem
   dinheiro; todos existem no XML. */
const FALTOU = [
  'as anotações de cada tarefa (frente, folga, quantidade) — elas estão no XML',
  'o prazo-limite (a seta de Deadline) e a folga em campo',
  'a numeração da planilha (WBS) — no .mpp vale a numeração do próprio Project'
];
/* ⚠ O QUE FALTA DEPENDE DO QUE O XML TRAZ. A linha de base 0 atravessa; as 1
   a 10 (as reprogramações) não — escrever `Baseline1Start` por COM sem nunca
   ter aberto o resultado no Project real seria prometer o que não foi medido
   (pendência declarada). Dizer isso só quando elas existem evita o recado que
   assusta à toa e o silêncio que engana. */
function faltouDo(plano) {
  const extras = (plano.tarefas || []).reduce((m, t) => Math.max(m, Number(t.basesExtras) || 0), 0);
  if (!extras) return FALTOU;
  return FALTOU.concat(['as linhas de base 1 a 10 (as reprogramações) — no .mpp vai só a linha de base ativa; ' +
    'todas estão no XML']);
}

/* Compara as datas que o PROJECT devolveu com as que o XML declara, tarefa a
   tarefa, pela ORDEM (o conversor cria as tarefas na ordem do XML e a releitura
   varre `Tasks` na mesma ordem — o `ID` do Project é essa posição).
   ⚠ COMPARA O DIA, NÃO O INSTANTE. O calendário da máquina pode ter turno
   diferente (medido: o padrão desta começa às 9 h, e o conversor o reescreve
   para 8 h), e o resumo do Project termina no instante do último filho. Quem o
   cliente lê na coluna "Término" é a DATA.
   ⚠ RESUMO FICA DE FORA: a duração e as datas dele o Project calcula pelos
   filhos, e é assim que tem de ser — conferi-lo seria conferir a nossa própria
   aritmética, não o arquivo. */
function soData(s) { return String(s || '').slice(0, 10); }
function difDias(a, b) {
  const x = Date.parse(a + 'T12:00:00'), y = Date.parse(b + 'T12:00:00');
  if (!isFinite(x) || !isFinite(y)) return 0;
  return Math.round(Math.abs(x - y) / 86400000);
}
function compararDatas(plano, linhas) {
  const out = { comparadas: 0, fora: [], maiorDias: 0, exemplo: '', erro: '' };
  /* ⚠ UMA GUARDA SÓ, e de propósito: eram duas (uma para a lista vazia, outra
     para o tamanho errado) e a redundância ESCONDIA o furo do controle negativo
     — desligar uma delas não reprovava nada, porque a outra pegava. Guarda que
     sobrevive à própria sabotagem não prova o que protege.
     ⚠ "não consegui conferir" NUNCA vira "está tudo bem": é o mesmo princípio
     que já recusa o arquivo quando a releitura não responde. */
  if (!Array.isArray(linhas) || linhas.length !== plano.tarefas.length) {
    out.erro = 'a releitura devolveu ' + (Array.isArray(linhas) ? linhas.length + ' linha(s)' : 'nada') +
      ' para ' + plano.tarefas.length + ' tarefa(s)';
    return out;
  }
  plano.tarefas.forEach(function (t, i) {
    const L = linhas[i];
    if (!L || t.resumo || L.resumo) return;
    if (!t.inicio && !t.fim) return;            // o XML não declarou: nada a conferir
    const parInicio = [soData(t.inicio), soData(L.inicio)];
    const parFim = [soData(t.fim), soData(L.fim)];
    let d = 0;
    if (parInicio[0] && parInicio[1] && parInicio[0] !== parInicio[1]) d = difDias(parInicio[0], parInicio[1]);
    if (parFim[0] && parFim[1] && parFim[0] !== parFim[1]) d = Math.max(d, difDias(parFim[0], parFim[1]));
    out.comparadas++;
    if (!d) return;
    out.fora.push(t.uid);
    if (d > out.maiorDias) {
      out.maiorDias = d;
      out.exemplo = '"' + String(t.nome || '').slice(0, 40) + '": o cronograma diz ' +
        (parInicio[0] || '?') + ' e o arquivo abriu em ' + (parInicio[1] || '?');
    }
  });
  if (out.fora.length && !out.exemplo) out.exemplo = out.fora.length + ' tarefa(s)';
  return out;
}

/* ⚠ UMA GERAÇÃO POR VEZ, e isto não é zelo: o conversor RECUSA quando acha um
   WINPROJ vivo (é a defesa que impede mexer no documento do usuário). Dois
   cliques seguidos fariam o segundo pedido encontrar o WINPROJ do PRIMEIRO e
   responder "feche o MS Project" — uma mensagem falsa, mandando o cliente
   procurar uma janela que não existe. Recado que mente é pior que recado
   nenhum: aqui ele diz a verdade, que é "espere o anterior terminar". */
let gerando = false;

/* O nome que o cliente vê no download. ⚠ NADA DAQUI VIRA CAMINHO DE ARQUIVO —
   o .mpp é gravado com nome fixo numa pasta temporária nossa. Este texto só
   entra num cabeçalho HTTP, e por isso CR/LF e aspas saem fora (com eles, o
   nome da obra forjaria um cabeçalho inteiro). */
function nomeMpp(nome) {
  let n = String(nome == null ? '' : nome).replace(/[\r\n\t"\\/:*?<>|]+/g, ' ').replace(/\s+/g, ' ').trim();
  n = n.replace(/\.(xml|mpp)$/i, '');
  if (n.length > 80) n = n.slice(0, 80).trim();
  return (n || 'Cronograma') + '.mpp';
}

function recusa(codigo, erro, extra) {
  const o = { ok: false, codigo: codigo, erro: erro };
  if (extra) Object.keys(extra).forEach(function (k) { o[k] = extra[k]; });
  return o;
}

/* xml: o MSPDI que js/msproject.js gerou.
   cb(resultado): { ok:true, buffer, bytes, tarefas, nome } ou
                  { ok:false, codigo, erro }  — `erro` é o texto que o cliente lê.
   ⚠ opts.ganchos existe para o TESTE (trocar a descoberta, o conversor e a
     releitura por dublês), porque o gate roda em máquina sem MS Project. O
     produto nunca passa ganchos: a rota chama gerar(xml, null, cb). */
function gerar(xml, opts, cb) {
  if (typeof opts === 'function') { cb = opts; opts = null; }
  opts = opts || {};
  const ganchos = opts.ganchos || {};

  const plano = planoDoXML(xml);
  if (!plano.tarefas.length) {
    return cb(recusa('xml-vazio', 'O cronograma veio sem tarefa nenhuma. Gere o cronograma antes de exportar.'));
  }
  /* ⚠ SEM CALENDÁRIO O PROJECT RECALCULA PELA SEMANA DELE e devolve datas
     diferentes das do PDF. Melhor recusar do que entregar outro cronograma. */
  if (plano.semana.indexOf(true) < 0) {
    return cb(recusa('xml-sem-calendario', 'O arquivo do cronograma veio sem calendário de trabalho. ' + RECADO_XML));
  }
  if (gerando) {
    return cb(recusa('ocupado', 'Já estou gerando um .mpp neste computador. Espere este terminar e clique de novo.'));
  }
  gerando = true;
  /* daqui para baixo TODA saída passa por `responder` — é ele que solta o
     trinco. Um `cb` direto deixaria a ponte travada até reiniciar o servidor. */
  const responder = function (r) { gerando = false; cb(r); };

  /* ⚠ `agora: true` = contagem de WINPROJ FRESCA, sem cache e sem carona numa
     medição já no ar. Quem está prestes a abrir o COM não pode decidir por uma
     foto de 1,5 s atrás: nesse intervalo o cliente pode ter aberto o Project, e
     o `New-Object` se anexaria à instância dele. Custa um powershell por clique
     em [Gerar .mpp] — e é o único caminho que paga esse preço. */
  status({ ganchos: ganchos, agora: true }, function (st) {
    if (!st.temProject) {
      /* ⚠ "NÃO CONSEGUI MEDIR" NÃO É "NÃO TEM". Quando a verificação nem rodou
         (pasta temporária que não nasce, PowerShell que não responde), dizer ao
         cliente que o MS Project não está instalado é afirmar sobre a máquina
         dele uma coisa que ninguém apurou — e ele vai procurar o defeito no
         lugar errado. Medido: com o %TEMP% quebrado, a resposta era
         literalmente "O MS Project não está instalado neste computador". */
      if (st.verificou === false) {
        return responder(recusa('nao-verificado',
          'Não consegui verificar o MS Project neste computador, então não sei se dá para gerar o .mpp aqui. ' +
          RECADO_XML, { detalhe: st.motivo }));
      }
      return responder(recusa('sem-project',
        'O MS Project não está instalado neste computador. ' + RECADO_XML, { detalhe: st.motivo }));
    }
    /* ⚠ RECUSA ANTES DE TOCAR NO COM. `New-Object -ComObject MSProject.Application`
       pode se anexar à instância que o cliente está usando; o FileNew criaria um
       projeto na cara dele e o Quit fecharia o trabalho, possivelmente não salvo. */
    if (st.aberto) {
      /* ⚠ TODA TRAVA PRECISA DE PORTA. Esta era a única recusa do módulo sem
         saída: mandava "feche o Project" e não oferecia o XML — e quando o que
         está aberto é um WINPROJ SEM JANELA (que a própria ponte fabrica), a
         pessoa procura uma janela que não existe e fica sem alternativa. */
      return responder(recusa('project-aberto', st.semJanela
        ? 'Sobrou um MS Project rodando em segundo plano neste computador, sem janela. Abra o Gerenciador de Tarefas, encerre o WINPROJ.EXE e clique de novo — enquanto ele estiver lá eu não mexo. ' + RECADO_XML
        : 'O MS Project está aberto neste computador. Feche o Project e clique de novo — ' +
          'com ele aberto eu não mexo, para não arriscar o arquivo que você tem lá dentro. ' + RECADO_XML));
    }
    if (st.automacao !== 'ok') {
      return responder(recusa('automacao-indisponivel',
        'O MS Project está instalado aqui, mas a automação dele não respondeu, então não consigo gerar o .mpp neste computador. ' +
        RECADO_XML, { detalhe: st.motivo }));
    }

    /* ⚠ DENTRO DO TRY. Antes de 12/09/2026 esta linha ficava solta, dentro de um
       callback assíncrono, e uma falha de %TEMP% derrubava o SERVIDOR do cliente
       — o app inteiro, não só a ponte (medido por HTTP real). E, sem soltar o
       trinco, o POST seguinte responderia "já estou gerando" para sempre. */
    let dir = null;
    try { dir = pastaTemp(); } catch (e) {
      return responder(recusa('temp', 'Não consegui criar a pasta temporária deste computador (' + (e && e.message) + '). ' + RECADO_XML));
    }
    const arqPlano = path.join(dir, 'plano.json');
    const arqPs = path.join(dir, 'converter.ps1');
    const arqRes = path.join(dir, 'res.json');
    const arqPs2 = path.join(dir, 'recontar.ps1');
    const arqRes2 = path.join(dir, 'recontar.json');
    /* ⚠ NADA VINDO DO XML ENTRA EM CAMINHO DE ARQUIVO. O nome do .mpp é gerado
       aqui; o nome que o cliente vê sai depois, no cabeçalho HTTP. */
    const arqMpp = path.join(dir, 'cronograma.mpp');
    function terminar(r) { apagarPasta(dir); responder(r); }

    try {
      fs.writeFileSync(arqPlano, JSON.stringify(plano), 'utf8');
      gravarPS(arqPs, PS_CONVERTER);
      gravarPS(arqPs2, PS_RECONTAR);
    } catch (e) {
      return terminar(recusa('temp', 'Não consegui preparar os arquivos temporários: ' + e.message));
    }

    const converter = ganchos.converter || function (a, fim) {
      rodarPS(arqPs, ['-Plano', a.plano, '-Saida', a.saida, '-Res', a.res], MS_CONVERTER, fim);
    };
    const comecou = Date.now();
    converter({ plano: arqPlano, saida: arqMpp, res: arqRes, dir: dir }, function (_e, exec) {
      exec = exec || { codigo: -1, matou: false };
      let r = null;
      try { r = lerJson(arqRes); } catch (e) {}

      function limparEDizer(resp) {
        matarPidsAnotados(arqRes + '.pid', comecou, function () { terminar(resp); });
      }
      if (exec.matou) {
        return limparEDizer(recusa('demorou',
          'O MS Project não terminou em ' + Math.round(MS_CONVERTER / 60000) + ' minutos e eu interrompi. ' + RECADO_XML));
      }
      if (r && r.erro === 'project-aberto') {
        return limparEDizer(recusa('project-aberto',
          'O MS Project foi aberto no meio da geração. Feche o Project e clique de novo. ' + RECADO_XML));
      }
      /* ⚠ INTRUSO: apareceu um segundo WINPROJ na janela entre o snapshot e o
         New-Object. O script não matou NINGUÉM de propósito (um deles pode ser o
         arquivo do cliente), então quem avisa somos nós — e o MS Project do
         cliente continua vivo, que é o ponto. */
      if (r && Number(r.intruso || 0) > 1) {
        return terminar(recusa('intruso',
          'Apareceu um MS Project neste computador no meio da geração, e eu não sei qual é o seu — ' +
          'por isso não fechei nenhum. Feche os MS Project abertos e clique de novo. ' + RECADO_XML));
      }
      if (!fs.existsSync(arqMpp)) {
        return limparEDizer(recusa('nao-gerou',
          'O MS Project não chegou a gravar o arquivo' + (r && r.erro ? ' (' + r.erro + ')' : '') + '. ' + RECADO_XML));
      }
      /* assinatura OLE: um .mpp de verdade começa com D0 CF 11 E0 A1 B1 1A E1.
         Sem esta conferência, um arquivo de outro formato com a extensão certa
         passaria — e o cliente descobriria na frente do contratante. */
      let buf = null;
      try { buf = fs.readFileSync(arqMpp); } catch (e) {}
      if (!buf || buf.length < 8 || !ASSINATURA_OLE.every(function (b, i) { return buf[i] === b; })) {
        return limparEDizer(recusa('formato',
          'O arquivo gerado não é um .mpp válido. ' + RECADO_XML));
      }

      /* ⚠ O RELATÓRIO DO CONVERSOR NÃO PODE SER LIDO E JOGADO FORA. Ele monta
         `falhas`, `elosPedidos`/`elosFeitos` e `excecoes` justamente porque cada
         `TaskDependencies.Add` e cada `Exceptions.Add` pode estourar sozinho — o
         `Passo` engole a exceção e soma em $falhas para não perder o arquivo
         inteiro por causa de um elo. Até 12/09/2026 o Node lia esse JSON e usava
         só `r.erro`: simulado o desastre (7 falhas, 0 de 2 elos, 0 feriado), a
         ponte respondeu ok:true e ENTREGOU. Um .mpp com as tarefas certas e ZERO
         dependência abre no Project com tudo começando na data de início — datas
         completamente diferentes do PDF que o contratante já tem, que é a "duas
         verdades" que este módulo existe para impedir.
         ⚠ O FERIADO ENTRA NA MESMA RÉGUA: sem a exceção de calendário o Project
         recalcula pela semana dele e ANTECIPA a entrega. */
      if (r) {
        const falta = [];
        if (Number(r.elosFeitos || 0) !== Number(r.elosPedidos || 0)) {
          falta.push('o cronograma tem ' + Number(r.elosPedidos || 0) + ' ligação(ões) entre tarefas e ' +
            Number(r.elosFeitos || 0) + ' entrou(aram) no arquivo');
        }
        if (Number(r.excecoes || 0) !== plano.excecoes.length) {
          falta.push('o calendário tem ' + plano.excecoes.length + ' feriado(s) e ' +
            Number(r.excecoes || 0) + ' entrou(aram) — sem eles o Project recalcula e antecipa a entrega');
        }
        if (!falta.length && Number(r.falhas || 0) > 0) {
          falta.push(Number(r.falhas) + ' passo(s) da montagem falharam no MS Project' + (r.erro ? ' (' + r.erro + ')' : ''));
        }
        if (falta.length) {
          try { fs.unlinkSync(arqMpp); } catch (e) {}
          return limparEDizer(recusa('rede-incompleta',
            'O .mpp saiu incompleto: ' + falta.join('; ') + '. Apaguei o arquivo, porque assim ele ' +
            'mostraria datas diferentes das do PDF que o cliente já tem. ' + RECADO_XML));
        }
      }

      /* ⚠ CONTAR AS TAREFAS, NUNCA OS BYTES. Um .mpp de 239 KB com ZERO tarefa
         já foi produzido nesta máquina: ele tem o tamanho, a assinatura e abre
         no Project — vazio. Qualquer conferência por tamanho o aprovaria, e o
         cliente levaria um cronograma em branco para a reunião. Por isso o
         arquivo é REABERTO pelo próprio Project, num processo novo, e as
         tarefas são contadas lá dentro. */
      const recontar = ganchos.recontar || function (a, fim) {
        rodarPS(arqPs2, ['-Arquivo', a.arquivo, '-Res', a.res], MS_RECONTAR, fim);
      };
      recontar({ arquivo: arqMpp, res: arqRes2 }, function (_e2, exec2) {
        exec2 = exec2 || { codigo: -1, matou: false };
        let c = null;
        try { c = lerJson(arqRes2); } catch (e) {}
        function falharNaConferencia(texto, codigo) {
          try { fs.unlinkSync(arqMpp); } catch (e) {}
          matarPidsAnotados(arqRes2 + '.pid', comecou, function () { terminar(recusa(codigo, texto)); });
        }
        if (!c || c.tarefas == null || c.tarefas < 0) {
          /* ⚠ Recado que mente é pior que recado nenhum: o arquivo até existe,
             mas não foi possível conferir — então ele NÃO é entregue. */
          return falharNaConferencia(
            'Gerei o arquivo, mas não consegui reabri-lo para conferir' +
            (c && c.erro ? ' (' + c.erro + ')' : exec2.matou ? ' (passou de ' + Math.round(MS_RECONTAR / 60000) + ' minutos)' : '') +
            '. Não entrego um .mpp que não pude verificar. ' + RECADO_XML, 'nao-conferido');
        }
        if (c.tarefas === 0) {
          return falharNaConferencia(
            'O arquivo saiu VAZIO: o Project gravou o .mpp, mas ao reabrir ele tem 0 tarefa das ' +
            plano.tarefas.length + ' do cronograma. Apaguei o arquivo. ' + RECADO_XML, 'vazio');
        }
        if (c.tarefas !== plano.tarefas.length) {
          return falharNaConferencia(
            'O arquivo saiu incompleto: o cronograma tem ' + plano.tarefas.length + ' tarefas e o .mpp reabriu com ' +
            c.tarefas + '. Apaguei o arquivo. ' + RECADO_XML, 'incompleto');
        }
        /* ⚠ CONTAR TAREFAS TAMBÉM NÃO É CONFERIR O CRONOGRAMA. Com uma única
           linha sabotada (os décimos de minuto tratados como minutos), o .mpp
           saiu com 8 de 8 tarefas, assinatura OLE, 247 KB — e SETE delas com
           início e fim errados, uma por cinco meses. A contagem continuou certa
           o tempo todo. Por isso a releitura devolve as DATAS de cada tarefa e
           elas são comparadas com as que o XML declara, tarefa a tarefa. */
        const dif = compararDatas(plano, c.linhas);
        if (dif.erro) {
          return falharNaConferencia('Gerei o arquivo, mas não consegui conferir as datas dentro dele (' +
            dif.erro + '). Não entrego um .mpp que não pude verificar. ' + RECADO_XML, 'nao-conferido');
        }
        if (dif.fora.length) {
          return falharNaConferencia(
            'O .mpp saiu com datas diferentes das do cronograma: ' + dif.fora.length + ' de ' +
            dif.comparadas + ' tarefa(s) fora do lugar' + (dif.maiorDias ? ', a pior por ' + dif.maiorDias + ' dia(s)' : '') +
            ' (' + dif.exemplo + '). Apaguei o arquivo — ele mostraria outro cronograma ao contratante. ' + RECADO_XML,
            'datas-divergentes');
        }
        terminar({
          ok: true, buffer: buf, bytes: buf.length, tarefas: c.tarefas, resumos: c.resumos || 0,
          nome: nomeMpp(plano.nome), versaoProject: st.versao || '',
          /* o que foi CONFERIDO dentro do arquivo, para a tela mostrar número em
             vez de promessa — e `faltou` para ela não prometer o que não foi */
          conferido: {
            tarefas: c.tarefas, datas: dif.comparadas, elos: Number(c.elos || 0), feriados: Number(c.excecoes || 0),
            recursos: Number(c.recursos || 0), alocacoes: Number(c.alocacoes || 0),
            custoTotal: Number(c.custoTotal || 0), horas: Math.round(Number(c.trabalho || 0) / 60 * 10) / 10,
            bases: Number(c.bases || 0), avancos: Number(c.avancos || 0)
          },
          faltou: faltouDo(plano)
        });
      });
    });
  });
}

module.exports = {
  planoDoXML: planoDoXML,
  compararDatas: compararDatas,
  FALTOU: FALTOU,
  nomeMpp: nomeMpp,
  descobrir: descobrir,
  status: status,
  gerar: gerar,
  MIN_DIA: MIN_DIA,
  DEC_POR_DIA: DEC_POR_DIA,
  ASSINATURA_OLE: ASSINATURA_OLE,
  MS_CONVERTER: MS_CONVERTER,
  _scripts: { sonda: PS_SONDA, converter: PS_CONVERTER, recontar: PS_RECONTAR },
  /* usado pelo teste para não herdar a sonda de uma medição anterior
     ⚠ NÃO mexe em `contagemNoAr`: zerar uma fila EM VOO faz a medição que está
     no ar entregar para ninguém e a próxima chamada abrir uma segunda — que é o
     defeito que a coalescência existe para impedir. */
  _limparCache: function () { cacheSonda = null; meusWinproj = []; cacheAbertos = null; },
  /* semeia SÓ a parte que não envelhece (o resultado do COM), para a bancada
     exercitar o caminho do CACHE — o único que chama `contarAbertos` — sem MS
     Project instalado. O gate roda em máquina sem Project. */
  _semearCache: function (versao) {
    cacheSonda = { em: Date.now(), com: 'ok', versao: versao || '16.0', automacao: 'ok',
      motivo: 'MS Project ' + (versao || '16.0') + ' respondeu à automação neste computador.' };
  },
  /* a bancada do "WINPROJ que é NOSSO não conta como Project aberto": o teste
     anota PIDs falsos e pergunta, sem subir Project nenhum */
  GRACA_MEUS_MS: GRACA_MEUS_MS,
  _meus: function () { return meusWinproj.slice(); },
  _anotarMeus: function (pids, quando) {
    const agora = quando == null ? Date.now() : quando;
    (pids || []).forEach(function (p) { meusWinproj.push({ pid: String(p), em: agora }); });
  },
  /* a MESMA função que o contarAbertos usa — não uma cópia dela */
  _abertoDeOutrem: abertoDeOutrem,
  /* ⚠ A REDE DE SEGURANÇA SÓ SE PROVA MATANDO. Assert que confere "a função foi
     chamada" passa nos dois mundos — e passou: a comparação de fuso deixou esta
     limpeza inerte no Brasil por toda a vida dela. A bancada sobe um WINPROJ
     pelo mesmo caminho da sonda e exige que ELE MORRA. */
  _matarPidsAnotados: matarPidsAnotados
};
