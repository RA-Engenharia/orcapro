' =====================================================================
'  iniciar-oculto.vbs — sobe um processo SEM janela de console
'
'  POR QUE ISTO EXISTE (27/08/2026)
'  O Iniciar-OrcaPRO.bat subia o servidor assim:
'      start "OrcaPRO App" /min cmd /c "node server\static.js"
'  Isso deixa uma JANELA DE CONSOLE ABERTA O TEMPO TODO na barra de
'  tarefas do cliente — o próprio .bat admitia isso na última linha
'  ("as duas janelas minimizadas precisam ficar abertas"). Minimizada
'  não é escondida: ela ocupa a barra, aparece no Alt+Tab, e quem clica
'  sem querer e aperta uma tecla derruba o servidor no meio do trabalho.
'
'  Clientes reclamaram. Aqui a janela não é criada: `Run` com o segundo
'  argumento 0 nasce sem console.
'
'  O terceiro argumento é False (não esperar) DE PROPÓSITO: o servidor
'  roda até ser parado, e esperar por ele deixaria o .bat pendurado para
'  sempre.
'
'  ⚠ SEM JANELA, PRECISA HAVER COMO PARAR. Antes o cliente fechava a
'    janela; agora existe o Fechar-OrcaPRO.bat, que derruba SÓ o node da
'    porta do app — nunca todos os node da máquina.
'
'  Uso:  wscript //B //Nologo iniciar-oculto.vbs "<pasta>" "<comando>"
' =====================================================================
Option Explicit

Dim sh, pasta, comando
Set sh = CreateObject("WScript.Shell")

If WScript.Arguments.Count < 2 Then
  WScript.Quit 2
End If

pasta   = WScript.Arguments(0)
comando = WScript.Arguments(1)

On Error Resume Next
sh.CurrentDirectory = pasta
On Error GoTo 0

' 0 = sem janela · False = não esperar (o servidor fica no ar)
sh.Run comando, 0, False
WScript.Quit 0
