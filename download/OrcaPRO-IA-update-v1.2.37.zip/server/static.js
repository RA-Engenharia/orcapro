/* =====================================================================
 * static.js — Servidor estático do OrçaPRO (sem dependências)
 * Serve a pasta do app em http://localhost:8754 com no-cache (sempre a
 * versão mais nova). Só precisa do Node.js. Porta via env PORT_APP.
 *
 * + AUTO-UPDATE (roda no PC do cliente, tem acesso ao disco):
 *   GET  /__update/check  -> compara a versão instalada com o latest.json do GitHub
 *   POST /__update/apply  -> baixa o pacote do Release, extrai num STAGE, valida
 *                            (index.html + versão bate) e só então promove por cima.
 *   Os dados do cliente ficam no navegador (localStorage) — a troca de arquivos não os toca.
 * ===================================================================== */
'use strict';
const http = require('http');
const https = require('https');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile, spawn } = require('child_process');

const PORT = process.env.PORT_APP || 8754;
const ROOT = path.join(__dirname, '..');  // a raiz do OrçaPRO (onde está o index.html)

// Manifesto de versão (fonte da verdade do "tem atualização?"). URL FIXA e confiável.
const MANIFEST_URL = process.env.ORCAPRO_MANIFEST || 'https://raw.githubusercontent.com/RA-Engenharia/orcapro/main/download/latest.json';
// Só baixamos o pacote destes hosts (hosts de RELEASE do GitHub; sem source-archive).
const HOSTS_OK = ['github.com', 'objects.githubusercontent.com', 'release-assets.githubusercontent.com', 'raw.githubusercontent.com'];

let atualizando = false; // lock em memória: serializa /__update/apply

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  /* .mjs é MÓDULO ES. Sem esta linha o servidor devolve octet-stream, o
     navegador recusa o import() por MIME e o pdf.js — logo, o caminho de
     PDF inteiro — morre SÓ no install do cliente. O servidor de teste
     conhece .mjs e o defeito passava batido. */
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', '.woff2': 'font/woff2',
  '.webmanifest': 'application/manifest+json; charset=utf-8'
};

// ---- Helpers de versão / rede ----
function versaoDeArquivo(cfgPath) {
  try {
    var t = fs.readFileSync(cfgPath, 'utf8');
    var m = t.match(/versao:\s*["']([^"']+)["']/);
    return m ? m[1] : '0.0.0';
  } catch (e) { return '0.0.0'; }
}
function versaoInstalada() { return versaoDeArquivo(path.join(ROOT, 'js', 'config.js')); }
// normaliza "v1.1.10", "1.2.0-rc1", "" -> [1,1,10] / [1,2,0] / [0]
function normVer(v) {
  v = String(v == null ? '' : v).trim().replace(/^v/i, '').split(/[-+]/)[0];
  return v.split('.').map(function (x) { var n = parseInt(x, 10); return isNaN(n) ? 0 : n; });
}
// compara versões. >0 se a>b, <0 se a<b, 0 se igual.
function cmpVersao(a, b) {
  var pa = normVer(a), pb = normVer(b);
  for (var i = 0; i < Math.max(pa.length, pb.length); i++) { var x = pa[i] || 0, y = pb[i] || 0; if (x !== y) return x - y; }
  return 0;
}
function hostOk(u) { try { return HOSTS_OK.indexOf(new URL(u).hostname) >= 0; } catch (e) { return false; } }

// TIMEOUT nos downloads: sem isto, uma conexão que trava (TCP meio-aberto) deixaria o
// lock do /__update/apply preso PARA SEMPRE (409 em todo apply até reiniciar o Node).
function comTimeout(req, cb, ms) {
  req.setTimeout(ms || 120000, function () {
    try { req.destroy(new Error('timeout no download')); } catch (e) {}
  });
  req.on('error', cb);
  return req;
}
// cb chamável UMA vez (destroy pode emitir erro no req E no res — sem isto, callback duplo)
function umaVez(cb) {
  var feito = false;
  return function () { if (feito) return; feito = true; cb.apply(null, arguments); };
}
function getTexto(url, cb, depth) {
  cb = umaVez(cb);
  depth = depth || 0; if (depth > 6) return cb(new Error('muitos redirects'));
  comTimeout(https.get(url, { headers: { 'User-Agent': 'OrcaPRO-Updater', 'Accept': 'application/json,text/plain,*/*' } }, function (res) {
    if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) { res.resume(); return getTexto(res.headers.location, cb, depth + 1); }
    if (res.statusCode !== 200) { res.resume(); return cb(new Error('HTTP ' + res.statusCode)); }
    var buf = ''; res.setEncoding('utf8');
    res.on('data', function (d) { buf += d; }); res.on('end', function () { cb(null, buf); });
  }), cb, 60000);
}
function baixarArquivo(url, dest, cb, depth) {
  cb = umaVez(cb);
  depth = depth || 0; if (depth > 6) return cb(new Error('muitos redirects'));
  if (!hostOk(url)) return cb(new Error('host não confiável: ' + url));
  comTimeout(https.get(url, { headers: { 'User-Agent': 'OrcaPRO-Updater' } }, function (res) {
    if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) { res.resume(); return baixarArquivo(res.headers.location, dest, cb, depth + 1); }
    if (res.statusCode !== 200) { res.resume(); return cb(new Error('HTTP ' + res.statusCode)); }
    var f = fs.createWriteStream(dest);
    // zip grande em rede lenta: 10 min de teto total; sem dados por 120s = morto
    res.setTimeout(120000, function () { try { res.destroy(new Error('timeout no download')); } catch (e) {} });
    res.pipe(f);
    f.on('finish', function () { f.close(function () { cb(null); }); });
    f.on('error', function (e) { cb(e); });
    res.on('error', function (e) { try { f.close(function () {}); } catch (e2) {} cb(e); });
  }), cb, 600000);
}
/* ⚠ `windowsHide: true` EM TODO PROCESSO FILHO — E O PADRÃO DO NODE É `false`.
 * Sem ele, cada chamada destas ABRE UMA JANELA DE CONSOLE NA CARA DO CLIENTE,
 * e a janela nova ROUBA O FOCO: quem estava digitando perde a tecla no meio da
 * palavra. Numa atualização são três (extrair, copiar, apagar), uma atrás da
 * outra, no momento em que a pessoa está usando o sistema.
 * Clientes reclamaram disso. Não é cosmético: é o app tomando o teclado. */
function ps(cmd, cb) { execFile('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', cmd], { maxBuffer: 1024 * 1024 * 32, windowsHide: true }, cb); }
function q(p) { return "'" + String(p).replace(/'/g, "''") + "'"; }

/* ⚠ O MAC NÃO TEM POWERSHELL NEM ROBOCOPY.
 * As três funções abaixo (extrair, promover, apagar) eram o único trecho do
 * servidor amarrado ao Windows — e são justamente as que fazem a ATUALIZAÇÃO.
 * No Mac elas falhavam com ENOENT, e a tela dizia "falha ao extrair" sem
 * dizer que o problema não tinha conserto naquela máquina: o cliente ficaria
 * carimbando "Atualizar" para sempre.
 * O equivalente da Apple é o `ditto`, que vem com o sistema (não é Homebrew,
 * não é Xcode) e faz as duas coisas: `-x -k` extrai zip, e sem parâmetro
 * MESCLA uma pasta sobre a outra preservando metadados — que é exatamente a
 * semântica do `robocopy /E` usada aqui.
 *
 * ⚠ As chamadas do Mac também levam `windowsHide: true`, e não é engano:
 * a opção é ignorada fora do Windows, e o gate (test-sem-janela-console.js)
 * exige que TODO processo filho a carregue. Abrir exceção por plataforma
 * enfraqueceria a regra que existe porque janela de console roubando foco
 * já tirou tecla da mão de cliente no meio de uma palavra. */
const EH_MAC = process.platform === 'darwin';
// Extrai um zip para uma pasta NOVA (stage), sem tocar no app.
function extrairPara(zip, stage, cb) {
  if (EH_MAC) {
    /* `-x` extrai, `-k` diz que a origem é um arquivo PKZip. */
    return execFile('ditto', ['-x', '-k', zip, stage], { maxBuffer: 1024 * 1024 * 32, windowsHide: true }, function (err, so, se) {
      cb(err ? new Error('falha ao extrair: ' + (se || err.message)) : null);
    });
  }
  ps('Expand-Archive -LiteralPath ' + q(zip) + ' -DestinationPath ' + q(stage) + ' -Force', function (err, so, se) {
    cb(err ? new Error('falha ao extrair: ' + (se || err.message)) : null);
  });
}
// Se o zip tinha uma única pasta-raiz (source archive), desce nela.
function raizEfetiva(stage) {
  try {
    if (fs.existsSync(path.join(stage, 'index.html'))) return stage;
    var itens = fs.readdirSync(stage);
    if (itens.length === 1) { var sub = path.join(stage, itens[0]); if (fs.statSync(sub).isDirectory()) return sub; }
  } catch (e) {}
  return stage;
}
// Copia os arquivos do stage POR CIMA da raiz (sem apagar o que não veio, ex.: data/).
function promover(src, dst, cb) {
  if (EH_MAC) {
    /* `ditto <src> <dst>` copia o CONTEÚDO de src por cima de dst, mesclando
       e sem apagar o que não veio (data/, porta.txt) — igual ao robocopy /E.
       Depois tira a quarentena: os arquivos vieram de um download, e sem isso
       o próximo `Iniciar` esbarraria no Gatekeeper numa instalação que ANTES
       funcionava — a atualização quebraria o sistema do cliente. */
    return execFile('ditto', [src, dst], { maxBuffer: 1024 * 1024 * 32, windowsHide: true }, function (err, so, se) {
      if (err) return cb(new Error('falha ao copiar: ' + (se || err.message)));
      execFile('xattr', ['-dr', 'com.apple.quarantine', dst], { windowsHide: true }, function () {
        /* ⚠ O BIT DE EXECUCAO PRECISA VOLTAR, E SO NOS ARQUIVOS CERTOS.
           O zip da atualizacao e montado no Windows e sai sem permissao
           Unix nenhuma (host MS-DOS): depois de extrair, os .command chegam
           NAO executaveis, e o proximo duplo clique no icone do Mac nao abre
           mais nada — a atualizacao teria QUEBRADO uma instalacao que estava
           funcionando.
           `chmod -R u+x` na pasta inteira resolveria, e foi o que escrevi
           primeiro; mas marca .js, .json e .html como executaveis, que e
           sujeira que fica no disco do cliente para sempre. So o que precisa:
           os lancadores, os scripts do instalador e o binario do Node. */
        execFile('/bin/sh', ['-c',
          'cd "$1" && chmod +x *.command instalador/*.sh 2>/dev/null; chmod +x runtime/bin/* 2>/dev/null; exit 0',
          'sh', dst], { windowsHide: true }, function () { cb(null); });
      });
    });
  }
  /* `windowsHide` aqui também — ver a nota em `ps()`. O robocopy é console
     puro: sem isto ele pisca uma janela no meio da atualização. */
  execFile('robocopy', [src, dst, '/E', '/NFL', '/NDL', '/NJH', '/NJS', '/NP', '/R:1', '/W:1'], { maxBuffer: 1024 * 1024 * 32, windowsHide: true }, function (err) {
    var code = err && typeof err.code === 'number' ? err.code : 0; // robocopy: 0-7 = sucesso, >=8 = erro
    if (code >= 8) return cb(new Error('falha ao copiar (robocopy ' + code + ')'));
    cb(null);
  });
}
function apagar(p) {
  if (EH_MAC) { try { execFile('rm', ['-rf', p], { windowsHide: true }, function () {}); } catch (e) {} return; }
  try { ps('Remove-Item -LiteralPath ' + q(p) + ' -Recurse -Force -ErrorAction SilentlyContinue', function () {}); } catch (e) {}
}
function sendJson(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

// ---- Auto-update: rotas /__update/* ----
function rotaUpdate(req, res, rel) {
  // Só o próprio PC (loopback) fala com o updater — nunca outra máquina da rede/LAN.
  var ra = (req.socket && req.socket.remoteAddress) || '';
  if (ra !== '127.0.0.1' && ra !== '::1' && ra !== '::ffff:127.0.0.1') { sendJson(res, 403, { ok: false, erro: 'Somente local.' }); return true; }
  if (rel === '/__update/check' && req.method === 'GET') {
    var instalada = versaoInstalada();
    getTexto(MANIFEST_URL, function (err, txt) {
      if (err) return sendJson(res, 200, { temAtualizacao: false, instalada: instalada, offline: true });
      var man; try { man = JSON.parse(txt); } catch (e) { return sendJson(res, 200, { temAtualizacao: false, instalada: instalada, erro: 'manifesto inválido' }); }
      var disponivel = String(man.versao || '0.0.0');
      var tem = cmpVersao(disponivel, instalada) > 0 && !!man.zip && hostOk(man.zip);
      /* tipo: "silenciosa" (padrão) sobe sozinha; "maior" avisa e pede a ação do
         usuário. Manifesto SEM o campo = silenciosa — é o que mantém compatível
         com os manifestos antigos e com clientes que ainda não conhecem o campo. */
      var tipo = String(man.tipo || 'silenciosa').toLowerCase();
      if (tipo !== 'maior') tipo = 'silenciosa';
      return sendJson(res, 200, { temAtualizacao: tem, instalada: instalada, disponivel: disponivel, notas: man.notas || '', tipo: tipo, titulo: man.titulo || '', obrigatoria: !!man.obrigatoria });
    });
    return true;
  }
  if (rel === '/__update/apply' && req.method === 'POST') {
    // Anti-CSRF: só o próprio app (localhost) pode disparar; bloqueia site externo.
    // (responder E retornar true — 'return sendJson' devolvia undefined e o 404
    //  em cima derrubava o servidor com ERR_HTTP_HEADERS_SENT)
    var origem = req.headers.origin;
    if (origem) { var oh = null; try { oh = new URL(origem).hostname; } catch (e) {} if (oh !== 'localhost' && oh !== '127.0.0.1') { sendJson(res, 403, { ok: false, erro: 'Origem não permitida.' }); return true; } }
    if (atualizando) { sendJson(res, 409, { ok: false, erro: 'Atualização já em andamento.' }); return true; }
    atualizando = true;
    var stage = path.join(os.tmpdir(), 'orcapro-stage-' + process.pid + '-' + Math.round(process.uptime() * 1000));
    var tmpZip = stage + '.zip';
    var responder = function (code, obj) { atualizando = false; apagar(tmpZip); apagar(stage); sendJson(res, code, obj); };
    getTexto(MANIFEST_URL, function (err, txt) {
      if (err) return responder(502, { ok: false, erro: 'Sem conexão para baixar a atualização.' });
      var man; try { man = JSON.parse(txt); } catch (e) { return responder(500, { ok: false, erro: 'Manifesto inválido.' }); }
      if (!man.zip || !hostOk(man.zip)) return responder(400, { ok: false, erro: 'Pacote de atualização indisponível.' });
      baixarArquivo(man.zip, tmpZip, function (e2) {
        if (e2) return responder(502, { ok: false, erro: 'Falha no download: ' + e2.message });
        var okZip = false; try { var fd = fs.openSync(tmpZip, 'r'); var b = Buffer.alloc(2); fs.readSync(fd, b, 0, 2, 0); fs.closeSync(fd); okZip = (b[0] === 0x50 && b[1] === 0x4B); } catch (e) {}
        if (!okZip) return responder(502, { ok: false, erro: 'Arquivo baixado inválido.' });
        extrairPara(tmpZip, stage, function (e3) {
          if (e3) return responder(500, { ok: false, erro: e3.message });
          var eff = raizEfetiva(stage);
          // valida ANTES de tocar na pasta viva: precisa ter index.html + a versão certa
          if (!fs.existsSync(path.join(eff, 'index.html')) || !fs.existsSync(path.join(eff, 'js', 'config.js'))) {
            return responder(500, { ok: false, erro: 'Pacote incompleto (sem index.html).' });
          }
          var verPacote = versaoDeArquivo(path.join(eff, 'js', 'config.js'));
          if (cmpVersao(verPacote, man.versao) !== 0) {
            return responder(500, { ok: false, erro: 'Versão do pacote (' + verPacote + ') não confere com o anúncio (' + man.versao + ').' });
          }
          promover(eff, ROOT, function (e4) {
            if (e4) return responder(500, { ok: false, erro: e4.message });
            var verFinal = versaoInstalada();
            if (cmpVersao(verFinal, man.versao) !== 0) return responder(500, { ok: false, erro: 'A instalação não foi concluída (ficou em ' + verFinal + ').' });
            responder(200, { ok: true, versao: verFinal, reiniciando: true });
            /* ⚠ O DEFEITO QUE ISTO FECHA (visto na maquina do dono, 07/08):
             * a troca de versao substitui os ARQUIVOS, mas o Node ja esta
             * carregado em memoria - ele continua servindo o codigo VELHO ate
             * alguem fechar e abrir o app. O navegador recarrega e pega o app
             * novo; o servidor, nao. Resultado: rota nova = 404, e a funcao
             * recem-lancada (o backup automatico) fica MORTA sem erro nenhum,
             * na frota inteira, ate cada cliente reabrir por conta propria.
             * Agora o processo se substitui: nasce um filho que ESPERA a porta
             * (ORCAPRO_ESPERAR_PORTA) e o pai sai. */
            /* ORDEM IMPORTA, e custou uma tentativa: o filho roda o codigo que
             * ACABOU de ser instalado - que pode ser uma versao que nao sabe
             * esperar porta. Se o pai ainda estiver segurando a 8754 quando ele
             * nascer, ele desiste e o cliente fica SEM servidor nenhum (visto no
             * teste de update real). Entao: soltar a porta PRIMEIRO, so depois
             * criar o filho. Se a criacao falhar, o pai volta a escutar - nunca
             * deixamos o app sem servidor. */
            setTimeout(function () {
              console.log('[orcapro] versao ' + verFinal + ' instalada - reiniciando o servidor');
              try { servidor.close(); } catch (e5) {}
              setTimeout(function () {
                try {
                  var filho = spawn(process.execPath, [__filename], {
                    /* ⚠ `windowsHide` aqui também: sem ele o app volta da
                       atualização com uma janela de console NOVA na tela — e
                       essa fica aberta para sempre, não é só um piscar. */
                    detached: true, stdio: 'ignore', cwd: process.cwd(), windowsHide: true,
                    env: Object.assign({}, process.env, { ORCAPRO_ESPERAR_PORTA: '1' })
                  });
                  filho.unref();
                } catch (eR) {
                  console.log('[orcapro] nao consegui reiniciar sozinho: ' + eR.message);
                  try { servidor.listen(PORT); } catch (e6) {}   // volta ao ar; o cliente reabre quando puder
                  return;
                }
                setTimeout(function () { process.exit(0); }, 600);
              }, 300);
            }, 800);   // deixa a resposta chegar no navegador antes de trocar o processo
            return;
          });
        });
      });
    });
    return true;
  }
  return false;
}

// ---- Ponte Revit: POST /__revit/exportar grava revit/obra-ativa.json ----
// O plugin RA BIM Tools (pyRevit) lê esse arquivo para BDI/etapas/cronograma.
function rotaRevit(req, res, rel) {
  var ra = (req.socket && req.socket.remoteAddress) || '';
  if (ra !== '127.0.0.1' && ra !== '::1' && ra !== '::ffff:127.0.0.1') { sendJson(res, 403, { ok: false, erro: 'Somente local.' }); return true; }
  /* ---- POST /__revit/ia grava revit/ia.json ----
   * O plugin do Revit nao tem localStorage: nao sabe a licenca nem o endereco
   * do backend de IA, e sem isso leva 403 do servidor. Quem sabe e o navegador,
   * e e ele quem manda para ca no mesmo clique de "Exportar p/ Revit".
   *
   * ⚠ ESTE ARQUIVO GUARDA UMA CREDENCIAL. Fica em <orcapro>/revit/ia.json, na
   *   maquina do usuario, com a licenca DELE — mesmo lugar onde o app ja grava
   *   os dados da obra. NAO entra no backup automatico (que exporta so o
   *   localStorage de dados) e NAO deve ser copiado para lugar nenhum. */
  if (rel === '/__revit/ia' && req.method === 'POST') {
    req.setEncoding('utf8');
    var cIA = '', nIA = 0, gdIA = false;
    req.on('data', function (ch) {
      if (gdIA) return;
      cIA += ch; nIA += Buffer.byteLength(ch, 'utf8');
      if (nIA > 64 * 1024) { gdIA = true; sendJson(res, 413, { ok: false, erro: 'Corpo grande demais.' }); req.destroy(); }
    });
    req.on('end', function () {
      if (gdIA) return;
      var o; try { o = JSON.parse(cIA); } catch (e) { return sendJson(res, 400, { ok: false, erro: 'JSON inválido.' }); }
      if (!o || o.formato !== 1 || !o.backend || !o.licenca) return sendJson(res, 400, { ok: false, erro: 'Contrato inválido (backend/licenca).' });
      try {
        var dIA = path.join(ROOT, 'revit');
        fs.mkdirSync(dIA, { recursive: true });
        var alvoIA = path.join(dIA, 'ia.json');
        var tmpIA = alvoIA + '.tmp';
        fs.writeFileSync(tmpIA, JSON.stringify({
          formato: 1,
          backend: String(o.backend),
          licenca: String(o.licenca),
          gravadoEm: new Date().toISOString(),
          _aviso: 'Contem a licenca do OrcaPRO. Nao compartilhe este arquivo.'
        }, null, 1), 'utf8');
        fs.renameSync(tmpIA, alvoIA);
        // resposta sem eco da licenca: log de rede nao pode carregar credencial
        return sendJson(res, 200, { ok: true, backend: String(o.backend) });
      } catch (e2) {
        return sendJson(res, 500, { ok: false, erro: 'Falha ao gravar: ' + e2.message });
      }
    });
    return true;
  }

  if (rel === '/__revit/exportar' && req.method === 'POST') {
    var origem = req.headers.origin;
    // IMPORTANTE: responder E retornar true — 'return sendJson(...)' devolve
    // undefined e o servidor tentaria um 404 em cima (headers já enviados = crash)
    if (origem) { var oh = null; try { oh = new URL(origem).hostname; } catch (e) {} if (oh !== 'localhost' && oh !== '127.0.0.1') { sendJson(res, 403, { ok: false, erro: 'Origem não permitida.' }); return true; } }
    // setEncoding: sem ele cada chunk vira string ISOLADA e um "ç" partido na
    // fronteira TCP vira U+FFFD — corrupção silenciosa do nome da etapa.
    req.setEncoding('utf8');
    var corpo = '', bytes = 0, demais = false;
    req.on('data', function (ch) {
      if (demais) return;
      corpo += ch;
      bytes += Buffer.byteLength(ch, 'utf8');
      if (bytes > 1024 * 1024) {
        demais = true;
        // responde ANTES de destruir — destroy suprime o 'end' e o 413 nunca sairia
        sendJson(res, 413, { ok: false, erro: 'Arquivo grande demais (1MB).' });
        req.destroy();
      }
    });
    req.on('end', function () {
      if (demais) return; // 413 já respondido
      var obj; try { obj = JSON.parse(corpo); } catch (e) { return sendJson(res, 400, { ok: false, erro: 'JSON inválido.' }); }
      if (!obj || obj.formato !== 1 || !Array.isArray(obj.etapas)) return sendJson(res, 400, { ok: false, erro: 'Contrato inválido (formato/etapas).' });
      try {
        var dir = path.join(ROOT, 'revit');
        fs.mkdirSync(dir, { recursive: true });
        var destino = path.join(dir, 'obra-ativa.json');
        // gravação atômica (tmp + rename): o plugin no Revit pode ler o arquivo
        // a qualquer momento — nunca pode enxergar um JSON pela metade
        var tmp = destino + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(obj, null, 1), 'utf8');
        fs.renameSync(tmp, destino);
        return sendJson(res, 200, { ok: true, caminho: destino });
      } catch (e2) {
        return sendJson(res, 500, { ok: false, erro: 'Falha ao gravar: ' + e2.message });
      }
    });
    return true;
  }
  return false;
}

/* ---- BACKUP AUTOMATICO EM ARQUIVO -----------------------------------
 * POR QUE NO SERVIDOR: os dados do cliente moram no navegador. Limpar o
 * cache, trocar de navegador ou reinstalar leva TUDO junto - foi assim
 * que um cliente perdeu as composicoes proprias dele. O app roda em cima
 * deste processo Node, que tem disco: dele sai a unica copia que sobrevive
 * ao navegador. A pasta fica em Documentos, FORA da pasta do programa, para
 * o backup nao morrer numa reinstalacao.
 *
 * REGRA DA ROTACAO: guarda os 30 mais novos. E, separado da fila, mantem
 * SEMPRE o snapshot com MAIS composicoes proprias ja visto (o "melhor").
 * Sem isso, um app com defeito mandando copias vazias empurraria o backup
 * bom para fora da janela em 30 gravacoes - a rotacao viraria a segunda
 * forma de perder o mesmo dado. */
var BKP_MAX = 30;
function pastaBackup() {
  var alvos = [process.env.ORCAPRO_BACKUP_DIR,   // usado pelos testes; vazio no cliente
               path.join(os.homedir(), 'Documents', 'OrcaPRO-Backups'),
               path.join(os.homedir(), 'Documentos', 'OrcaPRO-Backups'),
               path.join(ROOT, 'backups')];
  for (var i = 0; i < alvos.length; i++) {
    if (!alvos[i]) continue;
    try { fs.mkdirSync(alvos[i], { recursive: true }); return alvos[i]; } catch (e) {}
  }
  return null;
}
function listaBackups(dir) {
  try {
    return fs.readdirSync(dir).filter(function (f) { return /^orcapro-auto-.*\.json$/.test(f); })
      .map(function (f) { var p = path.join(dir, f); var st = fs.statSync(p); return { nome: f, em: st.mtimeMs, bytes: st.size }; })
      .sort(function (a, b) { return b.em - a.em; });
  } catch (e) { return []; }
}
function contaProprias(obj) {
  try { return (obj && obj.basePropria && Array.isArray(obj.basePropria.dados)) ? obj.basePropria.dados.length : 0; }
  catch (e) { return 0; }
}
function gravarAtomico(destino, texto) {
  var tmp = destino + '.tmp';
  fs.writeFileSync(tmp, texto, 'utf8');
  fs.renameSync(tmp, destino);
}
function rotaBackup(req, res, rel) {
  var ra = (req.socket && req.socket.remoteAddress) || '';
  if (ra !== '127.0.0.1' && ra !== '::1' && ra !== '::ffff:127.0.0.1') { sendJson(res, 403, { ok: false, erro: 'Somente local.' }); return true; }
  var dir = pastaBackup();

  /* ===== v1.1.233 — IDENTIDADE DA MÁQUINA FORA DO NAVEGADOR =====
     O deviceId morava só no localStorage: limpar dados do site (ou trocar de
     navegador) gerava um id novo e o servidor de licença abria OUTRO trial de
     7 dias zerado — trial infinito com dois cliques, sem detector nenhum.
     Aqui ele passa a viver num arquivo ao lado da pasta de backup: sobrevive à
     limpeza do navegador. No PWA (sem servidor local) o fetch falha e o app
     cai no comportamento antigo — o cerco fecha onde dá para fechar. */
  /* ===== /__bases — QUAIS COMPETÊNCIAS ESTÃO NO DISCO =====
   *
   * O `data/estados.json` é escrito no empacotamento e lista UMA competência
   * por UF: a mais nova do pacote. Só que a atualização NÃO apaga a anterior —
   * e é bom que não apague, porque orçamento aberto tem de reabrir na base que
   * ele declara (`orc.competenciaSinapi`), senão o preço muda sozinho e o
   * documento vira alvo de impugnação.
   *
   * O resultado, antes desta rota: numa instalação de alguns meses havia 27
   * arquivos de competências anteriores, íntegros, ocupando ~79 MB, que o
   * sistema NÃO SABIA QUE EXISTIAM. Ocupavam espaço, não serviam para nada, e
   * reabrir um orçamento antigo caía no aviso "não deu para carregar a base" —
   * falhando calado justamente no caso que mais importa.
   *
   * O motor já sabia carregar qualquer competência (`App.trocarBaseSinapi`
   * deriva o nome do arquivo da competência pedida). Faltava DESCOBRIR. É só
   * isso que esta rota faz: lista o que está no disco. Sem servidor local
   * (PWA), o fetch falha e o app segue com o manifesto — como sempre foi. */
  if ((rel === '/__bases' || rel.indexOf('/__bases?') === 0) && req.method === 'GET') {
    var dirData = path.join(ROOT, 'data');
    var achadas = [], analiticos = [], analiticoLegado = [];
    try {
      fs.readdirSync(dirData).forEach(function (nome) {
        /* O ANALÍTICO COM A COMPETÊNCIA NO NOME é o que torna honesto orçar numa
           competência anterior: preço e insumo do MESMO mês. Sem ele, a base de
           preço seria de um mês e o detalhamento de outro — e o analítico é a
           fonte oficial de custo de ~2.000 insumos por UF. */
        var a = /^sinapi-([A-Za-z]{2})-(\d{4}-\d{2})-analitico\.json(\.gz)?$/.exec(nome);
        if (a) {
          var ja = false;
          for (var q = 0; q < analiticos.length; q++) if (analiticos[q].uf === a[1].toUpperCase() && analiticos[q].competencia === a[2]) ja = true;
          if (!ja) analiticos.push({ uf: a[1].toUpperCase(), competencia: a[2] });
          return;
        }
        /* o nome ANTIGO, sem competência: vale só para o mês EMBARCADO. Quem
           decide isso é o app, comparando com o manifesto — aqui só se informa
           que ele existe (instalação que ainda não recebeu pacote completo só
           tem este, porque o zip de ATUALIZAÇÃO não leva `data/`). */
        var l = /^sinapi-([A-Za-z]{2})-analitico\.json(\.gz)?$/.exec(nome);
        if (l) { if (analiticoLegado.indexOf(l[1].toUpperCase()) < 0) analiticoLegado.push(l[1].toUpperCase()); return; }
        var m = /^sinapi-([A-Za-z]{2})-(\d{4}-\d{2})\.json$/.exec(nome);
        if (!m) return;
        var tam = 0;
        try { tam = fs.statSync(path.join(dirData, nome)).size; } catch (e) {}
        achadas.push({ uf: m[1].toUpperCase(), competencia: m[2], arquivo: 'data/' + nome, bytes: tam });
      });
    } catch (e) {}
    /* mais nova primeiro: quem consome pega [0] esperando a atual */
    achadas.sort(function (a, b) {
      if (a.uf !== b.uf) return a.uf < b.uf ? -1 : 1;
      return a.competencia < b.competencia ? 1 : (a.competencia > b.competencia ? -1 : 0);
    });
    sendJson(res, 200, { ok: true, bases: achadas, analiticos: analiticos, analiticoLegado: analiticoLegado });
    return true;
  }
  if ((rel === '/__device' || rel.indexOf('/__device?') === 0) && req.method === 'GET') {
    if (!dir) { sendJson(res, 200, { ok: false }); return true; }
    var devArq = path.join(dir, 'orcapro-device.json');
    var devId = '';
    try { devId = String(JSON.parse(fs.readFileSync(devArq, 'utf8')).id || ''); } catch (e) {}
    if (!devId) {
      /* 1ª vez: adota a identidade que o navegador JÁ TEM (instalação antiga
         ativada continua sendo o mesmo dispositivo para o servidor de licença);
         sem seed, nasce uma nova. */
      var mSeed = String(req.url || '').match(/[?&]seed=([\w-]{8,64})/);
      try {
        devId = mSeed ? mSeed[1] : require('crypto').randomUUID();
        gravarAtomico(devArq, JSON.stringify({ id: devId, criadoEm: new Date().toISOString() }));
      } catch (e2) { devId = ''; }
    }
    sendJson(res, 200, devId ? { ok: true, id: devId } : { ok: false });
    return true;
  }

  if (rel === '/__backup/status' && req.method === 'GET') {
    if (!dir) { sendJson(res, 200, { ok: false, erro: 'Sem pasta de backup gravavel.' }); return true; }
    var L = listaBackups(dir), melhorN = 0;
    try { melhorN = contaProprias(JSON.parse(fs.readFileSync(path.join(dir, 'orcapro-melhor-composicoes.json'), 'utf8'))); } catch (e) {}
    sendJson(res, 200, { ok: true, pasta: dir, total: L.length,
      ultimo: L[0] ? L[0].nome : '', ultimoEm: L[0] ? new Date(L[0].em).toISOString() : '',
      ultimoBytes: L[0] ? L[0].bytes : 0, melhorComposicoes: melhorN });
    return true;
  }

  if (rel === '/__backup/salvar' && req.method === 'POST') {
    var origem = req.headers.origin;
    if (origem) { var oh = null; try { oh = new URL(origem).hostname; } catch (e) {} if (oh !== 'localhost' && oh !== '127.0.0.1') { sendJson(res, 403, { ok: false, erro: 'Origem nao permitida.' }); return true; } }
    if (!dir) { sendJson(res, 500, { ok: false, erro: 'Sem pasta de backup gravavel.' }); return true; }
    req.setEncoding('utf8');
    var corpo = '', bytes = 0, demais = false;
    req.on('data', function (ch) {
      if (demais) return;
      corpo += ch; bytes += Buffer.byteLength(ch, 'utf8');
      if (bytes > 64 * 1024 * 1024) { demais = true; sendJson(res, 413, { ok: false, erro: 'Backup grande demais (64MB).' }); req.destroy(); }
    });
    req.on('end', function () {
      if (demais) return;
      var obj; try { obj = JSON.parse(corpo); } catch (e) { return sendJson(res, 400, { ok: false, erro: 'JSON invalido.' }); }
      var nOrc = (obj && Array.isArray(obj.orcamentos)) ? obj.orcamentos.length : 0;
      var nProp = contaProprias(obj);
      // backup vazio nao entra na fila: so serviria para empurrar os bons para fora
      if (!nOrc && !nProp) return sendJson(res, 400, { ok: false, erro: 'Nada para guardar.' });
      try {
        var d = new Date();
        var carimbo = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0')
          + '_' + String(d.getHours()).padStart(2, '0') + '-' + String(d.getMinutes()).padStart(2, '0') + '-' + String(d.getSeconds()).padStart(2, '0');
        // nome SEMPRE gerado aqui: nada que venha do cliente entra em caminho de arquivo.
        // O sufixo existe porque o carimbo tem resolucao de SEGUNDO: duas copias no
        // mesmo segundo gravavam por cima uma da outra e uma delas sumia calada -
        // justamente o tipo de perda silenciosa que este backup veio impedir.
        var destino = path.join(dir, 'orcapro-auto-' + carimbo + '.json');
        for (var s = 2; s <= 50 && fs.existsSync(destino); s++) destino = path.join(dir, 'orcapro-auto-' + carimbo + '-' + s + '.json');
        gravarAtomico(destino, corpo);

        // o melhor snapshot de composicoes proprias fica fora da rotacao
        var melhorPath = path.join(dir, 'orcapro-melhor-composicoes.json'), melhorN = -1;
        try { melhorN = contaProprias(JSON.parse(fs.readFileSync(melhorPath, 'utf8'))); } catch (e) { melhorN = -1; }
        if (nProp > 0 && nProp >= melhorN) { try { gravarAtomico(melhorPath, corpo); } catch (e) {} }

        // rotacao: so apaga arquivo NOSSO, so o excedente, so na nossa pasta
        var L = listaBackups(dir), apagados = 0;
        for (var i = BKP_MAX; i < L.length; i++) { try { fs.unlinkSync(path.join(dir, L[i].nome)); apagados++; } catch (e) {} }
        return sendJson(res, 200, { ok: true, caminho: destino, orcamentos: nOrc, composicoes: nProp, guardados: Math.min(L.length, BKP_MAX), apagados: apagados });
      } catch (e2) {
        return sendJson(res, 500, { ok: false, erro: 'Falha ao gravar: ' + e2.message });
      }
    });
    return true;
  }
  return false;
}

const servidor = http.createServer((req, res) => {
  try {
    let rel = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    if (rel.indexOf('/__update/') === 0) { if (rotaUpdate(req, res, rel)) return; res.writeHead(404); res.end('no'); return; }
    /* ⚠ `/__device` TAMBÉM ENTRA AQUI. O tratador dele mora dentro de
       rotaBackup(), mas só se chegava nessa função com caminho começando em
       `/__backup/` — então `/__device` caia no 404 e a proteção da v1.1.233
       (ancorar a identidade da máquina no DISCO, para limpar os dados do site
       não abrir outro trial de 7 dias) NUNCA rodou: o `licenca.js` engole a
       falha em silencio e o deviceId seguiu vivendo só no localStorage.
       Apareceu como 404 repetido no console de quem estava com o DevTools
       aberto — barulho que era sintoma. */
    /* ⚠ RESPONDE 200 SEMPRE, com um booleano — nunca 404.
       O app pergunta aqui se esta instalação tem o Painel de Apresentação
       (material de venda, que não é empacotado para o cliente). A primeira
       versão fazia `HEAD apresentacao.html` e contava com o 404 como
       resposta "não" — o que encheria o console de TODO cliente com um erro
       vermelho por sessão. Ruído assim tem custo real: foi um 404 repetido
       que escondeu a rota /__device morta por meses, e foi preciso um print
       de console para achá-la. Pergunta que tem resposta "não" deve devolver
       200 com "não", não um erro. */
    if (rel === '/__venda' && req.method === 'GET') {
      var temPainel = false;
      try { temPainel = fs.existsSync(path.join(ROOT, 'apresentacao.html')); } catch (e) {}
      sendJson(res, 200, { ok: true, painel: temPainel });
      return;
    }
    if (rel.indexOf('/__backup/') === 0 || rel === '/__device' || rel === '/__bases') { if (rotaBackup(req, res, rel)) return; res.writeHead(404); res.end('no'); return; }
    if (rel.indexOf('/__revit/') === 0) { if (rotaRevit(req, res, rel)) return; res.writeHead(404); res.end('no'); return; }
    // IPs da rede local (LAN) — pro QR da RA/RV abrir o app em outro celular/tablet da mesma rede
    if (rel === '/__lan') {
      var ips = [];
      try { var ni = os.networkInterfaces(); Object.keys(ni).forEach(function (k) { (ni[k] || []).forEach(function (a) { if (a && a.family === 'IPv4' && !a.internal) ips.push(a.address); }); }); } catch (e) {}
      sendJson(res, 200, { ips: ips, porta: PORT }); return;
    }
    if (rel === '/' || rel === '') rel = '/index.html';
    // impede sair da raiz (path traversal): usa path.relative (fecha o caso de pasta-irmã com prefixo)
    const full = path.normalize(path.join(ROOT, rel));
    const rp = path.relative(ROOT, full);
    if (rp.split(path.sep)[0] === '..' || path.isAbsolute(rp)) { res.writeHead(403); res.end('forbidden'); return; }
    fs.readFile(full, (err, data) => {
      if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('404 — ' + rel); return; }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-store' });
      res.end(data);
    });
  } catch (e) { res.writeHead(500); res.end('erro'); }
}).on('error', (e) => {
  /* Sem este handler, EADDRINUSE virava uncaughtException e o processo MORRIA.
     Como o launcher sobe com `start /min`, a janela sumia e o cliente ficava
     olhando um navegador que nao conecta, sem nenhuma mensagem. */
  /* FILHO DA TROCA DE VERSAO: nasce enquanto o pai ainda segura a porta.
     Aqui ele ESPERA a porta em vez de desistir - sem isto, a atualizacao
     derrubaria o servidor e nao subiria nada no lugar. Vale SO para quem foi
     iniciado pelo update (a variavel de ambiente); inicio manual mantem a
     mensagem de sempre, sem laco infinito. */
  if (e && e.code === 'EADDRINUSE' && process.env.ORCAPRO_ESPERAR_PORTA) {
    if (!global.__tentativasPorta) global.__tentativasPorta = 0;
    if (++global.__tentativasPorta <= 60) {           // ate ~30s
      setTimeout(() => { try { servidor.listen(PORT); } catch (e2) {} }, 500);
      return;
    }
  }
  if (e && e.code === 'EADDRINUSE') {
    console.log('\n  A porta ' + PORT + ' ja esta em uso.');
    console.log('  O OrcaPRO provavelmente JA ESTA ABERTO — procure a janela do navegador,');
    console.log('  ou acesse http://localhost:' + PORT + '/index.html');
    console.log('\n  (Se nao for o OrcaPRO, feche o outro programa e abra de novo.)\n');
  } else {
    console.log('\n  Nao consegui iniciar o servidor: ' + (e && e.message) + '\n');
  }
  setTimeout(() => process.exit(1), 15000); // deixa a mensagem legivel antes de fechar
}).listen(PORT, () => console.log('[orcapro] App em http://localhost:' + PORT));
