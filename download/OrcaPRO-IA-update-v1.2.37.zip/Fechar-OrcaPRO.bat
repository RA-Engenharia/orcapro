@echo off
REM  EnableDelayedExpansion: sem ele o !ULTIMO! do laco abaixo sai literal
REM  e o de-duplicador nao funciona.
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Fechar OrcaPRO IA
cd /d "%~dp0"

REM =====================================================================
REM  PARA O ORCAPRO IA.
REM
REM  Ate a v1.2 o servidor rodava numa janela de console minimizada, e
REM  desligar era fechar essa janela. A janela saiu (ela ficava na barra
REM  de tarefas o dia inteiro e clientes reclamaram), entao o desligar
REM  virou este arquivo.
REM
REM  ⚠ DERRUBA SO O NODE DESTA PORTA, NUNCA "todos os node".
REM    Um `taskkill /IM node.exe` mataria junto qualquer outra coisa em
REM    Node na maquina — inclusive uma SEGUNDA instalacao do OrcaPRO em
REM    outra porta, que e caso comum aqui. A porta identifica o processo
REM    certo.
REM =====================================================================

set "PORT_APP=8754"
if exist "%~dp0porta.txt" (for /f "usebackq delims=" %%p in ("%~dp0porta.txt") do set "PORT_APP=%%p")

echo Desligando o OrcaPRO IA ^(porta %PORT_APP%^) e o ContabPRO ^(porta 8770^)...

REM  O ContabPRO sobe junto, na 8770, e TAMBEM deixou de ter janela. Se este
REM  arquivo parasse so o OrcaPRO, o ContabPRO ficaria rodando invisivel e sem
REM  como desligar — trocaria um incomodo por um processo fantasma.
set "ACHOU="
call :parar %PORT_APP% "OrcaPRO IA"
call :parar 8770 "ContabPRO"

if not defined ACHOU (
  echo.
  echo Nada estava rodando — nada a fazer.
) else (
  echo.
  echo Desligado.
  echo Para usar de novo, abra o Iniciar-OrcaPRO.bat ^(ou o atalho na area de trabalho^).
)
echo.
timeout /t 5 >nul
exit /b 0

REM ---------------------------------------------------------------------
REM  :parar <porta> <nome>
REM  ⚠ o netstat lista a MESMA porta duas vezes (IPv4 e IPv6), com o mesmo
REM    PID — sem de-duplicar, a tela diz "encerrando o processo" duas vezes e
REM    parece que havia dois servidores.
REM ---------------------------------------------------------------------
:parar
set "ULTIMO="
for /f "tokens=5" %%a in ('netstat -ano ^| findstr /r /c:"TCP .*:%~1 .*LISTENING"') do (
  if not "%%a"=="!ULTIMO!" (
    set "ACHOU=1"
    set "ULTIMO=%%a"
    echo   %~2 ^(porta %~1^): encerrando o processo %%a
    taskkill /PID %%a /F >nul 2>nul
  )
)
exit /b 0
