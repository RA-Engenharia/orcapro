#!/bin/bash
# =====================================================================
# Fechar-OrcaPRO.command — desliga o OrçaPRO no Mac.
# Espelho do Fechar-OrcaPRO.bat.
#
# ⚠ DERRUBA SÓ O PROCESSO DESTA PORTA, NUNCA "todos os node".
#   Um `killall node` mataria junto qualquer outra coisa em Node na
#   máquina — inclusive uma SEGUNDA instalação do OrçaPRO em outra porta,
#   que é caso comum. A porta identifica o processo certo.
# =====================================================================
set -u
cd "$(dirname "${BASH_SOURCE[0]}")" || exit 1
RAIZ="$(pwd)"

PORT_APP=8754
[ -f "$RAIZ/porta.txt" ] && PORT_APP="$(tr -d '[:space:]' < "$RAIZ/porta.txt")"
[ -z "$PORT_APP" ] && PORT_APP=8754

echo "Desligando o OrçaPRO IA (porta $PORT_APP) e o ContabPRO (porta 8770)..."

ACHOU=""
SEM_FERRAMENTA=""
parar() {
  porta="$1"; nome="$2"
  pids=""
  if command -v lsof >/dev/null 2>&1; then
    # -sTCP:LISTEN pega só quem está SERVINDO a porta. Sem isso, uma aba do
    # navegador conectada na porta entra na lista e o script mataria o Chrome.
    pids="$(lsof -ti "tcp:$porta" -sTCP:LISTEN 2>/dev/null | sort -u)"
  elif command -v pgrep >/dev/null 2>&1; then
    # ⚠ CAMINHO DE RESERVA, E ELE É ESTREITO DE PROPÓSITO. O casamento é com o
    #   CAMINHO COMPLETO do static.js DESTA instalação — nunca com "node".
    #   Um `pkill node` derrubaria junto qualquer outra coisa em Node na
    #   máquina, inclusive uma segunda instalação do OrçaPRO. E como este
    #   caminho não sabe a porta, ele só vale para o OrçaPRO daqui: para as
    #   outras portas o script diz que não conseguiu, em vez de chutar.
    if [ "$porta" = "$PORT_APP" ]; then
      pids="$(pgrep -f "$RAIZ/server/static.js" 2>/dev/null | sort -u)"
    else
      SEM_FERRAMENTA=1
      return 0
    fi
  else
    SEM_FERRAMENTA=1
    return 0
  fi
  [ -z "$pids" ] && return 0
  for pid in $pids; do
    ACHOU=1
    echo "  $nome (porta $porta): encerrando o processo $pid"
    kill "$pid" 2>/dev/null
  done
  # dá um instante para sair limpo antes de insistir
  sleep 1
  restantes=""
  if command -v lsof >/dev/null 2>&1; then
    restantes="$(lsof -ti "tcp:$porta" -sTCP:LISTEN 2>/dev/null | sort -u)"
  elif command -v pgrep >/dev/null 2>&1 && [ "$porta" = "$PORT_APP" ]; then
    restantes="$(pgrep -f "$RAIZ/server/static.js" 2>/dev/null | sort -u)"
  fi
  for pid in $restantes; do kill -9 "$pid" 2>/dev/null; done
  return 0
}

parar "$PORT_APP" "OrçaPRO IA"
# O ContabPRO sobe junto, na 8770. Se este arquivo parasse só o OrçaPRO, o
# ContabPRO ficaria rodando invisível e sem como desligar.
parar 8770 "ContabPRO"

echo ""
if [ -n "$SEM_FERRAMENTA" ] && [ -z "$ACHOU" ]; then
  # ⚠ NÃO DIZER "nada estava rodando" QUANDO NÃO DEU PARA OLHAR. São coisas
  #   diferentes, e confundi-las manda o cliente embora achando que desligou.
  echo "Não consegui verificar o que está rodando neste Mac (faltam os comandos"
  echo "lsof e pgrep, que normalmente vêm com o sistema)."
  echo "O OrçaPRO pode continuar aberto. Reiniciar o Mac resolve."
elif [ -z "$ACHOU" ]; then
  echo "Nada estava rodando — nada a fazer."
else
  echo "Desligado."
  echo "Para usar de novo, abra o OrçaPRO no Launchpad (ou o Iniciar-OrcaPRO.command)."
fi
echo ""
sleep 4
exit 0
