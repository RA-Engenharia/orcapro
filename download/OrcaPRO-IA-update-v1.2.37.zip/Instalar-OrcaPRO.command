#!/bin/bash
# =====================================================================
# Instalar-OrcaPRO.command — instalação do OrçaPRO IA no macOS.
# Espelho do Instalar-OrcaPRO.bat, com o que só existe no Mac.
#
# ⚠ POR QUE ESTE ARQUIVO EXISTE, E POR QUE ELE CONSERTA A SI MESMO.
#   O pacote do OrçaPRO é montado no Windows. O formato ZIP guarda a
#   permissão de execução do Unix num campo que o compactador do Windows
#   não escreve — então, ao descompactar no Mac, TODO arquivo chega SEM o
#   bit de execução. O duplo clique num .command sem esse bit não abre
#   nada: o Finder responde que o arquivo não pôde ser executado, e não
#   há como saber por quê olhando a tela. Some a isso a quarentena
#   (com.apple.quarantine) que o macOS carimba em tudo que veio da
#   internet, e o resultado é o instalador que "não instala" — que foi
#   exatamente o que aconteceu.
#   As duas primeiras coisas que este arquivo faz são consertar isso na
#   pasta inteira. O LEIA-ME-MAC.txt traz a linha de Terminal que dá
#   partida nele quando nem o duplo clique funciona.
# =====================================================================
set -u
cd "$(dirname "${BASH_SOURCE[0]}")" || exit 1
RAIZ="$(pwd)"
APP_NOME="OrçaPRO IA"
APP_DIR="$HOME/Applications/$APP_NOME.app"

echo ""
echo "  ================================================================"
echo "     OrçaPRO IA  -  Instalação no Mac"
echo "  ================================================================"
echo ""

# ---------------------------------------------------------------------
# [0/5] Conserta a própria pasta: execução + quarentena.
# ---------------------------------------------------------------------
echo "  [0/5] Ajustando permissões da pasta..."
chmod +x "$RAIZ"/*.command 2>/dev/null
chmod +x "$RAIZ"/instalador/*.sh 2>/dev/null
xattr -dr com.apple.quarantine "$RAIZ" 2>/dev/null
echo "        Pronto."
echo ""

# ---------------------------------------------------------------------
# ⚠ ESTOU NA PASTA DO ORÇAPRO, OU SÓ NA PASTA DOS ARQUIVOS DO MAC?
#
#   Os arquivos do Mac são entregues à parte, num pacote pequeno, para
#   quem já tem o OrçaPRO instalado. É natural descompactar em Downloads
#   e clicar ali mesmo — e foi o que aconteceu na primeira vez que isto
#   rodou num Mac de verdade. Sem esta verificação o Node subia, não
#   achava server/static.js e cuspia um rastro de pilha terminado em
#   MODULE_NOT_FOUND: quinze linhas que não dizem ao cliente NADA sobre
#   o que ele tem de fazer.
#
#   Em vez de só reclamar, o instalador PROCURA a pasta do OrçaPRO e se
#   copia para lá. O engano deixa de ser um problema.
# ---------------------------------------------------------------------
if [ ! -f "$RAIZ/server/static.js" ]; then
  echo "  Estes são os arquivos do Mac — a pasta do OrçaPRO está noutro lugar."
  echo "  Procurando..."

  ACHADAS="$(
    for base in "$(dirname "$RAIZ")" "$HOME/Downloads" "$HOME/Desktop" "$HOME/Documents" "$HOME/Applications" "$HOME"; do
      [ -d "$base" ] || continue
      find "$base" -maxdepth 4 -type f -path '*/server/static.js' 2>/dev/null
    done | while IFS= read -r s; do
      d="$(dirname "$(dirname "$s")")"
      [ "$d" = "$RAIZ" ] && continue
      [ -f "$d/index.html" ] && printf '%s\n' "$d"
    done | sort -u
  )"

  N=0
  [ -n "$ACHADAS" ] && N="$(printf '%s\n' "$ACHADAS" | grep -c .)"

  if [ "$N" -eq 0 ]; then
    echo ""
    echo "  [ERRO] Não achei a pasta do OrçaPRO neste Mac."
    echo ""
    echo "         Estes arquivos são um COMPLEMENTO: eles precisam ficar DENTRO"
    echo "         da pasta do OrçaPRO (aquela que tem o index.html e a pasta"
    echo "         server). Copie para lá:"
    echo ""
    echo "             Instalar-OrcaPRO.command"
    echo "             Iniciar-OrcaPRO.command"
    echo "             Fechar-OrcaPRO.command"
    echo "             LEIA-ME-MAC.txt"
    echo "             instalador/baixar-node-mac.sh   (dentro da pasta instalador)"
    echo ""
    echo "         Se o OrçaPRO ainda não está neste Mac, peça o pacote completo"
    echo "         antes — este aqui não traz o sistema, só o instalador."
    echo ""
    read -r -p "  Pressione Enter para fechar." _
    exit 1
  fi

  DESTINO=""
  if [ "$N" -eq 1 ]; then
    DESTINO="$ACHADAS"
    echo "        Achei: $DESTINO"
  else
    echo ""
    echo "  Achei mais de uma pasta do OrçaPRO. Qual você quer usar?"
    i=1
    while [ "$i" -le "$N" ]; do
      echo "    [$i] $(printf '%s\n' "$ACHADAS" | sed -n "${i}p")"
      i=$((i + 1))
    done
    read -r -p "  Número (Enter = 1): " ESC
    case "$ESC" in ''|*[!0-9]*) ESC=1 ;; esac
    [ "$ESC" -lt 1 ] && ESC=1
    [ "$ESC" -gt "$N" ] && ESC=1
    DESTINO="$(printf '%s\n' "$ACHADAS" | sed -n "${ESC}p")"
  fi

  echo "        Copiando os arquivos do Mac para lá..."
  mkdir -p "$DESTINO/instalador"
  for arq in Instalar-OrcaPRO.command Iniciar-OrcaPRO.command Fechar-OrcaPRO.command LEIA-ME-MAC.txt; do
    [ -f "$RAIZ/$arq" ] && cp -f "$RAIZ/$arq" "$DESTINO/$arq"
  done
  [ -f "$RAIZ/instalador/baixar-node-mac.sh" ] && cp -f "$RAIZ/instalador/baixar-node-mac.sh" "$DESTINO/instalador/baixar-node-mac.sh"
  chmod +x "$DESTINO"/*.command "$DESTINO/instalador/"*.sh 2>/dev/null
  xattr -dr com.apple.quarantine "$DESTINO" 2>/dev/null
  echo "        Pronto. Continuando a instalação lá dentro."
  echo ""
  # ⚠ `exec` e não chamada comum: quem manda daqui para a frente é a cópia
  #   que está na pasta certa. Duas instalações rodando em paralelo brigariam
  #   pela mesma porta.
  exec /bin/bash "$DESTINO/Instalar-OrcaPRO.command"
fi

# ---------------------------------------------------------------------
# [1/5] Node.js
# ---------------------------------------------------------------------
echo "  [1/5] Verificando o Node.js..."
NODE=""
if [ -x "$RAIZ/runtime/bin/node" ]; then
  NODE="$RAIZ/runtime/bin/node"
elif command -v node >/dev/null 2>&1; then
  NODE="$(command -v node)"
  echo "        Usando o Node já instalado neste Mac: $("$NODE" -v)"
else
  echo "        Node não encontrado — vou baixar e preparar (precisa de internet)..."
  bash "$RAIZ/instalador/baixar-node-mac.sh" || true
  [ -x "$RAIZ/runtime/bin/node" ] && NODE="$RAIZ/runtime/bin/node"
fi

if [ -z "$NODE" ]; then
  echo ""
  echo "  [ERRO] Não consegui preparar o Node.js."
  echo "         Verifique a internet e abra este arquivo de novo, ou instale"
  echo "         o Node LTS em https://nodejs.org e abra de novo."
  echo ""
  read -r -p "  Pressione Enter para fechar." _
  exit 1
fi
echo "        Node OK."
echo ""

# ---------------------------------------------------------------------
# [2/5] Base SINAPI do estado — só pergunta se houver mais de uma.
#       (Perfis sem o módulo de orçamento não trazem base nenhuma; aí
#        este passo não pergunta nada e segue.)
# ---------------------------------------------------------------------
echo "  [2/5] Base SINAPI do seu estado..."
DATA="$RAIZ/data"
# ⚠ SEM ARRAY, DE PROPÓSITO. O macOS ainda entrega o bash 3.2 em /bin/bash
#   (a licença do bash 4 é GPLv3, e a Apple não a distribui). Nele, expandir
#   um array VAZIO com `set -u` ligado aborta o script com "unbound variable"
#   — ou seja, o instalador morreria justamente no pacote que não traz base
#   SINAPI nenhuma, que é o caso do perfil de carpintaria. Uma lista separada
#   por quebra de linha funciona igual no bash 3.2 e no 5.
BASES=""
NBASES=0
if [ -d "$DATA" ]; then
  while IFS= read -r arq; do
    [ -z "$arq" ] && continue
    nome="$(basename "$arq")"
    case "$nome" in
      *analitico*|*sample*|*insumos*) continue ;;
    esac
    BASES="$BASES$nome
"
    NBASES=$((NBASES + 1))
  done <<EOF
$(find "$DATA" -maxdepth 1 -name 'sinapi-*.json' 2>/dev/null | sort)
EOF
fi

gravar_base() {
  nome="$1"
  uf=""; comp=""
  if [[ "$nome" =~ sinapi-([A-Za-z]{2})-([0-9]{4}-[0-9]{2}) ]]; then
    uf="$(printf '%s' "${BASH_REMATCH[1]}" | tr '[:lower:]' '[:upper:]')"
    comp="${BASH_REMATCH[2]}"
  fi
  printf '{"arquivo":"data/%s","uf":"%s","competencia":"%s","rotulo":"SINAPI %s %s"}' \
    "$nome" "$uf" "$comp" "$uf" "$comp" > "$DATA/base-ativa.json"
  echo "        -> Base ativa: SINAPI $uf $comp"
}

enesima() { printf '%s\n' "$BASES" | sed -n "$1p"; }

if [ "$NBASES" -eq 0 ]; then
  echo "        Nenhuma base SINAPI neste pacote — nada a escolher."
elif [ "$NBASES" -eq 1 ]; then
  gravar_base "$(enesima 1)"
else
  echo ""
  echo "  Qual base SINAPI (estado) você quer usar como padrão?"
  i=1
  while [ "$i" -le "$NBASES" ]; do
    b="$(enesima "$i")"
    echo "    [$i] ${b%.json}"
    i=$((i + 1))
  done
  read -r -p "  Número (Enter = 1): " SEL
  case "$SEL" in ''|*[!0-9]*) SEL=1 ;; esac
  [ "$SEL" -lt 1 ] && SEL=1
  [ "$SEL" -gt "$NBASES" ] && SEL=1
  gravar_base "$(enesima "$SEL")"
fi
echo ""

# ---------------------------------------------------------------------
# [3/5] O aplicativo do Mac.
#
# ⚠ O .app É CRIADO AQUI, NA MÁQUINA DO CLIENTE — não vem no pacote.
#   Um .app que viaja dentro de um zip chega sem permissão de execução e
#   com quarentena, e o macOS o recusa dizendo que "está danificado" —
#   mensagem que faz qualquer pessoa apagar o arquivo e desistir. Um .app
#   MONTADO no próprio Mac nunca recebe quarentena: abre no duplo clique,
#   aparece no Launchpad e no Spotlight, e não pede autorização nenhuma.
# ---------------------------------------------------------------------
echo "  [3/5] Criando o aplicativo \"$APP_NOME\"..."
rm -rf "$APP_DIR"
mkdir -p "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources"

cat > "$APP_DIR/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>OrçaPRO IA</string>
  <key>CFBundleDisplayName</key><string>OrçaPRO IA</string>
  <key>CFBundleIdentifier</key><string>br.eng.raengenharia.orcapro</string>
  <key>CFBundleVersion</key><string>1.0</string>
  <key>CFBundleShortVersionString</key><string>1.0</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleExecutable</key><string>OrcaPRO</string>
  <key>CFBundleIconFile</key><string>orcapro</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>LSUIElement</key><true/>
</dict>
</plist>
PLIST

# O executável do .app é uma casca fina: ele só chama o Iniciar da pasta
# do sistema. Assim a atualização do OrçaPRO não precisa refazer o .app.
cat > "$APP_DIR/Contents/MacOS/OrcaPRO" <<LANCADOR
#!/bin/bash
exec /bin/bash "$RAIZ/Iniciar-OrcaPRO.command"
LANCADOR
chmod +x "$APP_DIR/Contents/MacOS/OrcaPRO"

# Ícone: o macOS quer .icns. O sips e o iconutil vêm com o sistema, então
# não há dependência a instalar. Sem ícone o app continua funcionando —
# por isso nada aqui interrompe a instalação se falhar.
if [ -f "$RAIZ/img/app-icon-512.png" ] && command -v iconutil >/dev/null 2>&1; then
  ICO="$(mktemp -d "${TMPDIR:-/tmp}/orcapro-ico.XXXXXX")/orcapro.iconset"
  mkdir -p "$ICO"
  for t in 16 32 128 256 512; do
    sips -z $t $t "$RAIZ/img/app-icon-512.png" --out "$ICO/icon_${t}x${t}.png" >/dev/null 2>&1
    d=$((t * 2))
    sips -z $d $d "$RAIZ/img/app-icon-512.png" --out "$ICO/icon_${t}x${t}@2x.png" >/dev/null 2>&1
  done
  iconutil -c icns "$ICO" -o "$APP_DIR/Contents/Resources/orcapro.icns" >/dev/null 2>&1
  rm -rf "$(dirname "$ICO")"
fi

# ---------------------------------------------------------------------
# ⚠ ASSINATURA AD-HOC — E ELA NÃO É ENFEITE.
#
#   A partir do macOS 15.1 o botão "Abrir Mesmo Assim" (Ajustes do Sistema
#   › Privacidade e Segurança) SÓ APARECE para código que tenha ao menos
#   uma assinatura ad-hoc. Um bundle sem assinatura nenhuma é bloqueado e
#   NÃO ganha entrada em lugar nenhum — o cliente fica sem caminho pela
#   interface gráfica, olhando uma tela que só oferece "Mover para o Lixo".
#
#   `codesign --sign -` é a assinatura ad-hoc: não precisa de conta Apple,
#   nem de certificado, nem de internet. Ela NÃO faz o aviso sumir — só
#   notarização faz isso, e notarização exige o Apple Developer Program.
#   O que ela faz é garantir que EXISTA a saída de emergência.
#
#   Feita aqui, na máquina do cliente, porque é onde o .app nasce.
#   Se o `codesign` não existir (Mac sem as ferramentas de linha de
#   comando), a instalação segue: o app funciona, só fica sem a saída de
#   emergência caso ele pegue quarentena — e ele nasce sem quarentena
#   justamente por ter sido montado aqui.
# ---------------------------------------------------------------------
if command -v codesign >/dev/null 2>&1; then
  if codesign --force --deep --sign - "$APP_DIR" >/dev/null 2>&1; then
    echo "        Assinatura ad-hoc aplicada (garante a saída do Gatekeeper)."
  else
    echo "        (não consegui assinar em modo ad-hoc — o app funciona mesmo assim)"
  fi
fi

echo "        Aplicativo criado em: $APP_DIR"
echo ""

# ---------------------------------------------------------------------
# [4/5] Atalho na Mesa (Desktop).
#
# ⚠ NÃO é um symlink. O Finder abre o alvo de um symlink para .app, mas
#   quando a pasta do sistema muda de lugar o link vira um arquivo morto
#   que não diz nada. Um alias do Finder se conserta sozinho; se o
#   osascript não estiver disponível, cai para o symlink, que é melhor
#   que nada.
# ---------------------------------------------------------------------
echo "  [4/5] Criando o atalho na Mesa..."
MESA="$HOME/Desktop"
if [ -d "$MESA" ]; then
  rm -f "$MESA/$APP_NOME.app" "$MESA/$APP_NOME" 2>/dev/null
  if ! osascript -e "tell application \"Finder\" to make alias file to POSIX file \"$APP_DIR\" at POSIX file \"$MESA\"" >/dev/null 2>&1; then
    ln -sfn "$APP_DIR" "$MESA/$APP_NOME.app" 2>/dev/null
  fi
  echo "        Atalho \"$APP_NOME\" criado na Mesa."
else
  echo "        (Sem pasta Desktop — o app está no Launchpad.)"
fi
echo ""

# ---------------------------------------------------------------------
# [5/5] Abrir
# ---------------------------------------------------------------------
echo "  [5/5] Tudo pronto! Abrindo o guia de boas-vindas e o OrçaPRO IA..."
echo ""

# ---------------------------------------------------------------------
# ⚠ O RECADO SOBRE O GATEKEEPER MUDA COM A VERSÃO DO macOS, E ISSO NÃO É
#   DETALHE: a Apple REMOVEU o "clique com botão direito › Abrir" no
#   macOS 15 (Sequoia), anunciado em 06/08/2024, e ele continua removido
#   no macOS 26. Uma instrução escrita para o Sonoma manda o cliente de
#   Sequoia para uma tela cuja única opção é "Mover para o Lixo" — e ele
#   conclui, com razão, que o programa é lixo.
#   Imprimir o caminho certo para a máquina que está na frente é a única
#   forma honesta de escrever isto, porque não dá para escolher um texto
#   só que sirva para as duas.
# ---------------------------------------------------------------------
V="$(env -u SYSTEM_VERSION_COMPAT /usr/bin/sw_vers -productVersion 2>/dev/null || sw_vers -productVersion 2>/dev/null)"
MAJ="$(printf '%s' "$V" | cut -d. -f1)"; [ -z "$MAJ" ] && MAJ=0
echo "  ----------------------------------------------------------------"
if [ "$MAJ" -ge 15 ] 2>/dev/null; then
  echo "  Este Mac está no macOS $V."
  echo ""
  echo "  A partir do macOS 15 a Apple tirou o atalho do botão direito para"
  echo "  abrir programa sem assinatura. Se algum dia um arquivo daqui for"
  echo "  bloqueado, o caminho é:"
  echo ""
  echo "     Ajustes do Sistema › Privacidade e Segurança › Segurança"
  echo "     → botão \"Abrir Mesmo Assim\" → confirmar → senha do Mac"
  echo ""
  echo "  ⚠ Esse botão só fica disponível por cerca de 1 hora depois da"
  echo "    tentativa que foi bloqueada. Passou disso, tente abrir de novo"
  echo "    e vá aos Ajustes na sequência."
  echo ""
  echo "  O caminho que NUNCA é bloqueado é o Terminal — está no"
  echo "  LEIA-ME-MAC.txt, e vale para qualquer versão do macOS."
else
  echo "  Este Mac está no macOS $V."
  echo ""
  echo "  Se algum arquivo daqui for bloqueado, use o botão direito › Abrir"
  echo "  (nesta versão do macOS esse atalho ainda existe)."
fi
echo "  ----------------------------------------------------------------"
echo ""

[ -f "$RAIZ/Bem-vindo.html" ] && open "$RAIZ/Bem-vindo.html" >/dev/null 2>&1
sleep 1
exec /bin/bash "$RAIZ/Iniciar-OrcaPRO.command"
