﻿; =====================================================================
;  OrcaPRO IA — instalador Windows (Inno Setup 6)
;
;  Compilar:
;    "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" ^
;       /DVersao=1.1.139 /DConteudo="C:\caminho\da\pasta\extraida" OrcaPRO.iss
;
;  O que este instalador faz, e por que cada escolha:
;
;  - INSTALA EM %LOCALAPPDATA%\Programs (NAO em Arquivos de Programas). O app se
;    atualiza sozinho sobrescrevendo os proprios arquivos; em Arquivos de
;    Programas isso exigiria elevacao a cada update e a atualizacao silenciosa
;    — que e a regra do produto — falharia por permissao. Por isso tambem
;    PrivilegesRequired=lowest: instala sem pedir administrador.
;
;  - NUNCA APAGA A PASTA data\. As bases SINAPI e as bases proprias do cliente
;    moram la; o desinstalador remove o programa e preserva o que e do usuario.
;
;  - NAO MEXE NOS DADOS DE TRABALHO. Orcamentos, obras e financeiro ficam no
;    localStorage do navegador, no perfil do Windows — fora da pasta do
;    programa. Reinstalar, mudar de pasta ou desinstalar nao os apaga.
; =====================================================================

#ifndef Versao
  #define Versao "1.1.139"
#endif
#ifndef Conteudo
  #define Conteudo "..\..\_conteudo"
#endif

#define Nome        "OrcaPRO IA"
#define NomeExib    "OrçaPRO IA"
#define Publisher   "RA Engenharia Especial"
#define URL         "https://orcapro.raengenhariaespecial.com.br"
#define ExeLauncher "Iniciar-OrcaPRO.bat"

[Setup]
AppId={{8B3F2C51-9A47-4D6E-B012-0C7A5E1F9D34}
AppName={#NomeExib}
AppVersion={#Versao}
AppVerName={#NomeExib} {#Versao}
AppPublisher={#Publisher}
AppPublisherURL={#URL}
AppSupportURL={#URL}
AppUpdatesURL={#URL}
VersionInfoVersion={#Versao}
VersionInfoCompany={#Publisher}
VersionInfoDescription=Instalador do {#NomeExib}

; --- pasta de instalacao: o usuario escolhe, e o padrao tem permissao de escrita
DefaultDirName={localappdata}\Programs\OrcaPRO
DisableDirPage=no
DirExistsWarning=no
UsePreviousAppDir=yes
DefaultGroupName={#NomeExib}
DisableProgramGroupPage=yes
AllowNoIcons=yes

; --- sem administrador: instalacao por usuario
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog

; --- documentos que o usuario le e aceita
LicenseFile=..\documentos\TERMO-DE-USO.txt
InfoBeforeFile=..\documentos\POLITICA-DE-PRIVACIDADE.txt

; --- identidade visual
SetupIconFile=assets\orcapro.ico
WizardImageFile=assets\wizard-grande.bmp
WizardSmallImageFile=assets\wizard-pequeno.bmp
WizardStyle=modern
WizardSizePercent=110

; --- saida
OutputDir=..\..\Documents\RA_Engenharia\Releases
OutputBaseFilename=OrcaPRO-IA-Instalador-v{#Versao}
Compression=lzma2/max
SolidCompression=yes
InternalCompressLevel=max

; --- desinstalador + entrada em "Adicionar ou remover programas"
UninstallDisplayName={#NomeExib} {#Versao}
UninstallDisplayIcon={app}\assets\orcapro.ico
CreateUninstallRegKey=yes

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon";  Description: "Criar um atalho na Área de Trabalho"; GroupDescription: "Atalhos:"
Name: "startupicon";  Description: "Abrir o OrçaPRO junto com o Windows"; GroupDescription: "Atalhos:"; Flags: unchecked

[Files]
; conteudo do app (a pasta extraida do pacote de distribuicao)
; TUDO menos data/ — o data/ entra logo abaixo com uninsneveruninstall
Source: "{#Conteudo}\*"; DestDir: "{app}"; Excludes: "data\*"; Flags: ignoreversion recursesubdirs createallsubdirs
; BASES DE PRECOS: uninsneveruninstall e o que REALMENTE protege. Sem esta flag,
; tudo que entra por [Files] fica no unins000.dat e o Inno apaga arquivo a arquivo
; DEPOIS do hook de desinstalacao — o ramo "manter" do hook nao impedia nada.
Source: "{#Conteudo}\data\*"; DestDir: "{app}\data"; Flags: ignoreversion recursesubdirs createallsubdirs uninsneveruninstall
; Os documentos NAO entram por aqui: eles viajam dentro de {#Conteudo}\documentos,
; junto com o resto do app. Motivo: o auto-update promove o conteudo do pacote com
; robocopy, entao os .txt so se atualizam em quem ja instalou se estiverem NO PACOTE.
; Instalados por [Files] a partir de assets\, ficariam congelados na versao do .exe.
Source: "assets\orcapro.ico";                  DestDir: "{app}\assets";     Flags: ignoreversion

[Icons]
Name: "{group}\{#NomeExib}";              Filename: "{app}\{#ExeLauncher}"; WorkingDir: "{app}"; IconFilename: "{app}\assets\orcapro.ico"
; O servidor deixou de rodar numa janela de console minimizada — ela ficava na
; barra de tarefas o dia inteiro e clientes reclamaram. Sem janela, "fechar a
; janela" deixou de ser o jeito de desligar, entao o desligar precisa de um
; atalho proprio. Sem esta linha o cliente fica sem como parar o sistema.
Name: "{group}\Desligar {#NomeExib}";     Filename: "{app}\Fechar-OrcaPRO.bat"; WorkingDir: "{app}"; IconFilename: "{app}\assets\orcapro.ico"
Name: "{group}\Termo de Uso";             Filename: "{app}\documentos\TERMO-DE-USO.txt"
Name: "{group}\Política de Privacidade";  Filename: "{app}\documentos\POLITICA-DE-PRIVACIDADE.txt"
Name: "{group}\Desinstalar {#NomeExib}";  Filename: "{uninstallexe}"
Name: "{autodesktop}\{#NomeExib}";        Filename: "{app}\{#ExeLauncher}"; WorkingDir: "{app}"; IconFilename: "{app}\assets\orcapro.ico"; Tasks: desktopicon
Name: "{userstartup}\{#NomeExib}";        Filename: "{app}\{#ExeLauncher}"; WorkingDir: "{app}"; IconFilename: "{app}\assets\orcapro.ico"; Tasks: startupicon

[Run]
Filename: "{app}\{#ExeLauncher}"; Description: "Abrir o {#NomeExib} agora"; WorkingDir: "{app}"; Flags: nowait postinstall skipifsilent shellexec

[UninstallDelete]
; o servidor local escreve estes; nao sao dados do usuario
Type: filesandordirs; Name: "{app}\.update-tmp"
Type: files;          Name: "{app}\*.log"

[Registry]
; carimba a aceitacao dos documentos: quem aceitou, qual versao e quando.
; E o que prova o consentimento exigido pela LGPD — sem isso, a tela de aceite
; e so decoracao.
Root: HKCU; Subkey: "Software\{#Publisher}\OrcaPRO"; ValueType: string; ValueName: "TermoVersao";   ValueData: "1.2"; Flags: uninsdeletevalue
Root: HKCU; Subkey: "Software\{#Publisher}\OrcaPRO"; ValueType: string; ValueName: "TermoAceitoEm"; ValueData: "{code:AgoraISO}"; Flags: uninsdeletevalue
Root: HKCU; Subkey: "Software\{#Publisher}\OrcaPRO"; ValueType: string; ValueName: "Versao";        ValueData: "{#Versao}"; Flags: uninsdeletevalue
Root: HKCU; Subkey: "Software\{#Publisher}\OrcaPRO"; ValueType: string; ValueName: "Pasta";         ValueData: "{app}"; Flags: uninsdeletevalue

[Code]
{ NAO existe pagina de "escolher o estado" aqui, e isso e deliberado: uma tela que
  pergunta e nao usa a resposta e pior que tela nenhuma. O pacote traz as 27 bases
  e o app abre com a base do proprio pacote; trocar de estado e 1 clique DENTRO do
  programa, onde a competencia de cada base fica visivel. }

function AgoraISO(Param: String): String;
begin
  Result := GetDateTimeString('yyyy-mm-dd hh:nn:ss', '-', ':');
end;

// PASTA PROTEGIDA — o app se atualiza sobrescrevendo os proprios arquivos; ali
// cada update falharia por permissao e o cliente ficaria numa versao velha SEM
// SABER. Duas correcoes em relacao a primeira versao desta funcao:
//
// 1) NAO usar a constante commonpf. Sem ArchitecturesInstallIn64BitMode no
//    [Setup], Is64BitInstallMode e sempre 0 e ela resolve para "Program Files
//    (x86)" — entao "C:\Program Files\OrcaPRO" PASSAVA pelo filtro. Agora a
//    lista e literal e cobre as duas arvores.
// 2) NextButtonClick nao roda em instalacao SILENCIOSA. A checagem tambem entra
//    em CurStepChanged(ssInstall), que roda sempre.
// (comentario com // e nao com chaves: no Inno as chaves de comentario NAO
//  aninham, e uma constante entre chaves no meio do texto fecha o comentario)
function PastaProtegida(Caminho: String): Boolean;
var
  C: String;
begin
  C := Lowercase(Caminho);
  Result := (Pos('\program files', C) > 0) or
            (Pos('\arquivos de programas', C) > 0) or
            (Pos('\windows\', C) = Pos(':\windows\', C) - 1) or
            (Copy(C, 2, 10) = ':\windows\') or
            (Pos(Lowercase(ExpandConstant('{sys}')), C) = 1);
end;

function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;
  if CurPageID = wpSelectDir then
  begin
    if PastaProtegida(WizardDirValue) then
    begin
      MsgBox('Esta pasta é protegida pelo Windows.' + #13#10#13#10 +
             'O OrçaPRO se atualiza sozinho, sobrescrevendo os próprios arquivos. ' +
             'Instalado aqui, cada atualização falharia por falta de permissão — e o ' +
             'sistema ficaria parado numa versão antiga sem avisar.' + #13#10#13#10 +
             'Escolha uma pasta do seu usuário. A sugerida é a recomendada.',
             mbError, MB_OK);
      Result := False;
    end;
  end;
end;

{ mesma trava para a instalacao silenciosa, onde NextButtonClick nao e chamado }
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if (CurStep = ssInstall) and PastaProtegida(ExpandConstant('{app}')) then
  begin
    SuppressibleMsgBox('Pasta protegida pelo Windows — a atualização automática do ' +
      'OrçaPRO não funcionaria aqui. Instalação cancelada.', mbError, MB_OK, IDOK);
    Abort;
  end;
end;

{ Ao desinstalar, pergunta o que fazer com as bases de precos. Elas podem ter
  base propria importada pelo cliente — apagar sem perguntar seria destruir
  trabalho dele. }
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  Dados: String;
begin
  if CurUninstallStep = usUninstall then
  begin
    Dados := ExpandConstant('{app}\data');
    if DirExists(Dados) then
    begin
      { SuppressibleMsgBox, NUNCA MsgBox: MsgBox SEMPRE abre a caixa modal e
        IGNORA /SUPPRESSMSGBOXES — uma desinstalação silenciosa ficaria TRAVADA
        esperando um clique que ninguém vai dar. SuppressibleMsgBox honra a flag e
        usa a resposta padrão que passamos (IDYES = manter as bases). }
      if SuppressibleMsgBox('Manter as bases de preços instaladas nesta pasta?' + #13#10#13#10 +
                'Recomendado: Sim. Se você importou bases próprias ou tabelas de ' +
                'fornecedor, elas estão aqui — responder Não as apaga.' + #13#10#13#10 +
                'Seus orçamentos, obras e financeiro NÃO estão nesta pasta: ficam no ' +
                'navegador e não são afetados por esta escolha.',
                mbConfirmation, MB_YESNO or MB_DEFBUTTON1, IDYES) = IDNO then
        DelTree(Dados, True, True, True);
    end;
  end;
end;
