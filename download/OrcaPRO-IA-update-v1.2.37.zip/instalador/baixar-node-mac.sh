#!/bin/bash
# =====================================================================
# baixar-node-mac.sh — prepara o Node.js no Mac SEM instalar no sistema
# e SEM pedir senha de administrador. Baixa o Node portátil, extrai, e
# deixa o binário em runtime/bin/node.
#
# Espelha o instalador/baixar-node.ps1 do Windows. As diferenças que
# importam estão anotadas onde aparecem.
# =====================================================================
set -u

RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUNTIME="$RAIZ/runtime"
NODE_BIN="$RUNTIME/bin/node"

if [ -x "$NODE_BIN" ]; then
  echo "        Node já preparado (runtime/bin/node)."
  exit 0
fi

# ---------------------------------------------------------------------
# ⚠ `uname -m` RESPONDE A ARQUITETURA DO PROCESSO, NÃO A DA MÁQUINA.
#
#   Se o Terminal estiver marcado como "Abrir usando o Rosetta" (Obter
#   Informações do Finder), TODO processo filho — este script, o curl, o
#   node — roda traduzido, e num Mac com chip Apple o `uname -m` responde
#   `x86_64`. Baixaríamos o Node Intel para uma máquina ARM: ele até roda
#   sob Rosetta, mas devagar, e no dia em que a Apple encerrar o Rosetta
#   (documentado: até o macOS 27) a instalação simplesmente para de abrir.
#   A Apple documenta que "a tradução se aplica ao processo inteiro,
#   incluindo os módulos carregados dinamicamente" — por isso a herança.
#
#   A pergunta certa é `sysctl.proc_translated`, que a própria Apple
#   documenta: 1 = este processo está traduzido, 0 = nativo, ausente =
#   Mac Intel de verdade. É o mesmo teste que o Homebrew usa.
#
#   ⚠ E NUNCA `arch` SEM ARGUMENTO: ele imprime `i386` tanto num Mac Intel
#   quanto sob Rosetta, e nunca `x86_64`. O manual da Apple diz que ele
#   "mostra o tipo de arquitetura da máquina" — o manual está errado; o
#   código-fonte (system_cmds/arch/arch.c) chama NXGetLocalArchInfo(),
#   que é do PROCESSO.
# ---------------------------------------------------------------------
MAQUINA="$(uname -m)"
TRADUZIDO="$(sysctl -n sysctl.proc_translated 2>/dev/null || echo 0)"
if [ "$MAQUINA" = "x86_64" ] && [ "$TRADUZIDO" = "1" ]; then
  MAQUINA="arm64"      # é um Mac Apple Silicon fingindo ser Intel
fi
case "$MAQUINA" in
  x86_64) ARCO="darwin-x64" ;;
  arm64)  ARCO="darwin-arm64" ;;
  *)      echo "  [ERRO] Arquitetura de Mac não reconhecida: $MAQUINA"; exit 1 ;;
esac

# ---------------------------------------------------------------------
# Versão do macOS.
#
# ⚠ `env -u SYSTEM_VERSION_COMPAT`: essa variável é um atalho de
#   compatibilidade do Big Sur que, quando herdada de um processo pai
#   antigo, faz o `sw_vers` responder "10.16" no lugar de 11 ou mais. O
#   gate de versão abaixo passaria a barrar Macs perfeitamente bons.
# ---------------------------------------------------------------------
MACOS_VER="$(env -u SYSTEM_VERSION_COMPAT /usr/bin/sw_vers -productVersion 2>/dev/null || sw_vers -productVersion 2>/dev/null)"
MACOS_MAJOR="$(printf '%s' "$MACOS_VER" | cut -d. -f1)"
MACOS_MINOR="$(printf '%s' "$MACOS_VER" | cut -d. -f2)"
[ -z "$MACOS_MAJOR" ] && MACOS_MAJOR=0
[ -z "$MACOS_MINOR" ] && MACOS_MINOR=0

if [ "$MACOS_MAJOR" -lt 11 ] 2>/dev/null; then
  echo ""
  echo "  [ERRO] Este Mac está no macOS $MACOS_VER, e as versões do Node que"
  echo "         damos suporte precisam do macOS 11 (Big Sur) ou mais novo."
  echo "         Atualize o macOS e rode este instalador de novo."
  echo ""
  exit 1
fi

# ---------------------------------------------------------------------
# QUAL LINHA DO NODE.
#
# ⚠ A ESCOLHA É POR PRAZO DE VIDA, não por "a mais nova". O Node 24 sai de
#   suporte em 30/04/2028; o 22, em 30/04/2027. Um instalador que nasce
#   hoje com o 22 já nasce com pouco tempo de estrada.
#   Mas o 24 exige macOS 13.5 (Ventura). Em Mac mais antigo — que é
#   justamente o Mac que sobrou para virar máquina de escritório — a linha
#   22 ainda cobre a partir do macOS 11.
#   Escolher pela versão do sistema, e não pela mais nova, é o que evita
#   entregar um binário que abre e morre sem explicar.
# ---------------------------------------------------------------------
if [ "$MACOS_MAJOR" -gt 13 ] 2>/dev/null || { [ "$MACOS_MAJOR" -eq 13 ] && [ "$MACOS_MINOR" -ge 5 ]; } 2>/dev/null; then
  LINHA="24"; FALLBACK="v24.13.0"
else
  LINHA="22"; FALLBACK="v22.23.2"
fi

# Descobre a versão mais nova da linha escolhida; se a internet não
# responder, usa a de apoio. `curl` vem com o macOS — sem dependência.
VER=""
LISTA="$(curl -fsSL --max-time 25 https://nodejs.org/dist/index.json 2>/dev/null)"
if [ -n "$LISTA" ]; then
  VER="$(printf '%s' "$LISTA" | tr ',' '\n' | grep -o "\"version\":\"v$LINHA\.[0-9.]*\"" | head -1 | sed 's/.*"v/v/; s/"//')"
fi
[ -z "$VER" ] && VER="$FALLBACK"

URL="https://nodejs.org/dist/$VER/node-$VER-$ARCO.tar.gz"
echo "        Baixando o Node.js ($VER, $ARCO) para o macOS $MACOS_VER..."

TMP="$(mktemp -d "${TMPDIR:-/tmp}/orcapro-node.XXXXXX")"
# shellcheck disable=SC2064
trap "rm -rf '$TMP'" EXIT

if ! curl -fL --max-time 900 -o "$TMP/node.tar.gz" "$URL"; then
  echo ""
  echo "  [ERRO] Não consegui baixar o Node.js."
  echo "         Confira a internet e rode de novo, ou instale o Node LTS"
  echo "         em https://nodejs.org e rode este instalador de novo."
  echo ""
  exit 1
fi

# `tar` vem com o macOS e entende .tar.gz.
if ! tar -xzf "$TMP/node.tar.gz" -C "$TMP"; then
  echo "  [ERRO] O arquivo baixado veio corrompido. Rode de novo."
  exit 1
fi

ORIG="$(find "$TMP" -maxdepth 2 -type d -name 'node-v*' | head -1)"
if [ -z "$ORIG" ] || [ ! -x "$ORIG/bin/node" ]; then
  echo "  [ERRO] O pacote do Node veio sem o binário esperado."
  exit 1
fi

rm -rf "$RUNTIME"
mkdir -p "$RUNTIME"
# ⚠ COPIA bin/ E lib/ JUNTOS. Só o binário `node` não basta: ele carrega o
#   ICU e os módulos internos a partir de ../lib. Copiar só o executável dá
#   um Node que abre e falha no primeiro `require`.
cp -R "$ORIG/bin" "$RUNTIME/bin"
[ -d "$ORIG/lib" ] && cp -R "$ORIG/lib" "$RUNTIME/lib"

chmod +x "$RUNTIME/bin/node" 2>/dev/null

# ⚠ TIRA A QUARENTENA DO BINÁRIO BAIXADO. Tudo que o `curl` traz recebe o
#   atributo com.apple.quarantine; ao rodar, o Gatekeeper barra com
#   "não foi possível verificar o desenvolvedor" e o cliente vê o sistema
#   simplesmente não abrir. O Node vem assinado e notarizado pela própria
#   Node.js Foundation — a quarentena aqui só atrapalha.
xattr -dr com.apple.quarantine "$RUNTIME" 2>/dev/null

if ! "$NODE_BIN" -v >/dev/null 2>&1; then
  echo "  [ERRO] O Node baixado não executou neste Mac."
  echo "         (arquitetura detectada: $MAQUINA · pacote: $ARCO)"
  exit 1
fi

echo "        Node.js pronto: $("$NODE_BIN" -v) em runtime/bin/node"
exit 0
