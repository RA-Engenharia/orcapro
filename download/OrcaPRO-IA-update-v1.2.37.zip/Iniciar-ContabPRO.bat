@echo off
chcp 65001 >nul
title ContabPRO
cd /d "%~dp0"

REM --- Node: usa o MESMO runtime embutido do OrcaPRO; senao o do sistema; senao baixa ---
if exist "%~dp0runtime\node.exe" set "PATH=%~dp0runtime;%PATH%"
where node >nul 2>nul
if errorlevel 1 (
  echo Preparando o Node.js ^(so na 1a vez, precisa de internet^)...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalador\baixar-node.ps1"
  if exist "%~dp0runtime\node.exe" set "PATH=%~dp0runtime;%PATH%"
)
where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js indisponivel. Rode Instalar-OrcaPRO.bat com a internet ligada.
  pause
  exit /b 1
)

echo [OK] Subindo o ContabPRO ^(porta 8770^)...

REM --- SEM JANELA DE CONSOLE ---
REM  Mesmo caso do Iniciar-OrcaPRO.bat: o `start /min cmd /c` deixava uma
REM  janela na barra de tarefas o dia inteiro. Quem usa os dois apps ficava
REM  com DUAS — foi o que apareceu na reclamacao. Consertar so um lado
REM  deixaria a metade do incomodo de pe.
if exist "%~dp0iniciar-oculto.vbs" (
  wscript //B //Nologo "%~dp0iniciar-oculto.vbs" "%~dp0." "node contabpro\server\static.js 8770"
) else (
  REM  pacote antigo sem o lancador: volta ao jeito de antes, com janela.
  start "ContabPRO App" /min cmd /c "node contabpro\server\static.js 8770"
)
ping 127.0.0.1 -n 3 >nul
start "" "http://localhost:8770/index.html?v=%RANDOM%%RANDOM%"
echo.
echo ContabPRO aberto no navegador. Esta janela fecha sozinha.
echo (Para desligar depois, use o Fechar-OrcaPRO.bat.)
timeout /t 4 >nul
