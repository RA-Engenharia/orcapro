/* Servidor estático mínimo do ContabPRO (dev). Uso: node server/static.js [porta] */
"use strict";
var http = require("http"), fs = require("fs"), path = require("path"), url = require("url");
var ROOT = path.join(__dirname, "..");
var PORT = parseInt(process.env.PORT || process.argv[2] || "8770", 10);
var MIME = { ".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8", ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon" };

http.createServer(function (req, res) {
  var p = decodeURIComponent(url.parse(req.url).pathname);
  if (p === "/") p = "/index.html";
  var f = path.join(ROOT, p.replace(/\.\./g, ""));
  fs.readFile(f, function (err, data) {
    if (err) { res.writeHead(404, { "Content-Type": "text/plain" }); res.end("404 " + p); return; }
    res.writeHead(200, { "Content-Type": MIME[path.extname(f)] || "application/octet-stream", "Cache-Control": "no-store" });
    res.end(data);
  });
}).listen(PORT, function () { console.log("ContabPRO em http://localhost:" + PORT); });
