/* =====================================================================
 * obrigacoes.js — MOTOR da Agenda de Obrigações (seção 3.4, o coração).
 * Gera a agenda do ano por cliente (regime × UF × segmento × serviços × funcionários),
 * regenera o FUTURO mantendo o passado, ajusta prazo por feriado (regra do tributo),
 * e controla o workflow (comprovante obrigatório p/ concluir; retificação exige causa-raiz).
 * Puro/testável (module.exports no fim).
 * ===================================================================== */
(function (global) {
  "use strict";
  var Util = (typeof require !== "undefined") ? require("./util.js") : global.Util;

  // Workflow (seção 3.4.3)
  var WORKFLOW = ["pendente", "em_preparacao", "em_conferencia", "aguardando_cliente", "transmitida", "comprovante_anexado", "concluida"];
  var ROTULO = {
    pendente: "Pendente", em_preparacao: "Em preparação", em_conferencia: "Em conferência (4 olhos)",
    aguardando_cliente: "Aguardando cliente", transmitida: "Transmitida", comprovante_anexado: "Comprovante anexado",
    concluida: "Concluída", retificada: "Retificada"
  };

  // ---- Feriados nacionais (fixos + móveis via Páscoa) ----
  function pascoa(ano) { // algoritmo de Gauss/Butcher
    var a = ano % 19, b = Math.floor(ano / 100), c = ano % 100, d = Math.floor(b / 4), e = b % 4,
      f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30,
      i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451),
      mes = Math.floor((h + l - 7 * m + 114) / 31), dia = ((h + l - 7 * m + 114) % 31) + 1;
    return { m: mes, d: dia };
  }
  function feriadosNacionais(ano) {
    var fx = ["01-01", "04-21", "05-01", "09-07", "10-12", "11-02", "11-15", "11-20", "12-25"];
    var out = {}; fx.forEach(function (f) { out[ano + "-" + f] = 1; });
    var p = pascoa(ano); var base = Util.iso(ano, p.m, p.d);
    [-48, -47, -2, 60].forEach(function (off) { out[Util.somaDias(base, off)] = 1; }); // Carnaval(seg/ter), Sexta Santa, Corpus Christi
    return out;
  }

  function ehDiaUtil(iso, feriados) { var ds = Util.diaSemana(iso); return ds !== 0 && ds !== 6 && !feriados[iso]; }
  // ajusta o vencimento conforme a regra do tributo (antecipa/posterga/nenhum)
  function ajustar(iso, modo, feriados) {
    if (modo === "nenhum") return iso;
    var passo = modo === "antecipa" ? -1 : 1, guard = 0, cur = iso;
    while (!ehDiaUtil(cur, feriados) && guard++ < 20) cur = Util.somaDias(cur, passo);
    return cur;
  }

  // ---- Aplicabilidade de uma obrigação a um cliente (para um ano/UF) ----
  function regimeNoAno(cliente, ano) {
    var h = cliente.regimeTributario || [];
    if (typeof h === "string") return h;
    var achou = null; // pega o regime cuja vigência cobre o ano (o de maior ano <= ano)
    for (var i = 0; i < h.length; i++) { if ((h[i].ano || 0) <= ano) { if (!achou || h[i].ano > achou.ano) achou = h[i]; } }
    return achou ? achou.regime : (h[0] && h[0].regime) || null;
  }
  function temIE(cliente) { var ins = cliente.inscricoes || []; for (var i = 0; i < ins.length; i++) if ((ins[i].tipo === "estadual" || ins[i].tipo === "IE") && ins[i].numero) return true; return false; }
  function ufsDoCliente(cliente) {
    var set = {}; if (cliente.uf) set[cliente.uf] = 1;
    (cliente.filiais || []).forEach(function (f) { if (f.uf) set[f.uf] = 1; });
    var out = []; for (var k in set) out.push(k); return out.length ? out : (cliente.uf ? [cliente.uf] : []);
  }
  function segmentos(cliente) { return cliente.segmento || cliente.segmentos || []; }
  function atividadeServico(cliente) { var s = segmentos(cliente); return s.indexOf("servicos") >= 0 || s.indexOf("saude") >= 0 || s.indexOf("imobiliaria") >= 0 || s.indexOf("condominio") >= 0 || !!cliente.prestaServico; }

  function aplica(def, cliente, ano, uf) {
    var a = def.aplica || {}, reg = regimeNoAno(cliente, ano), segs = segmentos(cliente);
    if (a.regime && a.regime.indexOf(reg) < 0) return false; // regime é gate: sem bater, não aplica
    if (a.excluiRegime && a.excluiRegime.indexOf(reg) >= 0) return false;
    if (a.segmento) { var ok = false; for (var i = 0; i < a.segmento.length; i++) if (segs.indexOf(a.segmento[i]) >= 0) ok = true; if (!ok) return false; }
    if (a.excluiSegmento) { for (var j = 0; j < a.excluiSegmento.length; j++) if (segs.indexOf(a.excluiSegmento[j]) >= 0) return false; }
    if (a.temIE && !temIE(cliente)) return false;
    if (a.temFuncionarios && !((cliente.funcionarios || 0) > 0)) return false;
    if (a.atividadeServico && !atividadeServico(cliente)) return false;
    if (a.uf && uf && a.uf.indexOf(uf) < 0) return false; // GIA só em certas UFs
    return true;
  }

  // ---- Ocorrências no ano (competências + vencimento) ----
  function ocorrencias(def, ano, feriados) {
    var out = [], meses = [];
    if (def.periodicidade === "mensal") for (var m = 1; m <= 12; m++) meses.push(m);
    else if (def.periodicidade === "trimestral") meses = [3, 6, 9, 12];
    else if (def.periodicidade === "semestral") meses = [6, 12];
    else if (def.periodicidade === "anual") meses = [def.mesRef || 12];

    meses.forEach(function (mesComp) {
      var comp = Util.competencia(ano, mesComp), vencAno, vencMes;
      if (def.periodicidade === "anual") { vencAno = ano + 1; vencMes = def.mesRef || 12; } // anuais vencem no ano seguinte
      else { // vencimento no mês seguinte à competência
        vencMes = mesComp + 1; vencAno = ano; if (vencMes > 12) { vencMes = 1; vencAno = ano + 1; }
      }
      var dia = Math.min(def.diaVenc || 20, Util.ultimoDia(vencAno, vencMes));
      var prazoLegal = Util.iso(vencAno, vencMes, dia);
      var prazoAjustado = ajustar(prazoLegal, def.ajusteFeriado || "nenhum", feriados);
      out.push({ competencia: comp, prazoLegal: prazoLegal, prazoAjustado: prazoAjustado });
    });
    return out;
  }

  function novaObrigacao(cliente, def, occ, uf) {
    var id = cliente.id + "|" + def.codigo + "|" + occ.competencia + (uf ? "|" + uf : "");
    return {
      id: id, clienteId: cliente.id, codigo: def.codigo, nome: def.nome + (uf ? " (" + uf + ")" : ""),
      grupo: def.grupo, departamento: def.departamento, uf: uf || null,
      competencia: occ.competencia, prazoLegal: occ.prazoLegal, prazoAjustado: occ.prazoAjustado,
      status: "pendente", responsavelId: null, conferenteId: null, semMovimento: false,
      comprovante: null, retificacoes: [], multa: null,
      historico: [{ status: "pendente", quando: Util.hojeISO() }]
    };
  }

  // ---- API pública ----
  var CObrig = {
    WORKFLOW: WORKFLOW, ROTULO: ROTULO, feriadosNacionais: feriadosNacionais, ehDiaUtil: ehDiaUtil, ajustar: ajustar,
    aplica: aplica, regimeNoAno: regimeNoAno,

    // Gera a agenda inteira do ano (array de obrigações, NÃO persiste).
    gerarAgenda: function (cliente, ano, matriz, feriadosExtra) {
      var defs = (matriz && matriz.obrigacoes) || [];
      var feriados = feriadosNacionais(ano);
      if (feriadosExtra) for (var k in feriadosExtra) feriados[k] = 1;
      var out = [];
      defs.forEach(function (def) {
        var ufs = def.porUF ? ufsDoCliente(cliente) : [null];
        ufs.forEach(function (uf) {
          if (!aplica(def, cliente, ano, uf)) return;
          ocorrencias(def, ano, feriados).forEach(function (occ) { out.push(novaObrigacao(cliente, def, occ, uf)); });
        });
      });
      return out;
    },

    // Regenera o FUTURO mantendo o passado (seção 3.4 / teste 4).
    // existentes = obrigações já salvas; novas = gerarAgenda(); compCorte = "2026-07".
    // REGRA DE OURO (nunca perder prazo): além das competências >= corte, TAMBÉM entram
    // obrigações de competência passada cujo VENCIMENTO ainda é futuro e que o cliente
    // ainda não tem registrada (cliente novo cadastrado no meio do ano; anuais tipo
    // DEFIS/DIMOB cujo mesRef já passou mas vencem no ano seguinte; segmento novo).
    regenerarFuturo: function (existentes, novas, compCorte, hojeRef) {
      hojeRef = hojeRef || Util.hojeISO();
      var mantidas = existentes.filter(function (o) { return o.competencia < compCorte; });
      var idxAntigo = {}; existentes.forEach(function (o) { idxAntigo[o.id] = o; });
      var entrantes = novas.filter(function (o) {
        if (o.competencia >= compCorte) return true;
        // competência passada: só entra se o prazo ainda não venceu E não existe registro
        return o.prazoAjustado >= hojeRef && !idxAntigo[o.id];
      });
      // preserva status/comprovante das que já existiam com a mesma identidade (mesmo id)
      entrantes = entrantes.map(function (o) { var v = idxAntigo[o.id]; return (v && v.status !== "pendente") ? v : o; });
      return mantidas.concat(entrantes);
    },

    // Transição de status com validação (seção 3.4.3).
    avancar: function (ob, novoStatus, usuarioId) {
      // o 1º a mexer é o PREPARADOR real (persistido) — base da segregação dos 4 olhos
      if (!ob.preparadorId && usuarioId) ob.preparadorId = usuarioId;
      ob.status = novoStatus; (ob.historico = ob.historico || []).push({ status: novoStatus, quando: Util.hojeISO(), por: usuarioId || null });
      return ob;
    },
    // Dupla conferência (4 olhos, seção 3.22): obrigações de alto impacto exigem
    // que um SEGUNDO analista confira antes de transmitir. Lista/liga-desliga em CONFIG.
    CRITICAS: { "ECF": 1, "ECD": 1, "DCTFWeb": 1, "DCTFWeb-Folha": 1, "EFD-Contribuicoes": 1, "eSocial": 1, "DEFIS": 1 },
    exigeConferencia: function (ob) {
      var cfg = global.CONFIG && global.CONFIG.duplaConferencia;
      if (cfg && cfg.ativa === false) return false;
      var criticas = (cfg && cfg.criticas) ? cfg.criticas : null;
      return criticas ? (criticas.indexOf(ob.codigo) >= 0) : !!CObrig.CRITICAS[ob.codigo];
    },
    // Marca conferência. Segregação: conferente ≠ PREPARADOR REAL (persistido em ob.preparadorId).
    conferir: function (ob, conferenteId, preparadorFallback) {
      var prep = ob.preparadorId || preparadorFallback || null;
      if (conferenteId && prep && conferenteId === prep) { var e2 = new Error("Quem prepara não pode conferir (segregação de funções — 4 olhos)."); e2.codigo = "MESMO_PREPARADOR"; throw e2; }
      ob.conferenteId = conferenteId; ob.conferidoEm = Util.hojeISO();
      if (ob.status === "pendente" || ob.status === "em_preparacao") ob.status = "em_conferencia";
      (ob.historico = ob.historico || []).push({ status: "conferida", quando: Util.hojeISO(), por: conferenteId || null });
      return ob;
    },
    // Dispensa a conferência (escritório solo / config desligada) — com motivo auditado.
    dispensarConferencia: function (ob, motivo, usuarioId) {
      ob.conferenciaDispensada = true; ob.conferenciaDispensaMotivo = motivo || "";
      (ob.historico = ob.historico || []).push({ status: "conferencia_dispensada", quando: Util.hojeISO(), por: usuarioId || null, motivo: motivo || "" });
      return ob;
    },

    // Concluir SÓ com comprovante (regra de ouro seção 1 / teste 5) + 4 olhos nas críticas.
    concluir: function (ob, comprovante, usuarioId) {
      if (!comprovante) { var e = new Error("Não é possível concluir sem recibo/protocolo anexado."); e.codigo = "SEM_COMPROVANTE"; throw e; }
      if (CObrig.exigeConferencia(ob) && !ob.conferenteId && !ob.conferenciaDispensada && !(comprovante && comprovante.tipo === "sem_movimento")) {
        var ec = new Error("Obrigação crítica exige dupla conferência (4 olhos) antes de transmitir."); ec.codigo = "CONFERENCIA_PENDENTE"; throw ec;
      }
      ob.comprovante = comprovante; ob.status = "concluida";
      (ob.historico = ob.historico || []).push({ status: "concluida", quando: Util.hojeISO(), por: usuarioId || null });
      return ob;
    },
    // Retificar exige causa-raiz (KPI de qualidade seção 3.22 / teste 5).
    retificar: function (ob, causaRaiz, motivo, usuarioId) {
      if (!causaRaiz) { var e = new Error("Retificação exige causa-raiz (erro interno / dado do cliente / mudança de norma)."); e.codigo = "SEM_CAUSA_RAIZ"; throw e; }
      (ob.retificacoes = ob.retificacoes || []).push({ causaRaiz: causaRaiz, motivo: motivo || "", quando: Util.hojeISO(), por: usuarioId || null });
      ob.status = "retificada";
      (ob.historico = ob.historico || []).push({ status: "retificada", quando: Util.hojeISO(), por: usuarioId || null });
      return ob;
    }
  };

  global.CObrig = CObrig;
  if (typeof module !== "undefined" && module.exports) module.exports = CObrig;
})(typeof window !== "undefined" ? window : global);
