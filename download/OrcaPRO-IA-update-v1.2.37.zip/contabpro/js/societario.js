/* =====================================================================
 * societario.js — Societário/Legalização (seção 3.8).
 * Duas frentes numa tela:
 *  (A) Processos societários (abertura/alteração/baixa/transformação) com
 *      checklist de etapas por órgão (viabilidade → Junta → Receita →
 *      estado → prefeitura → licenças), prazo, taxa e protocolo.
 *  (B) Alvarás e licenças com controle de vencimento (semáforo).
 * Coleções novas: "processosSoc" e "alvaras".
 * RBAC: Auth.pode("societario", "criar"/"editar"/"excluir") — guard NA
 * FUNÇÃO (não só esconde botão). Registrada como id "societario".
 * ES5 estrito (var/function/concat). Orquestra Store + Auth + UI + App.
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  // ---------- Tabelas fixas do módulo ----------
  var TIPOS = [
    { v: "abertura",       t: "Abertura",       cor: "azul" },
    { v: "alteracao",      t: "Alteração",      cor: "roxo" },
    { v: "baixa",          t: "Baixa",          cor: "vermelho" },
    { v: "transformacao",  t: "Transformação",  cor: "amber" }
  ];
  var TIPOS_ALVARA = [
    { v: "alvara",    t: "Alvará" },
    { v: "licenca",   t: "Licença" },
    { v: "inscricao", t: "Inscrição" }
  ];
  // Órgãos sugeridos (ordem do rito de legalização).
  var ORGAOS = ["Junta Comercial", "Receita Federal", "SEFAZ (Estado)", "Prefeitura", "Vigilância Sanitária", "Corpo de Bombeiros", "Meio Ambiente", "Outro"];

  // ---------- Helpers puros (closure do módulo) ----------

  // Padrão de nome entre telas; null-safe (cliente pode ter sido excluído).
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(cliente excluído)"; }
  function idUsuario() { var u = Auth.usuario(); return u ? u.id : null; }

  function tipoInfo(v) { for (var i = 0; i < TIPOS.length; i++) if (TIPOS[i].v === v) return TIPOS[i]; return { v: v, t: v || "—", cor: "cinza" }; }
  function tipoBadge(v) { var t = tipoInfo(v); return UI.badge(t.t, t.cor); }
  function rotuloAlvara(v) { for (var i = 0; i < TIPOS_ALVARA.length; i++) if (TIPOS_ALVARA[i].v === v) return TIPOS_ALVARA[i].t; return v || "—"; }

  // Status do processo -> badge.
  function statusBadge(st) {
    if (st === "concluido") return UI.badge("concluído", "verde");
    if (st === "cancelado") return UI.badge("cancelado", "vermelho");
    return UI.badge("em andamento", "azul");
  }

  // Progresso do checklist (feitas/total).
  function progresso(proc) {
    var et = proc.etapas || [], feitas = 0;
    for (var i = 0; i < et.length; i++) if (et[i].feito) feitas++;
    return { feitas: feitas, total: et.length };
  }
  function todasFeitas(proc) { var p = progresso(proc); return p.total > 0 && p.feitas === p.total; }

  // Etapas padrão de ABERTURA (rito de legalização). IDs por uid (interativo).
  function etapasPadraoAbertura() {
    var base = [
      { orgao: "Junta Comercial", titulo: "Viabilidade / consulta prévia (nome + endereço)" },
      { orgao: "Junta Comercial", titulo: "Registro do ato constitutivo (NIRE)" },
      { orgao: "Receita Federal", titulo: "Inscrição no CNPJ" },
      { orgao: "SEFAZ (Estado)",  titulo: "Inscrição Estadual" },
      { orgao: "Prefeitura",      titulo: "Inscrição Municipal" },
      { orgao: "Prefeitura",      titulo: "Alvará de funcionamento" }
    ];
    var out = [];
    for (var i = 0; i < base.length; i++) {
      out.push({ id: Util.uid("et"), orgao: base[i].orgao, titulo: base[i].titulo, prazo: "", taxa: 0, protocolo: "", feito: false, feitoEm: null });
    }
    return out;
  }

  // Badge de prazo de uma etapa pendente (atraso vermelho / <=7d âmbar).
  function prazoEtapaBadge(et) {
    if (et.feito || !et.prazo) return "";
    var d = Util.diasAte(et.prazo);
    if (d == null) return "";
    if (d < 0) return " " + UI.badge((-d) + "d atraso", "vermelho");
    if (d === 0) return " " + UI.badge("hoje", "amber");
    if (d <= 7) return " " + UI.badge("em " + d + "d", "amber");
    return "";
  }

  // Semáforo de vencimento de alvará.
  function alvaraBadge(al) {
    var d = Util.diasAte(al.validade);
    if (d == null) return UI.badge("sem validade", "cinza");
    if (d < 0) return UI.badge("vencido há " + (-d) + "d", "vermelho");
    if (d <= 30) return UI.badge("vence em " + d + "d", "amber");
    return UI.badge("válido", "cinza");
  }

  // ---------- View ----------
  global.SocietarioView = App.registrar({
    id: "societario",
    titulo: "Societário",

    render: function () {
      if (!this._filtroCliente) this._filtroCliente = "";
      var self = this;

      // Clientes visíveis (respeita carteira do analista).
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      var setVis = {}, nomeCli = {}, i;
      for (i = 0; i < visiveis.length; i++) { setVis[visiveis[i].id] = 1; nomeCli[visiveis[i].id] = nomeCliente(visiveis[i]); }
      function nomeDe(id) { return nomeCli[id] || "(cliente excluído)"; }

      // Filtro fantasma: cliente filtrado sumiu -> volta pra "todos".
      if (this._filtroCliente && !setVis[this._filtroCliente]) this._filtroCliente = "";

      // Processos de clientes visíveis.
      var todos = Store.listar("processosSoc"), procs = [];
      for (i = 0; i < todos.length; i++) if (setVis[todos[i].clienteId]) procs.push(todos[i]);

      // Detalhe aberto ainda existe e é visível?
      if (this._aberto) {
        var pa = Store.obter("processosSoc", this._aberto);
        if (!pa || !setVis[pa.clienteId]) this._aberto = null;
      }

      // ---- KPIs ----
      var nAnd = 0, nConc = 0, i2;
      for (i2 = 0; i2 < procs.length; i2++) { if (procs[i2].status === "concluido") nConc++; else if (procs[i2].status !== "cancelado") nAnd++; }
      var alvarasVis = Store.listar("alvaras").filter(function (a) { return setVis[a.clienteId]; });
      var nVenc = 0, nVenc30 = 0;
      for (i2 = 0; i2 < alvarasVis.length; i2++) {
        var d = Util.diasAte(alvarasVis[i2].validade);
        if (d != null) { if (d < 0) nVenc++; else if (d <= 30) nVenc30++; }
      }
      var kpis = '<div class="grid-kpi">' +
        '<div class="kpi ' + (nAnd ? "wr" : "") + '"><div class="n">' + nAnd + '</div><div class="l">Processos em andamento</div></div>' +
        '<div class="kpi ok"><div class="n">' + nConc + '</div><div class="l">Processos concluídos</div></div>' +
        '<div class="kpi ' + (nVenc ? "al" : "") + '"><div class="n">' + nVenc + '</div><div class="l">Alvarás vencidos</div></div>' +
        '<div class="kpi ' + (nVenc30 ? "wr" : "") + '"><div class="n">' + nVenc30 + '</div><div class="l">Vencem em 30 dias</div></div>' +
        "</div>";

      var podeCriar = Auth.pode("societario", "criar");

      // ---- Card A: processos OU detalhe do processo aberto ----
      var cardA;
      if (this._aberto) {
        cardA = this._detalheHtml(Store.obter("processosSoc", this._aberto), nomeDe);
      } else {
        // Toolbar: filtro por cliente + novo processo.
        var opCli = [{ v: "", t: "Todos os clientes" }];
        for (i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });
        var toolbar = '<div class="toolbar">' +
          UI.sel("soc-f-cli", opCli, this._filtroCliente) +
          (podeCriar ? '<button class="btn primary" data-acao="novoProcesso">' + UI.icone("plus", 16) + ' Novo processo</button>' : "") +
          "</div>";

        var linhas = procs.filter(function (p) { return !self._filtroCliente || p.clienteId === self._filtroCliente; });
        linhas = Util.ordenaPor(linhas, "abertoEm", true); // mais recentes primeiro
        var rows = linhas.map(function (p) {
          var pg = progresso(p);
          return { _cli: nomeDe(p.clienteId), _tipo: p.tipo, descricao: p.descricao, _prog: pg.feitas + "/" + pg.total, _st: p.status, abertoEm: p.abertoEm, _p: p };
        });
        var cols = [
          { k: "_cli", label: "Cliente", fmt: function (v) { return Util.esc(v); } },
          { k: "_tipo", label: "Tipo", fmt: function (v) { return tipoBadge(v); } },
          { k: "descricao", label: "Descrição", fmt: function (v) { return Util.esc(v || "—"); } },
          { k: "_prog", label: "Progresso", cls: "ctr", fmt: function (v) { return '<span class="chip">' + Util.esc(v) + " etapas</span>"; } },
          { k: "_st", label: "Status", fmt: function (v) { return statusBadge(v); } },
          { k: "abertoEm", label: "Aberto em", fmt: function (v) { return '<span style="white-space:nowrap">' + Util.esc(Util.brData(v)) + "</span>"; } },
          { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) {
            var out = '<button class="btn sm" data-acao="abrir:' + Util.esc(row._p.id) + '">Abrir</button> ';
            out += '<button class="btn sm" data-acao="imprimir:' + Util.esc(row._p.id) + '">🖨</button>';
            if (Auth.pode("societario", "editar")) out += ' <button class="btn sm" data-acao="editarProcesso:' + Util.esc(row._p.id) + '">Editar</button>';
            return out;
          } }
        ];
        var tbl = UI.tabela(cols, rows, { vazio: "Nenhum processo societário. Use “Novo processo”." });
        cardA = '<div class="card"><div class="card-hd"><b>Processos societários</b>' +
          '<span class="chip">' + linhas.length + ' processo(s)</span></div>' +
          '<div class="card-bd">' + toolbar + tbl + "</div></div>";
      }

      // ---- Card B: alvarás e licenças (vencimentos) ----
      var alvOrd = Util.ordenaPor(alvarasVis, "validade"); // mais próximos de vencer primeiro
      var colsAl = [
        { k: "clienteId", label: "Cliente", fmt: function (v) { return Util.esc(nomeDe(v)); } },
        { k: "tipo", label: "Tipo", fmt: function (v) { return Util.esc(rotuloAlvara(v)); } },
        { k: "orgao", label: "Órgão", fmt: function (v) { return Util.esc(v || "—"); } },
        { k: "numero", label: "Número", fmt: function (v) { return Util.esc(v || "—"); } },
        { k: "validade", label: "Validade", fmt: function (v, row) { return '<span style="white-space:nowrap">' + Util.esc(Util.brData(v)) + "</span> " + alvaraBadge(row); } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) {
          if (!Auth.pode("societario", "editar")) return "";
          return '<button class="btn sm" data-acao="editarAlvara:' + Util.esc(row.id) + '">Editar</button>';
        } }
      ];
      var tblAl = UI.tabela(colsAl, alvOrd, { vazio: "Nenhum alvará/licença registrado." });
      var cardB = '<div class="card"><div class="card-hd"><b>Alvarás e licenças (vencimentos)</b>' +
        (podeCriar ? '<button class="btn sm green" data-acao="novoAlvara">' + UI.icone("plus", 14) + ' Registrar alvará</button>' : "") +
        '</div><div class="card-bd">' + tblAl + "</div></div>";

      return '<div class="page-hd"><div><h1>Societário / Legalização</h1>' +
        '<div class="sub">Abertura, alteração, baixa e transformação + controle de vencimento de alvarás e licenças.</div></div></div>' +
        kpis + cardA + cardB;
    },

    // HTML do detalhe (checklist de etapas por órgão) do processo aberto.
    _detalheHtml: function (proc, nomeDe) {
      if (!proc) { this._aberto = null; return '<div class="card"><div class="card-bd"><div class="empty">Processo não encontrado.</div></div></div>'; }
      var podeEditar = Auth.pode("societario", "editar");
      var podeExcluir = Auth.pode("societario", "excluir");
      var pg = progresso(proc);
      var et = proc.etapas || [], i, linhas = "";

      if (!et.length) {
        linhas = '<div class="empty">Sem etapas. ' + (podeEditar ? "Use “+ Etapa” para montar o checklist." : "") + "</div>";
      } else {
        var trs = et.map(function (e) {
          var chk = '<input type="checkbox" data-acao="marcarEtapa:' + Util.esc(proc.id) + "|" + Util.esc(e.id) + '"' + (e.feito ? " checked" : "") + (podeEditar ? "" : " disabled") + ">";
          var taxa = (Number(e.taxa) > 0) ? Util.esc(Util.brMoeda(e.taxa)) : "—";
          var proto = e.protocolo ? Util.esc(e.protocolo) : "—";
          var prazo = e.prazo ? (Util.esc(Util.brData(e.prazo)) + prazoEtapaBadge(e)) : "—";
          var feitoTxt = e.feito ? ('<span class="ok">✓ ' + Util.esc(e.feitoEm ? Util.brData(e.feitoEm) : "") + "</span>") : "—";
          var acoes = "";
          if (podeEditar) acoes += '<button class="btn sm" data-acao="editarEtapa:' + Util.esc(proc.id) + "|" + Util.esc(e.id) + '">Editar</button> ';
          if (podeExcluir) acoes += '<button class="btn sm danger" data-acao="removerEtapa:' + Util.esc(proc.id) + "|" + Util.esc(e.id) + '">✕</button>';
          return "<tr><td class='ctr'>" + chk + "</td><td>" + Util.esc(e.orgao || "—") + "</td><td>" + Util.esc(e.titulo || "—") +
            "</td><td>" + prazo + "</td><td class='num'>" + taxa + "</td><td>" + proto + "</td><td>" + feitoTxt +
            "</td><td class='ctr'>" + acoes + "</td></tr>";
        }).join("");
        linhas = '<div class="tbl-wrap"><table class="tbl"><thead><tr><th class="ctr">✓</th><th>Órgão</th><th>Etapa</th><th>Prazo</th><th>Taxa</th><th>Protocolo</th><th>Concluída</th><th class="ctr">Ações</th></tr></thead><tbody>' +
          trs + "</tbody></table></div>";
      }

      var barra = '<div class="toolbar">' +
        '<button class="btn sm" data-acao="voltar">← Voltar à lista</button>' +
        '<button class="btn sm" data-acao="imprimir:' + Util.esc(proc.id) + '">🖨 Comprovante</button>' +
        (podeEditar ? '<button class="btn sm green" data-acao="adicionarEtapa:' + Util.esc(proc.id) + '">' + UI.icone("plus", 14) + ' Etapa</button>' : "") +
        (podeEditar ? '<button class="btn sm" data-acao="editarProcesso:' + Util.esc(proc.id) + '">Editar dados</button>' : "") +
        (podeExcluir ? '<button class="btn sm danger" data-acao="excluirProcesso:' + Util.esc(proc.id) + '">Excluir processo</button>' : "") +
        "</div>";

      var resumo = "<div class='fld-d' style='margin-bottom:10px'><b>" + Util.esc(nomeDe(proc.clienteId)) + "</b> · " +
        Util.esc(tipoInfo(proc.tipo).t) + " · aberto em " + Util.esc(Util.brData(proc.abertoEm)) +
        " · " + pg.feitas + "/" + pg.total + " etapas · " + statusBadge(proc.status) +
        (proc.descricao ? "<br>" + Util.esc(proc.descricao) : "") + "</div>";

      return '<div class="card"><div class="card-hd"><b>Processo — ' + Util.esc(nomeDe(proc.clienteId)) + "</b>" + tipoBadge(proc.tipo) + "</div>" +
        '<div class="card-bd">' + barra + resumo + linhas + "</div></div>";
    },

    // Liga o filtro de cliente (change -> estado + re-render).
    onMount: function () {
      var self = this, e = UI.el("soc-f-cli");
      if (e) e.addEventListener("change", function () { self._filtroCliente = e.value; App.render(); });
    },

    // ---- Navegação de detalhe ----
    abrir: function (id) { this._aberto = id; App.render(); },
    voltar: function () { this._aberto = null; App.render(); },

    // ---- Processos ----

    // Modal compartilhado (novo/editar): cliente + tipo + descrição.
    _modalProcesso: function (proc) {
      var novo = !proc;
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      var corpoTopo;
      if (novo) {
        if (!visiveis.length) { UI.toast("Cadastre um cliente antes de abrir um processo.", "info"); return; }
        var opCli = [{ v: "", t: "— selecione o cliente —" }];
        for (var i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });
        corpoTopo = UI.campo("Cliente", UI.sel("soc-p-cli", opCli, ""));
      } else {
        corpoTopo = UI.campo("Cliente", '<input class="in" value="' + Util.esc(nomeCliente(Store.obter("clientes", proc.clienteId))) + '" disabled>');
      }

      var opTipo = TIPOS.map(function (t) { return { v: t.v, t: t.t }; });
      var opSt = [{ v: "em_andamento", t: "Em andamento" }, { v: "concluido", t: "Concluído" }, { v: "cancelado", t: "Cancelado" }];

      var corpo = corpoTopo +
        UI.campo("Tipo de processo", UI.sel("soc-p-tipo", opTipo, proc ? proc.tipo : "abertura"),
          novo ? "Abertura já vem com o checklist padrão (Junta → Receita → Estado → Prefeitura)." : "") +
        UI.campo("Descrição", UI.inp("soc-p-desc", proc ? proc.descricao : "", "ex.: Abertura LTDA — comércio varejista")) +
        (novo ? "" : UI.campo("Status", UI.sel("soc-p-st", opSt, proc.status)));

      UI.modal(novo ? "Novo processo societário" : "Editar processo", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "primary", onClick: function (fechar) {
          if (!Auth.pode("societario", novo ? "criar" : "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var clienteId = novo ? UI.v("soc-p-cli") : proc.clienteId;
          if (!clienteId) { UI.toast("Selecione o cliente.", "alerta"); return; }
          var tipo = UI.v("soc-p-tipo") || "abertura";
          var desc = UI.v("soc-p-desc");
          var obj;
          if (novo) {
            obj = {
              id: Util.uid("proc"),
              clienteId: clienteId,
              tipo: tipo,
              descricao: desc,
              status: "em_andamento",
              abertoEm: Util.hojeISO(),
              etapas: (tipo === "abertura") ? etapasPadraoAbertura() : [],
              criadoEm: Util.hojeISO()
            };
          } else {
            obj = Util.clone(proc);
            obj.tipo = tipo;
            obj.descricao = desc;
            obj.status = UI.v("soc-p-st") || proc.status;
            // reabrir manualmente não força etapas; concluir manual só se coerente
          }
          Store.salvar("processosSoc", obj); // STORAGE_CHEIO -> ui.js mostra toast
          if (global.Audit) global.Audit.log(novo ? "processo_criar" : "processo_editar", "processosSoc", obj.id);
          UI.toast("Processo salvo.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    novoProcesso: function () {
      if (!Auth.pode("societario", "criar")) { UI.toast("Sem permissão para criar processos.", "erro"); return; }
      this._modalProcesso(null);
    },
    editarProcesso: function (id) {
      if (!Auth.pode("societario", "editar")) { UI.toast("Sem permissão para editar.", "erro"); return; }
      var proc = Store.obter("processosSoc", id);
      if (!proc) { UI.toast("Processo não encontrado.", "erro"); return; }
      this._modalProcesso(proc);
    },
    excluirProcesso: function (id) {
      if (!Auth.pode("societario", "excluir")) { UI.toast("Sem permissão para excluir.", "erro"); return; }
      var proc = Store.obter("processosSoc", id);
      if (!proc) { UI.toast("Processo não encontrado.", "erro"); return; }
      var self = this;
      UI.modal("Excluir processo",
        "<p>Excluir o processo <b>" + Util.esc(tipoInfo(proc.tipo).t) + "</b> de <b>" + Util.esc(nomeCliente(Store.obter("clientes", proc.clienteId))) + "</b>? Esta ação não pode ser desfeita.</p>",
        [{ txt: "Cancelar" }, { txt: "Excluir", classe: "danger", onClick: function (fechar) {
          if (!Auth.pode("societario", "excluir")) { UI.toast("Sem permissão.", "erro"); return; }
          Store.excluir("processosSoc", id);
          if (global.Audit) global.Audit.log("processo_excluir", "processosSoc", id);
          self._aberto = null;
          UI.toast("Processo excluído.", "ok");
          fechar(); App.render();
        } }]);
    },

    // ---- Etapas ----

    // Alterna "feito" da etapa; se todas feitas -> conclui o processo; se
    // desmarcar depois de concluído, volta para "em andamento".
    marcarEtapa: function (arg) {
      if (!Auth.pode("societario", "editar")) { UI.toast("Sem permissão para movimentar etapas.", "erro"); App.render(); return; }
      var p = String(arg || "").split("|"), procId = p[0], etId = p[1];
      var proc = Store.obter("processosSoc", procId);
      if (!proc) { UI.toast("Processo não encontrado.", "erro"); return; }
      var et = proc.etapas || [], alvo = null, i;
      for (i = 0; i < et.length; i++) if (et[i].id === etId) { alvo = et[i]; break; }
      if (!alvo) { UI.toast("Etapa não encontrada.", "erro"); return; }
      alvo.feito = !alvo.feito;
      alvo.feitoEm = alvo.feito ? Util.hojeISO() : null;
      // Status derivado do checklist (não mexe em processo cancelado).
      if (proc.status !== "cancelado") {
        if (todasFeitas(proc)) proc.status = "concluido";
        else if (proc.status === "concluido") proc.status = "em_andamento";
      }
      Store.salvar("processosSoc", proc);
      if (global.Audit) global.Audit.log(alvo.feito ? "etapa_concluir" : "etapa_reabrir", "processosSoc", procId + "|" + etId);
      if (alvo.feito && proc.status === "concluido") UI.toast("Todas as etapas concluídas — processo concluído!", "ok");
      App.render();
    },

    // Modal de etapa (adicionar/editar): órgão + título + prazo + taxa + protocolo.
    _modalEtapa: function (procId, et) {
      var novo = !et;
      var opOrgao = ORGAOS.map(function (o) { return { v: o, t: o }; });
      var corpo =
        '<div class="row">' +
        UI.campo("Órgão", UI.sel("soc-e-orgao", opOrgao, et ? et.orgao : "Junta Comercial")) +
        UI.campo("Prazo (opcional)", UI.inp("soc-e-prazo", et ? et.prazo : "", "", "date")) +
        "</div>" +
        UI.campo("Etapa", UI.inp("soc-e-tit", et ? et.titulo : "", "ex.: Registro do contrato social")) +
        '<div class="row">' +
        UI.campo("Taxa (R$, opcional)", UI.inp("soc-e-taxa", (et && et.taxa) ? Util.brNum(et.taxa, 2) : "", "0,00")) +
        UI.campo("Protocolo (opcional)", UI.inp("soc-e-proto", et ? et.protocolo : "", "nº do protocolo")) +
        "</div>";
      var self = this;
      UI.modal(novo ? "Nova etapa" : "Editar etapa", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "primary", onClick: function (fechar) {
          if (!Auth.pode("societario", "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var proc = Store.obter("processosSoc", procId);
          if (!proc) { UI.toast("Processo não encontrado.", "erro"); return; }
          var tit = UI.v("soc-e-tit");
          if (!tit) { UI.toast("Informe o nome da etapa.", "alerta"); return; }
          var vraw = UI.v("soc-e-taxa");
          if (/^\d+\.\d{1,2}$/.test(vraw)) vraw = vraw.replace(".", ","); // aceita "150.00"
          var taxa = Util.parseBR(vraw);
          if (!proc.etapas) proc.etapas = [];
          if (novo) {
            proc.etapas.push({ id: Util.uid("et"), orgao: UI.v("soc-e-orgao"), titulo: tit, prazo: UI.v("soc-e-prazo"), taxa: taxa, protocolo: UI.v("soc-e-proto"), feito: false, feitoEm: null });
          } else {
            for (var i = 0; i < proc.etapas.length; i++) if (proc.etapas[i].id === et.id) {
              proc.etapas[i].orgao = UI.v("soc-e-orgao");
              proc.etapas[i].titulo = tit;
              proc.etapas[i].prazo = UI.v("soc-e-prazo");
              proc.etapas[i].taxa = taxa;
              proc.etapas[i].protocolo = UI.v("soc-e-proto");
              break;
            }
          }
          // recomputa status derivado (nova etapa pendente pode reabrir concluído)
          if (proc.status !== "cancelado") {
            if (todasFeitas(proc)) proc.status = "concluido";
            else if (proc.status === "concluido") proc.status = "em_andamento";
          }
          Store.salvar("processosSoc", proc);
          if (global.Audit) global.Audit.log(novo ? "etapa_criar" : "etapa_editar", "processosSoc", procId);
          UI.toast("Etapa salva.", "ok");
          self._aberto = procId; // garante permanecer no detalhe
          fechar(); App.render();
        } }
      ]);
    },
    adicionarEtapa: function (procId) {
      if (!Auth.pode("societario", "editar")) { UI.toast("Sem permissão.", "erro"); return; }
      if (!Store.obter("processosSoc", procId)) { UI.toast("Processo não encontrado.", "erro"); return; }
      this._modalEtapa(procId, null);
    },
    editarEtapa: function (arg) {
      if (!Auth.pode("societario", "editar")) { UI.toast("Sem permissão.", "erro"); return; }
      var p = String(arg || "").split("|"), proc = Store.obter("processosSoc", p[0]);
      if (!proc) { UI.toast("Processo não encontrado.", "erro"); return; }
      var et = null, i; for (i = 0; i < (proc.etapas || []).length; i++) if (proc.etapas[i].id === p[1]) { et = proc.etapas[i]; break; }
      if (!et) { UI.toast("Etapa não encontrada.", "erro"); return; }
      this._modalEtapa(p[0], et);
    },
    removerEtapa: function (arg) {
      if (!Auth.pode("societario", "excluir")) { UI.toast("Sem permissão para excluir etapas.", "erro"); return; }
      var p = String(arg || "").split("|"), procId = p[0], etId = p[1];
      var proc = Store.obter("processosSoc", procId);
      if (!proc) { UI.toast("Processo não encontrado.", "erro"); return; }
      var self = this;
      UI.modal("Remover etapa", "<p>Remover esta etapa do checklist?</p>", [
        { txt: "Cancelar" },
        { txt: "Remover", classe: "danger", onClick: function (fechar) {
          if (!Auth.pode("societario", "excluir")) { UI.toast("Sem permissão.", "erro"); return; }
          var out = [], i; for (i = 0; i < (proc.etapas || []).length; i++) if (proc.etapas[i].id !== etId) out.push(proc.etapas[i]);
          proc.etapas = out;
          if (proc.status !== "cancelado") {
            if (todasFeitas(proc)) proc.status = "concluido";
            else if (proc.status === "concluido") proc.status = "em_andamento";
          }
          Store.salvar("processosSoc", proc);
          if (global.Audit) global.Audit.log("etapa_remover", "processosSoc", procId + "|" + etId);
          self._aberto = procId;
          UI.toast("Etapa removida.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    // ---- Alvarás e licenças ----

    _modalAlvara: function (al) {
      var novo = !al;
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      var corpoTopo;
      if (novo) {
        if (!visiveis.length) { UI.toast("Cadastre um cliente antes de registrar alvará.", "info"); return; }
        var opCli = [{ v: "", t: "— selecione o cliente —" }];
        for (var i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });
        corpoTopo = UI.campo("Cliente", UI.sel("soc-a-cli", opCli, ""));
      } else {
        corpoTopo = UI.campo("Cliente", '<input class="in" value="' + Util.esc(nomeCliente(Store.obter("clientes", al.clienteId))) + '" disabled>');
      }
      var opTipo = TIPOS_ALVARA.map(function (t) { return { v: t.v, t: t.t }; });
      var opOrgao = ORGAOS.map(function (o) { return { v: o, t: o }; });
      var corpo = corpoTopo +
        '<div class="row">' +
        UI.campo("Tipo", UI.sel("soc-a-tipo", opTipo, al ? al.tipo : "alvara")) +
        UI.campo("Órgão emissor", UI.sel("soc-a-orgao", opOrgao, al ? al.orgao : "Prefeitura")) +
        "</div>" +
        '<div class="row">' +
        UI.campo("Número", UI.inp("soc-a-num", al ? al.numero : "", "nº do documento")) +
        UI.campo("Validade", UI.inp("soc-a-val", al ? al.validade : "", "", "date")) +
        "</div>" +
        UI.campo("Observações", UI.inp("soc-a-obs", al ? al.obs : "", "ex.: renovação anual"));
      UI.modal(novo ? "Registrar alvará/licença" : "Editar alvará/licença", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "primary", onClick: function (fechar) {
          if (!Auth.pode("societario", novo ? "criar" : "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var clienteId = novo ? UI.v("soc-a-cli") : al.clienteId;
          if (!clienteId) { UI.toast("Selecione o cliente.", "alerta"); return; }
          var validade = UI.v("soc-a-val");
          if (!validade) { UI.toast("Informe a validade.", "alerta"); return; }
          var obj = {
            id: novo ? Util.uid("alv") : al.id,
            clienteId: clienteId,
            tipo: UI.v("soc-a-tipo") || "alvara",
            orgao: UI.v("soc-a-orgao"),
            numero: UI.v("soc-a-num"),
            validade: validade,
            obs: UI.v("soc-a-obs"),
            criadoEm: al ? (al.criadoEm || Util.hojeISO()) : Util.hojeISO()
          };
          Store.salvar("alvaras", obj); // STORAGE_CHEIO -> ui.js mostra toast
          if (global.Audit) global.Audit.log(novo ? "alvara_criar" : "alvara_editar", "alvaras", obj.id);
          UI.toast("Alvará salvo.", "ok");
          fechar(); App.render();
        } }
      ]);
    },
    novoAlvara: function () {
      if (!Auth.pode("societario", "criar")) { UI.toast("Sem permissão para registrar alvará.", "erro"); return; }
      this._modalAlvara(null);
    },
    editarAlvara: function (id) {
      if (!Auth.pode("societario", "editar")) { UI.toast("Sem permissão para editar.", "erro"); return; }
      var al = Store.obter("alvaras", id);
      if (!al) { UI.toast("Alvará não encontrado.", "erro"); return; }
      this._modalAlvara(al);
    },

    // ---- Comprovante de andamento (impresso A4, shell da marca) ----
    imprimir: function (procId) {
      var proc = Store.obter("processosSoc", procId);
      if (!proc) { UI.toast("Processo não encontrado.", "erro"); return; }
      var cli = Store.obter("clientes", proc.clienteId); // null-safe
      var pg = progresso(proc);
      var stTxt = proc.status === "concluido" ? "<span class='ok'>CONCLUÍDO</span>" : (proc.status === "cancelado" ? "<span class='al'>CANCELADO</span>" : "EM ANDAMENTO");

      var corpo =
        "<h2>Dados do processo</h2>" +
        "<table>" +
        "<tr><th style='width:30%'>Escritório</th><td>" + Util.esc(CONFIG.marca.nome) + " · " + Util.esc(CONFIG.marca.slogan) + "</td></tr>" +
        "<tr><th>Cliente</th><td>" + Util.esc(nomeCliente(cli)) + "</td></tr>" +
        (cli && cli.cnpj ? "<tr><th>CNPJ</th><td>" + Util.esc(Util.formataCNPJ(cli.cnpj)) + "</td></tr>" : "") +
        "<tr><th>Tipo</th><td>" + Util.esc(tipoInfo(proc.tipo).t) + "</td></tr>" +
        (proc.descricao ? "<tr><th>Descrição</th><td>" + Util.esc(proc.descricao) + "</td></tr>" : "") +
        "<tr><th>Aberto em</th><td>" + Util.esc(Util.brData(proc.abertoEm)) + "</td></tr>" +
        "<tr><th>Progresso</th><td>" + pg.feitas + " de " + pg.total + " etapa(s)</td></tr>" +
        "<tr><th>Situação</th><td>" + stTxt + "</td></tr>" +
        "</table>" +
        "<h2>Andamento por órgão</h2>" +
        "<table>" +
        "<tr><th style='width:20%'>Órgão</th><th>Etapa</th><th style='width:13%'>Prazo</th><th class='dir' style='width:13%'>Taxa</th><th style='width:16%'>Protocolo</th><th style='width:13%'>Situação</th></tr>";

      var et = proc.etapas || [], i, totalTaxa = 0;
      if (!et.length) {
        corpo += "<tr><td colspan='6'>Sem etapas registradas.</td></tr>";
      } else {
        for (i = 0; i < et.length; i++) {
          var e = et[i];
          totalTaxa += Number(e.taxa) || 0;
          var sit = e.feito ? ("<span class='ok'>concluída" + (e.feitoEm ? " " + Util.brData(e.feitoEm) : "") + "</span>") : "pendente";
          corpo += "<tr><td>" + Util.esc(e.orgao || "—") + "</td><td>" + Util.esc(e.titulo || "—") +
            "</td><td>" + (e.prazo ? Util.esc(Util.brData(e.prazo)) : "—") +
            "</td><td class='dir'>" + (Number(e.taxa) > 0 ? Util.esc(Util.brMoeda(e.taxa)) : "—") +
            "</td><td>" + (e.protocolo ? Util.esc(e.protocolo) : "—") +
            "</td><td>" + sit + "</td></tr>";
        }
        corpo += "<tr class='tot'><td colspan='3'>Total de taxas</td><td class='dir'>" + Util.esc(Util.brMoeda(totalTaxa)) + "</td><td colspan='2'></td></tr>";
      }
      corpo += "</table>";

      App._abrirPrint("Processo Societário", corpo);
      if (global.Audit) global.Audit.log("processo_imprimir", "processosSoc", proc.id);
    }
  });
})(window);
