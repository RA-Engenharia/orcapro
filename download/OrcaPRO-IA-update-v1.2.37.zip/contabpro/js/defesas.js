/* =====================================================================
 * defesas.js — Processos Administrativos e Defesas (seção 3.12).
 * PRAZO PROCESSUAL != prazo de obrigação: contagem própria a partir da
 * ciência do auto de infração, com ALERTA AGRESSIVO. É o prazo que, se
 * passar, não volta. Registrado como id "defesas" (bate com CONFIG.modulos
 * e Auth.pode("defesas", ...)).
 * Coleção nova "defesas" = { id, clienteId, orgao, autoInfracao, tributo,
 *   valor, cienciaEm(ISO), prazoDefesaDias(number, default 30),
 *   faseAtual, resultado?, pecas:[{id,titulo,quando}], obs, criadoEm }.
 * ES5 estrito (var/function/concat). Orquestra Store + Auth + UI + App.
 * ===================================================================== */
(function (global) {
  "use strict";
  var Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  // ---------- Tabelas de domínio ----------
  var ORGAOS = [
    { v: "RFB", t: "Receita Federal (RFB)" },
    { v: "PGFN", t: "Procuradoria (PGFN)" },
    { v: "SEFAZ", t: "Fazenda Estadual (SEFAZ)" },
    { v: "prefeitura", t: "Prefeitura/Município" },
    { v: "INSS", t: "INSS/Previdenciário" }
  ];
  // Fases em ordem — o índice define a progressão de avancarFase.
  var FASES = [
    { v: "ciencia", t: "Ciência", cor: "cinza" },
    { v: "analise", t: "Análise/estratégia", cor: "azul" },
    { v: "defesa", t: "Defesa protocolada", cor: "roxo" },
    { v: "julgamento_1a", t: "Julgamento 1ª instância", cor: "amber" },
    { v: "recurso", t: "Recurso", cor: "amber" },
    { v: "encerrado", t: "Encerrado", cor: "verde" }
  ];
  var RESULTADOS = [
    { v: "improcedente", t: "Improcedente (autuação cancelada)" },
    { v: "parcial", t: "Parcialmente procedente" },
    { v: "procedente", t: "Procedente (autuação mantida)" }
  ];
  // Fases em que o prazo de DEFESA ainda corre (antes de protocolar).
  // 'defesa' = defesa JÁ protocolada -> prazo cumprido, não alerta falso "VENCEU".
  var FASES_PRAZO = { ciencia: 1, analise: 1 };

  // ---------- Helpers puros (closure do módulo) ----------
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(cliente excluído)"; }

  function orgaoLabel(v) { for (var i = 0; i < ORGAOS.length; i++) if (ORGAOS[i].v === v) return ORGAOS[i].t; return v || "—"; }
  function faseObj(v) { for (var i = 0; i < FASES.length; i++) if (FASES[i].v === v) return FASES[i]; return null; }
  function faseIdx(v) { for (var i = 0; i < FASES.length; i++) if (FASES[i].v === v) return i; return 0; }
  function resultadoLabel(v) { for (var i = 0; i < RESULTADOS.length; i++) if (RESULTADOS[i].v === v) return RESULTADOS[i].t; return v || "—"; }

  function encerrada(d) { return d.faseAtual === "encerrado"; }
  // Resultado favorável ao cliente (autuação derrubada total ou parcialmente).
  function favoravel(d) { return d.resultado === "improcedente" || d.resultado === "parcial"; }

  // Prazo processual: data-limite da defesa e dias restantes (própria contagem).
  function prazoDefesaDias(d) { var n = Number(d.prazoDefesaDias); return (n > 0) ? n : 30; }
  function prazoFinal(d) { return d.cienciaEm ? Util.somaDias(d.cienciaEm, prazoDefesaDias(d)) : null; }
  function diasRestantes(d) { var pf = prazoFinal(d); return pf ? Util.diasAte(pf) : null; }
  // O prazo de defesa ainda corre nesta fase?
  function prazoCorrendo(d) { return !!FASES_PRAZO[d.faseAtual]; }

  // Valor: aceita "1.500,00" e "1500.00" (regex vira vírgula) antes do parseBR.
  function parseValor(s) {
    if (typeof s === "number") return s;
    s = String(s == null ? "" : s).trim();
    if (/^\d+\.\d{1,2}$/.test(s)) s = s.replace(".", ",");
    return Util.parseBR(s);
  }

  // Badge do prazo de defesa: vencido / <=5d (crítico) / <=15d (atenção).
  // Só alerta enquanto o prazo corre (fase de ciência/análise/defesa).
  function prazoCel(d) {
    var pf = prazoFinal(d);
    if (!pf) return "—";
    var txt = '<span style="white-space:nowrap">' + Util.esc(Util.brData(pf)) + "</span>";
    if (!prazoCorrendo(d)) return txt;
    var r = diasRestantes(d);
    if (r == null) return txt;
    if (r < 0) return txt + " " + UI.badge("VENCEU", "vermelho");
    if (r <= 5) return txt + " " + UI.badge(r + "d!", "vermelho");
    if (r <= 15) return txt + " " + UI.badge("em " + r + "d", "amber");
    return txt;
  }

  // Badge da fase; encerrado colore pelo resultado.
  function faseCel(d) {
    if (d.faseAtual === "encerrado") {
      if (d.resultado === "improcedente") return UI.badge("Encerrado — improcedente", "verde");
      if (d.resultado === "parcial") return UI.badge("Encerrado — parcial", "amber");
      if (d.resultado === "procedente") return UI.badge("Encerrado — procedente", "vermelho");
      return UI.badge("Encerrado", "cinza");
    }
    var fo = faseObj(d.faseAtual);
    return UI.badge(fo ? fo.t : (d.faseAtual || "—"), fo ? fo.cor : "cinza");
  }

  // Prazo crítico? (corre e vence em <=5 dias, inclusive já vencido).
  function critico(d) {
    if (!prazoCorrendo(d)) return false;
    var r = diasRestantes(d);
    return r != null && r <= 5;
  }

  // ---------- View ----------
  global.DefesasView = App.registrar({
    id: "defesas",
    titulo: "Defesas & Processos",

    render: function () {
      if (!this._filtros) this._filtros = { cliente: "", orgao: "", fase: "" };
      var f = this._filtros;
      if (f.cliente && !Store.obter("clientes", f.cliente)) f.cliente = "";

      // Clientes visíveis (respeita carteira do analista).
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      var setVis = {}, nomeCli = {}, i;
      for (i = 0; i < visiveis.length; i++) { setVis[visiveis[i].id] = 1; nomeCli[visiveis[i].id] = nomeCliente(visiveis[i]); }
      function nomeDe(id) { return nomeCli[id] || "(cliente excluído)"; }

      // Defesas só de clientes visíveis.
      var todas = Store.listar("defesas"), vis = [];
      for (i = 0; i < todas.length; i++) if (setVis[todas[i].clienteId]) vis.push(todas[i]);

      // Aplica filtros.
      var linhas = vis.filter(function (d) {
        if (f.cliente && d.clienteId !== f.cliente) return false;
        if (f.orgao && d.orgao !== f.orgao) return false;
        if (f.fase && d.faseAtual !== f.fase) return false;
        return true;
      });

      // ---- KPIs (sobre o conjunto filtrado) ----
      var nAbertas = 0, nCriticos = 0, valorDisc = 0, nFavoraveis = 0;
      linhas.forEach(function (d) {
        if (!encerrada(d)) { nAbertas++; valorDisc += Number(d.valor) || 0; }
        if (critico(d)) nCriticos++;
        if (encerrada(d) && favoravel(d)) nFavoraveis++;
      });

      var kpis = '<div class="grid-kpi">' +
        '<div class="kpi"><div class="n">' + nAbertas + '</div><div class="l">Defesas em aberto</div></div>' +
        '<div class="kpi ' + (nCriticos ? "al" : "") + '"><div class="n">' + nCriticos + '</div><div class="l">Prazos vencendo (≤5 dias)</div></div>' +
        '<div class="kpi"><div class="n">' + Util.brMoeda(valorDisc) + '</div><div class="l">Valor em discussão</div></div>' +
        '<div class="kpi ' + (nFavoraveis ? "ok" : "") + '"><div class="n">' + nFavoraveis + '</div><div class="l">Encerradas favoráveis</div></div>' +
        "</div>";

      // ---- Toolbar: filtros + nova ----
      var opCli = [{ v: "", t: "Todos os clientes" }];
      for (i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });
      var opOrgao = [{ v: "", t: "Todos os órgãos" }];
      for (i = 0; i < ORGAOS.length; i++) opOrgao.push(ORGAOS[i]);
      var opFase = [{ v: "", t: "Todas as fases" }];
      for (i = 0; i < FASES.length; i++) opFase.push({ v: FASES[i].v, t: FASES[i].t });

      var podeCriar = Auth.pode("defesas", "criar");
      var toolbar = '<div class="toolbar">' +
        UI.sel("def-f-cli", opCli, f.cliente) +
        UI.sel("def-f-orgao", opOrgao, f.orgao) +
        UI.sel("def-f-fase", opFase, f.fase) +
        (podeCriar ? '<button class="btn primary" data-acao="novo">' + UI.icone("plus", 16) + ' Novo processo</button>' : "") +
        "</div>";

      // ---- Card de DESTAQUE: prazos críticos (o que não pode passar) ----
      var criticos = linhas.filter(function (d) { return critico(d); });
      criticos.sort(function (a, b) {
        var ra = diasRestantes(a), rb = diasRestantes(b);
        if (ra == null) ra = 9e9; if (rb == null) rb = 9e9;
        return ra - rb;
      });
      var alertaHtml = "";
      if (criticos.length) {
        var itens = criticos.map(function (d) {
          var r = diasRestantes(d);
          var txt = (r < 0) ? ("VENCEU há " + (-r) + " dia(s)") : (r === 0 ? "VENCE HOJE" : ("faltam " + r + " dia(s)"));
          return '<div class="def-crit-row">' +
            '<b>' + Util.esc(nomeDe(d.clienteId)) + '</b>' +
            ' — ' + Util.esc(orgaoLabel(d.orgao)) +
            (d.autoInfracao ? ' · auto ' + Util.esc(d.autoInfracao) : "") +
            ' · prazo ' + Util.esc(Util.brData(prazoFinal(d))) +
            ' <span class="def-crit-tag">' + Util.esc(txt) + '</span>' +
            ' <button class="btn sm" data-acao="editar:' + Util.esc(d.id) + '">Abrir</button>' +
            "</div>";
        }).join("");
        alertaHtml =
          '<div class="card" style="border:2px solid ' + global.CONFIG.marca.corAlerta + ';background:rgba(220,38,38,.06)">' +
          '<div class="card-hd"><b style="color:' + global.CONFIG.marca.corAlerta + '">⚠ Prazos de defesa críticos</b>' +
          '<span class="chip">' + criticos.length + ' processo(s)</span></div>' +
          '<div class="card-bd">' + itens + "</div></div>";
      }

      // ---- Tabela principal ----
      var ordenadas = linhas.slice().sort(function (a, b) {
        // abertas antes de encerradas; dentro, por dias restantes (mais urgente primeiro)
        var ea = encerrada(a) ? 1 : 0, eb = encerrada(b) ? 1 : 0;
        if (ea !== eb) return ea - eb;
        var ra = diasRestantes(a), rb = diasRestantes(b);
        if (ra == null) ra = 9e9; if (rb == null) rb = 9e9;
        return ra - rb;
      });

      var rows = ordenadas.map(function (d) {
        return { _cli: nomeDe(d.clienteId), _d: d };
      });
      var cols = [
        { k: "_cli", label: "Cliente", fmt: function (v) { return Util.esc(v); } },
        { k: "_d", label: "Órgão", fmt: function (v, row) { return UI.badge(row._d.orgao || "—", "azul"); } },
        { k: "_d", label: "Auto de infração", fmt: function (v, row) { return Util.esc(row._d.autoInfracao || "—"); } },
        { k: "_d", label: "Valor", cls: "dir", fmt: function (v, row) { return Util.esc(Util.brMoeda(row._d.valor)); } },
        { k: "_d", label: "Ciência", fmt: function (v, row) { return '<span style="white-space:nowrap">' + Util.esc(Util.brData(row._d.cienciaEm)) + "</span>"; } },
        { k: "_d", label: "Prazo defesa", fmt: function (v, row) { return prazoCel(row._d); } },
        { k: "_d", label: "Fase", fmt: function (v, row) { return faseCel(row._d); } },
        { k: "_d", label: "Ações", cls: "ctr", fmt: function (v, row) {
          var d = row._d, out = "";
          out += '<button class="btn sm" data-acao="editar:' + Util.esc(d.id) + '">Editar</button> ';
          if (!encerrada(d) && Auth.pode("defesas", "editar")) {
            out += '<button class="btn sm green" data-acao="avancarFase:' + Util.esc(d.id) + '">Avançar ▸</button> ';
            out += '<button class="btn sm" data-acao="addPeca:' + Util.esc(d.id) + '">+ Peça</button> ';
          }
          out += '<button class="btn sm" data-acao="imprimir:' + Util.esc(d.id) + '">🖨</button>';
          if (Auth.pode("defesas", "excluir")) out += ' <button class="btn sm danger" data-acao="excluir:' + Util.esc(d.id) + '">✕</button>';
          return out;
        } }
      ];
      var tbl = UI.tabela(cols, rows, { vazio: "Nenhum processo administrativo para os filtros atuais." });

      var aviso = podeCriar ? "" : '<span class="chip">Somente leitura: seu perfil não registra processos</span>';

      return '<div class="page-hd"><div><h1>Processos Administrativos e Defesas</h1>' +
        '<div class="sub">Prazo processual tem contagem própria e alerta agressivo — se passar, não volta.</div></div>' +
        '<div>' + aviso + "</div></div>" +
        kpis + toolbar + alertaHtml +
        '<div class="card"><div class="card-hd"><b>Processos e defesas</b>' +
        '<span class="chip">' + linhas.length + ' item(ns)</span></div>' +
        '<div class="card-bd">' + tbl + "</div></div>";
    },

    // Liga os filtros (change -> guarda estado + re-render).
    onMount: function () {
      var self = this, map = [["def-f-cli", "cliente"], ["def-f-orgao", "orgao"], ["def-f-fase", "fase"]];
      map.forEach(function (par) {
        var e = UI.el(par[0]);
        if (e) e.addEventListener("change", function () { self._filtros[par[1]] = e.value; App.render(); });
      });
    },

    // ---- Ações ----
    novo: function () {
      if (!Auth.pode("defesas", "criar")) { UI.toast("Sem permissão para criar processos.", "erro"); return; }
      this._modal(null);
    },

    editar: function (id) {
      if (!Auth.pode("defesas", "editar")) { UI.toast("Sem permissão para editar processos.", "erro"); return; }
      var d = Store.obter("defesas", id);
      if (!d) { UI.toast("Processo não encontrado.", "erro"); return; }
      this._modal(d);
    },

    // Modal compartilhado (d=null -> novo). Cadastro do processo administrativo.
    _modal: function (d) {
      var novo = !d;
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      if (novo && !visiveis.length) { UI.toast("Cadastre um cliente antes de registrar um processo.", "info"); return; }

      var opCli = [{ v: "", t: "— selecione o cliente —" }];
      for (var i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });
      var opFase = [];
      for (i = 0; i < FASES.length; i++) opFase.push({ v: FASES[i].v, t: FASES[i].t });
      var opRes = [{ v: "", t: "— sem resultado —" }];
      for (i = 0; i < RESULTADOS.length; i++) opRes.push(RESULTADOS[i]);

      var hoje = Util.hojeISO();
      var corpo =
        UI.campo("Cliente", UI.sel("def-cli", opCli, d ? d.clienteId : "")) +
        '<div class="row">' +
        UI.campo("Órgão", UI.sel("def-orgao", ORGAOS, d ? d.orgao : "RFB")) +
        UI.campo("Auto de infração / processo", UI.inp("def-auto", d ? d.autoInfracao : "", "nº do auto/processo")) +
        "</div>" +
        '<div class="row">' +
        UI.campo("Tributo", UI.inp("def-tributo", d ? d.tributo : "", "ex.: IRPJ, ICMS, ISS")) +
        UI.campo("Valor autuado (R$)", UI.inp("def-valor", d ? Util.brNum(d.valor, 2) : "", "0,00")) +
        "</div>" +
        '<div class="row">' +
        UI.campo("Ciência em", UI.inp("def-ciencia", d ? d.cienciaEm : hoje, "", "date"), "início da contagem do prazo") +
        UI.campo("Prazo de defesa (dias)", UI.inp("def-prazodias", d ? prazoDefesaDias(d) : 30, "30", "number"), "prazo processual, não de obrigação") +
        "</div>" +
        '<div class="row">' +
        UI.campo("Fase atual", UI.sel("def-fase", opFase, d ? d.faseAtual : "ciencia")) +
        UI.campo("Resultado (se encerrado)", UI.sel("def-res", opRes, d ? (d.resultado || "") : "")) +
        "</div>" +
        UI.campo("Observações", UI.inp("def-obs", d ? d.obs : "", "estratégia, fundamentos, protocolo…"));

      var self = this;
      UI.modal(novo ? "Novo processo administrativo" : "Editar processo", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "primary", onClick: function (fechar) {
          if (!Auth.pode("defesas", novo ? "criar" : "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var clienteId = UI.v("def-cli");
          if (!clienteId) { UI.toast("Selecione o cliente.", "alerta"); return; }
          var cienciaEm = UI.v("def-ciencia");
          if (!cienciaEm) { UI.toast("Informe a data de ciência (início do prazo).", "alerta"); return; }
          var pd = parseInt(UI.v("def-prazodias"), 10); if (!(pd > 0)) pd = 30;
          var fase = UI.v("def-fase");
          var resultado = UI.v("def-res");
          if (fase !== "encerrado") resultado = ""; // resultado só faz sentido encerrado

          var obj = {
            id: d ? d.id : Util.uid("def"),
            clienteId: clienteId,
            orgao: UI.v("def-orgao"),
            autoInfracao: UI.v("def-auto"),
            tributo: UI.v("def-tributo"),
            valor: parseValor(UI.v("def-valor")),
            cienciaEm: cienciaEm,
            prazoDefesaDias: pd,
            faseAtual: fase,
            resultado: resultado || undefined,
            pecas: d ? (d.pecas || []) : [],
            obs: UI.v("def-obs"),
            criadoEm: d ? (d.criadoEm || Util.hojeISO()) : Util.hojeISO()
          };
          Store.salvar("defesas", obj); // STORAGE_CHEIO -> ui.js mostra toast
          if (global.Audit) global.Audit.log(novo ? "criou_defesa" : "editou_defesa", "defesas", obj.id);
          UI.toast("Processo salvo.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    // Avança para a próxima fase; ao encerrar, pede o resultado.
    avancarFase: function (id) {
      if (!Auth.pode("defesas", "editar")) { UI.toast("Sem permissão para movimentar processos.", "erro"); return; }
      var d = Store.obter("defesas", id);
      if (!d) { UI.toast("Processo não encontrado.", "erro"); return; }
      var idx = faseIdx(d.faseAtual);
      if (idx >= FASES.length - 1) { UI.toast("Processo já está encerrado.", "info"); return; }
      var prox = FASES[idx + 1];

      if (prox.v === "encerrado") {
        var opRes = [{ v: "", t: "— selecione o resultado —" }];
        for (var i = 0; i < RESULTADOS.length; i++) opRes.push(RESULTADOS[i]);
        UI.modal("Encerrar processo",
          '<p>Encerrando o processo de <b>' + Util.esc(nomeCliente(Store.obter("clientes", d.clienteId))) + '</b>.</p>' +
          UI.campo("Resultado do julgamento", UI.sel("def-enc-res", opRes, "")),
          [{ txt: "Cancelar" }, { txt: "Encerrar", classe: "primary", onClick: function (fechar) {
            if (!Auth.pode("defesas", "editar")) { UI.toast("Sem permissão.", "erro"); return; }
            var res = UI.v("def-enc-res");
            if (!res) { UI.toast("Selecione o resultado para encerrar.", "alerta"); return; }
            var atual = Store.obter("defesas", id);
            if (!atual) { UI.toast("Processo não encontrado.", "erro"); return; }
            atual.faseAtual = "encerrado";
            atual.resultado = res;
            Store.salvar("defesas", atual);
            if (global.Audit) global.Audit.log("encerrou_defesa", "defesas", atual.id);
            UI.toast("Processo encerrado (" + resultadoLabel(res) + ").", "ok");
            fechar(); App.render();
          } }]);
        return;
      }

      d.faseAtual = prox.v;
      Store.salvar("defesas", d);
      if (global.Audit) global.Audit.log("avancou_fase_defesa", "defesas", d.id);
      UI.toast("Fase avançada para: " + prox.t + ".", "ok");
      App.render();
    },

    // Registra uma peça processual (título + data) no array pecas.
    addPeca: function (id) {
      if (!Auth.pode("defesas", "editar")) { UI.toast("Sem permissão para registrar peças.", "erro"); return; }
      var d = Store.obter("defesas", id);
      if (!d) { UI.toast("Processo não encontrado.", "erro"); return; }
      var corpo =
        UI.campo("Título da peça", UI.inp("def-peca-tit", "", "ex.: Impugnação, Recurso Voluntário, Diligência")) +
        UI.campo("Data", UI.inp("def-peca-data", Util.hojeISO(), "", "date"));
      UI.modal("Registrar peça — " + orgaoLabel(d.orgao), corpo, [
        { txt: "Cancelar" },
        { txt: "Registrar", classe: "primary", onClick: function (fechar) {
          if (!Auth.pode("defesas", "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var tit = UI.v("def-peca-tit");
          if (!tit) { UI.toast("Informe o título da peça.", "alerta"); return; }
          var atual = Store.obter("defesas", id);
          if (!atual) { UI.toast("Processo não encontrado.", "erro"); return; }
          if (!atual.pecas) atual.pecas = [];
          atual.pecas.push({ id: Util.uid("pec"), titulo: tit, quando: UI.v("def-peca-data") || Util.hojeISO() });
          Store.salvar("defesas", atual);
          if (global.Audit) global.Audit.log("registrou_peca_defesa", "defesas", atual.id);
          UI.toast("Peça registrada.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    excluir: function (id) {
      if (!Auth.pode("defesas", "excluir")) { UI.toast("Sem permissão para excluir processos.", "erro"); return; }
      var d = Store.obter("defesas", id);
      if (!d) { UI.toast("Processo não encontrado.", "erro"); return; }
      var cli = Store.obter("clientes", d.clienteId);
      UI.modal("Excluir processo",
        "<p>Excluir o processo <b>" + Util.esc(orgaoLabel(d.orgao)) + "</b>" +
        (d.autoInfracao ? " (auto " + Util.esc(d.autoInfracao) + ")" : "") +
        " de <b>" + Util.esc(nomeCliente(cli)) + "</b>?</p>" +
        '<div class="fld-d">A perda do histórico e das peças registradas é irreversível.</div>',
        [{ txt: "Cancelar" }, { txt: "Excluir", classe: "danger", onClick: function (fechar) {
          if (!Auth.pode("defesas", "excluir")) { UI.toast("Sem permissão.", "erro"); return; }
          Store.excluir("defesas", id);
          if (global.Audit) global.Audit.log("excluiu_defesa", "defesas", id);
          UI.toast("Processo excluído.", "ok");
          fechar(); App.render();
        } }]);
    },

    // Dossiê impresso (A4, shell da marca) — dados + prazo + fases + peças.
    imprimir: function (id) {
      var d = Store.obter("defesas", id);
      if (!d) { UI.toast("Processo não encontrado.", "erro"); return; }
      var cli = Store.obter("clientes", d.clienteId); // null-safe

      var pf = prazoFinal(d), prazoTxt;
      if (!pf) prazoTxt = "—";
      else if (prazoCorrendo(d)) {
        var r = diasRestantes(d);
        if (r == null) prazoTxt = Util.esc(Util.brData(pf));
        else if (r < 0) prazoTxt = '<span class="al">' + Util.esc(Util.brData(pf)) + " — VENCEU há " + (-r) + " dia(s)</span>";
        else if (r <= 5) prazoTxt = '<span class="al">' + Util.esc(Util.brData(pf)) + " — faltam " + r + " dia(s)</span>";
        else prazoTxt = Util.esc(Util.brData(pf)) + " (faltam " + r + " dias)";
      } else prazoTxt = Util.esc(Util.brData(pf)) + " (prazo de defesa já encerrado nesta fase)";

      var faseTxt = (faseObj(d.faseAtual) || {}).t || d.faseAtual || "—";
      if (d.faseAtual === "encerrado" && d.resultado) faseTxt += " · " + resultadoLabel(d.resultado);

      var dados =
        "<h2>Dossiê do processo administrativo</h2>" +
        "<table>" +
        "<tr><th style='width:30%'>Escritório</th><td>" + Util.esc(global.CONFIG.marca.nome) + " · " + Util.esc(global.CONFIG.marca.slogan) + "</td></tr>" +
        "<tr><th>Cliente</th><td>" + Util.esc(nomeCliente(cli)) + "</td></tr>" +
        (cli && cli.cnpj ? "<tr><th>CNPJ</th><td>" + Util.esc(Util.formataCNPJ(cli.cnpj)) + "</td></tr>" : "") +
        "<tr><th>Órgão</th><td>" + Util.esc(orgaoLabel(d.orgao)) + "</td></tr>" +
        "<tr><th>Auto de infração</th><td>" + Util.esc(d.autoInfracao || "—") + "</td></tr>" +
        "<tr><th>Tributo</th><td>" + Util.esc(d.tributo || "—") + "</td></tr>" +
        "<tr><th>Valor autuado</th><td class='dir'>" + Util.esc(Util.brMoeda(d.valor)) + "</td></tr>" +
        "<tr><th>Ciência em</th><td>" + Util.esc(Util.brData(d.cienciaEm)) + "</td></tr>" +
        "<tr><th>Prazo de defesa</th><td>" + prazoDefesaDias(d) + " dia(s) · limite " + prazoTxt + "</td></tr>" +
        "<tr><th>Fase atual</th><td>" + Util.esc(faseTxt) + "</td></tr>" +
        (d.obs ? "<tr><th>Observações</th><td>" + Util.esc(d.obs) + "</td></tr>" : "") +
        "</table>";

      // Trilha de fases
      var trilha = "<h2>Andamento (fases)</h2><table><tr><th style='width:8%'>#</th><th>Fase</th><th>Situação</th></tr>";
      var atualIdx = faseIdx(d.faseAtual);
      for (var i = 0; i < FASES.length; i++) {
        var sit = (i < atualIdx) ? "concluída" : (i === atualIdx ? "atual" : "pendente");
        var cls = (i === atualIdx) ? "ok" : "";
        trilha += "<tr><td>" + (i + 1) + "</td><td>" + Util.esc(FASES[i].t) + "</td><td class='" + cls + "'>" + Util.esc(sit) + "</td></tr>";
      }
      trilha += "</table>";

      // Peças processuais
      var pecas = d.pecas || [], pecasHtml;
      if (!pecas.length) pecasHtml = "<h2>Peças processuais</h2><p style='color:#64748b'>Nenhuma peça registrada.</p>";
      else {
        pecasHtml = "<h2>Peças processuais</h2><table><tr><th style='width:20%'>Data</th><th>Peça</th></tr>";
        for (i = 0; i < pecas.length; i++) pecasHtml += "<tr><td>" + Util.esc(Util.brData(pecas[i].quando)) + "</td><td>" + Util.esc(pecas[i].titulo) + "</td></tr>";
        pecasHtml += "</table>";
      }

      var rodape = "<p style='margin-top:16px;color:#64748b;font-size:11px'>Documento de controle interno do escritório. O prazo de defesa é processual e não se confunde com prazos de obrigações acessórias.</p>";

      App._abrirPrint("Processo Administrativo", dados + trilha + pecasHtml + rodape);
      if (global.Audit) global.Audit.log("imprimiu_defesa", "defesas", d.id);
    }
  });
})(window);
