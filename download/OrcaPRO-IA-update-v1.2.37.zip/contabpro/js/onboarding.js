/* =====================================================================
 * onboarding.js — Onboarding de clientes (seção 3.3).
 * Checklist padrão com prazos (D+n), progresso por cliente, diagnóstico
 * de entrada (proteção do escritório) e termo impresso via App._abrirPrint.
 * Coleção: "onboardings" = { id:"ob_"+clienteId, clienteId, criadoEm,
 *   concluido, diagnostico, etapas:[{id,titulo,prazo,feito,feitoEm}] }.
 * ID determinístico ("ob_"+clienteId) => criação idempotente.
 * ES5 estrito (var/function/concat).
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  // ---------- Checklist padrão (seção 3.3) — prazos em D+n a partir de hoje ----------
  var ETAPAS_PADRAO = [
    { id: "agenda",      titulo: "Carga da agenda de obrigações",                                        dias: 1 },
    { id: "boasvindas",  titulo: "Comunicação de boas-vindas",                                           dias: 2 },
    { id: "contrato",    titulo: "Contrato de prestação assinado",                                       dias: 3 },
    { id: "proc_ecac",   titulo: "Procuração e-CAC",                                                     dias: 5 },
    { id: "proc_govbr",  titulo: "Procuração gov.br",                                                    dias: 5 },
    { id: "certificado", titulo: "Certificado digital no cofre",                                         dias: 7 },
    { id: "arquivos",    titulo: "Solicitar arquivos ao contador anterior (SPEDs, folhas, balancetes)",  dias: 7 },
    { id: "diagnostico", titulo: "Diagnóstico inicial (débitos? parcelamentos? malha?)",                 dias: 15 }
  ];

  // ---------- Helpers puros ----------
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(sem nome)"; } // padrão entre telas
  function etapaAtrasada(et) { if (et.feito) return false; var d = Util.diasAte(et.prazo); return d != null && d < 0; }
  function contaFeitas(ob) { var n = 0, i; for (i = 0; i < ob.etapas.length; i++) if (ob.etapas[i].feito) n++; return n; }
  function contaAtrasadas(ob) { var n = 0, i; for (i = 0; i < ob.etapas.length; i++) if (etapaAtrasada(ob.etapas[i])) n++; return n; }
  function todasFeitas(ob) { return contaFeitas(ob) === ob.etapas.length && ob.etapas.length > 0; }

  // Barra de progresso simples (div inline) — verde ao completar.
  function barraProgresso(feitas, total) {
    var pct = total ? Math.round((feitas / total) * 100) : 0;
    var cor = pct >= 100 ? "#16a34a" : "#2e6f9e";
    return '<span style="white-space:nowrap">' + feitas + "/" + total + "</span> " +
      '<div style="display:inline-block;vertical-align:middle;width:110px;height:8px;background:#e2e8f0;border-radius:6px;overflow:hidden;margin-left:6px">' +
      '<div style="height:8px;width:' + pct + '%;background:' + cor + '"></div></div>';
  }

  // ---------- API pública: hook do cadastro de clientes ----------
  // IDEMPOTENTE: se já existe onboarding do cliente, devolve o existente (não duplica).
  global.Onboarding = {
    aoCriarCliente: function (cliente) {
      if (!cliente || !cliente.id) return null;
      var id = "ob_" + cliente.id;
      var existente = Store.obter("onboardings", id);
      if (existente) return existente;
      var hoje = Util.hojeISO();
      var etapas = [], i, ep, feito;
      for (i = 0; i < ETAPAS_PADRAO.length; i++) {
        ep = ETAPAS_PADRAO[i];
        // a agenda é gerada automaticamente pelo cadastro: nasce feita se cliente já está ativo
        feito = (ep.id === "agenda" && cliente.status === "ativo");
        etapas.push({ id: ep.id, titulo: ep.titulo, prazo: Util.somaDias(hoje, ep.dias), feito: feito, feitoEm: feito ? hoje : null });
      }
      var ob = { id: id, clienteId: cliente.id, criadoEm: hoje, concluido: false, diagnostico: "", etapas: etapas };
      Store.salvar("onboardings", ob);
      if (global.Audit) global.Audit.log("onboarding_criado", "onboarding", id);
      return ob;
    },
    // Cliente virou ATIVO depois de criado (prospect -> ativo): a agenda foi gerada
    // pelo cadastro, então a etapa 'agenda' do onboarding é marcada automaticamente.
    aoAtivarCliente: function (cliente) {
      if (!cliente || !cliente.id) return null;
      var ob = Store.obter("onboardings", "ob_" + cliente.id);
      if (!ob || ob.concluido) return ob;
      var mudou = false, i;
      for (i = 0; i < ob.etapas.length; i++) {
        if (ob.etapas[i].id === "agenda" && !ob.etapas[i].feito) { ob.etapas[i].feito = true; ob.etapas[i].feitoEm = Util.hojeISO(); mudou = true; }
      }
      if (mudou) {
        var todas = true; for (i = 0; i < ob.etapas.length; i++) if (!ob.etapas[i].feito) todas = false;
        ob.concluido = todas;
        Store.salvar("onboardings", ob);
        if (global.Audit) global.Audit.log("etapa_onboarding_auto", "onboarding", ob.id);
      }
      return ob;
    }
  };

  // ---------- View ----------
  global.OnboardingView = App.registrar({
    id: "onboarding",
    titulo: "Onboarding",

    render: function () {
      var todos = Store.listar("onboardings");
      // só clientes visíveis (respeita carteira do analista)
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      var mapCli = {}, i;
      for (i = 0; i < visiveis.length; i++) mapCli[visiveis[i].id] = visiveis[i];
      var procs = [];
      for (i = 0; i < todos.length; i++) if (mapCli[todos[i].clienteId]) procs.push(todos[i]);

      // detalhe aberto some se o processo foi excluído/ficou invisível
      if (this._aberto && !Store.obter("onboardings", this._aberto)) this._aberto = null;

      // ---- KPIs ----
      var nAndamento = 0, nAtras = 0, nConc = 0;
      for (i = 0; i < procs.length; i++) {
        if (procs[i].concluido) nConc++; else nAndamento++;
        nAtras += contaAtrasadas(procs[i]);
      }
      var kpis = '<div class="grid-kpi">' +
        '<div class="kpi"><div class="n">' + nAndamento + '</div><div class="l">Em andamento</div></div>' +
        '<div class="kpi ' + (nAtras ? "al" : "") + '"><div class="n">' + nAtras + '</div><div class="l">Etapas atrasadas</div></div>' +
        '<div class="kpi ok"><div class="n">' + nConc + '</div><div class="l">Concluídos</div></div>' +
        "</div>";

      var podeEditar = Auth.pode("onboarding", "editar");
      var btnNovo = podeEditar ? '<button class="btn primary" data-acao="novo">' + UI.icone("plus", 16) + " Iniciar onboarding</button>" : '<span class="chip">Somente leitura</span>';

      var hd = '<div class="page-hd"><div><h1>Onboarding</h1>' +
        '<div class="sub">Entrada de clientes com checklist, prazos e diagnóstico de proteção do escritório.</div></div>' +
        "<div>" + btnNovo + "</div></div>";

      var detalhe = this._aberto ? this._renderDetalhe(this._aberto, mapCli, podeEditar) : "";

      // ---- Lista de processos ----
      var linhas = Util.ordenaPor(procs, "criadoEm", true).map(function (ob) {
        return { _ob: ob, _cli: nomeCliente(mapCli[ob.clienteId]) };
      });
      var cols = [
        { k: "_cli", label: "Cliente", fmt: function (v, row) { return Util.esc(v) + (row._ob.concluido ? " " + UI.badge("Concluído", "verde") : ""); } },
        { k: "_prog", label: "Progresso", fmt: function (v, row) { return barraProgresso(contaFeitas(row._ob), row._ob.etapas.length); } },
        { k: "_atr", label: "Etapas atrasadas", fmt: function (v, row) { var n = contaAtrasadas(row._ob); return n ? UI.badge(n + " atrasada(s)", "vermelho") : UI.badge("em dia", "cinza"); } },
        { k: "_ini", label: "Iniciado em", fmt: function (v, row) { return Util.esc(Util.brData(row._ob.criadoEm)); } },
        { k: "_ac", label: "Ações", cls: "ctr", fmt: function (v, row) { return '<button class="btn sm" data-acao="abrir:' + row._ob.id + '">Abrir</button>'; } }
      ];
      var tabela = UI.tabela(cols, linhas, { vazio: "Nenhum onboarding iniciado. Novos clientes entram aqui automaticamente." });

      return hd + kpis + detalhe +
        '<div class="card"><div class="card-hd"><b>Processos de onboarding</b><span class="chip">' + linhas.length + " processo(s)</span></div>" +
        '<div class="card-bd">' + tabela + "</div></div>";
    },

    // Card de detalhe: checklist + diagnóstico de entrada + termo impresso.
    _renderDetalhe: function (obId, mapCli, podeEditar) {
      var ob = Store.obter("onboardings", obId);
      if (!ob) return "";
      var cli = mapCli[ob.clienteId] || Store.obter("clientes", ob.clienteId);
      var feitas = contaFeitas(ob), total = ob.etapas.length, i, et, chk, prazoHtml, linha = "";

      for (i = 0; i < total; i++) {
        et = ob.etapas[i];
        chk = '<input type="checkbox"' + (et.feito ? " checked" : "") + (podeEditar ? "" : " disabled") +
          ' data-acao="marcar:' + ob.id + "|" + et.id + '" style="width:16px;height:16px;cursor:pointer">';
        prazoHtml = Util.esc(Util.brData(et.prazo));
        if (et.feito) prazoHtml += " " + UI.badge("feito em " + Util.brData(et.feitoEm || ""), "verde");
        else if (etapaAtrasada(et)) prazoHtml += " " + UI.badge((-Util.diasAte(et.prazo)) + "d atraso", "vermelho");
        else { var d = Util.diasAte(et.prazo); if (d != null && d <= 3) prazoHtml += " " + UI.badge(d === 0 ? "hoje" : ("em " + d + "d"), "amber"); }
        linha += '<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #e2e8f0">' +
          chk + '<div style="flex:1' + (et.feito ? ";text-decoration:line-through;opacity:.65" : "") + '">' + Util.esc(et.titulo) + "</div>" +
          '<div style="white-space:nowrap">' + prazoHtml + "</div></div>";
      }

      var diag = '<div style="margin-top:14px">' +
        '<label class="fld"><span class="fld-l">Diagnóstico de entrada (proteção do escritório)</span>' +
        '<textarea id="ob-diag" class="in" rows="4" placeholder="Pendências herdadas do contador anterior: débitos, parcelamentos, malha, obrigações não entregues...">' + Util.esc(ob.diagnostico || "") + "</textarea>" +
        '<span class="fld-d">Registre aqui o passivo herdado — é a prova de que veio do contador anterior.</span></label>' +
        '<div class="toolbar" style="margin-top:8px">' +
        (podeEditar ? '<button class="btn green sm" data-acao="salvarDiag:' + ob.id + '">Salvar diagnóstico</button> ' : "") +
        '<button class="btn sm" data-acao="imprimirTermo:' + ob.id + '">Imprimir termo de diagnóstico</button>' +
        "</div></div>";

      return '<div class="card"><div class="card-hd"><b>' + Util.esc(nomeCliente(cli)) + "</b>" +
        '<span class="chip">' + feitas + "/" + total + " etapas" + (ob.concluido ? " · concluído" : "") + "</span>" +
        '<button class="btn sm" data-acao="fechar" style="margin-left:auto">Fechar</button></div>' +
        '<div class="card-bd">' + barraProgresso(feitas, total) + '<div style="margin-top:10px">' + linha + "</div>" + diag + "</div></div>";
    },

    onMount: function () {},

    // ---- Ações (data-acao) ----

    abrir: function (id) { this._aberto = id; App.render(); },
    fechar: function () { this._aberto = null; App.render(); },

    // Alterna feito/feitoEm de uma etapa. arg = "obId|etapaId".
    marcar: function (arg) {
      if (!Auth.pode("onboarding", "editar")) { UI.toast("Sem permissão para editar onboarding.", "erro"); return; }
      var partes = String(arg || "").split("|"), obId = partes[0], etId = partes[1];
      var ob = Store.obter("onboardings", obId);
      if (!ob) { UI.toast("Onboarding não encontrado.", "erro"); return; }
      var i, et = null;
      for (i = 0; i < ob.etapas.length; i++) if (ob.etapas[i].id === etId) { et = ob.etapas[i]; break; }
      if (!et) { UI.toast("Etapa não encontrada.", "erro"); return; }
      et.feito = !et.feito;
      et.feitoEm = et.feito ? Util.hojeISO() : null;
      var completo = todasFeitas(ob);
      ob.concluido = completo; // desmarcar reabre o processo
      Store.salvar("onboardings", ob);
      if (global.Audit) global.Audit.log("etapa_onboarding", "onboarding", ob.id);
      if (completo) UI.toast("🎉 Onboarding concluído! Cliente 100% integrado.", "ok");
      else UI.toast(et.feito ? "Etapa concluída." : "Etapa reaberta.", "info");
      App.render();
    },

    // Salva o texto livre do diagnóstico de entrada.
    salvarDiag: function (obId) {
      if (!Auth.pode("onboarding", "editar")) { UI.toast("Sem permissão para editar onboarding.", "erro"); return; }
      var ob = Store.obter("onboardings", obId);
      if (!ob) { UI.toast("Onboarding não encontrado.", "erro"); return; }
      var e = UI.el("ob-diag");
      ob.diagnostico = e ? e.value : "";
      Store.salvar("onboardings", ob);
      if (global.Audit) global.Audit.log("diagnostico_onboarding", "onboarding", ob.id);
      UI.toast("Diagnóstico salvo.", "ok");
      App.render();
    },

    // Termo de diagnóstico de entrada — prova documental do passivo herdado.
    imprimirTermo: function (obId) {
      if (!Auth.pode("onboarding", "exportar")) { UI.toast("Sem permissão para exportar.", "erro"); return; }
      var ob = Store.obter("onboardings", obId);
      if (!ob) { UI.toast("Onboarding não encontrado.", "erro"); return; }
      var cli = Store.obter("clientes", ob.clienteId);
      var nome = nomeCliente(cli);
      var cnpj = cli && cli.cnpj ? Util.formataCNPJ(cli.cnpj) : "—";

      // pendências herdadas: texto do diagnóstico (linha a linha) ou placeholder
      var pend = "", i;
      var txt = String(ob.diagnostico || "").split("\n");
      for (i = 0; i < txt.length; i++) if (txt[i].replace(/\s/g, "")) pend += "<tr><td>" + Util.esc(txt[i]) + "</td></tr>";
      if (!pend) pend = '<tr><td>Nenhuma pendência registrada até a data deste termo.</td></tr>';

      // situação do checklist na data do termo
      var etps = "";
      for (i = 0; i < ob.etapas.length; i++) {
        var et = ob.etapas[i];
        etps += "<tr><td>" + Util.esc(et.titulo) + "</td><td>" + Util.esc(Util.brData(et.prazo)) + "</td>" +
          '<td class="' + (et.feito ? "ok" : (etapaAtrasada(et) ? "al" : "")) + '">' +
          (et.feito ? "Concluída em " + Util.esc(Util.brData(et.feitoEm || "")) : (etapaAtrasada(et) ? "Pendente (atrasada)" : "Pendente")) + "</td></tr>";
      }

      var corpo = "<h2>Termo de Diagnóstico de Entrada</h2>" +
        "<table><tr><th>Cliente</th><th>CNPJ</th><th>Início do onboarding</th><th>Data do termo</th></tr>" +
        "<tr><td>" + Util.esc(nome) + "</td><td>" + Util.esc(cnpj) + "</td><td>" + Util.esc(Util.brData(ob.criadoEm)) + "</td><td>" + Util.esc(Util.brData(Util.hojeISO())) + "</td></tr></table>" +
        "<h2>Pendências herdadas (anteriores à entrada no escritório)</h2>" +
        "<table><tr><th>Descrição da pendência</th></tr>" + pend + "</table>" +
        "<p style='margin:8px 0'>As pendências acima são anteriores ao início da prestação de serviços por este escritório e foram apuradas no diagnóstico de entrada. O cliente declara ciência de que tais passivos decorrem de período sob responsabilidade do contador anterior.</p>" +
        "<h2>Checklist de integração na data do termo</h2>" +
        "<table><tr><th>Etapa</th><th>Prazo</th><th>Situação</th></tr>" + etps + "</table>" +
        '<div style="margin-top:56px;display:flex;justify-content:space-between;gap:40px">' +
        '<div style="flex:1;border-top:1px solid #0f172a;padding-top:6px;text-align:center">' + Util.esc(nome) + "<br><small>Cliente — ciente das pendências herdadas</small></div>" +
        '<div style="flex:1;border-top:1px solid #0f172a;padding-top:6px;text-align:center">' + Util.esc(CONFIG.marca.nome) + "<br><small>Responsável pelo diagnóstico</small></div>" +
        "</div>";

      if (global.Audit) global.Audit.log("termo_diagnostico_impresso", "onboarding", ob.id);
      App._abrirPrint("Termo de Diagnóstico de Entrada — " + nome, corpo);
    },

    // Modal "Iniciar onboarding": clientes visíveis SEM onboarding.
    novo: function () {
      if (!Auth.pode("onboarding", "editar")) { UI.toast("Sem permissão para iniciar onboarding.", "erro"); return; }
      var self = this;
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      var sem = [], i;
      for (i = 0; i < visiveis.length; i++) if (!Store.obter("onboardings", "ob_" + visiveis[i].id)) sem.push(visiveis[i]);
      if (!sem.length) { UI.toast("Todos os clientes visíveis já têm onboarding.", "info"); return; }
      var ops = [{ v: "", t: "— selecione o cliente —" }];
      for (i = 0; i < sem.length; i++) ops.push({ v: sem[i].id, t: nomeCliente(sem[i]) });
      var corpo = UI.campo("Cliente", UI.sel("ob-novo-cli", ops, ""), "O checklist padrão é criado com prazos a partir de hoje.");
      UI.modal("Iniciar onboarding", corpo, [
        { txt: "Cancelar" },
        { txt: "Iniciar", classe: "primary", onClick: function (fechar) {
          var cliId = UI.v("ob-novo-cli");
          if (!cliId) { UI.toast("Selecione um cliente.", "alerta"); return; }
          var cli = Store.obter("clientes", cliId);
          if (!cli) { UI.toast("Cliente não encontrado.", "erro"); return; }
          var ob = global.Onboarding.aoCriarCliente(cli);
          UI.toast("Onboarding iniciado para " + nomeCliente(cli) + ".", "ok");
          fechar();
          self._aberto = ob ? ob.id : null;
          App.render();
        } }
      ]);
    }
  });
})(window);
