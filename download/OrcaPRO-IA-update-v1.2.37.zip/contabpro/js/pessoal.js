/* =====================================================================
 * pessoal.js — Departamento Pessoal (seção 3.7): admissão, contrato de
 * experiência, férias (período aquisitivo), desligamento e um RADAR de
 * prazos trabalhistas por cliente.
 * RBAC DURO: Auth.veFolha() no render e em TODA ação — comercial e
 * financeiro interno NÃO enxergam folha. Registrada como id "pessoal".
 * Coleção nova: "funcionarios" (id determinístico via Util.uid).
 * ES5 estrito (var/function/concat). Orquestra Store + Auth + UI + CONFIG.
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  // Tipos de contrato (badge por cor).
  var TIPOS = [
    { v: "clt",         t: "CLT",         cor: "azul" },
    { v: "experiencia", t: "Experiência", cor: "amber" },
    { v: "aprendiz",    t: "Aprendiz",    cor: "roxo" },
    { v: "domestico",   t: "Doméstico",   cor: "cinza" }
  ];
  var STATUS = [
    { v: "ativo",     t: "Ativo",     cor: "verde" },
    { v: "afastado",  t: "Afastado",  cor: "amber" },
    { v: "desligado", t: "Desligado", cor: "cinza" }
  ];

  // ---------- Helpers puros (closure do módulo) ----------

  // Padrão de nome entre telas; null-safe (cliente pode ter sido excluído).
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(cliente excluído)"; }
  function idUsuario() { var u = Auth.usuario(); return u ? u.id : null; }

  // Guard central do módulo: segregação de folha (seção 2) + toast.
  function semAcesso() {
    if (Auth.veFolha()) return false;
    UI.toast("Sem acesso à folha.", "erro");
    return true;
  }

  function rotuloTipo(v) { for (var i = 0; i < TIPOS.length; i++) if (TIPOS[i].v === v) return TIPOS[i]; return { v: v, t: v || "—", cor: "cinza" }; }
  function rotuloStatus(v) { for (var i = 0; i < STATUS.length; i++) if (STATUS[i].v === v) return STATUS[i]; return { v: v, t: v || "—", cor: "cinza" }; }
  function tipoBadge(v) { var r = rotuloTipo(v); return UI.badge(r.t, r.cor); }
  function statusBadge(v) { var r = rotuloStatus(v); return UI.badge(r.t, r.cor); }

  // Aceita "1500.00" (decimal com ponto) sem virar 150000 no parseBR (que trata ponto como milhar).
  function parseValor(raw) { if (/^\d+\.\d{1,2}$/.test(raw)) raw = raw.replace(".", ","); return Util.parseBR(raw); }

  // Dias desde a admissão (positivo p/ passado). diasAte devolve negativo p/ datas passadas.
  function diasDesde(iso) { var d = Util.diasAte(iso); return d == null ? null : -d; }

  // Alertas automáticos de UM funcionário. Cada um: {txt, cor, quente}.
  // "quente" = prazo legal que exige ação agora (entra nos KPIs).
  function alertasFunc(f) {
    var out = [];
    // 1) contrato de experiência acabando
    if (f.tipoContrato === "experiencia" && f.fimExperiencia) {
      var d = Util.diasAte(f.fimExperiencia);
      if (d != null) {
        if (d < 0) out.push({ txt: "Experiência vencida — efetivado?", cor: "vermelho", quente: true });
        else if (d <= 7) out.push({ txt: "Experiência vence em " + d + "d", cor: "amber", quente: true });
      }
    }
    // 2) período aquisitivo de férias (simplificação: >330 dias ativo sem registro de gozo)
    if (f.status === "ativo" && f.admissao) {
      var da = diasDesde(f.admissao);
      if (da != null && da > 330) out.push({ txt: "Férias vencendo — período aquisitivo", cor: "amber", quente: true });
    }
    // 3) aprendiz — informativo (contrato determinado, limite legal de 2 anos / cota)
    if (f.tipoContrato === "aprendiz" && f.status !== "desligado")
      out.push({ txt: "Aprendiz — contrato determinado (limite 2 anos)", cor: "roxo", quente: false });
    return out;
  }
  function temQuente(f) { var a = alertasFunc(f); for (var i = 0; i < a.length; i++) if (a[i].quente) return true; return false; }

  // Funcionários que o usuário PODE ver (só de clientes visíveis à sua carteira).
  function visiveis() {
    var todos = Auth.clientesVisiveis(Store.listar("clientes"));
    var set = {}; for (var i = 0; i < todos.length; i++) set[todos[i].id] = 1;
    return Store.listar("funcionarios").filter(function (f) { return set[f.clienteId]; });
  }

  // ---------- View ----------
  global.PessoalView = App.registrar({
    id: "pessoal",
    titulo: "Depto. Pessoal",

    render: function () {
      // RBAC DURO: quem não vê folha não vê NADA aqui.
      if (!Auth.veFolha()) return '<div class="empty">Sem acesso à folha.</div>';

      var clientesVis = Auth.clientesVisiveis(Store.listar("clientes"));
      var nomeCli = {}, i;
      for (i = 0; i < clientesVis.length; i++) nomeCli[clientesVis[i].id] = nomeCliente(clientesVis[i]);
      function nomeDe(id) { return nomeCli[id] || "(cliente excluído)"; }

      // filtro de cliente (estado do módulo)
      var funcs = visiveis();
      if (this._cliente && this._cliente !== "*") {
        var alvo = this._cliente;
        funcs = funcs.filter(function (f) { return f.clienteId === alvo; });
      }
      // ordena por nome do cliente e depois nome do funcionário
      funcs = funcs.map(function (f) { f._nomeCli = nomeDe(f.clienteId); return f; });
      funcs = Util.ordenaPor(Util.ordenaPor(funcs, "nome"), "_nomeCli");

      // ---- KPIs ----
      var h = Util.partes(Util.hojeISO()), compAtual = Util.competencia(h.y, h.m);
      var ativos = 0, admMes = 0, quentes = 0;
      for (i = 0; i < funcs.length; i++) {
        var f = funcs[i];
        if (f.status === "ativo") ativos++;
        if (String(f.admissao || "").slice(0, 7) === compAtual) admMes++;
        if (temQuente(f)) quentes++;
      }
      var kpis = '<div class="grid-kpi">' +
        '<div class="kpi ok"><div class="n">' + ativos + '</div><div class="l">Funcionários ativos</div></div>' +
        '<div class="kpi"><div class="n">' + admMes + '</div><div class="l">Admissões no mês</div></div>' +
        '<div class="kpi ' + (quentes ? "al" : "") + '"><div class="n">' + quentes + '</div><div class="l">Prazos trabalhistas quentes</div></div>' +
        "</div>";

      // ---- Toolbar: filtro por cliente + admitir ----
      var opCli = [{ v: "*", t: "Todos os clientes" }];
      for (i = 0; i < clientesVis.length; i++) opCli.push({ v: clientesVis[i].id, t: nomeCliente(clientesVis[i]) });
      var toolbar = '<div class="toolbar">' +
        UI.sel("dp-cli", opCli, this._cliente || "*") +
        '<button class="btn primary" data-acao="novo">' + UI.icone("plus", 16) + ' Admitir funcionário</button>' +
        "</div>";

      // ---- Tabela ----
      var cols = [
        { k: "_nomeCli", label: "Cliente", fmt: function (v) { return Util.esc(v); } },
        { k: "nome", label: "Nome", fmt: function (v) { return Util.esc(v || "—"); } },
        { k: "cargo", label: "Cargo", fmt: function (v) { return Util.esc(v || "—"); } },
        { k: "salario", label: "Salário", cls: "num", fmt: function (v) { return Util.esc(Util.brMoeda(v)); } },
        { k: "admissao", label: "Admissão", fmt: function (v) { return '<span style="white-space:nowrap">' + Util.esc(Util.brData(v)) + "</span>"; } },
        { k: "tipoContrato", label: "Tipo", fmt: function (v) { return tipoBadge(v); } },
        { k: "status", label: "Status", fmt: function (v) { return statusBadge(v); } },
        { k: "_alertas", label: "Alertas", fmt: function (v, row) {
          var a = alertasFunc(row);
          if (!a.length) return '<span class="fld-d">—</span>';
          return a.map(function (x) { return UI.badge(x.txt, x.cor); }).join(" ");
        } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) {
          var out = '<button class="btn sm" data-acao="editar:' + Util.esc(row.id) + '">Editar</button>';
          if (row.status !== "desligado") out += ' <button class="btn sm danger" data-acao="desligar:' + Util.esc(row.id) + '">Desligar</button>';
          return out;
        } }
      ];
      var tbl = UI.tabela(cols, funcs, { vazio: "Nenhum funcionário cadastrado. Use “Admitir funcionário”." });

      // ---- Radar trabalhista (consolidado, abaixo da tabela) ----
      var radar = this._radar(funcs, nomeDe);

      return '<div class="page-hd"><div><h1>Departamento Pessoal</h1>' +
        '<div class="sub">Admissões, contrato de experiência, férias e desligamentos — com radar de prazos legais.</div></div></div>' +
        kpis + toolbar +
        '<div class="card"><div class="card-hd"><b>Funcionários</b>' +
        '<span class="chip">' + funcs.length + ' registro(s)</span></div>' +
        '<div class="card-bd">' + tbl + "</div></div>" +
        radar;
    },

    // Card "Radar trabalhista": lista consolidada de todos os alertas visíveis.
    _radar: function (funcs, nomeDe) {
      var itens = [];
      for (var i = 0; i < funcs.length; i++) {
        var f = funcs[i], a = alertasFunc(f);
        for (var j = 0; j < a.length; j++) {
          itens.push("<li><b>" + Util.esc(f.nome || "—") + "</b> <span class=\"fld-d\">(" + Util.esc(nomeDe(f.clienteId)) + ")</span> — " +
            UI.badge(a[j].txt, a[j].cor) + "</li>");
        }
      }
      var corpo;
      if (itens.length) corpo = '<ul style="margin:0 0 4px 18px">' + itens.join("") + "</ul>";
      else corpo = '<div class="empty">Nenhum prazo trabalhista em aberto entre os funcionários visíveis.</div>';
      return '<div class="card"><div class="card-hd"><b>Radar trabalhista</b>' +
        '<span class="chip">' + itens.length + ' aviso(s)</span></div>' +
        '<div class="card-bd">' + corpo +
        '<div class="fld-d" style="margin-top:8px">Experiência (efetivação), período aquisitivo de férias e aprendizes/PCD — informativo. Prazos legais devem ser confirmados na convenção coletiva e no eSocial.</div>' +
        "</div></div>";
    },

    // Liga o filtro de cliente (change -> guarda estado + re-render).
    onMount: function () {
      var self = this, e = UI.el("dp-cli");
      if (e) e.addEventListener("change", function () { self._cliente = e.value; App.render(); });
    },

    // ---- Admissão / edição ----

    // Modal compartilhado. f=null -> admitir novo (cliente selecionável).
    _modalFunc: function (f) {
      var novo = !f;
      var clientesVis = Auth.clientesVisiveis(Store.listar("clientes"));
      var corpoTopo;
      if (novo) {
        if (!clientesVis.length) { UI.toast("Cadastre um cliente antes de admitir funcionários.", "info"); return; }
        var opCli = [{ v: "", t: "— selecione o cliente —" }];
        for (var i = 0; i < clientesVis.length; i++) opCli.push({ v: clientesVis[i].id, t: nomeCliente(clientesVis[i]) });
        // pré-seleciona o cliente do filtro atual (se houver)
        var pre = (this._cliente && this._cliente !== "*") ? this._cliente : "";
        corpoTopo = UI.campo("Cliente (empresa)", UI.sel("dp-f-cli", opCli, pre));
      } else {
        var cli = Store.obter("clientes", f.clienteId);
        corpoTopo = UI.campo("Cliente (empresa)", '<input class="in" value="' + Util.esc(nomeCliente(cli)) + '" disabled>');
      }

      var tipoAtual = f ? f.tipoContrato : "clt";
      var corpo = corpoTopo +
        '<div class="row">' +
        UI.campo("Nome completo", UI.inp("dp-f-nome", f ? f.nome : "", "ex.: Maria Silva")) +
        UI.campo("CPF", UI.inp("dp-f-cpf", f ? Util.formataCPF(f.cpf) : "", "000.000.000-00")) +
        "</div>" +
        '<div class="row-3">' +
        UI.campo("Cargo", UI.inp("dp-f-cargo", f ? f.cargo : "", "ex.: Auxiliar")) +
        UI.campo("Salário (R$)", UI.inp("dp-f-sal", f ? Util.brNum(f.salario, 2) : "", "0,00")) +
        UI.campo("Admissão", UI.inp("dp-f-adm", f ? f.admissao : Util.hojeISO(), "", "date")) +
        "</div>" +
        '<div class="row-3">' +
        UI.campo("Tipo de contrato", UI.sel("dp-f-tipo", TIPOS.map(function (t) { return { v: t.v, t: t.t }; }), tipoAtual)) +
        UI.campo("Sindicato / categoria", UI.inp("dp-f-sind", f ? f.sindicato : "", "ex.: SINDECON")) +
        UI.campo("Dependentes", UI.inp("dp-f-dep", f ? (f.dependentes || 0) : 0, "0", "number")) +
        "</div>" +
        UI.campo("Situação", UI.sel("dp-f-status", STATUS.map(function (s) { return { v: s.v, t: s.t }; }), f ? f.status : "ativo")) +
        '<div class="fld-d" id="dp-f-dica" style="' + (tipoAtual === "experiencia" ? "" : "display:none") + '">Contrato de experiência: o sistema calcula o fim em 90 dias a partir da admissão.</div>';

      var self = this;
      var ov = UI.modal(novo ? "Admitir funcionário" : "Editar funcionário", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "primary", onClick: function (fechar) {
          if (!Auth.veFolha()) { UI.toast("Sem acesso à folha.", "erro"); return; }
          var clienteId = novo ? UI.v("dp-f-cli") : f.clienteId;
          if (!clienteId) { UI.toast("Selecione o cliente.", "alerta"); return; }
          var nome = UI.v("dp-f-nome");
          if (!nome) { UI.toast("Informe o nome do funcionário.", "alerta"); return; }
          var admissao = UI.v("dp-f-adm");
          if (!admissao) { UI.toast("Informe a data de admissão.", "alerta"); return; }
          var salario = parseValor(UI.v("dp-f-sal"));
          if (!(salario > 0)) { UI.toast("Informe um salário maior que zero.", "alerta"); return; }
          var tipo = UI.v("dp-f-tipo");
          var dep = Math.max(0, Math.round(Util.parseBR(UI.v("dp-f-dep"))));

          var obj = {
            id: f ? f.id : Util.uid("func"),
            clienteId: clienteId,
            nome: nome,
            cpf: Util.soDigitos(UI.v("dp-f-cpf")),
            cargo: UI.v("dp-f-cargo"),
            salario: salario,
            admissao: admissao,
            tipoContrato: tipo,
            sindicato: UI.v("dp-f-sind"),
            status: UI.v("dp-f-status"),
            dependentes: dep,
            desligamento: f ? (f.desligamento || null) : null,
            criadoEm: f ? (f.criadoEm || Util.hojeISO()) : Util.hojeISO()
          };
          // experiência: calcula o fim (90 dias) se ainda não houver
          if (tipo === "experiencia") {
            obj.fimExperiencia = (f && f.fimExperiencia) ? f.fimExperiencia : Util.somaDias(admissao, 90);
          } else {
            obj.fimExperiencia = null; // trocou de tipo -> zera
          }

          Store.salvar("funcionarios", obj); // STORAGE_CHEIO -> ui.js mostra toast
          if (global.Audit) global.Audit.log(novo ? "admitiu" : "editou", "funcionario", obj.id);
          UI.toast(novo ? "Funcionário admitido." : "Cadastro atualizado.", "ok");
          // eSocial admissão é evento D-1: lembra o operador do prazo de envio
          if (novo) UI.toast("eSocial: o evento de admissão deve ser enviado até 1 dia antes do início.", "info");
          fechar(); App.render();
        } }
      ]);

      // mostra/oculta a dica de 90 dias conforme o tipo escolhido
      if (ov) {
        var selTipo = ov.querySelector("#dp-f-tipo"), dica = ov.querySelector("#dp-f-dica");
        if (selTipo && dica) selTipo.addEventListener("change", function () {
          dica.style.display = selTipo.value === "experiencia" ? "" : "none";
        });
      }
    },

    novo: function () {
      if (semAcesso()) return;
      this._modalFunc(null);
    },

    editar: function (id) {
      if (semAcesso()) return;
      var f = Store.obter("funcionarios", id);
      if (!f) { UI.toast("Funcionário não encontrado.", "erro"); return; }
      this._modalFunc(f);
    },

    // ---- Desligamento ----
    desligar: function (id) {
      if (semAcesso()) return;
      var f = Store.obter("funcionarios", id);
      if (!f) { UI.toast("Funcionário não encontrado.", "erro"); return; }
      if (f.status === "desligado") { UI.toast("Funcionário já está desligado.", "info"); return; }
      var cli = Store.obter("clientes", f.clienteId);
      var corpo = '<p class="fld-d" style="margin-bottom:14px">' + Util.esc(f.nome || "—") + " — " +
        Util.esc(nomeCliente(cli)) + " · admitido em " + Util.esc(Util.brData(f.admissao)) + "</p>" +
        UI.campo("Data do desligamento", UI.inp("dp-dl-data", Util.hojeISO(), "", "date")) +
        '<div class="fld-d">O acerto rescisório (verbas + guias) tem prazo legal de 10 dias corridos a partir do término do contrato.</div>';
      UI.modal("Desligar funcionário", corpo, [
        { txt: "Cancelar" },
        { txt: "Confirmar desligamento", classe: "danger", onClick: function (fechar) {
          if (!Auth.veFolha()) { UI.toast("Sem acesso à folha.", "erro"); return; }
          var data = UI.v("dp-dl-data");
          if (!data) { UI.toast("Informe a data do desligamento.", "alerta"); return; }
          f.status = "desligado";
          f.desligamento = data;
          Store.salvar("funcionarios", f);
          if (global.Audit) global.Audit.log("desligou", "funcionario", f.id);
          // prazo do acerto rescisório (art. 477 CLT): 10 dias corridos
          var limite = Util.somaDias(data, 10);
          UI.toast("Desligamento registrado. Acerto rescisório até " + Util.brData(limite) + " (10 dias).", "ok");
          fechar(); App.render();
        } }
      ]);
    }
  });
})(window);
