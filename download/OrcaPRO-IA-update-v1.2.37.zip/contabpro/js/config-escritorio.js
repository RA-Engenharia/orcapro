/* =====================================================================
 * config-escritorio.js — Configurações do Escritório (módulo "config").
 * SÓ O SÓCIO acessa (soPerfil:["socio"] + guard duro nivel>=100 no render
 * e em TODA ação). Quatro abas:
 *   - Marca (white-label 3.26): nome + cores + preview; aplica --navy na hora.
 *   - Parâmetros: valorPonto (honorário), custoPorPonto (margem no BI) e o
 *     toggle da dupla conferência (4 olhos) — reflete em CONFIG em runtime.
 *   - Matriz de obrigações (REGRA DE OURO): fonte da agenda, versionada e
 *     EDITÁVEL pelo escritório (add/editar/excluir EM MEMÓRIA nesta sessão;
 *     a base persistente é data/matriz-obrigacoes.json).
 *   - Usuários: cadastro que habilita o modo EQUIPE (>=2 usuários) dos 4 olhos.
 * Guarda config em Store "config_escritorio" (id fixo "cfg").
 * ES5 estrito (var/function/concat). Util.esc() em TODO dado de usuário.
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  // ---------- Helpers puros ----------

  // Só o sócio (nivel 100) mexe nas configurações. Null-safe.
  function ehSocio() { var p = Auth.perfil(); return !!(p && p.nivel >= 100); }

  // Nome de cliente no padrão das telas (null-safe).
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(sem nome)"; }

  // Iniciais para o "logo" da marca (2 letras).
  function iniciais(nome) {
    var s = String(nome || "").replace(/[^0-9A-Za-zÀ-ÿ]/g, "");
    return (s.slice(0, 2) || "CP").toUpperCase();
  }

  // parseValor: aceita "1.500,00" -> 1500 E "1500.00" -> 1500 (senão o ponto
  // decimal viraria milhar e gravaria valor 100x maior sem aviso).
  function parseValor(raw) {
    raw = String(raw == null ? "" : raw).trim();
    if (/^\d+\.\d{1,2}$/.test(raw)) raw = raw.replace(".", ",");
    return Util.parseBR(raw);
  }

  // Config atual: lê Store "config_escritorio"/"cfg" ou cai nos defaults do CONFIG.
  // Null-safe em cada campo (arquivo pode não existir ou estar parcial).
  function cfgAtual() {
    var c = Store.obter("config_escritorio", "cfg");
    return {
      id: "cfg",
      nomeExibicao: (c && c.nomeExibicao) || CONFIG.marca.nome,
      corPrimaria: (c && c.corPrimaria) || CONFIG.marca.corPrimaria,
      corSecundaria: (c && c.corSecundaria) || CONFIG.marca.corSecundaria,
      valorPonto: (c && c.valorPonto != null) ? c.valorPonto : (CONFIG.precificacao.valorPonto || 0),
      custoPorPonto: (c && c.custoPorPonto != null) ? c.custoPorPonto : null, // null = nunca configurado (BI usa proxy 35%); 0 é valor explícito válido
      duplaConferenciaAtiva: (c && typeof c.duplaConferenciaAtiva === "boolean") ? c.duplaConferenciaAtiva : (CONFIG.duplaConferencia.ativa !== false),
      criticas: (c && c.criticas) || (CONFIG.duplaConferencia.criticas || []),
      atualizadoEm: c ? (c.atualizadoEm || null) : null
    };
  }

  // Resumo legível das regras de aplicabilidade de uma obrigação da matriz.
  function resumoAplica(a) {
    a = a || {};
    var p = [];
    if (a.regime) p.push("regime: " + a.regime.join("/"));
    if (a.excluiRegime) p.push("exceto regime: " + a.excluiRegime.join("/"));
    if (a.segmento) p.push("segmento: " + a.segmento.join("/"));
    if (a.excluiSegmento) p.push("exceto seg.: " + a.excluiSegmento.join("/"));
    if (a.temIE) p.push("com IE");
    if (a.temFuncionarios) p.push("com funcionários");
    if (a.atividadeServico) p.push("atividade de serviço");
    if (a.uf) p.push("UF: " + a.uf.join("/"));
    return p.length ? p.join(" · ") : "todos os clientes";
  }

  var GRUPOS = [
    { v: "federal", t: "Federal" },
    { v: "estadual", t: "Estadual" },
    { v: "municipal", t: "Municipal" },
    { v: "trabalhista", t: "Trabalhista" }
  ];
  var PERIODICIDADES = [
    { v: "mensal", t: "Mensal" },
    { v: "trimestral", t: "Trimestral" },
    { v: "semestral", t: "Semestral" },
    { v: "anual", t: "Anual" }
  ];

  // Lê os valores selecionados de um <select multiple>.
  function lerMulti(id) {
    var e = UI.el(id), out = [];
    if (!e || !e.options) return out;
    for (var i = 0; i < e.options.length; i++) if (e.options[i].selected) out.push(e.options[i].value);
    return out;
  }

  // ---------- View ----------
  global.ConfigEscritorioView = App.registrar({
    id: "config",
    titulo: "Configurações",

    // Guard de ação: toast + true quando NÃO é sócio.
    _guard: function () {
      if (ehSocio()) return false;
      UI.toast("Só o sócio acessa as configurações.", "erro");
      return true;
    },

    render: function () {
      if (!ehSocio()) return '<div class="empty">Só o sócio acessa as configurações.</div>';
      if (!this._aba) this._aba = "marca";
      var aba = this._aba;

      var abas = [
        { id: "marca", nome: "Marca (white-label)" },
        { id: "parametros", nome: "Parâmetros" },
        { id: "matriz", nome: "Matriz de obrigações" },
        { id: "usuarios", nome: "Usuários" }
      ];
      var tabBar = '<div class="toolbar">' + abas.map(function (a) {
        return '<button class="btn ' + (aba === a.id ? "primary" : "") + '" data-acao="aba:' + a.id + '">' + Util.esc(a.nome) + "</button>";
      }).join("") + "</div>";

      var corpo = "";
      if (aba === "marca") corpo = this._renderMarca();
      else if (aba === "parametros") corpo = this._renderParametros();
      else if (aba === "matriz") corpo = this._renderMatriz();
      else if (aba === "usuarios") corpo = this._renderUsuarios();

      return '<div class="page-hd"><div><h1>Configurações do Escritório</h1>' +
        '<div class="sub">White-label, parâmetros de precificação, matriz de obrigações e equipe. Acesso exclusivo do sócio.</div></div></div>' +
        tabBar + corpo;
    },

    // ---- ABA MARCA ----
    _renderMarca: function () {
      var cur = cfgAtual();
      var form =
        '<div class="card"><div class="card-hd"><b>Identidade visual (white-label)</b></div><div class="card-bd">' +
        UI.campo("Nome de exibição do escritório", UI.inp("cfg-nome", cur.nomeExibicao, "ex.: Contabilidade Silva")) +
        '<div class="row">' +
        UI.campo("Cor primária (navy)", UI.inp("cfg-cor-prim", cur.corPrimaria, "", "color")) +
        UI.campo("Cor secundária (aço)", UI.inp("cfg-cor-sec", cur.corSecundaria, "", "color")) +
        "</div>" +
        '<div class="fld-d">A cor primária é aplicada imediatamente à interface (variável --navy) ao salvar.</div>' +
        '<div class="toolbar"><button class="btn primary" data-acao="salvarMarca">' + UI.icone("check", 16) + " Salvar marca</button></div>" +
        "</div></div>";

      var pv =
        '<div class="card"><div class="card-hd"><b>Pré-visualização</b></div><div class="card-bd">' +
        '<div id="cfg-preview" style="border-radius:12px;padding:18px;background:' + Util.esc(cur.corPrimaria) + ';color:#fff">' +
        '<div style="display:flex;align-items:center;gap:12px">' +
        '<div id="cfg-preview-logo" style="width:42px;height:42px;border-radius:10px;background:' + Util.esc(cur.corSecundaria) + ';display:flex;align-items:center;justify-content:center;font-weight:800">' + Util.esc(iniciais(cur.nomeExibicao)) + "</div>" +
        '<div><b id="cfg-preview-nome" style="font-size:17px">' + Util.esc(cur.nomeExibicao) + "</b>" +
        '<div style="opacity:.82;font-size:12px">' + Util.esc(CONFIG.marca.slogan) + "</div></div></div>" +
        '<button id="cfg-preview-bt" style="margin-top:14px;background:' + Util.esc(cur.corSecundaria) + ';color:#fff;border:none;border-radius:8px;padding:8px 14px;font-weight:600;cursor:default">Botão de exemplo</button>' +
        "</div></div></div>";

      return form + pv;
    },

    salvarMarca: function () {
      if (this._guard()) return;
      var cur = cfgAtual();
      var nome = UI.v("cfg-nome");
      if (!nome) { UI.toast("Informe o nome de exibição do escritório.", "alerta"); return; }
      var cp = UI.v("cfg-cor-prim") || cur.corPrimaria;
      var cs = UI.v("cfg-cor-sec") || cur.corSecundaria;
      cur.nomeExibicao = nome;
      cur.corPrimaria = cp;
      cur.corSecundaria = cs;
      cur.atualizadoEm = Util.hojeISO();
      Store.salvar("config_escritorio", cur); // STORAGE_CHEIO -> delegação mostra toast
      // efeito imediato: reflete no CONFIG (sidebar, cabeçalho de impressão) + variável de tema
      CONFIG.marca.nome = nome;
      CONFIG.marca.corPrimaria = cp;
      CONFIG.marca.corSecundaria = cs;
      try { document.documentElement.style.setProperty("--navy", cp); } catch (e) {}
      // redesenha a barra lateral (marca/nome) sem esperar reload
      try { var sw = UI.el("side-wrap"); if (sw && App._sidebar) sw.innerHTML = App._sidebar(); } catch (e2) {}
      if (global.Audit) global.Audit.log("config_marca_salvar", "config_escritorio", "cfg");
      UI.toast("Marca salva e aplicada.", "ok");
      App.render();
    },

    // ---- ABA PARÂMETROS ----
    _renderParametros: function () {
      var cur = cfgAtual();
      // custo efetivo = o MESMO que o BI usa: proxy 35% do valor do ponto quando não configurado,
      // senão o custo/ponto definido — para a margem prevista aqui bater com a margem do BI.
      var semCusto = cur.custoPorPonto == null;
      var custoEfetivo = semCusto ? (cur.valorPonto * 0.35) : cur.custoPorPonto;
      var margem = cur.valorPonto > 0 ? ((cur.valorPonto - custoEfetivo) / cur.valorPonto) * 100 : 0;
      var form =
        '<div class="card"><div class="card-hd"><b>Precificação por pontos de complexidade</b></div><div class="card-bd">' +
        '<div class="row">' +
        UI.campo("Valor do ponto (R$) — base do honorário", UI.inp("cfg-vp", Util.brNum(cur.valorPonto, 2), "0,00")) +
        UI.campo("Custo por ponto (R$) — para margem no BI", UI.inp("cfg-cpp", semCusto ? "" : Util.brNum(cur.custoPorPonto, 2), "auto: 35% do valor")) +
        "</div>" +
        '<div class="fld-d">' + (semCusto ? "Custo/ponto não definido — o BI usa <b>35% do valor do ponto</b> como proxy (" + Util.esc(Util.brMoeda(custoEfetivo)) + "/ponto). Deixe em branco para manter o automático. " : "") +
        "Margem estimada por ponto: <b>" + Util.esc(Util.brNum(margem, 0)) + "%</b> (mesma base do BI de rentabilidade).</div>" +
        "</div></div>" +
        '<div class="card"><div class="card-hd"><b>Dupla conferência (4 olhos)</b></div><div class="card-bd">' +
        UI.campo("Conferência obrigatória nas obrigações críticas", UI.sel("cfg-dupla", [{ v: "1", t: "Ativa" }, { v: "0", t: "Desligada" }], cur.duplaConferenciaAtiva ? "1" : "0")) +
        '<div class="fld-d">Quando ativa, obrigações críticas (' + Util.esc((cur.criticas || []).join(", ") || "—") + ') exigem um segundo analista antes de transmitir. Em escritório solo a conferência é dispensada automaticamente e auditada.</div>' +
        '<div class="toolbar"><button class="btn primary" data-acao="salvarParametros">' + UI.icone("check", 16) + " Salvar parâmetros</button></div>" +
        "</div></div>";
      return form;
    },

    salvarParametros: function () {
      if (this._guard()) return;
      var cur = cfgAtual();
      var vp = parseValor(UI.v("cfg-vp"));
      if (!(vp > 0)) { UI.toast("Informe um valor do ponto maior que zero.", "alerta"); return; }
      // custo/ponto: vazio = não configurado (null → BI usa proxy 35%); 0 é valor explícito válido
      var cppRaw = UI.v("cfg-cpp");
      var cpp = (cppRaw === "") ? null : parseValor(cppRaw);
      if (cpp != null && cpp < 0) { UI.toast("Custo por ponto não pode ser negativo.", "alerta"); return; }
      cur.valorPonto = vp;
      cur.custoPorPonto = cpp;
      cur.duplaConferenciaAtiva = UI.v("cfg-dupla") === "1";
      cur.atualizadoEm = Util.hojeISO();
      Store.salvar("config_escritorio", cur);
      // reflete em runtime (a régua de honorário, o BI de margem e o motor de 4 olhos leem do CONFIG)
      CONFIG.precificacao.valorPonto = vp;
      CONFIG.precificacao.custoPorPonto = cpp;
      CONFIG.duplaConferencia.ativa = cur.duplaConferenciaAtiva;
      if (global.Audit) global.Audit.log("config_parametros_salvar", "config_escritorio", "cfg");
      UI.toast("Parâmetros salvos.", "ok");
      App.render();
    },

    // ---- ABA MATRIZ (REGRA DE OURO) ----
    _renderMatriz: function () {
      var matriz = App.matriz || { versao: "—", obrigacoes: [] };
      var defs = matriz.obrigacoes || [];

      var aviso =
        '<div class="card"><div class="card-bd">' +
        '<div style="background:rgba(245,158,11,.12);border:1px solid ' + Util.esc(CONFIG.marca.corAmbar) + ';border-radius:10px;padding:12px 14px;color:inherit">' +
        "<b>⚠ A matriz é a fonte da agenda.</b> Edite com cuidado; confira sempre com a legislação vigente. " +
        "As alterações feitas aqui valem <b>nesta sessão</b> — a matriz base é o arquivo <code>" + Util.esc(CONFIG.matrizArquivo) + "</code>." +
        "</div></div></div>";

      var cols = [
        { k: "codigo", label: "Código", fmt: function (v) { return "<b>" + Util.esc(v || "—") + "</b>"; } },
        { k: "nome", label: "Nome", fmt: function (v) { return Util.esc(v || "—"); } },
        { k: "grupo", label: "Grupo", fmt: function (v) { return Util.esc(v || "—"); } },
        { k: "periodicidade", label: "Periodicidade", fmt: function (v) { return Util.esc(v || "—"); } },
        { k: "diaVenc", label: "Dia venc.", cls: "num", fmt: function (v) { return Util.esc(v == null ? "—" : v); } },
        { k: "aplica", label: "Aplica a", fmt: function (v) { return Util.esc(resumoAplica(v)); } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) {
            // índice real gravado em row._idx (UI.tabela não passa índice ao fmt)
            var i = row._idx;
            return '<button class="btn sm" data-acao="matrizEditar:' + i + '">Editar</button> ' +
              '<button class="btn sm danger" data-acao="matrizExcluir:' + i + '">✕</button>';
          } }
      ];
      var linhas = defs.map(function (d, i) { d._idx = i; return d; });
      var tbl = UI.tabela(cols, linhas, { vazio: "Matriz vazia. Adicione obrigações ou verifique o arquivo base." });

      var head =
        '<div class="card"><div class="card-hd"><b>Matriz de obrigações</b>' +
        '<span class="chip">versão ' + Util.esc(matriz.versao) + "</span>" +
        '<span class="chip">' + defs.length + " obrigação(ões)</span></div>" +
        '<div class="card-bd">' +
        '<div class="toolbar"><button class="btn green" data-acao="matrizAdd">' + UI.icone("plus", 16) + " Adicionar obrigação</button></div>" +
        tbl + "</div></div>";

      return aviso + head;
    },

    // Modal compartilhado de obrigação. idx undefined/"" -> nova; senão edita a posição.
    _modalObrig: function (idx) {
      var matriz = App.matriz || (App.matriz = { versao: "sessao", obrigacoes: [] });
      var editando = (idx !== undefined && idx !== "" && idx !== null);
      var pos = editando ? parseInt(idx, 10) : -1;
      var def = editando ? matriz.obrigacoes[pos] : null;
      if (editando && !def) { UI.toast("Obrigação não encontrada.", "erro"); return; }
      var a = (def && def.aplica) || {};
      var jaReg = {}; (a.regime || []).forEach(function (r) { jaReg[r] = 1; });

      var ckReg = CONFIG.regimes.map(function (r) {
        return '<label class="chip" style="display:inline-flex;align-items:center;gap:6px;margin:0 8px 6px 0;cursor:pointer">' +
          '<input type="checkbox" id="cfg-mx-reg-' + Util.esc(r.id) + '"' + (jaReg[r.id] ? " checked" : "") + "> " + Util.esc(r.nome) + "</label>";
      }).join("");

      var opsDepto = [{ v: "", t: "— sem departamento —" }];
      for (var i = 0; i < CONFIG.departamentos.length; i++) opsDepto.push({ v: CONFIG.departamentos[i].id, t: CONFIG.departamentos[i].nome });

      var corpo =
        '<div class="row">' +
        UI.campo("Código", UI.inp("cfg-mx-cod", def ? def.codigo : "", "ex.: DCTFWeb")) +
        UI.campo("Nome", UI.inp("cfg-mx-nome", def ? def.nome : "", "ex.: DCTFWeb mensal")) +
        "</div>" +
        '<div class="row-3">' +
        UI.campo("Grupo", UI.sel("cfg-mx-grupo", GRUPOS, def ? def.grupo : "federal")) +
        UI.campo("Departamento", UI.sel("cfg-mx-depto", opsDepto, def ? (def.departamento || "") : "")) +
        UI.campo("Periodicidade", UI.sel("cfg-mx-per", PERIODICIDADES, def ? def.periodicidade : "mensal")) +
        "</div>" +
        '<div class="row">' +
        UI.campo("Dia de vencimento (1-28)", UI.inp("cfg-mx-dia", def ? def.diaVenc : 20, "20", "number")) +
        UI.campo("Segmentos (separados por vírgula)", UI.inp("cfg-mx-seg", def ? (a.segmento || []).join(", ") : "", "ex.: saude, condominio")) +
        "</div>" +
        UI.campo("Regimes aplicáveis (vazio = todos)", '<div style="padding-top:4px">' + ckReg + "</div>");

      UI.modal(editando ? "Editar obrigação" : "Adicionar obrigação", corpo, [
        { txt: "Cancelar" },
        { txt: editando ? "Salvar alteração" : "Adicionar", classe: "primary", onClick: function (fechar) {
          if (!ehSocio()) { UI.toast("Só o sócio acessa as configurações.", "erro"); return; }
          var codigo = UI.v("cfg-mx-cod"), nome = UI.v("cfg-mx-nome");
          if (!codigo) { UI.toast("Informe o código da obrigação.", "alerta"); return; }
          if (!nome) { UI.toast("Informe o nome da obrigação.", "alerta"); return; }
          var dia = Math.round(parseValor(UI.v("cfg-mx-dia")));
          if (!(dia >= 1 && dia <= 28)) { UI.toast("Dia de vencimento deve estar entre 1 e 28.", "alerta"); return; }
          var regs = [];
          for (var j = 0; j < CONFIG.regimes.length; j++) {
            var e = UI.el("cfg-mx-reg-" + CONFIG.regimes[j].id);
            if (e && e.checked) regs.push(CONFIG.regimes[j].id);
          }
          var segRaw = UI.v("cfg-mx-seg");
          var segs = [];
          if (segRaw) {
            var parts = segRaw.split(",");
            for (var s = 0; s < parts.length; s++) { var t = parts[s].replace(/^\s+|\s+$/g, ""); if (t) segs.push(t); }
          }
          // Ao EDITAR, parte de uma cópia do def original e sobrescreve só os campos que o
          // formulário controla — senão editar uma obrigação da matriz base descartaria os
          // campos não expostos (mesRef, porUF, e filtros de aplica: temIE/temFuncionarios/
          // excluiRegime/excluiSegmento/atividadeServico/uf), corrompendo prazo/aplicabilidade
          // e gerando agenda errada ao re-sincronizar (risco de prazo perdido/multa).
          var nova = def ? Util.clone(def) : {};
          delete nova._idx; // prop de scratch da renderização, não faz parte da matriz
          nova.codigo = codigo;
          nova.nome = nome;
          nova.grupo = UI.v("cfg-mx-grupo") || "federal";
          nova.departamento = UI.v("cfg-mx-depto") || null;
          nova.periodicidade = UI.v("cfg-mx-per") || "mensal";
          nova.diaVenc = dia;
          nova.ajusteFeriado = nova.ajusteFeriado || "nenhum";
          nova.aplica = nova.aplica || {};
          if (regs.length) nova.aplica.regime = regs; else delete nova.aplica.regime;
          if (segs.length) nova.aplica.segmento = segs; else delete nova.aplica.segmento;
          if (editando) { App.matriz.obrigacoes[pos] = nova; }
          else { App.matriz.obrigacoes.push(nova); }
          if (global.Audit) global.Audit.log(editando ? "config_matriz_editar" : "config_matriz_add", "matriz", codigo);
          UI.toast((editando ? "Obrigação alterada" : "Obrigação adicionada") + " nesta sessão (a matriz base é o " + CONFIG.matrizArquivo + ").", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    matrizAdd: function () { if (this._guard()) return; this._modalObrig(undefined); },
    matrizEditar: function (idx) { if (this._guard()) return; this._modalObrig(idx); },

    matrizExcluir: function (idx) {
      if (this._guard()) return;
      var pos = parseInt(idx, 10);
      var matriz = App.matriz || { obrigacoes: [] };
      var def = matriz.obrigacoes[pos];
      if (!def) { UI.toast("Obrigação não encontrada.", "erro"); return; }
      UI.modal("Excluir obrigação",
        "<p>Remover <b>" + Util.esc(def.codigo) + "</b> — " + Util.esc(def.nome) + " da matriz <b>nesta sessão</b>? A matriz base (" + Util.esc(CONFIG.matrizArquivo) + ") não é alterada.</p>",
        [{ txt: "Cancelar" }, { txt: "Excluir", classe: "danger", onClick: function (fechar) {
          if (!ehSocio()) { UI.toast("Só o sócio acessa as configurações.", "erro"); return; }
          App.matriz.obrigacoes.splice(pos, 1);
          if (global.Audit) global.Audit.log("config_matriz_excluir", "matriz", def.codigo);
          UI.toast("Obrigação removida nesta sessão.", "ok");
          fechar(); App.render();
        } }]);
    },

    // ---- ABA USUÁRIOS ----
    _renderUsuarios: function () {
      var usuarios = Store.listar("usuarios");
      var equipe = usuarios.filter(function (u) { return u.ativo !== false; }).length;

      var cols = [
        { k: "nome", label: "Usuário", fmt: function (v) { return Util.esc(v || "—"); } },
        { k: "perfil", label: "Perfil", fmt: function (v) { return Util.esc((CONFIG.perfis[v] || {}).nome || v || "—"); } },
        { k: "capacidadePontos", label: "Capacidade (pts)", cls: "num", fmt: function (v) { return Util.esc(v == null ? "—" : v); } },
        { k: "carteiraClientes", label: "Carteira", cls: "num", fmt: function (v) { return Util.esc((v || []).length); } },
        { k: "ativo", label: "Status", fmt: function (v) { return v === false ? UI.badge("inativo", "cinza") : UI.badge("ativo", "verde"); } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) {
            return '<button class="btn sm" data-acao="toggleUsuario:' + Util.esc(row.id) + '">' + (row.ativo === false ? "Ativar" : "Desativar") + "</button>";
          } }
      ];
      var tbl = UI.tabela(cols, usuarios, { vazio: "Nenhum usuário cadastrado." });

      var dica = equipe >= 2
        ? '<div class="fld-d">Modo EQUIPE ativo (' + equipe + " usuários): a dupla conferência (4 olhos) exige preparador ≠ conferente.</div>"
        : '<div class="fld-d">Com apenas 1 usuário ativo o escritório está em modo SOLO — a conferência é dispensada automaticamente. Cadastre um 2º usuário para habilitar os 4 olhos.</div>';

      return '<div class="card"><div class="card-hd"><b>Equipe do escritório</b>' +
        '<span class="chip">' + usuarios.length + " usuário(s)</span></div>" +
        '<div class="card-bd">' +
        '<div class="toolbar"><button class="btn green" data-acao="novoUsuario">' + UI.icone("plus", 16) + " Novo usuário</button></div>" +
        tbl + dica + "</div></div>";
    },

    novoUsuario: function () {
      if (this._guard()) return;
      var opsPerfil = [];
      for (var k in CONFIG.perfis) if (CONFIG.perfis.hasOwnProperty(k)) opsPerfil.push({ v: k, t: CONFIG.perfis[k].nome });

      var clientes = Util.ordenaPor(Store.listar("clientes").map(function (c) { c._nome = nomeCliente(c); return c; }), "_nome");
      var optsCli = clientes.map(function (c) { return '<option value="' + Util.esc(c.id) + '">' + Util.esc(c._nome) + "</option>"; }).join("");
      var multiCli = clientes.length
        ? '<select id="cfg-us-cart" class="in" multiple size="6">' + optsCli + "</select>"
        : '<div class="fld-d">Nenhum cliente cadastrado ainda — a carteira pode ser atribuída depois.</div>';

      var corpo =
        UI.campo("Nome do usuário", UI.inp("cfg-us-nome", "", "ex.: Maria Analista")) +
        '<div class="row">' +
        UI.campo("Perfil", UI.sel("cfg-us-perfil", opsPerfil, "analista")) +
        UI.campo("Capacidade (pontos)", UI.inp("cfg-us-cap", 100, "100", "number")) +
        "</div>" +
        UI.campo("Carteira de clientes (opcional, seleção múltipla)", multiCli);

      UI.modal("Novo usuário", corpo, [
        { txt: "Cancelar" },
        { txt: "Cadastrar", classe: "primary", onClick: function (fechar) {
          if (!ehSocio()) { UI.toast("Só o sócio acessa as configurações.", "erro"); return; }
          var nome = UI.v("cfg-us-nome");
          if (!nome) { UI.toast("Informe o nome do usuário.", "alerta"); return; }
          var perfil = UI.v("cfg-us-perfil");
          if (!CONFIG.perfis[perfil]) { UI.toast("Perfil inválido.", "alerta"); return; }
          var cap = Math.round(parseValor(UI.v("cfg-us-cap")));
          if (cap < 0) cap = 0;
          var obj = {
            id: Util.uid("u"),
            nome: nome,
            perfil: perfil,
            departamento: null,
            email: "",
            carteiraClientes: lerMulti("cfg-us-cart"),
            capacidadePontos: cap,
            ativo: true,
            criadoEm: Util.hojeISO()
          };
          Store.salvar("usuarios", obj); // STORAGE_CHEIO -> delegação mostra toast
          if (global.Audit) global.Audit.log("config_usuario_criar", "usuarios", obj.id);
          UI.toast("Usuário cadastrado.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    toggleUsuario: function (id) {
      if (this._guard()) return;
      var u = Store.obter("usuarios", id);
      if (!u) { UI.toast("Usuário não encontrado.", "erro"); return; }
      // não deixa desativar o último sócio ativo (perderia o acesso às configurações)
      if (u.ativo !== false && u.perfil === "socio") {
        var socios = Store.listar("usuarios").filter(function (x) { return x.perfil === "socio" && x.ativo !== false; });
        if (socios.length <= 1) { UI.toast("Não é possível desativar o único sócio ativo.", "alerta"); return; }
      }
      u.ativo = (u.ativo === false);
      Store.salvar("usuarios", u);
      if (global.Audit) global.Audit.log(u.ativo ? "config_usuario_ativar" : "config_usuario_desativar", "usuarios", u.id);
      UI.toast(u.ativo ? "Usuário ativado." : "Usuário desativado.", "ok");
      App.render();
    },

    // ---- Navegação de abas ----
    aba: function (nome) {
      if (this._guard()) return;
      this._aba = nome;
      App.render();
    },

    // Liga a pré-visualização ao vivo da aba Marca (cores + nome atualizam na hora).
    onMount: function (el) {
      if (this._aba !== "marca") return;
      var cp = UI.el("cfg-cor-prim"), cs = UI.el("cfg-cor-sec"), nm = UI.el("cfg-nome");
      var pv = UI.el("cfg-preview"), logo = UI.el("cfg-preview-logo"), bt = UI.el("cfg-preview-bt"), nomeEl = UI.el("cfg-preview-nome");
      function updCores() {
        if (pv && cp) pv.style.background = cp.value;
        if (cs) { if (logo) logo.style.background = cs.value; if (bt) bt.style.background = cs.value; }
      }
      function updNome() {
        if (!nm) return;
        var val = nm.value || "";
        if (nomeEl) nomeEl.textContent = val || CONFIG.marca.nome;
        if (logo) logo.textContent = iniciais(val || CONFIG.marca.nome);
      }
      if (cp) cp.addEventListener("input", updCores);
      if (cs) cs.addEventListener("input", updCores);
      if (nm) nm.addEventListener("input", updNome);
    }
  });
})(window);
