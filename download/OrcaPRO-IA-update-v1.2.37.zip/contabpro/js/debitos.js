/* =====================================================================
 * debitos.js — Débitos & Parcelamentos (seção 3.10).
 * Duas coleções:
 *   "debitos"       = { id, clienteId, esfera, origem, tributo, valor,
 *                       situacao, obs, criadoEm }
 *   "parcelamentos" = { id, clienteId, esfera, modalidade, saldoTotal,
 *                       numParcelas, valorParcela, diaVenc(1-28),
 *                       inicio(competência "2026-07"), status,
 *                       parcelasPagas, criadoEm }
 *
 * SINCRONIZA COM A AGENDA: cada parcela FUTURA de um parcelamento ATIVO vira
 * uma obrigação mensal na coleção "obrigacoes" (código "PARCELA", depto fiscal),
 * com id determinístico "parc_"+parcId+"|"+competência — idempotente. Assim a
 * parcela aparece como prazo na Torre de Controle. Ao dar baixa numa parcela, a
 * obrigação correspondente é concluída com comprovante {tipo:"pagamento_parcela"}.
 *
 * Registrada como id "debitos" (bate com CONFIG.modulos e Auth.pode).
 * ES5 estrito (var/function/concat). Orquestra Store + Auth + UI + App.
 * ===================================================================== */
(function (global) {
  "use strict";
  var Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  // ---------- Tabelas de domínio ----------
  var ESFERAS = [
    { v: "federal",   t: "Federal" },
    { v: "estadual",  t: "Estadual" },
    { v: "municipal", t: "Municipal" },
    { v: "fgts",      t: "FGTS" }
  ];
  var SITUACOES = [
    { v: "exigivel",     t: "Exigível" },
    { v: "suspenso",     t: "Suspenso" },
    { v: "parcelado",    t: "Parcelado" },
    { v: "divida_ativa", t: "Dívida ativa" },
    { v: "protestado",   t: "Protestado" }
  ];
  var MODALIDADES = [
    { v: "convencional",   t: "Convencional" },
    { v: "transacao_pgfn", t: "Transação PGFN" },
    { v: "transacao_rfb",  t: "Transação RFB" },
    { v: "refis",          t: "REFIS/Especial" },
    { v: "estadual",       t: "Parcelamento estadual" },
    { v: "municipal",      t: "Parcelamento municipal" }
  ];
  var STATUS_PARC = [
    { v: "ativo",      t: "Ativo" },
    { v: "quitado",    t: "Quitado" },
    { v: "rescindido", t: "Rescindido" }
  ];

  // Situações que contam como débito EXIGÍVEL (risco real de execução).
  var EXIGIVEIS = { exigivel: 1, divida_ativa: 1, protestado: 1 };

  // ---------- Helpers puros (closure do módulo) ----------

  // Padrão de nome entre telas; null-safe (cliente pode ter sido excluído).
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(cliente excluído)"; }
  function idUsuario() { var u = Auth.usuario(); return u ? u.id : null; }
  function rotulo(tabela, v) { for (var i = 0; i < tabela.length; i++) if (tabela[i].v === v) return tabela[i].t; return v || "—"; }
  function esferaLabel(v) { return rotulo(ESFERAS, v); }
  function modalidadeLabel(v) { return rotulo(MODALIDADES, v); }

  // parseValor: aceita "1.500,00" -> 1500 E "1500.00" -> 1500.
  // Sem o guard do decimal-ponto, o parseBR trataria o ponto como milhar
  // e salvaria um valor 100x maior sem aviso.
  function parseValor(raw) {
    raw = String(raw == null ? "" : raw).trim();
    if (/^\d+\.\d{1,2}$/.test(raw)) raw = raw.replace(".", ",");
    return Util.parseBR(raw);
  }

  function esferaBadge(v) {
    if (v === "federal") return UI.badge("Federal", "azul");
    if (v === "estadual") return UI.badge("Estadual", "roxo");
    if (v === "municipal") return UI.badge("Municipal", "cinza");
    if (v === "fgts") return UI.badge("FGTS", "amber");
    return UI.badge(esferaLabel(v), "cinza");
  }
  function modalidadeBadge(v) { return UI.badge(modalidadeLabel(v), "azul"); }
  function situacaoBadge(v) {
    if (v === "exigivel") return UI.badge("Exigível", "vermelho");
    if (v === "suspenso") return UI.badge("Suspenso", "amber");
    if (v === "parcelado") return UI.badge("Parcelado", "azul");
    if (v === "divida_ativa") return UI.badge("DÍVIDA ATIVA", "vermelho");
    if (v === "protestado") return UI.badge("Protestado", "vermelho");
    return UI.badge(rotulo(SITUACOES, v), "cinza");
  }

  // ---- Cálculo de vencimento das parcelas ----
  // Parcela n (1-based) vence em: inicio (competência) + (n-1) meses, no dia diaVenc.
  function vencParcela(parc, n) {
    var p = Util.partes(String(parc.inicio || "") + "-01");
    if (!p.y) return null;
    var d = new Date(Date.UTC(p.y, p.m - 1 + (n - 1), 1));
    var vy = d.getUTCFullYear(), vm = d.getUTCMonth() + 1;
    var dia = Math.min(Math.max(1, parc.diaVenc || 1), Util.ultimoDia(vy, vm));
    return Util.iso(vy, vm, dia);
  }
  // Próxima parcela em aberto = parcelasPagas + 1 (só faz sentido se < numParcelas).
  function proxNumParcela(parc) { return (parc.parcelasPagas || 0) + 1; }
  function temProxima(parc) { return (parc.parcelasPagas || 0) < (parc.numParcelas || 0); }
  function proxVenc(parc) { return temProxima(parc) ? vencParcela(parc, proxNumParcela(parc)) : null; }
  // Saldo devedor restante = parcelas em aberto × valor da parcela.
  function saldoRestante(parc) {
    var restantes = Math.max(0, (parc.numParcelas || 0) - (parc.parcelasPagas || 0));
    return restantes * (Number(parc.valorParcela) || 0);
  }
  // Risco de rescisão: parcelamento ATIVO cuja próxima parcela já venceu.
  function parcelaVencida(parc) {
    if (parc.status !== "ativo" || !temProxima(parc)) return false;
    var v = proxVenc(parc); if (!v) return false;
    var d = Util.diasAte(v);
    return d != null && d < 0;
  }

  // ---- Sincronização com a Agenda (coleção "obrigacoes") ----
  function obrigParcId(parcId, comp) { return "parc_" + parcId + "|" + comp; }

  // Monta (ou recupera) a obrigação-parcela n. Preserva status/comprovante/histórico
  // se já existir (não regride uma parcela concluída).
  function obrigacaoParcelaBase(parc, n) {
    var venc = vencParcela(parc, n);
    var p = Util.partes(venc);
    var comp = Util.competencia(p.y, p.m);
    var id = obrigParcId(parc.id, comp);
    var base = Store.obter("obrigacoes", id);
    if (!base) base = { id: id, status: "pendente", historico: [{ status: "pendente", quando: Util.hojeISO() }] };
    base.clienteId = parc.clienteId;
    base.codigo = "PARCELA";
    base.parcelamentoId = parc.id;
    base.parcelaNum = n;
    base.uf = null;
    base.nome = "Parcela " + n + "/" + (parc.numParcelas || 0) + " — " + modalidadeLabel(parc.modalidade);
    base.grupo = "federal";
    base.departamento = "fiscal";
    base.competencia = comp;
    base.prazoLegal = venc;
    base.prazoAjustado = venc;
    if (!base.historico) base.historico = [{ status: base.status || "pendente", quando: Util.hojeISO() }];
    return base;
  }

  // Cria/atualiza as obrigações das parcelas FUTURAS (só ativo) e limpa as obsoletas.
  // Idempotente via id determinístico + salvarLote. NUNCA mexe em parcela concluída (histórico).
  function sincronizarAgenda(parc) {
    var total = parc.numParcelas || 0, pagas = parc.parcelasPagas || 0;
    var ativo = parc.status === "ativo";
    var novas = [], validos = {}, n, ob, da;

    if (ativo) {
      for (n = pagas + 1; n <= total; n++) {
        var venc = vencParcela(parc, n);
        if (!venc) break;
        da = Util.diasAte(venc);
        if (da != null && da < 0) continue; // parcela já vencida não gera novo prazo (o card de Risco sinaliza)
        ob = obrigacaoParcelaBase(parc, n);
        validos[ob.id] = 1;
        if (ob.status === "concluida") continue; // já paga: preserva, não reenvia
        novas.push(ob);
      }
    }
    // Remove obrigações-parcela obsoletas deste parcelamento (inicio/nº/dia mudou, ou virou
    // quitado/rescindido). Concluídas ficam como histórico.
    var todas = Store.listar("obrigacoes");
    for (var i = 0; i < todas.length; i++) {
      var o = todas[i];
      if (o.codigo !== "PARCELA" || o.parcelamentoId !== parc.id) continue;
      if (o.status === "concluida") continue;
      if (!validos[o.id]) Store.excluir("obrigacoes", o.id);
    }
    if (novas.length) Store.salvarLote("obrigacoes", novas); // STORAGE_CHEIO -> delegação mostra toast
  }

  // Remove as obrigações-parcela pendentes de um parcelamento (ao excluí-lo).
  function removerObrigacoesParc(parcId) {
    var todas = Store.listar("obrigacoes");
    for (var i = 0; i < todas.length; i++) {
      var o = todas[i];
      if (o.codigo === "PARCELA" && o.parcelamentoId === parcId && o.status !== "concluida") Store.excluir("obrigacoes", o.id);
    }
  }

  // Competência exibível "2026-07" -> "jul/2026".
  function compRotulo(comp) { var p = Util.partes(String(comp || "") + "-01"); return p.y ? (Util.mesNome(p.m) + "/" + p.y) : "—"; }

  // Célula "Próx. venc." (só faz sentido em parcelamento ativo com parcela em aberto).
  function proxVencCel(parc) {
    if (parc.status !== "ativo" || !temProxima(parc)) return '<span style="color:#94a3b8">—</span>';
    var v = proxVenc(parc);
    var txt = '<span style="white-space:nowrap">' + Util.esc(Util.brData(v)) + "</span>";
    var d = Util.diasAte(v);
    if (d != null) {
      if (d < 0) return txt + " " + UI.badge((-d) + "d atraso", "vermelho");
      if (d === 0) return txt + " " + UI.badge("hoje", "amber");
      if (d <= 7) return txt + " " + UI.badge("em " + d + "d", "amber");
    }
    return txt;
  }

  // Célula "Risco" (o coração deste módulo).
  function riscoCel(parc) {
    if (parc.status === "quitado") return UI.badge("Quitado ✓", "verde");
    if (parc.status === "rescindido") return UI.badge("Rescindido", "vermelho");
    if (!temProxima(parc)) return UI.badge("Quitado ✓", "verde");
    if (parcelaVencida(parc)) return UI.badge("⚠ RISCO DE RESCISÃO — perde o benefício", "vermelho");
    return UI.badge("em dia", "verde");
  }

  // ---------- View ----------
  global.DebitosView = App.registrar({
    id: "debitos",
    titulo: "Débitos & Parcelamentos",

    render: function () {
      if (!this._filtros) this._filtros = { cliente: "" };
      var f = this._filtros;
      // filtro fantasma: cliente filtrado foi excluído -> volta pra "todos"
      if (f.cliente && !Store.obter("clientes", f.cliente)) f.cliente = "";

      // Clientes visíveis (respeita carteira do analista).
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      var setVis = {}, nomeCli = {}, i;
      for (i = 0; i < visiveis.length; i++) { setVis[visiveis[i].id] = 1; nomeCli[visiveis[i].id] = nomeCliente(visiveis[i]); }
      function nomeDe(id) { return nomeCli[id] || "(cliente excluído)"; }

      // Débitos e parcelamentos só de clientes visíveis + filtro de cliente.
      var todosDeb = Store.listar("debitos"), debs = [];
      for (i = 0; i < todosDeb.length; i++) {
        if (!setVis[todosDeb[i].clienteId]) continue;
        if (f.cliente && todosDeb[i].clienteId !== f.cliente) continue;
        debs.push(todosDeb[i]);
      }
      var todosParc = Store.listar("parcelamentos"), parcs = [];
      for (i = 0; i < todosParc.length; i++) {
        if (!setVis[todosParc[i].clienteId]) continue;
        if (f.cliente && todosParc[i].clienteId !== f.cliente) continue;
        parcs.push(todosParc[i]);
      }

      // ---- KPIs ----
      var totalExig = 0, nAtivos = 0, nAtraso = 0, saldoParc = 0;
      debs.forEach(function (d) { if (EXIGIVEIS[d.situacao]) totalExig += Number(d.valor) || 0; });
      parcs.forEach(function (p) {
        if (p.status === "ativo") {
          nAtivos++;
          saldoParc += saldoRestante(p);
          if (parcelaVencida(p)) nAtraso++;
        }
      });

      var kpis = '<div class="grid-kpi">' +
        '<div class="kpi ' + (totalExig ? "al" : "") + '"><div class="n">' + Util.esc(Util.brMoeda(totalExig)) + '</div><div class="l">Débitos exigíveis</div></div>' +
        '<div class="kpi"><div class="n">' + nAtivos + '</div><div class="l">Parcelamentos ativos</div></div>' +
        '<div class="kpi ' + (nAtraso ? "al" : "") + '"><div class="n">' + nAtraso + '</div><div class="l">Parcelas em atraso (risco)</div></div>' +
        '<div class="kpi ' + (saldoParc ? "wr" : "") + '"><div class="n">' + Util.esc(Util.brMoeda(saldoParc)) + '</div><div class="l">Saldo parcelado em aberto</div></div>' +
        "</div>";

      // ---- Toolbar: filtro de cliente + ações ----
      var opCli = [{ v: "", t: "Todos os clientes" }];
      for (i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });

      var podeCriar = Auth.pode("debitos", "criar");
      var toolbar = '<div class="toolbar">' +
        UI.sel("deb-f-cli", opCli, f.cliente) +
        (podeCriar ? '<button class="btn primary" data-acao="novoDebito">' + UI.icone("plus", 16) + ' Novo débito</button>' : "") +
        (podeCriar ? '<button class="btn green" data-acao="novoParc">' + UI.icone("plus", 16) + ' Novo parcelamento</button>' : "") +
        '<button class="btn" data-acao="simulador">🧮 Simular transação</button>' +
        "</div>";

      // ---- Card A: Inventário de débitos ----
      var rowsDeb = debs.map(function (d) {
        return { _cli: nomeDe(d.clienteId), esfera: d.esfera, tributo: d.tributo, valor: d.valor, situacao: d.situacao, _deb: d };
      });
      rowsDeb.sort(function (a, b) { return a._cli < b._cli ? -1 : (a._cli > b._cli ? 1 : 0); });
      var podeExcluir = Auth.pode("debitos", "excluir");
      var colsDeb = [
        { k: "_cli", label: "Cliente", fmt: function (v) { return Util.esc(v); } },
        { k: "esfera", label: "Esfera", fmt: function (v) { return esferaBadge(v); } },
        { k: "tributo", label: "Tributo", fmt: function (v) { return Util.esc(v || "—"); } },
        { k: "valor", label: "Valor", cls: "num", fmt: function (v) { return Util.esc(Util.brMoeda(v)); } },
        { k: "situacao", label: "Situação", fmt: function (v) { return situacaoBadge(v); } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) {
          var out = '<button class="btn sm" data-acao="editarDebito:' + Util.esc(row._deb.id) + '">Editar</button>';
          if (podeExcluir) out += ' <button class="btn sm danger" data-acao="excluirDebito:' + Util.esc(row._deb.id) + '">✕</button>';
          return out;
        } }
      ];
      var tblDeb = UI.tabela(colsDeb, rowsDeb, { vazio: "Nenhum débito registrado para os filtros atuais." });

      // ---- Card B: Parcelamentos (ativos em primeiro, depois quitados/rescindidos) ----
      var rowsParc = parcs.map(function (p) {
        return {
          _cli: nomeDe(p.clienteId), modalidade: p.modalidade, _saldo: saldoRestante(p),
          _parc: (p.parcelasPagas || 0) + "/" + (p.numParcelas || 0), valorParcela: p.valorParcela,
          _ativo: p.status === "ativo" ? 0 : 1, _p: p
        };
      });
      rowsParc.sort(function (a, b) { if (a._ativo !== b._ativo) return a._ativo - b._ativo; return a._cli < b._cli ? -1 : (a._cli > b._cli ? 1 : 0); });
      var colsParc = [
        { k: "_cli", label: "Cliente", fmt: function (v) { return Util.esc(v); } },
        { k: "modalidade", label: "Modalidade", fmt: function (v) { return modalidadeBadge(v); } },
        { k: "_saldo", label: "Saldo", cls: "num", fmt: function (v) { return Util.esc(Util.brMoeda(v)); } },
        { k: "_parc", label: "Parcelas", cls: "ctr", fmt: function (v) { return Util.esc(v); } },
        { k: "valorParcela", label: "Valor parcela", cls: "num", fmt: function (v) { return Util.esc(Util.brMoeda(v)); } },
        { k: "_prox", label: "Próx. venc.", fmt: function (v, row) { return proxVencCel(row._p); } },
        { k: "_risco", label: "Risco", fmt: function (v, row) { return riscoCel(row._p); } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) {
          var p = row._p, out = "";
          if (p.status === "ativo" && temProxima(p)) out += '<button class="btn sm green" data-acao="registrarPagamento:' + Util.esc(p.id) + '">Pagar parcela</button> ';
          out += '<button class="btn sm" data-acao="editarParc:' + Util.esc(p.id) + '">Editar</button>';
          if (podeExcluir) out += ' <button class="btn sm danger" data-acao="excluirParc:' + Util.esc(p.id) + '">✕</button>';
          return out;
        } }
      ];
      var tblParc = UI.tabela(colsParc, rowsParc, { vazio: "Nenhum parcelamento registrado para os filtros atuais." });

      var aviso = podeCriar ? "" : '<span class="chip">Somente leitura: seu perfil não registra débitos/parcelamentos</span>';

      return '<div class="page-hd"><div><h1>Débitos & Parcelamentos</h1>' +
        '<div class="sub">Inventário de débitos por esfera e controle de parcelamentos — com alerta de risco de rescisão e integração com a Agenda.</div></div>' +
        '<div>' + aviso + "</div></div>" +
        kpis + toolbar +
        '<div class="card"><div class="card-hd"><b>Inventário de débitos</b>' +
        '<span class="chip">' + debs.length + ' item(ns)</span></div>' +
        '<div class="card-bd">' + tblDeb + "</div></div>" +
        '<div class="card"><div class="card-hd"><b>Parcelamentos ativos</b>' +
        '<span class="chip">' + nAtivos + ' ativo(s) · ' + parcs.length + ' no total</span></div>' +
        '<div class="card-bd">' + tblParc + "</div></div>";
    },

    // Liga o filtro de cliente (change -> guarda estado + re-render).
    onMount: function () {
      var self = this, e = UI.el("deb-f-cli");
      if (e) e.addEventListener("change", function () { self._filtros.cliente = e.value; App.render(); });
    },

    // ================= DÉBITOS =================

    novoDebito: function () {
      if (!Auth.pode("debitos", "criar")) { UI.toast("Sem permissão para registrar débitos.", "erro"); return; }
      this._modalDebito(null);
    },
    editarDebito: function (id) {
      if (!Auth.pode("debitos", "editar")) { UI.toast("Sem permissão para editar débitos.", "erro"); return; }
      var d = Store.obter("debitos", id);
      if (!d) { UI.toast("Débito não encontrado.", "erro"); return; }
      this._modalDebito(d);
    },

    _modalDebito: function (deb) {
      var novo = !deb;
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      if (novo && !visiveis.length) { UI.toast("Cadastre um cliente antes de registrar débitos.", "info"); return; }
      var opCli = [{ v: "", t: "— selecione o cliente —" }];
      for (var i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });

      var corpo =
        UI.campo("Cliente", UI.sel("deb-cli", opCli, deb ? deb.clienteId : "")) +
        '<div class="row">' +
        UI.campo("Esfera", UI.sel("deb-esfera", ESFERAS, deb ? deb.esfera : "federal")) +
        UI.campo("Situação", UI.sel("deb-sit", SITUACOES, deb ? deb.situacao : "exigivel")) +
        "</div>" +
        '<div class="row">' +
        UI.campo("Tributo", UI.inp("deb-trib", deb ? deb.tributo : "", "ex.: IRPJ, ICMS, INSS, DAS")) +
        UI.campo("Valor (R$)", UI.inp("deb-valor", deb ? Util.brNum(deb.valor, 2) : "", "0,00")) +
        "</div>" +
        UI.campo("Origem", UI.inp("deb-origem", deb ? deb.origem : "", "ex.: Auto de infração nº..., DAS em atraso, notificação")) +
        UI.campo("Observações", UI.inp("deb-obs", deb ? deb.obs : "", "detalhes, nº do processo, pendência")) +
        '<div class="fld-d">Débitos exigíveis, em dívida ativa ou protestados entram no total de risco (KPI).</div>';

      UI.modal(novo ? "Novo débito" : "Editar débito", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "primary", onClick: function (fechar) {
          if (!Auth.pode("debitos", novo ? "criar" : "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var clienteId = UI.v("deb-cli");
          if (!clienteId) { UI.toast("Selecione o cliente.", "alerta"); return; }
          var tributo = UI.v("deb-trib");
          if (!tributo) { UI.toast("Informe o tributo.", "alerta"); return; }
          var valor = parseValor(UI.v("deb-valor"));
          if (!(valor > 0)) { UI.toast("Informe um valor maior que zero.", "alerta"); return; }
          var obj = {
            id: deb ? deb.id : Util.uid("deb"),
            clienteId: clienteId,
            esfera: UI.v("deb-esfera"),
            origem: UI.v("deb-origem"),
            tributo: tributo,
            valor: valor,
            situacao: UI.v("deb-sit"),
            obs: UI.v("deb-obs"),
            criadoEm: deb ? (deb.criadoEm || Util.hojeISO()) : Util.hojeISO()
          };
          Store.salvar("debitos", obj); // STORAGE_CHEIO -> ui.js mostra toast
          if (global.Audit) global.Audit.log(novo ? "debito_criar" : "debito_editar", "debitos", obj.id);
          UI.toast("Débito salvo.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    excluirDebito: function (id) {
      if (!Auth.pode("debitos", "excluir")) { UI.toast("Sem permissão para excluir débitos.", "erro"); return; }
      var d = Store.obter("debitos", id);
      if (!d) { UI.toast("Débito não encontrado.", "erro"); return; }
      var cli = Store.obter("clientes", d.clienteId);
      UI.modal("Excluir débito",
        "<p>Excluir o débito de <b>" + Util.esc(d.tributo || "—") + "</b> (" + Util.esc(esferaLabel(d.esfera)) +
        ", " + Util.esc(Util.brMoeda(d.valor)) + ") de <b>" + Util.esc(nomeCliente(cli)) + "</b>?</p>",
        [{ txt: "Cancelar" }, { txt: "Excluir", classe: "danger", onClick: function (fechar) {
          if (!Auth.pode("debitos", "excluir")) { UI.toast("Sem permissão.", "erro"); return; }
          Store.excluir("debitos", id);
          if (global.Audit) global.Audit.log("debito_excluir", "debitos", id);
          UI.toast("Débito excluído.", "ok");
          fechar(); App.render();
        } }]);
    },

    // ================= PARCELAMENTOS =================

    novoParc: function () {
      if (!Auth.pode("debitos", "criar")) { UI.toast("Sem permissão para registrar parcelamentos.", "erro"); return; }
      this._modalParc(null);
    },
    editarParc: function (id) {
      if (!Auth.pode("debitos", "editar")) { UI.toast("Sem permissão para editar parcelamentos.", "erro"); return; }
      var p = Store.obter("parcelamentos", id);
      if (!p) { UI.toast("Parcelamento não encontrado.", "erro"); return; }
      this._modalParc(p);
    },

    _modalParc: function (parc) {
      var novo = !parc;
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      if (novo && !visiveis.length) { UI.toast("Cadastre um cliente antes de registrar parcelamentos.", "info"); return; }
      var opCli = [{ v: "", t: "— selecione o cliente —" }];
      for (var i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });

      var hp = Util.partes(Util.hojeISO()), compAtual = Util.competencia(hp.y, hp.m);

      var corpo =
        UI.campo("Cliente", UI.sel("parc-cli", opCli, parc ? parc.clienteId : "")) +
        '<div class="row">' +
        UI.campo("Esfera", UI.sel("parc-esfera", ESFERAS, parc ? parc.esfera : "federal")) +
        UI.campo("Modalidade", UI.sel("parc-mod", MODALIDADES, parc ? parc.modalidade : "convencional")) +
        "</div>" +
        '<div class="row-3">' +
        UI.campo("Saldo total (R$)", UI.inp("parc-saldo", parc ? Util.brNum(parc.saldoTotal, 2) : "", "0,00")) +
        UI.campo("Nº de parcelas", UI.inp("parc-num", parc ? parc.numParcelas : "", "60", "number")) +
        UI.campo("Valor da parcela (R$)", UI.inp("parc-vparc", parc ? Util.brNum(parc.valorParcela, 2) : "", "auto"), "vazio = saldo ÷ nº parcelas") +
        "</div>" +
        '<div class="row-3">' +
        UI.campo("Dia de vencimento (1-28)", UI.inp("parc-dia", parc ? parc.diaVenc : 20, "20", "number")) +
        UI.campo("Início (competência)", UI.inp("parc-inicio", parc ? parc.inicio : compAtual, "", "month")) +
        UI.campo("Parcelas já pagas", UI.inp("parc-pagas", parc ? (parc.parcelasPagas || 0) : 0, "0", "number")) +
        "</div>" +
        UI.campo("Status", UI.sel("parc-status", STATUS_PARC, parc ? parc.status : "ativo")) +
        '<div class="fld-d">Parcelamento ativo envia as parcelas FUTURAS para a Agenda de Obrigações (prazos na Torre de Controle).</div>';

      var ov = UI.modal(novo ? "Novo parcelamento" : "Editar parcelamento", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "primary", onClick: function (fechar) {
          if (!Auth.pode("debitos", novo ? "criar" : "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var clienteId = UI.v("parc-cli");
          if (!clienteId) { UI.toast("Selecione o cliente.", "alerta"); return; }
          var saldo = parseValor(UI.v("parc-saldo"));
          if (!(saldo > 0)) { UI.toast("Informe o saldo total (maior que zero).", "alerta"); return; }
          var num = Math.round(Util.parseBR(UI.v("parc-num")));
          if (!(num >= 1)) { UI.toast("Nº de parcelas deve ser 1 ou mais.", "alerta"); return; }
          var vraw = UI.v("parc-vparc");
          var vparc = vraw ? parseValor(vraw) : (saldo / num);
          if (!(vparc > 0)) { UI.toast("Informe um valor de parcela maior que zero.", "alerta"); return; }
          var dia = Math.round(Util.parseBR(UI.v("parc-dia")));
          if (!(dia >= 1 && dia <= 28)) { UI.toast("Dia de vencimento deve estar entre 1 e 28.", "alerta"); return; }
          var inicio = UI.v("parc-inicio");
          if (!/^\d{4}-\d{2}$/.test(inicio)) { UI.toast("Informe a competência de início (mês/ano).", "alerta"); return; }
          var pagas = Math.round(Util.parseBR(UI.v("parc-pagas"))) || 0;
          if (pagas < 0) pagas = 0;
          if (pagas > num) { UI.toast("Parcelas pagas não pode exceder o total.", "alerta"); return; }
          var status = UI.v("parc-status");

          var obj = {
            id: parc ? parc.id : Util.uid("parc"),
            clienteId: clienteId,
            esfera: UI.v("parc-esfera"),
            modalidade: UI.v("parc-mod"),
            saldoTotal: saldo,
            numParcelas: num,
            valorParcela: vparc,
            diaVenc: dia,
            inicio: inicio,
            status: status,
            parcelasPagas: pagas,
            criadoEm: parc ? (parc.criadoEm || Util.hojeISO()) : Util.hojeISO()
          };
          Store.salvar("parcelamentos", obj); // STORAGE_CHEIO -> ui.js mostra toast
          sincronizarAgenda(obj);             // parcelas futuras -> Agenda (idempotente)
          if (global.Audit) global.Audit.log(novo ? "parcelamento_criar" : "parcelamento_editar", "parcelamentos", obj.id);
          UI.toast("Parcelamento salvo." + (status === "ativo" ? " Parcelas futuras enviadas à Agenda." : ""), "ok");
          fechar(); App.render();
        } }
      ]);

      // Prefill do valor da parcela = saldo ÷ nº parcelas (só enquanto o campo estiver vazio).
      if (ov) {
        var recalc = function () {
          var vp = ov.querySelector("#parc-vparc"); if (!vp || vp.value.trim()) return;
          var s = parseValor(ov.querySelector("#parc-saldo").value);
          var np = Math.round(Util.parseBR(ov.querySelector("#parc-num").value));
          if (s > 0 && np >= 1) vp.value = Util.brNum(s / np, 2);
        };
        var s = ov.querySelector("#parc-saldo"), np = ov.querySelector("#parc-num");
        if (s) s.addEventListener("input", recalc);
        if (np) np.addEventListener("input", recalc);
      }
    },

    // Baixa da próxima parcela: incrementa parcelasPagas (não passa do total), conclui a
    // obrigação-parcela na Agenda e, ao atingir o total, marca o parcelamento como quitado.
    registrarPagamento: function (id) {
      if (!Auth.pode("debitos", "editar")) { UI.toast("Sem permissão para dar baixa em parcelas.", "erro"); return; }
      var parc = Store.obter("parcelamentos", id);
      if (!parc) { UI.toast("Parcelamento não encontrado.", "erro"); return; }
      if (parc.status !== "ativo") { UI.toast("Só parcelamentos ativos recebem baixa de parcela.", "alerta"); return; }
      var total = parc.numParcelas || 0, pagas = parc.parcelasPagas || 0;
      if (pagas >= total) { UI.toast("Todas as parcelas já foram pagas.", "info"); return; }
      var proxNum = pagas + 1, hoje = Util.hojeISO();

      // Conclui a obrigação-parcela correspondente (comprovante de pagamento).
      var ob = obrigacaoParcelaBase(parc, proxNum);
      ob.status = "concluida";
      ob.semMovimento = false;
      ob.comprovante = { tipo: "pagamento_parcela", protocolo: "Parcela " + proxNum + "/" + total, quando: hoje, por: idUsuario() };
      (ob.historico = ob.historico || []).push({ status: "concluida", quando: hoje, por: idUsuario() });
      Store.salvar("obrigacoes", ob);

      // Incrementa e, se chegou ao fim, quita.
      parc.parcelasPagas = proxNum;
      var quitou = parc.parcelasPagas >= total;
      if (quitou) parc.status = "quitado";
      Store.salvar("parcelamentos", parc);
      sincronizarAgenda(parc); // gera/limpa as próximas parcelas na Agenda

      if (global.Audit) global.Audit.log(quitou ? "parcelamento_quitado" : "parcelamento_pagar_parcela", "parcelamentos", parc.id);
      UI.toast(quitou
        ? "Parcela " + proxNum + "/" + total + " paga — parcelamento QUITADO! 🎉"
        : "Parcela " + proxNum + "/" + total + " registrada como paga.", "ok");
      App.render();
    },

    excluirParc: function (id) {
      if (!Auth.pode("debitos", "excluir")) { UI.toast("Sem permissão para excluir parcelamentos.", "erro"); return; }
      var p = Store.obter("parcelamentos", id);
      if (!p) { UI.toast("Parcelamento não encontrado.", "erro"); return; }
      var cli = Store.obter("clientes", p.clienteId);
      UI.modal("Excluir parcelamento",
        "<p>Excluir o parcelamento <b>" + Util.esc(modalidadeLabel(p.modalidade)) + "</b> de <b>" + Util.esc(nomeCliente(cli)) +
        "</b> (" + Util.esc((p.parcelasPagas || 0) + "/" + (p.numParcelas || 0)) + " parcelas)? As parcelas futuras saem da Agenda.</p>",
        [{ txt: "Cancelar" }, { txt: "Excluir", classe: "danger", onClick: function (fechar) {
          if (!Auth.pode("debitos", "excluir")) { UI.toast("Sem permissão.", "erro"); return; }
          Store.excluir("parcelamentos", id);
          removerObrigacoesParc(id); // limpa prazos-parcela pendentes na Agenda
          if (global.Audit) global.Audit.log("parcelamento_excluir", "parcelamentos", id);
          UI.toast("Parcelamento excluído.", "ok");
          fechar(); App.render();
        } }]);
    },

    // Simulador de transação (consultivo — NÃO grava). Desconto% × entrada% × prazo.
    simulador: function () {
      var corpo =
        '<p class="fld-d" style="margin-bottom:12px">Simulação orientativa de uma proposta de transação/parcelamento. Não substitui a proposta oficial do órgão e nada é gravado.</p>' +
        '<div class="row">' +
        UI.campo("Valor do débito (R$)", UI.inp("sim-valor", "", "0,00")) +
        UI.campo("Desconto (%)", UI.inp("sim-desc", "", "ex.: 50", "number")) +
        "</div>" +
        '<div class="row">' +
        UI.campo("Entrada (%)", UI.inp("sim-entrada", "", "ex.: 6", "number")) +
        UI.campo("Prazo (nº parcelas)", UI.inp("sim-prazo", "", "ex.: 120", "number")) +
        "</div>" +
        '<div id="sim-out" class="card-bd" style="margin-top:8px;padding:12px;border:1px solid #cbd5e1;border-radius:8px">Preencha os campos para ver a simulação.</div>';

      var ov = UI.modal("Simular transação", corpo, [{ txt: "Fechar" }]);
      if (!ov) return;
      var out = ov.querySelector("#sim-out");
      function recalc() {
        var valor = parseValor(ov.querySelector("#sim-valor").value);
        var desc = Util.parseBR(ov.querySelector("#sim-desc").value);
        var ent = Util.parseBR(ov.querySelector("#sim-entrada").value);
        var prazo = Math.round(Util.parseBR(ov.querySelector("#sim-prazo").value));
        if (!(valor > 0) || !(prazo >= 1)) { out.innerHTML = "Informe um valor (&gt; 0) e um prazo (&ge; 1) para calcular."; return; }
        if (desc < 0) desc = 0; if (desc > 100) desc = 100;
        if (ent < 0) ent = 0; if (ent > 100) ent = 100;
        var comDesconto = valor * (1 - desc / 100);
        var entradaVal = comDesconto * (ent / 100);
        var saldo = comDesconto - entradaVal;
        var parcela = saldo / prazo;
        var economia = valor - comDesconto;
        out.innerHTML =
          '<table style="width:100%;border-collapse:collapse;font-size:13px">' +
          '<tr><td style="padding:4px 0">Valor original</td><td class="dir" style="text-align:right">' + Util.esc(Util.brMoeda(valor)) + "</td></tr>" +
          '<tr><td style="padding:4px 0">Desconto (' + Util.esc(Util.brNum(desc, 0)) + '%)</td><td class="dir" style="text-align:right;color:#15803d">− ' + Util.esc(Util.brMoeda(economia)) + "</td></tr>" +
          '<tr><td style="padding:4px 0"><b>Valor com desconto</b></td><td class="dir" style="text-align:right"><b>' + Util.esc(Util.brMoeda(comDesconto)) + "</b></td></tr>" +
          '<tr><td style="padding:4px 0">Entrada (' + Util.esc(Util.brNum(ent, 0)) + '%)</td><td class="dir" style="text-align:right">' + Util.esc(Util.brMoeda(entradaVal)) + "</td></tr>" +
          '<tr><td style="padding:4px 0">Saldo a parcelar</td><td class="dir" style="text-align:right">' + Util.esc(Util.brMoeda(saldo)) + "</td></tr>" +
          '<tr><td style="padding:6px 0;border-top:1px solid #cbd5e1"><b>' + Util.esc(prazo) + "× de</b></td><td class=\"dir\" style=\"text-align:right;border-top:1px solid #cbd5e1\"><b>" + Util.esc(Util.brMoeda(parcela)) + "</b></td></tr>" +
          "</table>";
      }
      var ids = ["sim-valor", "sim-desc", "sim-entrada", "sim-prazo"];
      for (var i = 0; i < ids.length; i++) { var e = ov.querySelector("#" + ids[i]); if (e) e.addEventListener("input", recalc); }
    }
  });
})(window);
