/* =====================================================================
 * app.js — shell, roteador e boot do ContabPRO.
 * PADRÃO DE MÓDULO (cada tela): window.MinhaView = App.registrar({
 *   id:"clientes", titulo:"Clientes",
 *   render:function(){ return "<...html...>"; },   // devolve HTML p/ #conteudo
 *   onMount:function(el){},                          // opcional, após render
 *   <metodo>:function(arg, el){}                     // chamado por data-acao="<metodo>[:arg]"
 * });
 * Navegação: data-nav="clientes".  Ação da view atual: data-acao="metodo:arg".
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Auth = global.Auth, UI = global.UI, Util = global.Util;

  var App = {
    views: {}, atualId: null, matriz: null,

    registrar: function (view) { App.views[view.id] = view; return view; },

    // carrega a matriz de obrigações (JSON) — cai num embutido mínimo se offline sem fetch
    carregarMatriz: function (cb) {
      if (App.matriz) return cb(App.matriz);
      if (global.MATRIZ_EMBUTIDA) { App.matriz = global.MATRIZ_EMBUTIDA; return cb(App.matriz); }
      try {
        fetch(CONFIG.matrizArquivo).then(function (r) { return r.json(); }).then(function (j) { App.matriz = j; cb(j); })
          .catch(function () { App.matriz = { versao: "vazia", obrigacoes: [] }; cb(App.matriz); });
      } catch (e) { App.matriz = { versao: "vazia", obrigacoes: [] }; cb(App.matriz); }
    },

    // O perfil pode ABRIR este módulo? (dashboard é comum a todos; soPerfil e p.modulos são gates)
    podeAbrir: function (id) {
      var u = Auth.usuario(), p = Auth.perfil(); if (!u || !p) return false;
      var mod = CONFIG.modulos.filter(function (m) { return m.id === id; })[0];
      if (mod && mod.soPerfil && mod.soPerfil.indexOf(u.perfil) < 0) return false;
      if (id === "dashboard") return true; // torre de controle é de todos
      if (p.modulos !== "*" && p.modulos.indexOf(id) < 0) return false;
      return true;
    },

    ir: function (id) {
      var v = App.views[id]; if (!v) { UI.toast("Módulo indisponível: " + id, "erro"); return; }
      if (!App.podeAbrir(id)) { UI.toast("Sem acesso a este módulo.", "erro"); return; }
      App.atualId = id;
      var cont = UI.el("conteudo");
      try { cont.innerHTML = v.render(); } catch (e) { cont.innerHTML = '<div class="empty">Erro ao abrir: ' + Util.esc(e.message) + '</div>'; }
      if (v.onMount) try { v.onMount(cont); } catch (e2) {}
      App._marcarNav(id);
      window.scrollTo(0, 0);
    },
    render: function () { if (App.atualId) App.ir(App.atualId); },
    viewAtual: function () { return App.views[App.atualId]; },

    _marcarNav: function (id) { var ns = document.querySelectorAll("[data-nav]"); for (var i = 0; i < ns.length; i++) ns[i].classList.toggle("ativo", ns[i].getAttribute("data-nav") === id); },

    // Shell de impressão (propostas, relatórios de entregas, faturas): janela nova
    // com cabeçalho da marca + CSS de A4 + window.print(). Todo entregável usa isto.
    _abrirPrint: function (titulo, corpoHtml) {
      var w = window.open("", "_blank", "width=900,height=1000");
      if (!w) { UI.toast("Popup bloqueado — libere popups para imprimir.", "erro"); return; }
      var css = "*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Segoe UI',system-ui,Arial,sans-serif;color:#0f172a;font-size:13px;padding:34px 40px}" +
        ".ph{display:flex;align-items:center;gap:14px;border-bottom:3px solid #0f2740;padding-bottom:14px;margin-bottom:22px}" +
        ".ph .lg{width:46px;height:46px;border-radius:12px;background:linear-gradient(135deg,#2e6f9e,#16a34a);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:16px}" +
        ".ph b{font-size:19px;color:#0f2740;display:block}.ph small{color:#64748b}" +
        "h2{color:#0f2740;font-size:16px;margin:18px 0 8px}table{width:100%;border-collapse:collapse;font-size:12px;margin:8px 0}" +
        "th{background:#0f2740;color:#fff;text-align:left;padding:7px 9px;font-size:11px}td{border:1px solid #cbd5e1;padding:7px 9px}" +
        ".tot{font-weight:800;background:#f1f5f9}.dir{text-align:right}.ok{color:#15803d;font-weight:700}.al{color:#b91c1c;font-weight:700}" +
        ".foot{margin-top:26px;padding-top:10px;border-top:1px solid #cbd5e1;color:#64748b;font-size:11px;display:flex;justify-content:space-between}" +
        "@media print{body{padding:10mm 12mm}}";
      w.document.write("<!doctype html><html><head><meta charset='utf-8'><title>" + Util.esc(titulo) + "</title><style>" + css + "</style></head><body>" +
        '<div class="ph"><div class="lg">CP</div><div><b>' + Util.esc(CONFIG.marca.nome) + '</b><small>' + Util.esc(titulo) + ' · emitido em ' + Util.brData(Util.hojeISO()) + '</small></div></div>' +
        corpoHtml +
        '<div class="foot"><span>' + Util.esc(CONFIG.marca.nome) + ' · ' + Util.esc(CONFIG.marca.slogan) + '</span><span>gerado pelo sistema</span></div>' +
        "</body></html>");
      w.document.close();
      setTimeout(function () { try { w.focus(); w.print(); } catch (e) {} }, 400);
    },

    _sidebar: function () {
      var u = Auth.usuario();
      var itens = CONFIG.modulos.filter(function (m) { return App.podeAbrir(m.id); }).map(function (m) {
        return '<a class="nav-i" data-nav="' + m.id + '">' + UI.icone(m.icone, 18) + '<span>' + Util.esc(m.nome) + '</span></a>';
      }).join("");
      return '<div class="side"><div class="brand"><div class="logo">CP</div><div><b>' + Util.esc(CONFIG.marca.nome) + '</b><small>' + Util.esc(CONFIG.marca.slogan) + '</small></div></div>' +
        '<nav>' + itens + '</nav>' +
        '<div class="side-ft"><div class="who">' + Util.esc(u ? u.nome : "—") + '<small>' + Util.esc(u ? (CONFIG.perfis[u.perfil] || {}).nome || "" : "") + '</small></div>' +
        '<button class="btn sm ghost" data-acao="_trocarUsuario">Trocar</button></div></div>';
    },

    // Aplica o white-label/parâmetros salvos pelo sócio (Configurações do Escritório)
    // ANTES de montar a UI — senão o nome/cor/valor-ponto/4-olhos revertiam ao default
    // a cada reload (config "salva" mas sem efeito). Idempotente e null-safe.
    aplicarConfigEscritorio: function () {
      try {
        var Store = global.Store; if (!Store) return;
        var c = Store.obter("config_escritorio", "cfg"); if (!c) return;
        if (c.nomeExibicao) CONFIG.marca.nome = c.nomeExibicao;
        if (c.corPrimaria) { CONFIG.marca.corPrimaria = c.corPrimaria; try { document.documentElement.style.setProperty("--navy", c.corPrimaria); } catch (e) {} }
        if (c.corSecundaria) CONFIG.marca.corSecundaria = c.corSecundaria;
        if (c.valorPonto != null && c.valorPonto > 0) CONFIG.precificacao.valorPonto = c.valorPonto;
        if (c.custoPorPonto != null) CONFIG.precificacao.custoPorPonto = c.custoPorPonto;
        if (typeof c.duplaConferenciaAtiva === "boolean") CONFIG.duplaConferencia.ativa = c.duplaConferenciaAtiva;
        if (c.criticas && c.criticas.length) CONFIG.duplaConferencia.criticas = c.criticas;
      } catch (e) { /* config corrompida não pode travar o boot */ }
    },

    boot: function () {
      Auth.bootstrap(); Auth.autoEntrar();
      App.aplicarConfigEscritorio();
      document.body.innerHTML = '<div id="app"><div id="side-wrap"></div><main id="main"><div id="topbar"></div><div id="conteudo"></div></main></div><div id="toasts"></div>';
      UI.el("side-wrap").innerHTML = App._sidebar();
      App.carregarMatriz(function () {
        App._delegacao();
        App.ir("dashboard");
      });
    },

    _delegacao: function () {
      document.addEventListener("click", function (e) {
        var nav = e.target.closest ? e.target.closest("[data-nav]") : null;
        if (nav) { App.ir(nav.getAttribute("data-nav")); return; }
        var ac = e.target.closest ? e.target.closest("[data-acao]") : null;
        if (ac) {
          var raw = ac.getAttribute("data-acao"), p = raw.split(":"), metodo = p[0], arg = p.slice(1).join(":");
          if (metodo === "_trocarUsuario") return App._trocarUsuario();
          var v = App.viewAtual();
          if (v && typeof v[metodo] === "function") { try { v[metodo](arg || undefined, ac); } catch (err) { UI.toast(err.codigo === "SEM_PERMISSAO" ? "Sem permissão." : ("Erro: " + err.message), "erro"); } }
        }
      });
    },

    _trocarUsuario: function () {
      var us = Auth.usuarios();
      var corpo = us.map(function (u) { return '<button class="btn linha" data-acao-troca="' + u.id + '">' + Util.esc(u.nome) + ' — ' + Util.esc((CONFIG.perfis[u.perfil] || {}).nome || "") + '</button>'; }).join("") ||
        '<div class="empty">Só há o sócio admin. Novos usuários entram no módulo (fase futura).</div>';
      var ov = UI.modal("Entrar como", '<div class="col-btns">' + corpo + '</div>', [{ txt: "Fechar" }]);
      var bs = ov.querySelectorAll("[data-acao-troca]");
      for (var i = 0; i < bs.length; i++) bs[i].onclick = function () { Auth.entrar(this.getAttribute("data-acao-troca")); UI.fecharModal(); UI.el("side-wrap").innerHTML = App._sidebar(); App.render(); };
    }
  };

  global.App = App;
  if (typeof document !== "undefined") {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", App.boot); else App.boot();
  }
})(window);
