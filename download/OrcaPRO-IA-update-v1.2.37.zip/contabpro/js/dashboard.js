/* =====================================================================
 * dashboard.js — "Torre de Controle" (seção 3.4.3), tela inicial.
 * Visão de comando: KPIs de risco, "o que me derruba hoje" (atrasadas +
 * vencendo em 7d) e mapa de calor de pendências por departamento.
 * Respeita RBAC: analista só enxerga a própria carteira (Auth.clientesVisiveis).
 * ===================================================================== */
(function (global) {
  "use strict";
  var Store = global.Store, Auth = global.Auth, Util = global.Util, UI = global.UI, App = global.App;
  var CONFIG = global.CONFIG, CObrig = global.CObrig;

  // status que já "saíram" da fila operacional
  function encerrada(ob) { return ob.status === "concluida" || ob.status === "retificada"; }

  // clientes que este usuário pode ver (analista = só carteira)
  function clientesVisiveis() {
    return Auth.clientesVisiveis(Store.listar("clientes"));
  }

  // obrigações apenas dos clientes visíveis
  function obrigacoesVisiveis(clientes) {
    var vis = {};
    for (var i = 0; i < clientes.length; i++) vis[clientes[i].id] = 1;
    return Store.listar("obrigacoes").filter(function (o) { return vis[o.clienteId]; });
  }

  // varre certificados digitais e procurações do cliente -> [datas de validade]
  function validadesDoCliente(c) {
    var out = [];
    // certificado digital: objeto único OU lista
    if (c.certificadoDigital && c.certificadoDigital.validade) out.push(c.certificadoDigital.validade);
    var listas = [c.certificados, c.procuracoes, c.certificadosDigitais];
    for (var i = 0; i < listas.length; i++) {
      var arr = listas[i];
      if (arr && arr.length) for (var j = 0; j < arr.length; j++) {
        var v = arr[j] && (arr[j].validade || arr[j].vencimento);
        if (v) out.push(v);
      }
    }
    return out;
  }

  // conta certificados/procurações vencendo (validade a <= 30 dias, inclui vencidos)
  function certsVencendo(clientes) {
    var n = 0;
    for (var i = 0; i < clientes.length; i++) {
      var vs = validadesDoCliente(clientes[i]);
      for (var j = 0; j < vs.length; j++) {
        var d = Util.diasAte(vs[j]);
        if (d != null && d <= 30) n++;
      }
    }
    return n;
  }

  // formata competência "2026-07" -> "jul/2026"
  function fmtComp(comp) {
    var p = String(comp || "").split("-");
    if (p.length < 2) return Util.esc(comp || "—");
    return Util.mesNome(+p[1]) + "/" + p[0];
  }

  // rótulo legível do status do workflow
  function rotulo(st) { return (CObrig && CObrig.ROTULO && CObrig.ROTULO[st]) || st || "—"; }

  window.DashboardView = App.registrar({
    id: "dashboard",

    render: function () {
      var clientes = clientesVisiveis();
      var obrs = obrigacoesVisiveis(clientes);

      // ---- KPIs ----
      var ativos = clientes.filter(function (c) { return c.status === "ativo"; }).length;

      var pendentes = 0, vence7 = 0, atrasadas = 0;
      var derruba = [];       // atrasadas + vencendo em 7d
      var porDepto = {};      // deptoId -> {pend, atr}

      for (var i = 0; i < obrs.length; i++) {
        var o = obrs[i];
        if (encerrada(o)) continue;
        pendentes++;

        var dep = o.departamento || "_sem";
        if (!porDepto[dep]) porDepto[dep] = { pend: 0, atr: 0 };
        porDepto[dep].pend++;

        var d = Util.diasAte(o.prazoAjustado);
        if (d == null) continue;
        if (d < 0) { atrasadas++; porDepto[dep].atr++; derruba.push(o); }
        else if (d <= 7) { vence7++; derruba.push(o); }
      }

      var certs = certsVencendo(clientes);

      var kpis =
        kpi(ativos, "Clientes ativos", "") +
        kpi(pendentes, "Obrigações pendentes", "") +
        kpi(vence7, "Vencem em 7 dias", "wr") +
        kpi(atrasadas, "Atrasadas", "al") +
        kpi(certs, "Certificados/procurações vencendo", certs > 0 ? "wr" : "");

      // ---- Card: o que me derruba hoje ----
      var derrubaOrd = Util.ordenaPor(derruba, "prazoAjustado");
      var colsD = [
        { k: "clienteId", label: "Cliente", fmt: function (v) { var c = Store.obter("clientes", v); return Util.esc(c ? (c.razaoSocial || c.nomeFantasia || c.nome || "—") : "—"); } },
        { k: "nome", label: "Obrigação", fmt: function (v) { return Util.esc(v || "—"); } },
        { k: "competencia", label: "Competência", fmt: function (v) { return fmtComp(v); } },
        { k: "prazoAjustado", label: "Vence", fmt: function (v) { return Util.brData(v); } },
        { k: "status", label: "Status", fmt: function (v, row) {
            var dd = Util.diasAte(row.prazoAjustado);
            var cor = (dd != null && dd < 0) ? "vermelho" : "amber";
            return UI.badge(rotulo(v), cor);
          } }
      ];
      var tabD = derrubaOrd.length
        ? UI.tabela(colsD, derrubaOrd, { onRow: true })
        : '<div class="empty">Tudo em dia! 🎉</div>';

      var cardDerruba =
        '<div class="card"><div class="card-hd"><b>O que me derruba hoje</b>' +
        (derrubaOrd.length ? UI.badge(derrubaOrd.length + " item" + (derrubaOrd.length > 1 ? "s" : ""), "vermelho") : "") +
        '</div><div class="card-bd" id="dash-derruba">' + tabD + '</div></div>';

      // ---- Card: mapa de calor por departamento ----
      var linhasDep = CONFIG.departamentos.map(function (dp) {
        var stt = porDepto[dp.id] || { pend: 0, atr: 0 };
        return { dep: dp.nome, pend: stt.pend, atr: stt.atr };
      });
      var colsDep = [
        { k: "dep", label: "Departamento", fmt: function (v) { return Util.esc(v); } },
        { k: "pend", label: "Pendentes", cls: "num", fmt: function (v) { return v > 0 ? '<b>' + v + '</b>' : '<span style="color:var(--mut)">0</span>'; } },
        { k: "atr", label: "Atrasadas", cls: "num", fmt: function (v) { return v > 0 ? '<span style="color:var(--red);font-weight:800">' + v + '</span>' : '<span style="color:var(--mut)">0</span>'; } }
      ];
      var cardHeat =
        '<div class="card"><div class="card-hd"><b>Mapa de calor por departamento</b></div>' +
        '<div class="card-bd">' + UI.tabela(colsDep, linhasDep, { vazio: "Sem departamentos configurados." }) + '</div></div>';

      // ---- montagem ----
      return '<div class="page-hd"><div><h1>Torre de Controle</h1>' +
        '<div class="sub">' + Util.esc(Util.brData(Util.hojeISO())) + '</div></div></div>' +
        '<div class="grid-kpi">' + kpis + '</div>' +
        cardDerruba +
        cardHeat;
    },

    // liga o clique nas linhas de "o que me derruba" -> abre a Agenda de Obrigações
    onMount: function (el) {
      var wrap = el.querySelector ? el.querySelector("#dash-derruba") : null;
      if (!wrap) return;
      var linhas = wrap.querySelectorAll("tr.clk");
      for (var i = 0; i < linhas.length; i++) {
        linhas[i].onclick = function () {
          // módulo da agenda registra-se como "obrigacoes" (CONFIG.modulos)
          App.ir("obrigacoes");
        };
      }
    }
  });

  // helper de KPI (n grande + label; variação de cor .al/.ok/.wr)
  function kpi(n, label, cor) {
    return '<div class="kpi' + (cor ? " " + cor : "") + '">' +
      '<div class="n">' + n + '</div>' +
      '<div class="l">' + Util.esc(label) + '</div></div>';
  }
})(window);
