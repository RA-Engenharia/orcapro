/* =====================================================================
 * agenda.js — Agenda de Obrigações + Torre de Controle operacional (3.4).
 * Tela: filtros (cliente/competência/status/departamento) + tabela de
 * obrigações com workflow por linha (Avançar / Concluir / Retificar /
 * Marcar sem movimento) + resumo em KPIs no topo.
 * Registrada como id "obrigacoes" (bate com CONFIG.modulos e com o RBAC
 * Auth.pode("obrigacoes", ...)); o arquivo é agenda.js por organização.
 * ES5 estrito (só var/function/concat). Orquestra CObrig + Store + Auth.
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, CObrig = global.CObrig, App = global.App;

  // ---------- Helpers puros (closure do módulo) ----------
  var FINALIZADOS = { concluida: 1, retificada: 1 };

  // Está atrasada? (não finalizada e já passou do prazo ajustado)
  function atrasada(ob) {
    if (FINALIZADOS[ob.status]) return false;
    var d = Util.diasAte(ob.prazoAjustado);
    return d != null && d < 0;
  }
  // Vence nos próximos 7 dias (inclusive hoje) e ainda não finalizada.
  function vencendo7(ob) {
    if (FINALIZADOS[ob.status]) return false;
    var d = Util.diasAte(ob.prazoAjustado);
    return d != null && d >= 0 && d <= 7;
  }
  // Data (ISO) em que foi concluída, lida do histórico (mais recente).
  function dataConclusao(ob) {
    var h = ob.historico || [];
    for (var i = h.length - 1; i >= 0; i--) if (h[i].status === "concluida") return h[i].quando;
    return null;
  }
  // Nome do departamento a partir do id.
  function deptoNome(id) {
    if (!id) return "—";
    for (var i = 0; i < CONFIG.departamentos.length; i++) if (CONFIG.departamentos[i].id === id) return CONFIG.departamentos[i].nome;
    return id;
  }
  // Nome exibível de um cliente.
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || c.id) : ""; } // razão social primeiro (padrão entre telas)
  function idUsuario() { var u = Auth.usuario(); return u ? u.id : null; }

  // Badge de status por regra (seção 3.4.3).
  function statusBadge(ob) {
    var s = ob.status, rotulo = (CObrig.ROTULO && CObrig.ROTULO[s]) || s, cor;
    if (s === "concluida") cor = "verde";
    else if (s === "retificada") cor = "roxo";
    else if (atrasada(ob)) cor = "vermelho";
    else if (s === "transmitida" || s === "comprovante_anexado") cor = "azul";
    else cor = "cinza";
    return UI.badge(rotulo, cor);
  }

  // Célula "Vence": data + badge de dias (atraso vermelho / <=7d âmbar).
  function venceCel(ob) {
    var txt = '<span style="white-space:nowrap">' + Util.esc(Util.brData(ob.prazoAjustado)) + "</span>";
    if (!FINALIZADOS[ob.status]) {
      var d = Util.diasAte(ob.prazoAjustado);
      if (d != null) {
        if (d < 0) return txt + " " + UI.badge((-d) + "d atraso", "vermelho");
        if (d === 0) return txt + " " + UI.badge("hoje", "amber");
        if (d <= 7) return txt + " " + UI.badge("em " + d + "d", "amber");
      }
    }
    return txt;
  }

  // há equipe (>=2 usuários) para valer os 4 olhos? (solo dispensa automaticamente)
  function temEquipe() { return Auth.usuarios().length >= 2; }

  // Célula extra: selo de 4 olhos (conferência) nas obrigações críticas.
  function confCel(ob) {
    if (!CObrig.exigeConferencia(ob)) return '<span class="chip" style="opacity:.4">—</span>';
    if (ob.conferenteId) return UI.badge("conferida ✓", "verde");
    if (ob.conferenciaDispensada) return UI.badge("dispensada (solo)", "cinza");
    return UI.badge(temEquipe() ? "aguarda 4 olhos" : "solo — dispensa", temEquipe() ? "amber" : "cinza");
  }

  // Botões de ação por linha.
  function acoesCel(ob) {
    var id = ob.id, out = "";
    if (!FINALIZADOS[ob.status]) {
      out += '<button class="btn sm" data-acao="avancar:' + id + '">Avançar</button> ';
      // crítica sem conferência E com equipe: mostra "Conferir" (2º analista). Solo dispensa no concluir.
      if (CObrig.exigeConferencia(ob) && !ob.conferenteId && !ob.conferenciaDispensada && temEquipe()) out += '<button class="btn sm" data-acao="conferir:' + id + '">Conferir</button> ';
      out += '<button class="btn sm green" data-acao="concluir:' + id + '">Concluir</button> ';
      out += '<button class="btn sm" data-acao="semMovimento:' + id + '">s/ mov.</button> ';
      out += '<button class="btn sm danger" data-acao="retificar:' + id + '">Retificar</button>';
    } else if (ob.status === "concluida") {
      out += '<button class="btn sm danger" data-acao="retificar:' + id + '">Retificar</button>';
    } else {
      out += UI.badge("Retificada", "roxo");
    }
    return out;
  }

  // ---------- View ----------
  global.AgendaView = App.registrar({
    id: "obrigacoes",
    titulo: "Agenda de Obrigações",

    render: function () {
      if (!this._filtros) this._filtros = { cliente: "", competencia: "todas", status: "todos", depto: "" };
      var f = this._filtros;
      // filtro fantasma: cliente filtrado foi excluído -> volta pra "todos" (senão a tabela fica vazia sem explicação)
      if (f.cliente && !Store.obter("clientes", f.cliente)) f.cliente = "";

      // Clientes visíveis (respeita carteira do analista).
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      var setVis = {}, nomeCli = {}, i;
      for (i = 0; i < visiveis.length; i++) { setVis[visiveis[i].id] = 1; nomeCli[visiveis[i].id] = nomeCliente(visiveis[i]); }

      // Obrigações só de clientes visíveis.
      var todas = Store.listar("obrigacoes"), visObrig = [];
      for (i = 0; i < todas.length; i++) if (setVis[todas[i].clienteId]) visObrig.push(todas[i]);

      // Competências distintas (para o seletor).
      var compsSet = {}, cc;
      for (i = 0; i < visObrig.length; i++) if (visObrig[i].competencia) compsSet[visObrig[i].competencia] = 1;
      var compsArr = []; for (cc in compsSet) if (compsSet.hasOwnProperty(cc)) compsArr.push(cc);
      compsArr.sort(); compsArr.reverse();

      // Aplica filtros.
      var linhas = visObrig.filter(function (ob) {
        if (f.cliente && ob.clienteId !== f.cliente) return false;
        if (f.competencia && f.competencia !== "todas" && ob.competencia !== f.competencia) return false;
        if (f.depto && ob.departamento !== f.depto) return false;
        if (f.status && f.status !== "todos") {
          if (f.status === "atrasadas") { if (!atrasada(ob)) return false; }
          else if (ob.status !== f.status) return false;
        }
        return true;
      });
      linhas = Util.ordenaPor(linhas, "prazoAjustado");

      // KPIs (sobre o conjunto filtrado).
      var hp = Util.partes(Util.hojeISO()), compAtual = Util.competencia(hp.y, hp.m);
      var total = linhas.length, nAtr = 0, nVenc = 0, nConc = 0;
      linhas.forEach(function (ob) {
        if (atrasada(ob)) nAtr++;
        if (vencendo7(ob)) nVenc++;
        if (ob.status === "concluida") { var dc = dataConclusao(ob); if (dc && dc.indexOf(compAtual) === 0) nConc++; }
      });

      // Linhas da tabela (objetos "planos" p/ o UI.tabela + _ob p/ ações).
      var rows = linhas.map(function (ob) {
        return {
          _cli: nomeCli[ob.clienteId] || ob.clienteId, nome: ob.nome, competencia: ob.competencia,
          prazoAjustado: ob.prazoAjustado, departamento: ob.departamento, status: ob.status, _ob: ob
        };
      });

      var cols = [
        { k: "_cli", label: "Cliente", fmt: function (v) { return Util.esc(v); } },
        { k: "nome", label: "Obrigação", fmt: function (v) { return Util.esc(v); } },
        { k: "competencia", label: "Comp.", fmt: function (v) { return '<span style="white-space:nowrap">' + Util.esc(v || "—") + "</span>"; } },
        { k: "prazoAjustado", label: "Vence", fmt: function (v, row) { return venceCel(row._ob); } },
        { k: "departamento", label: "Depto", fmt: function (v) { return Util.esc(deptoNome(v)); } },
        { k: "status", label: "Status", fmt: function (v, row) { return statusBadge(row._ob); } },
        { k: "_conf", label: "4 olhos", cls: "ctr", fmt: function (v, row) { return confCel(row._ob); } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) { return acoesCel(row._ob); } }
      ];
      var tabela = UI.tabela(cols, rows, { vazio: "Nenhuma obrigação para os filtros atuais." });

      // ---- Seletores de filtro ----
      var opCli = [{ v: "", t: "Todos os clientes" }];
      for (i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });

      var opComp = [{ v: "todas", t: "Todas as competências" }];
      for (i = 0; i < compsArr.length; i++) { var p = Util.partes(compsArr[i] + "-01"); opComp.push({ v: compsArr[i], t: Util.mesNome(p.m) + "/" + p.y }); }

      var opSt = [{ v: "todos", t: "Todos os status" }, { v: "atrasadas", t: "⚠ Atrasadas" }];
      for (i = 0; i < CObrig.WORKFLOW.length; i++) opSt.push({ v: CObrig.WORKFLOW[i], t: CObrig.ROTULO[CObrig.WORKFLOW[i]] || CObrig.WORKFLOW[i] });
      opSt.push({ v: "retificada", t: CObrig.ROTULO.retificada || "Retificada" });

      var opDep = [{ v: "", t: "Todos os departamentos" }];
      for (i = 0; i < CONFIG.departamentos.length; i++) opDep.push({ v: CONFIG.departamentos[i].id, t: CONFIG.departamentos[i].nome });

      var toolbar = '<div class="toolbar">' +
        UI.sel("f-cliente", opCli, f.cliente) +
        UI.sel("f-comp", opComp, f.competencia) +
        UI.sel("f-status", opSt, f.status) +
        UI.sel("f-depto", opDep, f.depto) +
        "</div>";

      // ---- KPIs ----
      var kpis = '<div class="grid-kpi">' +
        '<div class="kpi"><div class="n">' + total + '</div><div class="l">Obrigações (filtro)</div></div>' +
        '<div class="kpi ' + (nAtr ? "al" : "") + '"><div class="n">' + nAtr + '</div><div class="l">Atrasadas</div></div>' +
        '<div class="kpi ' + (nVenc ? "wr" : "") + '"><div class="n">' + nVenc + '</div><div class="l">Vencendo em 7 dias</div></div>' +
        '<div class="kpi ok"><div class="n">' + nConc + '</div><div class="l">Concluídas no mês</div></div>' +
        "</div>";

      var podeTransmitir = Auth.pode("obrigacoes", "transmitir");
      var aviso = podeTransmitir ? "" : '<span class="chip">Somente leitura: seu perfil não conclui/transmite</span>';

      return '<div class="page-hd"><div><h1>Agenda de Obrigações</h1>' +
        '<div class="sub">Torre de controle operacional — prazos, workflow e comprovantes por cliente.</div></div>' +
        '<div>' + aviso + "</div></div>" +
        kpis + toolbar +
        '<div class="card"><div class="card-hd"><b>Obrigações</b><span class="chip">' + total + ' item(ns)</span></div>' +
        '<div class="card-bd">' + tabela + "</div></div>";
    },

    // Liga os filtros (change -> guarda estado + re-render).
    onMount: function () {
      var self = this, map = [["f-cliente", "cliente"], ["f-comp", "competencia"], ["f-status", "status"], ["f-depto", "depto"]];
      map.forEach(function (par) {
        var e = UI.el(par[0]);
        if (e) e.addEventListener("change", function () { self._filtros[par[1]] = e.value; App.render(); });
      });
    },

    // ---- Ações de workflow ----

    // Avança para o próximo status do WORKFLOW (se o próximo for "concluida", exige comprovante).
    avancar: function (id) {
      // guard na função (não só no botão): movimentar workflow exige o módulo no perfil
      if (!Auth.pode("obrigacoes", "editar")) { UI.toast("Sem permissão para movimentar obrigações.", "erro"); return; }
      var ob = Store.obter("obrigacoes", id);
      if (!ob) { UI.toast("Obrigação não encontrada.", "erro"); return; }
      if (ob.status === "concluida") { UI.toast("Já concluída.", "info"); return; }
      var i = CObrig.WORKFLOW.indexOf(ob.status);
      if (i < 0) { UI.toast("Status atual não permite avançar.", "alerta"); return; }
      var proximo = CObrig.WORKFLOW[i + 1];
      if (!proximo) { UI.toast("Já está no último status.", "info"); return; }
      if (proximo === "concluida") { this.concluir(id); return; } // conclusão exige comprovante
      CObrig.avancar(ob, proximo, idUsuario());
      Store.salvar("obrigacoes", ob);
      if (global.Audit) global.Audit.log("obrigacao_avancar", "obrigacoes", ob.id);
      UI.toast("Avançou para: " + (CObrig.ROTULO[proximo] || proximo), "ok");
      App.render();
    },

    // Conferir (dupla conferência 4 olhos, seção 3.22): 2º analista valida a crítica.
    conferir: function (id) {
      if (!Auth.pode("obrigacoes", "aprovar") && !Auth.pode("obrigacoes", "transmitir")) { UI.toast("Sem permissão para conferir.", "erro"); return; }
      var ob = Store.obter("obrigacoes", id);
      if (!ob) { UI.toast("Obrigação não encontrada.", "erro"); return; }
      var eu = idUsuario();
      var prep = ob.preparadorId || null; // preparador REAL persistido (não heurístico)
      var corpo = "<p>Conferir <b>" + Util.esc(ob.nome) + "</b> (" + Util.esc(ob.competencia || "") + ")? " +
        "A dupla conferência (4 olhos) é exigida para obrigações críticas antes de transmitir.</p>" +
        (prep && prep === eu ? '<p class="chip" style="color:#b91c1c">⚠ Você preparou esta obrigação — quem prepara não pode conferir (segregação). Peça a outro analista.</p>' : "");
      UI.modal("Dupla conferência", corpo, [
        { txt: "Cancelar" },
        { txt: "Confirmar conferência", classe: "primary", onClick: function (fechar) {
          try { CObrig.conferir(ob, eu, prep); }
          catch (e) { UI.toast(e.codigo === "MESMO_PREPARADOR" ? e.message : ("Erro: " + e.message), "erro"); return; }
          Store.salvar("obrigacoes", ob);
          if (global.Audit) global.Audit.log("obrigacao_conferir", "obrigacoes", ob.id);
          UI.toast("Conferida (4 olhos). Pode transmitir/concluir.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    // Concluir: abre modal pedindo comprovante (protocolo/arquivo). Guard de permissão.
    concluir: function (id) {
      if (!Auth.pode("obrigacoes", "transmitir")) { UI.toast("Sem permissão para concluir/transmitir.", "erro"); return; }
      var ob = Store.obter("obrigacoes", id);
      if (!ob) { UI.toast("Obrigação não encontrada.", "erro"); return; }
      // crítica não conferida:
      if (CObrig.exigeConferencia(ob) && !ob.conferenteId && !ob.conferenciaDispensada) {
        // escritório SOLO (1 usuário) — não há 2º analista: dispensa automática, auditada
        if (Auth.usuarios().length < 2) {
          CObrig.dispensarConferencia(ob, "Escritório solo (1 usuário) — dupla conferência dispensada automaticamente.", idUsuario());
          Store.salvar("obrigacoes", ob);
          if (global.Audit) global.Audit.log("obrigacao_conferencia_dispensada", "obrigacoes", ob.id);
        } else {
          // há equipe: exige o 2º analista de verdade
          UI.toast("Obrigação crítica: faça a dupla conferência (botão Conferir, por outro analista) antes de concluir.", "alerta"); return;
        }
      }
      var cli = Store.obter("clientes", ob.clienteId), quem = nomeCliente(cli);
      var corpo = '<p class="fld-d" style="margin-bottom:14px">' + Util.esc(quem) + " — " + Util.esc(ob.nome) +
        " · " + Util.esc(ob.competencia || "") + "</p>" +
        UI.campo("Protocolo / recibo", UI.inp("obrig-cp-proto", "", "Nº do protocolo, recibo ou hash")) +
        UI.campo("Arquivo (referência)", UI.inp("obrig-cp-arq", "", "ex.: recibo_DCTFWeb_2026-06.pdf"), "Anexe o PDF no GED e registre aqui a referência.");
      UI.modal("Concluir obrigação", corpo, [
        { txt: "Cancelar" },
        { txt: "Concluir", classe: "green", onClick: function (fechar) {
          var proto = UI.v("obrig-cp-proto"), arq = UI.v("obrig-cp-arq");
          var comp = (proto || arq) ? { protocolo: proto, arquivo: arq, quando: Util.hojeISO(), por: idUsuario() } : null;
          try { CObrig.concluir(ob, comp, idUsuario()); }
          catch (e) { UI.toast(e.codigo === "SEM_COMPROVANTE" ? e.message : ("Erro: " + e.message), "erro"); return; }
          Store.salvar("obrigacoes", ob);
          if (global.Audit) global.Audit.log("obrigacao_concluir", "obrigacoes", ob.id);
          UI.toast("Obrigação concluída.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    // Marcar sem movimento: conclui com comprovante de ausência de movimento.
    semMovimento: function (id) {
      if (!Auth.pode("obrigacoes", "transmitir")) { UI.toast("Sem permissão para concluir/transmitir.", "erro"); return; }
      var ob = Store.obter("obrigacoes", id);
      if (!ob) { UI.toast("Obrigação não encontrada.", "erro"); return; }
      var corpo = "<p>Confirmar que <b>" + Util.esc(ob.nome) + "</b> (" + Util.esc(ob.competencia || "") +
        ") está <b>sem movimento</b>? Será concluída com comprovante de ausência de movimento.</p>";
      UI.modal("Marcar sem movimento", corpo, [
        { txt: "Cancelar" },
        { txt: "Confirmar", classe: "green", onClick: function (fechar) {
          ob.semMovimento = true;
          var comp = { tipo: "sem_movimento", protocolo: "SEM MOVIMENTO", quando: Util.hojeISO(), por: idUsuario() };
          try { CObrig.concluir(ob, comp, idUsuario()); }
          catch (e) { UI.toast("Erro: " + e.message, "erro"); return; }
          Store.salvar("obrigacoes", ob);
          if (global.Audit) global.Audit.log("obrigacao_sem_movimento", "obrigacoes", ob.id);
          UI.toast("Marcada sem movimento e concluída.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    // Retificar: modal com causa-raiz (obrigatória) + motivo.
    retificar: function (id) {
      if (!Auth.pode("obrigacoes", "transmitir")) { UI.toast("Sem permissão para retificar.", "erro"); return; }
      var ob = Store.obter("obrigacoes", id);
      if (!ob) { UI.toast("Obrigação não encontrada.", "erro"); return; }
      var opCausa = [
        { v: "", t: "— selecione a causa-raiz —" },
        { v: "erro_interno", t: "Erro interno (escritório)" },
        { v: "dado_cliente", t: "Dado do cliente" },
        { v: "mudanca_norma", t: "Mudança de norma" }
      ];
      var corpo = '<p class="fld-d" style="margin-bottom:14px">' + Util.esc(ob.nome) + " · " + Util.esc(ob.competencia || "") + "</p>" +
        UI.campo("Causa-raiz", UI.sel("obrig-rt-causa", opCausa, ""), "Obrigatória — alimenta o KPI de qualidade.") +
        UI.campo("Motivo / observação", UI.inp("obrig-rt-motivo", "", "O que motivou a retificação?"));
      UI.modal("Retificar obrigação", corpo, [
        { txt: "Cancelar" },
        { txt: "Retificar", classe: "danger", onClick: function (fechar) {
          var causa = UI.v("obrig-rt-causa"), motivo = UI.v("obrig-rt-motivo");
          try { CObrig.retificar(ob, causa, motivo, idUsuario()); }
          catch (e) { UI.toast(e.codigo === "SEM_CAUSA_RAIZ" ? e.message : ("Erro: " + e.message), "erro"); return; }
          Store.salvar("obrigacoes", ob);
          if (global.Audit) global.Audit.log("obrigacao_retificar", "obrigacoes", ob.id);
          UI.toast("Obrigação retificada.", "ok");
          fechar(); App.render();
        } }
      ]);
    }
  });
})(window);
