/* =====================================================================
 * financeiro.js — Honorários (seção 3.17): contratos de honorário por
 * cliente + cobranças mensais por competência + régua de inadimplência.
 * RBAC DURO: Auth.veFinanceiro() no render e em TODA ação (analista/
 * gerente/comercial NUNCA veem valores). Registrada como id "financeiro".
 * Coleções: "contratosHon" (1 por cliente, id determinístico "ch_"+clienteId)
 * e "cobrancas" (id determinístico clienteId+"|"+competencia → idempotente).
 * "Atrasada" é DERIVADO (status aberta && venceu), nunca gravado.
 * ES5 estrito (var/function/concat). Orquestra Store + Auth + UI + CONFIG.
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  var FORMAS = [
    { v: "pix", t: "PIX" },
    { v: "boleto", t: "Boleto" },
    { v: "transferencia", t: "Transferência" },
    { v: "dinheiro", t: "Dinheiro" }
  ];

  // ---------- Helpers puros (closure do módulo) ----------

  // Padrão de nome entre telas; null-safe (cliente pode ter sido excluído).
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(cliente excluído)"; }
  function idUsuario() { var u = Auth.usuario(); return u ? u.id : null; }

  // Guard central do módulo: segregação de valores (seção 2) + toast.
  function semAcesso() {
    if (Auth.veFinanceiro()) return false;
    UI.toast("Sem acesso ao financeiro.", "erro");
    return true;
  }

  // Atrasada = derivado, nunca gravado.
  function atrasada(cb) {
    if (cb.status !== "aberta") return false;
    var d = Util.diasAte(cb.vencimento);
    return d != null && d < 0;
  }
  function diasAtraso(cb) { var d = Util.diasAte(cb.vencimento); return d == null ? 0 : -d; }

  // Régua de cobrança (badge): paga | no prazo | D+1..6 amber | D+7..29 verm | D+30 avaliar suspensão.
  function reguaBadge(cb) {
    if (cb.status === "paga") return UI.badge("paga", "verde");
    if (!atrasada(cb)) return UI.badge("no prazo", "cinza");
    var n = diasAtraso(cb);
    if (n <= 6) return UI.badge("D+" + n, "amber");
    if (n <= 29) return UI.badge("D+" + n, "vermelho");
    return UI.badge("D+" + n + " ⚠ avaliar suspensão", "vermelho");
  }

  // Competência exibível: "2026-07" -> "jul/2026".
  function compRotulo(comp) { var p = Util.partes(comp + "-01"); return Util.mesNome(p.m) + "/" + p.y; }

  // Opções de competência: próximo mês + atual + 11 anteriores.
  function opcoesCompetencia() {
    var h = Util.partes(Util.hojeISO()), ops = [], k;
    for (k = 1; k >= -11; k--) {
      // normaliza ano/mês via Date UTC (sem fuso)
      var d = new Date(Date.UTC(h.y, h.m - 1 + k, 1));
      var comp = Util.competencia(d.getUTCFullYear(), d.getUTCMonth() + 1);
      ops.push({ v: comp, t: compRotulo(comp) });
    }
    return ops;
  }

  // Contrato do cliente (id determinístico — 1 contrato por cliente).
  function contratoDe(clienteId) { return Store.obter("contratosHon", "ch_" + clienteId); }

  // Sugestão da régua de pontos (seção 5) para exibir na dica do modal.
  function dicaSugestao(cliente) {
    if (!cliente) return "selecione um cliente para ver a sugestão da régua";
    return "sugerido pela régua de pontos: " + Util.brMoeda(CONFIG.honorarioSugerido(cliente));
  }

  // ---------- View ----------
  global.FinanceiroView = App.registrar({
    id: "financeiro",
    titulo: "Honorários",

    render: function () {
      // RBAC DURO no render: quem não vê financeiro não vê NENHUM valor.
      if (!Auth.veFinanceiro()) return '<div class="empty">Sem acesso ao financeiro.</div>';

      var h = Util.partes(Util.hojeISO());
      if (!this._comp) this._comp = Util.competencia(h.y, h.m);
      var comp = this._comp, i;

      var clientes = Store.listar("clientes"), nomeCli = {};
      for (i = 0; i < clientes.length; i++) nomeCli[clientes[i].id] = nomeCliente(clientes[i]);
      function nomeDe(id) { return nomeCli[id] || "(cliente excluído)"; }

      var contratos = Store.listar("contratosHon");
      var cobrancas = Store.onde("cobrancas", "competencia", comp);
      cobrancas = Util.ordenaPor(cobrancas, "vencimento");

      // ---- KPIs ----
      var mrr = 0;
      for (i = 0; i < contratos.length; i++) if (contratos[i].ativo) mrr += Number(contratos[i].valorMensal) || 0;
      var recebido = 0, emAberto = 0, nAtr = 0;
      for (i = 0; i < cobrancas.length; i++) {
        var cb = cobrancas[i];
        if (cb.status === "paga") recebido += Number(cb.valor) || 0;
        else emAberto += Number(cb.valor) || 0;
        if (atrasada(cb)) nAtr++;
      }
      var inad = cobrancas.length ? (nAtr / cobrancas.length) * 100 : 0;

      var kpis = '<div class="grid-kpi">' +
        '<div class="kpi"><div class="n">' + Util.brMoeda(mrr) + '</div><div class="l">MRR (contratos ativos)</div></div>' +
        '<div class="kpi ok"><div class="n">' + Util.brMoeda(recebido) + '</div><div class="l">Recebido em ' + Util.esc(compRotulo(comp)) + '</div></div>' +
        '<div class="kpi ' + (emAberto ? "wr" : "") + '"><div class="n">' + Util.brMoeda(emAberto) + '</div><div class="l">Em aberto</div></div>' +
        '<div class="kpi ' + (nAtr ? "al" : "") + '"><div class="n">' + Util.brNum(inad, 0) + '%</div><div class="l">Inadimplência (cobranças)</div></div>' +
        "</div>";

      // ---- Toolbar: competência + ações de lote ----
      var podeCriar = Auth.pode("financeiro", "criar");
      var toolbar = '<div class="toolbar">' +
        UI.sel("fin-comp", opcoesCompetencia(), comp) +
        (podeCriar ? '<button class="btn primary" data-acao="gerarCompetencia">' + UI.icone("plus", 16) + ' Gerar cobranças da competência</button>' : "") +
        (podeCriar ? '<button class="btn green" data-acao="novoContrato">' + UI.icone("plus", 16) + ' Novo contrato</button>' : "") +
        "</div>";

      // ---- Card 1: cobranças da competência ----
      var colsCb = [
        { k: "clienteId", label: "Cliente", fmt: function (v) { return Util.esc(nomeDe(v)); } },
        { k: "valor", label: "Valor", cls: "num", fmt: function (v) { return Util.esc(Util.brMoeda(v)); } },
        { k: "vencimento", label: "Vencimento", fmt: function (v) { return '<span style="white-space:nowrap">' + Util.esc(Util.brData(v)) + "</span>"; } },
        { k: "_regua", label: "Régua", fmt: function (v, row) { return reguaBadge(row); } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) {
          var out = "";
          if (row.status === "aberta") out += '<button class="btn sm green" data-acao="receber:' + Util.esc(row.id) + '">Receber</button> ';
          out += '<button class="btn sm" data-acao="fatura:' + Util.esc(row.id) + '">🖨 Fatura</button>';
          // aberta com valor errado precisa de caminho de correção: excluir e regerar
          if (row.status === "aberta") out += ' <button class="btn sm danger" data-acao="excluirCobranca:' + Util.esc(row.id) + '" title="Excluir cobrança aberta">✕</button>';
          return out;
        } }
      ];
      var tblCb = UI.tabela(colsCb, cobrancas, { vazio: "Nenhuma cobrança nesta competência. Use “Gerar cobranças da competência”." });

      // ---- Card 2: contratos ----
      var contratosOrd = contratos.map(function (ct) { ct._nome = nomeDe(ct.clienteId); return ct; });
      contratosOrd = Util.ordenaPor(contratosOrd, "_nome");
      var colsCt = [
        { k: "_nome", label: "Cliente", fmt: function (v) { return Util.esc(v); } },
        { k: "valorMensal", label: "Honorário mensal", cls: "num", fmt: function (v) { return Util.esc(Util.brMoeda(v)); } },
        { k: "diaVenc", label: "Dia venc.", cls: "ctr", fmt: function (v) { return Util.esc(v || "—"); } },
        { k: "ativo", label: "Status", fmt: function (v) { return v ? UI.badge("ativo", "verde") : UI.badge("inativo", "cinza"); } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) { return '<button class="btn sm" data-acao="editarContrato:' + Util.esc(row.id) + '">Editar</button>'; } }
      ];
      var tblCt = UI.tabela(colsCt, contratosOrd, { vazio: "Nenhum contrato de honorários ainda." });

      // ---- Card 3 (condicional): inadimplência 30+ dias ----
      // Decisão de suspensão é do SÓCIO, NUNCA automática (escopo 3.17) — aqui é só aviso.
      var criticas = Store.listar("cobrancas").filter(function (c) { return atrasada(c) && diasAtraso(c) >= 30; });
      criticas = Util.ordenaPor(criticas, "vencimento");
      var card3 = "";
      if (criticas.length) {
        var lis = criticas.map(function (c) {
          return "<li><b>" + Util.esc(nomeDe(c.clienteId)) + "</b> — " + Util.esc(compRotulo(c.competencia)) +
            " · " + Util.esc(Util.brMoeda(c.valor)) + " · vencida em " + Util.esc(Util.brData(c.vencimento)) +
            " " + UI.badge("D+" + diasAtraso(c), "vermelho") + "</li>";
        }).join("");
        card3 = '<div class="card"><div class="card-hd"><b class="al">⚠ Inadimplência 30+ dias</b>' +
          '<span class="chip">' + criticas.length + ' cobrança(s)</span></div>' +
          '<div class="card-bd"><ul style="margin:0 0 10px 18px">' + lis + "</ul>" +
          '<div class="fld-d">A decisão de suspender serviços é do sócio — o sistema apenas sinaliza, nunca suspende automaticamente.</div>' +
          "</div></div>";
      }

      return '<div class="page-hd"><div><h1>Honorários</h1>' +
        '<div class="sub">Contratos, cobranças por competência e régua de inadimplência do escritório.</div></div></div>' +
        kpis + toolbar +
        '<div class="card"><div class="card-hd"><b>Cobranças da competência ' + Util.esc(compRotulo(comp)) + '</b>' +
        '<span class="chip">' + cobrancas.length + ' item(ns)</span></div>' +
        '<div class="card-bd">' + tblCb + "</div></div>" +
        '<div class="card"><div class="card-hd"><b>Contratos</b><span class="chip">' + contratos.length + ' contrato(s)</span></div>' +
        '<div class="card-bd">' + tblCt + "</div></div>" +
        card3;
    },

    // Liga o seletor de competência (change -> guarda estado + re-render).
    onMount: function () {
      var self = this, e = UI.el("fin-comp");
      if (e) e.addEventListener("change", function () { self._comp = e.value; App.render(); });
    },

    // ---- Contratos ----

    // Modal compartilhado de contrato. ct=null -> novo (sel de cliente sem contrato).
    _modalContrato: function (ct) {
      var novo = !ct;
      var cliente = ct ? Store.obter("clientes", ct.clienteId) : null;
      var corpoTopo;
      if (novo) {
        // só clientes que AINDA não têm contrato (1 contrato por cliente)
        var livres = Store.listar("clientes").filter(function (c) { return !contratoDe(c.id); });
        if (!livres.length) { UI.toast("Todos os clientes já têm contrato. Edite o existente.", "info"); return; }
        var opCli = [{ v: "", t: "— selecione o cliente —" }];
        for (var i = 0; i < livres.length; i++) opCli.push({ v: livres[i].id, t: nomeCliente(livres[i]) });
        corpoTopo = UI.campo("Cliente", UI.sel("fin-ct-cli", opCli, ""));
      } else {
        corpoTopo = UI.campo("Cliente", '<input class="in" value="' + Util.esc(nomeCliente(cliente)) + '" disabled>');
      }

      var corpo = corpoTopo +
        '<div class="row-3">' +
        UI.campo("Honorário mensal (R$)", UI.inp("fin-ct-valor", ct ? Util.brNum(ct.valorMensal, 2) : "", "0,00")) +
        UI.campo("Dia de vencimento (1-28)", UI.inp("fin-ct-dia", ct ? ct.diaVenc : 10, "10", "number")) +
        UI.campo("Início", UI.inp("fin-ct-inicio", ct ? ct.inicio : Util.hojeISO(), "", "date")) +
        "</div>" +
        UI.campo("Contrato ativo", UI.sel("fin-ct-ativo", [{ v: "1", t: "Sim" }, { v: "0", t: "Não" }], (ct && !ct.ativo) ? "0" : "1")) +
        UI.campo("Observações", UI.inp("fin-ct-obs", ct ? ct.obs : "", "ex.: reajuste anual em janeiro")) +
        '<div class="fld-d" id="fin-ct-dica">' + Util.esc(dicaSugestao(cliente)) + "</div>";

      var ov = UI.modal(novo ? "Novo contrato de honorários" : "Editar contrato", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "primary", onClick: function (fechar) {
          if (!Auth.veFinanceiro() || !Auth.pode("financeiro", novo ? "criar" : "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var clienteId = novo ? UI.v("fin-ct-cli") : ct.clienteId;
          if (!clienteId) { UI.toast("Selecione o cliente.", "alerta"); return; }
          if (novo && contratoDe(clienteId)) { UI.toast("Este cliente já tem contrato.", "alerta"); return; }
          // aceita também decimal com ponto ("1500.00") — senão o parseBR trataria o ponto
          // como milhar e salvaria contrato 100x maior sem aviso
          var vraw = UI.v("fin-ct-valor");
          if (/^\d+\.\d{1,2}$/.test(vraw)) vraw = vraw.replace(".", ",");
          var valor = Util.parseBR(vraw);
          if (!(valor > 0)) { UI.toast("Informe um honorário mensal maior que zero.", "alerta"); return; }
          var dia = Math.round(Util.parseBR(UI.v("fin-ct-dia")));
          if (!(dia >= 1 && dia <= 28)) { UI.toast("Dia de vencimento deve estar entre 1 e 28.", "alerta"); return; }
          var obj = {
            id: "ch_" + clienteId, // determinístico: 1 contrato por cliente (upsert idempotente)
            clienteId: clienteId,
            valorMensal: valor,
            diaVenc: dia,
            inicio: UI.v("fin-ct-inicio") || Util.hojeISO(),
            ativo: UI.v("fin-ct-ativo") === "1",
            obs: UI.v("fin-ct-obs"),
            criadoEm: ct ? (ct.criadoEm || Util.hojeISO()) : Util.hojeISO()
          };
          Store.salvar("contratosHon", obj); // STORAGE_CHEIO -> ui.js mostra toast
          if (global.Audit) global.Audit.log(novo ? "contrato_criar" : "contrato_editar", "contratosHon", obj.id);
          UI.toast("Contrato salvo.", "ok");
          fechar(); App.render();
        } }
      ]);

      // PREFILL: ao escolher o cliente, sugere honorário pela régua de pontos (seção 5).
      if (novo && ov) {
        var selCli = ov.querySelector("#fin-ct-cli");
        if (selCli) selCli.addEventListener("change", function () {
          var c = Store.obter("clientes", selCli.value);
          var dica = ov.querySelector("#fin-ct-dica");
          if (dica) dica.textContent = dicaSugestao(c);
          var inpV = ov.querySelector("#fin-ct-valor");
          if (c && inpV && !Util.parseBR(inpV.value)) inpV.value = Util.brNum(CONFIG.honorarioSugerido(c), 2);
        });
      }
    },

    novoContrato: function () {
      if (semAcesso()) return;
      if (!Auth.pode("financeiro", "criar")) { UI.toast("Sem permissão para criar contratos.", "erro"); return; }
      this._modalContrato(null);
    },

    editarContrato: function (id) {
      if (semAcesso()) return;
      if (!Auth.pode("financeiro", "editar")) { UI.toast("Sem permissão para editar contratos.", "erro"); return; }
      var ct = Store.obter("contratosHon", id);
      if (!ct) { UI.toast("Contrato não encontrado.", "erro"); return; }
      this._modalContrato(ct);
    },

    // ---- Cobranças ----

    // Gera as cobranças da competência selecionada para TODO contrato ativo.
    // Id determinístico clienteId+"|"+competencia -> rodar 2x NÃO duplica (idempotente).
    // Vencimento: padrão de mercado, honorário vence no mês SEGUINTE à competência
    // (serviço de julho cobra-se em agosto): venc = iso(comp+1 mês, min(diaVenc, últimoDia)).
    gerarCompetencia: function () {
      if (semAcesso()) return;
      if (!Auth.pode("financeiro", "criar")) { UI.toast("Sem permissão para gerar cobranças.", "erro"); return; }
      var self = this;
      var comp = this._comp, p = Util.partes(comp + "-01");
      if (!p.y) { UI.toast("Competência inválida.", "erro"); return; }
      // competência no passado gera dívida retroativa p/ todos os contratos — exige confirmação explícita
      var hp = Util.partes(Util.hojeISO()), compAtual = Util.competencia(hp.y, hp.m);
      if (comp < compAtual && !this._confirmouRetro) {
        UI.modal("Gerar competência passada?",
          "<p>Você vai gerar cobranças de <b>" + Util.esc(compRotulo(comp)) + "</b> (competência passada). Elas nascem vencidas e entram na inadimplência. Confirmar?</p>",
          [{ txt: "Cancelar" }, { txt: "Gerar mesmo assim", classe: "danger", onClick: function (fechar) { self._confirmouRetro = true; fechar(); self.gerarCompetencia(); self._confirmouRetro = false; } }]);
        return;
      }
      this._confirmouRetro = false;
      var contratos = Store.listar("contratosHon").filter(function (c) {
        if (!c.ativo) return false;
        // contrato só gera a partir da competência do seu INÍCIO (nada de cobrar quem nem era cliente)
        var ini = String(c.inicio || "").slice(0, 7);
        return !ini || ini <= comp;
      });
      if (!contratos.length) { UI.toast("Nenhum contrato ativo (com início até esta competência) para gerar cobranças.", "info"); return; }

      // mês seguinte normalizado (dez -> jan do ano seguinte) via Date UTC
      var dv = new Date(Date.UTC(p.y, p.m, 1)); // p.m é 1-based -> índice p.m = mês seguinte
      var vy = dv.getUTCFullYear(), vm = dv.getUTCMonth() + 1;
      var ult = Util.ultimoDia(vy, vm);

      var novas = [], jaExistiam = 0, hoje = Util.hojeISO();
      for (var i = 0; i < contratos.length; i++) {
        var ct = contratos[i];
        var id = ct.clienteId + "|" + comp; // DETERMINÍSTICO
        if (Store.obter("cobrancas", id)) { jaExistiam++; continue; } // nunca sobrescreve paga/editada
        var dia = Math.min(Math.max(1, ct.diaVenc || 10), ult);
        novas.push({
          id: id,
          clienteId: ct.clienteId,
          competencia: comp,
          valor: Number(ct.valorMensal) || 0,
          vencimento: Util.iso(vy, vm, dia),
          status: "aberta",
          criadoEm: hoje
        });
      }
      if (novas.length) {
        Store.salvarLote("cobrancas", novas); // STORAGE_CHEIO -> delegação mostra toast
        if (global.Audit) global.Audit.log("cobranca_gerar_lote", "cobrancas", comp + " (" + novas.length + ")");
      }
      UI.toast(novas.length + " cobrança(s) criada(s) · " + jaExistiam + " já existia(m) em " + compRotulo(comp) + ".", novas.length ? "ok" : "info");
      App.render();
    },

    // Baixa de recebimento: forma de pagamento + data -> status "paga".
    // Excluir cobrança ABERTA (correção de valor errado: exclui e regera após ajustar o contrato).
    // Paga NUNCA se exclui (registro financeiro é histórico).
    excluirCobranca: function (id) {
      if (semAcesso()) return;
      if (!Auth.pode("financeiro", "excluir")) { UI.toast("Sem permissão para excluir cobranças.", "erro"); return; }
      var cb = Store.obter("cobrancas", id);
      if (!cb) { UI.toast("Cobrança não encontrada.", "erro"); return; }
      if (cb.status === "paga") { UI.toast("Cobrança paga não pode ser excluída (histórico financeiro).", "alerta"); return; }
      UI.modal("Excluir cobrança aberta",
        "<p>Excluir a cobrança de <b>" + Util.esc(nomeDe(cb.clienteId)) + "</b> — " + Util.esc(compRotulo(cb.competencia)) + " (" + Util.esc(Util.brMoeda(cb.valor)) + ")? Depois de ajustar o contrato, gere a competência de novo.</p>",
        [{ txt: "Cancelar" }, { txt: "Excluir", classe: "danger", onClick: function (fechar) {
          if (!Auth.veFinanceiro() || !Auth.pode("financeiro", "excluir")) { UI.toast("Sem permissão.", "erro"); return; }
          Store.excluir("cobrancas", id);
          if (global.Audit) global.Audit.log("cobranca_excluir", "cobrancas", id);
          UI.toast("Cobrança excluída.", "ok");
          fechar(); App.render();
        } }]);
    },

    receber: function (id) {
      if (semAcesso()) return;
      if (!Auth.pode("financeiro", "editar")) { UI.toast("Sem permissão para dar baixa.", "erro"); return; }
      var cb = Store.obter("cobrancas", id);
      if (!cb) { UI.toast("Cobrança não encontrada.", "erro"); return; }
      if (cb.status === "paga") { UI.toast("Cobrança já está paga.", "info"); return; }
      var cli = Store.obter("clientes", cb.clienteId);
      var corpo = '<p class="fld-d" style="margin-bottom:14px">' + Util.esc(nomeCliente(cli)) + " — " +
        Util.esc(compRotulo(cb.competencia)) + " · " + Util.esc(Util.brMoeda(cb.valor)) + "</p>" +
        '<div class="row">' +
        UI.campo("Forma de pagamento", UI.sel("fin-rc-forma", FORMAS, "pix")) +
        UI.campo("Data do pagamento", UI.inp("fin-rc-data", Util.hojeISO(), "", "date")) +
        "</div>";
      UI.modal("Receber honorário", corpo, [
        { txt: "Cancelar" },
        { txt: "Confirmar recebimento", classe: "green", onClick: function (fechar) {
          if (!Auth.veFinanceiro() || !Auth.pode("financeiro", "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var data = UI.v("fin-rc-data");
          if (!data) { UI.toast("Informe a data do pagamento.", "alerta"); return; }
          cb.status = "paga";
          cb.pagoEm = data;
          cb.formaPgto = UI.v("fin-rc-forma");
          Store.salvar("cobrancas", cb);
          if (global.Audit) global.Audit.log("recebeu", "cobranca", cb.id);
          UI.toast("Recebimento registrado.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    // Fatura impressa (A4, shell da marca) — todo entregável impresso usa _abrirPrint.
    fatura: function (id) {
      if (semAcesso()) return;
      var cb = Store.obter("cobrancas", id);
      if (!cb) { UI.toast("Cobrança não encontrada.", "erro"); return; }
      var cli = Store.obter("clientes", cb.clienteId); // null-safe: cliente pode ter sido excluído
      var stHtml;
      if (cb.status === "paga") stHtml = '<span class="ok">PAGA em ' + Util.esc(Util.brData(cb.pagoEm)) + (cb.formaPgto ? " (" + Util.esc(cb.formaPgto) + ")" : "") + "</span>";
      else if (atrasada(cb)) stHtml = '<span class="al">EM ABERTO — ' + diasAtraso(cb) + " dia(s) de atraso</span>";
      else stHtml = "EM ABERTO";

      var corpo =
        "<h2>Dados da fatura</h2>" +
        "<table>" +
        "<tr><th style='width:30%'>Escritório</th><td>" + Util.esc(CONFIG.marca.nome) + " · " + Util.esc(CONFIG.marca.slogan) + "</td></tr>" +
        "<tr><th>Cliente</th><td>" + Util.esc(nomeCliente(cli)) + "</td></tr>" +
        (cli && cli.cnpj ? "<tr><th>CNPJ</th><td>" + Util.esc(Util.formataCNPJ(cli.cnpj)) + "</td></tr>" : "") +
        "<tr><th>Competência</th><td>" + Util.esc(compRotulo(cb.competencia)) + "</td></tr>" +
        "<tr><th>Vencimento</th><td>" + Util.esc(Util.brData(cb.vencimento)) + "</td></tr>" +
        "<tr><th>Situação</th><td>" + stHtml + "</td></tr>" +
        "</table>" +
        "<h2>Valores</h2>" +
        "<table>" +
        "<tr><th>Descrição</th><th class='dir' style='width:25%'>Valor</th></tr>" +
        "<tr><td>Honorários contábeis — competência " + Util.esc(compRotulo(cb.competencia)) + "</td><td class='dir'>" + Util.esc(Util.brMoeda(cb.valor)) + "</td></tr>" +
        "<tr class='tot'><td>Total</td><td class='dir'>" + Util.esc(Util.brMoeda(cb.valor)) + "</td></tr>" +
        "</table>";

      App._abrirPrint("Fatura de Honorários", corpo);
      if (global.Audit) global.Audit.log("fatura_imprimir", "cobranca", cb.id);
    }
  });
})(window);
