/* =====================================================================
 * bi.js — BI & Rentabilidade · PAINEL DO SÓCIO (seções 3.18 + 10).
 * NÃO cria coleção — AGREGA das existentes (contratosHon, cobrancas,
 * obrigacoes, creditos, declarantes, clientes, usuarios).
 * RBAC em DOIS NÍVEIS (o módulo é soPerfil socio/gerente no CONFIG):
 *   - Auth.veFinanceiro() (sócio): vê TUDO (MRR, inadimplência, multas,
 *     receita nova, rentabilidade por cliente e relatório impresso).
 *   - sem veFinanceiro (gerente): vê SÓ os KPIs operacionais + carga por
 *     analista; a rentabilidade e o relatório financeiro ficam ocultos.
 * READ-ONLY: nenhuma escrita, nenhum Audit (só leitura/impressão).
 * ES5 estrito (var/function/concat). Orquestra Store + Auth + UI + CONFIG.
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  // ---------- Helpers puros (closure do módulo) ----------

  // Padrão de nome entre telas; null-safe (cliente pode ter sido excluído).
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(cliente excluído)"; }

  // Contrato de honorário do cliente (id determinístico "ch_"+clienteId).
  function contratoDe(clienteId) { return Store.obter("contratosHon", "ch_" + clienteId); }

  // Custo estimado por ponto de complexidade.
  // 1º) usa o custo/ponto configurado pelo sócio (Configurações → Parâmetros);
  // 2º) senão, proxy de 35% do valor/ponto (ex.: 45 × 0,35 = 15,75); 3º) 15 fixo.
  function custoPorPonto() {
    var pr = CONFIG.precificacao || {};
    // custoPorPonto configurado (inclusive 0 explícito) vence; proxy 35% só quando não configurado.
    if (pr.custoPorPonto != null && pr.custoPorPonto >= 0) return pr.custoPorPonto;
    return pr.valorPonto ? pr.valorPonto * 0.35 : 15;
  }

  // Valor da multa de uma obrigação — robusto a número OU objeto {valor}.
  function valMulta(ob) {
    var m = ob.multa;
    if (m == null) return 0;
    if (typeof m === "number") return m;
    if (typeof m === "object") return Number(m.valor != null ? m.valor : m.total) || 0;
    return Util.parseBR(m);
  }

  // Cobrança atrasada = derivado (status aberta && venceu), nunca gravado.
  function atrasada(cb) {
    if (cb.status !== "aberta") return false;
    var d = Util.diasAte(cb.vencimento);
    return d != null && d < 0;
  }

  // Data de conclusão de uma obrigação (última entrada "concluida" no histórico).
  function dataConclusao(ob) {
    var h = ob.historico || [];
    for (var i = h.length - 1; i >= 0; i--) if (h[i].status === "concluida") return h[i].quando;
    return ob.concluidoEm || null;
  }

  // Honorário de êxito potencial de um crédito (valorLevantado × %).
  function honorarioExito(cr) { return (Number(cr.valorLevantado) || 0) * (Number(cr.honorarioExitoPct) || 0) / 100; }

  // Badge de saúde da margem: prejuízo (neg) · margem baixa (<20%) · saudável.
  function margemBadge(hon, margem) {
    if (margem < 0) return UI.badge("prejuízo", "vermelho");
    var pct = hon > 0 ? (margem / hon) * 100 : 0;
    if (pct < 20) return UI.badge("margem baixa", "amber");
    return UI.badge("saudável", "verde");
  }
  // Recomendação textual espelhando o badge.
  function recomendacao(hon, margem) {
    if (margem < 0) return "automatizar ou reajustar";
    var pct = hon > 0 ? (margem / hon) * 100 : 0;
    if (pct < 20) return "revisar preço";
    return "OK";
  }

  // ---------- Agregação central (usada pelo render E pelo relatório) ----------
  // Recalcula tudo a partir das coleções existentes — sem estado persistido.
  function agregar() {
    var i;
    var clientes = Store.listar("clientes");
    var ativos = clientes.filter(function (c) { return c.status === "ativo"; });

    // MRR — soma dos contratos de honorário ATIVOS.
    var contratos = Store.listar("contratosHon"), mrr = 0;
    for (i = 0; i < contratos.length; i++) if (contratos[i].ativo) mrr += Number(contratos[i].valorMensal) || 0;

    // Inadimplência % — cobranças atrasadas / total de cobranças.
    var cobrancas = Store.listar("cobrancas"), nAtr = 0;
    for (i = 0; i < cobrancas.length; i++) if (atrasada(cobrancas[i])) nAtr++;
    var inad = cobrancas.length ? (nAtr / cobrancas.length) * 100 : 0;

    // Obrigações no prazo % + multas incorridas.
    var obrs = Store.listar("obrigacoes");
    var totConc = 0, noPrazo = 0, totMulta = 0;
    for (i = 0; i < obrs.length; i++) {
      var ob = obrs[i];
      totMulta += valMulta(ob);
      if (ob.status === "concluida") {
        totConc++;
        var dc = dataConclusao(ob);
        if (dc && ob.prazoAjustado && String(ob.prazoAjustado) >= String(dc)) noPrazo++;
      }
    }
    var prazoPct = totConc ? (noPrazo / totConc) * 100 : 0;

    // Receita nova = êxito potencial (créditos não-indeferidos) + preço dos declarantes entregues.
    var creditos = Store.listar("creditos"), recNova = 0;
    for (i = 0; i < creditos.length; i++) if (creditos[i].status !== "indeferido") recNova += honorarioExito(creditos[i]);
    var declarantes = Store.listar("declarantes");
    for (i = 0; i < declarantes.length; i++) if (declarantes[i].status === "entregue") recNova += Number(declarantes[i].preco) || 0;

    // Rentabilidade por cliente ATIVO — honorário mensal − custo estimado (pontos × custo/ponto).
    var cpp = custoPorPonto(), rent = [], somaHon = 0, somaCusto = 0;
    for (i = 0; i < ativos.length; i++) {
      var cli = ativos[i];
      var ct = contratoDe(cli.id);
      var hon = (ct && ct.ativo) ? (Number(ct.valorMensal) || 0) : 0;
      var pts = CONFIG.calcPontos(cli);
      var custo = pts * cpp;
      var margem = hon - custo;
      somaHon += hon; somaCusto += custo;
      rent.push({ nome: nomeCliente(cli), hon: hon, pts: pts, custo: custo, margem: margem });
    }
    rent = Util.ordenaPor(rent, "margem"); // pior margem primeiro (quem dá prejuízo)

    // Carga por analista (3.18) — soma dos pontos da carteira × capacidade.
    var usuarios = Store.listar("usuarios").filter(function (u) { return u.perfil === "analista" && u.ativo !== false; });
    var carga = usuarios.map(function (u) {
      var ids = u.carteiraClientes || [], soma = 0, n = 0;
      for (var j = 0; j < ids.length; j++) {
        var c = Store.obter("clientes", ids[j]);
        if (c) { soma += CONFIG.calcPontos(c); n++; }
      }
      // capacidade 0 é válida (analista sem folga) — não pode virar 100 e esconder sobrecarga;
      // só cai no default 100 quando NÃO configurada (null/undefined/NaN).
      var cap = (u.capacidadePontos != null ? Number(u.capacidadePontos) : 100);
      if (isNaN(cap)) cap = 100;
      return { nome: u.nome || "(sem nome)", pontos: soma, clientes: n, capacidade: cap, over: soma > cap };
    });
    carga = Util.ordenaPor(carga, "pontos", true);

    return {
      nAtivos: ativos.length, mrr: mrr, inad: inad, nAtr: nAtr, nCob: cobrancas.length,
      prazoPct: prazoPct, totConc: totConc, noPrazo: noPrazo, totMulta: totMulta,
      recNova: recNova, rent: rent, somaHon: somaHon, somaCusto: somaCusto,
      somaMargem: somaHon - somaCusto, carga: carga
    };
  }

  // Helper de KPI (n grande + label; variação de cor .al/.ok/.wr).
  function kpi(n, label, cor) {
    return '<div class="kpi' + (cor ? " " + cor : "") + '">' +
      '<div class="n">' + n + '</div><div class="l">' + Util.esc(label) + '</div></div>';
  }

  // ---------- View ----------
  global.BiView = App.registrar({
    id: "bi",
    titulo: "BI & Rentabilidade",

    render: function () {
      var veFin = Auth.veFinanceiro();
      var a = agregar();

      // ---- KPIs ----
      var opCliAtivos = kpi(a.nAtivos, "Clientes ativos", "");
      var opPrazo = kpi(a.totConc ? (Util.brNum(a.prazoPct, 0) + "%") : "—", "Obrigações no prazo",
        a.totConc ? (a.prazoPct >= 90 ? "ok" : (a.prazoPct >= 75 ? "wr" : "al")) : "");

      var kpis;
      if (veFin) {
        kpis =
          kpi(Util.brMoeda(a.mrr), "MRR (contratos ativos)", "") +
          opCliAtivos +
          kpi(Util.brNum(a.inad, 0) + "%", "Inadimplência", a.nAtr ? "al" : "ok") +
          opPrazo +
          kpi(Util.brMoeda(a.totMulta), "Multas incorridas", a.totMulta > 0 ? "al" : "") +
          kpi(Util.brMoeda(a.recNova), "Receita nova (potencial)", "ok");
      } else {
        // gerente sem verFinanceiro: só os operacionais (sem valores em R$).
        kpis = opCliAtivos + opPrazo;
      }

      // ---- Toolbar (relatório do sócio só p/ quem vê financeiro) ----
      var toolbar = veFin
        ? '<div class="toolbar"><button class="btn primary" data-acao="relatorio">' + UI.icone("trend", 16) + ' 🖨 Relatório do Sócio</button></div>'
        : "";

      // ---- Card: Rentabilidade por cliente (só veFinanceiro) ----
      var cardRent;
      if (veFin) {
        var rows = a.rent.map(function (r) {
          return {
            nome: r.nome, hon: r.hon, pts: r.pts, custo: r.custo, margem: r.margem,
            _rec: recomendacao(r.hon, r.margem)
          };
        });
        var cols = [
          { k: "nome", label: "Cliente", fmt: function (v) { return Util.esc(v); } },
          { k: "hon", label: "Honorário", cls: "num", fmt: function (v) { return Util.esc(Util.brMoeda(v)); } },
          { k: "pts", label: "Pontos", cls: "ctr", fmt: function (v) { return Util.esc(Util.brNum(Number(v) || 0, 0)); } },
          { k: "custo", label: "Custo estimado", cls: "num", fmt: function (v) { return Util.esc(Util.brMoeda(v)); } },
          { k: "margem", label: "Margem", cls: "num", fmt: function (v, row) {
            return Util.esc(Util.brMoeda(v)) + " " + margemBadge(row.hon, row.margem);
          } },
          { k: "_rec", label: "Recomendação", fmt: function (v) { return Util.esc(v); } }
        ];
        var tbl = UI.tabela(cols, rows, { vazio: "Nenhum cliente ativo para avaliar rentabilidade." });
        cardRent =
          '<div class="card"><div class="card-hd"><b>Rentabilidade por cliente</b>' +
          '<span class="chip">' + a.rent.length + ' cliente(s) · piores margens no topo</span></div>' +
          '<div class="card-bd">' + tbl +
          '<div class="fld-d" style="margin-top:8px">Custo estimado = pontos de complexidade × ' +
          Util.esc(Util.brMoeda(custoPorPonto())) + '/ponto (proxy interno). Margem negativa = prejuízo.</div>' +
          "</div></div>";
      } else {
        cardRent =
          '<div class="card"><div class="card-hd"><b>Rentabilidade por cliente</b></div>' +
          '<div class="card-bd"><div class="empty">Sem acesso ao BI financeiro.</div></div></div>';
      }

      // ---- Card: Carga por analista (pontos) — operacional (3.18), sempre visível ----
      var linhasCarga = a.carga.map(function (c) {
        var pct = c.capacidade ? (c.pontos / c.capacidade) * 100 : 0;
        var w = Math.max(0, Math.min(100, Math.round(pct)));
        var cor = c.over ? "#dc2626" : "linear-gradient(90deg,#2e6f9e,#16a34a)";
        var bar = '<div style="background:#e2e8f0;border-radius:8px;height:14px;overflow:hidden">' +
          '<div style="height:100%;width:' + w + '%;background:' + cor + '"></div></div>';
        var topo = '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:5px">' +
          '<b>' + Util.esc(c.nome) + '</b>' +
          '<span class="fld-d">' + Util.esc(Util.brNum(c.pontos, 0)) + " / " + Util.esc(Util.brNum(c.capacidade, 0)) +
          " pts · " + c.clientes + " cliente(s) " + (c.over ? UI.badge("acima do teto", "vermelho") : "") + "</span></div>";
        return '<div style="margin:10px 0">' + topo + bar + "</div>";
      }).join("");
      var cardCarga =
        '<div class="card"><div class="card-hd"><b>Carga por analista (pontos)</b>' +
        '<span class="chip">' + a.carga.length + ' analista(s)</span></div>' +
        '<div class="card-bd">' + (a.carga.length ? linhasCarga : '<div class="empty">Nenhum analista com carteira atribuída.</div>') + "</div></div>";

      var aviso = veFin ? "" : '<span class="chip">Valores financeiros ocultos para o seu perfil</span>';

      return '<div class="page-hd"><div><h1>BI &amp; Rentabilidade</h1>' +
        '<div class="sub">Painel do sócio — indicadores do escritório, rentabilidade por cliente e carga da equipe.</div></div>' +
        '<div>' + aviso + "</div></div>" +
        '<div class="grid-kpi">' + kpis + "</div>" +
        toolbar +
        cardRent +
        cardCarga;
    },

    // ---- Relatório do Sócio (A4, shell da marca) — só quem vê financeiro ----
    relatorio: function () {
      if (!Auth.veFinanceiro()) { UI.toast("Sem acesso ao BI financeiro.", "erro"); return; }
      var a = agregar();

      var indicadores =
        "<h2>Indicadores do escritório</h2><table>" +
        "<tr><th style='width:60%'>Indicador</th><th class='dir'>Valor</th></tr>" +
        "<tr><td>MRR (contratos ativos)</td><td class='dir'>" + Util.esc(Util.brMoeda(a.mrr)) + "</td></tr>" +
        "<tr><td>Clientes ativos</td><td class='dir'>" + a.nAtivos + "</td></tr>" +
        "<tr><td>Inadimplência (" + a.nAtr + "/" + a.nCob + " cobranças)</td><td class='dir " + (a.nAtr ? "al" : "ok") + "'>" + Util.esc(Util.brNum(a.inad, 0)) + "%</td></tr>" +
        "<tr><td>Obrigações no prazo (" + a.noPrazo + "/" + a.totConc + " concluídas)</td><td class='dir'>" + (a.totConc ? (Util.esc(Util.brNum(a.prazoPct, 0)) + "%") : "—") + "</td></tr>" +
        "<tr><td>Multas incorridas</td><td class='dir " + (a.totMulta > 0 ? "al" : "") + "'>" + Util.esc(Util.brMoeda(a.totMulta)) + "</td></tr>" +
        "<tr class='tot'><td>Receita nova potencial</td><td class='dir'>" + Util.esc(Util.brMoeda(a.recNova)) + "</td></tr>" +
        "</table>";

      var rentRows = a.rent.map(function (r) {
        return "<tr><td>" + Util.esc(r.nome) + "</td>" +
          "<td class='dir'>" + Util.esc(Util.brMoeda(r.hon)) + "</td>" +
          "<td class='dir'>" + Util.esc(Util.brNum(r.pts, 0)) + "</td>" +
          "<td class='dir'>" + Util.esc(Util.brMoeda(r.custo)) + "</td>" +
          "<td class='dir " + (r.margem < 0 ? "al" : "ok") + "'>" + Util.esc(Util.brMoeda(r.margem)) + "</td>" +
          "<td>" + Util.esc(recomendacao(r.hon, r.margem)) + "</td></tr>";
      }).join("");
      if (!rentRows) rentRows = "<tr><td colspan='6'>Nenhum cliente ativo.</td></tr>";

      var rentabilidade =
        "<h2>Rentabilidade por cliente</h2><table>" +
        "<tr><th>Cliente</th><th class='dir'>Honorário</th><th class='dir'>Pontos</th><th class='dir'>Custo est.</th><th class='dir'>Margem</th><th>Recomendação</th></tr>" +
        rentRows +
        "<tr class='tot'><td>Total</td><td class='dir'>" + Util.esc(Util.brMoeda(a.somaHon)) + "</td><td class='dir'>—</td>" +
        "<td class='dir'>" + Util.esc(Util.brMoeda(a.somaCusto)) + "</td>" +
        "<td class='dir " + (a.somaMargem < 0 ? "al" : "ok") + "'>" + Util.esc(Util.brMoeda(a.somaMargem)) + "</td><td>—</td></tr>" +
        "</table>" +
        "<p style='margin-top:14px;color:#64748b;font-size:11px'>Custo estimado = pontos de complexidade × " +
        Util.esc(Util.brMoeda(custoPorPonto())) + "/ponto (proxy interno de custo). Documento de gestão interna do escritório.</p>";

      App._abrirPrint("Painel do Sócio", indicadores + rentabilidade);
    }
  });
})(window);
