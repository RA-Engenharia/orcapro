/* =====================================================================
 * wiki.js — Base de Conhecimento Interna (seção 3.23).
 * Memória do escritório: procedimentos, particularidades de cliente,
 * pegadinhas de sistema municipal e — o mais importante — LIÇÕES
 * APRENDIDAS (prevenção de erro/multa, destacadas em âmbar).
 * Conteúdo, não planilha: lista em CARDS. Busca e filtro de categoria
 * agem no DOM no onMount (sem re-render), preservando o texto digitado.
 * Coleção "wiki": {id, titulo, categoria, conteudo, tags[], clienteId?,
 *   autor(usuarioId), atualizadoEm(ISO), criadoEm(ISO)}.
 * ES5 estrito (var/function/concat). Orquestra Store + Auth + UI + App.
 * ===================================================================== */
(function (global) {
  "use strict";
  var Store = global.Store, Auth = global.Auth, Util = global.Util, UI = global.UI, App = global.App;

  // Categorias (rótulo + cor do badge). Lição aprendida em âmbar = prevenção.
  var CATS = [
    { v: "procedimento",       t: "Procedimento",        cor: "azul" },
    { v: "cliente_especifico", t: "Específico do cliente", cor: "roxo" },
    { v: "sistema_municipal",  t: "Sistema municipal",    cor: "cinza" },
    { v: "licao_aprendida",    t: "Lição aprendida",      cor: "amber" }
  ];
  function catMeta(v) { for (var i = 0; i < CATS.length; i++) if (CATS[i].v === v) return CATS[i]; return { v: v, t: v || "—", cor: "cinza" }; }

  // ---------- Helpers puros ----------
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(cliente excluído)"; }
  function idUsuario() { var u = Auth.usuario(); return u ? u.id : null; }

  // Mapa usuarioId -> nome (autor exibível; null-safe).
  function mapaAutores() {
    var us = Store.listar("usuarios"), m = {}, i;
    for (i = 0; i < us.length; i++) m[us[i].id] = us[i].nome || us[i].email || us[i].id;
    return m;
  }
  function nomeAutor(m, id) { return id ? (m[id] || "(usuário removido)") : "—"; }

  // Texto de busca de um artigo (título + conteúdo + tags), minúsculo p/ filtro DOM.
  function textoBusca(a) {
    var tags = (a.tags || []).join(" ");
    return String((a.titulo || "") + " " + (a.conteudo || "") + " " + tags).toLowerCase();
  }

  // Trecho do conteúdo p/ o card (1 linha, sem quebra) — 120 chars.
  function trecho(txt) {
    var s = String(txt || "").replace(/\s+/g, " ").trim();
    if (!s) return "(sem conteúdo)";
    return s.length > 120 ? s.slice(0, 120) + "…" : s;
  }

  // Chips de tags (escapados).
  function chipsTags(tags) {
    if (!tags || !tags.length) return "";
    var out = '<div style="margin:8px 0 2px">';
    for (var i = 0; i < tags.length; i++) out += '<span class="chip">#' + Util.esc(tags[i]) + "</span>";
    return out + "</div>";
  }

  // Parse do input de tags "a, b ,c" -> ["a","b","c"] (sem vazios, sem duplicadas).
  function parseTags(raw) {
    var parts = String(raw || "").split(","), out = [], vistos = {}, i, t, k;
    for (i = 0; i < parts.length; i++) {
      t = parts[i].replace(/^\s+|\s+$/g, "");
      if (!t) continue;
      k = t.toLowerCase();
      if (vistos[k]) continue;
      vistos[k] = 1; out.push(t);
    }
    return out;
  }

  // ---------- View ----------
  global.WikiView = App.registrar({
    id: "wiki",
    titulo: "Base de Conhecimento",

    render: function () {
      var artigos = Store.listar("wiki");
      var autores = mapaAutores();
      var podeCriar = Auth.pode("wiki", "criar");
      var podeEditar = Auth.pode("wiki", "editar");
      var podeExcluir = Auth.pode("wiki", "excluir");
      var i;

      // ---- Card topo: lições aprendidas recentes (últimas 3) — cultura de prevenção ----
      var licoes = artigos.filter(function (a) { return a.categoria === "licao_aprendida"; });
      licoes = Util.ordenaPor(licoes, "atualizadoEm", true).slice(0, 3);
      var cardLicoes = "";
      if (licoes.length) {
        var lis = licoes.map(function (a) {
          return '<li style="margin-bottom:8px">' +
            '<b>' + Util.esc(a.titulo || "(sem título)") + "</b> " +
            '<span style="color:var(--mut)">— ' + Util.esc(trecho(a.conteudo)) + "</span> " +
            '<a href="#" class="wiki-link" data-acao="abrir:' + Util.esc(a.id) + '" style="white-space:nowrap">abrir »</a>' +
            "</li>";
        }).join("");
        cardLicoes =
          '<div class="card" style="border-left:4px solid var(--amber,#f59e0b)">' +
          '<div class="card-hd"><b class="wr">⚠ Lições aprendidas recentes</b>' +
          '<span class="chip">prevenção de erro/multa</span></div>' +
          '<div class="card-bd"><ul style="margin:0 0 0 18px;padding:0">' + lis + "</ul></div></div>";
      }

      // ---- Toolbar: busca + filtro de categoria + novo ----
      var opsCat = [{ v: "", t: "Todas as categorias" }];
      for (i = 0; i < CATS.length; i++) opsCat.push({ v: CATS[i].v, t: CATS[i].t });
      var toolbar =
        '<div class="toolbar">' +
        '<div class="fld" style="margin:0;flex:1;min-width:200px"><input id="wiki-busca" class="in" type="text" placeholder="Buscar por título, conteúdo ou tag…"></div>' +
        UI.sel("wiki-cat", opsCat, "") +
        (podeCriar ? '<button class="btn primary" data-acao="novo">' + UI.icone("plus", 16) + " Novo artigo</button>" : "") +
        "</div>";

      // ---- Lista em cards ----
      var artigosOrd = Util.ordenaPor(artigos, "atualizadoEm", true);
      var cards = "";
      for (i = 0; i < artigosOrd.length; i++) {
        var a = artigosOrd[i];
        var meta = catMeta(a.categoria);
        var destaque = a.categoria === "licao_aprendida";
        var cli = a.clienteId ? Store.obter("clientes", a.clienteId) : null;
        var acoes = '<button class="btn sm" data-acao="abrir:' + Util.esc(a.id) + '">Abrir</button>';
        if (podeEditar) acoes += ' <button class="btn sm" data-acao="editar:' + Util.esc(a.id) + '">Editar</button>';
        if (podeExcluir) acoes += ' <button class="btn sm danger" data-acao="excluir:' + Util.esc(a.id) + '">Excluir</button>';

        cards +=
          '<div class="card wiki-card" data-cat="' + Util.esc(a.categoria || "") + '" data-busca="' + Util.esc(textoBusca(a)) + '"' +
          ' style="margin-bottom:12px' + (destaque ? ";border-left:4px solid var(--amber,#f59e0b)" : "") + '">' +
          '<div class="card-bd">' +
          '<div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">' +
          '<div style="min-width:0">' +
          '<h3 style="margin:0 0 6px;font-size:16px">' + Util.esc(a.titulo || "(sem título)") + "</h3>" +
          UI.badge(meta.t, meta.cor) +
          (cli || a.clienteId ? ' <span class="badge badge-cinza">' + Util.esc(nomeCliente(cli)) + "</span>" : "") +
          "</div>" +
          '<div style="white-space:nowrap">' + acoes + "</div>" +
          "</div>" +
          chipsTags(a.tags) +
          '<p style="margin:8px 0 6px;color:var(--mut)">' + Util.esc(trecho(a.conteudo)) + "</p>" +
          '<div class="fld-d">por ' + Util.esc(nomeAutor(autores, a.autor)) + " · " + Util.esc(Util.brData(a.atualizadoEm || a.criadoEm)) + "</div>" +
          "</div></div>";
      }
      if (!artigosOrd.length) {
        cards = '<div class="empty">Nenhum artigo ainda. Registre o primeiro procedimento ou lição aprendida do escritório.</div>';
      }
      // aviso de "nada encontrado" para o filtro DOM (fica oculto até zerar resultados)
      var vazioFiltro = '<div class="empty" id="wiki-vazio-filtro" style="display:none">Nenhum artigo corresponde à busca/filtro.</div>';

      return '<div class="page-hd"><div><h1>Base de Conhecimento</h1>' +
        '<div class="sub">A memória do escritório: procedimentos, particularidades de cliente, sistemas municipais e lições aprendidas.</div></div></div>' +
        cardLicoes + toolbar +
        '<div id="wiki-lista">' + cards + vazioFiltro + "</div>";
    },

    // Busca + filtro de categoria agem no DOM (sem re-render — preserva o que foi digitado).
    onMount: function (el) {
      var busca = el.querySelector ? el.querySelector("#wiki-busca") : null;
      var cat = el.querySelector ? el.querySelector("#wiki-cat") : null;
      var lista = el.querySelector ? el.querySelector("#wiki-lista") : null;
      if (!lista) return;
      var vazio = lista.querySelector("#wiki-vazio-filtro");

      function aplicar() {
        var q = busca ? busca.value.replace(/^\s+|\s+$/g, "").toLowerCase() : "";
        var c = cat ? cat.value : "";
        var cards = lista.querySelectorAll(".wiki-card");
        var visiveis = 0, j;
        for (j = 0; j < cards.length; j++) {
          var card = cards[j];
          var okCat = !c || card.getAttribute("data-cat") === c;
          var okQ = !q || (card.getAttribute("data-busca") || "").indexOf(q) >= 0;
          var show = okCat && okQ;
          card.style.display = show ? "" : "none";
          if (show) visiveis++;
        }
        if (vazio) vazio.style.display = (cards.length && visiveis === 0) ? "" : "none";
      }
      if (busca) busca.addEventListener("input", aplicar);
      if (cat) cat.addEventListener("change", aplicar);
    },

    // ---- Abrir (leitura completa) ----
    abrir: function (id) {
      var a = Store.obter("wiki", id);
      if (!a) { UI.toast("Artigo não encontrado.", "erro"); return; }
      var meta = catMeta(a.categoria);
      var cli = a.clienteId ? Store.obter("clientes", a.clienteId) : null;
      var autores = mapaAutores();

      var cabec = '<div style="margin-bottom:10px">' + UI.badge(meta.t, meta.cor) +
        (cli || a.clienteId ? ' <span class="badge badge-cinza">' + Util.esc(nomeCliente(cli)) + "</span>" : "") +
        "</div>";
      var meta2 = '<div class="fld-d" style="margin-bottom:10px">por ' + Util.esc(nomeAutor(autores, a.autor)) +
        " · atualizado em " + Util.esc(Util.brData(a.atualizadoEm || a.criadoEm)) + "</div>";
      // white-space:pre-wrap preserva quebras de linha do texto (conteúdo, não HTML)
      var corpo = cabec + meta2 + chipsTags(a.tags) +
        '<div style="white-space:pre-wrap;line-height:1.55;margin-top:10px;max-height:60vh;overflow:auto">' +
        Util.esc(a.conteudo || "(sem conteúdo)") + "</div>";

      var botoes = [{ txt: "Fechar" }];
      if (Auth.pode("wiki", "editar")) botoes.push({ txt: "Editar", classe: "primary", onClick: function (fechar) { fechar(); global.WikiView.editar(id); } });
      UI.modal(a.titulo || "(sem título)", corpo, botoes);
    },

    // ---- Novo / Editar (modal compartilhado) ----
    _modalArtigo: function (a) {
      var novo = !a;
      var opsCat = CATS.map(function (c) { return { v: c.v, t: c.t }; });
      var opsCli = [{ v: "", t: "— nenhum (geral) —" }];
      var clientes = Util.ordenaPor(Store.listar("clientes"), "razaoSocial");
      for (var i = 0; i < clientes.length; i++) opsCli.push({ v: clientes[i].id, t: nomeCliente(clientes[i]) });

      var corpo =
        UI.campo("Título", UI.inp("wiki-titulo", a ? a.titulo : "", "ex.: Como emitir NFS-e no ISS de Uberlândia")) +
        '<div class="row">' +
        UI.campo("Categoria", UI.sel("wiki-cat-f", opsCat, a ? a.categoria : "procedimento")) +
        UI.campo("Cliente (se específico)", UI.sel("wiki-cli-f", opsCli, a ? (a.clienteId || "") : "")) +
        "</div>" +
        UI.campo("Conteúdo",
          '<textarea id="wiki-conteudo-f" class="in" style="min-height:220px;resize:vertical;font-family:inherit;line-height:1.5" ' +
          'placeholder="Descreva o procedimento, a particularidade ou a lição aprendida. Quebras de linha são preservadas.">' +
          Util.esc(a ? a.conteudo : "") + "</textarea>") +
        UI.campo("Tags (separadas por vírgula)", UI.inp("wiki-tags-f", a ? (a.tags || []).join(", ") : "", "ex.: iss, nfse, uberlandia"),
          "Lição aprendida? Marque a categoria — ela é destacada em âmbar como prevenção de erro/multa.");

      UI.modal(novo ? "Novo artigo" : "Editar artigo", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "primary", onClick: function (fechar) {
          if (!Auth.pode("wiki", novo ? "criar" : "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var titulo = UI.v("wiki-titulo");
          if (!titulo) { UI.toast("Informe o título do artigo.", "alerta"); return; }
          var conteudo = UI.v("wiki-conteudo-f");
          if (!conteudo) { UI.toast("O conteúdo não pode ficar vazio.", "alerta"); return; }
          var categoria = UI.v("wiki-cat-f") || "procedimento";
          var clienteId = UI.v("wiki-cli-f") || null;
          var obj = {
            id: novo ? Util.uid("wiki") : a.id,
            titulo: titulo,
            categoria: categoria,
            conteudo: conteudo,
            tags: parseTags(UI.v("wiki-tags-f")),
            clienteId: clienteId,
            autor: novo ? idUsuario() : (a.autor || idUsuario()),
            criadoEm: novo ? Util.hojeISO() : (a.criadoEm || Util.hojeISO()),
            atualizadoEm: Util.hojeISO()
          };
          Store.salvar("wiki", obj); // STORAGE_CHEIO -> delegação/modal mostra toast
          if (global.Audit) global.Audit.log(novo ? "wiki_criar" : "wiki_editar", "wiki", obj.id);
          UI.toast("Artigo salvo.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    novo: function () {
      if (!Auth.pode("wiki", "criar")) { UI.toast("Sem permissão para criar artigos.", "erro"); return; }
      this._modalArtigo(null);
    },

    editar: function (id) {
      if (!Auth.pode("wiki", "editar")) { UI.toast("Sem permissão para editar artigos.", "erro"); return; }
      var a = Store.obter("wiki", id);
      if (!a) { UI.toast("Artigo não encontrado.", "erro"); return; }
      this._modalArtigo(a);
    },

    excluir: function (id) {
      if (!Auth.pode("wiki", "excluir")) { UI.toast("Sem permissão para excluir artigos.", "erro"); return; }
      var a = Store.obter("wiki", id);
      if (!a) { UI.toast("Artigo não encontrado.", "erro"); return; }
      UI.modal("Excluir artigo",
        "<p>Excluir <b>" + Util.esc(a.titulo || "(sem título)") + "</b> da base de conhecimento? Esta ação não pode ser desfeita.</p>",
        [{ txt: "Cancelar" }, { txt: "Excluir", classe: "danger", onClick: function (fechar) {
          if (!Auth.pode("wiki", "excluir")) { UI.toast("Sem permissão.", "erro"); return; }
          Store.excluir("wiki", id);
          if (global.Audit) global.Audit.log("wiki_excluir", "wiki", id);
          UI.toast("Artigo excluído.", "ok");
          fechar(); App.render();
        } }]);
    }
  });
})(window);
