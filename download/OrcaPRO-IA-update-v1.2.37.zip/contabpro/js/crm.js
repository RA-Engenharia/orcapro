/* =====================================================================
 * crm.js — CRM & Propostas (seções 3.1 + 5). Funil de leads em kanban
 * (novo → contato → proposta → ganho | perdido), honorário sugerido pela
 * régua de pontos (CONFIG.honorarioSugerido) e proposta impressa via
 * App._abrirPrint. Ganho converte em cliente "prospect" (idempotente).
 * ES5 estrito (var/function/concatenação). Todo dado de usuário -> Util.esc.
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
      Auth = global.Auth, UI = global.UI, App = global.App;

  // Siglas das 27 unidades federativas (mesmo conjunto do clientes.js)
  var UFS = ["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS",
             "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC",
             "SP", "SE", "TO"];

  // Etapas do funil, na ordem do kanban
  var ETAPAS = ["novo", "contato", "proposta", "ganho", "perdido"];
  var ETAPA_LBL = { novo: "Novo lead", contato: "Em contato", proposta: "Proposta enviada", ganho: "Ganho", perdido: "Perdido" };
  var ETAPA_COR = { novo: "azul", contato: "amber", proposta: "roxo", ganho: "verde", perdido: "vermelho" };

  var ORIGENS = [
    { v: "indicacao", t: "Indicação", cor: "verde" },
    { v: "site", t: "Site", cor: "azul" },
    { v: "instagram", t: "Instagram", cor: "roxo" },
    { v: "outro", t: "Outro", cor: "cinza" }
  ];
  var MOTIVOS_PERDA = [
    { v: "preco", t: "Preço" },
    { v: "timing", t: "Timing (não é o momento)" },
    { v: "concorrente", t: "Ficou com concorrente" },
    { v: "sem_resposta", t: "Sem resposta" },
    { v: "outro", t: "Outro" }
  ];

  // ---------- Helpers puros ----------
  function nomeLead(l) { return (l && (l.razaoSocial || l.nomeFantasia || l.nome)) || "(sem nome)"; } // padrão de nome entre telas
  function ativo(l) { return l.etapa !== "ganho" && l.etapa !== "perdido"; }
  function anoCorrente() { return new Date().getFullYear(); }

  function origemInfo(v) {
    for (var i = 0; i < ORIGENS.length; i++) if (ORIGENS[i].v === v) return ORIGENS[i];
    return { v: v || "outro", t: v || "—", cor: "cinza" };
  }
  function motivoLbl(v) {
    for (var i = 0; i < MOTIVOS_PERDA.length; i++) if (MOTIVOS_PERDA[i].v === v) return MOTIVOS_PERDA[i].t;
    return v || "—";
  }
  function regimeNome(id) {
    for (var i = 0; i < CONFIG.regimes.length; i++) if (CONFIG.regimes[i].id === id) return CONFIG.regimes[i].nome;
    return id || "—";
  }
  function segNome(id) {
    for (var i = 0; i < CONFIG.segmentos.length; i++) if (CONFIG.segmentos[i].id === id) return CONFIG.segmentos[i].nome;
    return id;
  }
  // Objeto no formato aceito por CONFIG.calcPontos/honorarioSugerido
  function leadLike(l) {
    return { regime: l.regime, funcionarios: l.funcionarios || 0, notasMes: l.notasMes || 0, segmento: l.segmento || [] };
  }

  // Linhas de composição dos pontos (espelha a régua da seção 5 — mesma conta do CONFIG.calcPontos)
  function composicaoPontos(l) {
    var pr = CONFIG.precificacao, out = [], i;
    for (i = 0; i < CONFIG.regimes.length; i++) {
      if (CONFIG.regimes[i].id === l.regime) { out.push({ item: "Regime tributário", det: CONFIG.regimes[i].nome, pts: CONFIG.regimes[i].pontos }); break; }
    }
    var faixaF = pr.faixaFuncionarios || 5;
    var ptsF = Math.floor((l.funcionarios || 0) / faixaF) * (pr.pontosPorFaixaFuncionarios || 1);
    if (ptsF) out.push({ item: "Funcionários", det: (l.funcionarios || 0) + " funcionário(s) — +1 pt a cada " + faixaF, pts: ptsF });
    var faixaN = pr.faixaNotas || 50;
    var ptsN = Math.floor((l.notasMes || 0) / faixaN) * (pr.pontosPorFaixaNotas || 1);
    if (ptsN) out.push({ item: "Volume de notas", det: (l.notasMes || 0) + " nota(s)/mês — +1 pt a cada " + faixaN, pts: ptsN });
    var segs = l.segmento || [];
    for (i = 0; i < segs.length; i++) {
      var p = (pr.pontosSegmento || {})[segs[i]] || 0;
      if (p) out.push({ item: "Segmento", det: segNome(segs[i]), pts: p });
    }
    return out;
  }

  // Obrigações que se aplicariam ao lead (via matriz + CObrig.aplica); fallback texto padrão
  function inclusosDoLead(l) {
    var out = [], i;
    if (global.CObrig && App.matriz && (App.matriz.obrigacoes || []).length) {
      var ano = anoCorrente();
      var cli = { regimeTributario: [{ ano: ano, regime: l.regime }], segmento: l.segmento || [],
                  funcionarios: l.funcionarios || 0, uf: l.uf || "" };
      var defs = App.matriz.obrigacoes;
      for (i = 0; i < defs.length && out.length < 8; i++) {
        try { if (global.CObrig.aplica(defs[i], cli, ano, l.uf || null)) out.push(defs[i].nome); } catch (e) {}
      }
    }
    if (!out.length) {
      out = ["Apuração e emissão das guias mensais do regime", "Declarações acessórias federais do regime",
             "Escrituração contábil e balancetes", "Folha de pagamento e encargos (quando houver funcionários)",
             "Acompanhamento de prazos e comprovantes de entrega", "Atendimento a notificações fiscais de rotina"];
    }
    return out;
  }

  // ---------- View ----------
  global.CrmView = App.registrar({
    id: "crm",
    titulo: "CRM & Propostas",

    render: function () {
      var leads = Store.listar("leads"), i, l;
      leads = Util.ordenaPor(leads, "atualizadoEm", true);

      // KPIs
      var hp = Util.partes(Util.hojeISO()), compAtual = Util.competencia(hp.y, hp.m);
      var nAtivos = 0, nProp = 0, nGanhoMes = 0, valorProp = 0;
      for (i = 0; i < leads.length; i++) {
        l = leads[i];
        if (ativo(l)) nAtivos++;
        if (l.etapa === "proposta") { nProp++; valorProp += Number(l.valorProposta) || 0; }
        if (l.etapa === "ganho") { var q = l.ganhoEm || l.atualizadoEm || ""; if (q.indexOf(compAtual) === 0) nGanhoMes++; }
      }
      var kpis = '<div class="grid-kpi">' +
        '<div class="kpi"><div class="n">' + nAtivos + '</div><div class="l">Leads ativos</div></div>' +
        '<div class="kpi ' + (nProp ? "wr" : "") + '"><div class="n">' + nProp + '</div><div class="l">Propostas abertas</div></div>' +
        '<div class="kpi ok"><div class="n">' + nGanhoMes + '</div><div class="l">Ganhos no mês</div></div>' +
        '<div class="kpi"><div class="n" style="font-size:22px">' + Util.esc(Util.brMoeda(valorProp)) + '</div><div class="l">Valor em propostas</div></div>' +
        "</div>";

      // Funil kanban: 5 colunas, uma por etapa
      var cols = ETAPAS.map(function (et) {
        var doGrupo = leads.filter(function (x) { return (x.etapa || "novo") === et; });
        var cards = doGrupo.map(function (x) { return cardLead(x); }).join("") ||
          '<div style="padding:14px 6px;text-align:center;color:var(--mut);font-size:12px">vazio</div>';
        return '<div style="background:var(--bg);border:1px solid var(--line);border-radius:12px;padding:10px;min-width:190px">' +
          '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;padding:0 2px">' +
            '<span style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.5px;color:var(--mut)">' + Util.esc(ETAPA_LBL[et]) + '</span>' +
            UI.badge(String(doGrupo.length), ETAPA_COR[et]) + "</div>" + cards + "</div>";
      }).join("");
      var funil = '<div style="overflow-x:auto"><div style="display:grid;grid-template-columns:repeat(5,minmax(190px,1fr));gap:12px;align-items:start;min-width:980px">' + cols + "</div></div>";

      var podeCriar = Auth.pode("crm", "criar");
      return '<div class="page-hd"><div><h1>CRM &amp; Propostas</h1>' +
        '<div class="sub">Funil comercial — do lead à proposta de honorários e à conversão em cliente.</div></div>' +
        (podeCriar ? '<button class="btn primary" data-acao="novo">' + UI.icone("plus", 16) + " Novo lead</button>" : "") +
        "</div>" + kpis +
        '<div class="card"><div class="card-hd"><b>Funil de vendas</b><span class="chip">' + leads.length + " lead(s)</span></div>" +
        '<div class="card-bd" style="padding:14px">' + funil + "</div></div>";
    },

    // ---------------------------------------------------------------
    // AÇÕES
    // ---------------------------------------------------------------
    novo: function () { this._form(null); },
    editar: function (id) { this._form(id); },

    _form: function (id) {
      var self = this;
      if (id && !Auth.pode("crm", "editar")) { UI.toast("Sem permissão para editar leads.", "erro"); return; }
      if (!id && !Auth.pode("crm", "criar")) { UI.toast("Sem permissão para criar leads.", "erro"); return; }
      var l = id ? (Util.clone(Store.obter("leads", id)) || {}) : {};
      if (id && !l.id) { UI.toast("Lead não encontrado.", "erro"); return; }

      var ufOps = [{ v: "", t: "—" }];
      for (var u = 0; u < UFS.length; u++) ufOps.push({ v: UFS[u], t: UFS[u] });
      var regOps = [{ v: "", t: "— selecione —" }].concat(CONFIG.regimes.map(function (r) { return { v: r.id, t: r.nome }; }));
      var origOps = ORIGENS.map(function (o) { return { v: o.v, t: o.t }; });

      var segSel = l.segmento || [];
      var segsHtml = CONFIG.segmentos.map(function (s) {
        var ck = segSel.indexOf(s.id) >= 0 ? " checked" : "";
        return '<label style="display:flex;align-items:center;gap:6px;font-size:12px;font-weight:600;cursor:pointer">' +
          '<input type="checkbox" name="l-seg" value="' + Util.esc(s.id) + '"' + ck + "> " + Util.esc(s.nome) + "</label>";
      }).join("");

      var corpo =
        '<div class="row">' +
          UI.campo("Empresa", UI.inp("l-nome", l.nome, "Nome da empresa/prospect")) +
          UI.campo("Contato", UI.inp("l-contato", l.contatoNome, "Nome da pessoa de contato")) +
        "</div>" +
        '<div class="row-3">' +
          UI.campo("Telefone", UI.inp("l-tel", l.telefone, "(00) 00000-0000")) +
          UI.campo("E-mail", UI.inp("l-email", l.email, "contato@empresa.com")) +
          UI.campo("Origem", UI.sel("l-origem", origOps, l.origem || "indicacao")) +
        "</div>" +
        '<div class="row-3">' +
          UI.campo("Regime tributário", UI.sel("l-regime", regOps, l.regime || ""), "Base da régua de pontos do honorário.") +
          UI.campo("Nº de funcionários", UI.inp("l-func", l.funcionarios || 0, "0", "number")) +
          UI.campo("Notas fiscais/mês", UI.inp("l-notas", l.notasMes || 0, "0", "number")) +
        "</div>" +
        '<div class="row">' +
          UI.campo("UF", UI.sel("l-uf", ufOps, l.uf || "")) +
          UI.campo("Observações", UI.inp("l-obs", l.obs, "Anotações do contato, dores, urgência...")) +
        "</div>" +
        UI.campo("Segmentos", '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:6px">' + segsHtml + "</div>",
          "Cada segmento soma pontos e dispara obrigações extras na proposta.");

      UI.modal(id ? "Editar lead" : "Novo lead", corpo, [
        { txt: "Cancelar" },
        { txt: id ? "Salvar alterações" : "Cadastrar lead", classe: "primary", onClick: function (fechar) {
          var nome = UI.v("l-nome");
          if (!nome) { UI.toast("Informe o nome da empresa.", "erro"); return; }
          var obj = id ? (Util.clone(Store.obter("leads", id)) || {}) : {};
          if (id) obj.id = id;
          obj.nome = nome;
          obj.contatoNome = UI.v("l-contato");
          obj.telefone = UI.v("l-tel");
          obj.email = UI.v("l-email");
          obj.origem = UI.v("l-origem") || "outro";
          obj.regime = UI.v("l-regime");
          obj.funcionarios = parseInt(UI.v("l-func"), 10) || 0;
          obj.notasMes = parseInt(UI.v("l-notas"), 10) || 0;
          obj.uf = UI.v("l-uf");
          obj.obs = UI.v("l-obs");
          var checks = document.querySelectorAll('input[name="l-seg"]:checked'), segArr = [];
          for (var i = 0; i < checks.length; i++) segArr.push(checks[i].value);
          obj.segmento = segArr;
          obj.etapa = obj.etapa || "novo";
          // honorário sugerido pela régua de pontos — vira o valor da proposta no card
          obj.valorProposta = CONFIG.honorarioSugerido(leadLike(obj));
          obj.criadoEm = obj.criadoEm || Util.hojeISO();
          obj.atualizadoEm = Util.hojeISO();
          var salvo = Store.salvar("leads", obj); // STORAGE_CHEIO sobe -> modal mostra toast
          if (global.Audit) global.Audit.log(id ? "lead_editar" : "lead_criar", "leads", salvo.id);
          fechar();
          UI.toast("Lead salvo. Honorário sugerido: " + Util.brMoeda(salvo.valorProposta), "ok");
          App.render();
        } }
      ]);
    },

    // Avança novo -> contato -> proposta -> ganho (ganho pede confirmação e converte)
    avancarEtapa: function (id) {
      if (!Auth.pode("crm", "editar")) { UI.toast("Sem permissão para movimentar o funil.", "erro"); return; }
      var self = this, l = Store.obter("leads", id);
      if (!l) { UI.toast("Lead não encontrado.", "erro"); return; }
      var seq = ["novo", "contato", "proposta", "ganho"];
      var i = seq.indexOf(l.etapa || "novo");
      if (i < 0) { UI.toast("Lead ganho/perdido não avança. Edite a etapa se necessário.", "alerta"); return; }
      var prox = seq[i + 1];
      if (!prox) { UI.toast("Já está na última etapa.", "info"); return; }
      if (prox === "ganho") {
        UI.modal("Fechar negócio",
          "<p>Marcar <b>" + Util.esc(nomeLead(l)) + "</b> como <b>GANHO</b>?</p>" +
          '<p class="fld-d" style="margin-top:8px">Será criado um cliente com status "prospect" no módulo Clientes para completar o cadastro (CNPJ, IE, filiais...).</p>',
          [
            { txt: "Cancelar" },
            { txt: "Confirmar ganho", classe: "green", onClick: function (fechar) { fechar(); self.converter(id); } }
          ]);
        return;
      }
      l.etapa = prox;
      l.atualizadoEm = Util.hojeISO();
      Store.salvar("leads", l);
      if (global.Audit) global.Audit.log("lead_avancar_" + prox, "leads", l.id);
      UI.toast("Lead avançou para: " + (ETAPA_LBL[prox] || prox), "ok");
      App.render();
    },

    // Perder: motivo obrigatório — alimenta churn/BI
    perder: function (id) {
      if (!Auth.pode("crm", "editar")) { UI.toast("Sem permissão para movimentar o funil.", "erro"); return; }
      var l = Store.obter("leads", id);
      if (!l) { UI.toast("Lead não encontrado.", "erro"); return; }
      var ops = [{ v: "", t: "— selecione o motivo —" }].concat(MOTIVOS_PERDA);
      var corpo = '<p class="fld-d" style="margin-bottom:14px">' + Util.esc(nomeLead(l)) + "</p>" +
        UI.campo("Motivo da perda", UI.sel("l-perda", ops, ""), "Obrigatório — alimenta o BI comercial (por que perdemos).");
      UI.modal("Marcar como perdido", corpo, [
        { txt: "Cancelar" },
        { txt: "Confirmar perda", classe: "danger", onClick: function (fechar) {
          var motivo = UI.v("l-perda");
          if (!motivo) { UI.toast("Selecione o motivo da perda.", "erro"); return; }
          l.etapa = "perdido";
          l.motivoPerda = motivo;
          l.atualizadoEm = Util.hojeISO();
          Store.salvar("leads", l);
          if (global.Audit) global.Audit.log("lead_perder_" + motivo, "leads", l.id);
          fechar();
          UI.toast("Lead marcado como perdido.", "ok");
          App.render();
        } }
      ]);
    },

    // Converter ganho -> cliente prospect (idempotente por origemLead + id determinístico)
    converter: function (id) {
      if (!Auth.pode("crm", "editar")) { UI.toast("Sem permissão para converter leads.", "erro"); return; }
      var l = Store.obter("leads", id);
      if (!l) { UI.toast("Lead não encontrado.", "erro"); return; }
      var ano = anoCorrente();
      var jaExiste = Store.onde("clientes", "origemLead", id);
      if (!jaExiste.length) {
        var cliente = {
          id: "cli_" + id, // determinístico: reconverter nunca duplica
          razaoSocial: nomeLead(l), cnpj: "", uf: l.uf || "",
          regimeTributario: l.regime ? [{ ano: ano, regime: l.regime }] : [],
          segmento: l.segmento || [], funcionarios: l.funcionarios || 0,
          notasMes: l.notasMes || 0, // entra na régua: sem isto o honorário do cliente sai menor que a proposta aceita
          status: "prospect", origemLead: id, criadoEm: Util.hojeISO()
        };
        Store.salvar("clientes", cliente);
        if (global.Audit) global.Audit.log("lead_converter", "clientes", cliente.id);
        // evento cliente criado -> onboarding automático (acoplamento fraco)
        if (global.Onboarding && global.Onboarding.aoCriarCliente) { try { global.Onboarding.aoCriarCliente(cliente); } catch (e) {} }
      }
      l.etapa = "ganho";
      l.ganhoEm = l.ganhoEm || Util.hojeISO();
      l.atualizadoEm = Util.hojeISO();
      Store.salvar("leads", l);
      if (global.Audit) global.Audit.log("lead_ganho", "leads", l.id);
      UI.toast(jaExiste.length ? "Lead ganho — cliente já existia (nada duplicado)." :
        "Negócio fechado! Complete o cadastro (CNPJ, IE...) no módulo Clientes.", "ok");
      App.render();
    },

    // ---------------------------------------------------------------
    // PROPOSTA DE HONORÁRIOS IMPRESSA (entregável comercial nº 1)
    // ---------------------------------------------------------------
    proposta: function (id) {
      if (!Auth.pode("crm", "exportar")) { UI.toast("Sem permissão para gerar propostas.", "erro"); return; }
      var l = Store.obter("leads", id);
      if (!l) { UI.toast("Lead não encontrado.", "erro"); return; }
      if (!l.regime) { UI.toast("Informe o regime tributário do lead antes de gerar a proposta.", "alerta"); return; }

      var pr = CONFIG.precificacao;
      var pts = CONFIG.calcPontos(leadLike(l));
      var honor = CONFIG.honorarioSugerido(leadLike(l));
      var comp = composicaoPontos(l);
      var hoje = Util.hojeISO();
      var validade = Util.somaDias(hoje, 15);

      // 1) Dados do prospect
      var dados = "<h2>1. Dados do prospect</h2><table>" +
        "<tr><th style='width:30%'>Empresa</th><td>" + Util.esc(nomeLead(l)) + "</td></tr>" +
        "<tr><th>Contato</th><td>" + Util.esc(l.contatoNome || "—") +
          (l.telefone ? " · " + Util.esc(l.telefone) : "") + (l.email ? " · " + Util.esc(l.email) : "") + "</td></tr>" +
        "<tr><th>Regime tributário</th><td>" + Util.esc(regimeNome(l.regime)) + "</td></tr>" +
        "<tr><th>UF</th><td>" + Util.esc(l.uf || "—") + "</td></tr>" +
        "<tr><th>Funcionários / Notas por mês</th><td>" + (l.funcionarios || 0) + " / " + (l.notasMes || 0) + "</td></tr>" +
        "<tr><th>Segmentos</th><td>" + Util.esc((l.segmento || []).map(segNome).join(", ") || "—") + "</td></tr>" +
        "</table>";

      // 2) Composição transparente do honorário (régua de pontos)
      var linhas = comp.map(function (c) {
        return "<tr><td>" + Util.esc(c.item) + "</td><td>" + Util.esc(c.det) + "</td><td class='dir'>" + c.pts + "</td></tr>";
      }).join("");
      var compTbl = "<h2>2. Composição do honorário mensal</h2>" +
        "<table><tr><th>Fator</th><th>Detalhe</th><th class='dir'>Pontos</th></tr>" + linhas +
        "<tr class='tot'><td colspan='2'>Total de pontos de complexidade</td><td class='dir'>" + pts + "</td></tr>" +
        "<tr class='tot'><td colspan='2'>Honorário mensal sugerido (" + pts + " pts × " + Util.esc(Util.brMoeda(pr.valorPonto || 0)) + "/pt)</td>" +
        "<td class='dir ok' style='font-size:15px'>" + Util.esc(Util.brMoeda(honor)) + "</td></tr></table>";

      // 3) Escopo incluso (obrigações que a matriz aplica a este perfil)
      var inclusos = inclusosDoLead(l);
      var liInc = inclusos.map(function (n) { return "<li style='margin:3px 0'>" + Util.esc(n) + "</li>"; }).join("");
      var escopo = "<h2>3. O que está incluso</h2>" +
        "<p>Gestão completa da agenda de obrigações do regime <b>" + Util.esc(regimeNome(l.regime)) + "</b>, com controle de prazos, transmissão e guarda de comprovantes. Exemplos aplicáveis ao seu perfil:</p>" +
        "<ul style='margin:8px 0 8px 20px'>" + liInc + "</ul>" +
        "<p style='color:#64748b;font-size:11px'>A relação completa é gerada automaticamente conforme regime, UF, segmentos e quadro de funcionários. Serviços extraordinários (parcelamentos, alterações societárias, atendimentos a fiscalização) são orçados à parte.</p>";

      // 4) Condições + assinaturas
      var cond = "<h2>4. Condições comerciais</h2><table>" +
        "<tr><th style='width:30%'>Honorário mensal</th><td class='ok'>" + Util.esc(Util.brMoeda(honor)) + "</td></tr>" +
        "<tr><th>Emissão</th><td>" + Util.esc(Util.brData(hoje)) + "</td></tr>" +
        "<tr><th>Validade da proposta</th><td class='al'>" + Util.esc(Util.brData(validade)) + " (15 dias)</td></tr>" +
        "<tr><th>Reajuste</th><td>Anual, ou quando houver mudança relevante de regime/porte (recontagem de pontos)</td></tr>" +
        "</table>";
      var ass = "<div style='display:flex;gap:40px;margin-top:56px'>" +
        "<div style='flex:1;text-align:center;border-top:1px solid #0f172a;padding-top:6px'>" + Util.esc(CONFIG.marca.nome) + "<br><span style='color:#64748b;font-size:11px'>Responsável comercial</span></div>" +
        "<div style='flex:1;text-align:center;border-top:1px solid #0f172a;padding-top:6px'>" + Util.esc(nomeLead(l)) + "<br><span style='color:#64748b;font-size:11px'>" + Util.esc(l.contatoNome || "Representante legal") + "</span></div>" +
        "</div>";

      App._abrirPrint("Proposta de Honorários", dados + compTbl + escopo + cond + ass);
      if (global.Audit) global.Audit.log("lead_proposta", "leads", l.id);
      // proposta gerada de um lead ainda no início do funil já o coloca em "proposta"
      if (l.etapa === "novo" || l.etapa === "contato") {
        if (Auth.pode("crm", "editar")) {
          l.etapa = "proposta"; l.atualizadoEm = Util.hojeISO();
          Store.salvar("leads", l);
          App.render();
        }
      }
    }
  });

  // ---------- Card do kanban (fora da view: helper de render) ----------
  function cardLead(l) {
    var oi = origemInfo(l.origem);
    var val = l.valorProposta ? '<div style="font-weight:800;color:var(--navy);font-size:13px;margin-top:4px">' + Util.esc(Util.brMoeda(l.valorProposta)) + "</div>" : "";
    var contato = l.contatoNome ? '<div style="font-size:11px;color:var(--mut);margin-top:2px">' + Util.esc(l.contatoNome) + "</div>" : "";
    var rodape = "";
    if (ativo(l)) {
      rodape = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:8px">' +
        '<button class="btn sm" data-acao="avancarEtapa:' + Util.esc(l.id) + '">Avançar →</button>' +
        (l.regime ? '<button class="btn sm green" data-acao="proposta:' + Util.esc(l.id) + '">Proposta</button>' : "") +
        '<button class="btn sm danger" data-acao="perder:' + Util.esc(l.id) + '">✕</button></div>';
    } else if (l.etapa === "ganho") {
      rodape = '<div style="margin-top:8px">' + UI.badge("virou cliente", "verde") +
        ' <button class="btn sm" data-acao="proposta:' + Util.esc(l.id) + '">Reimprimir</button></div>';
    } else {
      rodape = '<div style="margin-top:8px">' + UI.badge(motivoLbl(l.motivoPerda), "vermelho") + "</div>";
    }
    return '<div data-acao="editar:' + Util.esc(l.id) + '" style="background:var(--card);border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin-bottom:8px;cursor:pointer;box-shadow:var(--shadow)">' +
      '<div style="display:flex;justify-content:space-between;gap:6px;align-items:flex-start">' +
        '<b style="font-size:13px;line-height:1.3">' + Util.esc(nomeLead(l)) + "</b>" + UI.badge(oi.t, oi.cor) + "</div>" +
      contato + val + rodape + "</div>";
  }
})(window);
