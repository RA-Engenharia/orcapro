/* =====================================================================
 * clientes.js — CADASTRO de clientes (núcleo, seção 3.2).
 * Coração do sistema: lista + detalhe + form. Ao salvar cliente ATIVO,
 * (re)gera a agenda de obrigações do ano preservando o passado.
 * ES5 estrito (var/function/concatenação). Toda saída de dado -> Util.esc.
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
      Auth = global.Auth, UI = global.UI, App = global.App, CObrig = global.CObrig;

  // Siglas das 27 unidades federativas
  var UFS = ["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS",
             "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC",
             "SP", "SE", "TO"];

  var STATUS_LBL = { prospect: "Prospect", ativo: "Ativo", suspenso: "Suspenso", em_saida: "Em saída", encerrado: "Encerrado" };
  var STATUS_COR = { prospect: "azul", ativo: "verde", suspenso: "amber", em_saida: "amber", encerrado: "cinza" };

  function anoCorrente() { return new Date().getFullYear(); }
  function mesCorrente() { return new Date().getMonth() + 1; }

  var View = {
    id: "clientes",
    titulo: "Clientes",
    _detalheId: null,   // se setado, render() mostra o detalhe
    _aba: "dados",      // aba ativa no detalhe
    _lista: [],         // lista atual (mapeia data-row -> cliente no onMount)

    // ---------------------------------------------------------------
    // RENDER (decide entre lista e detalhe)
    // ---------------------------------------------------------------
    render: function () {
      if (this._detalheId) {
        var c = Store.obter("clientes", this._detalheId);
        if (!c) { this._detalheId = null; } // sumiu (excluído em outra aba)
        else return this._renderDetalhe(c);
      }
      return this._renderLista();
    },

    onMount: function (el) {
      if (this._detalheId) return; // no detalhe as ações são via data-acao
      var self = this, lista = this._lista || [];
      var rows = el.querySelectorAll("tr.clk");
      var i;
      for (i = 0; i < rows.length; i++) {
        (function (tr) {
          tr.onclick = function () {
            var idx = parseInt(tr.getAttribute("data-row"), 10);
            var c = lista[idx];
            if (c) self.abrir(c.id);
          };
        })(rows[i]);
      }
      var busca = el.querySelector("#cli-busca");
      if (busca) {
        busca.oninput = function () {
          var q = (busca.value || "").toLowerCase();
          for (var j = 0; j < rows.length; j++) {
            var txt = (rows[j].textContent || "").toLowerCase();
            rows[j].style.display = txt.indexOf(q) >= 0 ? "" : "none";
          }
        };
      }
    },

    // ---------------------------------------------------------------
    // LISTA
    // ---------------------------------------------------------------
    _renderLista: function () {
      var self = this, ano = anoCorrente();
      var lista = Auth.clientesVisiveis(Store.listar("clientes"));
      lista = Util.ordenaPor(lista, "razaoSocial");
      this._lista = lista;

      var cols = [
        { k: "razaoSocial", label: "Razão Social", fmt: function (v, row) {
            var sub = row.nomeFantasia ? '<div style="font-size:11px;color:var(--mut)">' + Util.esc(row.nomeFantasia) + '</div>' : "";
            return '<b>' + Util.esc(v || "—") + '</b>' + sub;
          } },
        { k: "cnpj", label: "CNPJ", fmt: function (v, row) {
            var t = v ? Util.esc(Util.formataCNPJ(v)) : "—";
            if (row.cnpjPendente) t += " " + UI.badge("pendência", "amber");
            return t;
          } },
        { k: "regimeTributario", label: "Regime", fmt: function (v, row) {
            return Util.esc(self._regimeNome(CObrig.regimeNoAno(row, ano)));
          } },
        { k: "uf", label: "UF", cls: "ctr", fmt: function (v) { return Util.esc(v || "—"); } },
        { k: "segmento", label: "Segmentos", fmt: function (v) { return self._segChips(v); } },
        { k: "status", label: "Status", cls: "ctr", fmt: function (v) { return UI.badge(self._statusLbl(v), self._statusCor(v)); } },
        { k: "id", label: "Score", cls: "ctr", fmt: function (v, row) { var s = self._score(row); return UI.badge(String(s), self._scoreCor(s)); } }
      ];

      var tabela = UI.tabela(cols, lista, {
        vazio: "Nenhum cliente cadastrado ainda. Clique em “Novo cliente” para começar.",
        onRow: true
      });

      var podeCriar = self._podeEditar();

      return '' +
        '<div class="page-hd"><div><h1>Clientes</h1>' +
          '<div class="sub">' + lista.length + ' cliente(s) na carteira</div></div>' +
          (podeCriar ? '<button class="btn primary" data-acao="novo">' + UI.icone("plus", 16) + ' Novo cliente</button>' : "") +
        '</div>' +
        '<div class="toolbar">' + UI.icone("search", 16) +
          '<input id="cli-busca" class="in" placeholder="Buscar por razão social, fantasia, cidade, UF, regime...">' +
        '</div>' +
        '<div class="card"><div class="card-bd">' + tabela + '</div></div>';
    },

    // ---------------------------------------------------------------
    // DETALHE
    // ---------------------------------------------------------------
    _renderDetalhe: function (c) {
      var self = this, ano = anoCorrente();
      var reg = CObrig.regimeNoAno(c, ano);
      var pts = this._pontos(c);
      var pr = CONFIG.precificacao || {};
      var honor = pts * (pr.valorPonto || 0);
      var score = this._score(c);
      var obrigs = Util.ordenaPor(Store.onde("obrigacoes", "clienteId", c.id), "prazoAjustado");
      var aba = this._aba || "dados";
      var soLeitura = !self._podeEditar();
      var podeExcluir = Auth.pode("clientes", "excluir");

      // cabeçalho
      var badges = UI.badge(self._regimeNome(reg), "azul") + " " +
        UI.badge(self._statusLbl(c.status), self._statusCor(c.status)) +
        (c.cnpjPendente ? " " + UI.badge("CNPJ pendente", "amber") : "");

      var acoes = "";
      if (!soLeitura) acoes += '<button class="btn sm" data-acao="editar:' + Util.esc(c.id) + '">Editar</button> ';
      if (c.status === "ativo") acoes += '<button class="btn sm" data-acao="regenerar:' + Util.esc(c.id) + '">Regenerar agenda</button> ';
      if (podeExcluir) acoes += '<button class="btn sm danger" data-acao="excluir:' + Util.esc(c.id) + '">Excluir</button>';

      var head = '<div class="page-hd"><div>' +
        '<button class="btn sm" data-acao="voltar">← Voltar para lista</button>' +
        '<h1 style="margin-top:12px">' + Util.esc(c.razaoSocial || "—") + '</h1>' +
        '<div class="sub">' + (c.cnpj ? Util.esc(Util.formataCNPJ(c.cnpj)) : "CNPJ não informado") +
          (c.municipio ? " · " + Util.esc(c.municipio) : "") + (c.uf ? "/" + Util.esc(c.uf) : "") + '</div>' +
        '<div style="margin-top:10px">' + badges + '</div>' +
        '</div><div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-start">' + acoes + '</div></div>';

      // KPIs
      var kpis = '<div class="grid-kpi">' +
        self._kpi(String(pts), "Pontos de complexidade") +
        self._kpi(Util.brMoeda(honor), "Honorário sugerido/mês") +
        self._kpi(String(score), "Score de saúde", self._scoreKpiClass(score)) +
        self._kpi(String(obrigs.length), "Obrigações no sistema") +
        '</div>';

      // abas
      function tab(idA, lbl) {
        return '<button class="btn sm' + (aba === idA ? " primary" : "") + '" data-acao="aba:' + idA + '">' + Util.esc(lbl) + '</button>';
      }
      var nav = '<div class="toolbar">' + tab("dados", "Dados") +
        tab("obrigacoes", "Obrigações do cliente") + tab("certificados", "Certificados / Procurações") + '</div>';

      var corpo;
      if (aba === "obrigacoes") corpo = self._abaObrigacoes(c, obrigs);
      else if (aba === "certificados") corpo = self._abaCertificados(c, soLeitura);
      else corpo = self._abaDados(c, ano);

      return head + kpis + nav + '<div class="card"><div class="card-bd">' + corpo + '</div></div>';
    },

    _abaDados: function (c, ano) {
      var self = this;
      var ie = self._ieAtual(c);
      function L(label, val) {
        return '<div class="row" style="margin:0;border-bottom:1px solid var(--line);padding:11px 6px">' +
          '<div class="fld-l" style="margin:0">' + Util.esc(label) + '</div><div>' + val + '</div></div>';
      }
      return '<div style="padding:6px 8px">' +
        L("Razão social", Util.esc(c.razaoSocial || "—")) +
        L("Nome fantasia", Util.esc(c.nomeFantasia || "—")) +
        L("CNPJ", (c.cnpj ? Util.esc(Util.formataCNPJ(c.cnpj)) : "—") + (c.cnpjPendente ? " " + UI.badge("pendência", "amber") : "")) +
        L("Regime (" + ano + ")", Util.esc(self._regimeNome(CObrig.regimeNoAno(c, ano)))) +
        L("UF / Município", Util.esc(c.uf || "—") + " / " + Util.esc(c.municipio || "—")) +
        L("Segmentos", self._segChips(c.segmento)) +
        L("Nº de funcionários", String(c.funcionarios || 0)) +
        L("Inscrição Estadual", Util.esc(ie || "—")) +
        L("Status", UI.badge(self._statusLbl(c.status), self._statusCor(c.status))) +
        '</div>';
    },

    _abaObrigacoes: function (c, obrigs) {
      var self = this;
      var cols = [
        { k: "nome", label: "Obrigação", fmt: function (v) { return Util.esc(v || ""); } },
        { k: "competencia", label: "Competência", cls: "ctr" },
        { k: "prazoAjustado", label: "Vence", cls: "ctr", fmt: function (v) { return Util.brData(v); } },
        { k: "status", label: "Status", cls: "ctr", fmt: function (v) { return UI.badge(CObrig.ROTULO[v] || v, self._obCor(v)); } }
      ];
      var t = UI.tabela(cols, obrigs, { vazio: "Nenhuma obrigação gerada. O cliente precisa estar ativo e ter a agenda gerada." });
      var barra = '<div style="padding:8px;display:flex;gap:8px;flex-wrap:wrap">' +
        '<button class="btn sm" data-nav="obrigacoes">Abrir agenda completa →</button>' +
        (c.status === "ativo" ? '<button class="btn sm primary" data-acao="regenerar:' + Util.esc(c.id) + '">Gerar/atualizar agenda</button>' : "") +
        '</div>';
      return barra + t;
    },

    _abaCertificados: function (c, soLeitura) {
      var self = this;
      var certs = c.certificados || [];
      var addBtn = soLeitura ? "" : '<button class="btn sm primary" data-acao="addCert:' + Util.esc(c.id) + '">' + UI.icone("plus", 14) + ' Adicionar</button>';
      var lista;
      if (!certs.length) {
        lista = '<div class="empty">Nenhum certificado digital ou procuração cadastrado.</div>';
      } else {
        var cols = [
          { k: "tipo", label: "Tipo", fmt: function (v) { return Util.esc(v || "—"); } },
          { k: "titular", label: "Titular / Obs.", fmt: function (v) { return Util.esc(v || "—"); } },
          { k: "validade", label: "Validade", cls: "ctr", fmt: function (v) { return Util.brData(v); } },
          { k: "validade", label: "Situação", cls: "ctr", fmt: function (v) { return self._certBadge(v); } },
          { k: "id", label: "", cls: "ctr", fmt: function (v) { return soLeitura ? "" : '<button class="btn sm danger" data-acao="delCert:' + Util.esc(v) + '">✕</button>'; } }
        ];
        lista = UI.tabela(cols, certs, {});
      }
      return '<div style="padding:8px 8px 0;display:flex;justify-content:flex-end">' + addBtn + '</div>' + lista;
    },

    // ---------------------------------------------------------------
    // AÇÕES (data-acao / cliques)
    // ---------------------------------------------------------------
    abrir: function (id) { this._detalheId = id; this._aba = "dados"; App.render(); },
    voltar: function () { this._detalheId = null; App.render(); },
    aba: function (nome) { this._aba = nome || "dados"; App.render(); },

    novo: function () { this._form(null); },
    editar: function (id) { this._form(id || this._detalheId); },

    // Form de cadastro/edição em modal
    _form: function (id) {
      var self = this;
      if (!self._podeEditar()) { UI.toast("Seu perfil não pode editar o cadastro.", "erro"); return; }
      if (id && !Auth.pode("clientes", "editar")) { UI.toast("Sem permissão para editar.", "erro"); return; }
      if (!id && !Auth.pode("clientes", "criar")) { UI.toast("Sem permissão para criar.", "erro"); return; }

      var ano = anoCorrente();
      var c = id ? (Util.clone(Store.obter("clientes", id)) || {}) : {};
      var regAtual = c.id ? CObrig.regimeNoAno(c, ano) : "";
      var ieAtual = self._ieAtual(c);
      var segSel = c.segmento || [];

      var ufOps = [{ v: "", t: "—" }];
      for (var u = 0; u < UFS.length; u++) ufOps.push({ v: UFS[u], t: UFS[u] });

      var regOps = CONFIG.regimes.map(function (r) { return { v: r.id, t: r.nome }; });
      var stOps = CONFIG.statusCliente.map(function (s) { return { v: s, t: STATUS_LBL[s] || s }; });

      var segsHtml = CONFIG.segmentos.map(function (s) {
        var ck = segSel.indexOf(s.id) >= 0 ? " checked" : "";
        return '<label style="display:flex;align-items:center;gap:6px;font-size:12px;font-weight:600;cursor:pointer">' +
          '<input type="checkbox" name="f-seg" value="' + Util.esc(s.id) + '"' + ck + '> ' + Util.esc(s.nome) + '</label>';
      }).join("");

      var corpo =
        '<div class="row">' +
          UI.campo("Razão social", UI.inp("f-razao", c.razaoSocial, "Empresa Exemplo LTDA")) +
          UI.campo("Nome fantasia", UI.inp("f-fantasia", c.nomeFantasia, "Nome comercial")) +
        '</div>' +
        '<div class="row-3">' +
          UI.campo("CNPJ", UI.inp("f-cnpj", c.cnpj, "00.000.000/0000-00")) +
          UI.campo("UF", UI.sel("f-uf", ufOps, c.uf || "")) +
          UI.campo("Município", UI.inp("f-munic", c.municipio, "Cidade")) +
        '</div>' +
        '<div class="row-3">' +
          UI.campo("Regime tributário (" + ano + ")", UI.sel("f-regime", regOps, regAtual)) +
          UI.campo("Nº de funcionários", UI.inp("f-func", c.funcionarios || 0, "0", "number")) +
          UI.campo("Status", UI.sel("f-status", stOps, c.status || "prospect")) +
        '</div>' +
        UI.campo("Inscrição Estadual", UI.inp("f-ie", ieAtual, "Opcional"), "Se preenchida, entra como inscrição estadual do cliente.") +
        '<div class="row">' +
          UI.campo("Presta serviços (gera ISS)", '<label style="display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;cursor:pointer;padding:9px 0"><input type="checkbox" id="f-servico"' + (c.prestaServico ? " checked" : "") + '> Sim, emite nota de serviço</label>', "Além dos segmentos, isto liga o ISS na agenda.") +
          UI.campo("Filiais — UFs extras", UI.inp("f-filiais", (c.filiais || []).map(function (fl) { return fl.uf; }).join(", "), "ex.: SP, RJ"), "Obrigações estaduais são duplicadas por UF.") +
        '</div>' +
        UI.campo("Segmentos", '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:6px">' + segsHtml + '</div>', "Marque todos que se aplicam — cada um dispara obrigações extras na agenda.");

      UI.modal(id ? "Editar cliente" : "Novo cliente", corpo, [
        { txt: "Cancelar" },
        { txt: id ? "Salvar alterações" : "Cadastrar cliente", classe: "primary", onClick: function (fechar) {
            self._salvar(id, ano, fechar);
          } }
      ]);
    },

    // Coleta o form, valida, persiste e sincroniza a agenda
    _salvar: function (id, ano, fechar) {
      var self = this;
      var razao = UI.v("f-razao");
      if (!razao) { UI.toast("Informe a razão social.", "erro"); return; }

      var cnpj = UI.v("f-cnpj");
      var obj = id ? (Util.clone(Store.obter("clientes", id)) || {}) : {};
      if (id) obj.id = id;

      obj.razaoSocial = razao;
      obj.nomeFantasia = UI.v("f-fantasia");
      obj.cnpj = cnpj;
      obj.uf = UI.v("f-uf");
      obj.municipio = UI.v("f-munic");
      obj.funcionarios = parseInt(UI.v("f-func"), 10) || 0;
      obj.status = UI.v("f-status") || "prospect";

      // regime do ano corrente — preserva histórico dos demais anos
      // (normaliza formato legado string -> array, senão .filter quebra em dado importado)
      var reg = UI.v("f-regime");
      var histBase = obj.regimeTributario || [];
      if (typeof histBase === "string") histBase = [{ ano: ano - 1, regime: histBase }];
      var hist = histBase.filter(function (r) { return r.ano !== ano; });
      if (reg) hist.push({ ano: ano, regime: reg });
      obj.regimeTributario = hist;

      // presta serviço (ISS) + filiais (UFs extras, separadas por vírgula)
      var chkServ = document.getElementById("f-servico");
      obj.prestaServico = !!(chkServ && chkServ.checked);
      var ufsFil = UI.v("f-filiais").toUpperCase().split(/[,;\s]+/).filter(function (s) { return /^[A-Z]{2}$/.test(s) && s !== (UI.v("f-uf") || "").toUpperCase(); });
      obj.filiais = ufsFil.map(function (uf) { return { uf: uf }; });

      // segmentos (checkboxes)
      var checks = document.querySelectorAll('input[name="f-seg"]:checked');
      var segArr = [];
      for (var i = 0; i < checks.length; i++) segArr.push(checks[i].value);
      obj.segmento = segArr;

      // inscrição estadual — preserva outras inscrições, substitui a estadual
      var ie = UI.v("f-ie");
      var ins = (obj.inscricoes || []).filter(function (x) { return x.tipo !== "estadual"; });
      if (ie) ins.push({ tipo: "estadual", numero: ie });
      obj.inscricoes = ins;

      // validação de CNPJ: não bloqueia, marca pendência
      obj.cnpjPendente = !!(cnpj && !Util.validaCNPJ(cnpj));

      obj.criadoEm = obj.criadoEm || Util.hojeISO();
      obj.atualizadoEm = Util.hojeISO();

      var salvo;
      try {
        salvo = Store.salvar("clientes", obj);
      } catch (e) {
        UI.toast("Falha ao salvar: " + e.message, "erro");
        return;
      }
      if (global.Audit) global.Audit.log(id ? "editou" : "criou", "cliente", salvo.id);
      // evento cliente.criado -> onboarding automático (seção 3.3); acoplamento fraco (módulo pode não existir)
      if (!id && global.Onboarding && global.Onboarding.aoCriarCliente) { try { global.Onboarding.aoCriarCliente(salvo); } catch (eOb) {} }

      if (fechar) fechar();

      if (cnpj && obj.cnpjPendente) UI.toast("CNPJ inválido — cliente salvo com pendência para revisão.", "alerta");

      if (salvo.status === "ativo") {
        var n = self._sincronizarAgenda(salvo);
        UI.toast(n < 0 ? "Cliente salvo (agenda não alterada — matriz indisponível)." : ("Cliente salvo. Agenda do ano com " + n + " obrigação(ões)."), n < 0 ? "alerta" : "ok");
        // prospect que virou ativo: marca a etapa 'agenda' do onboarding automaticamente
        if (n >= 0 && global.Onboarding && global.Onboarding.aoAtivarCliente) { try { global.Onboarding.aoAtivarCliente(salvo); } catch (eAt) {} }
      } else {
        UI.toast("Cliente salvo.", "ok");
      }

      // se veio da lista, abre o detalhe do recém-salvo para dar contexto
      self._detalheId = salvo.id;
      self._aba = self._aba || "dados";
      App.render();
    },

    // (Re)gera a agenda do ano corrente preservando o passado e limpando
    // obrigações futuras que deixaram de se aplicar (mudança de regime/segmento).
    _sincronizarAgenda: function (cliente) {
      // matriz não carregada (fetch falhou/offline sem servidor) -> NÃO mexe na agenda
      // (senão "regenerar" apagaria as obrigações futuras existentes em silêncio)
      if (!App.matriz || !(App.matriz.obrigacoes || []).length) {
        UI.toast("Matriz de obrigações não carregada — a agenda NÃO foi alterada. Abra o app pelo Iniciar-ContabPRO.bat.", "erro");
        return -1;
      }
      var ano = anoCorrente();
      var novas = CObrig.gerarAgenda(cliente, ano, App.matriz);
      var doCliente = Store.onde("obrigacoes", "clienteId", cliente.id);
      var corte = Util.competencia(ano, mesCorrente());
      var reger = CObrig.regenerarFuturo(doCliente, novas, corte);

      // remove futuras órfãs (deixaram de se aplicar) — MAS nunca apaga registro com
      // comprovante ou já concluída/retificada: histórico de entrega é prova, fica.
      var manter = {};
      reger.forEach(function (o) { manter[o.id] = 1; });
      doCliente.forEach(function (o) {
        if (manter[o.id]) return;
        if (o.codigo === "PARCELA") return; // parcelas de parcelamento são geridas pelo módulo Débitos, NÃO pela matriz — nunca apagar aqui
        if (o.comprovante || o.status === "concluida" || o.status === "retificada") return;
        Store.excluir("obrigacoes", o.id);
      });

      Store.salvarLote("obrigacoes", reger);
      return reger.length;
    },

    regenerar: function (id) {
      // guard na função: mexe em cadastro E em obrigações — comercial/recepção não regeneram
      if (!this._podeEditar() || !Auth.pode("obrigacoes", "editar")) { UI.toast("Sem permissão para regenerar a agenda.", "erro"); return; }
      var c = Store.obter("clientes", id || this._detalheId);
      if (!c) return;
      if (c.status !== "ativo") { UI.toast("Só clientes ativos geram agenda de obrigações.", "alerta"); return; }
      var n = this._sincronizarAgenda(c);
      if (n < 0) return; // matriz indisponível: aviso já dado, nada alterado
      if (global.Audit) global.Audit.log("regenerou_agenda", "cliente", c.id);
      UI.toast("Agenda regenerada: " + n + " obrigação(ões).", "ok");
      App.render();
    },

    excluir: function (id) {
      var self = this;
      id = id || this._detalheId;
      if (!Auth.pode("clientes", "excluir")) { UI.toast("Sem permissão para excluir.", "erro"); return; }
      var c = Store.obter("clientes", id);
      if (!c) return;
      UI.modal("Excluir cliente",
        '<p>Excluir <b>' + Util.esc(c.razaoSocial || "este cliente") + '</b> e TUDO dele (obrigações, documentos, funcionários, processos, certidões, honorários, timeline, onboarding)? Esta ação não pode ser desfeita.</p>',
        [
          { txt: "Cancelar" },
          { txt: "Excluir definitivamente", classe: "danger", onClick: function (fechar) {
              // varredura genérica de TODAS as coleções ligadas por clienteId (senão viram
              // órfãos invisíveis ocupando storage e distorcendo KPIs da auditoria)
              var porCliente = ["obrigacoes", "documentos", "funcionarios", "processosSoc", "alvaras", "certidoes", "contratosHon", "cobrancas", "comunicacoes", "onboardings", "debitos", "parcelamentos", "creditos", "defesas", "tarefas"];
              porCliente.forEach(function (col) { Store.onde(col, "clienteId", id).forEach(function (r) { Store.excluir(col, r.id); }); });
              // leads: desvincula (não apaga o histórico comercial), só tira o vínculo de origem
              Store.onde("leads", "origemLead", id).forEach(function (l) { /* mantém o lead como ganho histórico */ });
              // wiki: NÃO apaga o artigo (é memória do escritório — lição aprendida vale mesmo
              // sem o cliente); só desvincula p/ não ficar apontando pra cliente inexistente
              Store.onde("wiki", "clienteId", id).forEach(function (a) { a.clienteId = null; Store.salvar("wiki", a); });
              Store.excluir("clientes", id);
              if (global.Audit) global.Audit.log("excluiu", "cliente", id);
              if (fechar) fechar();
              self._detalheId = null;
              UI.toast("Cliente e todos os registros vinculados excluídos.", "ok");
              App.render();
            } }
        ]);
    },

    // Certificados / procurações
    addCert: function (id) {
      var self = this;
      id = id || this._detalheId;
      var c = Store.obter("clientes", id);
      if (!c) return;
      if (!self._podeEditar()) { UI.toast("Sem permissão.", "erro"); return; }
      var tipoOps = ["e-CNPJ A1", "e-CNPJ A3", "e-CPF A1", "e-CPF A3", "Procuração RFB (e-CAC)", "Procuração eSocial", "Outro"];
      var corpo =
        UI.campo("Tipo", UI.sel("cert-tipo", tipoOps, tipoOps[0])) +
        UI.campo("Titular / observação", UI.inp("cert-titular", "", "Nome do titular ou nota")) +
        UI.campo("Validade", UI.inp("cert-validade", "", "", "date"), "Alerta automático quando estiver perto de vencer.");
      UI.modal("Adicionar certificado / procuração", corpo, [
        { txt: "Cancelar" },
        { txt: "Adicionar", classe: "primary", onClick: function (fechar) {
            var validade = UI.v("cert-validade");
            var cert = { id: Util.uid("cert"), tipo: UI.v("cert-tipo"), titular: UI.v("cert-titular"), validade: validade };
            var obj = Util.clone(c);
            obj.certificados = obj.certificados || [];
            obj.certificados.push(cert);
            Store.salvar("clientes", obj);
            if (global.Audit) global.Audit.log("add_certificado", "cliente", obj.id);
            if (fechar) fechar();
            var d = validade ? Util.diasAte(validade) : null;
            if (d != null && d < 0) UI.toast("Certificado adicionado — já está VENCIDO.", "alerta");
            else if (d != null && d <= 30) UI.toast("Certificado adicionado — vence em " + d + " dia(s).", "alerta");
            else UI.toast("Certificado adicionado.", "ok");
            self._aba = "certificados";
            App.render();
          } }
      ]);
    },

    delCert: function (certId) {
      var self = this;
      var id = this._detalheId;
      var c = Store.obter("clientes", id);
      if (!c || !self._podeEditar()) return;
      var obj = Util.clone(c);
      obj.certificados = (obj.certificados || []).filter(function (x) { return x.id !== certId; });
      Store.salvar("clientes", obj);
      if (global.Audit) global.Audit.log("del_certificado", "cliente", id);
      UI.toast("Certificado removido.", "ok");
      App.render();
    },

    // ---------------------------------------------------------------
    // CÁLCULOS / HELPERS
    // ---------------------------------------------------------------
    // Score de saúde 0-100 (seção 3.2): parte de 100 e desconta riscos.
    _score: function (c) {
      var s = 100;
      var obrigs = Store.onde("obrigacoes", "clienteId", c.id);
      var hoje = Util.hojeISO();
      var i, temAtraso = false;
      for (i = 0; i < obrigs.length; i++) {
        var o = obrigs[i];
        if (o.status !== "concluida" && o.status !== "retificada" && o.prazoAjustado && o.prazoAjustado < hoje) { temAtraso = true; break; }
      }
      if (temAtraso) s -= 20;
      var certs = c.certificados || [];
      for (i = 0; i < certs.length; i++) { var d = Util.diasAte(certs[i].validade); if (d != null && d < 0) s -= 10; }
      if (c.cnpjPendente) s -= 10;
      if (c.status === "suspenso" || c.status === "em_saida") s -= 10;
      if (s < 0) s = 0;
      if (s > 100) s = 100;
      return s;
    },
    _scoreCor: function (s) { return s >= 80 ? "verde" : (s >= 50 ? "amber" : "vermelho"); },
    _scoreKpiClass: function (s) { return s >= 80 ? "ok" : (s >= 50 ? "wr" : "al"); },

    // Pontos de complexidade (seção 5) via CONFIG.precificacao
    _pontos: function (c) {
      var pr = CONFIG.precificacao || {};
      var ano = anoCorrente();
      var regId = CObrig.regimeNoAno(c, ano);
      var pts = 0, i;
      for (i = 0; i < CONFIG.regimes.length; i++) if (CONFIG.regimes[i].id === regId) pts = CONFIG.regimes[i].pontos || 0;
      var func = c.funcionarios || 0;
      var faixa = pr.faixaFuncionarios || 5;
      pts += Math.floor(func / faixa) * (pr.pontosPorFaixaFuncionarios || 1);
      var segs = c.segmento || [];
      var ps = pr.pontosSegmento || {};
      for (i = 0; i < segs.length; i++) if (ps[segs[i]]) pts += ps[segs[i]];
      var temIE = false, ins = c.inscricoes || [];
      for (i = 0; i < ins.length; i++) if ((ins[i].tipo === "estadual" || ins[i].tipo === "IE") && ins[i].numero) temIE = true;
      if (temIE || (c.filiais && c.filiais.length)) pts += (pr.pontosFilialOuIE || 0);
      return pts;
    },

    _regimeNome: function (id) {
      if (!id) return "—";
      for (var i = 0; i < CONFIG.regimes.length; i++) if (CONFIG.regimes[i].id === id) return CONFIG.regimes[i].nome;
      return id;
    },
    _segNome: function (id) {
      for (var i = 0; i < CONFIG.segmentos.length; i++) if (CONFIG.segmentos[i].id === id) return CONFIG.segmentos[i].nome;
      return id;
    },
    _segChips: function (arr) {
      var self = this;
      arr = arr || [];
      if (!arr.length) return '<span style="color:var(--mut)">—</span>';
      return arr.map(function (id) { return '<span class="chip">' + Util.esc(self._segNome(id)) + '</span>'; }).join("");
    },
    _statusLbl: function (s) { return STATUS_LBL[s] || (s ? s : "—"); },
    _statusCor: function (s) { return STATUS_COR[s] || "cinza"; },
    _obCor: function (s) {
      if (s === "concluida") return "verde";
      if (s === "retificada") return "roxo";
      if (s === "transmitida" || s === "comprovante_anexado") return "azul";
      if (s === "aguardando_cliente") return "amber";
      return "cinza";
    },
    _certBadge: function (validade) {
      var d = validade ? Util.diasAte(validade) : null;
      if (d == null) return UI.badge("sem validade", "cinza");
      if (d < 0) return UI.badge("vencido", "vermelho");
      if (d <= 30) return UI.badge("vence em " + d + "d", "amber");
      return UI.badge("válido", "verde");
    },
    _ieAtual: function (c) {
      var ie = "", ins = c.inscricoes || [];
      for (var i = 0; i < ins.length; i++) if (ins[i].tipo === "estadual") ie = ins[i].numero;
      return ie;
    },
    _kpi: function (n, l, cls) {
      return '<div class="kpi' + (cls ? " " + cls : "") + '"><div class="n">' + Util.esc(n) + '</div><div class="l">' + Util.esc(l) + '</div></div>';
    },
    // pode editar/criar cadastro? (respeita perfil somente-leitura do comercial)
    _podeEditar: function () {
      var p = Auth.perfil();
      if (p && p.soLeituraCadastro) return false;
      return Auth.pode("clientes", "criar") || Auth.pode("clientes", "editar");
    }
  };

  global.ClientesView = App.registrar(View);
})(window);
