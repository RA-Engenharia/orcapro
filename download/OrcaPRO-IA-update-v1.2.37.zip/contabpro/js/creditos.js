/* =====================================================================
 * creditos.js — Recuperação de Créditos & PER/DCOMP (seção 3.11).
 * CENTRO DE RECEITA: levanta créditos tributários do cliente e mede o
 * HONORÁRIO DE ÊXITO do escritório (valorLevantado × %). Controle manual
 * do ciclo levantado → PER/DCOMP transmitido → deferido → recebido
 * (com indeferido em ramo separado) + memória de cálculo impressa.
 * Registrada como id "creditos" (bate com CONFIG.modulos e Auth.pode).
 * Coleção nova: "creditos" = { id, clienteId, tese, descricao,
 *   periodoInicio(comp), periodoFim(comp), valorLevantado, baseLegal,
 *   status, perdcompNum, honorarioExitoPct(default 20), criadoEm,
 *   historico:[{status,quando,por,motivo?}] }.
 * ES5 estrito (var/function/concat). Orquestra Store + Auth + UI + App.
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  // ---------- Tabelas de domínio ----------
  var TESES = [
    { v: "pagamento_maior",    t: "Pagamento a maior/indevido" },
    { v: "monofasico_simples", t: "Monofásico no Simples Nacional" },
    { v: "pis_cofins",         t: "PIS/COFINS (exclusão ICMS da base)" },
    { v: "saldo_negativo",     t: "Saldo negativo de IRPJ/CSLL" },
    { v: "inss_retido",        t: "INSS retido não compensado" },
    { v: "icms_base",          t: "ICMS — base de cálculo indevida" }
  ];

  // Ciclo linear do crédito (indeferido é ramo à parte, não entra aqui).
  var PROXIMO = { levantado: "perdcomp_transmitido", perdcomp_transmitido: "deferido", deferido: "recebido" };
  var FINALIZADO = { recebido: 1, indeferido: 1 };

  var STATUS_ROTULO = {
    levantado: "Levantado",
    perdcomp_transmitido: "PER/DCOMP transmitido",
    deferido: "Deferido",
    indeferido: "Indeferido",
    recebido: "Recebido"
  };

  // ---------- Helpers puros (closure do módulo) ----------

  // Padrão de nome entre telas; null-safe (cliente pode ter sido excluído).
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(cliente excluído)"; }
  function idUsuario() { var u = Auth.usuario(); return u ? u.id : null; }

  // Nome de usuário p/ rastreabilidade (quem levantou / conduziu cada etapa).
  function nomeUsuario(id) {
    if (!id) return "—";
    var u = Store.obter("usuarios", id);
    return u ? u.nome : id;
  }

  function teseLabel(v) { for (var i = 0; i < TESES.length; i++) if (TESES[i].v === v) return TESES[i].t; return v || "—"; }
  function statusRotulo(s) { return STATUS_ROTULO[s] || s || "—"; }

  // Competência exibível: "2026-07" -> "jul/2026".
  function compRotulo(comp) { var p = Util.partes(comp + "-01"); if (!p.y) return "—"; return Util.mesNome(p.m) + "/" + p.y; }

  // Período do crédito p/ tabela/impressão.
  function periodoTxt(cr) {
    var ini = cr.periodoInicio ? compRotulo(cr.periodoInicio) : "—";
    var fim = cr.periodoFim ? compRotulo(cr.periodoFim) : "—";
    if (cr.periodoInicio && cr.periodoFim && cr.periodoInicio === cr.periodoFim) return ini;
    return ini + " – " + fim;
  }

  // Opções de competência: mês atual + 59 anteriores (5 anos — janela típica de recuperação).
  function opcoesCompetencia() {
    var h = Util.partes(Util.hojeISO()), ops = [], k;
    for (k = 0; k >= -59; k--) {
      var d = new Date(Date.UTC(h.y, h.m - 1 + k, 1));
      var comp = Util.competencia(d.getUTCFullYear(), d.getUTCMonth() + 1);
      ops.push({ v: comp, t: compRotulo(comp) });
    }
    return ops;
  }

  // parseValor robusto: "1.500,00" -> 1500 E "1500.00" -> 1500 (ponto decimal vira vírgula
  // p/ o parseBR não tratar como milhar e salvar 100x maior sem aviso).
  function parseValor(raw) {
    raw = String(raw == null ? "" : raw).trim();
    if (/^\d+\.\d{1,2}$/.test(raw)) raw = raw.replace(".", ",");
    return Util.parseBR(raw);
  }

  // Honorário de êxito de UM crédito (valorLevantado × %).
  function honorario(cr) { return (Number(cr.valorLevantado) || 0) * (Number(cr.honorarioExitoPct) || 0) / 100; }

  // Badge de status (levantado=cinza · transmitido=azul · deferido=verde · indeferido=vermelho · recebido=verde RECEBIDO).
  function statusBadge(cr) {
    var s = cr.status;
    if (s === "recebido") return UI.badge("RECEBIDO", "verde");
    if (s === "deferido") return UI.badge("Deferido", "verde");
    if (s === "perdcomp_transmitido") return UI.badge("PER/DCOMP transmitido", "azul");
    if (s === "indeferido") return UI.badge("Indeferido", "vermelho");
    return UI.badge("Levantado", "cinza");
  }

  // Quem levantou = 1ª entrada do histórico (rastreabilidade).
  function quemLevantou(cr) { var h = cr.historico || []; return h.length ? h[0].por : null; }

  // Registra a mudança de status no histórico (auditoria embutida no dado).
  function moverStatus(cr, novo, motivo) {
    cr.status = novo;
    cr.historico = cr.historico || [];
    var ev = { status: novo, quando: Util.hojeISO(), por: idUsuario() };
    if (motivo) ev.motivo = motivo;
    cr.historico.push(ev);
  }

  // ---------- View ----------
  global.CreditosView = App.registrar({
    id: "creditos",
    titulo: "Recuperação de Créditos",

    render: function () {
      if (!this._filtros) this._filtros = { cliente: "", status: "" };
      var f = this._filtros;
      // filtro fantasma: cliente filtrado foi excluído -> volta pra "todos".
      if (f.cliente && !Store.obter("clientes", f.cliente)) f.cliente = "";

      // Clientes visíveis (respeita carteira do analista).
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      var setVis = {}, nomeCli = {}, i;
      for (i = 0; i < visiveis.length; i++) { setVis[visiveis[i].id] = 1; nomeCli[visiveis[i].id] = nomeCliente(visiveis[i]); }
      function nomeDe(id) { return nomeCli[id] || "(cliente excluído)"; }

      // Créditos só de clientes visíveis.
      var todos = Store.listar("creditos"), visCred = [];
      for (i = 0; i < todos.length; i++) if (setVis[todos[i].clienteId]) visCred.push(todos[i]);

      // Aplica filtros (tabela + KPIs sobre o conjunto filtrado).
      var linhas = visCred.filter(function (cr) {
        if (f.cliente && cr.clienteId !== f.cliente) return false;
        if (f.status && cr.status !== f.status) return false;
        return true;
      });
      linhas = Util.ordenaPor(linhas, "criadoEm", true);

      // ---- KPIs ----
      var nAnalise = 0, totLevantado = 0, totRecebido = 0, honPotencial = 0;
      linhas.forEach(function (cr) {
        var v = Number(cr.valorLevantado) || 0;
        totLevantado += v;
        if (cr.status === "recebido") totRecebido += v;
        // "em análise" = ainda tramitando (nem recebido nem indeferido).
        if (cr.status !== "recebido" && cr.status !== "indeferido") nAnalise++;
        // honorário potencial: soma de tudo que NÃO foi indeferido (ainda pode virar receita).
        if (cr.status !== "indeferido") honPotencial += honorario(cr);
      });

      var kpis = '<div class="grid-kpi">' +
        '<div class="kpi ' + (nAnalise ? "wr" : "") + '"><div class="n">' + nAnalise + '</div><div class="l">Créditos em análise</div></div>' +
        '<div class="kpi"><div class="n">' + Util.brMoeda(totLevantado) + '</div><div class="l">Valor total levantado</div></div>' +
        '<div class="kpi ok"><div class="n">' + Util.brMoeda(totRecebido) + '</div><div class="l">Valor recebido</div></div>' +
        '<div class="kpi ok"><div class="n">' + Util.brMoeda(honPotencial) + '</div><div class="l">Honorário de êxito potencial</div></div>' +
        "</div>";

      // ---- Toolbar: filtros + novo ----
      var opCli = [{ v: "", t: "Todos os clientes" }];
      for (i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });
      var opSt = [{ v: "", t: "Todos os status" }];
      for (var s in STATUS_ROTULO) if (STATUS_ROTULO.hasOwnProperty(s)) opSt.push({ v: s, t: STATUS_ROTULO[s] });

      var podeCriar = Auth.pode("creditos", "criar");
      var toolbar = '<div class="toolbar">' +
        UI.sel("cred-f-cli", opCli, f.cliente) +
        UI.sel("cred-f-st", opSt, f.status) +
        (podeCriar ? '<button class="btn primary" data-acao="novo">' + UI.icone("plus", 16) + ' Levantar crédito</button>' : "") +
        "</div>";

      // ---- Tabela de créditos ----
      var rows = linhas.map(function (cr) { cr._cliNome = nomeDe(cr.clienteId); return cr; });
      var cols = [
        { k: "_cliNome", label: "Cliente", fmt: function (v, row) {
          var por = quemLevantou(row);
          var sub = por ? '<div class="fld-d" style="margin-top:2px">levantado por ' + Util.esc(nomeUsuario(por)) + "</div>" : "";
          return Util.esc(v) + sub;
        } },
        { k: "tese", label: "Tese", fmt: function (v) { return UI.badge(teseLabel(v), "roxo"); } },
        { k: "_periodo", label: "Período", fmt: function (v, row) { return '<span style="white-space:nowrap">' + Util.esc(periodoTxt(row)) + "</span>"; } },
        { k: "valorLevantado", label: "Valor levantado", cls: "num", fmt: function (v) { return Util.esc(Util.brMoeda(v)); } },
        { k: "status", label: "Status", fmt: function (v, row) { return statusBadge(row); } },
        { k: "honorarioExitoPct", label: "Êxito %", cls: "ctr", fmt: function (v) { return Util.esc(Util.brNum(Number(v) || 0, 0)) + "%"; } },
        { k: "_hon", label: "Honorário", cls: "num", fmt: function (v, row) { return Util.esc(Util.brMoeda(honorario(row))); } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) {
          var out = "";
          // avançar só até recebido; indeferido/recebido são finais.
          if (PROXIMO[row.status]) out += '<button class="btn sm green" data-acao="avancarStatus:' + Util.esc(row.id) + '">Avançar</button> ';
          if (!FINALIZADO[row.status]) out += '<button class="btn sm danger" data-acao="indeferir:' + Util.esc(row.id) + '">Indeferir</button> ';
          out += '<button class="btn sm" data-acao="editar:' + Util.esc(row.id) + '">Editar</button> ';
          out += '<button class="btn sm" data-acao="memoriaCalculo:' + Util.esc(row.id) + '">🖨 Memória</button>';
          if (Auth.pode("creditos", "excluir")) out += ' <button class="btn sm danger" data-acao="excluir:' + Util.esc(row.id) + '">✕</button>';
          return out;
        } }
      ];
      var tbl = UI.tabela(cols, rows, { vazio: "Nenhum crédito levantado para os filtros atuais." });

      var aviso = podeCriar ? "" : '<span class="chip">Somente leitura: seu perfil não levanta créditos</span>';

      return '<div class="page-hd"><div><h1>Recuperação de Créditos &amp; PER/DCOMP</h1>' +
        '<div class="sub">Centro de receita — créditos tributários levantados, ciclo do PER/DCOMP e honorário de êxito do escritório.</div></div>' +
        '<div>' + aviso + "</div></div>" +
        kpis + toolbar +
        '<div class="card"><div class="card-hd"><b>Créditos</b><span class="chip">' + linhas.length + ' item(ns)</span></div>' +
        '<div class="card-bd">' + tbl + "</div></div>";
    },

    // Liga os filtros (change -> guarda estado + re-render).
    onMount: function () {
      var self = this, map = [["cred-f-cli", "cliente"], ["cred-f-st", "status"]];
      map.forEach(function (par) {
        var e = UI.el(par[0]);
        if (e) e.addEventListener("change", function () { self._filtros[par[1]] = e.value; App.render(); });
      });
    },

    // ---- Ações ----

    novo: function () {
      if (!Auth.pode("creditos", "criar")) { UI.toast("Sem permissão para levantar créditos.", "erro"); return; }
      this._modalCredito(null);
    },

    editar: function (id) {
      if (!Auth.pode("creditos", "editar")) { UI.toast("Sem permissão para editar créditos.", "erro"); return; }
      var cr = Store.obter("creditos", id);
      if (!cr) { UI.toast("Crédito não encontrado.", "erro"); return; }
      this._modalCredito(cr);
    },

    // Modal compartilhado (cr=null -> novo). Cliente + tese + descrição + período (2 comps) + valor + base legal + % êxito.
    _modalCredito: function (cr) {
      var novo = !cr;
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      if (novo && !visiveis.length) { UI.toast("Cadastre um cliente antes de levantar créditos.", "info"); return; }

      var opCli = [{ v: "", t: "— selecione o cliente —" }];
      for (var i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });

      var h = Util.partes(Util.hojeISO()), compAtual = Util.competencia(h.y, h.m);
      var opComp = opcoesCompetencia();

      var corpo =
        UI.campo("Cliente", UI.sel("cred-cli", opCli, cr ? cr.clienteId : "")) +
        UI.campo("Tese", UI.sel("cred-tese", TESES, cr ? cr.tese : "pagamento_maior")) +
        UI.campo("Descrição", UI.inp("cred-desc", cr ? cr.descricao : "", "ex.: crédito de PIS/COFINS sobre ICMS destacado")) +
        '<div class="row">' +
        UI.campo("Período — início", UI.sel("cred-pini", opComp, cr ? cr.periodoInicio : compAtual)) +
        UI.campo("Período — fim", UI.sel("cred-pfim", opComp, cr ? cr.periodoFim : compAtual)) +
        "</div>" +
        '<div class="row">' +
        UI.campo("Valor levantado (R$)", UI.inp("cred-valor", cr ? Util.brNum(cr.valorLevantado, 2) : "", "0,00")) +
        UI.campo("Honorário de êxito (%)", UI.inp("cred-pct", cr ? Util.brNum(cr.honorarioExitoPct, 0) : "20", "20", "number")) +
        "</div>" +
        UI.campo("Base legal", '<textarea id="cred-base" class="in" rows="3" placeholder="ex.: Tema 69 STF (RE 574.706) — exclusão do ICMS da base do PIS/COFINS">' + Util.esc(cr ? cr.baseLegal : "") + "</textarea>") +
        '<div class="fld-d">O honorário de êxito é a receita do escritório: valor levantado × % (padrão 20%).</div>';

      var self = this;
      UI.modal(novo ? "Levantar crédito" : "Editar crédito", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "primary", onClick: function (fechar) {
          if (!Auth.pode("creditos", novo ? "criar" : "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var clienteId = UI.v("cred-cli");
          if (!clienteId) { UI.toast("Selecione o cliente.", "alerta"); return; }
          var pini = UI.v("cred-pini"), pfim = UI.v("cred-pfim");
          if (pini && pfim && pini > pfim) { UI.toast("O início do período não pode ser depois do fim.", "alerta"); return; }
          var valor = parseValor(UI.v("cred-valor"));
          if (!(valor > 0)) { UI.toast("Informe um valor levantado maior que zero.", "alerta"); return; }
          var pct = parseValor(UI.v("cred-pct"));
          if (!(pct >= 0 && pct <= 100)) { UI.toast("O % de êxito deve estar entre 0 e 100.", "alerta"); return; }

          var obj = {
            id: cr ? cr.id : Util.uid("cred"),
            clienteId: clienteId,
            tese: UI.v("cred-tese"),
            descricao: UI.v("cred-desc"),
            periodoInicio: pini,
            periodoFim: pfim,
            valorLevantado: valor,
            baseLegal: (function () { var e = UI.el("cred-base"); return e ? e.value.trim() : ""; })(),
            honorarioExitoPct: pct,
            status: cr ? cr.status : "levantado",
            perdcompNum: cr ? (cr.perdcompNum || "") : "",
            criadoEm: cr ? (cr.criadoEm || Util.hojeISO()) : Util.hojeISO(),
            // preserva histórico; novo nasce com a 1ª entrada (quem levantou).
            historico: cr ? (cr.historico || []) : [{ status: "levantado", quando: Util.hojeISO(), por: idUsuario() }]
          };
          Store.salvar("creditos", obj); // STORAGE_CHEIO -> ui.js mostra toast
          if (global.Audit) global.Audit.log(novo ? "credito_levantar" : "credito_editar", "creditos", obj.id);
          UI.toast(novo ? "Crédito levantado." : "Crédito atualizado.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    // Avança um passo no ciclo: levantado -> perdcomp_transmitido (pede nº) -> deferido -> recebido.
    avancarStatus: function (id) {
      if (!Auth.pode("creditos", "editar")) { UI.toast("Sem permissão para movimentar créditos.", "erro"); return; }
      var cr = Store.obter("creditos", id);
      if (!cr) { UI.toast("Crédito não encontrado.", "erro"); return; }
      var prox = PROXIMO[cr.status];
      if (!prox) { UI.toast("Crédito já está em status final.", "info"); return; }

      // Transmissão do PER/DCOMP exige o nº do documento (rastreabilidade fiscal).
      if (prox === "perdcomp_transmitido") {
        var corpo =
          '<p class="fld-d" style="margin-bottom:14px">Registre a transmissão do PER/DCOMP deste crédito.</p>' +
          UI.campo("Nº do PER/DCOMP", UI.inp("cred-perd", cr.perdcompNum || "", "ex.: 12345.67890/2026-11"));
        UI.modal("Transmitir PER/DCOMP", corpo, [
          { txt: "Cancelar" },
          { txt: "Confirmar transmissão", classe: "primary", onClick: function (fechar) {
            if (!Auth.pode("creditos", "editar")) { UI.toast("Sem permissão.", "erro"); return; }
            var num = UI.v("cred-perd");
            if (!num) { UI.toast("Informe o nº do PER/DCOMP.", "alerta"); return; }
            cr.perdcompNum = num;
            moverStatus(cr, "perdcomp_transmitido");
            Store.salvar("creditos", cr);
            if (global.Audit) global.Audit.log("credito_perdcomp_transmitido", "creditos", cr.id);
            UI.toast("PER/DCOMP transmitido.", "ok");
            fechar(); App.render();
          } }
        ]);
        return;
      }

      // deferido / recebido: confirmação simples.
      var msg = prox === "recebido"
        ? "Confirmar o <b>recebimento</b> do crédito? Ele passa a compor o valor recebido do escritório."
        : "Confirmar o <b>deferimento</b> do crédito pela Receita?";
      UI.modal("Avançar crédito", "<p>" + msg + "</p>", [
        { txt: "Cancelar" },
        { txt: "Confirmar", classe: "green", onClick: function (fechar) {
          if (!Auth.pode("creditos", "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          moverStatus(cr, prox);
          Store.salvar("creditos", cr);
          if (global.Audit) global.Audit.log("credito_" + prox, "creditos", cr.id);
          UI.toast("Crédito: " + statusRotulo(prox) + ".", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    // Indeferimento (ramo à parte): motivo obrigatório -> status indeferido.
    indeferir: function (id) {
      if (!Auth.pode("creditos", "editar")) { UI.toast("Sem permissão para indeferir créditos.", "erro"); return; }
      var cr = Store.obter("creditos", id);
      if (!cr) { UI.toast("Crédito não encontrado.", "erro"); return; }
      if (FINALIZADO[cr.status]) { UI.toast("Crédito já finalizado.", "info"); return; }
      var corpo =
        '<p class="fld-d" style="margin-bottom:14px">O indeferimento encerra o crédito e o retira do honorário de êxito potencial.</p>' +
        UI.campo("Motivo do indeferimento", UI.inp("cred-motivo", "", "ex.: glosa por falta de documentação / decadência"));
      UI.modal("Indeferir crédito", corpo, [
        { txt: "Cancelar" },
        { txt: "Indeferir", classe: "danger", onClick: function (fechar) {
          if (!Auth.pode("creditos", "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var motivo = UI.v("cred-motivo");
          if (!motivo) { UI.toast("Informe o motivo do indeferimento.", "alerta"); return; }
          moverStatus(cr, "indeferido", motivo);
          Store.salvar("creditos", cr);
          if (global.Audit) global.Audit.log("credito_indeferido", "creditos", cr.id);
          UI.toast("Crédito indeferido.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    excluir: function (id) {
      if (!Auth.pode("creditos", "excluir")) { UI.toast("Sem permissão para excluir créditos.", "erro"); return; }
      var cr = Store.obter("creditos", id);
      if (!cr) { UI.toast("Crédito não encontrado.", "erro"); return; }
      var cli = Store.obter("clientes", cr.clienteId);
      UI.modal("Excluir crédito",
        "<p>Excluir o crédito <b>" + Util.esc(teseLabel(cr.tese)) + "</b> de <b>" + Util.esc(nomeCliente(cli)) +
        "</b> (" + Util.esc(Util.brMoeda(cr.valorLevantado)) + ")? Esta ação não pode ser desfeita.</p>",
        [{ txt: "Cancelar" }, { txt: "Excluir", classe: "danger", onClick: function (fechar) {
          if (!Auth.pode("creditos", "excluir")) { UI.toast("Sem permissão.", "erro"); return; }
          Store.excluir("creditos", id);
          if (global.Audit) global.Audit.log("credito_excluir", "creditos", id);
          UI.toast("Crédito excluído.", "ok");
          fechar(); App.render();
        } }]);
    },

    // Memória de cálculo impressa (A4, shell da marca) — entregável que justifica o crédito
    // ao cliente/fisco: tese, base legal, período, valor em destaque, honorário e rastreabilidade.
    memoriaCalculo: function (id) {
      var cr = Store.obter("creditos", id);
      if (!cr) { UI.toast("Crédito não encontrado.", "erro"); return; }
      var cli = Store.obter("clientes", cr.clienteId); // null-safe
      var por = quemLevantou(cr);
      var valTxt = Util.brMoeda(cr.valorLevantado);
      var honTxt = Util.brMoeda(honorario(cr));
      var pctTxt = Util.brNum(Number(cr.honorarioExitoPct) || 0, 0) + "%";

      // Rastreabilidade: histórico completo (etapa · quando · responsável · motivo).
      var hist = cr.historico || [];
      var histRows = "";
      for (var i = 0; i < hist.length; i++) {
        var ev = hist[i];
        histRows += "<tr><td>" + Util.esc(statusRotulo(ev.status)) + "</td>" +
          "<td>" + Util.esc(Util.brData(ev.quando)) + "</td>" +
          "<td>" + Util.esc(nomeUsuario(ev.por)) + "</td>" +
          "<td>" + Util.esc(ev.motivo || "—") + "</td></tr>";
      }
      if (!histRows) histRows = '<tr><td colspan="4">Sem histórico registrado.</td></tr>';

      var corpo =
        "<h2>Identificação</h2>" +
        "<table>" +
        "<tr><th style='width:30%'>Escritório</th><td>" + Util.esc(CONFIG.marca.nome) + " · " + Util.esc(CONFIG.marca.slogan) + "</td></tr>" +
        "<tr><th>Cliente</th><td>" + Util.esc(nomeCliente(cli)) + "</td></tr>" +
        (cli && cli.cnpj ? "<tr><th>CNPJ</th><td>" + Util.esc(Util.formataCNPJ(cli.cnpj)) + "</td></tr>" : "") +
        "<tr><th>Tese</th><td>" + Util.esc(teseLabel(cr.tese)) + "</td></tr>" +
        (cr.descricao ? "<tr><th>Descrição</th><td>" + Util.esc(cr.descricao) + "</td></tr>" : "") +
        "<tr><th>Período apurado</th><td>" + Util.esc(periodoTxt(cr)) + "</td></tr>" +
        "<tr><th>Status atual</th><td class='" + (cr.status === "indeferido" ? "al" : (cr.status === "recebido" || cr.status === "deferido" ? "ok" : "")) + "'>" + Util.esc(statusRotulo(cr.status)) + "</td></tr>" +
        (cr.perdcompNum ? "<tr><th>Nº PER/DCOMP</th><td>" + Util.esc(cr.perdcompNum) + "</td></tr>" : "") +
        "</table>" +

        "<h2>Base legal</h2>" +
        "<p>" + (cr.baseLegal ? Util.esc(cr.baseLegal) : "<span class='al'>Base legal não informada.</span>") + "</p>" +

        "<h2>Apuração do crédito</h2>" +
        "<table>" +
        "<tr><th>Descrição</th><th class='dir' style='width:30%'>Valor</th></tr>" +
        "<tr class='tot'><td>Crédito levantado</td><td class='dir'>" + Util.esc(valTxt) + "</td></tr>" +
        "<tr><td>Honorário de êxito do escritório (" + Util.esc(pctTxt) + ")</td><td class='dir'>" + Util.esc(honTxt) + "</td></tr>" +
        "</table>" +

        "<h2>Rastreabilidade</h2>" +
        "<p>Crédito levantado por <b>" + Util.esc(nomeUsuario(por)) + "</b>.</p>" +
        "<table>" +
        "<tr><th>Etapa</th><th>Data</th><th>Responsável</th><th>Observação</th></tr>" +
        histRows +
        "</table>" +
        "<p style='margin-top:16px;color:#64748b;font-size:11px'>Documento de controle interno do escritório. A homologação do crédito depende de análise da Receita Federal — este demonstrativo não constitui reconhecimento definitivo do valor.</p>";

      App._abrirPrint("Memória de Cálculo — Recuperação de Crédito", corpo);
      if (global.Audit) global.Audit.log("credito_memoria_imprimir", "creditos", cr.id);
    }
  });
})(window);
