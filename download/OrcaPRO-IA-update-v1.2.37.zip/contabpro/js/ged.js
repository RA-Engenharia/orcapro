/* =====================================================================
 * ged.js — GED básico (seção 3.14). Documentos por cliente e categoria.
 * Árvore de categorias fixa. Upload local (dataURL p/ pequenos, metadados
 * p/ grandes). Alerta de validade (vencidos / vencendo em <=30d).
 * View no padrão App.registrar. ES5 estrito.
 * ===================================================================== */
(function (global) {
  "use strict";
  var Store = global.Store, Auth = global.Auth, Util = global.Util, UI = global.UI, App = global.App;

  // Árvore de categorias fixa (seção 3.14)
  var CATEGORIAS = ["Contratos", "Fiscal", "Contábil", "DP", "Societário", "Certidões", "Guias", "Defesas", "Correspondências"];
  // Cor da badge por categoria (só estético)
  var CORCAT = {
    "Contratos": "azul", "Fiscal": "roxo", "Contábil": "azul", "DP": "verde",
    "Societário": "roxo", "Certidões": "amber", "Guias": "cinza", "Defesas": "vermelho", "Correspondências": "cinza"
  };
  var CORORIGEM = { upload: "cinza", portal: "azul", robo: "roxo" };
  var LIMITE = 1.5 * 1024 * 1024; // 1,5 MB

  // nome apresentável do cliente (tolerante ao schema)
  function nomeCliente(c) {
    if (!c) return "(cliente removido)";
    return c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)"; // razão social primeiro (padrão entre telas)
  }
  // mapa id->cliente dos visíveis ao usuário
  function mapaClientes() {
    var vis = Auth.clientesVisiveis(Store.listar("clientes"));
    var idx = {}; for (var i = 0; i < vis.length; i++) idx[vis[i].id] = vis[i];
    return { lista: vis, idx: idx };
  }
  // tamanho legível
  function tamHum(bytes) {
    bytes = Number(bytes) || 0;
    if (!bytes) return "—";
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return Util.brNum(bytes / 1024, 0) + " KB";
    return Util.brNum(bytes / (1024 * 1024), 1) + " MB";
  }

  window.GedView = App.registrar({
    id: "ged",
    fCli: "",   // filtro cliente
    fCat: "",   // filtro categoria

    render: function () {
      var self = this;
      var mc = mapaClientes();

      // ---- documentos visíveis + filtros ----
      var docs = Store.listar("documentos").filter(function (d) { return mc.idx[d.clienteId]; });
      if (self.fCli) docs = docs.filter(function (d) { return d.clienteId === self.fCli; });
      if (self.fCat) docs = docs.filter(function (d) { return d.categoria === self.fCat; });
      docs = Util.ordenaPor(docs, "criadoEm", true); // mais recentes primeiro

      // ---- KPIs de validade ----
      var nVenc = 0, nVence = 0;
      docs.forEach(function (d) {
        if (!d.validade) return;
        var dias = Util.diasAte(d.validade);
        if (dias == null) return;
        if (dias < 0) nVenc++; else if (dias <= 30) nVence++;
      });

      // ---- toolbar ----
      var opsCli = [{ v: "", t: "Todos os clientes" }].concat(mc.lista.map(function (c) { return { v: c.id, t: nomeCliente(c) }; }));
      var opsCat = [{ v: "", t: "Todas as categorias" }].concat(CATEGORIAS.map(function (c) { return { v: c, t: c }; }));
      var podeCriar = mc.lista.length > 0;

      var toolbar =
        '<div class="toolbar">' +
        UI.sel("ged-fcli", opsCli, self.fCli) +
        UI.sel("ged-fcat", opsCat, self.fCat) +
        '<button class="btn primary" data-acao="novo"' + (podeCriar ? "" : " disabled") + '>' + UI.icone("plus", 16) + ' Adicionar documento</button>' +
        '</div>';

      // ---- alerta de validade ----
      var alerta = "";
      if (nVenc || nVence) {
        var partes = [];
        if (nVenc) partes.push('<b style="color:var(--red)">' + nVenc + '</b> vencido' + (nVenc > 1 ? "s" : ""));
        if (nVence) partes.push('<b style="color:var(--amber)">' + nVence + '</b> vencendo em 30 dias');
        alerta = '<div class="card" style="border-left:4px solid var(--amber)"><div class="card-bd" style="padding:14px 18px">' +
          UI.icone("alert", 16) + ' Atenção: ' + partes.join(" · ") + ' — verifique os documentos destacados abaixo.' +
          '</div></div>';
      }

      // ---- tabela ----
      var cols = [
        { k: "clienteId", label: "Cliente", fmt: function (v) { return Util.esc(nomeCliente(mc.idx[v])); } },
        { k: "categoria", label: "Categoria", fmt: function (v) { return v ? UI.badge(v, CORCAT[v] || "cinza") : "—"; } },
        { k: "descricao", label: "Nome / Descrição", fmt: function (v, r) { return '<b>' + Util.esc(v || r.nomeArquivo || "(sem descrição)") + '</b>' + (r.nomeArquivo && v ? '<div style="color:var(--mut);font-size:11px">' + Util.esc(r.nomeArquivo) + ' · ' + tamHum(r.tamanho) + (r.dataURL ? '' : ' · só metadados') + '</div>' : ''); } },
        { k: "competencia", label: "Competência", fmt: function (v) { return v ? Util.esc(v) : "—"; } },
        { k: "validade", label: "Validade", fmt: function (v) {
            if (!v) return '<span style="color:var(--mut)">—</span>';
            var dias = Util.diasAte(v), txt = Util.brData(v);
            if (dias == null) return txt;
            if (dias < 0) return txt + " " + UI.badge("vencido", "vermelho");
            if (dias <= 30) return txt + " " + UI.badge("vence em " + dias + "d", "amber");
            return txt + " " + UI.badge("válido", "verde");
          } },
        { k: "origem", label: "Origem", fmt: function (v) { v = v || "upload"; return UI.badge(v, CORORIGEM[v] || "cinza"); } },
        { k: "id", label: "Ações", cls: "ctr", fmt: function (v) {
            return '<button class="btn sm" data-acao="baixar:' + v + '" title="Baixar arquivo">Baixar</button> ' +
              '<button class="btn sm danger" data-acao="excluir:' + v + '" title="Excluir documento">Excluir</button>';
          } }
      ];
      var tabela = UI.tabela(cols, docs, { vazio: "Nenhum documento para este filtro. Use “Adicionar documento” para começar." });

      return '' +
        '<div class="page-hd"><div><h1>Documentos (GED)</h1>' +
        '<div class="sub">Arquivo digital por cliente e categoria — contratos, guias, certidões e correspondências.</div></div></div>' +
        '<div class="grid-kpi">' +
        '<div class="kpi"><div class="n">' + docs.length + '</div><div class="l">Documentos (filtro)</div></div>' +
        '<div class="kpi ' + (nVence ? "wr" : "") + '"><div class="n">' + nVence + '</div><div class="l">Vencendo em 30d</div></div>' +
        '<div class="kpi ' + (nVenc ? "al" : "") + '"><div class="n">' + nVenc + '</div><div class="l">Vencidos</div></div>' +
        '</div>' +
        toolbar + alerta +
        '<div class="card"><div class="card-bd">' + tabela + '</div></div>';
    },

    // liga os selects de filtro (change não passa por data-acao)
    onMount: function () {
      var self = this;
      var fc = UI.el("ged-fcli"), fk = UI.el("ged-fcat");
      if (fc) fc.onchange = function () { self.fCli = this.value; App.render(); };
      if (fk) fk.onchange = function () { self.fCat = this.value; App.render(); };
    },

    // ---- Adicionar documento ----
    novo: function () {
      var self = this;
      var mc = mapaClientes();
      if (!mc.lista.length) { UI.toast("Cadastre um cliente antes de anexar documentos.", "alerta"); return; }

      var opsCli = [{ v: "", t: "— selecione o cliente —" }].concat(mc.lista.map(function (c) { return { v: c.id, t: nomeCliente(c) }; }));
      var opsCat = CATEGORIAS.map(function (c) { return { v: c, t: c }; });
      var catPad = self.fCat || CATEGORIAS[0];
      var cliPad = self.fCli || "";

      var corpo =
        UI.campo("Cliente", UI.sel("ged-m-cli", opsCli, cliPad)) +
        '<div class="row">' +
        UI.campo("Categoria", UI.sel("ged-m-cat", opsCat, catPad)) +
        UI.campo("Competência", UI.inp("ged-m-comp", "", "2026-07 (opcional)"), "Formato ano-mês. Deixe vazio se não se aplica.") +
        '</div>' +
        UI.campo("Nome / Descrição", UI.inp("ged-m-desc", "", "Ex.: Contrato social, DAS 07/2026, CND Federal")) +
        UI.campo("Validade", UI.inp("ged-m-val", "", "", "date"), "Opcional. Certidões e contratos com data de vencimento entram no alerta.") +
        UI.campo("Arquivo", '<input id="ged-m-arq" class="in" type="file">', "Até 1,5 MB é guardado no app. Maior que isso: guardamos só os dados (nome/tamanho).");

      UI.modal("Adicionar documento", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar documento", classe: "green", onClick: function (fechar) {
            var clienteId = UI.v("ged-m-cli");
            if (!clienteId) { UI.toast("Selecione o cliente.", "erro"); return; }
            var categoria = UI.v("ged-m-cat") || CATEGORIAS[0];
            var competencia = UI.v("ged-m-comp");
            var descricao = UI.v("ged-m-desc");
            var validade = UI.v("ged-m-val");
            var elArq = UI.el("ged-m-arq");
            var file = (elArq && elArq.files && elArq.files.length) ? elArq.files[0] : null;

            if (!file && !descricao) { UI.toast("Informe uma descrição ou anexe um arquivo.", "erro"); return; }

            // arquivo pequeno -> lê como dataURL; grande -> só metadados
            if (file && file.size <= LIMITE) {
              var fr = new FileReader();
              fr.onload = function () {
                self._persistir(clienteId, categoria, descricao, competencia, validade, file.name, file.size, fr.result);
                fechar();
              };
              fr.onerror = function () { UI.toast("Não foi possível ler o arquivo.", "erro"); };
              try { fr.readAsDataURL(file); } catch (e) { UI.toast("Falha ao ler o arquivo: " + e.message, "erro"); }
            } else {
              if (file) UI.toast("Arquivo grande (" + tamHum(file.size) + "): guardando só os metadados.", "alerta");
              self._persistir(clienteId, categoria, descricao, competencia, validade, file ? file.name : "", file ? file.size : 0, null);
              fechar();
            }
          } }
      ]);
    },

    // monta o registro, salva, audita e re-renderiza
    _persistir: function (clienteId, categoria, descricao, competencia, validade, nomeArquivo, tamanho, dataURL) {
      var u = Auth.usuario();
      var doc = {
        id: Util.uid("doc"),
        clienteId: clienteId,
        categoria: categoria,
        descricao: descricao || "",
        competencia: competencia || "",
        validade: validade || "",
        origem: "upload",
        nomeArquivo: nomeArquivo || "",
        tamanho: tamanho || 0,
        acessos: [],
        criadoEm: Util.hojeISO(),
        criadoPor: u ? u.id : null
      };
      if (dataURL) doc.dataURL = dataURL; // só grava conteúdo se coube
      Store.salvar("documentos", doc);
      if (global.Audit) global.Audit.log("adicionou", "documento", doc.id);
      UI.toast("Documento adicionado.", "ok");
      App.render();
    },

    // ---- Baixar (simbólico): usa o dataURL guardado ----
    baixar: function (id) {
      var doc = Store.obter("documentos", id);
      if (!doc) { UI.toast("Documento não encontrado.", "erro"); return; }
      if (!doc.dataURL) { UI.toast("Arquivo não armazenado (grande) — só metadados.", "alerta"); return; }
      try {
        var a = document.createElement("a");
        a.href = doc.dataURL;
        a.download = doc.nomeArquivo || (doc.descricao ? doc.descricao + ".dat" : "documento.dat");
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        // registra acesso
        var u = Auth.usuario();
        (doc.acessos = doc.acessos || []).push({ quando: Util.hojeISO(), por: u ? u.id : null });
        Store.salvar("documentos", doc);
        if (global.Audit) global.Audit.log("baixou", "documento", doc.id);
      } catch (e) {
        UI.toast("Falha ao baixar: " + e.message, "erro");
      }
    },

    // ---- Excluir (com confirmação) ----
    excluir: function (id) {
      var self = this;
      // guard na função: excluir é destrutivo (nível >= 50) — recepção protocola, não apaga
      if (!Auth.pode("ged", "excluir")) { UI.toast("Sem permissão para excluir documentos.", "erro"); return; }
      var doc = Store.obter("documentos", id);
      if (!doc) { UI.toast("Documento não encontrado.", "erro"); return; }
      var rotulo = doc.descricao || doc.nomeArquivo || "este documento";
      UI.modal("Excluir documento",
        '<p>Excluir <b>' + Util.esc(rotulo) + '</b>? Esta ação não pode ser desfeita.</p>',
        [
          { txt: "Cancelar" },
          { txt: "Excluir", classe: "danger", onClick: function (fechar) {
              Store.excluir("documentos", id);
              if (global.Audit) global.Audit.log("excluiu", "documento", id);
              UI.toast("Documento excluído.", "ok");
              fechar();
              App.render();
            } }
        ]);
    }
  });
})(window);
