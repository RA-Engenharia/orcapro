/* =====================================================================
 * ui.js — componentes de UI reutilizáveis do ContabPRO (modal, toast,
 * tabela, formulário, badges, ícones). Base de TODAS as telas.
 * ===================================================================== */
(function (global) {
  "use strict";
  var Util = global.Util;
  var ICONS = {
    grid: "M3 3h7v7H3zM14 3h7v7h-7zM14 14h7v7h-7zM3 14h7v7H3z",
    users: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75",
    calendar: "M3 4h18v18H3zM3 10h18M8 2v4M16 2v4",
    check: "M9 11l3 3L22 4M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11",
    folder: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z",
    shield: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z",
    alert: "M12 9v4M12 17h.01M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z",
    plus: "M12 5v14M5 12h14", search: "M21 21l-4.35-4.35M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z",
    trend: "M23 6l-9.5 9.5-5-5L1 18M17 6h6v6",
    flag: "M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22v-7",
    clock: "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2",
    money: "M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"
  };

  var UI = {
    el: function (id) { return document.getElementById(id); },
    icone: function (nome, tam) { tam = tam || 20; var p = ICONS[nome] || ICONS.check; return '<svg width="' + tam + '" height="' + tam + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="' + p + '"/></svg>'; },

    toast: function (msg, tipo) {
      var d = document.createElement("div");
      d.className = "toast toast-" + (tipo || "info");
      d.textContent = msg;
      (UI.el("toasts") || document.body).appendChild(d);
      setTimeout(function () { d.classList.add("show"); }, 10);
      setTimeout(function () { d.classList.remove("show"); setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 300); }, 3600);
    },

    // modal(titulo, corpoHTML, botoes[{txt, classe, onClick(fecha)}])  -> onClick recebe fechar()
    modal: function (titulo, corpo, botoes) {
      UI.fecharModal();
      var ov = document.createElement("div"); ov.className = "modal-ov"; ov.id = "modal-ov";
      var bts = (botoes || [{ txt: "Fechar", classe: "" }]).map(function (b, i) { return '<button class="btn ' + (b.classe || "") + '" data-mb="' + i + '">' + Util.esc(b.txt) + '</button>'; }).join("");
      ov.innerHTML = '<div class="modal"><div class="modal-hd"><b>' + Util.esc(titulo) + '</b><button class="modal-x" data-mx="1">✕</button></div>' +
        '<div class="modal-bd">' + corpo + '</div><div class="modal-ft">' + bts + '</div></div>';
      document.body.appendChild(ov);
      function fechar() { UI.fecharModal(); }
      ov.querySelector("[data-mx]").onclick = fechar;
      ov.onclick = function (e) { if (e.target === ov) fechar(); };
      // cada botão chama onClick(fechar); se quiser fechar, o próprio onClick chama fechar().
      // try/catch: falha de gravação (STORAGE_CHEIO) vira toast, nunca exceção solta.
      (botoes || []).forEach(function (b, i) {
        var el = ov.querySelector('[data-mb="' + i + '"]');
        if (el) el.onclick = function () {
          try { if (b.onClick) b.onClick(fechar); else fechar(); }
          catch (err) { UI.toast(err && err.message ? err.message : "Erro inesperado.", "erro"); }
        };
      });
      return ov;
    },
    fecharModal: function () { var m = UI.el("modal-ov"); if (m && m.parentNode) m.parentNode.removeChild(m); },

    // tabela(colunas[{k,label,fmt?,cls?}], linhas[], opts{vazio,onRow})
    tabela: function (cols, linhas, opts) {
      opts = opts || {};
      if (!linhas || !linhas.length) return '<div class="empty">' + Util.esc(opts.vazio || "Nada por aqui ainda.") + '</div>';
      var th = cols.map(function (c) { return '<th class="' + (c.cls || "") + '">' + Util.esc(c.label) + '</th>'; }).join("");
      var tr = linhas.map(function (row, i) {
        var tds = cols.map(function (c) { var v = c.fmt ? c.fmt(row[c.k], row) : Util.esc(row[c.k] == null ? "" : row[c.k]); return '<td class="' + (c.cls || "") + '">' + v + '</td>'; }).join("");
        return '<tr data-row="' + i + '"' + (opts.onRow ? ' class="clk"' : "") + '>' + tds + '</tr>';
      }).join("");
      return '<div class="tbl-wrap"><table class="tbl"><thead><tr>' + th + '</tr></thead><tbody>' + tr + '</tbody></table></div>';
    },

    // ---- form helpers ----
    campo: function (label, inner, dica) { return '<label class="fld"><span class="fld-l">' + Util.esc(label) + '</span>' + inner + (dica ? '<span class="fld-d">' + Util.esc(dica) + '</span>' : "") + '</label>'; },
    inp: function (id, val, ph, tipo) { return '<input id="' + id + '" class="in" type="' + (tipo || "text") + '" value="' + Util.esc(val == null ? "" : val) + '" placeholder="' + Util.esc(ph || "") + '">'; },
    sel: function (id, ops, val) { var o = ops.map(function (op) { var v = op.v != null ? op.v : op, t = op.t != null ? op.t : op; return '<option value="' + Util.esc(v) + '"' + (String(v) === String(val) ? " selected" : "") + '>' + Util.esc(t) + '</option>'; }).join(""); return '<select id="' + id + '" class="in">' + o + '</select>'; },
    v: function (id) { var e = UI.el(id); return e ? e.value.trim() : ""; },

    badge: function (txt, cor) { return '<span class="badge badge-' + (cor || "cinza") + '">' + Util.esc(txt) + '</span>'; }
  };

  global.UI = UI;
})(window);
