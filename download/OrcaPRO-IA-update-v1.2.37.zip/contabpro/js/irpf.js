/* =====================================================================
 * irpf.js — Campanha IRPF (seção 3.19). Módulo SAZONAL (mar-mai) gerido
 * como PROJETO ANUAL: cada declarante é um "cartão" com checklist de
 * documentos por perfil, esteira de status e recibo de entrega.
 * Registrada como id "irpf" (bate com CONFIG.modulos e Auth.pode).
 * Coleção nova: "declarantes" = { id, ano(number), nome, cpf, clienteId?,
 *   perfil, preco, status, reciboNum?, checklist:[{item,ok}], obs, criadoEm }.
 * App OFFLINE: sem transmissão automática — o recibo é registro manual.
 * ES5 estrito (var/function/concat). Orquestra Store + Auth + UI + App.
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  // ---------- Tabelas de domínio ----------
  var PERFIS = [
    { v: "simples",       t: "Simples",           cor: "cinza" },
    { v: "com_bens",      t: "Com bens",          cor: "azul" },
    { v: "cripto",        t: "Cripto",            cor: "roxo" },
    { v: "exterior",      t: "Exterior",          cor: "amber" },
    { v: "rural",         t: "Rural",             cor: "verde" },
    { v: "ganho_capital", t: "Ganho de capital",  cor: "vermelho" }
  ];
  // Esteira (ordem de avanço). "malha" fica FORA da esteira (desvio pós-entrega).
  var ESTEIRA = ["docs_pendentes", "em_elaboracao", "em_conferencia", "entregue"];
  var STATUS = [
    { v: "docs_pendentes", t: "Docs pendentes",  cor: "amber" },
    { v: "em_elaboracao",  t: "Em elaboração",   cor: "azul" },
    { v: "em_conferencia", t: "Em conferência",  cor: "roxo" },
    { v: "entregue",       t: "Entregue",        cor: "verde" },
    { v: "malha",          t: "Malha fina",      cor: "vermelho" }
  ];

  // Documentos extras POR perfil (todos herdam a base do "simples").
  var DOCS_BASE = ["Informes de rendimento", "Informes bancários"];
  var DOCS_EXTRA = {
    com_bens:      ["Documentos de imóveis", "IPTU"],
    cripto:        ["Extratos de exchanges"],
    exterior:      ["DCBE/bens no exterior"],
    rural:         ["Livro-caixa rural/LCDPR"],
    ganho_capital: ["Contratos de compra/venda", "GCAP"]
  };

  // ---------- Helpers puros (closure do módulo) ----------

  // Padrão de nome entre telas; null-safe (cliente pode ter sido excluído).
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(cliente excluído)"; }
  function anoAtual() { return new Date().getFullYear(); }

  function perfilInfo(v) { for (var i = 0; i < PERFIS.length; i++) if (PERFIS[i].v === v) return PERFIS[i]; return { v: v, t: v || "—", cor: "cinza" }; }
  function statusInfo(v) { for (var i = 0; i < STATUS.length; i++) if (STATUS[i].v === v) return STATUS[i]; return { v: v, t: v || "—", cor: "cinza" }; }
  function perfilBadge(v) { var p = perfilInfo(v); return UI.badge(p.t, p.cor); }
  function statusBadge(v) { var s = statusInfo(v); return UI.badge(s.t, s.cor); }

  // Lista de itens (labels) da base de um perfil.
  function docsDoPerfil(perfil) { return DOCS_BASE.concat(DOCS_EXTRA[perfil] || []); }

  // Checklist novo (todos ok=false) para o perfil.
  function novoChecklist(perfil) {
    return docsDoPerfil(perfil).map(function (item) { return { item: item, ok: false }; });
  }

  // Recria a base do perfil PRESERVANDO os "ok" de itens de mesmo rótulo
  // (troca de perfil ao editar não perde o que já foi conferido).
  function mesclaChecklist(perfil, atual) {
    var prev = {}, i;
    for (i = 0; i < (atual || []).length; i++) prev[atual[i].item] = !!atual[i].ok;
    return docsDoPerfil(perfil).map(function (item) { return { item: item, ok: !!prev[item] }; });
  }

  // Progresso de documentos "x/y".
  function progresso(d) {
    var ch = d.checklist || [], ok = 0;
    for (var i = 0; i < ch.length; i++) if (ch[i].ok) ok++;
    return { ok: ok, total: ch.length };
  }

  // Parse monetário: aceita "1.500,00" (BR) E "1500.00" (ponto decimal) -> 1500.
  // Sem isto, "1500.00" viraria 150000 (ponto tratado como milhar) sem aviso.
  function parseValor(raw) {
    raw = String(raw == null ? "" : raw).trim();
    if (/^\d+\.\d{1,2}$/.test(raw)) raw = raw.replace(".", ",");
    return Util.parseBR(raw);
  }

  // Opções de ano: atual e os 2 anteriores.
  function opcoesAno() {
    var a = anoAtual(), ops = [];
    for (var k = 0; k <= 2; k++) ops.push({ v: String(a - k), t: String(a - k) });
    return ops;
  }

  // Barra de progresso da campanha (entregues/total).
  function barraCampanha(entregues, total) {
    var pct = total ? Math.round((entregues / total) * 100) : 0;
    return '<div class="card"><div class="card-hd"><b>Progresso da campanha</b>' +
      '<span class="chip">' + entregues + '/' + total + ' entregue(s) · ' + pct + '%</span></div>' +
      '<div class="card-bd"><div style="background:#e2e8f0;border-radius:8px;height:16px;overflow:hidden">' +
      '<div style="height:100%;width:' + pct + '%;background:linear-gradient(90deg,#2e6f9e,#16a34a);transition:width .3s"></div>' +
      '</div></div></div>';
  }

  // ---------- View ----------
  global.IrpfView = App.registrar({
    id: "irpf",
    titulo: "Campanha IRPF",

    render: function () {
      if (!this._ano) this._ano = String(anoAtual());
      // Detalhe aberto? (declarante inexistente/de outro ano -> volta pra lista)
      if (this._aberto) {
        var det = Store.obter("declarantes", this._aberto);
        if (!det || String(det.ano) !== String(this._ano)) this._aberto = null;
        else return this._renderDetalhe(det);
      }

      var ano = this._ano, i;
      var todos = Store.listar("declarantes").filter(function (d) { return String(d.ano) === String(ano); });
      todos = Util.ordenaPor(todos, "nome");

      // ---- KPIs ----
      var nTotal = todos.length, nDocs = 0, nEntreg = 0, nMalha = 0;
      for (i = 0; i < todos.length; i++) {
        if (todos[i].status === "docs_pendentes") nDocs++;
        if (todos[i].status === "entregue") nEntreg++;
        if (todos[i].status === "malha") nMalha++;
      }
      var kpis = '<div class="grid-kpi">' +
        '<div class="kpi"><div class="n">' + nTotal + '</div><div class="l">Declarantes ' + Util.esc(ano) + '</div></div>' +
        '<div class="kpi ' + (nDocs ? "wr" : "") + '"><div class="n">' + nDocs + '</div><div class="l">Docs pendentes</div></div>' +
        '<div class="kpi ok"><div class="n">' + nEntreg + '</div><div class="l">Entregues</div></div>' +
        '<div class="kpi ' + (nMalha ? "al" : "") + '"><div class="n">' + nMalha + '</div><div class="l">Em malha fina</div></div>' +
        "</div>";

      // ---- Toolbar: ano + ações ----
      var podeCriar = Auth.pode("irpf", "criar");
      var toolbar = '<div class="toolbar">' +
        UI.sel("irpf-ano", opcoesAno(), ano) +
        (podeCriar ? '<button class="btn primary" data-acao="novo">' + UI.icone("plus", 16) + ' Novo declarante</button>' : "") +
        '<button class="btn" data-acao="relatorio">' + UI.icone("trend", 16) + ' BI da campanha</button>' +
        "</div>";

      // ---- Tabela ----
      var rows = todos.map(function (d) { return d; });
      var cols = [
        { k: "nome", label: "Declarante", fmt: function (v) { return Util.esc(v || "(sem nome)"); } },
        { k: "cpf", label: "CPF", fmt: function (v) { return '<span style="white-space:nowrap">' + Util.esc(Util.formataCPF(v)) + "</span>"; } },
        { k: "perfil", label: "Perfil", fmt: function (v) { return perfilBadge(v); } },
        { k: "preco", label: "Preço", cls: "num", fmt: function (v) { return Util.esc(Util.brMoeda(v)); } },
        { k: "_prog", label: "Docs", cls: "ctr", fmt: function (v, row) { var p = progresso(row); return Util.esc(p.ok + "/" + p.total); } },
        { k: "status", label: "Status", fmt: function (v) { return statusBadge(v); } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) {
          var out = '<button class="btn sm" data-acao="abrir:' + Util.esc(row.id) + '">Abrir</button> ';
          if (Auth.pode("irpf", "editar")) {
            if (ESTEIRA.indexOf(row.status) >= 0 && row.status !== "entregue") out += '<button class="btn sm green" data-acao="avancarStatus:' + Util.esc(row.id) + '">Avançar</button> ';
            if (row.status === "entregue") out += '<button class="btn sm danger" data-acao="marcarMalha:' + Util.esc(row.id) + '">Malha</button> ';
            out += '<button class="btn sm" data-acao="editar:' + Util.esc(row.id) + '">Editar</button>';
          }
          if (Auth.pode("irpf", "excluir")) out += ' <button class="btn sm danger" data-acao="excluir:' + Util.esc(row.id) + '">✕</button>';
          return out;
        } }
      ];
      var tbl = UI.tabela(cols, rows, { vazio: "Nenhum declarante em " + ano + ". Cadastre o primeiro para começar a campanha." });

      var aviso = podeCriar ? "" : '<span class="chip">Somente leitura: seu perfil não edita a campanha IRPF</span>';

      return '<div class="page-hd"><div><h1>Campanha IRPF ' + Util.esc(ano) + '</h1>' +
        '<div class="sub">Gestão da temporada de declarações — checklist de documentos, esteira de entrega e controle de malha fina.</div></div>' +
        '<div>' + aviso + "</div></div>" +
        kpis + toolbar +
        barraCampanha(nEntreg, nTotal) +
        '<div class="card"><div class="card-hd"><b>Declarantes</b><span class="chip">' + nTotal + ' item(ns)</span></div>' +
        '<div class="card-bd">' + tbl + "</div></div>";
    },

    // Detalhe de um declarante: checklist clicável + dados + ações de esteira.
    _renderDetalhe: function (d) {
      var cli = d.clienteId ? Store.obter("clientes", d.clienteId) : null;
      var p = progresso(d), podeEditar = Auth.pode("irpf", "editar");

      // Checklist clicável (toggle por índice).
      var itens = (d.checklist || []).map(function (c, idx) {
        var marca = c.ok ? "✓" : "○";
        var cls = c.ok ? "ok" : "";
        var attr = podeEditar ? ' data-acao="marcarDoc:' + Util.esc(d.id) + "|" + idx + '" style="cursor:pointer"' : "";
        return '<li' + attr + ' class="' + cls + '" style="list-style:none;padding:7px 10px;margin:4px 0;border:1px solid #cbd5e1;border-radius:8px;' +
          (c.ok ? 'background:#f0fdf4' : '') + '"><b style="margin-right:8px">' + marca + "</b>" + Util.esc(c.item) + "</li>";
      }).join("") || '<div class="empty">Sem itens no checklist.</div>';

      // Ficha (dados).
      var ficha = "<table class='tbl'><tbody>" +
        "<tr><td><b>CPF</b></td><td>" + Util.esc(Util.formataCPF(d.cpf)) + "</td></tr>" +
        "<tr><td><b>Perfil</b></td><td>" + perfilBadge(d.perfil) + "</td></tr>" +
        "<tr><td><b>Preço</b></td><td>" + Util.esc(Util.brMoeda(d.preco)) + "</td></tr>" +
        "<tr><td><b>Status</b></td><td>" + statusBadge(d.status) + "</td></tr>" +
        "<tr><td><b>Cliente vinculado</b></td><td>" + Util.esc(cli ? nomeCliente(cli) : "— (pessoa física avulsa)") + "</td></tr>" +
        (d.reciboNum ? "<tr><td><b>Recibo de entrega</b></td><td>" + Util.esc(d.reciboNum) + "</td></tr>" : "") +
        (d.obs ? "<tr><td><b>Observações</b></td><td>" + Util.esc(d.obs) + "</td></tr>" : "") +
        "</tbody></table>";

      var acoes = '<div class="toolbar">' +
        '<button class="btn" data-acao="voltar">&larr; Voltar</button>';
      if (podeEditar) {
        if (ESTEIRA.indexOf(d.status) >= 0 && d.status !== "entregue") acoes += '<button class="btn green" data-acao="avancarStatus:' + Util.esc(d.id) + '">Avançar status</button>';
        if (d.status === "entregue") acoes += '<button class="btn danger" data-acao="marcarMalha:' + Util.esc(d.id) + '">Caiu na malha</button>';
        acoes += '<button class="btn" data-acao="editar:' + Util.esc(d.id) + '">Editar dados</button>';
      }
      acoes += "</div>";

      return '<div class="page-hd"><div><h1>' + Util.esc(d.nome || "(sem nome)") + '</h1>' +
        '<div class="sub">Declarante IRPF ' + Util.esc(d.ano) + ' · ' + p.ok + '/' + p.total + ' documento(s) recebido(s)</div></div>' +
        '<div>' + statusBadge(d.status) + "</div></div>" +
        acoes +
        '<div class="card"><div class="card-hd"><b>Checklist de documentos</b>' +
        '<span class="chip">' + p.ok + '/' + p.total + '</span></div>' +
        '<div class="card-bd"><ul style="margin:0;padding:0">' + itens + "</ul>" +
        (podeEditar ? '<div class="fld-d" style="margin-top:8px">Clique num item para marcar/desmarcar o recebimento.</div>' : "") +
        "</div></div>" +
        '<div class="card"><div class="card-hd"><b>Ficha do declarante</b></div>' +
        '<div class="card-bd">' + ficha + "</div></div>";
    },

    // Liga o seletor de ano (change -> guarda estado + re-render).
    onMount: function () {
      var self = this, e = UI.el("irpf-ano");
      if (e) e.addEventListener("change", function () { self._ano = e.value; self._aberto = null; App.render(); });
    },

    // ---- Navegação de detalhe ----
    abrir: function (id) { this._aberto = id; App.render(); },
    voltar: function () { this._aberto = null; App.render(); },

    // ---- CRUD ----
    novo: function () {
      if (!Auth.pode("irpf", "criar")) { UI.toast("Sem permissão para cadastrar declarantes.", "erro"); return; }
      this._modal(null);
    },

    editar: function (id) {
      if (!Auth.pode("irpf", "editar")) { UI.toast("Sem permissão para editar declarantes.", "erro"); return; }
      var d = Store.obter("declarantes", id);
      if (!d) { UI.toast("Declarante não encontrado.", "erro"); return; }
      this._modal(d);
    },

    // Modal compartilhado (d=null -> novo). Nome + CPF + perfil + preço + cliente + status.
    _modal: function (d) {
      var novo = !d, self = this;
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));

      var opCli = [{ v: "", t: "— pessoa física avulsa (sem vínculo) —" }];
      for (var i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });

      var perfilSel = d ? d.perfil : "simples";
      var statusSel = d ? d.status : "docs_pendentes";

      var corpo =
        '<div class="row">' +
        UI.campo("Nome do declarante", UI.inp("irpf-nome", d ? d.nome : "", "ex.: João da Silva")) +
        UI.campo("CPF", UI.inp("irpf-cpf", d ? d.cpf : "", "000.000.000-00")) +
        "</div>" +
        '<div class="row">' +
        UI.campo("Perfil", UI.sel("irpf-perfil", PERFIS, perfilSel), "Define o checklist de documentos.") +
        UI.campo("Preço (R$)", UI.inp("irpf-preco", d ? Util.brNum(d.preco, 2) : "", "0,00")) +
        "</div>" +
        UI.campo("Cliente vinculado (opcional)", UI.sel("irpf-cli", opCli, d ? (d.clienteId || "") : ""), "Vincule a um sócio de cliente PJ, se aplicável.") +
        '<div class="row">' +
        UI.campo("Status", UI.sel("irpf-status", STATUS, statusSel)) +
        UI.campo("Nº do recibo (se entregue)", UI.inp("irpf-recibo", d ? (d.reciboNum || "") : "", "recibo de entrega da DIRPF")) +
        "</div>" +
        UI.campo("Observações", UI.inp("irpf-obs", d ? d.obs : "", "ex.: cliente vai trazer informe do banco X")) +
        '<div class="card-bd" style="padding:8px 0"><b class="fld-l">Documentos deste perfil</b>' +
        '<div id="irpf-chk-prev" class="fld-d">' + Util.esc(docsDoPerfil(perfilSel).join(" · ")) + "</div></div>";

      var ov = UI.modal(novo ? "Novo declarante IRPF" : "Editar declarante", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "primary", onClick: function (fechar) {
          if (!Auth.pode("irpf", novo ? "criar" : "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var nome = UI.v("irpf-nome");
          if (!nome) { UI.toast("Informe o nome do declarante.", "alerta"); return; }
          var cpf = Util.soDigitos(UI.v("irpf-cpf"));
          if (cpf && cpf.length !== 11) { UI.toast("CPF deve ter 11 dígitos.", "alerta"); return; }
          var preco = parseValor(UI.v("irpf-preco"));
          if (!(preco >= 0)) { UI.toast("Preço inválido.", "alerta"); return; }
          var perfil = UI.v("irpf-perfil"), status = UI.v("irpf-status"), recibo = UI.v("irpf-recibo");
          if (status === "entregue" && !recibo) { UI.toast("Status “entregue” exige o nº do recibo.", "alerta"); return; }

          var obj = {
            id: d ? d.id : Util.uid("dec"),
            ano: d ? d.ano : Number(self._ano) || anoAtual(),
            nome: nome,
            cpf: cpf,
            clienteId: UI.v("irpf-cli") || null,
            perfil: perfil,
            preco: preco,
            status: status,
            reciboNum: recibo || null,
            // troca de perfil recria a base preservando os "ok" já marcados
            checklist: d ? mesclaChecklist(perfil, d.checklist) : novoChecklist(perfil),
            obs: UI.v("irpf-obs"),
            criadoEm: d ? (d.criadoEm || Util.hojeISO()) : Util.hojeISO()
          };
          Store.salvar("declarantes", obj); // STORAGE_CHEIO -> ui.js mostra toast
          if (global.Audit) global.Audit.log(novo ? "irpf_declarante_criar" : "irpf_declarante_editar", "declarantes", obj.id);
          UI.toast("Declarante salvo.", "ok");
          fechar(); App.render();
        } }
      ]);

      // Preview do checklist ao trocar o perfil (recria a base visível).
      if (ov) {
        var selP = ov.querySelector("#irpf-perfil");
        if (selP) selP.addEventListener("change", function () {
          var prev = ov.querySelector("#irpf-chk-prev");
          if (prev) prev.textContent = docsDoPerfil(selP.value).join(" · ");
        });
      }
    },

    // Marca/desmarca um item do checklist (arg "decId|idx").
    marcarDoc: function (arg) {
      if (!Auth.pode("irpf", "editar")) { UI.toast("Sem permissão para editar o checklist.", "erro"); return; }
      var p = String(arg || "").split("|"), id = p[0], idx = parseInt(p[1], 10);
      var d = Store.obter("declarantes", id);
      if (!d || !d.checklist || !d.checklist[idx]) { UI.toast("Item não encontrado.", "erro"); return; }
      d.checklist[idx].ok = !d.checklist[idx].ok;
      Store.salvar("declarantes", d); // STORAGE_CHEIO -> ui.js mostra toast
      if (global.Audit) global.Audit.log("irpf_marcar_doc", "declarantes", d.id);
      App.render();
    },

    // Avança na esteira: docs_pendentes -> em_elaboracao -> em_conferencia -> entregue.
    // Ao chegar em "entregue", exige o nº do recibo.
    avancarStatus: function (id) {
      if (!Auth.pode("irpf", "editar")) { UI.toast("Sem permissão para movimentar a campanha.", "erro"); return; }
      var d = Store.obter("declarantes", id);
      if (!d) { UI.toast("Declarante não encontrado.", "erro"); return; }
      var i = ESTEIRA.indexOf(d.status);
      if (i < 0) { UI.toast("Status atual não avança na esteira (malha fina é tratada à parte).", "alerta"); return; }
      var prox = ESTEIRA[i + 1];
      if (!prox) { UI.toast("Já está entregue.", "info"); return; }

      if (prox === "entregue") {
        var corpo =
          '<p class="fld-d" style="margin-bottom:14px">' + Util.esc(d.nome) + " — perfil " + Util.esc(perfilInfo(d.perfil).t) + "</p>" +
          UI.campo("Nº do recibo de entrega", UI.inp("irpf-av-recibo", d.reciboNum || "", "recibo da DIRPF"), "Registre o recibo gerado na transmissão.");
        UI.modal("Marcar como entregue", corpo, [
          { txt: "Cancelar" },
          { txt: "Confirmar entrega", classe: "green", onClick: function (fechar) {
            if (!Auth.pode("irpf", "editar")) { UI.toast("Sem permissão.", "erro"); return; }
            var recibo = UI.v("irpf-av-recibo");
            if (!recibo) { UI.toast("Informe o nº do recibo.", "alerta"); return; }
            d.status = "entregue"; d.reciboNum = recibo;
            Store.salvar("declarantes", d);
            if (global.Audit) global.Audit.log("irpf_entregue", "declarantes", d.id);
            UI.toast("Declaração marcada como entregue.", "ok");
            fechar(); App.render();
          } }
        ]);
        return;
      }

      d.status = prox;
      Store.salvar("declarantes", d);
      if (global.Audit) global.Audit.log("irpf_avancar", "declarantes", d.id);
      UI.toast("Avançou para: " + statusInfo(prox).t, "ok");
      App.render();
    },

    // Caiu na malha fina (desvio faturável — regularização é serviço extra).
    marcarMalha: function (id) {
      if (!Auth.pode("irpf", "editar")) { UI.toast("Sem permissão para movimentar a campanha.", "erro"); return; }
      var d = Store.obter("declarantes", id);
      if (!d) { UI.toast("Declarante não encontrado.", "erro"); return; }
      if (d.status === "malha") { UI.toast("Já está marcada como malha fina.", "info"); return; }
      UI.modal("Caiu na malha fina",
        "<p>Marcar a declaração de <b>" + Util.esc(d.nome) + "</b> como <b>malha fina</b>? " +
        "A regularização é um serviço adicional faturável.</p>",
        [{ txt: "Cancelar" }, { txt: "Confirmar", classe: "danger", onClick: function (fechar) {
          if (!Auth.pode("irpf", "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          d.status = "malha";
          Store.salvar("declarantes", d);
          if (global.Audit) global.Audit.log("irpf_malha", "declarantes", d.id);
          UI.toast("Marcada como malha fina — abra a regularização (serviço faturável).", "alerta");
          fechar(); App.render();
        } }]);
    },

    excluir: function (id) {
      if (!Auth.pode("irpf", "excluir")) { UI.toast("Sem permissão para excluir declarantes.", "erro"); return; }
      var d = Store.obter("declarantes", id);
      if (!d) { UI.toast("Declarante não encontrado.", "erro"); return; }
      var self = this;
      UI.modal("Excluir declarante",
        "<p>Excluir <b>" + Util.esc(d.nome || "(sem nome)") + "</b> da campanha IRPF " + Util.esc(d.ano) + "?</p>",
        [{ txt: "Cancelar" }, { txt: "Excluir", classe: "danger", onClick: function (fechar) {
          if (!Auth.pode("irpf", "excluir")) { UI.toast("Sem permissão.", "erro"); return; }
          Store.excluir("declarantes", id);
          if (global.Audit) global.Audit.log("irpf_excluir", "declarantes", id);
          if (self._aberto === id) self._aberto = null;
          UI.toast("Declarante excluído.", "ok");
          fechar(); App.render();
        } }]);
    },

    // ---- BI da campanha (A4, shell da marca) — todo entregável usa _abrirPrint ----
    relatorio: function () {
      var ano = this._ano || String(anoAtual());
      var todos = Store.listar("declarantes").filter(function (d) { return String(d.ano) === String(ano); });
      if (!todos.length) { UI.toast("Sem declarantes em " + ano + " para o BI.", "info"); return; }

      var i, total = todos.length, entregues = 0;
      var receitaPrev = 0, receitaReal = 0, distrib = {};
      for (i = 0; i < STATUS.length; i++) distrib[STATUS[i].v] = 0;
      for (i = 0; i < todos.length; i++) {
        var d = todos[i], pr = Number(d.preco) || 0;
        receitaPrev += pr;
        if (d.status === "entregue") { entregues++; receitaReal += pr; }
        if (distrib[d.status] == null) distrib[d.status] = 0;
        distrib[d.status]++;
      }
      var realiza = receitaPrev ? (receitaReal / receitaPrev) * 100 : 0;
      var ticket = entregues ? (receitaReal / entregues) : 0;

      var resumo = "<h2>Resumo da campanha " + Util.esc(ano) + "</h2><table>" +
        "<tr><th style='width:55%'>Indicador</th><th class='dir'>Valor</th></tr>" +
        "<tr><td>Total de declarantes</td><td class='dir'>" + total + "</td></tr>" +
        "<tr><td>Entregues</td><td class='dir'>" + entregues + "</td></tr>" +
        "<tr><td>Em malha fina</td><td class='dir'>" + (distrib.malha || 0) + "</td></tr>" +
        "<tr><td>Receita prevista (todos os preços)</td><td class='dir'>" + Util.esc(Util.brMoeda(receitaPrev)) + "</td></tr>" +
        "<tr><td>Receita realizada (entregues)</td><td class='dir ok'>" + Util.esc(Util.brMoeda(receitaReal)) + "</td></tr>" +
        "<tr><td>Ticket médio por entrega</td><td class='dir'>" + Util.esc(Util.brMoeda(ticket)) + "</td></tr>" +
        "<tr class='tot'><td>Realização da receita</td><td class='dir'>" + Util.esc(Util.brNum(realiza, 0)) + "%</td></tr>" +
        "</table>";

      var linhas = STATUS.map(function (s) {
        var q = distrib[s.v] || 0, pct = total ? Math.round((q / total) * 100) : 0;
        return "<tr><td>" + Util.esc(s.t) + "</td><td class='dir'>" + q + "</td><td class='dir'>" + pct + "%</td></tr>";
      }).join("");
      var tabStatus = "<h2>Distribuição por status</h2><table>" +
        "<tr><th>Status</th><th class='dir' style='width:20%'>Qtd</th><th class='dir' style='width:20%'>%</th></tr>" +
        linhas +
        "<tr class='tot'><td>Total</td><td class='dir'>" + total + "</td><td class='dir'>100%</td></tr>" +
        "</table>";

      App._abrirPrint("Campanha IRPF " + ano, resumo + tabStatus);
      if (global.Audit) global.Audit.log("irpf_bi", "declarantes", "ano_" + ano);
    }
  });
})(window);
