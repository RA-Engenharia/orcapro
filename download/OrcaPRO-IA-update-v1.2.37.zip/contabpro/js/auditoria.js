/* =====================================================================
 * auditoria.js — Módulo "Auditoria" (seção 3.24). Só sócio/gerente.
 * Painel de Saúde (KPIs de storage) + Alertas de vencimento
 * (certificados/procurações <=60 dias) + Log de auditoria (200 últimos).
 * Também define window.Audit (logger central chamado nas ações críticas).
 * ES5 estrito (só var/function/+). Sem dependências extras.
 * ===================================================================== */
(function (global) {
  "use strict";
  var Store = global.Store, Auth = global.Auth, Util = global.Util, UI = global.UI, App = global.App;

  // ---- Logger central de auditoria (usado por TODOS os módulos) ----
  // Guarda com try/catch: log nunca pode derrubar a ação de negócio.
  global.Audit = {
    log: function (acao, entidade, id) {
      try {
        Store.salvar("auditoria", {
          id: Util.uid("aud"),
          usuarioId: (Auth.usuario() || {}).id || null,
          acao: acao,
          entidade: entidade,
          entidadeId: id || null,
          contexto: null,
          quando: new Date().toISOString()
        });
      } catch (e) { /* silencioso: log não trava fluxo */ }
    }
  };

  // ---- Helpers puros ----
  function nomeCliente(c) {
    return c.razaoSocial || c.nome || c.nomeFantasia || c.fantasia || "(sem nome)";
  }

  // Extrai a data de validade de um cert/procuração (tolerante a variações de campo)
  function validadeDe(obj) {
    if (!obj || typeof obj !== "object") return null;
    return obj.validade || obj.vencimento || obj.validadeISO || null;
  }

  // Rótulo do tipo (ex.: "Certificado A1", "Procuração e-CAC")
  function rotuloTipo(base, obj) {
    var det = obj && (obj.tipo || obj.modelo || obj.nome || obj.orgao || obj.descricao);
    return base + (det ? " " + det : "");
  }

  // Varre todos os clientes -> linhas de certificados/procurações vencendo em <=60 dias.
  function coletarAlertas() {
    var clientes = Store.listar("clientes"), rows = [];
    function empurra(nome, base, obj) {
      var val = validadeDe(obj);
      if (!val) return;
      var d = Util.diasAte(val);
      if (d == null || d > 60) return; // fora da janela (inclui vencidos, que são <=60)
      rows.push({ cliente: nome, tipo: rotuloTipo(base, obj), validade: val, dias: d });
    }
    for (var i = 0; i < clientes.length; i++) {
      var c = clientes[i], nome = nomeCliente(c), j;
      var certs = c.certificados || [];
      for (j = 0; j < certs.length; j++) empurra(nome, "Certificado", certs[j]);
      var procs = c.procuracoes || [];
      for (j = 0; j < procs.length; j++) empurra(nome, "Procuração", procs[j]);
    }
    return Util.ordenaPor(rows, "dias"); // dias crescente (mais urgente primeiro)
  }

  // "vence em" formatado
  function fmtVence(v, row) {
    var d = row.dias, txt;
    if (d < 0) txt = "vencido há " + (-d) + " dia" + (d === -1 ? "" : "s");
    else if (d === 0) txt = "vence hoje";
    else txt = "em " + d + " dia" + (d === 1 ? "" : "s");
    return Util.esc(Util.brData(v) + " (" + txt + ")");
  }

  // badge de severidade por dias restantes
  function fmtBadge(v, row) {
    var d = row.dias, cor, lbl;
    if (d < 0) { cor = "vermelho"; lbl = "Vencido"; }
    else if (d < 7) { cor = "vermelho"; lbl = "Crítico"; }
    else if (d < 30) { cor = "amber"; lbl = "Atenção"; }
    else { cor = "cinza"; lbl = "No prazo"; }
    return UI.badge(lbl, cor);
  }

  // "2026-07-10T13:45:00.000Z" -> "10/07/2026 13:45"
  function fmtQuando(v) {
    if (!v) return "—";
    var s = String(v).split("T"), data = Util.brData(s[0]), hora = (s[1] || "").slice(0, 5);
    return Util.esc(data + (hora ? " " + hora : ""));
  }

  window.AuditoriaView = App.registrar({
    id: "auditoria",
    titulo: "Auditoria",

    render: function () {
      var p = Auth.perfil();
      // Gate duro: só sócio/gerente (nível >= 80). Guard na função, não só ocultar.
      if (!p || p.nivel < 80) {
        return '<div class="page-hd"><div><h1>Auditoria</h1><div class="sub">Painel de saúde, alertas e log</div></div></div>' +
          '<div class="empty">Sem acesso. Este módulo é restrito a sócio/gerente.</div>';
      }

      // ---- 1) Painel de Saúde (KPIs) ----
      var nClientes = Store.listar("clientes").length;
      var nObrig = Store.listar("obrigacoes").length;
      var nDocs = Store.listar("documentos").length;
      var nUsers = Store.listar("usuarios").length;
      var nErros = (Store._erros || []).length;

      function kpi(n, label, cls) {
        return '<div class="kpi ' + (cls || "") + '"><div class="n">' + n + '</div><div class="l">' + Util.esc(label) + '</div></div>';
      }
      var saude = '<div class="grid-kpi">' +
        kpi(nClientes, "Clientes") +
        kpi(nObrig, "Obrigações") +
        kpi(nDocs, "Documentos") +
        kpi(nUsers, "Usuários") +
        kpi(nErros, "Erros de storage", nErros > 0 ? "al" : "ok") +
        '</div>';

      // ---- 2) Alertas de vencimento ----
      var alertas = coletarAlertas();
      var colsAlerta = [
        { k: "cliente", label: "Cliente", fmt: function (v) { return Util.esc(v); } },
        { k: "tipo", label: "Tipo", fmt: function (v) { return Util.esc(v); } },
        { k: "validade", label: "Vence em", fmt: fmtVence },
        { k: "dias", label: "Situação", cls: "ctr", fmt: fmtBadge }
      ];
      var tblAlerta = UI.tabela(colsAlerta, alertas, {
        vazio: "Nenhum certificado ou procuração vence nos próximos 60 dias."
      });
      var badgeAlerta = alertas.length
        ? UI.badge(alertas.length + (alertas.length === 1 ? " alerta" : " alertas"), "vermelho")
        : UI.badge("tudo em dia", "verde");

      // ---- 3) Log de auditoria ----
      var log = Util.ordenaPor(Store.listar("auditoria"), "quando", true); // mais recentes primeiro
      var total = log.length, truncou = total > 200;
      if (truncou) log = log.slice(0, 200);
      var umap = {};
      Store.listar("usuarios").forEach(function (u) { umap[u.id] = u.nome; });

      var colsLog = [
        { k: "quando", label: "Quando", fmt: function (v) { return fmtQuando(v); } },
        { k: "usuarioId", label: "Usuário", fmt: function (v) { return Util.esc(umap[v] || (v ? v : "sistema")); } },
        { k: "acao", label: "Ação", fmt: function (v) { return Util.esc(v || "—"); } },
        {
          k: "entidade", label: "Entidade", fmt: function (v, row) {
            var t = Util.esc(v || "—");
            if (row.entidadeId) t += ' <span class="chip">' + Util.esc(row.entidadeId) + "</span>";
            return t;
          }
        }
      ];
      var tblLog = UI.tabela(colsLog, log, { vazio: "Nenhum evento de auditoria registrado ainda." });
      var avisoTrunc = truncou
        ? '<div class="fld-d" style="padding:10px 14px">Exibindo os 200 eventos mais recentes de ' + total + " registrados.</div>"
        : "";

      // ---- Monta a tela ----
      return '' +
        '<div class="page-hd"><div><h1>Auditoria</h1>' +
        '<div class="sub">Saúde do sistema, alertas de prazo e trilha de eventos</div></div></div>' +

        '<div class="card"><div class="card-hd"><b>Painel de Saúde</b></div>' +
        '<div class="card-bd" style="padding:16px">' + saude + '</div></div>' +

        '<div class="card"><div class="card-hd"><b>Alertas de vencimento</b>' + badgeAlerta + "</div>" +
        '<div class="card-bd">' + tblAlerta + "</div></div>" +

        '<div class="card"><div class="card-hd"><b>Log de auditoria</b>' +
        UI.badge(total + (total === 1 ? " evento" : " eventos"), "azul") + "</div>" +
        '<div class="card-bd">' + tblLog + avisoTrunc + "</div></div>";
    }
  });

})(window);
