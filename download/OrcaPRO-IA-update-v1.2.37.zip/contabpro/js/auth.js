/* =====================================================================
 * auth.js — RBAC do ContabPRO (seção 2). Login + sessão + guards por
 * departamento × módulo × ação. Guard na função, não só ocultar botão.
 * Segregação: analista não vê financeiro; comercial não vê folha.
 * ===================================================================== */
(function (global) {
  "use strict";
  var Store = global.Store, CONFIG = global.CONFIG, Util = global.Util;
  var _sessao = null;

  var Auth = {
    // Semeia um sócio admin no 1º uso (offline, uso solo do escritório)
    bootstrap: function () {
      try {
        var us = Store.listar("usuarios");
        if (!us.length) {
          Store.salvar("usuarios", { id: "u_socio", nome: "Sócio (admin)", perfil: "socio", departamento: null, email: "", carteiraClientes: [], ativo: true });
        }
      } catch (e) { /* storage cheio no boot: não trava a UI; painel de saúde mostra o erro */ }
    },
    usuarios: function () { return Store.listar("usuarios").filter(function (u) { return u.ativo !== false; }); },
    entrar: function (usuarioId) { var u = Store.obter("usuarios", usuarioId); if (!u) return null; _sessao = u; return u; },
    autoEntrar: function () { if (_sessao) return _sessao; var us = Auth.usuarios(); if (us.length === 1) { _sessao = us[0]; } return _sessao; },
    sair: function () { _sessao = null; },
    usuario: function () { return _sessao; },
    perfil: function () { return _sessao ? (CONFIG.perfis[_sessao.perfil] || null) : null; },

    // ---- Permissões ----
    // pode(modulo[, acao]) — respeita módulos do perfil + flags de segregação
    pode: function (modulo, acao) {
      var p = Auth.perfil(); if (!p) return false;
      if (p.modulos !== "*" && p.modulos.indexOf(modulo) < 0) return false;
      // segregação de funções
      if (modulo === "financeiro" && !p.verFinanceiro) return false;
      // comercial: cadastro de clientes é SOMENTE LEITURA (a conversão de lead cria via crm, não por aqui)
      if (modulo === "clientes" && p.soLeituraCadastro && acao && acao !== "ver" && acao !== "exportar") return false;
      // ações destrutivas/críticas só acima de nível 40
      if ((acao === "excluir" || acao === "transmitir") && p.nivel < 50) return false;
      if (acao === "aprovar" && !(p.aprovaDupla || p.nivel >= 100)) return false;
      return true;
    },
    // vê dados de folha? (comercial/financeiro não)
    veFolha: function () { var p = Auth.perfil(); return !!(p && p.verFolha); },
    veFinanceiro: function () { var p = Auth.perfil(); return !!(p && p.verFinanceiro); },
    // filtra clientes que o usuário pode ver (analista = só carteira; demais = todos)
    clientesVisiveis: function (todos) {
      var u = _sessao, p = Auth.perfil(); if (!p) return [];
      if (p.carteira) {
        // fail-closed: analista SEM carteira atribuída não vê nenhum cliente (gerente atribui)
        var ids = (u.carteiraClientes || []);
        var set = {}; ids.forEach(function (id) { set[id] = 1; });
        return todos.filter(function (c) { return set[c.id]; });
      }
      return todos;
    },
    // guard que lança erro (usar em funções críticas, não só esconder botão)
    exigir: function (modulo, acao) { if (!Auth.pode(modulo, acao)) { var e = new Error("Sem permissão: " + modulo + "/" + (acao || "ver")); e.codigo = "SEM_PERMISSAO"; throw e; } return true; }
  };

  global.Auth = Auth;
  if (typeof module !== "undefined" && module.exports) module.exports = Auth;
})(typeof window !== "undefined" ? window : global);
