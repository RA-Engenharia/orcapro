/* =====================================================================
 * store.js — persistência namespaced do ContabPRO.
 * Browser: localStorage (chave "contabpro:<entidade>"). Node: memória (testes).
 * Coleções são arrays de objetos com { id }. Idempotente por id.
 * Migração versionada + validação pós-load (corrompido -> isola + loga, não trava).
 * ===================================================================== */
(function (global) {
  "use strict";
  var NS = "contabpro:";
  var mem = {}; // fallback Node/testes
  var temLS = false;
  try { temLS = (typeof localStorage !== "undefined"); if (temLS) { localStorage.setItem(NS + "__t", "1"); localStorage.removeItem(NS + "__t"); } } catch (e) { temLS = false; }

  function _get(k) { try { return temLS ? localStorage.getItem(NS + k) : (mem[k] == null ? null : mem[k]); } catch (e) { return null; } }
  // Retorna false em falha (quota cheia) — NUNCA finge sucesso.
  function _set(k, v) { try { if (temLS) localStorage.setItem(NS + k, v); else mem[k] = v; return true; } catch (e) { return false; } }
  function _del(k) { try { if (temLS) localStorage.removeItem(NS + k); else delete mem[k]; } catch (e) {} }

  var Store = {
    _erros: [],
    // Lê uma coleção (array). Corrompido -> isola em backup + retorna [] (nunca trava).
    listar: function (entidade) {
      var raw = _get(entidade);
      if (raw == null) return [];
      try { var v = JSON.parse(raw); return Array.isArray(v) ? v : []; }
      catch (e) { _set(entidade + "__corrompido_" + (Store._erros.length), raw); Store._erros.push({ entidade: entidade, quando: (Date.now ? Date.now() : 0), erro: e.message }); return []; }
    },
    // Grava a coleção; em falha (quota cheia) registra e LANÇA — o chamador/App mostra
    // o erro ao usuário em vez de exibir falso "salvo com sucesso" (dado nunca some em silêncio).
    _grava: function (entidade, arr) {
      var ok = _set(entidade, JSON.stringify(arr || []));
      if (!ok) {
        Store._erros.push({ entidade: entidade, quando: (Date.now ? Date.now() : 0), erro: "gravação falhou (armazenamento cheio?)" });
        var e = new Error("Não foi possível gravar '" + entidade + "' — armazenamento cheio. O item NÃO foi salvo. Libere espaço (ex.: exclua documentos grandes do GED).");
        e.codigo = "STORAGE_CHEIO"; throw e;
      }
    },
    obter: function (entidade, id) { var a = Store.listar(entidade); for (var i = 0; i < a.length; i++) if (a[i].id === id) return a[i]; return null; },
    // Salva (upsert por id). Idempotente: mesmo id -> substitui. Retorna o objeto salvo.
    salvar: function (entidade, obj) {
      if (!obj.id) obj.id = (global.Util ? global.Util.uid(entidade) : "id_" + Math.random().toString(36).slice(2));
      var a = Store.listar(entidade), achou = false;
      for (var i = 0; i < a.length; i++) { if (a[i].id === obj.id) { a[i] = obj; achou = true; break; } }
      if (!achou) a.push(obj);
      Store._grava(entidade, a);
      return obj;
    },
    // salva vários (idempotente por id) — para geração em lote de obrigações
    salvarLote: function (entidade, objs) {
      var a = Store.listar(entidade), idx = {};
      for (var i = 0; i < a.length; i++) idx[a[i].id] = i;
      for (var j = 0; j < objs.length; j++) { var o = objs[j]; if (!o.id) o.id = (global.Util ? global.Util.uid(entidade) : "id_" + j); if (idx[o.id] != null) a[idx[o.id]] = o; else { idx[o.id] = a.length; a.push(o); } }
      Store._grava(entidade, a);
      return objs;
    },
    excluir: function (entidade, id) { var a = Store.listar(entidade), out = []; for (var i = 0; i < a.length; i++) if (a[i].id !== id) out.push(a[i]); Store._grava(entidade, out); },
    // consulta por campo === valor
    onde: function (entidade, campo, valor) { var a = Store.listar(entidade), out = []; for (var i = 0; i < a.length; i++) if (a[i][campo] === valor) out.push(a[i]); return out; },
    // meta (schema version etc.)
    meta: function (k, v) { if (arguments.length === 2) { _set("__meta_" + k, JSON.stringify(v)); return v; } var r = _get("__meta_" + k); try { return r == null ? null : JSON.parse(r); } catch (e) { return null; } },
    limparTudo: function () { mem = {}; if (temLS) { try { var rm = []; for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k && k.indexOf(NS) === 0) rm.push(k); } for (var j = 0; j < rm.length; j++) localStorage.removeItem(rm[j]); } catch (e) {} } }
  };

  global.Store = Store;
  if (typeof module !== "undefined" && module.exports) { global.Util = global.Util || require("./util.js"); module.exports = Store; }
})(typeof window !== "undefined" ? window : global);
