/* =====================================================================
 * certidoes.js — Certidões e Regularidade (seção 3.9).
 * App OFFLINE: NÃO há robô de emissão. Este módulo é o CONTROLE/registro
 * MANUAL das certidões, com alerta de validade e o alerta crítico
 * "positivou" (certidão POSITIVA = cliente irregular).
 * Registrada como id "certidoes" (bate com CONFIG.modulos e Auth.pode).
 * Coleção nova: "certidoes" = { id, clienteId, tipo, resultado,
 *   emissao(ISO), validade(ISO), obs, criadoEm }.
 * ES5 estrito (var/function/concat). Orquestra Store + Auth + UI + App.
 * ===================================================================== */
(function (global) {
  "use strict";
  var Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  // ---------- Tabelas de domínio ----------
  var TIPOS = [
    { v: "cnd_federal", t: "CND Federal/Previdenciária" },
    { v: "crf_fgts", t: "CRF FGTS" },
    { v: "cndt", t: "CNDT (trabalhista)" },
    { v: "estadual", t: "Estadual" },
    { v: "municipal", t: "Municipal" },
    { v: "simples", t: "Regularidade do Simples" }
  ];
  var RESULTADOS = [
    { v: "negativa", t: "Negativa (regular)" },
    { v: "positiva", t: "Positiva (irregular)" },
    { v: "positiva_efeito_negativa", t: "Positiva com efeito de negativa" }
  ];

  // ---------- Helpers puros (closure do módulo) ----------

  // Padrão de nome entre telas; null-safe (cliente pode ter sido excluído).
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(cliente excluído)"; }
  function idUsuario() { var u = Auth.usuario(); return u ? u.id : null; }

  function tipoLabel(tipo) { for (var i = 0; i < TIPOS.length; i++) if (TIPOS[i].v === tipo) return TIPOS[i].t; return tipo || "—"; }

  // Badge do resultado da certidão (o que importa é a POSITIVA em vermelho).
  function resultadoBadge(r) {
    if (r === "positiva") return UI.badge("POSITIVA ⚠", "vermelho");
    if (r === "positiva_efeito_negativa") return UI.badge("Positiva c/ efeito negativa", "amber");
    return UI.badge("Negativa", "verde");
  }

  // Célula "Validade": data + badge de dias (vencida vermelho / <=30d âmbar).
  function validadeCel(c) {
    var txt = '<span style="white-space:nowrap">' + Util.esc(Util.brData(c.validade)) + "</span>";
    if (!c.validade) return txt;
    var d = Util.diasAte(c.validade);
    if (d == null) return txt;
    if (d < 0) return txt + " " + UI.badge((-d) + "d vencida", "vermelho");
    if (d === 0) return txt + " " + UI.badge("vence hoje", "amber");
    if (d <= 30) return txt + " " + UI.badge("em " + d + "d", "amber");
    return txt;
  }

  // Está vencida? (tem validade e já passou)
  function vencida(c) { if (!c.validade) return false; var d = Util.diasAte(c.validade); return d != null && d < 0; }
  // Vence nos próximos 30 dias (inclusive hoje) e ainda não venceu.
  function vencendo30(c) { if (!c.validade) return false; var d = Util.diasAte(c.validade); return d != null && d >= 0 && d <= 30; }

  // Peso de gravidade de UMA certidão (p/ o semáforo por cliente).
  // 3 irregular (positiva) > 2 vencida > 1 regular. Positiva-c/-efeito-negativa vale como regular.
  function pesoCert(c) {
    if (c.resultado === "positiva") return 3;
    if (vencida(c)) return 2;
    return 1;
  }

  // Pior status entre as certidões MAIS RECENTES por tipo de um cliente.
  // Retorna {peso, badge}. 0 = sem registro.
  function statusRegularidade(certs) {
    var byTipo = {}, i, c, ex;
    for (i = 0; i < certs.length; i++) {
      c = certs[i]; ex = byTipo[c.tipo];
      // mais recente por emissão (fallback: validade)
      if (!ex || String(c.emissao || c.validade || "") > String(ex.emissao || ex.validade || "")) byTipo[c.tipo] = c;
    }
    var pior = 0, k;
    for (k in byTipo) if (byTipo.hasOwnProperty(k)) { var p = pesoCert(byTipo[k]); if (p > pior) pior = p; }
    if (pior === 3) return { peso: 3, badge: UI.badge("Irregular", "vermelho") };
    if (pior === 2) return { peso: 2, badge: UI.badge("Certidão vencida", "amber") };
    if (pior === 1) return { peso: 1, badge: UI.badge("Regular", "verde") };
    return { peso: 0, badge: UI.badge("Sem registro", "cinza") };
  }

  // Já existe tarefa de regularização deste cliente/título no mês corrente?
  // Idempotência por título + cliente + mês (evita enxurrada ao reeditar a certidão).
  function jaTemTarefa(clienteId, titulo) {
    var mes = Util.hojeISO().slice(0, 7);
    var ts = Store.onde("tarefas", "clienteId", clienteId);
    for (var i = 0; i < ts.length; i++) {
      if (ts[i].titulo === titulo && String(ts[i].criadoEm || "").slice(0, 7) === mes) return true;
    }
    return false;
  }

  // ---------- View ----------
  global.CertidoesView = App.registrar({
    id: "certidoes",
    titulo: "Certidões",

    render: function () {
      if (!this._filtros) this._filtros = { cliente: "", tipo: "" };
      var f = this._filtros;
      // filtro fantasma: cliente filtrado foi excluído -> volta pra "todos"
      if (f.cliente && !Store.obter("clientes", f.cliente)) f.cliente = "";

      // Clientes visíveis (respeita carteira do analista).
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      var setVis = {}, nomeCli = {}, i;
      for (i = 0; i < visiveis.length; i++) { setVis[visiveis[i].id] = 1; nomeCli[visiveis[i].id] = nomeCliente(visiveis[i]); }
      function nomeDe(id) { return nomeCli[id] || "(cliente excluído)"; }

      // Certidões só de clientes visíveis.
      var todas = Store.listar("certidoes"), visCert = [];
      for (i = 0; i < todas.length; i++) if (setVis[todas[i].clienteId]) visCert.push(todas[i]);

      // Aplica filtros (para a tabela e KPIs).
      var linhas = visCert.filter(function (c) {
        if (f.cliente && c.clienteId !== f.cliente) return false;
        if (f.tipo && c.tipo !== f.tipo) return false;
        return true;
      });
      linhas = Util.ordenaPor(linhas, "validade");

      // ---- KPIs (sobre o conjunto filtrado) ----
      var nValidas = 0, nVenc30 = 0, nVencidas = 0, nPositivas = 0;
      linhas.forEach(function (c) {
        if (c.validade && !vencida(c)) nValidas++;
        if (vencendo30(c)) nVenc30++;
        if (vencida(c)) nVencidas++;
        if (c.resultado === "positiva") nPositivas++;
      });

      var kpis = '<div class="grid-kpi">' +
        '<div class="kpi ok"><div class="n">' + nValidas + '</div><div class="l">Certidões válidas</div></div>' +
        '<div class="kpi ' + (nVenc30 ? "wr" : "") + '"><div class="n">' + nVenc30 + '</div><div class="l">Vencendo em 30 dias</div></div>' +
        '<div class="kpi ' + (nVencidas ? "al" : "") + '"><div class="n">' + nVencidas + '</div><div class="l">Vencidas</div></div>' +
        '<div class="kpi ' + (nPositivas ? "al" : "") + '"><div class="n">' + nPositivas + '</div><div class="l">Positivas (irregular)</div></div>' +
        "</div>";

      // ---- Toolbar: filtros + registrar ----
      var opCli = [{ v: "", t: "Todos os clientes" }];
      for (i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });
      var opTipo = [{ v: "", t: "Todos os tipos" }];
      for (i = 0; i < TIPOS.length; i++) opTipo.push(TIPOS[i]);

      var podeCriar = Auth.pode("certidoes", "criar");
      var toolbar = '<div class="toolbar">' +
        UI.sel("cert-f-cli", opCli, f.cliente) +
        UI.sel("cert-f-tipo", opTipo, f.tipo) +
        (podeCriar ? '<button class="btn primary" data-acao="registrar">' + UI.icone("plus", 16) + ' Registrar certidão</button>' : "") +
        "</div>";

      // ---- Card 1: Situação de regularidade (semáforo por cliente visível) ----
      var semaf = visiveis.map(function (cl) {
        var certs = [];
        for (var j = 0; j < visCert.length; j++) if (visCert[j].clienteId === cl.id) certs.push(visCert[j]);
        var st = statusRegularidade(certs);
        return { _nome: nomeCliente(cl), _peso: st.peso, _badge: st.badge, _n: certs.length };
      });
      // pior primeiro (irregular no topo), depois por nome
      semaf.sort(function (a, b) { if (a._peso !== b._peso) return b._peso - a._peso; return a._nome < b._nome ? -1 : (a._nome > b._nome ? 1 : 0); });
      var colsSem = [
        { k: "_nome", label: "Cliente", fmt: function (v) { return Util.esc(v); } },
        { k: "_badge", label: "Situação", fmt: function (v) { return v; } },
        { k: "_n", label: "Certidões", cls: "ctr", fmt: function (v) { return Util.esc(v || 0); } }
      ];
      var tblSem = UI.tabela(colsSem, semaf, { vazio: "Nenhum cliente visível." });

      // ---- Card 2: Certidões registradas ----
      var rows = linhas.map(function (c) {
        return { _cli: nomeDe(c.clienteId), tipo: c.tipo, resultado: c.resultado, emissao: c.emissao, validade: c.validade, _cert: c };
      });
      var cols = [
        { k: "_cli", label: "Cliente", fmt: function (v) { return Util.esc(v); } },
        { k: "tipo", label: "Tipo", fmt: function (v) { return UI.badge(tipoLabel(v), "azul"); } },
        { k: "resultado", label: "Resultado", fmt: function (v) { return resultadoBadge(v); } },
        { k: "emissao", label: "Emissão", fmt: function (v) { return '<span style="white-space:nowrap">' + Util.esc(Util.brData(v)) + "</span>"; } },
        { k: "validade", label: "Validade", fmt: function (v, row) { return validadeCel(row._cert); } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) {
          var out = '<button class="btn sm" data-acao="editar:' + Util.esc(row._cert.id) + '">Editar</button> ';
          out += '<button class="btn sm" data-acao="imprimir:' + Util.esc(row._cert.id) + '">🖨 Comprovante</button>';
          if (Auth.pode("certidoes", "excluir")) out += ' <button class="btn sm danger" data-acao="excluir:' + Util.esc(row._cert.id) + '">✕</button>';
          return out;
        } }
      ];
      var tbl = UI.tabela(cols, rows, { vazio: "Nenhuma certidão registrada para os filtros atuais." });

      var aviso = podeCriar ? "" : '<span class="chip">Somente leitura: seu perfil não registra certidões</span>';

      return '<div class="page-hd"><div><h1>Certidões e Regularidade</h1>' +
        '<div class="sub">Controle manual das certidões — validade, vencimento e o alerta crítico de certidão positiva.</div></div>' +
        '<div>' + aviso + "</div></div>" +
        kpis + toolbar +
        '<div class="card"><div class="card-hd"><b>Situação de regularidade</b>' +
        '<span class="chip">' + semaf.length + ' cliente(s)</span></div>' +
        '<div class="card-bd">' + tblSem + "</div></div>" +
        '<div class="card"><div class="card-hd"><b>Certidões registradas</b>' +
        '<span class="chip">' + linhas.length + ' item(ns)</span></div>' +
        '<div class="card-bd">' + tbl + "</div></div>";
    },

    // Liga os filtros (change -> guarda estado + re-render).
    onMount: function () {
      var self = this, map = [["cert-f-cli", "cliente"], ["cert-f-tipo", "tipo"]];
      map.forEach(function (par) {
        var e = UI.el(par[0]);
        if (e) e.addEventListener("change", function () { self._filtros[par[1]] = e.value; App.render(); });
      });
    },

    // ---- Ações ----

    registrar: function () {
      if (!Auth.pode("certidoes", "criar")) { UI.toast("Sem permissão para registrar certidões.", "erro"); return; }
      this._modalCertidao(null);
    },

    editar: function (id) {
      if (!Auth.pode("certidoes", "editar")) { UI.toast("Sem permissão para editar certidões.", "erro"); return; }
      var c = Store.obter("certidoes", id);
      if (!c) { UI.toast("Certidão não encontrada.", "erro"); return; }
      this._modalCertidao(c);
    },

    // Modal compartilhado (cert=null -> novo). Cliente + tipo + resultado + emissão + validade + obs.
    _modalCertidao: function (cert) {
      var novo = !cert;
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));
      if (novo && !visiveis.length) { UI.toast("Cadastre um cliente antes de registrar certidões.", "info"); return; }

      var opCli = [{ v: "", t: "— selecione o cliente —" }];
      for (var i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });

      var hoje = Util.hojeISO();
      var corpo =
        UI.campo("Cliente", UI.sel("cert-cli", opCli, cert ? cert.clienteId : "")) +
        '<div class="row">' +
        UI.campo("Tipo de certidão", UI.sel("cert-tipo", TIPOS, cert ? cert.tipo : "cnd_federal")) +
        UI.campo("Resultado", UI.sel("cert-res", RESULTADOS, cert ? cert.resultado : "negativa")) +
        "</div>" +
        '<div class="row">' +
        UI.campo("Emissão", UI.inp("cert-emissao", cert ? cert.emissao : hoje, "", "date")) +
        UI.campo("Validade", UI.inp("cert-validade", cert ? cert.validade : "", "", "date")) +
        "</div>" +
        UI.campo("Observações", UI.inp("cert-obs", cert ? cert.obs : "", "ex.: nº do protocolo / pendência que motivou a positiva")) +
        '<div class="fld-d">Certidão positiva gera alerta crítico e abre tarefa de regularização automaticamente.</div>';

      var self = this;
      UI.modal(novo ? "Registrar certidão" : "Editar certidão", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "primary", onClick: function (fechar) {
          if (!Auth.pode("certidoes", novo ? "criar" : "editar")) { UI.toast("Sem permissão.", "erro"); return; }
          var clienteId = UI.v("cert-cli");
          if (!clienteId) { UI.toast("Selecione o cliente.", "alerta"); return; }
          var emissao = UI.v("cert-emissao"), validade = UI.v("cert-validade");
          if (!emissao) { UI.toast("Informe a data de emissão.", "alerta"); return; }
          if (!validade) { UI.toast("Informe a data de validade.", "alerta"); return; }
          if (validade < emissao) { UI.toast("A validade não pode ser anterior à emissão.", "alerta"); return; }
          var tipo = UI.v("cert-tipo"), resultado = UI.v("cert-res");
          var obj = {
            id: cert ? cert.id : Util.uid("cert"),
            clienteId: clienteId,
            tipo: tipo,
            resultado: resultado,
            emissao: emissao,
            validade: validade,
            obs: UI.v("cert-obs"),
            criadoEm: cert ? (cert.criadoEm || Util.hojeISO()) : Util.hojeISO()
          };
          Store.salvar("certidoes", obj); // STORAGE_CHEIO -> ui.js mostra toast
          if (global.Audit) global.Audit.log("registrou_certidao", "certidoes", obj.id);

          // Alerta crítico + tarefa de regularização quando a certidão positivou.
          if (resultado === "positiva") self._tratarPositiva(clienteId, tipo);

          UI.toast("Certidão salva.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    // Dispara o alerta vermelho e cria a tarefa de regularização (idempotente).
    _tratarPositiva: function (clienteId, tipo) {
      var cli = Store.obter("clientes", clienteId), nome = nomeCliente(cli);
      UI.toast("⚠ Certidão POSITIVA de " + nome + " — regularização necessária", "erro");
      var titulo = "Regularizar " + tipoLabel(tipo) + " (certidão positiva)";
      if (jaTemTarefa(clienteId, titulo)) return; // idempotente por título+cliente+mês
      var tar = {
        id: Util.uid("tar"),
        clienteId: clienteId,
        titulo: titulo,
        origem: "robo",
        status: "pendente",
        prazo: Util.somaDias(Util.hojeISO(), 7),
        criadoEm: Util.hojeISO()
      };
      Store.salvar("tarefas", tar); // STORAGE_CHEIO -> ui.js mostra toast
      if (global.Audit) global.Audit.log("tarefa_regularizacao_certidao", "tarefas", tar.id);
    },

    excluir: function (id) {
      if (!Auth.pode("certidoes", "excluir")) { UI.toast("Sem permissão para excluir certidões.", "erro"); return; }
      var c = Store.obter("certidoes", id);
      if (!c) { UI.toast("Certidão não encontrada.", "erro"); return; }
      var cli = Store.obter("clientes", c.clienteId);
      UI.modal("Excluir certidão",
        "<p>Excluir a certidão <b>" + Util.esc(tipoLabel(c.tipo)) + "</b> de <b>" + Util.esc(nomeCliente(cli)) +
        "</b> (emissão " + Util.esc(Util.brData(c.emissao)) + ")?</p>",
        [{ txt: "Cancelar" }, { txt: "Excluir", classe: "danger", onClick: function (fechar) {
          if (!Auth.pode("certidoes", "excluir")) { UI.toast("Sem permissão.", "erro"); return; }
          Store.excluir("certidoes", id);
          if (global.Audit) global.Audit.log("excluir_certidao", "certidoes", id);
          UI.toast("Certidão excluída.", "ok");
          fechar(); App.render();
        } }]);
    },

    // Comprovante impresso (A4, shell da marca) — todo entregável usa _abrirPrint.
    imprimir: function (id) {
      var c = Store.obter("certidoes", id);
      if (!c) { UI.toast("Certidão não encontrada.", "erro"); return; }
      var cli = Store.obter("clientes", c.clienteId); // null-safe
      var resTxt, resCls = "";
      if (c.resultado === "positiva") { resTxt = "POSITIVA (irregular)"; resCls = "al"; }
      else if (c.resultado === "positiva_efeito_negativa") { resTxt = "Positiva com efeito de negativa"; }
      else { resTxt = "Negativa (regular)"; resCls = "ok"; }
      var vencTxt;
      if (vencida(c)) vencTxt = '<span class="al">VENCIDA em ' + Util.esc(Util.brData(c.validade)) + "</span>";
      else vencTxt = Util.esc(Util.brData(c.validade));

      var corpo =
        "<h2>Comprovante de certidão</h2>" +
        "<table>" +
        "<tr><th style='width:30%'>Escritório</th><td>" + Util.esc(global.CONFIG.marca.nome) + " · " + Util.esc(global.CONFIG.marca.slogan) + "</td></tr>" +
        "<tr><th>Cliente</th><td>" + Util.esc(nomeCliente(cli)) + "</td></tr>" +
        (cli && cli.cnpj ? "<tr><th>CNPJ</th><td>" + Util.esc(Util.formataCNPJ(cli.cnpj)) + "</td></tr>" : "") +
        "<tr><th>Tipo</th><td>" + Util.esc(tipoLabel(c.tipo)) + "</td></tr>" +
        "<tr><th>Resultado</th><td class='" + resCls + "'>" + Util.esc(resTxt) + "</td></tr>" +
        "<tr><th>Emissão</th><td>" + Util.esc(Util.brData(c.emissao)) + "</td></tr>" +
        "<tr><th>Validade</th><td>" + vencTxt + "</td></tr>" +
        (c.obs ? "<tr><th>Observações</th><td>" + Util.esc(c.obs) + "</td></tr>" : "") +
        "</table>" +
        "<p style='margin-top:16px;color:#64748b;font-size:11px'>Documento de controle interno do escritório. Não substitui a certidão oficial emitida pelo órgão competente.</p>";

      App._abrirPrint("Comprovante de Certidão", corpo);
      if (global.Audit) global.Audit.log("certidao_imprimir", "certidoes", c.id);
    }
  });
})(window);
