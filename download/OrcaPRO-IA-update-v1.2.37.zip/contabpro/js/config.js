/* =====================================================================
 * ContabPRO — Gestão para Escritório de Contabilidade
 * config.js — marca, versão, perfis RBAC e registro de módulos (Fase 1 MVP).
 * White-label friendly: mude a marca em um lugar só.
 * ===================================================================== */
(function (global) {
  "use strict";

  var CONFIG = {
    marca: {
      nome: "ContabPRO",
      slogan: "Gestão para Escritório de Contabilidade",
      fabricante: "RA Engenharia",
      corPrimaria: "#0f2740",   // navy
      corSecundaria: "#2e6f9e", // aço
      corAcento: "#16a34a",     // verde
      corAlerta: "#dc2626",     // vermelho (prazo/risco)
      corAmbar: "#f59e0b"       // âmbar (atenção)
    },
    versao: "2.0.0",
    fase: 1,
    schemaVersao: 1,

    // ---- Perfis RBAC (seção 2) — permissão por departamento × módulo × ação ----
    // acoes: ver, criar, editar, excluir, exportar, aprovar, transmitir
    perfis: {
      socio:      { nome: "Sócio/Diretor",        nivel: 100, deptos: "*", modulos: "*", verFinanceiro: true, verFolha: true },
      gerente:    { nome: "Gerente de Departamento", nivel: 80, deptos: "*", modulos: ["clientes","obrigacoes","tarefas","ged","auditoria","onboarding","timeline","pessoal","societario","certidoes","debitos","creditos","defesas","irpf","bi","radar","wiki"], verFinanceiro: false, verFolha: true, aprovaDupla: true },
      analista:   { nome: "Analista",              nivel: 50, deptos: ["fiscal","contabil","pessoal","societario"], modulos: ["clientes","obrigacoes","tarefas","ged","onboarding","timeline","pessoal","societario","certidoes","debitos","creditos","defesas","irpf","radar","wiki"], verFinanceiro: false, verFolha: true, carteira: true },
      financeiro: { nome: "Financeiro interno",    nivel: 50, deptos: ["financeiro"], modulos: ["financeiro","clientes"], verFinanceiro: true, verFolha: false, semOperacional: true },
      comercial:  { nome: "Comercial",             nivel: 40, deptos: ["comercial"], modulos: ["crm","clientes"], verFinanceiro: false, verFolha: false, soLeituraCadastro: true },
      recepcao:   { nome: "Recepção/Triagem",      nivel: 30, deptos: ["recepcao"], modulos: ["ged","tarefas"], verFinanceiro: false, verFolha: false }
    },

    // Departamentos (seção 3)
    departamentos: [
      { id: "fiscal",     nome: "Fiscal" },
      { id: "contabil",   nome: "Contábil" },
      { id: "pessoal",    nome: "Departamento Pessoal" },
      { id: "societario", nome: "Societário/Legalização" },
      { id: "financeiro", nome: "Financeiro do Escritório" },
      { id: "comercial",  nome: "Comercial" },
      { id: "recepcao",   nome: "Recepção" }
    ],

    // ---- Módulos (Fase 1 + Fase 2 do roadmap seção 8) ----
    modulos: [
      { id: "dashboard",  nome: "Torre de Controle", icone: "grid",   depto: null },
      { id: "crm",        nome: "CRM & Propostas",   icone: "trend",  depto: "comercial" },
      { id: "clientes",   nome: "Clientes",          icone: "users",  depto: null },
      { id: "onboarding", nome: "Onboarding",        icone: "flag",   depto: null },
      { id: "obrigacoes", nome: "Agenda de Obrigações", icone: "calendar", depto: null },
      { id: "pessoal",    nome: "Depto. Pessoal",     icone: "users",  depto: "pessoal" },
      { id: "societario", nome: "Societário",         icone: "folder", depto: "societario" },
      { id: "certidoes",  nome: "Certidões",          icone: "shield", depto: null },
      { id: "debitos",    nome: "Débitos & Parcelamentos", icone: "alert", depto: "fiscal" },
      { id: "creditos",   nome: "Recuperação de Créditos", icone: "trend", depto: "fiscal" },
      { id: "defesas",    nome: "Defesas & Processos", icone: "shield", depto: "fiscal" },
      { id: "irpf",       nome: "Campanha IRPF",      icone: "money",  depto: null },
      { id: "tarefas",    nome: "Tarefas",           icone: "check",  depto: null },
      { id: "ged",        nome: "Documentos (GED)",  icone: "folder", depto: null },
      { id: "timeline",   nome: "Timeline & Entregas", icone: "clock", depto: null },
      { id: "financeiro", nome: "Honorários",        icone: "money",  depto: "financeiro" },
      { id: "bi",         nome: "BI & Rentabilidade", icone: "trend", depto: null, soPerfil: ["socio", "gerente"] },
      { id: "radar",      nome: "Radar & Planejamento", icone: "alert", depto: null },
      { id: "wiki",       nome: "Base de Conhecimento", icone: "folder", depto: null },
      { id: "auditoria",  nome: "Auditoria",         icone: "shield", depto: null, soPerfil: ["socio", "gerente"] },
      { id: "config",     nome: "Configurações",     icone: "grid",   depto: null, soPerfil: ["socio"] }
    ],

    // Regimes tributários (seção 3.2) com pontos de complexidade (seção 5)
    regimes: [
      { id: "MEI",       nome: "MEI",                 pontos: 1 },
      { id: "Simples",   nome: "Simples Nacional",    pontos: 3 },
      { id: "Presumido", nome: "Lucro Presumido",     pontos: 6 },
      { id: "Real",      nome: "Lucro Real",          pontos: 12 },
      { id: "Imune",     nome: "Imune/Isenta",        pontos: 4 }
    ],

    // Segmentos (seção 3.2 / 3.4.2) — cada um dispara obrigações extras na matriz
    segmentos: [
      { id: "comercio",     nome: "Comércio" },
      { id: "industria",    nome: "Indústria" },
      { id: "servicos",     nome: "Serviços" },
      { id: "imobiliaria",  nome: "Imobiliária/Administradora" },
      { id: "saude",        nome: "Saúde (clínicas/planos)" },
      { id: "cartorio",     nome: "Cartório" },
      { id: "financeira",   nome: "Instituição financeira/factoring" },
      { id: "rural",        nome: "Produtor rural" },
      { id: "construcao",   nome: "Construção civil" },
      { id: "condominio",   nome: "Condomínio" },
      { id: "terceirosetor",nome: "Terceiro setor" },
      { id: "domestico",    nome: "Empregador doméstico (PF)" },
      { id: "holding",      nome: "Holding patrimonial" },
      { id: "cooperativa",  nome: "Cooperativa" }
    ],

    // Status do cliente (seção 3.2)
    statusCliente: ["prospect", "ativo", "suspenso", "em_saida", "encerrado"],

    // Pontos de precificação (seção 5) — editável pelo escritório
    precificacao: {
      valorPonto: 45.0,
      pontosPorFaixaFuncionarios: 1, faixaFuncionarios: 5,
      pontosPorFaixaNotas: 1, faixaNotas: 50,
      pontosFilialOuIE: 2, pontosComExterior: 4, pontosParcelamento: 2,
      pontosSegmento: { imobiliaria: 2, saude: 3, cartorio: 3, financeira: 6, rural: 4, construcao: 4, condominio: 3, terceirosetor: 4, holding: 3, cooperativa: 4, domestico: 2 }
    },

    matrizArquivo: "data/matriz-obrigacoes.json",

    // Dupla conferência (4 olhos, seção 3.22) — CONFIGURÁVEL pelo escritório.
    // ativa=false desliga; criticas = códigos de obrigação que exigem 2º analista.
    // Em escritório SOLO (1 usuário) a conferência é dispensada automaticamente (auditado).
    duplaConferencia: { ativa: true, criticas: ["ECF", "ECD", "DCTFWeb", "DCTFWeb-Folha", "EFD-Contribuicoes", "eSocial", "DEFIS"] }
  };

  // ---- Pontos de complexidade (seção 5) — MESMA régua p/ honorário e capacidade ----
  // clienteLike: { regime|regimeTributario, funcionarios, notasMes?, segmento[], inscricoes[], filiais[], parcelamentoAtivo? }
  CONFIG.calcPontos = function (c) {
    c = c || {};
    var pr = CONFIG.precificacao, pts = 0, i;
    var reg = c.regime;
    if (!reg && c.regimeTributario) {
      var h = c.regimeTributario;
      if (typeof h === "string") reg = h;
      else if (h.length) reg = h[h.length - 1].regime;
    }
    for (i = 0; i < CONFIG.regimes.length; i++) if (CONFIG.regimes[i].id === reg) pts += CONFIG.regimes[i].pontos;
    pts += Math.floor((c.funcionarios || 0) / (pr.faixaFuncionarios || 5)) * (pr.pontosPorFaixaFuncionarios || 1);
    pts += Math.floor((c.notasMes || 0) / (pr.faixaNotas || 50)) * (pr.pontosPorFaixaNotas || 1);
    var segs = c.segmento || [];
    for (i = 0; i < segs.length; i++) pts += pr.pontosSegmento[segs[i]] || 0;
    var nFil = (c.filiais || []).length; var temIE = false;
    var ins = c.inscricoes || []; for (i = 0; i < ins.length; i++) if (ins[i].tipo === "estadual") temIE = true;
    if (nFil || temIE) pts += (pr.pontosFilialOuIE || 2) * Math.max(1, nFil);
    if (c.comExterior) pts += pr.pontosComExterior || 4;
    if (c.parcelamentoAtivo) pts += pr.pontosParcelamento || 2;
    return pts;
  };
  CONFIG.honorarioSugerido = function (c) { return CONFIG.calcPontos(c) * (CONFIG.precificacao.valorPonto || 0); };

  global.CONFIG = CONFIG;
})(window);
