/* =====================================================================
 * util.js — helpers puros do ContabPRO (número/data BR, ids, datas, guards).
 * Sem dependências. Usável no navegador e no Node (module.exports no fim).
 * ===================================================================== */
(function (global) {
  "use strict";
  var MESES = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];

  var Util = {
    // ---- IDs ----
    uid: function (pref) {
      var t = (typeof Date !== "undefined" && Date.now) ? Date.now().toString(36) : "0";
      var r = Math.floor(Math.random() * 1e9).toString(36);
      return (pref || "id") + "_" + t + r;
    },

    // ---- Número / moeda BR ----
    brNum: function (n, casas) { casas = casas == null ? 2 : casas; var v = Number(n) || 0; return v.toLocaleString("pt-BR", { minimumFractionDigits: casas, maximumFractionDigits: casas }); },
    brMoeda: function (n) { return "R$ " + Util.brNum(n, 2); },
    parseBR: function (s) { if (typeof s === "number") return s; if (!s) return 0; return Number(String(s).replace(/\./g, "").replace(",", ".").replace(/[^0-9.\-]/g, "")) || 0; },

    // ---- Datas (ISO yyyy-mm-dd, sempre em componentes p/ evitar fuso) ----
    hojeISO: function () { var d = new Date(); return Util.iso(d.getFullYear(), d.getMonth() + 1, d.getDate()); },
    iso: function (y, m, d) { return y + "-" + Util.pad(m) + "-" + Util.pad(d); },
    pad: function (n) { n = String(n); return n.length < 2 ? "0" + n : n; },
    // parse "yyyy-mm-dd" -> {y,m,d} sem Date (evita fuso)
    partes: function (isoStr) { var p = String(isoStr || "").split("-"); return { y: +p[0] || 0, m: +p[1] || 0, d: +p[2] || 0 }; },
    brData: function (isoStr) { if (!isoStr) return "—"; var p = Util.partes(isoStr); if (!p.y) return "—"; return Util.pad(p.d) + "/" + Util.pad(p.m) + "/" + p.y; },
    mesNome: function (m) { return MESES[(m - 1) % 12] || ""; },
    competencia: function (ano, mes) { return ano + "-" + Util.pad(mes); }, // "2026-07"
    // dias entre hoje e um ISO (positivo = futuro)
    diasAte: function (isoStr) {
      var p = Util.partes(isoStr); if (!p.y) return null;
      var alvo = Date.UTC(p.y, p.m - 1, p.d);
      var h = new Date(); var hoje = Date.UTC(h.getFullYear(), h.getMonth(), h.getDate());
      return Math.round((alvo - hoje) / 86400000);
    },
    // dia da semana (0=dom..6=sab) de um ISO, via UTC (sem fuso)
    diaSemana: function (isoStr) { var p = Util.partes(isoStr); return new Date(Date.UTC(p.y, p.m - 1, p.d)).getUTCDay(); },
    // último dia do mês
    ultimoDia: function (ano, mes) { return new Date(Date.UTC(ano, mes, 0)).getUTCDate(); },
    // soma dias a um ISO (via UTC) -> ISO
    somaDias: function (isoStr, n) { var p = Util.partes(isoStr); var d = new Date(Date.UTC(p.y, p.m - 1, p.d + n)); return Util.iso(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate()); },

    // ---- HTML ----
    esc: function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); },

    // ---- Documentos BR ----
    formataCNPJ: function (v) { var d = String(v || "").replace(/\D/g, "").slice(0, 14); if (d.length !== 14) return v || ""; return d.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5"); },
    formataCPF: function (v) { var d = String(v || "").replace(/\D/g, "").slice(0, 11); if (d.length !== 11) return v || ""; return d.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, "$1.$2.$3-$4"); },
    soDigitos: function (v) { return String(v || "").replace(/\D/g, ""); },
    validaCNPJ: function (v) { var s = Util.soDigitos(v); if (s.length !== 14 || /^(\d)\1+$/.test(s)) return false; function calc(base) { var t = base.length - 7, sum = 0; for (var i = base.length; i >= 1; i--) { sum += base.charAt(base.length - i) * t--; if (t < 2) t = 9; } var r = sum % 11; return r < 2 ? 0 : 11 - r; } var b = s.slice(0, 12); var d1 = calc(b); var d2 = calc(b + d1); return s === b + "" + d1 + "" + d2; },

    clone: function (o) { return JSON.parse(JSON.stringify(o)); },
    // ordena por campo (string/num), estável
    ordenaPor: function (arr, campo, desc) { return arr.slice().sort(function (a, b) { var x = a[campo], y = b[campo]; if (x == null) x = ""; if (y == null) y = ""; if (x < y) return desc ? 1 : -1; if (x > y) return desc ? -1 : 1; return 0; }); }
  };

  global.Util = Util;
  if (typeof module !== "undefined" && module.exports) module.exports = Util;
})(typeof window !== "undefined" ? window : global);
