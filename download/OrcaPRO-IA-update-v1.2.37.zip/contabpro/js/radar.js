/* =====================================================================
 * radar.js — Radar Regulatório + Planejamento Tributário (seção 3.21).
 * Card A: registra mudanças normativas (lei/IN/tabela/prazo/CCT), calcula
 *   QUEM é atingido (regime × segmento × UF) e vira tarefas de adequação.
 * Card B: produto consultivo — compara complexidade/custo do cliente em
 *   cada regime (Simples×Presumido×Real). HONESTO: NÃO promete economia de
 *   imposto; é indicativo de complexidade/serviço, confirmar na apuração real.
 * Coleção "radar": {id,titulo,tipo,resumo,impacto,alvo:{regimes,segmentos,ufs},
 *   publicadoEm,lida,criadoEm}. Tarefas geradas: id determinístico (idempotente).
 * ES5 estrito (var/function/concat). Orquestra Store/UI/Auth/CONFIG/App/Audit.
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  var TIPOS = [
    { v: "lei", t: "Lei" },
    { v: "in", t: "IN/Ato" },
    { v: "tabela", t: "Tabela" },
    { v: "prazo", t: "Prazo" },
    { v: "cct", t: "CCT" }
  ];
  var TIPO_COR = { lei: "azul", in: "roxo", tabela: "cinza", prazo: "amber", cct: "verde" };
  var TIPO_ROTULO = { lei: "Lei", in: "IN/Ato", tabela: "Tabela", prazo: "Prazo", cct: "CCT" };

  var IMPACTOS = [
    { v: "alto", t: "Alto" },
    { v: "medio", t: "Médio" },
    { v: "baixo", t: "Baixo" }
  ];
  var IMP_COR = { alto: "vermelho", medio: "amber", baixo: "cinza" };
  var IMP_ROTULO = { alto: "Alto", medio: "Médio", baixo: "Baixo" };

  // Regimes comparados no planejamento (os 3 de tributação real de PJ).
  var REGIMES_COMPARA = ["Simples", "Presumido", "Real"];

  // ---------- Helpers puros ----------
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(cliente excluído)"; }
  function idUsuario() { var u = Auth.usuario(); return u ? u.id : null; }

  function regimeNome(id) {
    for (var i = 0; i < CONFIG.regimes.length; i++) if (CONFIG.regimes[i].id === id) return CONFIG.regimes[i].nome;
    return id || "—";
  }
  function segmentoNome(id) {
    for (var i = 0; i < CONFIG.segmentos.length; i++) if (CONFIG.segmentos[i].id === id) return CONFIG.segmentos[i].nome;
    return id;
  }

  // Regime tributário ATUAL do cliente (string, ou histórico [{ano,regime}] — pega o mais recente).
  function regimeAtual(c) {
    if (!c) return null;
    var reg = c.regime;
    if (!reg && c.regimeTributario) {
      var h = c.regimeTributario;
      if (typeof h === "string") reg = h;
      else if (h && h.length) {
        var achou = null;
        for (var i = 0; i < h.length; i++) { if (!achou || (h[i].ano || 0) >= (achou.ano || 0)) achou = h[i]; }
        reg = achou ? achou.regime : null;
      }
    }
    return reg || null;
  }
  function segsDe(c) { return (c && (c.segmento || c.segmentos)) || []; }
  function ufsDe(c) {
    var set = {}; if (c && c.uf) set[c.uf] = 1;
    ((c && c.filiais) || []).forEach(function (f) { if (f && f.uf) set[f.uf] = 1; });
    var out = []; for (var k in set) if (set.hasOwnProperty(k)) out.push(k); return out;
  }

  // Um item de radar atinge o cliente? (regime∈ OU segmento∈ OU uf∈; alvo vazio = todos)
  function afeta(item, c) {
    var alvo = item.alvo || {};
    var R = alvo.regimes || [], S = alvo.segmentos || [], U = alvo.ufs || [];
    if (!R.length && !S.length && !U.length) return true; // sem alvo definido = mudança geral (todos)
    var reg = regimeAtual(c);
    if (R.length && reg && R.indexOf(reg) >= 0) return true;
    var segs = segsDe(c);
    if (S.length) { for (var i = 0; i < segs.length; i++) if (S.indexOf(segs[i]) >= 0) return true; }
    var ufs = ufsDe(c);
    if (U.length) { for (var j = 0; j < ufs.length; j++) if (U.indexOf(ufs[j]) >= 0) return true; }
    return false;
  }
  function clientesAfetados(item, clientes) {
    var out = []; for (var i = 0; i < clientes.length; i++) if (afeta(item, clientes[i])) out.push(clientes[i]); return out;
  }

  // Clientes que ESTE usuário pode ver (analista = só carteira) — respeita RBAC.
  function clientesVisiveis() { return Auth.clientesVisiveis(Store.listar("clientes")); }

  // "2026-07" da data ISO (para "itens deste mês")
  function mesDe(isoStr) { return String(isoStr || "").slice(0, 7); }

  // Lê valores marcados de um grupo de checkboxes dentro do overlay do modal.
  function lidos(ov, cls) {
    var ns = ov.querySelectorAll("." + cls + ":checked"), out = [];
    for (var i = 0; i < ns.length; i++) out.push(ns[i].value);
    return out;
  }
  // "MG, SP; rj" -> ["MG","SP","RJ"] (2 letras, sem duplicar)
  function parseUFs(s) {
    var raw = String(s || "").toUpperCase().split(/[^A-Z]+/), set = {}, out = [];
    for (var i = 0; i < raw.length; i++) { var u = raw[i]; if (u.length === 2 && !set[u]) { set[u] = 1; out.push(u); } }
    return out;
  }

  // ---------- View ----------
  global.RadarView = App.registrar({
    id: "radar",
    titulo: "Radar & Planejamento",

    render: function () {
      if (this._fImp == null) this._fImp = "";
      var fImp = this._fImp, i;

      var clientes = clientesVisiveis();
      var itens = Store.listar("radar");
      itens = Util.ordenaPor(itens, "publicadoEm", true); // mais recentes primeiro

      // ---- KPIs (sobre TODOS os itens, ignorando o filtro de impacto) ----
      var mesAtual = mesDe(Util.hojeISO());
      var naoLidas = 0, altos = 0, esteMes = 0;
      for (i = 0; i < itens.length; i++) {
        if (!itens[i].lida) naoLidas++;
        if (itens[i].impacto === "alto") altos++;
        if (mesDe(itens[i].publicadoEm) === mesAtual) esteMes++;
      }
      var kpis = '<div class="grid-kpi">' +
        '<div class="kpi ' + (naoLidas ? "wr" : "") + '"><div class="n">' + naoLidas + '</div><div class="l">Itens não lidos</div></div>' +
        '<div class="kpi ' + (altos ? "al" : "") + '"><div class="n">' + altos + '</div><div class="l">Alto impacto</div></div>' +
        '<div class="kpi"><div class="n">' + esteMes + '</div><div class="l">Publicados este mês</div></div>' +
        '</div>';

      // ---- Toolbar: registrar + filtro de impacto ----
      var podeCriar = Auth.pode("radar", "criar");
      var opsFiltro = [{ v: "", t: "Todos os impactos" }].concat(IMPACTOS);
      var toolbar = '<div class="toolbar">' +
        (podeCriar ? '<button class="btn primary" data-acao="novo">' + UI.icone("plus", 16) + ' Registrar mudança</button>' : "") +
        UI.sel("rad-fimp", opsFiltro, fImp) +
        '</div>';

      // ---- Tabela filtrada ----
      var visiveis = fImp ? itens.filter(function (o) { return o.impacto === fImp; }) : itens;
      var cols = [
        { k: "titulo", label: "Título", fmt: function (v, row) {
            var tag = row.lida ? "" : ' <span class="chip">novo</span>';
            return '<b>' + Util.esc(v || "(sem título)") + '</b>' + tag +
              (row.resumo ? '<div class="fld-d">' + Util.esc(row.resumo) + '</div>' : "");
          } },
        { k: "tipo", label: "Tipo", fmt: function (v) { return UI.badge(TIPO_ROTULO[v] || v || "—", TIPO_COR[v] || "cinza"); } },
        { k: "impacto", label: "Impacto", fmt: function (v) { return UI.badge(IMP_ROTULO[v] || v || "—", IMP_COR[v] || "cinza"); } },
        { k: "_afet", label: "Clientes afetados", cls: "ctr", fmt: function (v, row) {
            var n = clientesAfetados(row, clientes).length;
            var cor = n > 0 ? "azul" : "cinza";
            return '<a href="#" data-acao="verAfetados:' + Util.esc(row.id) + '">' + UI.badge(n + " cliente" + (n === 1 ? "" : "s"), cor) + '</a>';
          } },
        { k: "publicadoEm", label: "Publicado", fmt: function (v) { return '<span style="white-space:nowrap">' + Util.esc(Util.brData(v)) + '</span>'; } },
        { k: "_acoes", label: "Ações", cls: "ctr", fmt: function (v, row) {
            var out = '<button class="btn sm" data-acao="verAfetados:' + Util.esc(row.id) + '">Afetados</button> ';
            out += '<button class="btn sm" data-acao="marcarLida:' + Util.esc(row.id) + '">' + (row.lida ? "↺ não lida" : "✓ lida") + '</button> ';
            if (Auth.pode("radar", "editar")) out += '<button class="btn sm" data-acao="editar:' + Util.esc(row.id) + '">Editar</button> ';
            if (Auth.pode("radar", "excluir")) out += '<button class="btn sm danger" data-acao="excluir:' + Util.esc(row.id) + '" title="Excluir">✕</button>';
            return out;
          } }
      ];
      var tblRadar = UI.tabela(cols, visiveis, { vazio: "Nenhuma mudança registrada. Use “Registrar mudança” para começar o radar." });

      var cardA = '<div class="card"><div class="card-hd"><b>Radar Regulatório</b>' +
        '<span class="chip">' + itens.length + ' item(ns)</span></div>' +
        '<div class="card-bd">' + toolbar + tblRadar + '</div></div>';

      // ---- Card B: Planejamento Tributário por cliente ----
      var opsCli = [{ v: "", t: "— selecione o cliente —" }];
      for (i = 0; i < clientes.length; i++) opsCli.push({ v: clientes[i].id, t: nomeCliente(clientes[i]) });
      var cardB = '<div class="card"><div class="card-hd"><b>Planejamento Tributário por cliente</b></div>' +
        '<div class="card-bd">' +
        '<p class="fld-d" style="margin-bottom:12px">Compara a <b>complexidade e o custo de serviço</b> do cliente em cada regime (Simples, Presumido e Real). ' +
        'Não é cálculo de tributo — é um indicativo de complexidade/honorário para orientar a conversa com o cliente.</p>' +
        '<div class="toolbar">' +
        UI.sel("rad-cli", opsCli, "") +
        '<button class="btn green" data-acao="comparar">' + UI.icone("trend", 16) + ' Comparar regimes</button>' +
        '</div>' +
        (clientes.length ? "" : '<div class="empty">Nenhum cliente visível para comparar.</div>') +
        '</div></div>';

      return '<div class="page-hd"><div><h1>Radar & Planejamento</h1>' +
        '<div class="sub">Mudanças normativas que atingem a carteira + planejamento tributário consultivo por cliente.</div></div></div>' +
        kpis + cardA + cardB;
    },

    // liga o filtro de impacto (re-render mantendo estado)
    onMount: function (el) {
      var self = this, f = el.querySelector ? el.querySelector("#rad-fimp") : null;
      if (f) f.addEventListener("change", function () { self._fImp = f.value; App.render(); });
    },

    // ---------- Card A: CRUD do radar ----------

    // Modal compartilhado (item=null -> novo).
    _modalItem: function (item) {
      var novo = !item;
      var alvo = (item && item.alvo) || {};
      var selReg = alvo.regimes || [], selSeg = alvo.segmentos || [];

      var checksReg = CONFIG.regimes.map(function (r) {
        var ck = selReg.indexOf(r.id) >= 0 ? " checked" : "";
        return '<label class="chip" style="cursor:pointer"><input type="checkbox" class="rad-reg" value="' + Util.esc(r.id) + '"' + ck + ' style="width:auto;margin-right:6px"> ' + Util.esc(r.nome) + '</label>';
      }).join(" ");
      var checksSeg = CONFIG.segmentos.map(function (s) {
        var ck = selSeg.indexOf(s.id) >= 0 ? " checked" : "";
        return '<label class="chip" style="cursor:pointer"><input type="checkbox" class="rad-seg" value="' + Util.esc(s.id) + '"' + ck + ' style="width:auto;margin-right:6px"> ' + Util.esc(s.nome) + '</label>';
      }).join(" ");

      var corpo =
        UI.campo("Título *", UI.inp("rad-titulo", item ? item.titulo : "", "Ex.: Nova tabela do Simples Nacional 2026")) +
        '<div class="row">' +
        UI.campo("Tipo", UI.sel("rad-tipo", TIPOS, item ? item.tipo : "lei")) +
        UI.campo("Impacto", UI.sel("rad-imp", IMPACTOS, item ? item.impacto : "medio")) +
        UI.campo("Publicado em", UI.inp("rad-pub", item ? item.publicadoEm : Util.hojeISO(), "", "date")) +
        '</div>' +
        UI.campo("Resumo", '<textarea id="rad-resumo" class="in" rows="3" placeholder="O que muda, a partir de quando e o que exige do escritório/cliente.">' + Util.esc(item ? (item.resumo || "") : "") + '</textarea>') +
        UI.campo("Regimes atingidos",
          '<div style="display:flex;flex-wrap:wrap;gap:6px">' + checksReg + '</div>',
          "Marque os regimes. Deixe TUDO desmarcado (regimes, segmentos e UFs) para uma mudança geral que atinge todos os clientes.") +
        UI.campo("Segmentos atingidos", '<div style="display:flex;flex-wrap:wrap;gap:6px">' + checksSeg + '</div>') +
        UI.campo("UFs atingidas", UI.inp("rad-ufs", item ? ((alvo.ufs || []).join(", ")) : "", "Ex.: MG, SP, RJ"), "Deixe em branco se a mudança é federal / não depende de UF.");

      var self = this, ov;
      ov = UI.modal(novo ? "Registrar mudança regulatória" : "Editar mudança", corpo, [
        { txt: "Cancelar" },
        { txt: novo ? "Registrar" : "Salvar", classe: "primary", onClick: function (fechar) {
            if (!Auth.pode("radar", novo ? "criar" : "editar")) { UI.toast("Sem permissão.", "erro"); return; }
            var titulo = UI.v("rad-titulo");
            if (!titulo) { UI.toast("Informe o título da mudança.", "alerta"); return; }
            var obj = {
              id: novo ? Util.uid("radar") : item.id,
              titulo: titulo,
              tipo: UI.v("rad-tipo") || "lei",
              resumo: (UI.el("rad-resumo") ? UI.el("rad-resumo").value.trim() : ""),
              impacto: UI.v("rad-imp") || "medio",
              alvo: {
                regimes: lidos(ov, "rad-reg"),
                segmentos: lidos(ov, "rad-seg"),
                ufs: parseUFs(UI.v("rad-ufs"))
              },
              publicadoEm: UI.v("rad-pub") || Util.hojeISO(),
              lida: item ? !!item.lida : false,
              criadoEm: item ? (item.criadoEm || Util.hojeISO()) : Util.hojeISO()
            };
            Store.salvar("radar", obj); // STORAGE_CHEIO -> delegação do modal vira toast
            if (global.Audit) global.Audit.log(novo ? "radar_criar" : "radar_editar", "radar", obj.id);
            if (novo) {
              var n = clientesAfetados(obj, clientesVisiveis()).length;
              UI.toast(n + " cliente(s) afetado(s) — gere comunicado/tarefas.", n ? "alerta" : "ok");
            } else {
              UI.toast("Mudança atualizada.", "ok");
            }
            fechar(); App.render();
          } }
      ]);
    },

    novo: function () {
      if (!Auth.pode("radar", "criar")) { UI.toast("Sem permissão para registrar mudanças.", "erro"); return; }
      this._modalItem(null);
    },
    editar: function (id) {
      if (!Auth.pode("radar", "editar")) { UI.toast("Sem permissão para editar.", "erro"); return; }
      var item = Store.obter("radar", id);
      if (!item) { UI.toast("Item não encontrado.", "erro"); return; }
      this._modalItem(item);
    },

    marcarLida: function (id) {
      var item = Store.obter("radar", id);
      if (!item) { UI.toast("Item não encontrado.", "erro"); return; }
      item.lida = !item.lida;
      Store.salvar("radar", item);
      if (global.Audit) global.Audit.log(item.lida ? "radar_marcar_lida" : "radar_marcar_naolida", "radar", item.id);
      App.render();
    },

    excluir: function (id) {
      if (!Auth.pode("radar", "excluir")) { UI.toast("Sem permissão para excluir.", "erro"); return; }
      var item = Store.obter("radar", id);
      if (!item) { UI.toast("Item não encontrado.", "erro"); return; }
      UI.modal("Excluir mudança regulatória",
        "<p>Excluir <b>" + Util.esc(item.titulo) + "</b>? As tarefas de adequação já geradas para clientes NÃO são removidas.</p>",
        [{ txt: "Cancelar" }, { txt: "Excluir", classe: "danger", onClick: function (fechar) {
            if (!Auth.pode("radar", "excluir")) { UI.toast("Sem permissão.", "erro"); return; }
            Store.excluir("radar", id);
            if (global.Audit) global.Audit.log("radar_excluir", "radar", id);
            UI.toast("Mudança excluída.", "ok");
            fechar(); App.render();
          } }]);
    },

    // Lista os clientes atingidos + botão para gerar tarefas de adequação.
    verAfetados: function (id) {
      var item = Store.obter("radar", id);
      if (!item) { UI.toast("Item não encontrado.", "erro"); return; }
      var clientes = clientesVisiveis();
      var afet = clientesAfetados(item, clientes);
      var self = this;

      var corpoTopo = '<p class="fld-d" style="margin-bottom:12px">' +
        UI.badge(TIPO_ROTULO[item.tipo] || item.tipo, TIPO_COR[item.tipo] || "cinza") + " " +
        UI.badge(IMP_ROTULO[item.impacto] || item.impacto, IMP_COR[item.impacto] || "cinza") + " · <b>" +
        Util.esc(item.titulo) + '</b>' + (item.resumo ? '<br>' + Util.esc(item.resumo) : "") + '</p>';

      var cols = [
        { k: "_nome", label: "Cliente", fmt: function (v) { return Util.esc(v); } },
        { k: "_reg", label: "Regime", fmt: function (v) { return v ? UI.badge(regimeNome(v), "cinza") : '<span class="fld-d">—</span>'; } }
      ];
      var linhas = afet.map(function (c) { return { _nome: nomeCliente(c), _reg: regimeAtual(c) }; });
      linhas = Util.ordenaPor(linhas, "_nome");
      var tbl = UI.tabela(cols, linhas, { vazio: "Nenhum cliente visível é atingido por esta mudança." });

      var botoes = [{ txt: "Fechar" }];
      if (afet.length && Auth.pode("tarefas", "criar")) {
        botoes.push({ txt: "Gerar tarefas p/ afetados", classe: "green", onClick: function (fechar) {
            fechar(); self.gerarTarefas(id);
          } });
      }
      UI.modal("Clientes afetados — " + afet.length, corpoTopo + tbl, botoes);
    },

    // Cria 1 tarefa de adequação por cliente afetado. Id determinístico
    // "radar_"+radarId+"|"+clienteId => rodar de novo NÃO duplica (idempotente).
    gerarTarefas: function (radarId) {
      if (!Auth.pode("tarefas", "criar")) { UI.toast("Sem permissão para criar tarefas.", "erro"); return; }
      var item = Store.obter("radar", radarId);
      if (!item) { UI.toast("Item não encontrado.", "erro"); return; }
      var afet = clientesAfetados(item, clientesVisiveis());
      if (!afet.length) { UI.toast("Nenhum cliente afetado — nada a gerar.", "info"); return; }

      var hoje = Util.hojeISO(), prazo = Util.somaDias(hoje, 15), uid = idUsuario();
      var novas = [], jaExistiam = 0;
      for (var i = 0; i < afet.length; i++) {
        var c = afet[i];
        var tid = "radar_" + radarId + "|" + c.id; // DETERMINÍSTICO
        if (Store.obter("tarefas", tid)) { jaExistiam++; continue; } // não sobrescreve andamento/conclusão
        novas.push({
          id: tid,
          titulo: "Adequar: " + item.titulo,
          clienteId: c.id,
          responsavelId: "",
          descricao: "Adequação regulatória (" + (TIPO_ROTULO[item.tipo] || item.tipo) + "). " + (item.resumo || ""),
          prazo: prazo,
          origem: "manual",
          faturavel: false,
          status: "pendente",
          radarId: radarId,
          criadoPor: uid,
          criadoEm: hoje,
          historico: [{ status: "pendente", quando: hoje, por: uid }]
        });
      }
      if (novas.length) {
        Store.salvarLote("tarefas", novas); // STORAGE_CHEIO -> delegação vira toast
        if (global.Audit) global.Audit.log("radar_gerar_tarefas", "tarefas", radarId + " (" + novas.length + ")");
      }
      UI.toast(novas.length + " tarefa(s) criada(s) · " + jaExistiam + " já existia(m).", novas.length ? "ok" : "info");
      App.render();
    },

    // ---------- Card B: Planejamento tributário (comparativo impresso) ----------
    comparar: function () {
      var id = UI.v("rad-cli");
      if (!id) { UI.toast("Selecione um cliente para comparar.", "alerta"); return; }
      // segregação por carteira: o analista só compara clientes que ele pode ver
      // (mesma regra de verAfetados/gerarTarefas), não o value cru do <select>
      var vis = clientesVisiveis(), permitido = false;
      for (var vi = 0; vi < vis.length; vi++) if (vis[vi].id === id) { permitido = true; break; }
      if (!permitido) { UI.toast("Cliente fora da sua carteira.", "erro"); return; }
      var cliente = Store.obter("clientes", id);
      if (!cliente) { UI.toast("Cliente não encontrado.", "erro"); return; }

      var atual = regimeAtual(cliente);
      var segs = segsDe(cliente).map(function (s) { return segmentoNome(s); });

      // Calcula pontos/honorário variando o regime do cliente (mesma régua da seção 5).
      var linhas = REGIMES_COMPARA.map(function (regId) {
        var cl = Util.clone(cliente); cl.regime = regId;
        var pts = CONFIG.calcPontos(cl);
        var hon = CONFIG.honorarioSugerido(cl);
        return { regId: regId, pts: pts, hon: hon, atual: regId === atual };
      });

      var linhasHtml = linhas.map(function (l) {
        return "<tr" + (l.atual ? " class='tot'" : "") + ">" +
          "<td>" + Util.esc(regimeNome(l.regId)) + (l.atual ? " <b>(atual)</b>" : "") + "</td>" +
          "<td class='dir'>" + Util.esc(Util.brNum(l.pts, 0)) + "</td>" +
          "<td class='dir'>" + Util.esc(Util.brMoeda(l.hon)) + "</td>" +
          "</tr>";
      }).join("");

      var corpo =
        "<h2>Cliente</h2>" +
        "<table>" +
        "<tr><th style='width:30%'>Razão social</th><td>" + Util.esc(nomeCliente(cliente)) + "</td></tr>" +
        (cliente.cnpj ? "<tr><th>CNPJ</th><td>" + Util.esc(Util.formataCNPJ(cliente.cnpj)) + "</td></tr>" : "") +
        "<tr><th>Regime atual</th><td>" + Util.esc(regimeNome(atual)) + "</td></tr>" +
        (segs.length ? "<tr><th>Segmentos</th><td>" + Util.esc(segs.join(", ")) + "</td></tr>" : "") +
        "<tr><th>Funcionários</th><td>" + Util.esc(Util.brNum(cliente.funcionarios || 0, 0)) + "</td></tr>" +
        "</table>" +
        "<h2>Comparativo por regime</h2>" +
        "<table>" +
        "<tr><th>Regime</th><th class='dir' style='width:28%'>Pontos de complexidade</th><th class='dir' style='width:28%'>Honorário estimado / mês</th></tr>" +
        linhasHtml +
        "</table>" +
        "<p style='margin-top:16px;font-size:11px;color:#64748b'>" +
        "<b>Análise de elegibilidade</b> — este comparativo NÃO é cálculo de tributo. É um indicativo de " +
        "<b>complexidade e custo de serviço</b> do escritório em cada regime, com base na régua de pontos (nº de funcionários, " +
        "notas, segmentos, filiais/IE, exterior e parcelamentos). A escolha do regime e a economia tributária real dependem da " +
        "<b>apuração fiscal do cliente</b> (faturamento, margens, folha, créditos) e devem ser confirmadas caso a caso." +
        "</p>";

      App._abrirPrint("Planejamento Tributário — " + nomeCliente(cliente), corpo);
      if (global.Audit) global.Audit.log("radar_planejamento", "clientes", cliente.id);
    }
  });
})(window);
