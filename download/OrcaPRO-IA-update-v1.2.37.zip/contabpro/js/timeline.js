/* =====================================================================
 * timeline.js — Timeline & Entregas (princípio 3: serviço invisível
 * vira valor percebido). Linha do tempo unificada por cliente/mês
 * (obrigações entregues + documentos + comunicações + auditoria) e o
 * RELATÓRIO MENSAL DE ENTREGAS impresso — o entregável que fideliza.
 * Coleção nova: "comunicacoes" = { id, clienteId, canal, direcao,
 * assunto, conteudo, quando(ISO), por, criadoEm }.
 * ES5 estrito. Orquestra Store + Auth + UI + App._abrirPrint.
 * ===================================================================== */
(function (global) {
  "use strict";
  var CONFIG = global.CONFIG, Util = global.Util, Store = global.Store,
    Auth = global.Auth, UI = global.UI, App = global.App;

  // ---------- Helpers puros ----------
  var CANAIS = [
    { v: "whatsapp", t: "WhatsApp", cor: "verde" },
    { v: "email", t: "E-mail", cor: "azul" },
    { v: "telefone", t: "Telefone", cor: "amber" },
    { v: "reuniao", t: "Reunião", cor: "roxo" },
    { v: "portal", t: "Portal", cor: "cinza" }
  ];
  // Status de obrigação que contam como "entrega" na timeline.
  var ENTREGA = { concluida: "verde", retificada: "roxo", transmitida: "azul" };
  var ROTULO_ST = { concluida: "Concluída", retificada: "Retificada", transmitida: "Transmitida" };

  // Padrão de nome de cliente (consistência entre telas).
  function nomeCliente(c) { return c ? (c.razaoSocial || c.nomeFantasia || c.nome || "(sem nome)") : "(sem nome)"; }

  function canalInfo(v) { for (var i = 0; i < CANAIS.length; i++) if (CANAIS[i].v === v) return CANAIS[i]; return { v: v, t: v || "—", cor: "cinza" }; }

  function nomeUsuario(id) {
    if (!id) return "";
    var u = Store.obter("usuarios", id);
    return u ? u.nome : id;
  }

  // Competências: mês atual + 11 anteriores -> [{v:"2026-07", t:"jul/2026"}]
  function competencias() {
    var p = Util.partes(Util.hojeISO()), out = [], y = p.y, m = p.m, i;
    for (i = 0; i < 12; i++) {
      out.push({ v: Util.competencia(y, m), t: Util.mesNome(m) + "/" + y });
      m--; if (m < 1) { m = 12; y--; }
    }
    return out;
  }

  // ISO datetime ou ISO date -> "yyyy-mm-dd"
  function soData(s) { return String(s || "").slice(0, 10); }
  // pertence à competência "yyyy-mm"?
  function noMes(s, comp) { return String(s || "").indexOf(comp) === 0; }

  // Data em que a obrigação atingiu um status (histórico, mais recente).
  function dataStatus(ob, status) {
    var h = ob.historico || [];
    for (var i = h.length - 1; i >= 0; i--) if (h[i].status === status) return h[i].quando;
    return null;
  }

  // Eventos da timeline: [{data:"yyyy-mm-dd", tipo, titulo(HTML), detalhe(HTML)}]
  function coletarEventos(clienteId, comp) {
    var evs = [], i, j;

    // 1) Obrigações do cliente com evento de entrega no mês.
    var obs = Store.onde("obrigacoes", "clienteId", clienteId);
    for (i = 0; i < obs.length; i++) {
      var h = obs[i].historico || [];
      for (j = 0; j < h.length; j++) {
        if (ENTREGA[h[j].status] && noMes(h[j].quando, comp)) {
          evs.push({
            data: soData(h[j].quando), tipo: "obrigacao",
            titulo: Util.esc(obs[i].nome) + " " + UI.badge(ROTULO_ST[h[j].status] || h[j].status, ENTREGA[h[j].status]),
            detalhe: "Competência " + Util.esc(obs[i].competencia || "—") +
              (h[j].por ? " · por " + Util.esc(nomeUsuario(h[j].por)) : "")
          });
        }
      }
    }

    // 2) Documentos adicionados no mês.
    var docs = Store.onde("documentos", "clienteId", clienteId);
    for (i = 0; i < docs.length; i++) {
      if (noMes(docs[i].criadoEm, comp)) {
        evs.push({
          data: soData(docs[i].criadoEm), tipo: "documento",
          titulo: UI.icone("folder", 14) + " Documento: <b>" + Util.esc(docs[i].descricao || docs[i].nomeArquivo || "(sem descrição)") + "</b>",
          detalhe: (docs[i].categoria ? UI.badge(docs[i].categoria, "azul") + " " : "") +
            (docs[i].nomeArquivo ? Util.esc(docs[i].nomeArquivo) : "")
        });
      }
    }

    // 3) Comunicações do mês.
    var coms = Store.onde("comunicacoes", "clienteId", clienteId);
    for (i = 0; i < coms.length; i++) {
      if (noMes(coms[i].quando, comp)) {
        var ci = canalInfo(coms[i].canal);
        evs.push({
          data: soData(coms[i].quando), tipo: "comunicacao",
          titulo: UI.badge(ci.t, ci.cor) + " " +
            UI.badge(coms[i].direcao === "recebida" ? "recebida" : "enviada", coms[i].direcao === "recebida" ? "cinza" : "verde") +
            " <b>" + Util.esc(coms[i].assunto || "(sem assunto)") + "</b>",
          detalhe: Util.esc(coms[i].conteudo || "") +
            (coms[i].por ? " · " + Util.esc(nomeUsuario(coms[i].por)) : "")
        });
      }
    }

    // 4) Auditoria ligada ao cliente (só ações relevantes: criou/editou/regenerou).
    var auds = Store.listar("auditoria");
    for (i = 0; i < auds.length; i++) {
      var a = auds[i];
      if (a.entidadeId !== clienteId && a.contexto !== clienteId) continue;
      var ac = String(a.acao || "");
      if (ac.indexOf("criou") < 0 && ac.indexOf("editou") < 0 && ac.indexOf("regenerou") < 0) continue;
      if (!noMes(a.quando, comp)) continue;
      evs.push({
        data: soData(a.quando), tipo: "auditoria",
        titulo: UI.icone("shield", 14) + " " + Util.esc(ac) + " " + Util.esc(a.entidade || ""),
        detalhe: a.usuarioId ? "por " + Util.esc(nomeUsuario(a.usuarioId)) : ""
      });
    }

    // Mais recentes primeiro.
    return Util.ordenaPor(evs, "data", true);
  }

  // Obrigações CONCLUÍDAS no mês (para o relatório): {ob, entregueEm, noPrazo}
  function entregasDoMes(clienteId, comp) {
    var obs = Store.onde("obrigacoes", "clienteId", clienteId), out = [];
    for (var i = 0; i < obs.length; i++) {
      var dc = dataStatus(obs[i], "concluida");
      if (dc && noMes(dc, comp)) {
        var d = soData(dc);
        out.push({ ob: obs[i], entregueEm: d, noPrazo: d <= obs[i].prazoAjustado });
      }
    }
    return Util.ordenaPor(out, "entregueEm");
  }

  // ---------- View ----------
  global.TimelineView = App.registrar({
    id: "timeline",
    titulo: "Timeline & Entregas",

    render: function () {
      var self = this, i;
      var visiveis = Auth.clientesVisiveis(Store.listar("clientes"));

      // Cliente obrigatório: default = primeiro visível; excluído -> volta ao primeiro.
      var achou = false;
      for (i = 0; i < visiveis.length; i++) if (visiveis[i].id === self._cliente) achou = true;
      if (!achou) self._cliente = visiveis.length ? visiveis[0].id : "";

      var comps = competencias();
      var temMes = false;
      for (i = 0; i < comps.length; i++) if (comps[i].v === self._mes) temMes = true;
      if (!temMes) self._mes = comps[0].v; // default: mês atual

      var opCli = [];
      for (i = 0; i < visiveis.length; i++) opCli.push({ v: visiveis[i].id, t: nomeCliente(visiveis[i]) });

      var toolbar = '<div class="toolbar">' +
        UI.sel("tl-cliente", opCli.length ? opCli : [{ v: "", t: "— sem clientes visíveis —" }], self._cliente) +
        UI.sel("tl-mes", comps, self._mes) +
        '<button class="btn primary" data-acao="novaCom">' + UI.icone("plus", 14) + ' Registrar comunicação</button>' +
        '<button class="btn green" data-acao="relatorio">🖨 Relatório Mensal de Entregas</button>' +
        "</div>";

      var corpo;
      if (!self._cliente) {
        corpo = '<div class="empty">Nenhum cliente visível para o seu perfil. Cadastre clientes (ou peça a atribuição da sua carteira) para ver a timeline.</div>';
      } else {
        var evs = coletarEventos(self._cliente, self._mes);
        // KPIs do mês: entregas, comunicações, documentos
        var ent = entregasDoMes(self._cliente, self._mes);
        var nPrazo = 0; for (i = 0; i < ent.length; i++) if (ent[i].noPrazo) nPrazo++;
        var nCom = 0, nDoc = 0;
        for (i = 0; i < evs.length; i++) { if (evs[i].tipo === "comunicacao") nCom++; if (evs[i].tipo === "documento") nDoc++; }
        var kpis = '<div class="grid-kpi">' +
          '<div class="kpi ok"><div class="n">' + ent.length + '</div><div class="l">Obrigações entregues no mês</div></div>' +
          '<div class="kpi ' + (ent.length && nPrazo === ent.length ? "ok" : (ent.length ? "wr" : "")) + '"><div class="n">' +
            (ent.length ? Math.round(nPrazo * 100 / ent.length) + "%" : "—") + '</div><div class="l">No prazo</div></div>' +
          '<div class="kpi"><div class="n">' + nCom + '</div><div class="l">Comunicações</div></div>' +
          '<div class="kpi"><div class="n">' + nDoc + '</div><div class="l">Documentos disponibilizados</div></div>' +
          "</div>";

        var lista;
        if (!evs.length) {
          lista = '<div class="empty">Nada registrado neste mês para este cliente ainda. Entregas de obrigações, documentos adicionados no GED e comunicações registradas aparecem aqui automaticamente — e alimentam o Relatório Mensal de Entregas.</div>';
        } else {
          var itens = "";
          for (i = 0; i < evs.length; i++) {
            itens += '<div style="display:flex;gap:14px;padding:10px 0;border-left:3px solid ' + CONFIG.marca.corAcento + ';padding-left:14px;margin-left:6px">' +
              '<div style="min-width:78px;font-weight:700;white-space:nowrap">' + Util.esc(Util.brData(evs[i].data)) + '</div>' +
              '<div><div>' + evs[i].titulo + '</div>' +
              (evs[i].detalhe ? '<div style="color:var(--mut,#64748b);font-size:12px;margin-top:2px">' + evs[i].detalhe + '</div>' : "") +
              "</div></div>";
          }
          lista = itens;
        }
        corpo = kpis +
          '<div class="card"><div class="card-hd"><b>Linha do tempo — ' + Util.esc(self._mes) + '</b>' +
          '<span class="chip">' + evs.length + ' evento(s)</span></div>' +
          '<div class="card-bd">' + lista + "</div></div>";
      }

      return '<div class="page-hd"><div><h1>Timeline & Entregas</h1>' +
        '<div class="sub">Tudo que o escritório fez pelo cliente, mês a mês — o serviço invisível vira valor percebido.</div></div></div>' +
        toolbar + corpo;
    },

    onMount: function () {
      var self = this, map = [["tl-cliente", "_cliente"], ["tl-mes", "_mes"]];
      map.forEach(function (par) {
        var e = UI.el(par[0]);
        if (e) e.addEventListener("change", function () { self[par[1]] = e.value; App.render(); });
      });
    },

    // ---- Registrar comunicação ----
    novaCom: function () {
      if (!Auth.pode("timeline", "criar")) { UI.toast("Sem permissão para registrar comunicações.", "erro"); return; }
      var self = this;
      var cli = Store.obter("clientes", self._cliente);
      if (!cli) { UI.toast("Selecione um cliente primeiro.", "erro"); return; }

      var opCanal = CANAIS.map(function (c) { return { v: c.v, t: c.t }; });
      var opDir = [{ v: "enviada", t: "Enviada (escritório → cliente)" }, { v: "recebida", t: "Recebida (cliente → escritório)" }];
      var corpo = '<p class="fld-d" style="margin-bottom:14px">Cliente: <b>' + Util.esc(nomeCliente(cli)) + "</b></p>" +
        '<div class="row">' +
        UI.campo("Canal", UI.sel("tl-m-canal", opCanal, "whatsapp")) +
        UI.campo("Direção", UI.sel("tl-m-dir", opDir, "enviada")) +
        "</div>" +
        UI.campo("Assunto", UI.inp("tl-m-assunto", "", "ex.: Envio das guias DAS 07/2026")) +
        UI.campo("Conteúdo / resumo", '<textarea id="tl-m-conteudo" class="in" rows="4" placeholder="O que foi tratado?"></textarea>') +
        UI.campo("Data", UI.inp("tl-m-data", Util.hojeISO(), "", "date"));

      UI.modal("Registrar comunicação", corpo, [
        { txt: "Cancelar" },
        { txt: "Salvar", classe: "green", onClick: function (fechar) {
          Auth.exigir("timeline", "criar"); // guard na função
          var assunto = UI.v("tl-m-assunto");
          if (!assunto) { UI.toast("Informe o assunto.", "erro"); return; }
          var quando = UI.v("tl-m-data") || Util.hojeISO();
          var u = Auth.usuario();
          var com = {
            id: Util.uid("com"),
            clienteId: self._cliente,
            canal: UI.v("tl-m-canal") || "whatsapp",
            direcao: UI.v("tl-m-dir") === "recebida" ? "recebida" : "enviada",
            assunto: assunto,
            conteudo: UI.v("tl-m-conteudo"),
            quando: quando,
            por: u ? u.id : null,
            criadoEm: Util.hojeISO()
          };
          Store.salvar("comunicacoes", com); // STORAGE_CHEIO: modal já mostra o toast
          if (global.Audit) global.Audit.log("registrou_comunicacao", "comunicacoes", com.id);
          UI.toast("Comunicação registrada.", "ok");
          fechar(); App.render();
        } }
      ]);
    },

    // ---- Relatório Mensal de Entregas (impresso) — O entregável que fideliza ----
    relatorio: function () {
      if (!Auth.pode("timeline", "exportar")) { UI.toast("Sem permissão para gerar relatórios.", "erro"); return; }
      var self = this, i;
      var cli = Store.obter("clientes", self._cliente);
      if (!cli) { UI.toast("Selecione um cliente primeiro.", "erro"); return; }

      var comp = self._mes, p = Util.partes(comp + "-01");
      var mesTxt = Util.mesNome(p.m) + "/" + p.y;

      // ---- Entregas (obrigações concluídas no mês) ----
      var ent = entregasDoMes(self._cliente, comp);
      var nPrazo = 0; for (i = 0; i < ent.length; i++) if (ent[i].noPrazo) nPrazo++;
      var pct = ent.length ? Math.round(nPrazo * 100 / ent.length) : 0;

      var resumo = '<div style="border:2px solid #16a34a;border-radius:10px;padding:16px 18px;margin:6px 0 14px;background:#f0fdf4">' +
        '<div style="font-size:15px"><b>Sua contabilidade entregou ' + ent.length +
        (ent.length === 1 ? " obrigação" : " obrigações") + " em " + Util.esc(mesTxt) + "</b>" +
        (ent.length ? ' — <span class="' + (pct === 100 ? "ok" : "al") + '">' + pct + "% no prazo</span>" : "") +
        "</div>" +
        '<div style="color:#64748b;font-size:11px;margin-top:4px">Cliente: ' + Util.esc(nomeCliente(cli)) +
        (cli.cnpj ? " · CNPJ " + Util.esc(Util.formataCNPJ(cli.cnpj)) : "") + "</div></div>";

      var linhasEnt = "";
      for (i = 0; i < ent.length; i++) {
        var e2 = ent[i], cp = e2.ob.comprovante || {};
        linhasEnt += "<tr><td>" + Util.esc(e2.ob.nome) + "</td><td>" + Util.esc(e2.ob.competencia || "—") + "</td>" +
          "<td>" + Util.esc(Util.brData(e2.ob.prazoLegal)) + "</td>" +
          '<td class="' + (e2.noPrazo ? "ok" : "al") + '">' + Util.esc(Util.brData(e2.entregueEm)) + (e2.noPrazo ? " ✓" : "") + "</td>" +
          "<td>" + Util.esc(cp.protocolo || cp.arquivo || "—") + "</td></tr>";
      }
      var tblEnt = ent.length
        ? "<table><tr><th>Obrigação</th><th>Competência</th><th>Prazo legal</th><th>Entregue em</th><th>Protocolo do comprovante</th></tr>" +
          linhasEnt +
          '<tr class="tot"><td colspan="3">Total de obrigações entregues</td><td class="' + (pct === 100 ? "ok" : "") + '">' +
          ent.length + " (" + pct + "% no prazo)</td><td></td></tr></table>"
        : "<p>Nenhuma obrigação concluída neste mês.</p>";

      // ---- Comunicações do mês ----
      var coms = Store.onde("comunicacoes", "clienteId", self._cliente).filter(function (c) { return noMes(c.quando, comp); });
      coms = Util.ordenaPor(coms, "quando");
      var linhasCom = "";
      for (i = 0; i < coms.length; i++) {
        linhasCom += "<tr><td>" + Util.esc(Util.brData(soData(coms[i].quando))) + "</td><td>" + Util.esc(canalInfo(coms[i].canal).t) + "</td>" +
          "<td>" + Util.esc(coms[i].direcao === "recebida" ? "Recebida" : "Enviada") + "</td>" +
          "<td>" + Util.esc(coms[i].assunto || "—") + "</td></tr>";
      }
      var tblCom = coms.length
        ? "<table><tr><th>Data</th><th>Canal</th><th>Direção</th><th>Assunto</th></tr>" + linhasCom +
          '<tr class="tot"><td colspan="3">Total de interações</td><td>' + coms.length + "</td></tr></table>"
        : "<p>Nenhuma comunicação registrada neste mês.</p>";

      // ---- Documentos disponibilizados no mês ----
      var docs = Store.onde("documentos", "clienteId", self._cliente).filter(function (d) { return noMes(d.criadoEm, comp); });
      docs = Util.ordenaPor(docs, "criadoEm");
      var linhasDoc = "";
      for (i = 0; i < docs.length; i++) {
        linhasDoc += "<tr><td>" + Util.esc(Util.brData(soData(docs[i].criadoEm))) + "</td>" +
          "<td>" + Util.esc(docs[i].categoria || "—") + "</td>" +
          "<td>" + Util.esc(docs[i].descricao || docs[i].nomeArquivo || "(sem descrição)") + "</td></tr>";
      }
      var tblDoc = docs.length
        ? "<table><tr><th>Data</th><th>Categoria</th><th>Documento</th></tr>" + linhasDoc +
          '<tr class="tot"><td colspan="2">Total de documentos</td><td>' + docs.length + "</td></tr></table>"
        : "<p>Nenhum documento disponibilizado neste mês.</p>";

      var corpoHtml = resumo +
        "<h2>Obrigações entregues</h2>" + tblEnt +
        "<h2>Comunicações do mês</h2>" + tblCom +
        "<h2>Documentos disponibilizados</h2>" + tblDoc +
        '<p style="margin-top:14px;color:#64748b;font-size:11px">Relatório gerado automaticamente a partir dos registros de obrigações, comunicações e documentos do período. Comprovantes disponíveis no GED do escritório.</p>';

      if (global.Audit) global.Audit.log("gerou_relatorio_entregas", "clientes", self._cliente);
      App._abrirPrint("Relatório de Entregas — " + mesTxt, corpoHtml);
    }
  });
})(window);
