/* =====================================================================
 * tarefas.js — Módulo de Tarefas internas (seção 3.13).
 * Lista + criação/edição de tarefas do escritório (kanban leve por status).
 * Combate ao escopo infinito: tarefa marcada como "faturável" lembra de orçar.
 * ES5 estrito (só var/function/concat). Orquestra Store/UI/Auth/Audit.
 * ===================================================================== */
(function (global) {
  "use strict";
  var Store = global.Store, UI = global.UI, Util = global.Util, Auth = global.Auth, App = global.App;

  // Fluxo simples de status desta tela (independente do workflow de obrigações)
  var STATUS = ["pendente", "em_andamento", "concluida"];
  var ST_ROTULO = { pendente: "Pendente", em_andamento: "Em andamento", concluida: "Concluída" };
  var ST_COR = { pendente: "cinza", em_andamento: "azul", concluida: "verde" };

  var ORIGEM = [
    { v: "manual", t: "Manual" },
    { v: "solicitacao", t: "Solicitação do cliente" },
    { v: "processo", t: "Processo interno" }
  ];
  var OR_ROTULO = { manual: "Manual", solicitacao: "Solicitação", processo: "Processo", obrigacao: "Obrigação" };
  var OR_COR = { manual: "cinza", solicitacao: "azul", processo: "roxo", obrigacao: "amber" };

  // ---- helpers de nome ----
  function nomeCliente(id) {
    if (!id) return "";
    var c = Store.obter("clientes", id);
    if (!c) return "(cliente removido)";
    return c.razaoSocial || c.nomeFantasia || c.nome || c.apelido || c.id;
  }
  function nomeUsuario(id) {
    if (!id) return "—";
    var u = Store.obter("usuarios", id);
    return u ? u.nome : "—";
  }
  function proxStatus(atual) {
    var i = STATUS.indexOf(atual);
    if (i < 0) return "em_andamento";
    if (i >= STATUS.length - 1) return STATUS[STATUS.length - 1];
    return STATUS[i + 1];
  }

  // ---- opções de select reaproveitadas ----
  function opsClientes() {
    var todos = Auth.clientesVisiveis(Store.listar("clientes"));
    var ops = [{ v: "", t: "— Sem cliente —" }];
    todos.forEach(function (c) { ops.push({ v: c.id, t: nomeCliente(c.id) }); });
    return ops;
  }
  function opsResponsaveis(incluiVazio) {
    var us = Auth.usuarios();
    var ops = incluiVazio ? [{ v: "", t: "— Sem responsável —" }] : [];
    us.forEach(function (u) { ops.push({ v: u.id, t: u.nome }); });
    return ops;
  }

  // ---- formatação de prazo (data BR + badge de atraso) ----
  function fmtPrazo(v, row) {
    if (!v) return '<span class="badge badge-cinza">sem prazo</span>';
    var txt = Util.brData(v);
    if (row.status === "concluida") return txt;
    var dias = Util.diasAte(v);
    if (dias == null) return txt;
    if (dias < 0) return txt + " " + UI.badge("Atrasada", "vermelho");
    if (dias <= 2) return txt + " " + UI.badge("Vence logo", "amber");
    return txt;
  }

  // ---- monta as linhas visíveis conforme filtros ----
  function linhasFiltradas(view) {
    var arr = Store.listar("tarefas");
    var fS = view._fStatus || "", fR = view._fResp || "";
    var out = [];
    for (var i = 0; i < arr.length; i++) {
      var t = arr[i];
      if (fS && t.status !== fS) continue;
      if (fR) {
        if (fR === "__none__") { if (t.responsavelId) continue; }
        else if (t.responsavelId !== fR) continue;
      }
      out.push(t);
    }
    // prazo mais próximo primeiro; sem prazo por último
    out.sort(function (a, b) {
      var pa = a.prazo || "9999-99-99", pb = b.prazo || "9999-99-99";
      if (pa < pb) return -1; if (pa > pb) return 1; return 0;
    });
    return out;
  }

  // ---- HTML da tabela (recolocado dentro de #tf-lista) ----
  function htmlLista(view) {
    var linhas = linhasFiltradas(view);
    var cols = [
      { k: "titulo", label: "Título", fmt: function (v, r) {
          return '<a href="#" data-acao="editar:' + Util.esc(r.id) + '"><b>' + Util.esc(v || "(sem título)") + '</b></a>';
        } },
      { k: "clienteId", label: "Cliente", fmt: function (v) { return v ? Util.esc(nomeCliente(v)) : '<span class="fld-d">—</span>'; } },
      { k: "origem", label: "Origem", fmt: function (v) { return UI.badge(OR_ROTULO[v] || v || "Manual", OR_COR[v] || "cinza"); } },
      { k: "responsavelId", label: "Responsável", fmt: function (v) { return Util.esc(nomeUsuario(v)); } },
      { k: "prazo", label: "Prazo", fmt: fmtPrazo },
      { k: "faturavel", label: "Faturável", cls: "ctr", fmt: function (v) { return v ? UI.badge("Faturável", "verde") : '<span class="fld-d">—</span>'; } },
      { k: "status", label: "Status", fmt: function (v) { return UI.badge(ST_ROTULO[v] || v, ST_COR[v] || "cinza"); } },
      { k: "id", label: "Ações", cls: "ctr", fmt: function (v, r) {
          if (r.status === "concluida") return '<span class="fld-d">—</span>';
          var b = '<button class="btn sm" data-acao="avancarTarefa:' + Util.esc(v) + '">Avançar</button>';
          b += ' <button class="btn sm green" data-acao="concluir:' + Util.esc(v) + '">Concluir</button>';
          return b;
        } }
    ];
    return UI.tabela(cols, linhas, { vazio: "Nenhuma tarefa com os filtros atuais." });
  }

  // ---- corpo do modal (novo/editar) ----
  function corpoForm(t) {
    var respPad = t.responsavelId || (Auth.usuario() ? Auth.usuario().id : "");
    var h = "";
    h += UI.campo("Título *", UI.inp("tf-titulo", t.titulo, "Ex.: Conferir NF-e de junho do cliente X"));
    h += '<div class="row">';
    h += UI.campo("Cliente (opcional)", UI.sel("tf-cliente", opsClientes(), t.clienteId || ""));
    h += UI.campo("Responsável", UI.sel("tf-resp", opsResponsaveis(true), respPad));
    h += '</div>';
    h += UI.campo("Descrição", '<textarea id="tf-desc" class="in" rows="3" placeholder="Detalhes da tarefa">' + Util.esc(t.descricao || "") + '</textarea>');
    h += '<div class="row">';
    h += UI.campo("Prazo", UI.inp("tf-prazo", t.prazo || "", "", "date"));
    h += UI.campo("Origem", UI.sel("tf-origem", ORIGEM, t.origem || "manual"));
    h += '</div>';
    h += UI.campo("Faturável",
      '<label style="display:flex;align-items:center;gap:8px;font-weight:600;cursor:pointer">' +
      '<input type="checkbox" id="tf-fatur"' + (t.faturavel ? " checked" : "") + " style=\"width:auto\"> " +
      'Cobrar à parte (serviço extra)</label>',
      "Marque para não absorver serviço fora do contrato. Ao salvar, lembramos de orçar.");
    return h;
  }

  window.TarefasView = App.registrar({
    id: "tarefas",

    render: function () {
      if (this._fStatus == null) this._fStatus = "";
      if (this._fResp == null) this._fResp = "";
      var todas = Store.listar("tarefas");
      // contagem por status (independente dos filtros)
      var cont = { pendente: 0, em_andamento: 0, concluida: 0 };
      for (var i = 0; i < todas.length; i++) { var s = todas[i].status; if (cont[s] != null) cont[s]++; }

      var h = "";
      h += '<div class="page-hd"><div><h1>Tarefas</h1>' +
        '<div class="sub">Demandas internas do escritório — organize, distribua e proteja o escopo.</div></div>' +
        '<button class="btn primary" data-acao="nova">' + UI.icone("plus", 18) + ' Nova tarefa</button></div>';

      // KPIs por coluna (clicáveis = filtro rápido)
      h += '<div class="grid-kpi">';
      h += '<div class="kpi" data-acao="filtrar:pendente" style="cursor:pointer"><div class="n">' + cont.pendente + '</div><div class="l">Pendentes</div></div>';
      h += '<div class="kpi wr" data-acao="filtrar:em_andamento" style="cursor:pointer"><div class="n">' + cont.em_andamento + '</div><div class="l">Em andamento</div></div>';
      h += '<div class="kpi ok" data-acao="filtrar:concluida" style="cursor:pointer"><div class="n">' + cont.concluida + '</div><div class="l">Concluídas</div></div>';
      h += '<div class="kpi" data-acao="filtrar:" style="cursor:pointer"><div class="n">' + todas.length + '</div><div class="l">Todas</div></div>';
      h += '</div>';

      // toolbar de filtros
      var opsS = [{ v: "", t: "Todos os status" }];
      STATUS.forEach(function (s) { opsS.push({ v: s, t: ST_ROTULO[s] }); });
      var opsR = [{ v: "", t: "Todos responsáveis" }, { v: "__none__", t: "Sem responsável" }].concat(opsResponsaveis(false));
      h += '<div class="toolbar">' +
        UI.sel("tf-fstatus", opsS, this._fStatus) +
        UI.sel("tf-fresp", opsR, this._fResp) +
        '</div>';

      // lista
      h += '<div class="card"><div class="card-bd" id="tf-lista">' + htmlLista(this) + '</div></div>';
      return h;
    },

    onMount: function (el) {
      var view = this;
      var fs = el.querySelector("#tf-fstatus");
      var fr = el.querySelector("#tf-fresp");
      function rebuild() {
        var box = el.querySelector("#tf-lista");
        if (box) box.innerHTML = htmlLista(view);
      }
      if (fs) fs.onchange = function () { view._fStatus = this.value; rebuild(); };
      if (fr) fr.onchange = function () { view._fResp = this.value; rebuild(); };
    },

    // filtro rápido pelos cards de KPI
    filtrar: function (status) {
      this._fStatus = status || "";
      App.render();
    },

    // data-acao="nova"
    nova: function () { this._abrirForm(null); },
    // data-acao="editar:ID"
    editar: function (id) {
      var t = Store.obter("tarefas", id);
      if (!t) { UI.toast("Tarefa não encontrada.", "erro"); return; }
      this._abrirForm(t);
    },

    _abrirForm: function (existente) {
      var view = this;
      var edicao = !!existente;
      var base = existente || { titulo: "", clienteId: "", responsavelId: "", descricao: "", prazo: "", origem: "manual", faturavel: false, status: "pendente" };
      UI.modal(edicao ? "Editar tarefa" : "Nova tarefa", corpoForm(base), [
        { txt: "Cancelar", classe: "" },
        { txt: edicao ? "Salvar" : "Criar tarefa", classe: "primary", onClick: function (fechar) {
            var titulo = UI.v("tf-titulo");
            if (!titulo) { UI.toast("Informe o título da tarefa.", "erro"); return; }
            var fatEl = UI.el("tf-fatur");
            var descEl = UI.el("tf-desc");
            var obj = Util.clone(base);
            obj.titulo = titulo;
            obj.clienteId = UI.v("tf-cliente") || "";
            obj.responsavelId = UI.v("tf-resp") || "";
            obj.descricao = descEl ? descEl.value.trim() : "";
            obj.prazo = UI.v("tf-prazo") || "";
            obj.origem = UI.v("tf-origem") || "manual";
            obj.faturavel = !!(fatEl && fatEl.checked);
            if (!edicao) {
              obj.status = "pendente";
              obj.criadoPor = Auth.usuario() ? Auth.usuario().id : null;
              obj.criadoEm = Util.hojeISO();
              obj.historico = [{ status: "pendente", quando: Util.hojeISO(), por: obj.criadoPor }];
            }
            var salvo = Store.salvar("tarefas", obj);
            if (window.Audit) window.Audit.log(edicao ? "editar" : "criar", "tarefas", salvo.id);
            if (obj.faturavel) UI.toast("Tarefa faturável: lembre de gerar orçamento/aditivo antes de executar.", "alerta");
            UI.toast(edicao ? "Tarefa atualizada." : "Tarefa criada.", "ok");
            fechar();
            App.render();
          } }
      ]);
    },

    // data-acao="avancarTarefa:ID" — pendente -> em_andamento -> concluida
    avancarTarefa: function (id) {
      var t = Store.obter("tarefas", id);
      if (!t) { UI.toast("Tarefa não encontrada.", "erro"); return; }
      if (t.status === "concluida") { UI.toast("Tarefa já concluída.", "info"); return; }
      var novo = proxStatus(t.status);
      t.status = novo;
      (t.historico = t.historico || []).push({ status: novo, quando: Util.hojeISO(), por: Auth.usuario() ? Auth.usuario().id : null });
      Store.salvar("tarefas", t);
      if (window.Audit) window.Audit.log("avancar", "tarefas", t.id);
      UI.toast("Status: " + (ST_ROTULO[novo] || novo) + ".", "ok");
      App.render();
    },

    // data-acao="concluir:ID"
    concluir: function (id) {
      var t = Store.obter("tarefas", id);
      if (!t) { UI.toast("Tarefa não encontrada.", "erro"); return; }
      if (t.status === "concluida") { UI.toast("Tarefa já concluída.", "info"); return; }
      t.status = "concluida";
      (t.historico = t.historico || []).push({ status: "concluida", quando: Util.hojeISO(), por: Auth.usuario() ? Auth.usuario().id : null });
      Store.salvar("tarefas", t);
      if (window.Audit) window.Audit.log("concluir", "tarefas", t.id);
      UI.toast("Tarefa concluída.", "ok");
      App.render();
    }
  });
})(window);
