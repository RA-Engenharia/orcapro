@echo off
chcp 65001 >nul
title OrcaPRO IA
cd /d "%~dp0"

REM --- Node: usa o runtime embutido/baixado; senao o do sistema; senao baixa ---
if exist "%~dp0runtime\node.exe" set "PATH=%~dp0runtime;%PATH%"
where node >nul 2>nul
if errorlevel 1 (
  echo Preparando o Node.js ^(so na 1a vez, precisa de internet^)...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalador\baixar-node.ps1"
  if exist "%~dp0runtime\node.exe" set "PATH=%~dp0runtime;%PATH%"
)
where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js indisponivel. Rode Instalar-OrcaPRO.bat com a internet ligada.
  pause
  exit /b 1
)

REM --- PORTA: porta.txt manda, senao 8754 ---
REM  Uma maquina pode ter mais de uma instalacao do OrcaPRO (a do atalho, a de
REM  um pacote antigo, a saida do instalador). Todas subiam na 8754, e quem
REM  chegava primeiro vencia — inclusive uma com MENOS bases SINAPI que a
REM  outra, sem nada na tela avisar qual respondeu. Criar um porta.txt com o
REM  numero desejado ao lado deste .bat resolve, e o arquivo NAO viaja no
REM  pacote de atualizacao: a escolha sobrevive ao proximo update.
set "PORT_APP=8754"
if exist "%~dp0porta.txt" (for /f "usebackq delims=" %%p in ("%~dp0porta.txt") do set "PORT_APP=%%p")

echo [OK] Subindo o OrcaPRO IA ^(porta %PORT_APP%^)... a IA ja vem pronta, roda na nuvem.

REM --- SEM JANELA DE CONSOLE ---
REM  Aqui era:  start "OrcaPRO App" /min cmd /c "node server\static.js"
REM  Isso deixava uma janela de console ABERTA O TEMPO TODO na barra de
REM  tarefas — minimizada nao e escondida: ocupa a barra, aparece no
REM  Alt+Tab, e um clique com uma tecla derruba o servidor no meio do
REM  trabalho. Clientes reclamaram disso.
REM  O wscript sobe o node sem console nenhum. Para PARAR o app agora
REM  existe o Fechar-OrcaPRO.bat (fechar a janela nao e mais uma opcao,
REM  porque nao ha janela).
if exist "%~dp0iniciar-oculto.vbs" (
  wscript //B //Nologo "%~dp0iniciar-oculto.vbs" "%~dp0." "node server\static.js"
) else (
  REM  pacote antigo sem o lancador: volta ao jeito de antes, com janela.
  start "OrcaPRO App" /min cmd /c "node server\static.js"
)
ping 127.0.0.1 -n 3 >nul
start "" "http://localhost:%PORT_APP%/index.html?v=%RANDOM%%RANDOM%"
echo.
echo OrcaPRO IA aberto no navegador. Esta janela fecha sozinha.
echo (Para desligar o sistema depois, use o Fechar-OrcaPRO.bat.)
timeout /t 4 >nul
