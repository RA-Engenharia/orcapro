#!/bin/bash
# =====================================================================
# Iniciar-OrcaPRO.command — sobe o OrçaPRO no Mac e abre no navegador.
# Espelho do Iniciar-OrcaPRO.bat do Windows.
# =====================================================================
set -u
cd "$(dirname "${BASH_SOURCE[0]}")" || exit 1
RAIZ="$(pwd)"

# ---------------------------------------------------------------------
# ⚠ ESTOU NA PASTA DO ORÇAPRO?
#
#   Os arquivos do Mac vêm num pacote pequeno, à parte. É natural
#   descompactar em Downloads e clicar ali mesmo — e foi o que aconteceu
#   na primeira vez que isto rodou num Mac de verdade. Sem esta linha o
#   Node subia, não achava o server/static.js e cuspia quinze linhas de
#   rastro de pilha terminadas em MODULE_NOT_FOUND, que não dizem ao
#   cliente NADA sobre o que fazer. A verificação custa uma linha.
# ---------------------------------------------------------------------
if [ ! -f "$RAIZ/server/static.js" ]; then
  echo ""
  echo "[ERRO] Este arquivo está fora da pasta do OrçaPRO."
  echo ""
  echo "       Ele está em:  $RAIZ"
  echo "       e aqui não há o sistema (falta a pasta \"server\")."
  echo ""
  echo "       Abra o Instalar-OrcaPRO.command que veio junto: ele procura a"
  echo "       pasta do OrçaPRO neste Mac e põe tudo no lugar sozinho."
  echo ""
  read -r -p "Pressione Enter para fechar." _
  exit 1
fi

# --- Node: usa o runtime da pasta; senão o do sistema; senão baixa ---
NODE=""
if [ -x "$RAIZ/runtime/bin/node" ]; then
  NODE="$RAIZ/runtime/bin/node"
elif command -v node >/dev/null 2>&1; then
  NODE="$(command -v node)"
else
  echo "Preparando o Node.js (só na 1ª vez, precisa de internet)..."
  bash "$RAIZ/instalador/baixar-node-mac.sh"
  [ -x "$RAIZ/runtime/bin/node" ] && NODE="$RAIZ/runtime/bin/node"
fi

if [ -z "$NODE" ]; then
  echo ""
  echo "[ERRO] Node.js indisponível. Abra o Instalar-OrcaPRO.command com a internet ligada."
  echo ""
  read -r -p "Pressione Enter para fechar." _
  exit 1
fi

# --- PORTA: porta.txt manda, senão 8754 ---
#  Mesma regra do Windows: uma máquina pode ter mais de uma instalação, e
#  quem chega primeiro na 8754 vence — inclusive uma com menos bases que a
#  outra, sem nada na tela avisar qual respondeu. O porta.txt NÃO viaja no
#  pacote de atualização: a escolha sobrevive ao próximo update.
PORT_APP=8754
[ -f "$RAIZ/porta.txt" ] && PORT_APP="$(tr -d '[:space:]' < "$RAIZ/porta.txt")"
[ -z "$PORT_APP" ] && PORT_APP=8754

# --- Já está rodando? Então só abre o navegador. ---
#  Subir um segundo servidor na mesma porta faria o Node morrer com EADDRINUSE
#  numa janela que o cliente não vê, e ele concluiria que o sistema quebrou.
JA=""
command -v lsof >/dev/null 2>&1 && JA="$(lsof -ti "tcp:$PORT_APP" -sTCP:LISTEN 2>/dev/null | head -1)"

# ---------------------------------------------------------------------
# ⚠ QUEM ESTÁ NA PORTA: ESTA PASTA, OU OUTRA INSTALAÇÃO?
#
#   Uma máquina acaba com mais de uma pasta do OrçaPRO — o macOS renomeia
#   para "OrcaPRO 2" ao descompactar por cima, e ninguém percebe. As duas
#   sobem na 8754, e quem chegou primeiro vence.
#   Sem esta verificação o lançador dizia "já estava aberto" e abria o
#   navegador — mostrando o sistema da OUTRA pasta. Foi exatamente o que
#   aconteceu com um cliente: ele copiou o arquivo que faltava para a pasta
#   certa, recarregou, e continuou vendo 404, porque quem respondia era a
#   outra instalação. Nada na tela ligava uma coisa à outra.
#   O diretório de trabalho do processo é a resposta: o servidor sobe com
#   `cd` na pasta dele.
# ---------------------------------------------------------------------
DONO=""
if [ -n "$JA" ] && command -v lsof >/dev/null 2>&1; then
  DONO="$(lsof -a -d cwd -p "$JA" -Fn 2>/dev/null | sed -n 's/^n//p' | head -1)"
fi
if [ -n "$JA" ] && [ -n "$DONO" ] && [ "$DONO" != "$RAIZ" ]; then
  echo ""
  echo "[ATENÇÃO] A porta $PORT_APP já está sendo usada por OUTRA pasta do OrçaPRO:"
  echo ""
  echo "    está rodando:  $DONO"
  echo "    você abriu:    $RAIZ"
  echo ""
  echo "  Se abrir o navegador agora, você verá o sistema da OUTRA pasta —"
  echo "  não esta. Vou desligar aquele e subir este."
  echo ""
  kill "$JA" 2>/dev/null
  # ⚠ ESPERA A PORTA LIBERAR DE VERDADE, e não um número fixo de segundos.
  #   O `kill` pede para sair; não garante que saiu. Se o servidor novo subir
  #   com a porta ainda ocupada, ele morre com EADDRINUSE dentro do log — e o
  #   teste de "já respondeu?" logo abaixo é satisfeito pelo servidor VELHO,
  #   que continua de pé. Resultado: a tela diz "aberto no navegador" e o
  #   usuário continua vendo o sistema da outra pasta. Foi assim que o cliente
  #   ficou vendo 404 depois de pôr o arquivo no lugar certo.
  LIVRE=""
  for _espera in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16; do
    sleep 0.5
    [ -z "$(lsof -ti "tcp:$PORT_APP" -sTCP:LISTEN 2>/dev/null)" ] && { LIVRE=1; break; }
    RESTA="$(lsof -ti "tcp:$PORT_APP" -sTCP:LISTEN 2>/dev/null | head -1)"
    [ "$_espera" = "6" ] && [ -n "$RESTA" ] && kill -9 "$RESTA" 2>/dev/null
  done
  if [ -z "$LIVRE" ]; then
    echo ""
    echo "[ERRO] Não consegui liberar a porta $PORT_APP — o outro OrçaPRO não desligou."
    echo ""
    echo "       Abra o Fechar-OrcaPRO.command da pasta:"
    echo "           $DONO"
    echo "       e tente de novo. (Reiniciar o Mac também resolve.)"
    echo ""
    read -r -p "Pressione Enter para fechar." _
    exit 1
  fi
  echo "  Porta liberada. Subindo esta instalação."
  echo ""
  JA=""
fi

if [ -n "$JA" ]; then
  echo "[OK] O OrçaPRO já estava aberto (porta $PORT_APP). Abrindo no navegador..."
else
  echo "[OK] Subindo o OrçaPRO IA (porta $PORT_APP)... a IA já vem pronta, roda na nuvem."
  # ⚠ SEM JANELA PRESA. `nohup ... &` solta o servidor do Terminal: fechar a
  #   janela depois não derruba o sistema. No Windows isso é feito pelo
  #   iniciar-oculto.vbs; aqui o nohup faz o mesmo papel.
  #   O log vai para um arquivo em vez de /dev/null porque, quando algo dá
  #   errado, ele é a única coisa que explica o quê.
  mkdir -p "$RAIZ/logs"
  PORT_APP="$PORT_APP" nohup "$NODE" "$RAIZ/server/static.js" \
    >> "$RAIZ/logs/orcapro.log" 2>&1 &
  disown 2>/dev/null || true

  # espera o servidor responder (até ~10 s) em vez de dormir um número fixo
  PRONTO=""
  for _tenta in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20; do
    sleep 0.5
    if curl -fsS --max-time 2 "http://localhost:$PORT_APP/index.html" >/dev/null 2>&1; then PRONTO=1; break; fi
  done
  if [ -z "$PRONTO" ]; then
    echo ""
    echo "[ERRO] O servidor não respondeu na porta $PORT_APP."
    echo "       O que aconteceu está no fim de: logs/orcapro.log"
    echo ""
    tail -n 12 "$RAIZ/logs/orcapro.log" 2>/dev/null
    echo ""
    read -r -p "Pressione Enter para fechar." _
    exit 1
  fi

  # ⚠ QUEM RESPONDEU FOI ESTA INSTALAÇÃO? "Alguém respondeu na porta" não é a
  #   mesma pergunta que "o meu servidor subiu". Se o antigo tiver sobrevivido,
  #   o teste acima passa e mandaríamos o usuário para o sistema errado dizendo
  #   que deu tudo certo. Aqui a resposta é conferida contra esta pasta.
  if command -v lsof >/dev/null 2>&1; then
    QUEM="$(lsof -ti "tcp:$PORT_APP" -sTCP:LISTEN 2>/dev/null | head -1)"
    ONDE=""
    [ -n "$QUEM" ] && ONDE="$(lsof -a -d cwd -p "$QUEM" -Fn 2>/dev/null | sed -n 's/^n//p' | head -1)"
    if [ -n "$ONDE" ] && [ "$ONDE" != "$RAIZ" ]; then
      echo ""
      echo "[ERRO] Quem está respondendo na porta $PORT_APP NÃO é esta instalação:"
      echo ""
      echo "    responde:   $ONDE"
      echo "    você abriu: $RAIZ"
      echo ""
      echo "       Não vou abrir o navegador — você veria o sistema da outra pasta"
      echo "       achando que é este. Abra o Fechar-OrcaPRO.command daquela pasta"
      echo "       e rode este de novo."
      echo ""
      read -r -p "Pressione Enter para fechar." _
      exit 1
    fi
  fi
fi

# `open` usa o navegador padrão do Mac. O parâmetro aleatório evita cache.
open "http://localhost:$PORT_APP/index.html?v=$RANDOM$RANDOM" >/dev/null 2>&1

echo ""
echo "OrçaPRO IA aberto no navegador. Pode fechar esta janela."
echo "(Para desligar o sistema depois, use o Fechar-OrcaPRO.command.)"
sleep 3
exit 0
