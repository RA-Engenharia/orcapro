/* =====================================================================
 * licenca.js — Licenciamento do OrçaPRO (trial + ativação por chave)
 * A licença é ASSINADA NO SERVIDOR (HMAC, segredo só no VPS). O app NÃO
 * guarda segredo nenhum: ele lê e-mail/validade da chave e DELEGA a
 * verificação ao servidor (/api/ativar), que controla a assinatura e a
 * trava de máquina. Por isso a chave não pode ser forjada no cliente.
 * ===================================================================== */
(function (global) {
  "use strict";

  // LOTE 5: teste grátis COMPLETO de 7 dias (salvar/exportar liberados na
  // janela; o início é ancorado NO SERVIDOR por dispositivo — trocar de
  // navegador não zera). Antes: "demonstração" que nunca salvava — ninguém
  // experimentava o entregável antes de pagar. Concorrência dá 7-30 dias.
  var TRIAL_MS = 7 * 24 * 3600 * 1000;
  var GRACE_MS = 7 * 24 * 3600 * 1000; // carência offline: até 7 dias sem reconectar; depois exige revalidação online
  var KEY = "orcapro:licenca";

  function agora() { return new Date().getTime(); }
  function rotuloTempo(ms) {
    if (ms <= 0) return "encerrado";
    var d = Math.floor(ms / 86400000), h = Math.floor((ms % 86400000) / 3600000), m = Math.floor((ms % 3600000) / 60000);
    if (d > 0) return d + "d " + h + "h";
    return h > 0 ? (h + "h" + (m < 10 ? "0" : "") + m) : (m + "min");
  }

  var Licenca = {
    _ler: function () { try { return JSON.parse(localStorage.getItem(KEY) || "null"); } catch (e) { return null; } },
    _gravar: function (o) { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} },
    chave: function () { var l = this._ler() || {}; return l.chave || ""; },

    /* ===== v1.1.233 — a identidade da máquina ancora no DISCO =====
       Só no localStorage, limpar os dados do site zerava o deviceId e o
       servidor abria outro trial de 7 dias — infinito, com dois cliques. O
       servidor local (que já serve o app) guarda o id num arquivo: na 1ª vez
       ele ADOTA o id que o navegador já tem (instalação ativada continua
       sendo o mesmo dispositivo); depois, storage limpo é RESTAURADO do
       disco. No PWA (sem servidor local) o fetch falha calado e fica o
       comportamento de sempre — o cerco fecha onde há onde ancorar. */
    sincronizarDevice: function () {
      try {
        if (typeof fetch === "undefined" || typeof localStorage === "undefined") return;
        var cur = null; try { cur = localStorage.getItem("orcapro:deviceid"); } catch (e) {}
        fetch("/__device" + (cur ? "?seed=" + encodeURIComponent(cur) : ""))
          .then(function (r) { return r.json(); })
          .then(function (j) {
            if (!j || !j.ok || !j.id) return;
            try { if (localStorage.getItem("orcapro:deviceid") !== j.id && !cur) localStorage.setItem("orcapro:deviceid", j.id); } catch (e2) {}
          })["catch"](function () {});
      } catch (e3) {}
    },

    // ID do dispositivo (gerado 1x e guardado) — base da trava anti-compartilhamento
    deviceId: function () {
      try {
        var k = "orcapro:deviceid", d = localStorage.getItem(k);
        if (!d) { d = (global.crypto && crypto.randomUUID) ? crypto.randomUUID() : (Date.now().toString(36) + Math.random().toString(36).slice(2, 12)); localStorage.setItem(k, d); }
        return d;
      } catch (e) { return "nodev"; }
    },
    _servidor: function () { return (typeof CONFIG !== "undefined" && CONFIG.licencaServer) ? String(CONFIG.licencaServer).replace(/\/$/, "") : ""; },
    _ehV2: function (chave) { return String(chave || "").indexOf("v2.") === 0; },
    // Lê email/exp do payload da chave (v2 ou v1) SEM verificar assinatura — só p/ exibir/checar validade
    _lerExpDe: function (chave) {
      try {
        var c = String(chave || "").trim(), s;
        if (c.indexOf("v2.") === 0) {
          var parts = c.split("."); if (parts.length !== 3) return null;
          s = parts[1].replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "=";
        } else {
          var i = c.lastIndexOf("-"); if (i < 0) return null;
          s = c.slice(0, i);
        }
        var payload = (typeof atob !== "undefined") ? atob(s) : Buffer.from(s, "base64").toString();
        var seg = payload.split("|");
        return { email: seg[0], exp: parseInt(seg[1], 10) || 0, tier: seg[2] || "" };
      } catch (e) { return null; }
    },
    /* ==================================================================
     * ESCADA DE PLANOS — e por que o tier do SERVIDOR pode subir o da chave.
     *
     * O tier viaja assinado dentro da chave (base|plus|bim). Isso resolve o
     * caso normal, mas trava um caso real: cliente que comprou o Plus e
     * ganhou o BIM numa promoção. Reemitir a chave obrigaria ele a reativar
     * tudo, e queimaria o slot de dispositivo.
     *
     * Então o servidor pode CONCEDER mais do que a chave diz, por um campo
     * no registro de ativação daquela chave (tierOverride). E a regra aqui é
     * de mão única: fica sempre o MAIOR entre o que a chave diz e o que o
     * servidor concedeu. Concessão nunca vira revogação — se o servidor
     * responder algo menor (registro incompleto, resposta velha em cache), o
     * cliente não perde o que pagou.
     * ================================================================== */
    TIERS: ["base", "plus", "bim"],
    _maiorTier: function (a, b) {
      var T = this.TIERS;
      var ia = T.indexOf(String(a || "").toLowerCase());
      var ib = T.indexOf(String(b || "").toLowerCase());
      if (ia < 0 && ib < 0) return String(a || b || "");   // tier desconhecido: devolve como veio
      return (ib > ia) ? T[ib] : (ia >= 0 ? T[ia] : T[ib]);
    },
    _ativarLocal: function (chave, v, verificado) {
      var l = this._ler() || {};
      l.chave = String(chave).trim(); l.email = v.email; l.expira = v.expira;
      /* o que o SERVIDOR disse — guardado para o status() poder subir o tier
         da chave. Nunca desce: ver _maiorTier. */
      if (v.tier) l.tierServidor = this._maiorTier(l.tierServidor, v.tier);
      l.ativadoEm = agora(); l.deviceId = this.deviceId();
      l.verificado = !!verificado; if (verificado) l.validadoEm = agora();
      this._gravar(l);
    },
    // Ativação ONLINE obrigatória p/ licenças v2: o servidor assina + trava o dispositivo (sem furo offline).
    ativarOnline: function (chave, cb) {
      var self = this, c = String(chave || "").trim();
      if (!this._ehV2(c)) { cb({ ok: false, erro: "Chave inválida." }); return; }
      var srv = this._servidor();
      if (!srv || typeof fetch === "undefined") { cb({ ok: false, erro: "Ative com a internet ligada — a licença é validada no servidor." }); return; }
      fetch(srv + "/api/ativar", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chave: c, deviceId: this.deviceId() }) })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          if (d && d.ok) { self._ativarLocal(c, { email: d.email, expira: d.expira, tier: d.tier }, true); cb({ ok: true, email: d.email, expira: d.expira, tier: d.tier || "" }); }
          else cb({ ok: false, erro: (d && d.erro) || "Não foi possível ativar." });
        }, function () { cb({ ok: false, erro: "Sem conexão com o servidor de licença. Tente novamente com a internet." }); });
    },
    // Revalida com o servidor: renova a carência e detecta bloqueio/troca de máquina.
    revalidar: function (cb) {
      cb = cb || function () {};
      var self = this, l = this._ler() || {};
      if (!l.chave || !l.verificado) { cb({ ok: true, skip: true }); return; }
      var srv = this._servidor(); if (!srv || typeof fetch === "undefined") { cb({ ok: true, offline: true }); return; }
      fetch(srv + "/api/ativar", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chave: l.chave, deviceId: this.deviceId() }) })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          if (d && d.ok) {
            l.validadoEm = agora(); l.email = d.email; l.expira = d.expira;
            // a revalidação é o caminho por onde uma concessão nova CHEGA a
            // quem já estava ativado — sem reativar, sem chave nova
            if (d.tier) l.tierServidor = self._maiorTier(l.tierServidor, d.tier);
            self._gravar(l); cb({ ok: true, tier: l.tierServidor || "" });
          }
          else if (d && d.bloqueado) { try { localStorage.removeItem(KEY); } catch (e) {} cb({ ok: false, bloqueado: true, erro: d.erro }); }
          else cb({ ok: true }); // recusa temporária: mantém (a carência cobre)
        }, function () { cb({ ok: true, offline: true }); });
    },
    // Ping de teste + ancora o início do trial no servidor (por dispositivo)
    registrarTeste: function () {
      try {
        var self = this, srv = this._servidor(); if (!srv || typeof fetch === "undefined") return;
        fetch(srv + "/api/teste", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ deviceId: this.deviceId() }) })
          .then(function (r) { return r.json(); })
          .then(function (d) {
            try {
              if (d && d.trialInicio) { var l = self._ler() || {}; if (!l.trialServidor || d.trialInicio < l.trialServidor) { l.trialServidor = d.trialInicio; self._gravar(l); } }
              localStorage.setItem("orcapro:teste_pingado", "1");
            } catch (e) {}
          }).catch(function () {});
      } catch (e) {}
    },

    status: function () {
      var l = this._ler() || {};
      if (l.chave) {
        var info = this._lerExpDe(l.chave);
        var expirada = !!(info && info.exp && info.exp < agora());
        if (l.verificado) {
          // v2: ativada e verificada pelo servidor; respeita validade + dispositivo + carência offline
          if (expirada) return { ativo: false, trial: false, expirada: true, email: (l.email || (info && info.email)) };
          if (l.deviceId && l.deviceId !== this.deviceId()) return { ativo: false, trial: false, outroDispositivo: true };
          var dias = (info && info.exp) ? Math.ceil((info.exp - agora()) / 86400000) : null;
          if (agora() < (l.validadoEm || 0) + GRACE_MS) {
            return { ativo: true, trial: false, email: l.email, expira: l.expira, diasRestantes: dias,
              /* o maior entre o que a chave carrega e o que o servidor concedeu */
              tier: this._maiorTier((info && info.tier) || "", l.tierServidor || "") };
          }
          return { ativo: false, trial: false, revalidar: true, email: l.email, diasRestantes: dias }; // carência vencida: reconectar
        }
        // chave presente mas sem ativação verificada pelo servidor -> não concede (cai p/ trial)
      }
      // trial: usa o início ancorado no servidor, se houver
      var ini = l.trialServidor || l.trialInicio;
      if (!ini) { ini = agora(); l.trialInicio = ini; this._gravar(l); }
      var fim = ini + TRIAL_MS;
      var rest = fim - agora();
      return { ativo: rest > 0, trial: true, expira: fim, expirado: rest <= 0, restanteMs: Math.max(0, rest), rotulo: rotuloTempo(rest) };
    }
  };

  global.Licenca = Licenca;
  // âncora da identidade no disco — roda no carregamento, sem depender de ninguém chamar
  try { if (typeof window !== "undefined") Licenca.sincronizarDevice(); } catch (eSd) {}
  if (typeof module !== "undefined" && module.exports) { module.exports = Licenca; }
})(typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this));
