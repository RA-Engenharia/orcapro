/* =====================================================================
 * ui.js — Renderização (telas, abas, modais, toasts, tabelas)
 * Consome o estado de app.js e os cálculos de orcamento.js.
 * ===================================================================== */
(function (global) {
  "use strict";

  var UI = {
    el: function (id) { return document.getElementById(id); },

    /* =================================================================
     * RÓTULO COM ÍCONE — título de modal, botão de rodapé e toast
     *
     * ⚠ POR QUE ISTO EXISTE (09/08/2026, v1.1.190 já na frota):
     * Esses três lugares são slots de TEXTO (`textContent` / `Util.esc`).
     * Quando os emoji viraram ícones próprios, passou-se a inlinar
     * `Icones.get(...)` — que devolve MARKUP — dentro deles. Resultado no
     * cliente: o título do modal virou o código-fonte do SVG, literalmente
     * `<svg class="ic-svg" viewBox="0 0 24 24" …> Composição 92543`.
     * São 50 títulos, 32 botões de rodapé e 46 toasts com o mesmo defeito.
     *
     * ⚠ E A CORREÇÃO NÃO PODE SER "DEIXAR O SVG PASSAR".
     * Por estes rótulos passa dado que não é nosso: nome de obra, e-mail e,
     * em uma dúzia de pontos, a mensagem de erro que o SERVIDOR devolveu
     * (`UI.toast(r.erro)`). Desescapar o trecho que "parece ícone" abriria
     * execução de script — provei que `<svg class="ic-svg"><animate
     * onbegin="…">` dispara.
     * Por isso aqui o ícone é REGENERADO a partir do nome (`data-ic`), nunca
     * recolado: mesmo que alguém digite o markup inteiro num campo, o pior
     * que acontece é aparecer um ícone da nossa própria biblioteca.
     * ================================================================= */
    _rotuloHtml: function (txt) {
      var s = String(txt == null ? "" : txt);
      if (typeof Icones === "undefined" || s.indexOf('class="ic-svg"') < 0) return Util.esc(s);
      var re = /<svg class="ic-svg" data-ic="([A-Za-z0-9_-]+)"[^>]*width="(\d+)"[^>]*>[\s\S]*?<\/svg>/g;
      var out = "", ultimo = 0, m;
      /* laço global: o ícone aparece no começo, no meio e às vezes três vezes
         no mesmo toast — uma versão ancorada em `^` cobriria só metade */
      while ((m = re.exec(s)) !== null) {
        out += Util.esc(s.slice(ultimo, m.index));
        out += (Icones.tem(m[1]) ? Icones.get(m[1], Number(m[2]) || 15) : "");
        ultimo = m.index + m[0].length;
      }
      return out + Util.esc(s.slice(ultimo));
    },
    _rotulo: function (el, txt) {
      var s = String(txt == null ? "" : txt);
      if (typeof Icones === "undefined" || s.indexOf('class="ic-svg"') < 0) { el.textContent = s; return; }
      el.innerHTML = this._rotuloHtml(s);
    },

    // ---------- Toast ----------
    toast: function (msg, tipo) {
      var wrap = this.el("toasts");
      var t = document.createElement("div");
      t.className = "toast " + (tipo || "");
      this._rotulo(t, msg);
      wrap.appendChild(t);
      setTimeout(function () { t.style.opacity = "0"; setTimeout(function () { t.remove(); }, 250); }, 2600);
    },

    // ---------- Modal ----------
    modal: function (titulo, corpoHTML, rodapeBotoes) {
      this.fecharModal();
      var bg = document.createElement("div");
      bg.className = "modal-bg"; bg.id = "modal-bg";
      bg.innerHTML =
        '<div class="modal"><header><h2>' + this._rotuloHtml(titulo) + '</h2>' +
        '<span style="flex:1"></span><button class="btn ghost sm" data-fechar>' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + '</button></header>' +
        '<div class="body">' + corpoHTML + '</div>' +
        '<footer id="modal-footer"></footer></div>';
      document.body.appendChild(bg);
      var footer = bg.querySelector("#modal-footer");
      (rodapeBotoes || []).forEach(function (b) {
        var btn = document.createElement("button");
        btn.className = "btn " + (b.classe || "");
        UI._rotulo(btn, b.texto);
        btn.onclick = b.onClick;
        footer.appendChild(btn);
      });
      /* FECHAR NO CLIQUE-FORA SÓ QUANDO O GESTO COMEÇOU FORA.
         O navegador sintetiza o click no ANCESTRAL COMUM quando mousedown e
         mouseup têm alvos diferentes — selecionar o texto de um input
         arrastando e soltar fora da caixa disparava click no véu e fechava
         o modal, levando junto tudo que o usuário digitou (reproduzido:
         mousedown no #cp-descricao + mouseup fora = formulário perdido).
         Guardar o alvo do mousedown separa o clique real no fundo do
         acidente de seleção. */
      bg._downNoBg = false;
      bg.addEventListener("mousedown", function (e) { bg._downNoBg = (e.target === bg); });
      /* QUALQUER digitação marca o modal como "tem trabalho": a guarda vale
         para todo formulário do app sem precisar instrumentar um a um */
      bg.addEventListener("input", function () { bg._tocado = true; });
      bg.addEventListener("change", function () { bg._tocado = true; });
      bg.addEventListener("click", function (e) {
        /* ⚠ O ALVO DE UM TOQUE SOBRE ÍCONE NUNCA É O BOTÃO.
           `data-fechar` está no <button>, mas o conteúdo dele é um <svg>
           inline: o alvo do evento é o <svg> ou o <path>, jamais o <button>
           que os contém. Com a comparação direta, o ✕ só fechava quando o
           clique caía no anel de padding em volta do ícone de 15px — no mouse
           o usuário tem hover e acerta a borda; no dedo o alvo é o centro, e
           o modal simplesmente não fechava. Subir a árvore com `closest`
           resolve, e `getAttribute` no fallback cobre navegador sem closest. */
        var alvoFechar = null;
        try { alvoFechar = e.target.closest ? e.target.closest("[data-fechar]") : null; } catch (eC) {}
        if (!alvoFechar) {
          var n = e.target;
          while (n && n !== bg) { if (n.hasAttribute && n.hasAttribute("data-fechar")) { alvoFechar = n; break; } n = n.parentNode; }
        }
        var fechar = !!alvoFechar || (e.target === bg && bg._downNoBg);
        if (!fechar) return;
        /* v1.1.235 — modal BLOQUEANTE (o do teste grátis): fechar deixaria o
           app numa tela branca, porque o gate aborta o boot antes do render */
        if (bg.dataset && bg.dataset.semFecharFora === "1") return;
        /* a confirmação é SÓ para gesto do usuário (véu/✕). Fluxos de salvar
           fecham por UI.fecharModal() direto e não podem ganhar pergunta. */
        if (UI.temTrabalhoNaoSalvo() &&
            !window.confirm("Há informações não salvas neste formulário. Fechar e perder o que foi preenchido?")) return;
        UI.fecharModal();
      });
      return bg;
    },
    /* "sujo" = usuário digitou algo no modal aberto. Um modal pode refinar
       com UI.modalSujo(fn) — fn decide (ex.: criador de composição, que
       re-renderiza o corpo e perderia o _tocado do DOM). */
    _modalDirty: null,
    _modalConsulta: false,
    /* modalSujo REFINA PARA CIMA, nunca rebaixa: o fn do criador lia um
       estado que só sincroniza no "Próximo →", e digitar no passo 1 ficava
       DESPROTEGIDO (o fn dizia limpo e vencia o _tocado do DOM). Agora é
       fn() OU _tocado. Modal somente-consulta (busca, detalhamento) usa
       modalConsulta(): nunca pergunta — pergunta falsa treina o usuário a
       dar OK no reflexo e corrói a que protege de verdade. */
    modalSujo: function (fn) { this._modalDirty = fn || null; this._modalConsulta = false; },
    modalConsulta: function () { this._modalDirty = null; this._modalConsulta = true; },
    temTrabalhoNaoSalvo: function () {
      var m = this.el("modal-bg"); if (!m) return false;
      if (this._modalConsulta) return false;
      var fnDiz = false;
      try { fnDiz = !!(this._modalDirty && this._modalDirty()); } catch (e) {}
      return fnDiz || !!m._tocado;
    },
    fecharModal: function () { this._modalDirty = null; this._modalConsulta = false; var m = this.el("modal-bg"); if (m) m.remove(); },

    // LOTE 5: overlay de carregamento p/ operações longas (analítico 17MB, IA).
    // Sem isso o app parece travado e a primeira impressão morre ali.
    loading: function (msg) {
      this.loadingFim();
      if (!document.getElementById("ui-loading-css")) {
        var s = document.createElement("style"); s.id = "ui-loading-css";
        s.textContent = "@keyframes uiSpin{to{transform:rotate(360deg)}}";
        document.head.appendChild(s);
      }
      var d = document.createElement("div");
      d.id = "ui-loading";
      d.style.cssText = "position:fixed;inset:0;background:rgba(15,39,64,.45);z-index:9999;display:flex;align-items:center;justify-content:center";
      d.innerHTML = '<div style="background:#fff;border-radius:12px;padding:18px 26px;font-weight:600;color:#1e293b;box-shadow:0 18px 50px rgba(0,0,0,.3);display:flex;gap:12px;align-items:center">' +
        '<span style="width:18px;height:18px;border:3px solid #cbd5e1;border-top-color:#2e6f9e;border-radius:50%;display:inline-block;animation:uiSpin .8s linear infinite"></span>' +
        Util.esc(msg || "Carregando…") + "</div>";
      document.body.appendChild(d);
    },
    loadingFim: function () { var d = document.getElementById("ui-loading"); if (d) d.remove(); },

    // ---------- Topbar ----------
    renderTopbar: function (usuario) {
      var plano = usuario.plano || "FREE";
      var freeCls = plano === "FREE" ? "free" : "";
      var admin = usuario.papel !== "usuario"; // sub-usuário não vê ações de dono (empresa/licença/backup)
      var deptoLbl = (usuario.departamento && typeof Gestao !== "undefined" && Gestao.rot) ? Gestao.rot(Gestao.P.departamento, usuario.departamento) : (usuario.departamento || "usuário");
      return '' +
        '<button class="topbar-burger" data-acao="menu" aria-label="Menu de módulos" title="Módulos">☰</button>' +
        '<div class="logo" style="display:flex;align-items:center;gap:10px">' +
          '<svg width="34" height="34" viewBox="0 0 100 100" style="flex:none"><defs><linearGradient id="tbg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#163a5c"/><stop offset="1" stop-color="#2e6f9e"/></linearGradient></defs><rect x="2" y="2" width="96" height="96" rx="24" fill="url(#tbg)"/><rect x="24" y="52" width="13" height="22" rx="4" fill="#fff" opacity=".55"/><rect x="44" y="38" width="13" height="36" rx="4" fill="#fff" opacity=".9"/><rect x="64" y="24" width="13" height="50" rx="4" fill="#6fd08a"/><path d="M73 10 l2.4 5.1 5.6 .7 -4.1 3.9 1 5.6 -4.9 -2.7 -4.9 2.7 1 -5.6 -4.1 -3.9 5.6 -.7z" fill="#9be7af"/></svg>' +
          '<div style="display:flex;flex-direction:column;line-height:1.05">' + CONFIG.marca.logoTexto + '<small>' + CONFIG.marca.slogan + ' · <span style="opacity:.85">v' + CONFIG.versao + '</span></small></div>' +
        '</div>' +
        '<span class="badge-plano ' + freeCls + '">' + (CONFIG.planos[plano] ? CONFIG.planos[plano].nome : plano) + '</span>' +
        '<span class="spacer"></span>' +
        /* ⚠ INSTALAR COMO APP MORA NA BARRA, NÃO FLUTUANDO — e não some.
           O botão anterior era um balão no canto inferior direito que (a) só
           nascia no evento `beforeinstallprompt`, que NÃO EXISTE no iOS, então
           iPhone e iPad nunca viam; (b) tinha um ✕ que gravava dispensa
           PERMANENTE em localStorage — um clique sem querer e ele não voltava
           nunca mais; e (c) disputava o canto com o FAB do BIM.
           Aqui ele é parte da barra: aparece sempre que o app NÃO está
           instalado, em qualquer aparelho, e desaparece sozinho quando passa
           a rodar em modo standalone — que é o único motivo legítimo de
           sumir. */
        (function () {
          var jaInstalado = false;
          try { jaInstalado = window.matchMedia("(display-mode: standalone)").matches || navigator.standalone === true; } catch (eI) {}
          if (jaInstalado) return "";
          return '<button class="topo-ic-btn topo-instalar" data-acao="instalar-app" aria-label="Instalar o OrçaPRO como aplicativo" title="Instalar o OrçaPRO IA como aplicativo — ícone na tela inicial, tela cheia e abre offline">' +
            (typeof Icones !== "undefined" ? Icones.get("baixar", 15) : "") + '<span class="topo-instalar-txt">Instalar app</span></button>';
        })() +
        '<button class="topo-ic-btn" data-busca-abrir aria-label="Busca universal (Ctrl+K)" title="Busca universal — pule pra qualquer obra, orçamento ou ação (Ctrl+K)">' + (typeof Icones !== 'undefined' ? Icones.get('buscar', 15) : '') + '<span class="topo-kbd">Ctrl+K</span></button>' +
        (function () {
          var n = (typeof AvisosUI !== "undefined") ? AvisosUI.contar() : 0;
          return '<button class="topo-ic-btn" data-avisos-abrir aria-label="Central de avisos" title="Central de avisos — medições a aprovar, tarefas atrasadas e restrições">' + (typeof Icones !== "undefined" ? Icones.solo("sino", 17) : "") +
            (n ? '<span class="aviso-badge">' + (n > 99 ? "99+" : n) + "</span>" : "") + "</button>";
        })() +
        '<div class="topbar-conta">' +
          '<button class="conta-btn" data-acao="conta" aria-label="Conta e configurações" title="Conta e configurações">' +
            /* A MARCA DE QUEM ESTA USANDO, NAO A NOSSA.
               O logo da empresa ja existia e so aparecia nos impressos. Na
               barra do topo ele diz, o dia inteiro, de quem e aquele sistema —
               que e o que faz o cliente sentir que o programa e da empresa
               dele. Sem logo, cai no ⚙ de sempre: nada quebra. */
            /* o tamanho desta imagem NÃO depende só do css/app.css: veja
               UI.chaoDeEstilo(), no fim deste arquivo — ele existe porque um
               tablet do cliente abriu o logo em 1200px por causa de folha de
               estilo velha presa no cache do service worker */
            (function () {
              var lg = (typeof Empresa !== "undefined" && Empresa.logo) ? Empresa.logo() : "";
              if (lg) return '<img class="conta-logo" src="' + lg + '" alt="">';
              return '<span class="conta-ic">' + (typeof Icones !== 'undefined' ? Icones.get('ajustes', 15) : '') + '</span>';
            })() +
            /* ⚠ O NOME QUE APARECE AQUI É O DA EMPRESA DO CLIENTE.
               `usuario.empresa` vem da CONTA/licença — no cliente que comprou,
               isso mostrava o nome de quem vendeu o sistema, não o dele. Ele
               abria o próprio OrçaPRO e via outra empresa na barra o dia
               inteiro. O nome certo é o que ele cadastrou em ⚙ Empresa, que é
               o mesmo que já sai nos documentos (Empresa.nomeDoc). */
            '<span class="conta-nome">' + Util.esc(
              (typeof Empresa !== "undefined" && Empresa.nomeDoc && Empresa.nomeDoc()) || usuario.empresa
            ) + '</span>' +
            /* e a foto de QUEM esta logado: sem foto, as iniciais — melhor que
               um bonequinho generico, porque a pessoa se reconhece de relance */
            (function () {
              var f = (typeof Empresa !== "undefined" && Empresa.fotoUsuario) ? Empresa.fotoUsuario() : "";
              /* ⚠ `usuario.nome` cai na EMPRESA quando o dono nao preencheu o
                 proprio nome — era o circulo do topo mostrando as iniciais da
                 razao social. `Auth.nome()` ja resolve pessoa antes de empresa. */
              var quem = (typeof Auth !== "undefined" && Auth.nome && Auth.nome()) || usuario.empresa || usuario.email || "";
              if (f) return '<img class="conta-foto" src="' + f + '" alt="" title="' + Util.esc(quem) + '">';
              var ini = (typeof Empresa !== "undefined" && Empresa.iniciais) ? Empresa.iniciais(quem) : "?";
              return '<span class="conta-foto ini" title="' + Util.esc(quem) + '">' + Util.esc(ini) + '</span>';
            })() +
            '<span class="conta-ca">▾</span>' +
          '</button>' +
          '<div class="conta-drop">' +
            '<div class="conta-cab"><b>' + Util.esc(usuario.empresa) + '</b><span>' + (function () {
              /* o cabecalho do menu responde "quem sou eu nesta conta": a
                 empresa em cima, a PESSOA embaixo. O dono so via o e-mail. */
              var pes = (typeof Auth !== "undefined" && Auth.nomePessoal) ? Auth.nomePessoal() : "";
              /* ⚠ o separador só entra quando há os DOIS lados. A conta de
                 demonstração não tem e-mail, e a primeira versão desta linha
                 deixava um "Rogério Souza ·" com o ponto pendurado no vazio. */
              if (admin) return Util.esc([pes, usuario.email].filter(Boolean).join(' · '));
              return Util.esc(pes || usuario.nome || usuario.email) + ' · ' + Util.esc(deptoLbl);
            })() + '</span></div>' +
            (function () {
              if (!admin) return "";
              var lic = (typeof Licenca !== "undefined") ? Licenca.status() : null;
              if (!lic) return "";
              var lbl, alerta = false;
              // LOTE 5: trial 7 dias completo — mostra o tempo restante e acende no fim
              if (lic.trial && lic.ativo) { lbl = "Teste grátis: " + (lic.rotulo || "") + " restantes"; alerta = (lic.restanteMs || 0) < 2 * 86400000; }
              else if (lic.trial) { lbl = "Teste encerrado (ativar licença)"; alerta = true; }
              else if (lic.expirada) { lbl = "Licença vencida"; alerta = true; }
              else if (lic.outroDispositivo) { lbl = "Ativada em outra máquina"; alerta = true; }
              else if (lic.revalidar) { lbl = "Reconecte para validar"; alerta = true; }
              else if (lic.diasRestantes != null) { lbl = "Licença: " + lic.diasRestantes + " dias"; alerta = lic.diasRestantes <= 7; }
              else lbl = "Licenciado";
              return '<button class="conta-item' + (alerta ? " alerta" : "") + '" data-acao="licenca"><span>' + (typeof Icones !== 'undefined' ? Icones.get('chave', 15) : '') + '</span>' + Util.esc(lbl) + '</button>';
            })() +
            (admin ? '<button class="conta-item" data-acao="empresa"><span>' + (typeof Icones !== 'undefined' ? Icones.get('ajustes', 15) : '') + '</span>Dados da empresa</button>' : '') +
            '<button class="conta-item" data-acao="tabelas"><span>' + (typeof Icones !== 'undefined' ? Icones.get('tabela', 15) : '') + '</span>Tabelas de preço</button>' +
            (admin ? '<button class="conta-item" data-acao="nuvem"><span>' + (typeof Icones !== 'undefined' ? Icones.get('nuvem', 15) : '') + '</span>Nuvem — sincronizar aparelhos</button>' : '') +
            (admin ? '<button class="conta-item" data-acao="celular"><span>' + (typeof Icones !== 'undefined' ? Icones.get('celular', 15) : '') + '</span>Usar no celular ou tablet</button>' : '') +
            (admin ? '<button class="conta-item" data-acao="backup"><span>' + (typeof Icones !== 'undefined' ? Icones.get('salvar', 15) : '') + '</span>Backup dos dados</button>' : '') +
            '<button class="conta-item" data-acao="minha-foto"><span>' + (typeof Icones !== 'undefined' ? Icones.get('pessoa', 15) : '') + '</span>Meu perfil — nome e foto</button>' +
            '<button class="conta-item" data-acao="tema"><span>' + (typeof Icones !== 'undefined' ? Icones.get('paleta', 15) : '') + '</span>Tema do aplicativo</button>' +
            '<button class="conta-item" data-acao="atualizar"><span>' + (typeof Icones !== 'undefined' ? Icones.get('ciclo', 15) : '') + '</span>Buscar atualização</button>' +
            /* ⚠ SÓ NA MÁQUINA DE QUEM IMPLANTA. `PreviewCli.disponiveis()` lê o
               catálogo privado (venda/perfis-clientes.js), que não vai em pacote
               nenhum — no cliente a lista é vazia e este item não existe. É o
               mesmo tipo de gate do Painel de Apresentação: o segredo é o
               arquivo ausente, não uma flag que dê para ligar. */
            ((typeof PreviewCli !== "undefined" && PreviewCli.disponiveis().length && !PreviewCli.ativo())
              ? '<div class="conta-sep"></div><button class="conta-item" data-acao="previa-abrir"><span>'
                + (typeof Icones !== 'undefined' ? Icones.get('olho', 15) : '') + '</span>Ver a versão de um cliente</button>'
              : '') +
            '<div class="conta-sep"></div>' +
            '<button class="conta-item sair" data-acao="logout"><span>' + (typeof Icones !== 'undefined' ? Icones.get('porta', 15) : '') + '</span>Sair</button>' +
            '<div class="conta-sep"></div>' +
            '<div style="padding:4px 12px 6px;font-size:11.5px;color:var(--texto-fraco);text-align:center">' + Util.esc(CONFIG.marca.nomeProduto || "OrçaPRO IA") + ' · <b>v' + Util.esc(CONFIG.versao) + '</b></div>' +
          '</div>' +
        '</div>';
    },

    // ---------- Atualizar tabelas (backend sinapi-fetcher) ----------
    renderAtualizar: function (info) {
      if (!info.online) {
        return '<div class="vazio card">⚠️ <b>Backend offline.</b><br>O atualizador automático usa o servidor <b>sinapi-fetcher</b> do ERP (porta 3040). ' +
          'Ligue o ERP/servidor e tente de novo — ou use <b>' + (typeof Icones !== 'undefined' ? Icones.get('tabela', 15) : '') + ' Tabelas</b> / <b>' + (typeof Icones !== 'undefined' ? Icones.get('importar', 15) : '') + ' Importar base SINAPI</b> para subir o arquivo manualmente.</div>';
      }
      var html = '<p>Backend <b style="color:var(--verde,#16a34a)">conectado</b> · base atual no app: <b>' + Util.esc(info.atual || "—") + ' / ' + Util.esc(info.uf) + '</b></p>';
      if (info.desatualizado) {
        html += '<div class="card" style="border-color:var(--amarelo,#f59e0b)">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Competência mais nova disponível na Caixa: <b>' + Util.esc(info.ultimaOficial || info.ultimaCache) + '</b></div>';
      } else {
        html += '<div class="muted mb">' + (typeof Icones !== 'undefined' ? Icones.get('check', 15) : '') + ' Sua base está na competência mais recente.</div>';
      }
      html += '<h3 style="margin:12px 0 6px">Competências prontas no cache</h3>';
      if (info.cacheMeses.length) {
        html += '<div class="flex" style="flex-wrap:wrap;gap:8px">' + info.cacheMeses.map(function (m) {
          return '<button class="btn sm ' + (m === info.atual ? "" : "primary") + '" data-atz-carregar="' + Util.esc(m) + '">' + (m === info.atual ? "✔ " : "⬇ ") + Util.esc(m) + '</button>';
        }).join("") + '</div>';
      } else { html += '<p class="muted">Nenhuma no cache.</p>'; }
      if (info.ultimaOficial && info.cacheMeses.indexOf(info.ultimaOficial) === -1) {
        html += '<h3 style="margin:14px 0 6px">Baixar da Caixa</h3>' +
          '<button class="btn sm success" data-atz-baixar="' + Util.esc(info.ultimaOficial) + '">' + (typeof Icones !== 'undefined' ? Icones.get('baixar', 15) : '') + ' Baixar ' + Util.esc(info.ultimaOficial) + ' (30–60s)</button>';
      }
      return html;
    },

    /* ==================================================================
     * BASES PRONTAS — uma linha por banco, dirigida pelo CATÁLOGO.
     *
     * ⚠ AQUI MORAVAM TRÊS DOS QUATRO CAMINHOS DE INSTALAÇÃO. Eram cinco
     * botões `data-inclusa` com o caminho do arquivo escrito na mão, mais um
     * bloco de selects para o SETOP (`carregar-setop`) e outro para a GOINFRA
     * (`carregar-goinfra`) — cada um com a sua ideia de qual é o padrão. Foi
     * assim que a GOINFRA acabou com DOIS defaults para o mesmo dado: um no
     * `<option>` desta tela e outro no `|| "onerada"` do handler.
     *
     * Agora a lista sai de BasesCat: os eixos de variante, os rótulos, o
     * arquivo e o peso vêm todos da mesma fonte que o Passo 3 do assistente
     * usa. Banco novo no catálogo aparece aqui sozinho; banco sem fonte não
     * aparece de jeito nenhum, porque nem está no catálogo.
     * ================================================================== */
    _basesProntas: function (lista, srv) {
      if (typeof BasesCat === "undefined") return '<p class="muted">Catálogo de bancos indisponível.</p>';
      var inst = {};
      (lista || []).forEach(function (b) { inst[b.fonte] = b; });
      /* o que o servidor anunciou na última consulta: é daqui que saem as UFs
         do SICRO e da SINAPI desonerada. Sem isso, a linha aparece sem opção
         de Local — que é o certo: não se oferece estado que não foi publicado. */
      srv = srv || {};
      var ctxSrv = {
        instaladas: inst,
        sicroUfs: (srv.sicroUfs || []).map(function (u) { return { v: u, r: u }; }),
        sinapiDesUfs: (srv.sinapiDesoneradaUfs || []).map(function (u) { return { v: u, r: u }; })
      };
      var ic = (typeof Icones !== "undefined") ? Icones.get("estoque", 15) : "";
      var linhas = BasesCat.CATALOGO.filter(function (e) {
        return !e.principal && !(e.entrega && e.entrega.autoral);
      }).map(function (e) {
        var jaTem = inst[e.id];
        var av = BasesCat.avaliar(e, ctxSrv);
        var eixos = (e.eixos || []).filter(function (x) { return BasesCat.opcoesDoEixo(e, x, ctxSrv).length > 1; });
        var selects = eixos.map(function (ex) {
          var atual = (jaTem && jaTem.sel && jaTem.sel[ex.id]) || ex.padrao;
          /* largura travada: com dois eixos (SETOP, AGETOP) os selects em
             tamanho natural empurravam o botão para a linha de baixo e a
             lista perdia o alinhamento de coluna */
          return '<select id="tabi-' + Util.esc(e.id) + "-" + Util.esc(ex.id) + '" class="btn sm" style="padding:5px;max-width:150px" ' +
            'aria-label="' + Util.esc(ex.rotulo + " de " + e.nome) + '">' +
            BasesCat.opcoesDoEixo(e, ex, ctxSrv).map(function (o) {
              return '<option value="' + Util.esc(o.v) + '"' + (String(o.v) === String(atual) ? " selected" : "") + ">" + Util.esc(o.r || o.v) + "</option>";
            }).join("") + "</select>";
        }).join("");
        return '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:7px 0;border-bottom:1px dashed var(--linha)">' +
          '<b style="font-size:12.5px;min-width:92px">' + Util.esc(e.nome) + "</b>" +
          '<span class="muted" style="font-size:11.5px;flex:1;min-width:150px">' + Util.esc(e.localRotulo || e.uf) +
          " · " + Util.esc(BasesCat.fmtVersao(av.versao) || "—") +
          (e.pesoMb ? " · " + String(e.pesoMb).replace(".", ",") + " MB" : "") + "</span>" +
          selects +
          '<button class="btn sm ' + (jaTem ? "" : "primary") + '" data-instalar="' + Util.esc(e.id) + '">' + ic + " " +
          (jaTem ? "Reinstalar" : "Instalar") + "</button></div>";
      }).join("");
      return '<p class="muted" style="font-size:12px;margin:-2px 0 8px">O app tenta primeiro a versão mais nova no servidor da RA e cai no arquivo que veio no pacote se estiver sem internet.</p>' +
        '<div style="margin-bottom:6px">' + linhas + "</div>";
    },

    // ---------- Tabelas de Preço (multi-base) ----------
    renderTabelas: function (lista) {
      var rows = (lista || []).map(function (b) {
        /* v1.1.203 — a VARIANTE carregada aparece aqui. Sem isto, uma SETOP
           instalada na região Central e outra em Triângulo eram
           indistinguíveis na tela, e como só existe UMA cópia de cada banco
           no app, era impossível saber qual preço estava valendo. */
        var varTxt = "";
        try {
          if (b.sel && typeof BasesCat !== "undefined") {
            var e = BasesCat.get(b.catId || b.fonte), p = [];
            Object.keys(b.sel).forEach(function (k) {
              var v = b.sel[k];
              if (e) (e.eixos || []).forEach(function (ex) {
                if (ex.id !== k) return;
                (ex.opcoes || []).forEach(function (o) { if (String(o.v) === String(v)) v = o.r; });
              });
              if (v) p.push(v);
            });
            if (p.length) varTxt = '<small style="display:block;opacity:.7">' + Util.esc(p.join(" · ")) + "</small>";
          }
        } catch (eV) {}
        var comp = (typeof BasesCat !== "undefined" && BasesCat.fmtVersao) ? (BasesCat.fmtVersao(b.competencia) || "—") : (b.competencia || "—");
        /* ⚠ desativada por estar em OUTRA UF não é o mesmo que desmarcada
           pelo usuário — e o checkbox mostra a ESCOLHA, não a circunstância */
        var porUf = b.inativaPorUf ? '<small style="display:block;color:#b45309">silenciada: base de ' + Util.esc(b.uf || "?") + ', a atual é outra UF</small>' : "";
        return '<tr><td><span class="pill ' + (b.cor || "proprio") + '">' + Util.esc(b.label) + '</span>' + varTxt + '</td>' +
          '<td>' + Util.esc(comp + " / " + (b.uf || "—")) + '</td>' +
          '<td class="num">' + (b.total || 0).toLocaleString("pt-BR") + '</td>' +
          '<td><label style="cursor:pointer"><input type="checkbox" data-base-toggle="' + Util.esc(b.fonte) + '"' + (b.ativaUsuario !== false ? " checked" : "") + '> ativa</label>' + porUf + '</td>' +
          '<td class="right">' + (b.fonte === "PROPRIA" ? '<button class="btn sm" data-acao="minhas-composicoes">' + (typeof Icones !== 'undefined' ? Icones.get('checklist', 15) : '') + ' ver itens</button> ' : '') +
            (b.fonte !== "SINAPI" ? '<button class="btn sm danger" data-base-remover="' + Util.esc(b.fonte) + '">remover</button>' : '') + '</td></tr>';
      }).join("");
      var fontes = (typeof Bases !== "undefined" && Bases.META) ? Object.keys(Bases.META).filter(function (k) { return k !== "SINAPI"; }) : ["SICRO", "SEINFRA", "SETOP", "ORSE", "SUDECAP", "SBC", "PROPRIA"];
      var opts = fontes.map(function (x) { var m = (typeof Bases !== "undefined" && Bases.META && Bases.META[x]) || {}; return '<option value="' + x + '">' + Util.esc(m.label || x) + '</option>'; }).join("");
      // v1.1.122 — Central de Atualização: 1 botão por banco; o servidor OrçaPRO
      // responde a competência mais recente e QUANDO entrou no ar. Sem novidade,
      // a resposta é honesta: "sem atualização — a última é a de tal data".
      var _icT = function (n) { return (typeof Icones !== "undefined") ? Icones.get(n, 14) : ""; };
      var compSin = (typeof Atualizacao !== "undefined" && Atualizacao.fmtComp) ? Atualizacao.fmtComp(Sinapi.competencia) : (Sinapi.competencia || "—");
      /* Os bancos que TÊM canal de atualização saem do catálogo (quem declara
         `chaveStatus`), não de um array escrito aqui — era a quarta cópia da
         mesma informação, e foi por causa dela que a GOINFRA precisava de um
         desvio próprio no handler. */
      var comCanal = (typeof BasesCat !== "undefined")
        ? BasesCat.CATALOGO.filter(function (e) { return e.chaveStatus && !e.principal; })
        : [];
      var atuLinhas = '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:8px 0;border-bottom:1px dashed var(--linha)">' +
        '<span class="pill sinapi">SINAPI</span><span style="font-size:12.5px">competência ativa: <b>' + Util.esc(compSin) + '</b> · ' + Util.esc(String(Sinapi.uf || "")) + '</span>' +
        '<button class="btn sm primary" data-atu-base="SINAPI" style="margin-left:auto">' + _icT("reimportar") + 'Verificar atualização</button>' +
        '<span class="muted" id="atu-st-SINAPI" style="flex-basis:100%;font-size:11.5px"></span></div>';
      comCanal.forEach(function (e) {
        var inst = (lista || []).filter(function (b) { return String(b.fonte).toUpperCase() === e.id; })[0];
        var comp = inst ? (BasesCat.fmtVersao(inst.competencia) || "—") : "";
        atuLinhas += '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:8px 0;border-bottom:1px dashed var(--linha)">' +
          '<span class="pill ' + Util.esc((inst && inst.cor) || "proprio") + '">' + Util.esc(e.nome) + '</span>' +
          '<span style="font-size:12.5px">' + (inst ? "competência ativa: <b>" + Util.esc(comp) + "</b> · " + Util.esc(inst.uf || "") : '<span class="muted">não instalada — instale nos botões ' + (typeof Icones !== 'undefined' ? Icones.get('estoque', 15) : '') + ' abaixo</span>') + '</span>' +
          '<button class="btn sm" data-atu-base="' + Util.esc(e.id) + '" style="margin-left:auto">' + _icT("reimportar") + 'Verificar atualização</button>' +
          '<span class="muted" id="atu-st-' + Util.esc(e.id) + '" style="flex-basis:100%;font-size:11.5px"></span></div>';
      });
      return '<h3 style="margin:0 0 6px;display:flex;align-items:center">' + _icT("reimportar") + 'Atualização dos bancos de preço</h3>' +
        '<p class="muted" style="font-size:12px;margin:0 0 8px">O sistema confere no servidor OrçaPRO se há competência nova e aplica na hora. A SINAPI também se atualiza <b>sozinha</b> (1× por dia, silencioso).</p>' +
        '<div style="margin-bottom:16px">' + atuLinhas + '</div>' +
        '<p class="muted mb">Habilite/priorize bancos de preço. A busca de itens varre todas as bases <b>ativas</b> (badge mostra a origem). A SINAPI continua padrão.</p>' +
        '<table class="tbl"><thead><tr><th>Base</th><th>Competência/UF</th><th class="num">Itens</th><th>Status</th><th></th></tr></thead><tbody>' +
        (rows || '<tr><td colspan="5">—</td></tr>') + '</tbody></table>' +
        '<h3 style="margin:18px 0 8px;display:flex;align-items:center">' + _icT("mais") + 'Criar composição própria</h3>' +
        '<p class="muted" style="font-size:12px;margin:-2px 0 8px">Monte a SUA composição (código PROP-XXXX): informações gerais + estrutura de insumos pescada das bases reais, com custo no seu método de cálculo. O <b>agente especialista</b> propõe a estrutura pela referência oficial mais parecida — nada é inventado e tudo passa por um checklist duro antes de gravar.</p>' +
        '<button class="btn primary" data-acao="criar-composicao" style="margin-bottom:10px">' + _icT("escopo") + 'Criar composição própria</button>' +
        '<h3 style="margin:18px 0 8px">Importar base extra</h3>' +
        '<p class="muted" style="font-size:12px;margin:-2px 0 8px">Carregue a <b>planilha oficial da base do seu estado</b> (EMOP-RJ, CPOS/FDE-SP, ORSE-SE, AGETOP-GO…). O detector reconhece as colunas (código, descrição, unidade, custo) sozinho — nada é inventado.</p>' +
        '<div class="row"><div class="field"><label>Fonte</label><select id="tab-fonte">' + opts + '</select></div>' +
        '<div class="field"><label>UF (opcional)</label><input id="tab-uf" placeholder="MG"></div></div>' +
        '<div class="field"><label>Arquivo (planilha oficial: Excel .xlsx/.xls, CSV, ou JSON do fetcher)</label><input type="file" id="tab-file" accept=".xlsx,.xls,.json,.csv,.txt"></div>' +
        '<div class="field"><label>ou cole o conteúdo (JSON, ou CSV: Código;Descrição;Custo)</label><textarea id="tab-text" rows="3"></textarea></div>' +
        '<h3 style="margin:18px 0 6px">' + (typeof Icones !== 'undefined' ? Icones.get('estoque', 15) : '') + ' Bases prontas (1 clique)</h3>' +
        this._basesProntas(lista, (typeof Atualizacao !== "undefined" && Atualizacao._ultimoStatus) || null) +
        '<h3 style="margin:18px 0 6px">' + (typeof Icones !== 'undefined' ? Icones.get('pasta', 15) : '') + ' Escanear pasta inteira (de uma vez)</h3>' +
        '<p class="muted" style="font-size:12px">Pasta DENTRO do projeto do ERP (ex.: <b>mg-01-2026</b> = SICRO-MG). O fetcher parseia TUDO (composições com MO/MAT/EQ + materiais + equipamentos + mão de obra) e organiza no multi-base sozinho.</p>' +
        '<div class="row"><div class="field"><label>Pasta</label><input id="scan-pasta" value="mg-01-2026"></div>' +
        '<div class="field"><label>UF</label><input id="scan-uf" placeholder="MG (auto)"></div>' +
        '<div class="field"><label>Competência</label><input id="scan-mes" placeholder="2026-01 (auto)"></div></div>' +
        '<div class="flex" style="align-items:center;gap:12px"><label style="cursor:pointer"><input type="checkbox" id="scan-deson"> com desoneração</label>' +
        '<button class="btn sm primary" data-acao="escanear-pasta">' + (typeof Icones !== 'undefined' ? Icones.get('pasta', 15) : '') + ' Escanear e organizar</button></div>';
    },

    // ---------- Comparar cenários de preço ----------
    renderCenarios: function (custo, cenarios) {
      var f = Util.fmtNum;
      var cards = cenarios.map(function (c) {
        var bdiV = custo * c.bdi / 100, venda = custo + bdiV;
        var border = c.dest ? "2px solid #16a34a" : "1px solid var(--linha,#e2e8f0)";
        return '<div style="flex:1;min-width:150px;border:' + border + ';border-radius:12px;padding:14px;text-align:center;background:' + (c.dest ? "#f0fdf4" : "#fff") + '">' +
          '<div style="font-weight:800;font-size:15px;color:' + c.cor + '">' + c.nome + (c.dest ? " ★" : "") + '</div>' +
          '<div style="font-size:11px;color:var(--mut,#64748b);min-height:30px">' + c.desc + '</div>' +
          '<div style="font-size:12px;color:var(--mut,#64748b);margin-top:6px">BDI ' + f(c.bdi, 2) + '%</div>' +
          '<div style="font-size:22px;font-weight:900;color:#0f2740;line-height:1.25">R$ ' + f(venda, 2) + '</div>' +
          '<div style="font-size:11px;color:#16a34a;margin-bottom:10px">margem R$ ' + f(bdiV, 2) + '</div>' +
          '<button class="btn sm primary" data-acao="aplicar-cenario" data-bdi="' + c.bdi + '">Aplicar</button>' +
          '</div>';
      }).join("");
      return '<p class="muted mb">Custo direto: <b>R$ ' + f(custo, 2) + '</b> (igual nos três). O que muda é o <b>BDI</b> (sua margem) e o preço final:</p>' +
        '<div style="display:flex;gap:10px;flex-wrap:wrap">' + cards + '</div>' +
        '<p class="muted" style="font-size:12px;margin-top:12px"><b>Agressivo</b> = preço menor pra ganhar a obra · <b>Conservador</b> = margem maior pra risco maior. Clique <b>Aplicar</b> pra usar o cenário no orçamento.</p>';
    },

    // ---------- Licença ----------
    renderLicenca: function (st) {
      var html = '<p class="muted mb">Status da sua licença do OrçaPRO.</p>';
      if (st.trial && st.ativo) {
        html += '<div class="card"><b>' + (typeof Icones !== 'undefined' ? Icones.get('destravado', 15) : '') + ' Teste grátis — ' + Util.esc(st.rotulo || "") + ' restantes</b><br>Durante o teste você usa <b>TUDO</b>: monta orçamento, salva e exporta (PDF, Excel, proposta, laudo). Ao final dos 7 dias, ative uma licença para continuar — seus orçamentos ficam preservados.</div>';
      } else if (st.trial) {
        html += '<div class="card"><b>⏰ Teste grátis encerrado</b><br>Seus orçamentos estão preservados. Ative sua licença com a chave da compra para voltar a salvar e exportar.</div>';
      } else {
        html += '<div class="card"><b style="color:var(--verde,#16a34a)">' + (typeof Icones !== 'undefined' ? Icones.get('check', 15) : '') + ' Licenciado</b><br>' + Util.esc(st.email || "") + (st.expira ? ' · válida até ' + new Date(st.expira).toLocaleDateString("pt-BR") : ' · permanente') + '</div>';
      }
      html += '<div class="field" style="margin-top:12px"><label>Chave de licença</label><input id="lic-chave" placeholder="cole aqui a chave que você recebeu"></div>';
      return html;
    },

    // ---------- Cadastro da Empresa / Responsável Técnico ----------
    renderEmpresa: function (emp, logo) {
      function f(id, lab, val) { return '<div class="field"><label>' + lab + '</label><input id="emp-' + id + '" value="' + Util.esc(val || "") + '"></div>'; }
      return '<p class="muted mb">Estes dados aparecem nos documentos (Anexo de Laudo, Proposta).</p>' +
        '<div class="row">' + f("nome", "Razão social / Empresa", emp.nome) + f("cnpj", "CNPJ", emp.cnpj) + '</div>' +
        '<div class="row">' + f("responsavel", "Responsável técnico", emp.responsavel) + f("titulo", "Título profissional", emp.titulo) + '</div>' +
        '<div class="row">' + f("crea", "Registro CREA/CAU", emp.crea) + f("registroNacional", "Reg. Nacional", emp.registroNacional) + '</div>' +
        '<div class="row">' + f("cidade", "Cidade / UF", emp.cidade) + f("contato", "Contato (tel/e-mail)", emp.contato) + '</div>' +
        '<div class="field"><label>Endereço (rua, nº, bairro — usado nos documentos)</label><input id="emp-endereco" value="' + Util.esc(emp.endereco || "") + '"></div>' +
        '<h3 style="margin:10px 0 4px;border-top:1px solid var(--linha);padding-top:12px;font-size:13px">Canais de contato (viram links clicáveis na proposta em PDF)</h3>' +
        '<div class="row">' + f("telefone", "Telefone (com DDD)", emp.telefone) + f("whatsapp", "WhatsApp (só números, com DDD)", emp.whatsapp) + '</div>' +
        '<div class="row">' + f("email", "E-mail", emp.email) + f("site", "Site (https://…)", emp.site) + '</div>' +
        f("instagram", "Instagram (@usuario)", emp.instagram) +
        '<div class="field"><label>Logo (PNG/JPG — aparece na capa dos documentos)</label>' +
        '<input type="file" id="emp-logo" accept="image/png,image/jpeg,image/jpg,image/webp">' +
        '<div id="emp-logo-prev" class="mt">' + (logo ? '<img src="' + logo + '" style="max-height:72px;border:1px solid var(--linha);border-radius:6px;padding:4px;background:#fff">' : '<span class="muted">Nenhum logo carregado.</span>') + '</div></div>' +
        this._renderEmpresaDocs() + this._renderEmpresaPerfil();
    },
    /* ==================================================================
     * PERFIL DE IMPLANTAÇÃO — a tela que faltava
     *
     * O `js/perfis.js` existe desde a v1.1.24x e nunca teve por onde ser
     * ligado: `Perfis.aplicar` não tinha um único chamador no repositório, e
     * a implantação de um cliente era digitar no console. Catálogo que
     * ninguém alcança é catálogo que não existe.
     *
     * ⚠ SÓ O DONO DA CONTA. O perfil decide o que a empresa INTEIRA enxerga;
     *   sub-usuário mexendo nisso enxuga a barra dos colegas.
     * ================================================================== */
    _renderEmpresaPerfil: function () {
      if (typeof Perfis === "undefined") return "";
      /* ⚠ A VITRINE NÃO É UMA CONTA. Ela monta `Auth._usuario` sem `papel`
         (js/app.js), então `ehAdmin()` responde true e este bloco desenharia
         numa página pública — com o catálogo de perfis e a caixa de semear.
         `Perfis.listar` já esconde perfil privado, mas quem visita a vitrine
         não tem empresa para configurar: aqui o bloco simplesmente não existe. */
      if (typeof App !== "undefined" && App._demo) return "";
      if (typeof Auth !== "undefined" && Auth.ehAdmin && !Auth.ehAdmin()) return "";
      var lista = Perfis.listar();
      if (lista.length < 2) return "";
      var atual = Perfis.idAtual();
      return '' +
        '<div class="card mt" style="padding:12px 14px">' +
          '<b>Perfil de implantação</b>' +
          '<p class="muted" style="font-size:12px;margin:4px 0 8px">Enxuga o sistema para a operação da sua empresa. ' +
          '<b>Nada é apagado</b>: o módulo oculto continua com os dados dele, e voltar para “Completo” devolve tudo.</p>' +
          '<div style="display:grid;grid-template-columns:1fr;gap:5px">' +
          lista.map(function (p) {
            return '<label class="opt-linha" style="font-size:12.5px">' +
              '<input type="radio" name="emp-perfil" value="' + Util.esc(p.id) + '"' + (p.id === atual ? " checked" : "") + ">" +
              "<span><b>" + Util.esc(p.nome) + "</b>" +
              (p.qtd ? ' <span class="muted">— ' + p.qtd + " módulos</span>" : "") +
              '<br><span class="muted" style="font-size:11px">' + Util.esc(p.desc) + "</span></span></label>";
          }).join("") + "</div>" +
          '<label class="flex" style="gap:8px;align-items:center;margin:8px 0 0"><input type="checkbox" id="emp-perfil-semear"> ' +
          'Preencher os parâmetros de fábrica deste perfil <span class="muted" style="font-size:11px">(só o que ainda estiver em branco — nada que você já ajustou é sobrescrito)</span></label>' +
        "</div>";
    },
    /* Seção "Documentos & entregáveis" do ⚙ Empresa — white-label: os docs saem com a
     * marca DO CLIENTE; menção ao produto, marca d'água e QR são opcionais. */
    _renderEmpresaDocs: function () {
      var cfg = (typeof Empresa !== "undefined" && Empresa.docsCfg) ? Empresa.docsCfg() : { creditos: true, marcaDagua: "empresa", qr: true };
      return '' +
        '<div class="card mt" style="padding:12px 14px">' +
          '<b>Documentos &amp; entregáveis (sua marca)</b>' +
          '<p class="muted" style="font-size:12px;margin:4px 0 8px">Todos os documentos saem com a SUA logo e os SEUS dados. Aqui você escolhe o que mais aparece neles.</p>' +
          '<label class="flex" style="gap:8px;align-items:center;margin:6px 0"><input type="checkbox" id="emp-doc-creditos"' + (cfg.creditos ? " checked" : "") + '> Mencionar “Gerado pelo OrçaPRO IA” no rodapé dos documentos</label>' +
          '<label class="flex" style="gap:8px;align-items:center;margin:6px 0"><input type="checkbox" id="emp-doc-qr"' + (cfg.qr ? " checked" : "") + '> Incluir QR de verificação (Portal do Cliente) nos impressos</label>' +
          '<div class="field" style="margin:6px 0 0"><label>Marca d’água das páginas internas (Proposta / Laudo / Relatório)</label>' +
            '<select id="emp-doc-wm">' +
              '<option value="empresa"' + (cfg.marcaDagua !== "nenhuma" ? " selected" : "") + '>Nome da minha empresa</option>' +
              '<option value="nenhuma"' + (cfg.marcaDagua === "nenhuma" ? " selected" : "") + '>Nenhuma</option>' +
            '</select></div>' +
        '</div>';
    },

    // ---------- Tela: Login ----------
    renderLogin: function () {
      var contas = (typeof Auth !== "undefined" && Auth.listarContas) ? Auth.listarContas() : [];
      // Login sugerido pelo link de acesso do admin (?u=): a pessoa só digita a senha.
      var sugLogin = ""; try { sugLogin = localStorage.getItem("orcapro:login-sugerido") || ""; } catch (e) {}
      var chips = contas.length
        ? '<div class="field"><label>Suas contas neste navegador (clique p/ preencher o e-mail)</label><div class="flex" style="flex-wrap:wrap;gap:6px">' +
            contas.map(function (c) { return '<button type="button" class="btn sm" data-conta="' + Util.esc(c.email) + '">👤 ' + Util.esc(c.email) + '</button>'; }).join("") +
          '</div></div>'
        : '';
      var badge = '<svg width="46" height="46" viewBox="0 0 100 100" style="flex:none"><defs><linearGradient id="lgg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#163a5c"/><stop offset="1" stop-color="#2e6f9e"/></linearGradient></defs><rect x="2" y="2" width="96" height="96" rx="24" fill="url(#lgg)"/><rect x="24" y="52" width="13" height="22" rx="4" fill="#fff" opacity=".55"/><rect x="44" y="38" width="13" height="36" rx="4" fill="#fff" opacity=".9"/><rect x="64" y="24" width="13" height="50" rx="4" fill="#6fd08a"/><path d="M73 10 l2.4 5.1 5.6 .7 -4.1 3.9 1 5.6 -4.9 -2.7 -4.9 2.7 1 -5.6 -4.1 -3.9 5.6 -.7z" fill="#9be7af"/></svg>';
      return '' +
        '<div class="login-wrap">' +
          '<div class="login-hero"><div class="lh-grid"></div><div class="lh-content">' +
            '<div class="lh-logo">' + badge + '<span>OrçaPRO<b>IA</b></span></div>' +
            '<h2 class="lh-h">Você descreve a obra.<br><em>A IA monta o orçamento.</em></h2>' +
            '<ul class="lh-feats">' +
              '<li>SINAPI, SICRO, SUDECAP e mais — já com BDI (TCU/DNIT)</li>' +
              '<li>Cronograma de Gantt e Excel profissional</li>' +
              '<li>Proposta comercial e anexo para laudo pericial</li>' +
            '</ul>' +
            '<div class="lh-trust">' + (typeof Icones !== 'undefined' ? Icones.get('cadeado', 15) : '') + ' Roda no seu PC · seus orçamentos ficam salvos no dispositivo</div>' +
          '</div></div>' +
          '<div class="login-formside"><div class="login-card">' +
            '<div class="brand"><div class="lc-logo">' + badge + '<span class="nome">OrçaPRO<span class="ia">IA</span></span></div>' +
            '<div class="slogan">Entre ou crie sua conta para começar.</div></div>' +
            '<div id="login-form">' +
            chips +
            '<div class="field"><label>Empresa / Escritório</label><input id="lg-empresa" placeholder="Ex.: Studio Arq + Eng"></div>' +
            '<div class="field"><label>E-mail ou usuário</label><input id="lg-email" type="text" value="' + String(sugLogin).replace(/"/g, "&quot;") + '" placeholder="voce@empresa.com (ou seu login de usuário)"></div>' +
            '<div class="field"><label>Senha</label><input id="lg-senha" type="password" placeholder="••••••"></div>' +
            '<button class="btn primary" style="width:100%" data-acao="entrar">Entrar / Criar conta</button>' +
            (contas.length
              ? '<p class="muted mt" style="font-size:12px;text-align:center"><a href="#" data-acao="esqueci-senha" style="color:var(--aco)">Esqueci a senha</a> · seus orçamentos ficam salvos neste navegador</p>'
              : '<p class="muted mt" style="font-size:12px;text-align:center">Conta nova é criada automaticamente no 1º acesso (modo demo PRO).</p>') +
            '</div>' +
          '</div></div>' +
        '</div>';
    },

    // ---------- Tela: Lista de orçamentos ----------
    renderLista: function (orcamentos, baseInfo) {
      var html = "";
      // Banner da base SINAPI ativa
      if (baseInfo) {
        var origem = baseInfo.personalizada ? "base própria importada" : "base padrão";
        html += '<div class="card flex between mb" style="padding:12px 16px">' +
          '<div><span class="pill sinapi">SINAPI</span> <b>' + Util.esc(baseInfo.competencia) + ' / ' + Util.esc(baseInfo.uf) + '</b> · ' +
          baseInfo.total.toLocaleString("pt-BR") + ' itens <span class="muted">(' + origem + ')</span></div>' +
          '<div class="flex"><button class="btn sm" data-acao="atualizar">' + (typeof Icones !== 'undefined' ? Icones.get('ciclo', 15) : '') + ' Atualizar</button> ' +
          '<button class="btn sm" data-acao="importar-sinapi">' + (typeof Icones !== 'undefined' ? Icones.get('importar', 15) : '') + ' Importar base SINAPI</button></div></div>';
      }
      html += '<div class="flex between mb"><h1 style="margin:0">Meus Orçamentos</h1>' +
                 /* "RECUPERAR" TEM PORTA PRÓPRIA (v1.1.212). Quem perdeu um orçamento
                    não procura "importar" — procura "recuperar", e por isso passava
                    reto pelo botão que resolvia o problema dele. São ações diferentes:
                    importar é ler planilha de TERCEIRO por heurística; recuperar é
                    devolver o que ESTE sistema gravou, sem adivinhar nada. */
                 '<div class="flex"><button class="btn" data-acao="recuperar-planilha" title="Perdeu um orçamento e tem o Excel que o sistema gerou? Ele volta inteiro — etapas, sub etapas, BDI, cronograma e memórias de cálculo">' + Icones.get("reimportar") + 'Recuperar de uma planilha</button>' +
                 '<button class="btn" data-acao="importar-planilha" title="Importe uma planilha de orçamento (Excel/CSV) de QUALQUER formato — o agente detecta as etapas e itens e casa o código SINAPI">' + Icones.get("importar") + 'Importar planilha</button>' +
                 '<button class="btn" data-acao="copiar-orc" title="Criar um orçamento a partir de outro que já existe">⧉ Copiar de outro</button> ' +
                 '<button class="btn primary" data-acao="novo">+ Novo Orçamento</button></div></div>';
      if (!orcamentos.length) {
        /* A LISTA VAZIA É EXATAMENTE A TELA DE QUEM PERDEU O ORÇAMENTO.
           Oferecer só "criar o primeiro" a quem acabou de perder o dele é a
           mensagem errada na hora errada — e foi o que aconteceu com um
           cliente que tinha o Excel na mão e redigitaria tudo. */
        html += '<div class="vazio card"><h3>Nenhum orçamento ainda</h3>' +
                '<p>Crie seu primeiro orçamento e comece a buscar composições SINAPI.</p>' +
                '<button class="btn primary mt" data-acao="novo">+ Criar primeiro orçamento</button>' +
                '<p class="muted" style="font-size:12.5px;margin:14px 0 0">Já tinha um orçamento aqui e ele sumiu? ' +
                'Se você exportou o Excel dele, <b>o orçamento inteiro está dentro daquele arquivo</b> — ' +
                'etapas, sub etapas, BDI, cronograma e memórias de cálculo.</p>' +
                '<button class="btn mt" data-acao="recuperar-planilha">' + Icones.get("reimportar") + 'Recuperar de uma planilha</button></div>';
        return html;
      }
      /* ============ CARTEIRA: filtros, KPIs e prazo (fases 1 e 2) ============
         O motor (Orcamento.filtrarLista) faz a conta; aqui só desenha. O
         filtro vive em App._filtroOrc — estado de TELA, nunca do orçamento. */
      var f = (typeof App !== "undefined" && App._filtroOrc) || {};
      var r = Orcamento.filtrarLista(orcamentos, f, Util.agoraISO());
      var k = r.kpis, temFiltro = !!(f.busca || f.cliente || f.tipo || f.faixa || f.prazo || f.estado);
      /* indicadores sobre a carteira INTEIRA, não sobre o filtro: conversão de
         um recorte não é conversão, é amostra escolhida a dedo. */
      var ind = Orcamento.indicadoresCarteira(orcamentos, Util.agoraISO());

      /* ⚠ O TERCEIRO DIALETO DE INDICADOR, ate 02/09/2026.
         Este helper desenhava o numero EM CIMA, centralizado e em 800, com o
         rotulo pequeno embaixo — enquanto o Painel usa `.kpi` (rotulo em
         cima, numero embaixo, alinhado a esquerda) e o Financeiro usa a
         `.fin-faixa`. Tres jeitos de dizer a mesma coisa, e a pessoa
         reaprendendo a ler a cada tela.
         Agora usa a MESMA classe do Painel: o CSS ja existia, so nao estava
         sendo aproveitado aqui. A cor semantica continua vindo por
         parametro, porque verde/laranja no numero e informacao (prazo
         vencido, conversao boa), nao decoracao. */
      /* ⚠ `sub` NAO E ENFEITE: sem ele, frases como "prazo: ligue em
         Parametros" viravam ROTULO — em caixa alta, quebrando em duas linhas
         e pesando como titulo. Rotulo nomeia, explicacao explica; cada um
         faz um trabalho so. */
      var kpi = function (v, rot, cor, sub) {
        return '<div class="kpi kpi-compacto" style="min-width:120px">' +
          '<div class="rotulo">' + rot + '</div>' +
          '<div class="num"' + (cor ? ' style="color:' + cor + '"' : "") + '>' + v + '</div>' +
          (sub ? '<div class="kpi-sub">' + sub + '</div>' : "") + '</div>';
      };
      html += '<div class="kpis" style="margin-bottom:14px">' +
        kpi(k.qtd + (temFiltro ? '<span style="font-size:12px;font-weight:600;color:var(--cinza)"> / ' + r.total + '</span>' : ""), temFiltro ? "no filtro" : "orçamentos") +
        kpi(Util.fmtMoeda(k.carteira), "carteira" + (temFiltro ? " (filtrada)" : "")) +
        kpi(Util.fmtMoeda(k.medio), "valor médio") +
        (k.comControle
          ? kpi(k.aVencer + (k.vencidos ? ' <span style="color:#dc2626">+' + k.vencidos + '</span>' : ""),
                "prazos", k.vencidos ? "#ea580c" : "#16a34a",
                k.vencidos ? "a vencer · vencidos" : "a vencer")
          /* sem nenhum prazo controlado, o KPI vira convite — e explica onde
             se liga isso, senão o usuário não descobre que existe */
          : kpi("—", "prazos", null, "ligue em Parâmetros")) +
        /* FASE 5 — o número que o dono olha. « — » quando nada foi enviado
           ainda: 0% ali seria mentira sobre um funil que nem começou.
           ⚠ ATÉ 03/09/2026 ESTE NÚMERO MEDIA A APROVAÇÃO INTERNA (quanto do
           que o orçamentista fez o gestor aprovou) e era lido como venda.
           Agora é o funil comercial: aceitas ÷ enviadas ao cliente. Sem
           nenhum envio registrado ele não inventa: diz onde se registra. */
        (ind.enviadas
          ? kpi(Util.fmtNum(ind.conversao, 1) + "%", "conversão",
                ind.conversao >= 50 ? "#16a34a" : "#0f2740",
                ind.aceitas + " de " + ind.enviadas + " enviadas ao cliente")
          : kpi("—", "conversão", null, "registre o envio no orçamento")) +
      '</div>' +
      /* orçamento parado: quem preencheu esqueceu, e ninguém cobra o que não
         aparece. Só conta o que AINDA NÃO FOI ENVIADO — esperar decisão de
         outra pessoa não é atraso de quem orçou. */
      /* ⚠ ESTE É O DINHEIRO NA MESA. Proposta enviada e sem resposta há dias
         não aparece em lugar nenhum do sistema — e é exatamente a que fecha
         com um telefonema. Vem antes dos "parados" porque já custou trabalho
         inteiro: foi orçada, virou documento e foi ao cliente. */
      (ind.semResposta && ind.semResposta.length
        ? '<div class="card" style="padding:9px 12px;margin-bottom:12px;background:rgba(15,39,64,.06);border-color:rgba(15,39,64,.25);font-size:12.5px">'
          + "<b>" + ind.semResposta.length + " proposta(s) enviada(s) sem resposta</b> há mais de " + ind.limiteParado + " dias: "
          + ind.semResposta.slice(0, 4).map(function (x) {
              return '<a href="#" data-abrir="' + Util.esc(x.orc.id) + '">' + Util.esc(x.orc.nome || x.orc.numero) + "</a> (" + x.dias + "d)";
            }).join(" · ")
          + (ind.semResposta.length > 4 ? " e mais " + (ind.semResposta.length - 4) : "")
          + '<div class="muted" style="margin-top:3px">Um telefonema resolve mais que uma proposta nova. Registre a resposta no orçamento quando souber.</div></div>'
        : "") +
      (ind.parados.length
        ? '<div class="card" style="padding:9px 12px;margin-bottom:12px;background:rgba(234,88,12,.08);border-color:rgba(234,88,12,.3);font-size:12.5px">' +
          (typeof Icones !== "undefined" ? Icones.get("alerta", 15) : "⚠") + ' <b>' + ind.parados.length +
          ' orçamento(s) parado(s)</b> há mais de ' + ind.limiteParado + ' dias sem edição e ainda não enviados: ' +
          ind.parados.slice(0, 3).map(function (p) {
            return Util.esc(p.orc.nome || p.orc.numero) + " (" + p.dias + "d)";
          }).join(" · ") + (ind.parados.length > 3 ? " …" : "") + '</div>'
        : "");

      var opt = function (v, rot, sel) { return '<option value="' + Util.esc(v) + '"' + (sel === v ? " selected" : "") + '>' + Util.esc(rot) + '</option>'; };
      html += '<div class="card" style="padding:10px 12px;margin-bottom:12px"><div class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-end">' +
        /* min-width:0 em TODO campo da barra: item de flex nasce com
           min-width:auto e não encolhe abaixo do conteúdo — o placeholder
           longo da busca empurrava o campo por cima do select de Cliente. */
        '<div class="field" style="flex:2;min-width:180px;margin:0"><label style="font-size:11px">Buscar</label>' +
          '<input id="fo-busca" style="width:100%;box-sizing:border-box" placeholder="nome, número, cliente…" value="' + Util.esc(f.busca || "") + '" autocomplete="off"></div>' +
        '<div class="field" style="flex:1;min-width:0;margin:0"><label style="font-size:11px">Cliente</label><select style="width:100%;box-sizing:border-box" id="fo-cliente">' +
          opt("", "Todos", f.cliente || "") + r.clientes.map(function (c) { return opt(c, c, f.cliente || ""); }).join("") + '</select></div>' +
        (k.porEstado && Object.keys(k.porEstado).length > 1 ? '<div class="field" style="flex:1;min-width:0;margin:0"><label style="font-size:11px">Estado</label><select style="width:100%;box-sizing:border-box" id="fo-estado">' +
          opt("", "Todos", f.estado || "") + Orcamento.ORDEM_ESTADO.filter(function (e) { return k.porEstado[e]; }).map(function (e) {
            return opt(e, ((typeof Aprovacao !== "undefined" && Aprovacao.ESTADOS[e]) ? Aprovacao.ESTADOS[e].rotulo : e) + " (" + k.porEstado[e].qtd + ")", f.estado || ""); }).join("") + '</select></div>' : "") +
        (r.tipos.length ? '<div class="field" style="flex:1;min-width:0;margin:0"><label style="font-size:11px">Tipo</label><select style="width:100%;box-sizing:border-box" id="fo-tipo">' +
          opt("", "Todos", f.tipo || "") + r.tipos.map(function (c) { return opt(c, c, f.tipo || ""); }).join("") + '</select></div>' : "") +
        '<div class="field" style="flex:1;min-width:0;margin:0"><label style="font-size:11px">Valor</label><select style="width:100%;box-sizing:border-box" id="fo-faixa">' +
          opt("", "Qualquer", f.faixa || "") + Orcamento.FAIXAS.map(function (x) { return opt(x.id, x.rotulo, f.faixa || ""); }).join("") + '</select></div>' +
        (k.comControle ? '<div class="field" style="flex:1;min-width:0;margin:0"><label style="font-size:11px">Prazo</label><select style="width:100%;box-sizing:border-box" id="fo-prazo">' +
          opt("", "Todos", f.prazo || "") + opt("avencer", "A vencer", f.prazo || "") + opt("vencidos", "Vencidos", f.prazo || "") + '</select></div>' : "") +
        '<div class="field" style="flex:1;min-width:0;margin:0"><label style="font-size:11px">Ordenar por</label><select style="width:100%;box-sizing:border-box" id="fo-ordem">' +
          opt("atualizado", "Atualização", f.ordem || "atualizado") + opt("valor", "Maior valor", f.ordem || "atualizado") +
          opt("prazo", "Prazo mais próximo", f.ordem || "atualizado") + opt("estado", "Estado da aprovação", f.ordem || "atualizado") + opt("nome", "Nome", f.ordem || "atualizado") + '</select></div>' +
        '<button class="btn sm" data-acao="fo-exportar" style="margin-bottom:2px" title="Exporta a lista como está na tela — o arquivo registra o filtro aplicado">' +
          (typeof Icones !== "undefined" ? Icones.get("excel", 15) : "") + 'Exportar</button>' +
        (temFiltro ? '<button class="btn sm ghost" data-acao="fo-limpar" style="margin-bottom:2px">Limpar filtros</button>' : "") +
      '</div></div>';

      /* VAZIO POR FILTRO ≠ VAZIO DE VERDADE. Sem esta distinção, quem filtra
         demais acha que perdeu orçamento de novo — e a tela de recuperação,
         aqui, seria a resposta errada. */
      if (!r.lista.length) {
        html += '<div class="vazio card"><h3>Nenhum orçamento neste filtro</h3>' +
                '<p>São ' + r.total + ' no total — ajuste ou limpe o filtro para vê-los.</p>' +
                '<button class="btn mt" data-acao="fo-limpar">Limpar filtros</button></div>';
        return html;
      }

      html += '<div class="grid-cards">';
      r.lista.forEach(function (m) {
        var o = m.orc, t = m.tot, p = m.prazo;
        var selo = "";
        if (p.controla) {
          var cor = p.estado === "vencido" ? "#dc2626" : (p.estado === "ok" ? "#16a34a" : "#ea580c");
          var txt = p.estado === "vencido" ? "vencido há " + Math.abs(p.dias) + "d"
                  : (p.estado === "hoje" ? "vence hoje" : "vence em " + p.dias + "d");
          selo = '<span class="g-pill" style="background:' + cor + '22;color:' + cor + ';font-weight:700">' + txt + '</span> ';
        }
        /* pilula do estado: rascunho nao vira ruido visual - so aparece quando
           o orcamento JA entrou no ciclo (foi enviado alguma vez) */
        var est = m.estado, info = (typeof Aprovacao !== "undefined" && Aprovacao.ESTADOS[est]) ? Aprovacao.ESTADOS[est] : null;
        var CORES = { cinza: "#64748b", ambar: "#ea580c", verde: "#16a34a", vermelho: "#dc2626" };
        var pilula = (info && est !== "rascunho")
          ? '<span class="g-pill" style="background:' + CORES[info.cor] + '22;color:' + CORES[info.cor] + ';font-weight:700">' + Util.esc(info.rotulo) + '</span> ' : "";
        var el = Orcamento.tempoElaboracao(o);
        html += '<div class="card orc-card" data-abrir="' + o.id + '">' +
          // 🗑 dentro do card clicável: o dispatch resolve o botão ANTES do abrir
          '<button class="btn sm ico danger orc-del" data-del-orc="' + o.id + '" title="Excluir este orçamento (pede confirmação)">' + (typeof Icones !== 'undefined' ? Icones.get('lixeira', 15) : '') + '</button>' +
          '<h3>' + Util.esc(o.nome) + '</h3>' +
          '<div class="meta">' + Util.esc(o.numero) + ' · ' + Util.esc(o.cliente.nome || "Sem cliente") + '</div>' +
          '<div class="meta">' + t.qtdEtapas + ' etapas · ' + t.qtdItens + ' itens · BDI ' + Util.fmtPct(t.bdiPercentual) + '</div>' +
          '<div class="valor">' + Util.fmtMoeda(t.precoVenda) + '</div>' +
          '<div class="meta mt">' + pilula + selo + 'Atualizado ' + Util.fmtData(o.atualizadoEm) +
            /* esforço quando existe (dias em que o orçamento foi mexido),
               calendário como retaguarda para quem é anterior à fase 3 —
               e o title diz QUAL das duas contas está na tela, senão o
               número muda de significado sem o usuário perceber */
            (el.diasTrabalhados
              ? ' · <span title="Dias em que este orçamento foi editado (esforço, não calendário)">elaboração: ' +
                el.diasTrabalhados + (el.diasTrabalhados === 1 ? " dia" : " dias") + ' de trabalho</span>'
              : (el.dias != null ? ' · <span title="Do primeiro salvamento até a última edição (tempo de calendário)">elaboração: ' +
                (el.dias >= 1 ? el.dias + (el.dias === 1 ? " dia" : " dias") : (el.horas || 0) + "h") + '</span>' : "")) +
          '</div>' +
        '</div>';
      });
      html += '</div>';
      return html;
    },

    /* AVISO DE PRECISÃO — modo "Não arredondar".
     *
     * O motor guarda os totais com toda a precisão e a tela imprime cada um ao
     * centavo. Nesse modo (e SÓ nele) isso faz a conta parecer não fechar por um
     * centavo: round2(custo) + round2(BDI) ≠ round2(preço) quando as frações
     * conspiram — medido em ~19% dos orçamentos. Nos outros quatro modos,
     * inclusive o padrão TCU, fecha sempre.
     *
     * A tentação é "consertar" o número exibido. Não dá: o mesmo trio aparece em
     * seis lugares (cartões, planilha, sintético, relatório, Excel, laudo), e
     * ajustar alguns deles cria DUAS verdades na mesma página — pior que a
     * diferença de um centavo. Então o número fica o do motor, igual em todos, e
     * o documento AVISA de onde vem a diferença. Quem não quer conviver com ela
     * troca o arredondamento em Parâmetros. */
    _seloPrecisao: function (modo) {
      return modo === "nenhum"
        ? ' · valores exibidos ao centavo (arredondamento: "não arredondar")'
        : "";
    },

    // ---------- Tela: Editor de orçamento ----------
    renderEditor: function (orc, abaAtiva) {
      var t = Orcamento.totais(orc);
      var html = '<div class="flex between mb">' +
        '<div><button class="btn ghost sm" data-acao="voltar">' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Voltar</button> ' +
        '<span style="font-size:20px;font-weight:800;margin-left:8px">' + Util.esc(orc.nome) + '</span> ' +
        '<span class="muted">' + Util.esc(orc.numero) + '</span></div>' +
        '<div class="flex">' +
          '<button class="btn sm primary" data-acao="escopo">' + Icones.get("escopo") + 'Escopo Inteligente</button>' +
          '<button class="btn sm" data-acao="relatorio">' + Icones.get("relatorio") + 'Relatório completo</button>' +
          /* FASE 4 — o ciclo de aprovação começa ANTES da proposta: é o preço
             conferido que vai ao cliente, não o contrário. Por isso a pílula
             e as ações abrem a barra. Sai vazio quando o motor não autoriza
             nada para esta pessoa — a tela não inventa botão. */
          ((typeof App !== "undefined" && App._aprovBotoesOrc) ? App._aprovBotoesOrc(orc) : "") +
          '<button class="btn sm success" data-acao="proposta">' + Icones.get("proposta") + 'Gerar Proposta</button>' +
          /* depois de gerar vem o que aconteceu com ela: enviada, aceita, recusada */
          ((typeof App !== "undefined" && App._propComercialBotoes) ? App._propComercialBotoes(orc) : "") +
          '<button class="btn sm" data-acao="apresentar" title="Modo apresentação: tela cheia pra reunião com o cliente (setas navegam, Esc sai)">' + Icones.get("apresentar") + 'Apresentar</button>' +
          '<button class="btn sm" data-acao="laudo">' + Icones.get("laudo") + 'Anexo p/ Laudo</button>' +
          '<button class="btn sm" data-acao="config-orc">' + Icones.get("dados") + 'Dados</button>' +
          '<button class="btn sm" data-acao="parametros-orc" title="Arredondamento, encargos, incidência do BDI, categoria e licitação">' + Icones.get("parametros") + 'Parâmetros</button>' +
          '<button class="btn sm" data-acao="cenarios">' + Icones.get("cenarios") + 'Comparar cenários</button>' +
          '<button class="btn sm" data-acao="exportar-excel">' + Icones.get("excel") + 'Excel (3 abas)</button>' +
          '<button class="btn sm" data-acao="reimportar-excel" title="Traz de volta as edições de Qtd/Custo feitas no Excel exportado">' + Icones.get("reimportar") + 'Reimportar</button>' +
        '</div></div>';

      // KPIs
      html += '<div class="kpis">' +
        kpi("Custo Direto", Util.fmtMoeda(t.custoDireto), "custo") +
        kpi("BDI", Util.fmtPct(t.bdiPercentual) + " (" + Util.fmtMoeda(t.bdiValor) + ")", "") +
        /* FECHAR EM UM VALOR — DENTRO do card de Preço de Venda, porque é a
           pergunta que nasce olhando exatamente para esse número: "preciso que
           dê outro". Ficou solto entre os KPIs e as abas na primeira versão e
           não foi encontrado. Ação longe do número que ela muda é ação que
           ninguém acha. */
        kpi("Preço de Venda", Util.fmtMoeda(t.precoVenda), "destaque",
          (typeof Fechamento === "undefined") ? "" :
          ('<button class="btn sm primary" data-acao="fechar-valor" style="width:100%" ' +
           'title="Chegar a um valor final definido, distribuindo a diferença no BDI, nos itens ou numa parcela">' +
           (typeof Icones !== "undefined" ? Icones.get("dinheiro", 14) : "") + " Fechar em um valor…</button>" +
           (orc.fechamento
             ? '<button class="btn sm ghost" data-acao="fechar-desfazer" style="width:100%;margin-top:5px" ' +
               'title="Volta os preços ao que eram antes do fechamento">Desfazer fechamento</button>'
             : ""))) +
        kpi("Itens / Etapas", t.qtdItens + " / " + t.qtdEtapas, "") +
      '</div>';

      /* Selo do fechamento ativo: de onde este preço veio. Fica FORA do card
         porque é informação de rastreio, não ação — e porque o texto é longo
         demais para caber num KPI sem espremer o número. */
      if (typeof Fechamento !== "undefined" && orc.fechamento) {
        var _fx = orc.fechamento, _dl = Util.num(_fx.delta);
        html += '<div style="margin:-4px 0 12px;font-size:12px;padding:7px 12px;border-radius:8px;' +
          'background:rgba(46,111,158,.10);border:1px solid rgba(46,111,158,.30)">' +
          "Este orçamento foi <b>fechado em " + Util.fmtMoeda(_fx.alvo) + "</b> — " +
          (_dl >= 0 ? "acréscimo" : "desconto") + " de <b>" + Util.fmtMoeda(Math.abs(_dl)) + "</b> sobre os " +
          Util.fmtMoeda(_fx.valorAnterior) + " originais, " +
          /* no combinado o interessante é a DIVISÃO, não a palavra "combinado":
             é ela que responde "de onde saiu esse dinheiro?" seis meses depois */
          (_fx.modo === "combinado" && _fx.criterios
            ? _fx.criterios.map(function (c) {
                return Util.esc(String(((Fechamento.MODOS[c.modo] || {}).rotulo) || c.modo).toLowerCase()) +
                       /* 1 casa, não 0: com inteiro, 57,5 + 42,5 virava
                          "58% + 43%" = 101% na cara do usuário */
                       " <b>" + Util.fmtNum(c.pct, 1) + "%</b>";
              }).join(" + ")
            : Util.esc(String(((Fechamento.MODOS[_fx.modo] || {}).rotulo) || _fx.modo).toLowerCase())) + "." +
          "</div>";
      }

      // Pendência de preço: faixa de erro ANTES das abas (não finaliza zerado)
      var _semPreco = Orcamento.itensSemPreco ? Orcamento.itensSemPreco(orc) : [];
      if (_semPreco.length) {
        html += '<div style="padding:10px 14px;border-radius:10px;background:rgba(220,38,38,.10);border:1px solid rgba(220,38,38,.3);font-size:13px;margin-bottom:12px">' +
          '⛔ <b>' + _semPreco.length + ' item(ns) sem preço:</b> ' +
          _semPreco.slice(0, 5).map(function (i) { return '<b>' + Util.esc(i.numero) + '</b>' + (i.codigo ? ' (' + Util.esc(i.codigo) + ')' : ''); }).join(', ') +
          (_semPreco.length > 5 ? '…' : '') +
          ' — informe o custo unitário nos campos em vermelho. <b>Proposta e apresentação ficam bloqueadas</b> enquanto houver item zerado.</div>';
      }
      /* v1.1.232 — a MESMA faixa para quantidade pendente. O item trazido sem
         metragem (fluxo do memorial) não soma no total, e sem este aviso a
         única pista era o campo marcado na linha — fácil de não ver num
         orçamento de 60 itens, e a proposta agora bloqueia por causa dele. */
      var _semQtd = Orcamento.itensSemQuantidade ? Orcamento.itensSemQuantidade(orc) : [];
      if (_semQtd.length) {
        html += '<div style="padding:10px 14px;border-radius:10px;background:rgba(234,88,12,.10);border:1px solid rgba(234,88,12,.35);font-size:13px;margin-bottom:12px">' +
          '⚠ <b>' + _semQtd.length + ' item(ns) sem quantidade:</b> ' +
          _semQtd.slice(0, 5).map(function (x) { return '<b>' + Util.esc(x.item.codigo || String(x.item.descricao || '').slice(0, 18)) + '</b>'; }).join(', ') +
          (_semQtd.length > 5 ? '…' : '') +
          ' — eles não somam no total. Clique em <b>Calcular</b> na linha para levantar a metragem. <b>Proposta e laudo ficam bloqueados</b> enquanto houver item pendente.</div>';
      }

      // Abas — ícone SVG padronizado em todas (nada de emoji)
      var abas = [
        ["planilha", "Planilha", "planilha"],
        ["sintetico", "Sintético", "sintetico"],
        /* ⚠ A LISTA DE COMPRAS FICA COLADA NO RESUMO, e nao no fim.
           A planilha responde por SERVICO (alvenaria, reboco); esta aba
           responde a mesma obra por MATERIAL, que e como se compra. Sao as
           duas leituras do mesmo orcamento, e andam juntas. */
        ["insumos", "Insumos & ABC", "insumo"],
        ["cronograma", "Cronograma", "cronograma"],
        ["execucao", "Execução", "execucao"],
        ["paredecebola", "Parede-Cebola", "paredecebola"],
        ["graficos", "Gráficos", "graficos"],
        ["relatorios", "Relatórios", "relatorios"],
        ["bdi", "BDI & Parâmetros", "bdi"]
      ];
      html += '<div class="tabs">';
      abas.forEach(function (a) {
        html += '<div class="tab ' + (abaAtiva === a[0] ? "ativa" : "") + '" data-aba="' + a[0] + '">' + Icones.get(a[2], 14) + a[1] + '</div>';
      });
      html += '</div>';

      html += '<div id="aba-conteudo">';
      if (abaAtiva === "sintetico") html += this.renderSintetico(orc);
      else if (abaAtiva === "insumos") html += this.renderInsumosOrc(orc);
      else if (abaAtiva === "cronograma") html += this.renderCronograma(orc);
      else if (abaAtiva === "execucao") html += this.renderExecucao(orc);
      else if (abaAtiva === "paredecebola") html += this.renderParedeCebola(orc);
      else if (abaAtiva === "graficos") html += this.renderGraficos(orc);
      else if (abaAtiva === "relatorios") html += this.renderRelatorios(orc);
      else if (abaAtiva === "bdi") html += this.renderBdi(orc);
      else html += this.renderPlanilha(orc);
      html += '</div>';
      return html;
    },

    // ----- Aba Planilha (analítico editável) -----
    /* =================================================================
     * ÍNDICE DE ETAPAS — o "mestre" do mestre-detalhe
     *
     * Com 22 etapas e 220 itens (o tamanho que uma obra de verdade tem), a
     * planilha vira uma fita: chegar na última etapa custa rolar o
     * orçamento inteiro, e não existe nenhum lugar onde se veja a
     * ESTRUTURA — quantas etapas há e quanto pesa cada uma.
     *
     * O concorrente resolve isso com um painel de fases à esquerda e o
     * detalhe à direita. Reescrever a planilha nesse molde seria mexer na
     * tela mais sensível do sistema (edição na célula, mover item, sub
     * etapa, arredondamento vindo do motor). Aqui o mesmo ganho vem por
     * FILTRO: o índice mostra a estrutura e escolhe qual etapa a tabela
     * desenha. A tabela não mudou.
     *
     * ⚠ O FILTRO É DE EXIBIÇÃO, NUNCA DE CONTA. Os totais do topo, o
     * subtotal de cada etapa e tudo que sai em documento continuam vindo de
     * `Orcamento.calcular(orc)` INTEIRO. Filtrar a tabela e deixar o total
     * seguir o recorte faria a tela dizer que o orçamento encolheu — e
     * alguém mandaria proposta com o preço de uma etapa só.
     *
     * ⚠ E SÓ APARECE A PARTIR DE 5 ETAPAS. Num orçamento de três, o painel
     * ocuparia um quarto da largura para listar o que já está inteiro na
     * tela ao lado.
     * ================================================================= */
    _indiceEtapas: function (orc, calc) {
      var etapas = orc.etapas || [];
      if (etapas.length < 5) return "";
      var foco = (typeof App !== "undefined") ? App._etapaFoco : "";
      var porEtapa = [];
      Util.arr(calc.linhas).forEach(function (L) {
        var s = porEtapa[L.etapaIdx] || (porEtapa[L.etapaIdx] = { custo: 0 });
        s.custo += L.custoTotal;
      });
      var total = 0;
      etapas.forEach(function (e, i) { total += (porEtapa[i] || { custo: 0 }).custo; });

      var h = '<aside class="idx-etapas" aria-label="Etapas do orçamento">'
        + '<button class="idx-item' + (!foco ? " on" : "") + '" data-etapa-foco="">'
        + '<span class="idx-nome">Todas as etapas</span>'
        + '<span class="idx-val">' + Util.fmtMoeda(total) + '</span></button>';
      etapas.forEach(function (e, i) {
        var c = (porEtapa[i] || { custo: 0 }).custo;
        /* a barrinha e a leitura de RELEVANCIA: qual etapa leva o dinheiro.
           E o mesmo que a curva ABC faz por insumo, aqui por etapa. */
        var pct = total > 0 ? Math.round(c / total * 100) : 0;
        h += '<button class="idx-item' + (foco === e.id ? " on" : "") + '" data-etapa-foco="' + Util.esc(e.id) + '"'
          + ' title="' + Util.esc(e.nome) + ' — ' + pct + '% do custo direto">'
          + '<span class="idx-num">' + (i + 1) + '</span>'
          + '<span class="idx-nome">' + Util.esc(e.nome) + '</span>'
          + '<span class="idx-val">' + Util.fmtMoeda(c) + '</span>'
          + '<span class="idx-barra"><i style="width:' + pct + '%"></i></span>'
          + '</button>';
      });
      return h + '</aside>';
    },

    renderPlanilha: function (orc) {
      var recTudo = (typeof App !== "undefined" && App._etapasRecolhidas && orc.etapas.length)
        ? !orc.etapas.some(function (e) { return !App.etapaRecolhida(orc.id, e.id); }) : false;
      var html = '<div class="flex between mb"><div></div><div style="display:flex;gap:6px">' +
        (orc.etapas.length > 1 ? '<button class="btn sm ghost" data-acao="etapas-recolher-todas" title="Orçamento grande: recolha as etapas para enxergar o todo">' +
          (recTudo ? "\u25BE Expandir todas" : "\u25B8 Recolher todas") + '</button>' : "") +
        '<button class="btn sm" data-acao="add-etapa">+ Etapa</button></div></div>';
      if (!orc.etapas.length) {
        html += '<div class="vazio card">Adicione uma <b>etapa</b> (ex.: Serviços Preliminares) e depois itens da SINAPI.</div>';
        return html;
      }
      html += this._faixaAjustes(orc);
      var _calcIdx = Orcamento.calcular(orc);
      var _idx = this._indiceEtapas(orc, _calcIdx);
      if (_idx) html += '<div class="pl-com-indice">' + _idx + '<div class="pl-tabela">';
      var _foco = (typeof App !== "undefined") ? App._etapaFoco : "";
      if (_foco) {
        var _nomeFoco = "";
        (orc.etapas || []).forEach(function (e) { if (e.id === _foco) _nomeFoco = e.nome; });
        /* ⚠ QUEM FILTROU TEM DE VER QUE FILTROU. Tabela curta sem aviso se le
           como orçamento pequeno — e o total do topo continua sendo o do
           orçamento inteiro, o que faria os dois números parecerem brigar. */
        html += '<div class="pl-foco">Mostrando só <b>' + Util.esc(_nomeFoco) + '</b>'
          + ' <span class="muted">— os totais acima continuam sendo do orçamento inteiro</span>'
          + ' <button class="btn sm ghost" data-etapa-foco="">Ver todas</button></div>';
      }
      html += '<table class="tbl"><thead><tr>' +
        '<th>Item</th><th>Código</th><th>Descrição</th><th>Unid</th>' +
        '<th class="num">Qtd</th><th class="num">Custo Unit</th><th class="num">Custo Total</th>' +
        '<th class="num">Preço Venda</th><th></th></tr></thead><tbody>';

      // Linhas e subtotais vêm da FONTE ÚNICA (Orcamento.calcular): a planilha da
      // tela precisa mostrar exatamente o mesmo número do Excel, do relatório e
      // do laudo — o critério de arredondamento é do orçamento, não da tela.
      var _c = Orcamento.calcular(orc);
      var _porEtapa = [], _porItem = {}, _porSub = {};
      _c.linhas.forEach(function (L) {
        var s = _porEtapa[L.etapaIdx] || (_porEtapa[L.etapaIdx] = { custo: 0, venda: 0 });
        s.custo += L.custoTotal; s.venda += L.precoTotal;
        _porItem[L.etapaIdx + "|" + L.itemIdx] = L;
      });
      // subtotal de sub etapa vem do MOTOR (c.grupos) — a tela nunca refaz a conta
      Util.arr(_c.grupos).forEach(function (g) { _porSub[g.subEtapaId] = g; });
      var nEtapas = orc.etapas.length;
      orc.etapas.forEach(function (e, ei) {
        /* ⚠ O FILTRO SAI AQUI DENTRO, e `ei` continua sendo o indice REAL do
           array. Filtrar antes (com um `.filter()`) renumeraria as etapas e,
           pior, faria "mover item" e "+ Item" apontarem para a posicao
           errada — as acoes carregam etapaIdx. */
        if (_foco && e.id !== _foco) return;
        // Subtotal da etapa = SOMA DAS LINHAS IMPRESSAS abaixo dela. Com o BDI
        // apartado ("no preço final") o preço do item é de custo, então usar o
        // sintético aqui (que já rateia o BDI) faria a etapa não bater com os
        // próprios itens — e o BDI apareceria duas vezes no documento.
        var sm = _porEtapa[ei] || { custo: 0, venda: 0 };
        var se = { custoDireto: Arred.valor(sm.custo, _c.modo), precoVenda: Arred.valor(sm.venda, _c.modo) };
        // número da etapa = posição (1, 2, 3…); item = 2.1, 2.2… (derivado da posição)
        var numEtapa = String(ei + 1);
        /* recolhido é estado de TELA (App._etapasRecolhidas), nunca do dado.
           A própria linha da etapa jamais some: é ela que segura os subtotais. */
        var rec = (typeof App !== "undefined" && App.etapaRecolhida) ? App.etapaRecolhida(orc.id, e.id) : false;
        var nItensEt = e.itens.length;
        html += '<tr class="etapa-row"><td data-toggle-etapa="' + e.id + '" style="cursor:pointer" title="' + (rec ? "Expandir" : "Recolher") + ' esta etapa"><span data-chevron-etapa="' + e.id + '">' + (rec ? "▸" : "▾") + '</span> <b>' + numEtapa + '</b></td>' +
          '<td colspan="5" data-toggle-etapa="' + e.id + '" style="cursor:pointer" title="' + (rec ? "Expandir" : "Recolher") + ' esta etapa">' + Util.esc(e.nome) +
            ' <span class="muted" style="font-weight:400;font-size:11px">(' + nItensEt + (nItensEt === 1 ? " item" : " itens") + ')</span>' +
            /* ⚠ A ETAPA OPCIONAL CONTINUA NO TOTAL DA TELA (e do Excel, e da
               medição): o que muda é a PROPOSTA, onde ela sai fora do valor
               fechado. Sem este selo, o usuário veria o papel com um total
               menor que o da planilha e pensaria em erro de conta. */
            (e.opcional ? ' <span class="g-pill" style="background:#7a6b4e22;color:#7a6b4e;font-weight:700;font-size:10.5px" title="Na proposta esta etapa sai como adicional, fora do valor total">adicional</span>' : "") + '</td>' +
          '<td class="num">' + Util.fmtMoeda(se.custoDireto) + '</td>' +
          '<td class="num">' + Util.fmtMoeda(se.precoVenda) + '</td>' +
          '<td class="right"><div class="acoes">' +
          '<button class="btn sm ico" data-mover-etapa="' + e.id + '|-1"' + (ei === 0 ? ' disabled' : '') + ' title="Subir etapa">▲</button>' +
          '<button class="btn sm ico" data-mover-etapa="' + e.id + '|1"' + (ei === nEtapas - 1 ? ' disabled' : '') + ' title="Descer etapa">▼</button>' +
          '<button class="btn sm" data-add-item="' + e.id + '">+ Item</button>' +
          '<button class="btn sm" data-add-sub="' + e.id + '" title="Dividir esta etapa em sub etapas (ex.: 1.1 Canteiro de Obras)">+ Sub etapa</button>' +
          '<button class="btn sm ico" data-edit-etapa="' + e.id + '" title="Renomear etapa">' + (typeof Icones !== 'undefined' ? Icones.get('editar', 15) : '') + '</button>' +
          '<button class="btn sm ico' + (e.opcional ? ' primary' : '') + '" data-opc-etapa="' + e.id + '" title="' + (e.opcional
            ? "Voltar a ser parte do valor fechado da proposta"
            : "Marcar como ADICIONAL: na proposta esta etapa sai fora do total, como um opcional que o cliente pode incluir") + '">' + (typeof Icones !== 'undefined' ? Icones.get('mais', 15) : '+') + '</button>' +
          '<button class="btn sm ico danger" data-del-etapa="' + e.id + '" title="Remover etapa">' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + '</button></div></td></tr>';

        /* CORPO DA ETAPA — soltos primeiro, depois um bloco por sub etapa (a mesma
           ordem canônica que Orcamento._normalizarEtapa impõe em e.itens; render
           e numeração TÊM que andar juntos, senão a tela mostra 1.3 em cima de 1.1). */
        var _subs = Orcamento.subEtapas(e), _idxDe = {}, _valido = {}, _soltos = [], _blocos = {};
        e.itens.forEach(function (it, ii) { _idxDe[it.id] = ii; });
        _subs.forEach(function (sx) { _valido[sx.id] = true; _blocos[sx.id] = []; });
        e.itens.forEach(function (it) {
          var sid0 = (it.subEtapaId && _valido[it.subEtapaId]) ? it.subEtapaId : "";
          if (sid0) _blocos[sid0].push(it); else _soltos.push(it);
        });
        // opções do seletor "em que grupo este item está" (só aparece se a etapa tem sub etapa)
        var _optsSub = "";
        if (_subs.length) {
          _optsSub = '<option value="">— solto na etapa —</option>' + _subs.map(function (sx) {
            var gg = _porSub[sx.id];
            return '<option value="' + sx.id + '">' + Util.esc((gg ? gg.numero + " " : "") + sx.nome) + '</option>';
          }).join("");
        }

        function linhaItem(it, posNoGrupo, tamGrupo, subId) {
          var ii = _idxDe[it.id];
          var L = _porItem[ei + "|" + ii] || { custoTotal: 0, precoTotal: 0, numero: "" };
          var fonte = it.baseFonte || (it.origem === "SINAPI" ? "SINAPI" : "PROPRIO");
          var ehSinapi = it.origem === "SINAPI" && (!it.baseFonte || it.baseFonte === "SINAPI");
          // v1.1.123: composição PRÓPRIA criada no app tem estrutura de insumos → detalhável
          var ehPropriaDet = fonte === "PROPRIA" && (typeof Bases !== "undefined") && (function () {
            var bp = Bases.obter("PROPRIA", it.codigo);
            return !!(bp && bp.insumos && bp.insumos.length);
          })();
          var pillCls = fonte === "SINAPI" ? "sinapi" : (fonte === "PROPRIO" ? "proprio" : String(fonte).toLowerCase());
          // número vem da FONTE ÚNICA (1.2 solto, 1.1.1 dentro de sub etapa)
          var numItem = L.numero || Orcamento.itemNumero(ei, ii);
          var temCod = it.codigo && it.codigo !== "—";
          /* cadeia do accordion: item de sub etapa some se a SUB ou a ETAPA
             estiver recolhida — por isso os dois ids na mesma marcação. */
          var cadeia = subId ? (subId + " " + e.id) : e.id;
          var recSub = subId && typeof App !== "undefined" && App.etapaRecolhida ? App.etapaRecolhida(orc.id, subId) : false;
          var recLinha = rec || recSub;
          var out = '<tr data-etapa-linhas="' + cadeia + '"' + (recLinha ? ' class="oculta"' : "") + '>' +
            // COLUNA "Item" = número hierárquico (2.1). Código SINAPI vai na coluna ao lado (separado).
            '<td class="num-item"><b>' + numItem + '</b></td>' +
            // código CLICÁVEL: abre a composição analítica (mesma ação do 🔍 Insumos)
            '<td>' + (temCod
              ? '<span class="pill ' + pillCls + (ehSinapi || ehPropriaDet ? ' cod-click" data-ver-insumos="' + Util.esc(it.codigo) + '" data-vi-item="' + e.id + '|' + it.id + '" title="Clique para abrir a composição analítica (insumos e coeficientes)"' : '"') + '>' + Util.esc(it.codigo) + '</span>' + (fonte !== "SINAPI" && fonte !== "PROPRIO" ? '<br><span class="muted" style="font-size:9px">' + Util.esc(fonte) + '</span>' : '')
              : '<span class="muted" style="font-size:11px">—</span>') + '</td>' +
            /* ⚠ ITEM PARCIAL NÃO PODE PARECER IGUAL AOS OUTROS. Um serviço
               lançado só com a mão de obra soma ~40% do preço de tabela — sem
               a etiqueta, a planilha entregue não explica a diferença e quem
               confere pensa em erro de preço. */
            '<td>' + Util.esc(it.descricao) +
              (it.modoCusto && it.modoCusto !== "total" && Orcamento.MODOS_CUSTO[it.modoCusto]
                ? ' <span class="g-pill" style="background:#2e6f9e22;color:#2e6f9e;font-weight:700;font-size:10px" title="' +
                  Util.esc(Orcamento.MODOS_CUSTO[it.modoCusto].ajuda) + '">' +
                  Util.esc(Orcamento.MODOS_CUSTO[it.modoCusto].curto) + '</span>' : "") + '</td>' +
            '<td>' + Util.esc(Util.unidadeDe(it.unidade, orc)) + '</td>' +
            /* QUANTIDADE PENDENTE (v1.1.226): item trazido de propósito sem
               metragem, para calcular no memorial depois. Ele NÃO soma no
               total — e some do total calado seria pior que o 1 fabricado que
               isto substituiu. Por isso o campo grita, igual ao custo zerado. */
            '<td class="num"><input class="cell' + (it.qtdPendente ? ' cell-erro' : '') + '" data-edit="quantidade" data-eta="' + e.id + '" data-itm="' + it.id + '" value="' + (it.qtdPendente ? '' : Util.fmtNum(it.quantidade, 2)) + '"' +
              (it.qtdPendente ? ' placeholder="pendente" title="QUANTIDADE PENDENTE — este item não está somando no total. Abra a memória de cálculo para calcular e lançar."' : '') + '></td>' +
            // custo ZERADO = pendência que trava a finalização: o campo grita
            '<td class="num"><input class="cell' + (Util.num(it.custoUnitario) > 0 ? '' : ' cell-erro') + '" data-edit="custoUnitario" data-eta="' + e.id + '" data-itm="' + it.id + '" value="' + Util.fmtNum(it.custoUnitario, 2) + '"' +
              (Util.num(it.custoUnitario) > 0 ? '' : ' title="SEM PREÇO — informe o custo unitário. Orçamento com item zerado não gera proposta nem apresentação."') + '>' +
              UI._seloAjuste(e.id, it) + '</td>' +
            '<td class="num">' + Util.fmtMoeda(L.custoTotal) + '</td>' +
            '<td class="num">' + Util.fmtMoeda(L.precoTotal) + '</td>' +
            '<td class="right"><div class="acoes">' +
              // ▲▼ andam DENTRO do grupo: subir o 1º item de uma sub etapa o
              // arrancaria dela e a numeração sairia 1.1.1, 1.2, 1.1.2.
              '<button class="btn sm ico" data-mover-item="' + e.id + '|' + it.id + '|-1"' + (posNoGrupo === 0 ? ' disabled' : '') + ' title="Subir item">▲</button>' +
              '<button class="btn sm ico" data-mover-item="' + e.id + '|' + it.id + '|1"' + (posNoGrupo === tamGrupo - 1 ? ' disabled' : '') + ' title="Descer item">▼</button>' +
              (_subs.length ? '<select class="cell sel-sub" data-item-sub="' + e.id + '|' + it.id + '" title="Mover este item para outro grupo da etapa">' +
                _optsSub.replace('value="' + (subId || "") + '"', 'value="' + (subId || "") + '" selected') + '</select>' : '') +
              (ehSinapi || ehPropriaDet ? '<button class="btn sm" data-ver-insumos="' + Util.esc(it.codigo) + '" data-vi-item="' + e.id + '|' + it.id + '" title="Ver e ajustar os insumos e coeficientes desta composição">' + (typeof Icones !== 'undefined' ? Icones.get('buscar', 15) : '') + ' Insumos</button>' : '') +
              /* com quantidade pendente o botão do memorial vira o caminho
                 principal: é lá que a metragem nasce, então ele se destaca */
              '<button class="btn sm' + (it.qtdPendente ? ' primary' : ' ico') + (!it.qtdPendente && it.memoriaCalculo ? ' primary' : '') + '" data-memoria="' + e.id + '|' + it.id + '" title="' + (it.qtdPendente ? 'CALCULAR A QUANTIDADE — descreva o serviço e o agente monta a conta' : 'Memória de cálculo do quantitativo (Lei 14.133) — sai na aba Memória do Excel') + '">' + (typeof Icones !== 'undefined' ? Icones.get('nota', 15) : '') + (it.qtdPendente ? ' Calcular' : '') + '</button>' +
              '<button class="btn sm ico danger" data-del-item="' + e.id + '|' + it.id + '" title="Remover item">' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + '</button></div></td></tr>';
          // v1.1.123 — SEMPRE que a composição tiver insumo sem preço coletado no
          // detalhamento, o aviso fica AQUI, embaixo dela na planilha (pedido do
          // Rogério): o usuário clica e informa a cotação manualmente no modal.
          if (ehSinapi) {
            var nSem = UI._insumosSemPrecoDe(it.codigo);
            if (nSem > 0) {
              out += '<tr class="tr-aviso-insumo' + (recLinha ? " oculta" : "") + '" data-etapa-linhas="' + cadeia + '"><td colspan="9">' + UI._avisoInsumoHtml(it.codigo, nSem) + '</td></tr>';
            }
          }
          return out;
        }

        // 1) itens soltos na etapa
        _soltos.forEach(function (it, k) { html += linhaItem(it, k, _soltos.length, ""); });
        // 2) um bloco por sub etapa — cabeçalho (1.1) + os itens dela (1.1.1…)
        _subs.forEach(function (sx, si) {
          var g = _porSub[sx.id] || { numero: "", custoTotal: 0, precoTotal: 0, qtdItens: 0 };
          var recS = (typeof App !== "undefined" && App.etapaRecolhida) ? App.etapaRecolhida(orc.id, sx.id) : false;
          var lst = _blocos[sx.id] || [];
          /* Sub etapa VAZIA não tem número (ver Orcamento.calcular): ela ainda não é
             uma linha do orçamento e os entregáveis não a imprimem — dar número aqui
             abriria um buraco na planilha entregue (1.1 → 1.3). Mostra "—" e explica. */
          var rotNum = g.numero ? '<b>' + g.numero + '</b>'
            : '<span class="muted" title="Recebe o número assim que tiver o primeiro item">—</span>';
          /* classe "subetapa", NÃO "sub": `.main .sub` (css/app.css:137) é a regra de
             SUBTÍTULO do app e estava pintando esta linha com --texto-fraco e 13.5px,
             que é justamente o oposto do pedido (mesma fonte e cor da etapa). */
          html += '<tr class="etapa-row subetapa' + (rec ? " oculta" : "") + '" data-etapa-linhas="' + e.id + '">' +
            '<td data-toggle-etapa="' + sx.id + '" style="cursor:pointer" title="' + (recS ? "Expandir" : "Recolher") + ' esta sub etapa"><span data-chevron-etapa="' + sx.id + '">' + (recS ? "▸" : "▾") + '</span> ' + rotNum + '</td>' +
            '<td colspan="5" data-toggle-etapa="' + sx.id + '" style="cursor:pointer" title="' + (recS ? "Expandir" : "Recolher") + ' esta sub etapa">' + Util.esc(sx.nome) +
              ' <span class="muted" style="font-weight:400;font-size:11px">(' + g.qtdItens + (g.qtdItens === 1 ? " item" : " itens") + ')</span></td>' +
            '<td class="num">' + Util.fmtMoeda(g.custoTotal) + '</td>' +
            '<td class="num">' + Util.fmtMoeda(g.precoTotal) + '</td>' +
            '<td class="right"><div class="acoes">' +
            '<button class="btn sm ico" data-mover-sub="' + e.id + '|' + sx.id + '|-1"' + (si === 0 ? ' disabled' : '') + ' title="Subir sub etapa">▲</button>' +
            '<button class="btn sm ico" data-mover-sub="' + e.id + '|' + sx.id + '|1"' + (si === _subs.length - 1 ? ' disabled' : '') + ' title="Descer sub etapa">▼</button>' +
            '<button class="btn sm" data-add-item="' + e.id + '|' + sx.id + '">+ Item</button>' +
            '<button class="btn sm ico" data-edit-sub="' + e.id + '|' + sx.id + '" title="Renomear sub etapa">' + (typeof Icones !== 'undefined' ? Icones.get('editar', 15) : '') + '</button>' +
            '<button class="btn sm ico danger" data-del-sub="' + e.id + '|' + sx.id + '" title="Remover sub etapa (os itens voltam para a etapa)">' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + '</button></div></td></tr>';
          if (!lst.length) {
            html += '<tr data-etapa-linhas="' + sx.id + ' ' + e.id + '"' + ((rec || recS) ? ' class="oculta"' : "") + '><td></td><td colspan="8" class="muted" style="font-size:12px">Sub etapa ainda sem itens — use <b>+ Item</b> na linha acima.</td></tr>';
          }
          lst.forEach(function (it, k) { html += linhaItem(it, k, lst.length, sx.id); });
        });
      });
      /* RODAPÉ DE TOTAIS — a planilha fechava sem somar nada e o usuário tinha de
         subir até os cartões do topo para saber quanto deu. Os números saem do
         MESMO _c de Orcamento.calcular que gerou as linhas acima, então batem
         com os cartões, o Excel, o relatório e o laudo.
         Com o BDI apartado ("no preço final") o preço unitário dos itens é de
         CUSTO: aí o BDI PRECISA aparecer como linha própria, senão a coluna não
         fecha com o total — o mesmo cuidado que o relatório completo já tem. */
      var _tt = _c; // mesmos números do motor que geraram as linhas acima
      html += '</tbody><tfoot>';
      if (!_c.bdiNoPU) {
        html += '<tr class="tot-linha"><td colspan="6">Custo direto</td>' +
          '<td class="num">' + Util.fmtMoeda(_tt.custoDireto) + '</td><td class="num">—</td><td></td></tr>' +
          '<tr class="tot-linha"><td colspan="6">BDI ' + Util.fmtPct(_c.pct) + ' (sobre o preço final)</td>' +
          '<td class="num">—</td><td class="num">' + Util.fmtMoeda(_tt.bdiValor) + '</td><td></td></tr>';
      }
      html += '<tr class="tot-geral"><td colspan="6">TOTAL GERAL' +
          '<span class="muted" style="font-weight:400;font-size:11px">' +
          ' — ' + _c.qtdItens + (_c.qtdItens === 1 ? " item" : " itens") +
          " em " + _c.qtdEtapas + (_c.qtdEtapas === 1 ? " etapa" : " etapas") +
          (_c.qtdSubEtapas ? " e " + _c.qtdSubEtapas + (_c.qtdSubEtapas === 1 ? " sub etapa" : " sub etapas") : "") +
          (_c.bdiNoPU ? " · BDI " + Util.fmtPct(_c.pct) + " embutido no preço unitário" : "") +
          this._seloPrecisao(_c.modo) +
          '</span></td>' +
        '<td class="num">' + Util.fmtMoeda(_tt.custoDireto) + '</td>' +
        '<td class="num">' + Util.fmtMoeda(_tt.precoVenda) + '</td><td></td></tr>' +
        '</tfoot></table>';
      /* fecha o par que o indice abriu (.pl-tabela e .pl-com-indice) */
      if (_idx) html += '</div></div>';
      return html;
    },

    /* v1.1.123 — quantos insumos da composição estão SEM preço coletado na UF,
     * já descontando as cotações que o usuário preencheu (Store.precosInsumos).
     * Usa o analítico carregado; sem ele carregado, devolve 0 (o modal cobre). */
    _insumosSemPrecoDe: function (codigo) {
      try {
        if (typeof Analitico === "undefined" || !Analitico.carregado) return 0;
        var a = Analitico.obter(codigo);
        if (!a || !a.insumos || !a.insumos.length) return 0;
        var meus = (typeof Store !== "undefined" && Store.precosInsumos) ? Store.precosInsumos(Auth.empresaId()) : {};
        var n = 0;
        a.insumos.forEach(function (i) {
          // conta TODA linha zerada (insumo OU sub-composição) — mesmo critério
          // do modal de detalhamento e da trava de finalização, senão a contagem
          // do aviso diverge do "⛔ N insumo(s) sem preço" do modal
          var cotado = meus[String(i.codigo)] && Number(meus[String(i.codigo)].preco) > 0;
          if (!(Number(i.custoUnitario) > 0) && !cotado) n++;
        });
        return n;
      } catch (e) { return 0; }
    },

    /* Conteúdo do aviso "insumo sem preço" da planilha — compartilhado entre o
     * renderPlanilha e o refresh in-place pós-cotação. */
    _avisoInsumoHtml: function (codigo, n) {
      return '⚠ ' + n + ' insumo(s) desta composição sem preço coletado na sua região — ' +
        '<b data-ver-insumos="' + Util.esc(codigo) + '">clique aqui para informar os valores manualmente</b>. A cotação fica salva para a sua empresa.';
    },

    /* v1.1.123 — depois que o usuário informa cotações no modal, os avisos da
     * planilha atrás são atualizados/removidos SEM re-renderizar a tela. */
    _refreshAvisosInsumo: function () {
      try {
        var trs = document.querySelectorAll("tr.tr-aviso-insumo");
        for (var i = 0; i < trs.length; i++) {
          var b = trs[i].querySelector("[data-ver-insumos]");
          var cod = b ? b.getAttribute("data-ver-insumos") : null;
          if (!cod) continue;
          var n = UI._insumosSemPrecoDe(cod);
          var td = trs[i].querySelector("td");
          if (n > 0) { if (td) td.innerHTML = UI._avisoInsumoHtml(cod, n); }
          else if (trs[i].parentNode) trs[i].parentNode.removeChild(trs[i]);
        }
      } catch (e) {}
    },

    /* v1.1.209 — as unidades que o app conhece, oferecidas em TODO campo de
     * unidade (composição própria e insumo próprio). Um <datalist> só: o id é
     * fixo e o navegador aceita o mesmo para vários inputs; repetir o bloco em
     * cada modal duplicaria 80 <option> por abertura de tela. */
    datalistUnidades: function () {
      var us = (typeof ComposicaoPropria !== "undefined" && ComposicaoPropria.unidadesSugeridas)
        ? ComposicaoPropria.unidadesSugeridas() : [];
      if (!us.length) return "";
      return '<datalist id="lista-unidades">' +
        us.map(function (u) { return '<option value="' + Util.esc(u) + '">'; }).join("") +
        '</datalist>';
    },

    /* v1.1.123 — CRIADOR DE COMPOSIÇÃO PRÓPRIA (2 passos, paridade de mercado).
     * st = App._cp: { passo, comp{codigo,codigoSec,descricao,grupo,unidade,uf,
     *   modeloRef,metodo,maoDeObra,observacao,insumos[]}, referencia, valida } */
    renderCriadorComposicao: function (st) {
      var _ic = function (n, s) { return (typeof Icones !== "undefined") ? Icones.get(n, s || 14) : ""; };
      var c = st.comp;
      var html = '<div class="tabs" style="margin-bottom:14px">' +
        '<div class="tab ' + (st.passo === 1 ? "ativa" : "") + '">Passo 1 — Informações gerais</div>' +
        '<div class="tab ' + (st.passo === 2 ? "ativa" : "") + '">Passo 2 — Estrutura e bases de referência</div></div>';
      if (st.passo === 1) {
        var gruposOpts = ComposicaoPropria.GRUPOS.map(function (g) { return '<option value="' + Util.esc(g) + '"' + (c.grupo === g ? " selected" : "") + '>' + Util.esc(g) + '</option>'; }).join("");
        html += '<div class="row">' +
          '<div class="field"><label>Código *</label><input id="cp-codigo" value="' + Util.esc(c.codigo) + '"></div>' +
          '<div class="field"><label>Código secundário (opcional)</label><input id="cp-codigosec" value="' + Util.esc(c.codigoSec || "") + '" placeholder="Seu código interno"></div></div>' +
          '<div class="field"><label>Descrição do serviço *</label><input id="cp-descricao" value="' + Util.esc(c.descricao || "") + '" placeholder="Ex.: Assentamento de tubo PVC DN 100 com anel elástico, inclusive escavação"></div>' +
          '<div class="row"><div class="field"><label>Tipo de composição (grupo) *</label><select id="cp-grupo"><option value="">— escolha —</option>' + gruposOpts + '</select></div>' +
          /* as unidades vêm do catálogo do motor (datalist): digitar continua
             livre — a lista é atalho, não gaiola. Antes o campo era um input
             seco e a única pista do vocabulário era a mensagem de erro. */
          '<div class="field" style="max-width:140px"><label>Unidade *</label><input id="cp-unidade" list="lista-unidades" autocomplete="off" value="' + Util.esc(c.unidade || "") + '" placeholder="m², un, cx…">' + UI.datalistUnidades() + '</div></div>' +
          /* ⚠ ÍCONE NUNCA DENTRO DE title="". O Icones.get devolve um <svg …>
             com aspas duplas: a primeira delas FECHAVA o title e o resto do
             texto vazava para a tela — o modal mostrava um « Tabelas"> » solto
             embaixo do campo Estado, e o tooltip nunca aparecia. title é texto
             puro; o nome da tela basta. */
          '<div class="row"><div class="field"><label>Estado (base de preços ativa)</label><input value="' + Util.esc(c.uf || "") + '" disabled title="A composição usa os preços da base ativa — troque o estado na tela Tabelas"></div>' +
          '<div class="field"><label>Modelo de referência</label><div class="flex" style="gap:12px;padding-top:8px">' +
            '<label style="cursor:pointer"><input type="radio" name="cp-modelo" value="SINAPI"' + (c.modeloRef !== "SICRO" ? " checked" : "") + '> SINAPI</label>' +
            '<label style="cursor:pointer"><input type="radio" name="cp-modelo" value="SICRO"' + (c.modeloRef === "SICRO" ? " checked" : "") + '> SICRO3</label></div></div></div>' +
          '<div class="field"><label>Método de cálculo</label>' +
            '<label style="display:block;cursor:pointer;padding:3px 0"><input type="radio" name="cp-metodo" value="truncar2"' + (c.metodo !== "arred2" && c.metodo !== "nenhum" ? " checked" : "") + '> Truncar em 2 casas decimais <span class="ow-selo" style="background:#16a34a;color:#fff;font-size:10px;font-weight:800;padding:2px 7px;border-radius:99px;margin-left:6px">Padrão TCU</span></label>' +
            '<label style="display:block;cursor:pointer;padding:3px 0"><input type="radio" name="cp-metodo" value="arred2"' + (c.metodo === "arred2" ? " checked" : "") + '> Arredondar em 2 casas decimais</label>' +
            '<label style="display:block;cursor:pointer;padding:3px 0"><input type="radio" name="cp-metodo" value="nenhum"' + (c.metodo === "nenhum" ? " checked" : "") + '> Não arredondar</label></div>' +
          '<label style="cursor:pointer;display:inline-flex;align-items:center;gap:8px;margin:6px 0"><input type="checkbox" id="cp-mo"' + (c.maoDeObra ? " checked" : "") + '> Composição com mão de obra</label>' +
          '<div class="field"><label>Observação</label><textarea id="cp-obs" rows="2">' + Util.esc(c.observacao || "") + '</textarea></div>' +
          '<div class="flex" style="gap:8px;margin-top:6px;flex-wrap:wrap">' +
            /* `longo`: o rótulo tem 355px e a caixa cabe em 313px a 375px. Sem a
               exceção, o `white-space: nowrap` do `.btn` trava tudo numa linha
               e a centralização derrama o excedente PARA OS DOIS LADOS — o
               usuário lia um pedaço do meio da frase, sem começo nem fim. */
            '<button class="btn primary longo" data-acao="cp-agente">' + _ic("escopo") + 'Agente especialista — montar pela referência oficial</button>' +
            '<button class="btn success" data-acao="cp-passo2" style="margin-left:auto">Próximo →</button></div>' +
          '<p class="muted" style="font-size:11px;margin-top:8px">O agente lê a sua descrição, encontra a composição oficial mais parecida no detalhamento da sua UF e propõe a estrutura com <b>coeficientes reais</b> — nunca inventa código nem preço; você revisa tudo no passo 2.</p>';
      } else {
        var custo = ComposicaoPropria.custo(c.insumos, c.metodo);
        var linhas = (c.insumos || []).map(function (i, idx) {
          var tot = (Number(i.coeficiente) || 0) * (Number(i.custoUnitario) || 0);
          var semPreco = !(Number(i.custoUnitario) > 0);
          return '<tr>' +
            '<td><span class="pill sinapi">' + Util.esc(i.codigo) + '</span></td>' +
            '<td style="max-width:320px">' + Util.esc(i.descricao) + '</td>' +
            /* a composição própria mistura bases de propósito (um insumo da
               SINAPI, outro do SICRO): sem normalizar, a MESMA unidade sai
               "M2" numa linha e "m²" na de baixo, na mesma tabela. O DADO
               continua como o órgão publicou — só a exibição é uniformizada. */
            '<td>' + Util.esc(Util.unidadeExibir(i.unidade)) + '</td>' +
            /* MEMÓRIA DO COEFICIENTE (v1.1.223): o número mais difícil de
               defender numa própria ganha o "por quê" ao lado. A calculadora
               abre no clique; o campo aceita texto livre para quem prefere
               escrever. Verde quando já tem justificativa — é o sinal de que
               aquela linha se defende sozinha. */
            '<td class="num"><input class="cell" data-cp-coef="' + idx + '" value="' + Util.fmtNum(i.coeficiente, 4) + '" style="width:86px">' +
              '<button class="btn sm ' + (i.memoria ? "success" : "ghost") + '" data-acao="cp-memoria" data-i="' + idx + '" ' +
              'style="font-size:10px;padding:1px 5px;margin-top:2px" title="' +
              (i.memoria ? Util.esc(String(i.memoria).replace(/\n/g, " · ")) : "Justificar este coeficiente (calculadora ou texto)") + '">' +
              (i.memoria ? "✓ justificado" : "por quê?") + '</button></td>' +
            // sem preço coletado na região → o usuário informa a cotação AQUI
            // (fica salva p/ a empresa, igual ao modal de detalhamento)
            '<td class="num">' + (semPreco
              ? '<input class="cell cell-erro" data-cp-preco="' + idx + '" value="" placeholder="informe R$" title="Insumo sem preço coletado na sua região — informe a cotação (fica salva para a sua empresa)" style="width:96px">'
              : Util.fmtMoeda(i.custoUnitario)) + '</td>' +
            '<td>' + Util.esc(i.categoria || "") + '</td>' +
            '<td class="num" data-cp-tot="' + idx + '">' + Util.fmtMoeda(tot) + '</td>' +
            '<td><button class="btn sm ico danger" data-cp-del="' + idx + '">' + (typeof Icones !== 'undefined' ? Icones.get('fechar', 15) : '') + '</button></td></tr>';
        }).join("");
        html += '<div class="muted" style="font-size:12px;margin-bottom:8px"><b>' + Util.esc(c.codigo) + '</b> — ' + Util.esc(c.descricao || "(sem descrição)") + ' · ' + Util.esc(Util.unidadeExibir(c.unidade) || "?") + (st.referencia ? ' · <span class="pill sinapi">ref. ' + Util.esc(st.referencia.codigo) + '</span>' : '') + '</div>' +
          '<div class="field"><label>Adicionar insumo/composição das bases reais (busque por código ou descrição)</label>' +
          '<input id="cp-busca" placeholder="Ex.: 88316, servente, tubo pvc 100…"></div>' +
          '<div id="cp-busca-res" style="max-height:180px;overflow-y:auto;margin-bottom:10px"></div>' +
          '<table class="tbl"><thead><tr><th>Código</th><th>Insumo</th><th>Und</th><th class="num">Coef.</th><th class="num">Preço</th><th>Categoria</th><th class="num">Total</th><th></th></tr></thead>' +
          '<tbody>' + (linhas || '<tr><td colspan="8" class="muted">Nenhum insumo ainda — busque acima ou use o Agente no passo 1.</td></tr>') + '</tbody></table>' +
          '<div class="kpis" style="margin-top:12px">' +
            '<div class="kpi"><div class="rotulo">Mão de obra</div><div class="num" id="cp-kpi-mo">' + Util.fmtMoeda(custo.mo) + '</div></div>' +
            '<div class="kpi"><div class="rotulo">Material</div><div class="num" id="cp-kpi-mat">' + Util.fmtMoeda(custo.mat) + '</div></div>' +
            '<div class="kpi"><div class="rotulo">Equipamento</div><div class="num" id="cp-kpi-eq">' + Util.fmtMoeda(custo.eq) + '</div></div>' +
            '<div class="kpi destaque"><div class="rotulo">Custo unitário (' + (c.metodo === "nenhum" ? "sem arredondar" : c.metodo === "arred2" ? "arredondado" : "truncado · TCU") + ')</div><div class="num destaque" id="cp-kpi-total">' + Util.fmtMoeda(custo.total) + '</div></div></div>' +
          '<div id="cp-valida" style="margin-top:10px"></div>' +
          '<div class="flex" style="gap:8px;margin-top:10px">' +
            '<button class="btn ghost" data-acao="cp-passo1">' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Voltar</button>' +
            '<button class="btn success" data-acao="cp-salvar" style="margin-left:auto">' + _ic("check") + 'Validar e gravar na base própria</button></div>';
      }
      return html;
    },

    // ----- Modal: composição explodida em insumos (base analítica SINAPI) -----
    renderInsumos: function (a, ufAtivo) {
      var catLabel = { MO: "Mão de obra", MAT: "Material", EQ: "Equipamento" };
      function box(rotulo, valor, classe) {
        return '<div class="kpi"><div class="rotulo">' + rotulo + '</div>' +
          '<div class="num' + (classe ? " " + classe : "") + '">' + Util.fmtMoeda(valor) + '</div></div>';
      }
      var anaUf = (typeof Analitico !== "undefined") ? Analitico.uf : null;
      var aviso = (ufAtivo && anaUf && ufAtivo !== anaUf)
        ? '<div class="muted mb" style="color:#f59e0b;font-size:12px">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Analítico de referência da UF <b>' + Util.esc(anaUf) + '</b> (a base ativa é <b>' + Util.esc(ufAtivo) + '</b>). Coeficientes são nacionais; os preços exibidos aqui são da UF de referência.</div>'
        : '';
      var html = aviso + '<div class="muted mb"><b>' + Util.esc(a.codigo) + '</b> · ' + Util.esc(a.unidade) +
        (a.grupo ? ' · ' + Util.esc(a.grupo) : '') + '<br>' + Util.esc(a.descricao) + '</div>';
      html += '<div class="kpis">' +
        box("Mão de obra", a.custoMO) + box("Material", a.custoMAT) +
        box("Equipamento", a.custoEQ) + box("Custo Unit.", a.custoUnitario, "destaque") + '</div>';

      // "não coletado": preço zerado NA FONTE para esta UF (o SINAPI publica em
      // branco o que não coletou na região). O usuário COTA e informa o preço
      // dele — fica salvo por empresa (vale p/ toda composição com o insumo) e
      // os entregáveis marcam "informado por você". Enquanto houver pendência,
      // o orçamento com item zerado não finaliza.
      var meusPrecos = {};
      try { if (typeof Store !== "undefined" && Store.precosInsumos) meusPrecos = Store.precosInsumos(Auth.empresaId()); } catch (eP) {}
      var somaIns = 0, temZero = false, pendentes = 0;

      html += '<table class="tbl tbl-analitico"><thead><tr><th></th><th>Código</th><th>Insumo</th><th>Und</th>' +
        '<th class="num">Coef.</th><th class="num">Custo Unit</th><th class="num">Custo Total</th><th>Categoria</th></tr></thead><tbody>';
      // 1ª linha = a PRÓPRIA composição (verde, como o mercado apresenta)
      html += '<tr class="lin-comp"><td><span class="tag-tipo tag-c" title="Composição">C</span></td>' +
        '<td><b>' + Util.esc(a.codigo) + '</b></td>' +
        '<td>' + Util.esc(a.descricao) + '</td>' +
        '<td>' + Util.esc(a.unidade) + '</td>' +
        '<td class="num">1,0</td>' +
        '<td class="num"><b>' + Util.fmtMoeda(a.custoUnitario) + '</b></td>' +
        '<td class="num"><b>' + Util.fmtMoeda(a.custoUnitario) + '</b></td>' +
        '<td>' + (a.grupo ? '<span class="pill sinapi">' + Util.esc(a.grupo) + '</span>' : '') + '</td></tr>';
      Util.arr(a.insumos).forEach(function (it) {
        var sub = (it.tipo === "COMPOSICAO");
        var zerado = !Util.num(it.custoUnitario);
        var meu = zerado ? meusPrecos[String(it.codigo)] : null;
        var celUnit, celTotal, classeExtra = "";
        if (!zerado) {
          somaIns += Util.num(it.custoTotal);
          celUnit = Util.fmtMoeda(it.custoUnitario);
          celTotal = Util.fmtMoeda(it.custoTotal);
        } else if (meu && Util.num(meu.preco) > 0) {
          // cotação do usuário preenche a lacuna — some no total e leva o selo
          temZero = true;
          var totMeu = Util.num(it.coeficiente) * Util.num(meu.preco);
          somaIns += totMeu;
          celUnit = '<input class="preco-user" data-preco-insumo="' + Util.esc(it.codigo) + '" value="' + Util.fmtNum(meu.preco, 2) + '" title="Preço informado por você — edite ou apague para voltar a pendente">';
          celTotal = Util.fmtMoeda(totMeu) + ' <span class="selo-user" title="Calculado com o preço que você informou">' + (typeof Icones !== 'undefined' ? Icones.get('pessoa', 15) : '') + '</span>';
        } else {
          // PENDENTE: o SINAPI não coletou nesta UF — o usuário precisa cotar
          temZero = true; pendentes++;
          classeExtra = " lin-pendente";
          celUnit = '<input class="preco-user pendente" data-preco-insumo="' + Util.esc(it.codigo) + '" placeholder="informe R$" title="Preço não coletado pelo SINAPI nesta UF — informe a sua cotação">';
          celTotal = '<span class="txt-pendente">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' sem preço</span>';
        }
        // sub-composição: código clicável abre o detalhamento DELA (drill-down)
        var celCod = sub
          ? '<a href="javascript:void 0" class="cod-link" data-ver-insumos="' + Util.esc(it.codigo) + '" title="Abrir a composição analítica de ' + Util.esc(it.codigo) + '">' + Util.esc(it.codigo) + '</a>'
          : Util.esc(it.codigo);
        html += '<tr class="' + (sub ? "lin-sub" : "lin-ins") + classeExtra + '">' +
          '<td><span class="tag-tipo ' + (sub ? "tag-s" : "tag-i") + '" title="' + (sub ? "Sub-composição" : "Insumo") + '">' + (sub ? "S" : "I") + '</span></td>' +
          '<td>' + celCod + '</td>' +
          '<td>' + Util.esc(it.descricao) + '</td>' +
          '<td>' + Util.esc(Util.unidadeExibir(it.unidade)) + '</td>' +
          /* JUSTIFICATIVA DO COEFICIENTE (v1.1.223): quem abre o detalhamento
             está perguntando "de onde vem esse número". Quando a composição
             própria responde, a resposta fica ali, não escondida. */
          '<td class="num">' + UI._celCoeficiente(it) +
            (it.memoria ? '<div class="watermark-hint" style="max-width:220px;white-space:normal;text-align:left" title="' +
              Util.esc(it.memoria) + '">' + Util.esc(String(it.memoria).replace(/\n/g, " · ").slice(0, 90)) + '</div>' : "") + '</td>' +
          '<td class="num">' + celUnit + '</td>' +
          '<td class="num">' + celTotal + '</td>' +
          '<td><span class="pill ' + (it.categoria === "MAT" ? "sinapi" : "proprio") + '">' + (catLabel[it.categoria] || it.categoria) + '</span></td></tr>';
      });
      html += '</tbody></table>';
      if (pendentes > 0) {
        html += '<div class="mb" style="padding:9px 12px;border-radius:8px;background:rgba(220,38,38,.10);border:1px solid rgba(220,38,38,.25);font-size:12px;margin-top:8px">' +
          '⛔ <b>' + pendentes + ' insumo(s) sem preço coletado' + (anaUf ? ' em ' + Util.esc(anaUf) : '') + '.</b> ' +
          'Informe a sua cotação nos campos <b>“informe R$”</b> acima — o valor fica salvo para a sua empresa e vale em toda composição que usa o insumo. ' +
          'Orçamento com item zerado <b>não pode ser finalizado</b>.</div>';
      }
      // reconciliação honesta: se a soma dos insumos ficou longe do custo oficial
      // (preços não coletados na UF), avisa — e reafirma que o orçamento não é
      // afetado. O "oficial" vem do cabeçalho analítico e, quando este também
      // está zerado, do SINTÉTICO — que é o preço que o orçamento realmente usa.
      var oficialRef = Util.num(a.custoUnitario);
      if (!oficialRef && typeof Sinapi !== "undefined" && Sinapi.obter) {
        var _sRef = Sinapi.obter(a.codigo);
        if (_sRef) oficialRef = Util.num(_sRef.custoUnitario);
      }
      if (temZero && oficialRef > 0 && somaIns < oficialRef * 0.98) {
        html += '<div class="mb" style="padding:9px 12px;border-radius:8px;background:rgba(245,158,11,.12);font-size:12px;margin-top:8px">' +
          '⚠ <b>Detalhamento parcial nesta UF:</b> o SINAPI não coletou o preço de parte dos insumos ' +
          (anaUf ? 'em <b>' + Util.esc(anaUf) + '</b>' : 'nesta região') +
          '. A soma exibida (' + Util.fmtMoeda(somaIns) + ') fica abaixo do preço oficial da composição (<b>' + Util.fmtMoeda(oficialRef) + '</b>), que é o valor usado no seu orçamento.</div>';
      }
      html += '<p class="muted mt" style="font-size:12px">Base analítica SINAPI ' +
        (typeof Analitico !== "undefined" ? (Analitico.competencia || "") + " / " + (Analitico.uf || "") : "") +
        ' — composição → insumos com coeficientes. Clique no código de uma sub-composição (S) para abrir o detalhamento dela. O orçamento usa o preço da sua competência.</p>';
      return html;
    },

    /* -----------------------------------------------------------------
     * QUADRO DE JUSTIFICATIVA DE PREÇOS — o anexo do orçamento impresso.
     *
     * POR QUE ISTO É UM ANEXO E NÃO UMA COLUNA: quem analisa um orçamento não
     * lê a planilha inteira procurando o que foi mexido; quer a lista curta do
     * que difere da referência oficial, com o motivo ao lado. É a peça que a
     * Lei 14.133/2021 espera junto da proposta quando há preço acima da base —
     * e a que o TCU pede para entender como se chegou nele.
     *
     * Sai ordenado por IMPACTO EM DINHEIRO, não por número do item: um desvio
     * de 40% num item de R$ 200 importa menos que 3% num item de R$ 80.000, e
     * quem revisa tem tempo para os primeiros da lista.
     * ----------------------------------------------------------------- */
    renderQuadroAjustes: function (orc, numeroSecao) {
      if (typeof Ajustes === "undefined" || !Ajustes.resumo) return "";
      var r = Ajustes.resumo(orc);
      if (!r.n) return "";
      var semJust = r.itens.filter(function (i) { return i.preco && i.preco.dif > 0 && !i.preco.motivo; }).length;

      /* o número do item vem da MESMA fonte da planilha (Orcamento.calcular) —
         numerar por índice aqui produziria "2.3" no quadro e "2.1.3" na
         planilha para o mesmo item, e quem confere as duas acha erro */
      var numDe = {};
      try {
        Util.arr(Orcamento.calcular(orc).linhas).forEach(function (L) {
          if (L && L.itemId) numDe[L.itemId] = L.numero || "";
        });
      } catch (e) {}

      var html = '<h2 class="rel-tit">' + (numeroSecao ? numeroSecao + ". " : "") +
        'Quadro de Justificativa de Preços</h2>';
      html += '<p class="muted" style="margin:-6px 0 10px;font-size:12px">' +
        '<b>' + r.n + '</b> item(ns) com preço diferente do da base de referência' +
        (r.nCoeficientes ? ', e <b>' + r.nCoeficientes + '</b> coeficiente(s) de composição ajustado(s)' : '') +
        '. Os demais itens do orçamento seguem integralmente o preço da base ' +
        Util.esc(Orcamento.basesUsadasTexto(orc)) + '. Ordenado pelo impacto em reais.</p>';

      html += '<table class="prop-tbl"><thead><tr>' +
        '<th>Item</th><th>Código</th><th>Descrição</th><th class="r">Qtd</th>' +
        '<th class="r">Preço da base</th><th class="r">Preço adotado</th>' +
        '<th class="r">Var.</th><th class="r">Impacto</th><th>Justificativa</th>' +
        '</tr></thead><tbody>';

      r.itens.forEach(function (i) {
        var d = i.preco;
        var coefs = i.deltas.filter(function (x) { return x.coeficiente; });
        var just = (d && d.motivo) || (i.deltas[0] && i.deltas[0].motivo) || "";
        html += '<tr>' +
          '<td>' + Util.esc(numDe[i.itemId] || "") + '</td>' +
          '<td>' + Util.esc(i.codigo) + '</td>' +
          '<td>' + Util.esc(Util.fixEnc(i.descricao)) +
            (coefs.length ? '<br><span class="muted" style="font-size:10.5px">' + coefs.length +
              ' coeficiente(s) ajustado(s): ' +
              Util.esc(coefs.map(function (c) {
                return String(c.campo).slice(5) + " " + Ajustes.fmtN(c.base, 4) + "→" + Ajustes.fmtN(c.atual, 4);
              }).join(" · ")) + '</span>' : '') + '</td>' +
          '<td class="r">' + Util.fmtNum(i.quantidade, 2) + ' ' + Util.esc(Util.unidadeExibir(i.unidade)) + '</td>' +
          (d
            ? '<td class="r">' + (d.semBase ? "—" : Util.fmtMoeda(d.base)) + '</td>' +
              '<td class="r"><b>' + Util.fmtMoeda(d.atual) + '</b></td>' +
              '<td class="r">' + (d.semBase ? "sem preço na base" : Ajustes.fmtPct(d.pct)) + '</td>' +
              '<td class="r">' + (i.impacto > 0 ? "+" : "−") + Util.fmtMoeda(Math.abs(i.impacto)) + '</td>'
            : '<td class="r">—</td><td class="r">—</td><td class="r">—</td><td class="r">—</td>') +
          '<td>' + (just ? Util.esc(just)
            : '<span style="font-style:italic">' + (d && d.dif > 0 ? "a justificar" : "—") + '</span>') + '</td>' +
          '</tr>';
      });

      html += '<tr class="sub"><td colspan="7">Efeito líquido das alterações sobre o custo direto</td>' +
        '<td class="r"><b>' + (r.impacto > 0 ? "+" : "−") + Util.fmtMoeda(Math.abs(r.impacto)) + '</b>' +
        (r.pct == null ? "" : '<br><span class="muted" style="font-size:10.5px">' + Ajustes.fmtPct(r.pct) +
          ' sobre estes itens</span>') + '</td><td></td></tr>';
      html += '</tbody></table>';

      if (semJust) {
        html += '<p class="muted" style="font-size:11.5px;margin-top:6px">' +
          '<b>' + semJust + '</b> item(ns) acima do preço de referência ainda sem justificativa registrada.</p>';
      }
      return html;
    },

    /* -----------------------------------------------------------------
     * CÉLULA DO COEFICIENTE no detalhamento analítico.
     *
     * Editável só quando o modal foi aberto por um ITEM do orçamento
     * (`UI._ajusteCtx`). Pela aba de bases continua texto: ali o usuário está
     * olhando a referência oficial, e campo editável naquele contexto sugere
     * que dá para reescrever a SINAPI — que é justamente o que não pode.
     * ----------------------------------------------------------------- */
    _celCoeficiente: function (ins) {
      var ctx = UI._ajusteCtx;
      var cod = String(ins.codigo || "");
      if (!ctx || !ctx.item || typeof Ajustes === "undefined") return Util.fmtNum(ins.coeficiente, 4);
      var ajust = ctx.item.coeficientes || {};
      var val = (cod in ajust) ? Util.num(ajust[cod]) : Util.num(ins.coeficiente);
      var d = Ajustes.delta(ctx.item, "coef:" + cod, val);
      var out = '<input class="cell coef-edit' + (d ? " mexido" : "") + '" data-coef-aj="' + Util.esc(cod) +
        '" value="' + Util.fmtNum(val, 4) + '" style="width:82px"' +
        ' title="Coeficiente da composição. Altere para a produtividade da sua equipe — a referência da base fica guardada.">';
      if (d) {
        out += '<button class="selo-ajuste ' + (d.dif > 0 ? "sobe" : "desce") + '" data-coef-restaurar="' + Util.esc(cod) + '"' +
          ' title="Era ' + Ajustes.fmtN(d.base, 4) + ' na base. Clique para restaurar.">' + Util.esc(Ajustes.selo(d)) + '</button>';
      }
      return out;
    },

    /* -----------------------------------------------------------------
     * SELO "ALTERADO POR VOCÊ" — mora DENTRO da célula do custo unitário.
     *
     * Por que não uma coluna nova: a planilha já tem 9 colunas e é o lugar
     * mais disputado da tela. Uma coluna a mais espremeria descrição em toda
     * linha por causa de um aviso que aparece em 4% delas. O selo fica
     * embaixo do próprio campo que mudou — onde o olho já está.
     *
     * O selo é BOTÃO, não texto: quem vê "+4,0%" quer saber de quanto era, e
     * a resposta tem que estar a um clique, não numa outra tela.
     * ----------------------------------------------------------------- */
    _seloAjuste: function (etapaId, it) {
      if (typeof Ajustes === "undefined" || !Ajustes.delta) return "";
      var d = Ajustes.delta(it, "custoUnitario", it.custoUnitario);
      var nCoef = Ajustes.campos(it).filter(function (c) { return c.indexOf("coef:") === 0; }).length;
      if (!d && !nCoef) return "";
      var out = "";
      if (d) {
        var cls = d.semBase ? "novo" : (d.dif > 0 ? "sobe" : "desce");
        out += '<button class="selo-ajuste ' + cls + '" data-ajuste="' + etapaId + '|' + it.id + '"' +
          ' title="' + Util.esc(Ajustes.frase(d)) + ' Clique para ver e restaurar.">' +
          Util.esc(Ajustes.selo(d)) + '</button>';
      }
      if (nCoef) {
        out += '<button class="selo-ajuste coef" data-ajuste="' + etapaId + '|' + it.id + '"' +
          ' title="' + nCoef + ' coeficiente(s) desta composição alterado(s) por você. Clique para ver e restaurar.">' +
          nCoef + ' coef.</button>';
      }
      return out;
    },

    /* Faixa no alto da planilha: o revisor precisa da conta em DINHEIRO
       ("12 itens mexidos somam +R$ 8.430"), não do número de itens solto. */
    _faixaAjustes: function (orc) {
      if (typeof Ajustes === "undefined" || !Ajustes.resumo) return "";
      var r = Ajustes.resumo(orc);
      if (!r.n) return "";
      var sinal = r.impacto > 0 ? "acima" : (r.impacto < 0 ? "abaixo" : "no mesmo valor");
      var pct = r.pct == null ? "" : " (" + Ajustes.fmtPct(r.pct) + ")";
      return '<div class="faixa-ajustes">' +
        '<span class="fa-ico">' + (typeof Icones !== "undefined" ? Icones.get("editar", 16) : "") + '</span>' +
        '<span class="fa-txt"><b>' + r.n + ' item(ns) com valor alterado por você</b> — ' +
        (r.impacto === 0 ? 'as alterações se anulam, o total fica ' + sinal :
          'somam <b>' + Util.fmtMoeda(Math.abs(r.impacto)) + '</b> ' + sinal + ' do preço da base' + pct) +
        (r.nCoeficientes ? ' · ' + r.nCoeficientes + ' coeficiente(s) ajustado(s)' : '') +
        '</span>' +
        '<button class="btn sm" data-ajustes-lista="1">Ver todos</button></div>';
    },

    // ----- Aba Sintético -----
    /* =================================================================
     * INSUMOS DESTE ORÇAMENTO — a lista de compras, e a curva ABC
     *
     * O motor esta em js/insumosorc.js (puro, testavel). Aqui so a tela.
     *
     * ⚠ ESTA TELA MOSTRA A COBERTURA NA CARA, E ISSO NAO E DETALHE. Item
     * digitado a mao, composicao propria sem analitico ou codigo de outra
     * base nao explodem em insumo. Sem o aviso, a lista sai curta com cara
     * de completa — e alguem compra material a menos numa obra inteira por
     * causa de uma tela que parecia certa.
     *
     * ⚠ E DIZ QUE E CUSTO DIRETO, SEM BDI. O total daqui nao bate com o do
     * orcamento de proposito; quem comparar tem de achar a explicacao
     * escrita, senao procura um erro que nao existe.
     * ================================================================= */
    renderInsumosOrc: function (orc) {
      if (typeof InsumosOrc === "undefined") return '<div class="vazio card">Módulo de insumos indisponível.</div>';
      if (!(orc.etapas || []).length) return '<div class="vazio card"><h3>Sem itens para abrir em insumos</h3><span class="muted">Monte a planilha primeiro: cada serviço lançado vira material, mão de obra e equipamento aqui.</span></div>';

      var temBase = (typeof Analitico !== "undefined" && Analitico.carregado);
      if (!temBase) {
        /* ⚠ NAO CARREGA SOZINHO AO ABRIR A ABA. O analitico tem ~17 MB; puxar
           isso porque alguem passou pela aba gasta a franquia de quem esta no
           celular do canteiro. O botao deixa a escolha com quem le. */
        return '<div class="card"><h3 style="margin:0 0 8px">Abrir o orçamento em insumos</h3>'
          + '<p class="muted" style="margin:0 0 12px;font-size:13px">Para listar o material da obra e montar a curva ABC, é preciso carregar a base analítica do estado — são cerca de 17 MB, e só na primeira vez.</p>'
          + '<button class="btn primary" data-acao="insumos-carregar-base">Carregar a base e abrir</button></div>';
      }

      var linhas = (typeof Orcamento !== "undefined") ? Orcamento.linhas(orc) : [];
      var res = InsumosOrc.consolidar(linhas, function (c) { return Analitico.obter(c); });
      var abc = InsumosOrc.resumoABC(res);
      var f = App._insumosOrcFiltro || { busca: "", cat: "TODAS" };
      var lista = InsumosOrc.filtrar(res.insumos, f.busca, f.cat);
      var self = this;

      /* o cabecalho diz de quanto do orcamento esta lista da conta */
      var corCob = res.cobertura >= 90 ? "var(--verde)" : (res.cobertura >= 60 ? "var(--amarelo)" : "var(--vermelho)");
      var html = '<div class="card" style="margin-bottom:14px">'
        + '<div class="kpis" style="margin-bottom:0">'
        + '<div class="kpi kpi-compacto"><div class="rotulo">Insumos diferentes</div><div class="num">' + res.nInsumos + '</div>'
        + '<div class="kpi-sub">de ' + res.nLinhas + ' serviço(s) na planilha</div></div>'
        + '<div class="kpi kpi-compacto"><div class="rotulo">Custo direto aberto</div><div class="num">' + Util.fmtMoeda(res.somaInsumos) + '</div>'
        + '<div class="kpi-sub">material, mão de obra e equipamento</div></div>'
        + '<div class="kpi kpi-compacto"><div class="rotulo">Cobertura</div><div class="num" style="color:' + corCob + '">' + Util.fmtNum(res.cobertura, 1) + '%</div>'
        + '<div class="kpi-sub">' + (res.naoDetalhado.length ? res.naoDetalhado.length + ' item(ns) sem composição — ver abaixo' : 'todo o orçamento abriu em insumo') + '</div></div>'
        + '<div class="kpi kpi-compacto"><div class="rotulo">Classe A</div><div class="num">' + abc.A.n + '</div>'
        + '<div class="kpi-sub">' + Util.fmtMoeda(abc.A.valor) + ' — os que levam 80% do dinheiro</div></div>'
        + '</div></div>';

      html += '<div class="card" style="margin-bottom:12px;padding:12px 14px">'
        + '<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">'
        + '<input type="search" id="ins-busca" placeholder="Buscar insumo ou código…" value="' + Util.esc(f.busca) + '" style="flex:1;min-width:200px">'
        + '<select id="ins-cat"><option value="TODAS">Todas as categorias</option>'
        + '<option value="MAT"' + (f.cat === "MAT" ? " selected" : "") + '>Só material</option>'
        + '<option value="MO"' + (f.cat === "MO" ? " selected" : "") + '>Só mão de obra</option>'
        + '<option value="EQ"' + (f.cat === "EQ" ? " selected" : "") + '>Só equipamento</option></select>'
        + '<button class="btn sm" data-acao="insumos-csv">Exportar CSV</button>'
        + '</div>'
        + '<p class="muted" style="font-size:12px;margin:8px 0 0">Quantidade e custo somam o mesmo insumo em todos os serviços. Valores em <b>custo direto, sem BDI</b> — é o que se paga ao fornecedor, não o que vai na proposta.</p>'
        + '</div>';

      if (!lista.length) {
        html += '<div class="vazio card"><h3>Nenhum insumo neste recorte</h3><span class="muted">Tire o filtro para ver a lista inteira.</span></div>';
      } else {
        html += '<div class="card" style="padding:0;overflow:auto"><table class="tbl"><thead><tr>'
          + '<th style="width:44px">ABC</th><th>Insumo</th><th>Un</th>'
          + '<th class="num">Quantidade</th><th class="num">Custo unit.</th><th class="num">Custo total</th>'
          + '<th class="num">% do custo</th></tr></thead><tbody>';
        lista.forEach(function (x) {
          html += '<tr><td><span class="ins-abc ins-' + x.classe + '">' + x.classe + '</span></td>'
            + '<td><b>' + Util.esc(x.descricao || "(sem descrição)") + '</b>'
            + '<div class="muted" style="font-size:11.5px">' + (x.codigo ? Util.esc(x.codigo) + " · " : "")
            + self._catRotulo(x.categoria) + (x.emServicos > 1 ? " · em " + x.emServicos + " serviços" : "") + '</div></td>'
            + '<td>' + Util.esc(x.unidade || "") + '</td>'
            + '<td class="num">' + Util.fmtNum(x.quantidade, 2) + '</td>'
            + '<td class="num">' + Util.fmtMoeda(x.custoUnitario) + '</td>'
            + '<td class="num"><b>' + Util.fmtMoeda(x.custoTotal) + '</b></td>'
            + '<td class="num">' + Util.fmtNum(x.pct, 1) + '%</td></tr>';
        });
        html += '</tbody></table></div>';
      }

      /* ⚠ O BALDE DO QUE NAO ABRIU FICA VISIVEL, com o motivo de cada um.
         E aqui que a pessoa descobre por que a lista de compras esta
         incompleta — e o que fazer para completa-la. */
      if (res.naoDetalhado.length) {
        html += '<div class="card" style="margin-top:14px">'
          + '<h3 style="margin:0 0 6px">' + res.naoDetalhado.length + ' item(ns) fora da lista de compras</h3>'
          + '<p class="muted" style="font-size:12.5px;margin:0 0 10px">Somam <b>' + Util.fmtMoeda(res.custoFechado)
          + '</b> do custo direto e não viraram material porque não têm composição na base analítica. O valor está no orçamento; o que falta é o detalhamento.</p>'
          + '<table class="tbl"><thead><tr><th>Código</th><th>Serviço</th><th class="num">Custo</th><th>Por quê</th></tr></thead><tbody>';
        res.naoDetalhado.slice(0, 40).forEach(function (x) {
          html += '<tr><td>' + Util.esc(x.codigo || "—") + '</td><td>' + Util.esc(x.descricao || "—") + '</td>'
            + '<td class="num">' + Util.fmtMoeda(x.custoTotal) + '</td>'
            + '<td class="muted">' + Util.esc(x.motivo) + '</td></tr>';
        });
        html += '</tbody></table>';
        if (res.naoDetalhado.length > 40) html += '<p class="muted" style="font-size:11.5px;margin:8px 0 0">Mostrando os 40 maiores de ' + res.naoDetalhado.length + '.</p>';
        html += '</div>';
      }
      return html;
    },

    _catRotulo: function (c) {
      var m = { MAT: "Material", MO: "Mão de obra", EQ: "Equipamento" };
      return m[String(c || "").toUpperCase()] || "Material";
    },

    renderSintetico: function (orc) {
      var lin = Orcamento.sintetico(orc);
      if (!lin.length) return '<div class="vazio card">Sem etapas para resumir.</div>';
      var html = '<table class="tbl"><thead><tr><th>Cód</th><th>Etapa</th>' +
        '<th class="num">Itens</th><th class="num">Custo Direto</th><th class="num">Preço Venda</th><th class="num">Peso %</th></tr></thead><tbody>';
      lin.forEach(function (l) {
        html += '<tr><td>' + Util.esc(l.codigo) + '</td><td>' + Util.esc(l.nome) + '</td>' +
          '<td class="num">' + l.qtdItens + '</td>' +
          '<td class="num">' + Util.fmtMoeda(l.custoDireto) + '</td>' +
          '<td class="num">' + Util.fmtMoeda(l.precoVenda) + '</td>' +
          '<td class="num">' + Util.fmtPct(l.peso, 1) + '</td></tr>';
      });
      var t = Orcamento.totais(orc);
      html += '</tbody><tfoot><tr class="etapa-row"><td colspan="3">TOTAL GERAL</td>' +
        '<td class="num">' + Util.fmtMoeda(t.custoDireto) + '</td>' +
        '<td class="num">' + Util.fmtMoeda(t.precoVenda) + '</td><td class="num">100%</td></tr></tfoot></table>';
      return html;
    },

    /* Selo dos feriados: quantos dias de obra eles custaram e quais foram.
       ⚠ O NÚMERO PRECISA SER CONFERÍVEL. Uma entrega que muda de data sem nada
       na tela explicando faz a pessoa achar que o sistema errou — e ela
       desliga o recurso certo. Aqui o title lista data por data, e quem
       trabalha em feriado desmarca o interruptor ao lado. */
    _pillFeriados: function (r) {
      var f = r.feriados || {};
      var html = "";
      if (f.ajusteInicio) {
        html += '<span class="pill" style="background:#f59e0b22;color:#b45309;font-weight:600" title="A obra não começa em dia parado: o início foi empurrado para o primeiro dia útil.">' +
          'início ajustado: ' + Util.esc(f.ajusteInicio.motivo) + '</span>';
      }
      if ((f.invalidos || []).length) {
        html += '<span class="pill" style="background:#dc262622;color:#b91c1c;font-weight:700" title="Data fora do formato AAAA-MM-DD — ignorada no cálculo, para um erro de digitação não deslocar a entrega da obra.">' +
          (f.invalidos.length === 1 ? 'feriado local não entendido' : f.invalidos.length + ' feriados locais não entendidos') + ': ' + Util.esc(f.invalidos.slice(0, 3).join(", ")) + '</span>';
      }
      var n = (f.noPeriodo || []).length;
      if (!n) return html;
      var lista = f.noPeriodo.map(function (x) {
        return x.data.slice(8, 10) + "/" + x.data.slice(5, 7) + " " + x.nome + (x.tipo === "facultativo" ? " (ponto facultativo)" : "");
      }).join(" · ");
      return html + '<span class="pill" style="background:#0d6ebd14;color:var(--aco,#0d6ebd);font-weight:600" title="' + Util.esc(lista) + '">' +
        n + ' feriado' + (n === 1 ? '' : 's') + ' descontado' + (n === 1 ? '' : 's') + ' do prazo</span>';
    },

    // ----- Aba Cronograma (Gantt parametrizado pelo agente) -----
    renderCronograma: function (orc) {
      if (typeof Cronograma === "undefined") return '<div class="vazio card">Módulo de cronograma indisponível.</div>';
      if (!(orc.etapas || []).length) return '<div class="vazio card">Adicione etapas e itens para o agente montar o cronograma.</div>';
      var r = Cronograma.estimar(orc), p = r.params;
      var iaM = (orc.cronograma && orc.cronograma.iaMotivos) || {};
      function ini() { try { return r.dataInicio.toISOString().slice(0, 10); } catch (e) { return ""; } }
      function opt(v, txt, sel) { return '<option value="' + v + '"' + (String(sel) === String(v) ? " selected" : "") + '>' + txt + '</option>'; }
      var html = '<div class="card" style="margin-bottom:12px"><div class="flex" style="flex-wrap:wrap;gap:12px;align-items:flex-end">' +
        '<div class="field" style="margin:0"><label>Início</label><input id="cron-inicio" type="date" value="' + ini() + '"></div>' +
        '<div class="field" style="margin:0"><label>Equipes/frentes</label><input id="cron-equipes" type="number" min="1" value="' + p.equipes + '" style="width:80px"></div>' +
        '<div class="field" style="margin:0"><label>Dias úteis/sem.</label><input id="cron-dias" type="number" min="1" max="7" value="' + p.diasUteisSemana + '" style="width:80px"></div>' +
        '<div class="field" style="margin:0"><label>Paralelismo</label><select id="cron-paral">' + opt(0, "Nenhum", p.paralelismo) + opt(0.15, "Leve 15%", p.paralelismo) + opt(0.3, "Médio 30%", p.paralelismo) + opt(0.5, "Alto 50%", p.paralelismo) + '</select></div>' +
        '<div class="field" style="margin:0"><label>R$/dia-equipe</label><input id="cron-custodia" type="number" value="' + p.custoDiaEquipe + '" style="width:100px"></div>' +
        /* Feriado é prazo: uma obra de um ano atravessa uns 12 e o cronograma
           antigo os contava como dia de trabalho. O campo de locais fica ao
           lado do interruptor porque é a primeira pergunta de quem liga isso
           ("e o feriado da minha cidade?"). */
        '<div class="field" style="margin:0"><label>Feriados</label>' +
          '<label style="display:flex;align-items:center;gap:6px;font-weight:400;cursor:pointer" title="Desconta feriados nacionais do prazo. Inclui Carnaval e Corpus Christi, que são ponto facultativo mas param a obra.">' +
          '<input id="cron-feriados" type="checkbox"' + (p.descontarFeriados !== false ? " checked" : "") + '> descontar</label></div>' +
        '<div class="field" style="margin:0"><label>Feriados locais</label>' +
          '<input id="cron-feriados-extras" type="text" placeholder="2026-06-24; 2026-08-15" value="' +
          Util.esc(((p.feriadosExtras || []).map(function (x) { return (x && x.data) ? x.data : x; })).join("; ")) +
          '" title="Feriados municipais/estaduais e paradas da empresa, em AAAA-MM-DD, separados por ; — o app não adivinha o feriado da sua cidade." style="width:170px"></div>' +
        '<button class="btn sm primary" data-acao="cron-recalc">' + (typeof Icones !== 'undefined' ? Icones.get('ciclo', 15) : '') + ' Recalcular</button>' +
        '<button class="btn sm" data-acao="cron-reset">Limpar edições</button>' +
        '<button class="btn sm" data-acao="cron-ia" title="Refina as durações com a IA do ERP (planejador)">' + (typeof Icones !== 'undefined' ? Icones.get('ia', 15) : '') + ' Refinar com IA</button>' +
        '</div></div>';
      var nCrit = (r.caminhoCritico || []).length;
      html += '<div class="flex" style="gap:18px;margin-bottom:8px;align-items:baseline;flex-wrap:wrap"><b style="font-size:16px">⏱ ' + r.totalDias + ' dias úteis (~' + r.totalSemanas + ' semanas)</b>' +
        '<span class="muted">' + r.dataInicio.toLocaleDateString("pt-BR") + ' → ' + r.dataFim.toLocaleDateString("pt-BR") + '</span>' +
        '<span class="pill" style="background:#b91c1c14;color:var(--graf-alerta,#b91c1c);font-weight:600" title="Etapas sem folga: atrasar qualquer uma delas atrasa a entrega da obra.">caminho crítico: ' + nCrit + ' de ' + r.etapas.length + ' etapa' + (r.etapas.length === 1 ? '' : 's') + '</span>' +
        (r.temCiclo ? '<span class="pill" style="background:#f59e0b22;color:#b45309;font-weight:700" title="Uma etapa depende de outra que, por sua vez, depende dela. O elo que fecha o laço foi ignorado no cálculo.">dependência circular — elo ignorado; revise a coluna “Depende de”</span>' : '') +
        this._pillFeriados(r) +
        '<span class="muted" style="font-size:12px">' + (typeof Icones !== 'undefined' ? Icones.get('ia', 15) : '') + ' estimado pelo agente · edite duração e dependências na tabela</span></div>';
      html += this._gantt(r);
      /* "Depende de" fala em Nº DA LINHA (1, 2, 3…), como o MS Project — o
         código da etapa pode ser "01.02" ou vazio, e ninguém digita id. O
         placeholder mostra o padrão em vigor (a linha anterior). */
      var numPorId = {}; r.etapas.forEach(function (e, i) { numPorId[e.id] = i + 1; });
      html += '<table class="tbl" style="margin-top:12px"><thead><tr><th>Etapa</th><th>Categoria (agente)</th><th class="num">Eq-dias</th><th class="num" title="Dias úteis. 0 = marco (entrega, vistoria, liberação): sem barra, um losango no Gantt.">Duração (d)</th>' +
        '<th class="num" title="Nº das etapas que precisam terminar antes desta (ex.: 1,3). Vazio = a anterior; 0 = começa no início da obra. 1+7 = 7 dias úteis depois da 1ª; 1-3 = começa 3 dias antes de a 1ª acabar.">Depende de</th>' +
        '<th class="num" title="Quanto a etapa pode atrasar sem mudar a entrega. Folga zero = caminho crítico.">Folga</th><th>Início</th><th>Fim</th></tr></thead><tbody>';
      r.etapas.forEach(function (e, i) {
        var c = Cronograma.cat(e.categoria);
        /* O CAMPO mostra só o que foi DIGITADO; a rede efetiva vai no tooltip
           da barra e nos documentos. Preenchê-lo com a cascata padrão ("1", "2",
           "3"…) apaga a distinção entre o que a pessoa escolheu e o que o
           sistema assumiu — some o placeholder que ensina o padrão, e a tabela
           inteira passa a parecer customizada. Elo para etapa apagada já caiu
           no motor, então o texto vem do resultado, não do que está gravado. */
        var valPred = e.predsExplicito ? Cronograma.predsTexto(e, numPorId) : "";
        html += '<tr><td>' + Util.esc(e.codigo) + ' ' + Util.esc(e.nome) + (e.marco ? ' <span class="pill" style="background:#0f172a14;color:#0f172a;font-weight:700;font-size:11px" title="Marco: evento sem duração (entrega, vistoria, liberação).">◆ marco</span>' : '') + '</td>' +
          '<td><span class="pill" style="background:' + c.cor + '22;color:' + c.cor + '">' + Util.esc(c.nome) + '</span></td>' +
          '<td class="num">' + e.equipeDias + '</td>' +
          '<td class="num"><input class="cell" type="number" min="0" data-cron-dur="' + e.id + '" value="' + e.duracao + '" title="Dias úteis · 0 = marco" style="width:60px;text-align:right' + (e.editado || e.marco ? ';border-color:var(--azul,#2563eb)' : '') + '">' + (iaM[e.id] ? ' <span title="🤖 IA: ' + Util.esc(iaM[e.id]) + '" style="cursor:help">' + (typeof Icones !== 'undefined' ? Icones.get('ia', 15) : '') + '</span>' : '') + '</td>' +
          '<td class="num"><input class="cell" type="text" data-cron-pred="' + e.id + '" value="' + valPred + '" placeholder="' + (i > 0 ? i : '—') + '" title="Nº das etapas que precisam terminar antes (ex.: 1,3). Vazio = a anterior; 0 = começa no início da obra. 1+7 = espera 7 dias úteis; 1-3 = começa 3 dias antes." style="width:72px;text-align:right' + (e.predsExplicito ? ';border-color:var(--aco,#0d6ebd)' : '') + '"></td>' +
          '<td class="num">' + (e.critico ? '<span class="pill" style="background:#b91c1c14;color:var(--graf-alerta,#b91c1c);font-weight:700" title="Sem folga: atrasar esta etapa atrasa a obra inteira.">crítica</span>' : '+' + e.folga + ' d') + '</td>' +
          '<td>' + e.dataInicio.toLocaleDateString("pt-BR") + '</td><td>' + e.dataFim.toLocaleDateString("pt-BR") + '</td></tr>';
      });
      html += '</tbody></table>';
      html += '<div class="muted" style="font-size:11px;margin-top:6px"><b>Depende de:</b> nº das etapas que precisam terminar antes (ex.: <code>1,3</code>). Vazio = a etapa anterior · <code>0</code> = começa no início da obra · <code>1+7</code> = espera 7 dias úteis depois da 1ª (cura, secagem) · <code>1-3</code> = começa 3 dias antes de a 1ª acabar · sem lag, vale a sobreposição do paralelismo. <b>Duração 0</b> = marco (◆). <b>Folga:</b> quanto a etapa pode atrasar sem mudar a entrega — folga zero é o caminho crítico.</div>';
      html += '<div class="flex" style="gap:8px;margin-top:10px;flex-wrap:wrap">' +
        '<button class="btn sm" data-acao="cron-pdf" title="Abre o cronograma pronto para imprimir ou salvar em PDF (A4 paisagem)">' + (typeof Icones !== 'undefined' ? Icones.get('imprimir', 15) : '') + ' Imprimir / PDF</button>' +
        '<button class="btn sm" data-acao="cron-msproject" title="Exporta as etapas, durações e dependências para o MS Project (XML). Abre também no Project Libre e no GanttProject.">' + (typeof Icones !== 'undefined' ? Icones.get('exportar', 15) : '') + ' MS Project (XML)</button>' +
        '<span class="muted" style="font-size:11.5px;align-self:center">A planilha Excel do orçamento leva este cronograma com fórmulas vivas (aba Gantt).</span></div>';
      return html;
    },

    // ----- Aba Execução (agente de canteiro: equipe/prazo/custo × orçamento) -----
    renderExecucao: function (orc) {
      if (typeof Execucao === "undefined") return '<div class="vazio card">Agente de execução indisponível.</div>';
      if (!(orc.etapas || []).length) return '<div class="vazio card">Adicione etapas e itens para o agente dimensionar equipe, prazo e custo.</div>';
      // RBAC: só usa as diárias REAIS do RH se o usuário tem o módulo 'colaboradores'
      // (senão vazaria salário via a aba de orçamento). Sem acesso -> cai no fallback SINAPI.
      var podeRH = (typeof Auth === "undefined" || !Auth.podeModulo) ? true : Auth.podeModulo("colaboradores");
      var colab = [];
      if (podeRH) { try { colab = Store.listar(Auth.empresaId(), "colaboradores") || []; } catch (e) {} }
      var sim = Execucao.simular(orc, { colaboradores: colab });
      var p = sim.params;
      function d10(v) { try { var x = new Date(v); return x.getFullYear() + "-" + ("0" + (x.getMonth() + 1)).slice(-2) + "-" + ("0" + x.getDate()).slice(-2); } catch (e) { return ""; } }
      function moeda(v) { return Util.fmtMoeda(Math.round(v || 0)); }
      function curto(prof) { var w = String(prof).split(" ")[0].toLowerCase(); return w.charAt(0).toUpperCase() + w.slice(1); }
      var COR = { dentro: "#16a34a", acima: "#dc2626", abaixo: "#2563eb", "sem-base": "#64748b" };
      var ROT = { dentro: "DENTRO DO ORÇADO", acima: "ACIMA DO ORÇADO", abaixo: "ABAIXO DO ORÇADO", "sem-base": "SEM BASE P/ RECONCILIAR" };
      var cor = COR[sim.status] || "#64748b";

      // form de parâmetros
      var html = '<div class="card" style="margin-bottom:12px"><div class="flex" style="flex-wrap:wrap;gap:12px;align-items:flex-end">' +
        '<div class="field" style="margin:0"><label>Início da obra</label><input id="exec-inicio" type="date" value="' + d10(sim.dataInicio) + '"></div>' +
        '<div class="field" style="margin:0"><label>Entrega desejada</label><input id="exec-entrega" type="date" value="' + (p.dataEntrega || "") + '"></div>' +
        '<div class="field" style="margin:0"><label>Jornada (h/dia)</label><input id="exec-jornada" type="number" min="1" max="12" value="' + p.jornadaH + '" style="width:80px"></div>' +
        '<div class="field" style="margin:0"><label>Dias úteis/sem.</label><input id="exec-dias" type="number" min="1" max="7" value="' + p.diasUteisSemana + '" style="width:80px"></div>' +
        '<div class="field" style="margin:0"><label title="Onera a diária de colaboradores CLT p/ comparar com o SINAPI (que já vem onerado). Diarista/autônomo/PJ entram cheios.">Encargos CLT (%)</label><input id="exec-encargos" type="number" min="0" max="150" value="' + (p.encargosPct || 0) + '" style="width:90px"></div>' +
        '<button class="btn sm primary" data-acao="exec-recalc">' + (typeof Icones !== 'undefined' ? Icones.get('ciclo', 15) : '') + ' Recalcular</button>' +
        '<button class="btn sm" data-acao="exec-cronograma" title="Usar estas durações no Cronograma">' + Icones.get("cronograma") + 'Enviar ao cronograma</button>' +
        '</div>' +
        '<div class="muted" style="font-size:11px;margin-top:8px">Produtividade = coeficientes de mão-de-obra do SINAPI (horas-homem). Custo/dia = diária dos seus colaboradores (RH); onde não há colaborador da profissão, usa a <b>referência SINAPI</b>.' +
        (colab.length ? '' : ' <b>Cadastre colaboradores em RH</b> para usar suas diárias reais — por ora tudo está na referência SINAPI.') + '</div></div>';

      var semBase = sim.semBaseMO;

      // headline + semáforo (sem prazo/equipe FANTASMA quando a base não tem MO)
      html += '<div class="flex" style="gap:14px;align-items:center;flex-wrap:wrap;margin-bottom:10px">';
      if (semBase) {
        html += '<b style="font-size:16px;color:#b45309">⏱ prazo/equipe não estimáveis</b>';
      } else {
        var parcial = sim.nEtapasSemBase > 0; // prazo cobre só as etapas estimáveis; as estaduais ficam de fora
        html += '<b style="font-size:16px">⏱ ' + sim.prazoDias + ' dias úteis (~' + sim.prazoSemanas + ' semanas)' + (parcial ? ' <span style="color:#b45309">*parcial</span>' : '') + '</b>' +
          (sim.dataFim ? '<span class="muted">' + sim.dataInicio.toLocaleDateString("pt-BR") + ' → ' + sim.dataFim.toLocaleDateString("pt-BR") + (parcial ? ' (só etapas estimáveis)' : '') + '</span>' : '') +
          (sim.metaAtingida === false ? '<span class="pill" style="background:#dc262622;color:#dc2626;font-weight:700">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' não bate a entrega pedida</span>' : '') +
          (parcial ? '<span class="pill" style="background:#f59e0b22;color:#b45309;font-weight:700">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' prazo parcial — ' + sim.nEtapasSemBase + ' etapa(s) sem base de MO fora da conta</span>' : '');
      }
      html += '<span class="pill" style="background:' + cor + '22;color:' + cor + ';font-weight:700">' + (ROT[sim.status] || sim.status) + (sim.reconConfiavel ? ' · ' + (sim.desvioPct >= 0 ? "+" : "") + sim.desvioPct.toFixed(1) + '%' : '') + '</span>';
      if (!semBase) html += '<span class="muted" style="font-size:12px' + (sim.coberturaBaixa ? ';color:#b45309;font-weight:600' : '') + '">🧠 ' + sim.cobertura.pct + '% dos itens (com qtd) têm produtividade SINAPI' + (sim.coberturaBaixa ? ' — reconciliação parcial' : '') + '</span>';
      html += '</div>';

      // aviso forte quando é 100% base estadual/própria sem custo de MO
      if (semBase) {
        html += '<div class="card" style="margin-bottom:12px;border-left:4px solid #b45309;background:#f59e0b0d"><b style="color:#b45309">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Orçamento de base estadual/própria sem custo de mão-de-obra.</b><div class="muted" style="font-size:12px;margin-top:4px">O agente precisa de composições SINAPI (horas-homem) — ou da produtividade informada — para dimensionar equipe, prazo e custo. Os números abaixo NÃO são uma estimativa de obra.</div></div>';
      } else {
        // reconciliação — SÓ sobre a porção com DIÁRIA REAL (real × orçado-SINAPI da mesma profissão)
        html += '<div class="card" style="margin-bottom:12px;border-left:4px solid ' + cor + '">';
        if (sim.reconConfiavel) {
          html += '<div class="flex" style="gap:24px;flex-wrap:wrap;align-items:baseline">' +
            '<div><div class="muted" style="font-size:12px" title="MO orçada (SINAPI) das profissões que têm diária cadastrada no RH">MO orçada (porção reconciliável)</div><b style="font-size:18px">' + moeda(sim.orcadoMOReal) + '</b></div>' +
            '<div style="font-size:20px;color:var(--aco,#64748b)">→</div>' +
            '<div><div class="muted" style="font-size:12px">MO simulada (diárias reais do RH)</div><b style="font-size:18px;color:' + cor + '">' + moeda(sim.custoMOReal) + '</b></div>' +
            '<div><div class="muted" style="font-size:12px">Diferença</div><b style="font-size:16px;color:' + cor + '">' + (sim.desvio >= 0 ? "+" : "") + moeda(sim.desvio) + ' (' + (sim.desvioPct >= 0 ? "+" : "") + sim.desvioPct.toFixed(1) + '%)</b></div>' +
            '</div>' +
            (sim.coberturaBaixa ? '<div class="pill" style="display:inline-block;margin-top:8px;background:#f59e0b22;color:#b45309;font-weight:600;font-size:11px">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' Cobre só ' + Math.round(sim.reconCobPct) + '% do custo de MO-SINAPI — só as profissões com diária real cadastrada</div>' : '');
        } else {
          html += '<div style="font-size:13px">' + (sim.orcadoMOExato > 0 ? 'Há itens SINAPI, mas nenhuma <b>diária real</b> no RH que case as profissões — comparar SINAPI × SINAPI daria sempre 0%. Cadastre sua equipe em RH para reconciliar custo real × orçado.' : 'Nenhum item com composição SINAPI para reconciliar o custo de MO — a base é própria/estadual.') + '</div>';
        }
        html += '<div class="muted" style="font-size:11px;margin-top:8px">Custo total de MO simulado (obra inteira): <b>' + moeda(sim.custoMOSimulado) + '</b> · MO total orçada: ' + moeda(sim.orcadoMO) + (sim.orcadoMOExato ? ' · com produtividade SINAPI: ' + moeda(sim.orcadoMOExato) : '') + '.</div>';
        html += '</div>';
      }

      // observações do agente (sempre)
      html += '<div class="card" style="margin-bottom:12px"><ul style="margin:0;padding-left:18px;font-size:13px;line-height:1.6">';
      sim.sugestoes.forEach(function (s) { html += '<li>' + Util.esc(s) + '</li>'; });
      html += '</ul></div>';

      // equipe de pico
      var picoKeys = Object.keys(sim.equipePico);
      if (picoKeys.length) {
        html += '<div class="card" style="margin-bottom:12px"><h3 style="margin:0 0 8px;font-size:14px">' + (typeof Icones !== 'undefined' ? Icones.get('capacete', 15) : '') + ' Equipe de pico (máximo simultâneo no canteiro)</h3><div class="flex" style="gap:8px;flex-wrap:wrap">';
        picoKeys.sort(function (a, b) { return sim.equipePico[b] - sim.equipePico[a]; }).forEach(function (pf) {
          var estim = pf.indexOf("estimada") >= 0;
          var lbl = estim ? (sim.equipePico[pf] + '× equipe geral (est.)') : (sim.equipePico[pf] + '× ' + curto(pf));
          var bg = estim ? '#f59e0b18' : '#0f274012', bd = estim ? '#f59e0b55' : 'var(--linha,#e2e8f0)';
          html += '<span class="pill" title="' + (estim ? 'itens sem código SINAPI — equipe geral estimada pela MO do orçamento' : Util.esc(pf)) + '" style="background:' + bg + ';border:1px solid ' + bd + ';font-weight:600">' + Util.esc(lbl) + '</span>';
        });
        html += '</div></div>';
      }

      // tabela por etapa
      html += '<table class="tbl"><thead><tr><th>Etapa</th><th class="num">Duração</th><th>Equipe por profissão</th><th class="num">Custo MO</th></tr></thead><tbody>';
      sim.etapas.forEach(function (et) {
        if (!et.temBaseMO) {
          html += '<tr><td><b>' + Util.esc(et.nome) + '</b></td><td class="num muted">—</td>' +
            '<td><span class="pill" style="background:#f59e0b22;color:#b45309;font-size:11px" title="base estadual/própria sem custo de MO — sem coeficiente p/ dimensionar equipe/prazo">não estimável (base sem MO)</span></td>' +
            '<td class="num muted">—</td></tr>';
          return;
        }
        var chips = Object.keys(et.prof).map(function (pf) {
          var s = et.prof[pf], ref = s.fonteCusto !== "real";
          return '<span class="pill" title="' + Util.esc(pf) + ' · R$' + Math.round(s.custoDia) + '/dia ' + (ref ? '(ref. SINAPI)' : '(diária real)') + '" style="background:' + (ref ? '#94a3b822' : '#16a34a1a') + ';color:' + (ref ? '#64748b' : '#16a34a') + ';font-size:11px">' + s.equipe + '× ' + Util.esc(curto(pf)) + '</span>';
        }).join(" ");
        if (et.homensDiaEstim > 0) chips += ' <span class="pill" style="background:#f59e0b22;color:#b45309;font-size:11px" title="itens sem código SINAPI mas com custoMO — equipe/produtividade estimada pela MO do orçamento">~' + (et.equipeEstim || 1) + '× equipe geral (est.)</span>';
        html += '<tr><td><b>' + Util.esc(et.nome) + '</b>' + (et.dataInicio ? '<br><span class="muted" style="font-size:11px">' + et.dataInicio.toLocaleDateString("pt-BR") + ' → ' + et.dataFim.toLocaleDateString("pt-BR") + '</span>' : '') + '</td>' +
          '<td class="num">' + et.duracao + ' d</td>' +
          '<td>' + (chips || '<span class="muted">—</span>') + '</td>' +
          '<td class="num">' + moeda(et.custoMO) + '</td></tr>';
      });
      html += '<tr style="font-weight:700;border-top:2px solid var(--linha,#e2e8f0)"><td>Total</td><td class="num">' + (semBase ? '—' : sim.prazoDias + ' d') + '</td><td></td><td class="num">' + moeda(sim.custoMOSimulado) + '</td></tr>';
      html += '</tbody></table>';
      html += '<div class="muted" style="font-size:11px;margin-top:8px">O custo de MO é pelo conteúdo de trabalho (equipe eficientemente dimensionada). A hora do SINAPI já vem <b>com encargos sociais/complementares</b>; por isso, ao comparar, as diárias de CLT são oneradas em ' + (p.encargosPct || 0) + '% (campo acima — mesmo % da Folha de pagamento) e as de diarista/autônomo/PJ entram cheias. A reconciliação vale <b>só sobre as profissões com diária real cadastrada no RH</b> — se a cobertura for baixa, o veredito é parcial. Itens de base estadual sem custo de MO aparecem como “não estimável”.</div>';
      return html;
    },

    renderParedeCebola: function (orc) {
      if (typeof ParedeCebola === "undefined") return '<div class="vazio card">Parede-Cebola indisponível.</div>';
      // preview TRANSIENTE (não polui o orçamento salvo/sincronizado): vive em App._pcPreview
      var pc = (typeof App !== "undefined" && App._pcPreview && App._pcPreview.orcId === orc.id) ? App._pcPreview : {};
      var esc = Util.esc, inp = pc.inputs || {};
      var receitas = ParedeCebola.receitas();
      function selReceita() {
        return receitas.map(function (r) { return '<option value="' + r.id + '"' + (inp.receita === r.id ? " selected" : "") + '>' + esc(r.rotulo) + '</option>'; }).join("");
      }
      var html = '<div class="card" style="margin-bottom:12px">' +
        '<h3 style="margin:0 0 4px;font-size:15px;display:flex;align-items:center">' + Icones.get("paredecebola", 16) + 'Parede-Cebola — do 2D à obra real</h3>' +
        '<p class="muted" style="font-size:12px;margin:0 0 10px">Uma parede é UMA linha, mas na obra ela é um empilhamento: bloco → chapisco → reboco → massa → pintura. Informe a parede e o sistema explode nas camadas de serviço, casando cada uma num <b>código SINAPI real</b> (nunca inventa — sem match vira “pendente”). Você revisa e joga no orçamento.</p>' +
        '<div class="flex" style="flex-wrap:wrap;gap:10px;align-items:flex-end">' +
        '<div class="field" style="margin:0"><label>Nome</label><input id="pc-nome" value="' + esc(inp.nome || "") + '" placeholder="Parede sala" style="width:150px"></div>' +
        '<div class="field" style="margin:0"><label>Área (m²)</label><input id="pc-area" type="number" min="0" step="0.01" value="' + (inp.area != null ? inp.area : "") + '" placeholder="ou C×A →" style="width:100px"></div>' +
        '<div class="field" style="margin:0"><label>Comprim. (m)</label><input id="pc-comp" type="number" min="0" step="0.01" value="' + (inp.comprimento != null ? inp.comprimento : "") + '" style="width:90px"></div>' +
        '<div class="field" style="margin:0"><label>Altura (m)</label><input id="pc-alt" type="number" min="0" step="0.01" value="' + (inp.altura != null ? inp.altura : "") + '" style="width:80px"></div>' +
        '<div class="field" style="margin:0"><label title="Portas/janelas em m² a abater">Vãos (m²)</label><input id="pc-vaos" type="number" min="0" step="0.01" value="' + (inp.descontos != null ? inp.descontos : "") + '" style="width:80px"></div>' +
        '<div class="field" style="margin:0"><label>Faces</label><select id="pc-faces"><option value="2"' + (inp.faces == 1 ? "" : " selected") + '>2 faces</option><option value="1"' + (inp.faces == 1 ? " selected" : "") + '>1 face</option></select></div>' +
        '<div class="field" style="margin:0"><label>Receita (tipo de parede)</label><select id="pc-receita">' + selReceita() + '</select></div>' +
        '<div class="field" style="margin:0"><label style="white-space:nowrap"><input id="pc-alv" type="checkbox"' + (inp.incluiAlvenaria === false ? "" : " checked") + '> incluir alvenaria</label></div>' +
        '<button class="btn sm primary" data-acao="parede-explodir">🧅 Explodir em camadas</button>' +
        '</div></div>';

      if (pc.resultado) {
        var r = pc.resultado, badge = { ok: ["#16a34a", "casou"], revisar: ["#b45309", "revisar unidade"], pendente: ["#dc2626", "sem código"] };
        html += '<div class="card" style="margin-bottom:12px"><div class="flex" style="gap:18px;flex-wrap:wrap;align-items:baseline">' +
          '<b style="font-size:15px">🧅 ' + esc(r.parede.nome) + '</b>' +
          '<span class="muted" style="font-size:12px">' + r.parede.areaLiquida + ' m² líquidos' + (r.parede.descontos ? ' (' + r.parede.areaBruta + ' − ' + r.parede.descontos + ' de vãos)' : '') + ' · ' + r.parede.faces + ' face(s) · ' + esc(r.receita.rotulo) + '</span>' +
          '<span class="pill" style="background:#16a34a22;color:#16a34a;font-weight:700">' + r.nOk + ' casaram</span>' +
          (r.nRevisar ? '<span class="pill" style="background:#f59e0b22;color:#b45309;font-weight:700">' + r.nRevisar + ' p/ revisar</span>' : '') +
          (r.nPendentes ? '<span class="pill" style="background:#dc262622;color:#dc2626;font-weight:700">' + r.nPendentes + ' sem código</span>' : '') +
          '</div>';
        html += '<table class="tbl" style="margin-top:10px;font-size:13px"><thead><tr><th>#</th><th>Camada</th><th style="text-align:right">Qtd</th><th>Un</th><th>Código casado (base)</th><th>Confiança</th><th></th></tr></thead><tbody>';
        r.camadas.forEach(function (c) {
          var cand = (c.escolhido >= 0 && c.candidatos[c.escolhido]) ? c.candidatos[c.escolhido] : null;
          var b = badge[c.status] || badge.pendente;
          var codCel;
          if (c.candidatos && c.candidatos.length) {
            codCel = '<select data-pc-cand="' + c.seq + '" style="max-width:340px">' + c.candidatos.map(function (k, i) {
              /* ⚠ a FONTE na cara. A coluna dizia "Código SINAPI casado" e a
                 opção não mostrava banco nenhum — item de SICRO ou SETOP era
                 lançado com o usuário lendo "SINAPI". k.fonte já existe desde
                 sempre (paredecebola.js) e era jogado fora. Agora que a
                 denylist age aqui, ver a origem deixou de ser cosmético: é
                 como o usuário percebe que o filtro agiu (ou não). */
              return '<option value="' + i + '"' + (i === c.escolhido ? " selected" : "") + '>' + esc("[" + (k.fonte || "SINAPI") + "] " + (k.item.codigo || "—") + " · " + (k.item.descricao || "").slice(0, 60)) + " [" + (k.item.unidade || "?") + "]</option>";
            }).join("") + '</select>' + (c.unidadeDivergente ? ' <span class="muted" style="color:#b45309;font-size:11px">' + (typeof Icones !== 'undefined' ? Icones.get('alerta', 15) : '') + ' unidade ' + esc(cand ? cand.item.unidade : "") + ' ≠ ' + c.unidade + '</span>' : "");
          } else {
            codCel = '<span class="muted" style="color:#dc2626">nenhum código casou — ajuste o termo ou lance manualmente</span>';
          }
          html += '<tr><td>' + c.seq + '</td><td>' + esc(c.camada) + (c.base ? ' <span class="muted" style="font-size:10px">(núcleo)</span>' : '') + '</td>' +
            '<td style="text-align:right">' + c.quantidade + '</td><td>' + c.unidade + '</td>' +
            '<td>' + codCel + '</td>' +
            '<td>' + (cand ? Math.round(c.confianca) + '%' : '—') + '</td>' +
            '<td><span class="pill" style="background:' + b[0] + '22;color:' + b[0] + ';font-size:11px;font-weight:700">' + b[1] + '</span></td></tr>';
        });
        html += '</tbody></table>';
        var etapas = (orc.etapas || []);
        var selEt = '<select id="pc-etapa"><option value="__nova__">' + (typeof Icones !== 'undefined' ? Icones.get('mais', 15) : '') + ' Nova etapa: Parede — ' + esc(r.parede.nome) + '</option>' +
          etapas.map(function (e) { return '<option value="' + e.id + '">' + esc((e.codigo ? e.codigo + " " : "") + e.nome) + '</option>'; }).join("") + '</select>';
        var aplicaveis = r.nOk + (r.nRevisar ? 0 : 0);
        html += '<div class="flex" style="gap:10px;align-items:flex-end;margin-top:12px;flex-wrap:wrap">' +
          '<div class="field" style="margin:0"><label>Adicionar em</label>' + selEt + '</div>' +
          '<button class="btn sm primary" data-acao="parede-aplicar" title="Só as camadas com código casado (OK) entram. Pendentes e as de unidade divergente ficam de fora.">' + (typeof Icones !== 'undefined' ? Icones.get('mais', 15) : '') + ' Adicionar ' + r.nOk + ' camada(s) ao orçamento</button>' +
          (r.nRevisar || r.nPendentes ? '<span class="muted" style="font-size:11px">' + (r.nRevisar ? r.nRevisar + ' de unidade divergente' : "") + (r.nRevisar && r.nPendentes ? " e " : "") + (r.nPendentes ? r.nPendentes + ' sem código' : "") + ' NÃO entram — resolva antes.</span>' : "") +
          '</div>';
        html += '<div class="muted" style="font-size:11px;margin-top:8px">Cada camada vira um <b>item normal do orçamento</b> (código SINAPI + qtd) — então o Agente de Execução (aba Execução) dimensiona equipe, prazo e custo dessas camadas automaticamente.</div>';
        html += '</div>';
      }
      return html;
    },

    /* Gantt em SVG: barras por etapa, folga tracejada, setas de dependência,
       caminho crítico em vermelho e a linha de hoje.
       ⚠ É PAPEL BRANCO de propósito (fundo #fff cravado, como os outros
       gráficos deste arquivo): as cores das categorias (Cronograma.CATS) foram
       calibradas para fundo claro, e token de tema aqui trocaria a tinta do
       texto para a do tema escuro SOBRE o papel branco — ilegível. O antigo
       `var(--card,#fff)` já caía sempre no #fff, porque --card não existe. */
    /* opts.limpo = versão para o CLIENTE (proposta comercial): só as barras, a
       grade de semanas e os marcos. Some o que é linguagem de planejamento —
       folga, setas de precedência, contorno do caminho crítico e a linha de
       hoje. Não é enfeite: "folga de 3 dias" impressa na proposta é um convite
       a negociar prazo em cima de uma reserva que existe para absorver chuva,
       e a legenda de caminho crítico só faz sentido para quem gerencia a obra.
       O engenheiro continua vendo tudo na aba e no PDF do cronograma. */
    _gantt: function (r, opts) {
      var limpo = !!(opts && opts.limpo);
      var dias = r.totalDias || 1, W = 880, labelW = 184, rowH = 30, top = 22;
      var plotW = W - labelW - 14, h = top + r.etapas.length * rowH + 12, dpw = r.params.diasUteisSemana || 5;
      var CRIT = "#b91c1c", CINZA = "#94a3b8", HOJE = "#b45309";
      var X = function (d) { return labelW + Math.min(1, d / dias) * plotW; };
      var yBar = function (i) { return top + i * rowH + 5; };
      var yc = function (i) { return yBar(i) + 9; };
      var idx = {}, numPorId = {}; r.etapas.forEach(function (e, i) { idx[e.id] = i; numPorId[e.id] = i + 1; });
      var svg = '<svg class="gantt" viewBox="0 0 ' + W + ' ' + h + '" style="width:100%;max-width:100%;background:#fff;border:1px solid var(--linha,#e2e8f0);border-radius:8px;font-family:inherit">';
      /* grade semanal com PASSO. Obra de 94 semanas desenhava 94 linhas e 94
         rótulos em 700 px: o topo virava um borrão de "S1S2S3…" ilegível e a
         grade escondia as barras (visto na foto da proposta). O passo mantém no
         máximo ~26 marcas, que é o que cabe com folga. */
      var passoS = Math.max(1, Math.ceil((r.totalSemanas || 1) / 26));
      for (var s = 0; s <= r.totalSemanas; s += passoS) {
        var gx = X(s * dpw);
        svg += '<line x1="' + gx.toFixed(1) + '" y1="' + top + '" x2="' + gx.toFixed(1) + '" y2="' + (h - 8) + '" stroke="#e2e8f0" stroke-width="1"/>';
        if (s < r.totalSemanas) svg += '<text x="' + (gx + 3).toFixed(1) + '" y="' + (top - 7) + '" font-size="9" fill="#94a3b8">S' + (s + 1) + '</text>';
      }
      // linha de HOJE — conta dias úteis com a MESMA régua do addDiasUteis
      // (avança o calendário e só conta o dia que a semana de trabalho tem)
      var hojeX = null;
      (function () {
        if (limpo) return;
        if (!r.dataInicio || typeof r.dataInicio.getFullYear !== "function") return;
        var d0 = new Date(r.dataInicio.getFullYear(), r.dataInicio.getMonth(), r.dataInicio.getDate());
        var hj = new Date(); hj = new Date(hj.getFullYear(), hj.getMonth(), hj.getDate());
        if (hj < d0) return;
        var cur = new Date(d0.getTime()), wd = 0;
        while (cur < hj && wd <= dias) {
          cur.setDate(cur.getDate() + 1);
          var dw = cur.getDay();
          if (dpw >= 7 || (dpw === 6 ? dw !== 0 : (dw !== 0 && dw !== 6))) wd++;
        }
        if (wd > dias) return; // obra já passou do fim previsto: sem marcador
        hojeX = X(wd);
      })();
      if (hojeX != null) svg += '<line x1="' + hojeX.toFixed(1) + '" y1="' + (top - 2) + '" x2="' + hojeX.toFixed(1) + '" y2="' + (h - 8) + '" stroke="' + HOJE + '" stroke-width="1.2" stroke-dasharray="4,3"><title>hoje</title></line>';
      // barras (+ folga tracejada depois da barra)
      r.etapas.forEach(function (e, i) {
        var y = yBar(i), x = X(e.inicio), w = Math.max(4, ((e.fim - e.inicio) / dias) * plotW);
        var cor = Cronograma.cat(e.categoria).cor, folga = e.folga || 0;
        var depTxt = (e.preds && e.preds.length) ? Cronograma.predsTexto(e, numPorId) : "início da obra";
        var tip = Util.esc(e.nome) + (e.marco ? ' — MARCO (sem duração) · ' + e.dataInicio.toLocaleDateString("pt-BR") : ' — ' + e.duracao + ' dia(s) · ' + e.dataInicio.toLocaleDateString("pt-BR") + ' → ' + e.dataFim.toLocaleDateString("pt-BR")) +
          (e.critico ? ' · CRÍTICA (sem folga)' : ' · folga de ' + folga + ' dia(s), até ' + e.dataLimite.toLocaleDateString("pt-BR")) +
          ' · depende de: ' + depTxt;
        // etapa sem `codigo` (importada, BIM) saía "undefined 1 FUNDACAO" no rótulo — a tabela protege, o SVG não protegia
        svg += '<text x="6" y="' + (y + 13) + '" font-size="10" fill="#475569"' + (e.critico ? ' font-weight="600"' : '') + '>' + Util.esc(((e.codigo ? e.codigo + " " : "") + (e.nome || "")).slice(0, 30)) + '</text>';
        if (e.marco) {
          // marco: losango no dia, sem barra (como no MS Project). A folga do marco continua valendo.
          var cx = x, cy = y + 9;
          svg += '<polygon class="gantt-marco' + (e.critico && !limpo ? ' gantt-critica' : '') + '" points="' + cx.toFixed(1) + ',' + (cy - 9) + ' ' + (cx + 9).toFixed(1) + ',' + cy + ' ' + cx.toFixed(1) + ',' + (cy + 9) + ' ' + (cx - 9).toFixed(1) + ',' + cy + '" fill="' + (e.critico && !limpo ? CRIT : '#0f172a') + '"><title>' + tip + '</title></polygon>';
          svg += '<text x="' + Math.min(W - 24, cx + 12).toFixed(1) + '" y="' + (y + 13) + '" font-size="9" fill="#64748b" pointer-events="none">' + e.dataInicio.toLocaleDateString("pt-BR").slice(0, 5) + '</text>';
          return;
        }
        if (folga > 0 && !limpo) {
          var wF = Math.max(2, (folga / dias) * plotW);
          svg += '<rect class="gantt-folga" x="' + (x + w).toFixed(1) + '" y="' + y + '" width="' + wF.toFixed(1) + '" height="18" rx="3" fill="' + cor + '" fill-opacity="0.13" stroke="' + cor + '" stroke-opacity="0.55" stroke-dasharray="3,3"><title>folga: pode ir até ' + e.dataLimite.toLocaleDateString("pt-BR") + ' sem atrasar a obra</title></rect>';
        }
        svg += '<rect class="gantt-barra' + (e.critico && !limpo ? ' gantt-critica' : '') + '" x="' + x.toFixed(1) + '" y="' + y + '" width="' + w.toFixed(1) + '" height="18" rx="3" fill="' + cor + '" opacity="0.92"' + (e.critico && !limpo ? ' stroke="' + CRIT + '" stroke-width="1.6"' : '') + '><title>' + tip + '</title></rect>';
        // duração DENTRO da barra: do lado de fora ela caía em cima da seta que sai do fim da barra
        // (visto na foto do e2e). pointer-events none para o <title> da barra continuar respondendo.
        if (w >= 30) svg += '<text x="' + (x + w - 4).toFixed(1) + '" y="' + (y + 13) + '" font-size="9" font-weight="600" fill="#fff" text-anchor="end" pointer-events="none">' + e.duracao + 'd</text>';
        else svg += '<text x="' + Math.min(W - 24, x + w + 3).toFixed(1) + '" y="' + (y + 13) + '" font-size="9" fill="#64748b" pointer-events="none">' + e.duracao + 'd</text>';
        if (folga > 0 && !limpo) svg += '<text x="' + Math.min(W - 24, X(e.fim + folga) + 3).toFixed(1) + '" y="' + (y + 13) + '" font-size="9" fill="#64748b" pointer-events="none">+' + folga + '</text>';
      });
      // setas de dependência, por cima das barras (como no MS Project). Fica
      // vermelho só o elo que APERTA duas etapas críticas — entre duas críticas
      // pode haver elo com sobra, e pintá-lo de vermelho mentiria o caminho.
      if (!limpo) r.etapas.forEach(function (e, si) {
        (e.preds || []).forEach(function (pid) {
          var pi = idx[pid]; if (pi == null) return;
          var p = r.etapas[pi];
          // o deslocamento do elo vem do MOTOR (lag explícito ou sobreposição do paralelismo)
          var off = (e.predDesloc && e.predDesloc[pid] != null) ? e.predDesloc[pid] : -Math.floor((r.params.paralelismo || 0) * p.duracao);
          var aperta = e.inicio === Math.max(0, p.fim + off);
          var verm = aperta && e.critico && p.critico;
          var px = X(p.fim), py = yc(pi), sx = X(e.inicio), sy = yc(si);
          var corD = verm ? CRIT : CINZA, d;
          if (sx >= px + 12) {
            d = "M" + px.toFixed(1) + "," + py + " H" + (sx - 5).toFixed(1) + " V" + sy + " H" + (sx - 1).toFixed(1);
          } else {
            // sucessora começa antes do fim da predecessora (sobreposição):
            // sai pela direita, corre pelo corredor entre as linhas e entra pela esquerda
            var faixa = py + (sy > py ? 15 : -15), volta = Math.max(labelW + 2, sx - 6);
            d = "M" + px.toFixed(1) + "," + py + " H" + (px + 5).toFixed(1) + " V" + faixa + " H" + volta.toFixed(1) + " V" + sy + " H" + (sx - 1).toFixed(1);
          }
          svg += '<path class="gantt-dep' + (verm ? ' gantt-dep-critica' : '') + '" d="' + d + '" fill="none" stroke="' + corD + '" stroke-width="' + (verm ? 1.8 : 1.1) + '" opacity="0.9"/>';
          svg += '<polygon points="' + sx.toFixed(1) + ',' + sy + ' ' + (sx - 5).toFixed(1) + ',' + (sy - 3) + ' ' + (sx - 5).toFixed(1) + ',' + (sy + 3) + '" fill="' + corD + '"/>';
          // lag explícito ("1+7") vira rótulo no elo — a espera pedida tem de ser visível, senão a barra parece solta
          var lagE = e.predLag && e.predLag[pid];
          if (lagE != null && sx >= px + 12) svg += '<text class="gantt-lag" x="' + ((px + sx) / 2).toFixed(1) + '" y="' + (py - 4) + '" font-size="8.5" fill="' + corD + '" text-anchor="middle" pointer-events="none">' + (lagE >= 0 ? '+' : '') + lagE + 'd</text>';
        });
      });
      svg += '</svg>';
      /* documento traz a própria legenda (com as categorias da obra): devolver
         a de HTML aqui imprimia DUAS legendas quase iguais, uma embaixo da
         outra — visto na foto do PDF do cronograma. */
      if (limpo || (opts && opts.semLegenda)) return svg;
      // legenda em HTML (herda o tema do card; as amostras repetem a tinta do papel)
      var amostra = function (css) { return '<span style="display:inline-block;width:16px;' + css + ';vertical-align:middle;margin-right:5px"></span>'; };
      return svg + '<div class="muted" style="font-size:11px;margin-top:4px;display:flex;gap:16px;flex-wrap:wrap;align-items:center">' +
        '<span>' + amostra('height:0;border-top:2px solid ' + CRIT) + 'caminho crítico (sem folga)</span>' +
        '<span>' + amostra('height:0;border-top:2px solid ' + CINZA) + 'dependência</span>' +
        '<span>' + amostra('width:12px;height:10px;border:1px dashed ' + CINZA + ';border-radius:2px') + 'folga</span>' +
        (hojeX != null ? '<span>' + amostra('height:0;border-top:2px dashed ' + HOJE) + 'hoje</span>' : '') +
        '</div>';
    },

    // ----- Aba Gráficos -----
    renderGraficos: function (orc) {
      if (!(orc.etapas || []).length) return '<div class="vazio card">Adicione etapas e itens para ver os gráficos.</div>';
      var sint = Orcamento.sintetico(orc);
      var html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">';
      html += '<div class="card"><h3 style="margin:0 0 8px">Custo por etapa</h3>' + this._barH(sint.map(function (s) { return { rotulo: s.codigo + " " + s.nome, valor: s.custoDireto }; }), function (v) { return Util.fmtMoeda(v); }) + '</div>';
      html += '<div class="card"><h3 style="margin:0 0 8px">Curva ABC (Pareto)</h3>' + this._pareto(sint) + '</div>';
      var mme = this._mmeOrc(orc);
      if (mme.total > 0) html += '<div class="card"><h3 style="margin:0 0 8px">Composição (MO/MAT/EQ)</h3>' + this._donut([{ rotulo: "Mão de obra", valor: mme.mo, cor: "#2563eb" }, { rotulo: "Material", valor: mme.mat, cor: "#16a34a" }, { rotulo: "Equipamento", valor: mme.eq, cor: "#f59e0b" }]) + '</div>';
      if (typeof Cronograma !== "undefined") {
        var r = Cronograma.estimar(orc), porCat = {};
        r.etapas.forEach(function (e) { porCat[e.categoria] = (porCat[e.categoria] || 0) + e.duracao; });
        var dd = Object.keys(porCat).map(function (k) { return { rotulo: Cronograma.cat(k).nome, valor: porCat[k], cor: Cronograma.cat(k).cor }; });
        /* ⚠ dias, e dito por extenso: sem o formatador este gráfico ganharia
           "R$" no dia em que uma categoria passasse de mil dias, porque o
           padrão antigo do `_barH` escolhia a unidade pela magnitude. */
        html += '<div class="card"><h3 style="margin:0 0 8px">Prazo por categoria (dias)</h3>' + this._barH(dd, function (v) { return Util.fmtNum(v, 0) + ' dia(s)'; }) + '</div>';
      }
      html += '<div class="card" style="grid-column:1/-1"><h3 style="margin:0 0 8px">Curva S — avanço físico-financeiro acumulado</h3>' + this._curvaS(orc) + '</div>';
      return html + '</div>';
    },

    _curvaS: function (orc) {
      if (typeof Cronograma === "undefined") return '<div class="muted">—</div>';
      var r = Cronograma.estimar(orc), nSem = r.totalSemanas, dpw = r.params.diasUteisSemana || 5;
      var custoSem = [], totalCusto = 0, w;
      for (w = 0; w < nSem; w++) custoSem[w] = 0;
      r.etapas.forEach(function (e) {
        totalCusto += e.custo;
        var s0 = e.inicio / dpw, s1 = e.fim / dpw, dur = Math.max(0.01, s1 - s0);
        for (var ww = 0; ww < nSem; ww++) { var ov = Math.max(0, Math.min(ww + 1, s1) - Math.max(ww, s0)); if (ov > 0) custoSem[ww] += e.custo * (ov / dur); }
      });
      var acc = 0, pts = [], totV = totalCusto || 1;
      for (w = 0; w < nSem; w++) { acc += custoSem[w]; pts.push(acc / totV * 100); }
      var W = 640, H = 200, padL = 34, padB = 22, padT = 10, padR = 12, plotW = W - padL - padR, plotH = H - padB - padT;
      var X = function (i) { return padL + (nSem <= 1 ? plotW : (i / (nSem - 1)) * plotW); };
      var Y = function (v) { return padT + (1 - v / 100) * plotH; };
      var grid = "";
      [0, 25, 50, 75, 100].forEach(function (g) { var yy = Y(g); grid += '<line x1="' + padL + '" y1="' + yy.toFixed(1) + '" x2="' + (W - padR) + '" y2="' + yy.toFixed(1) + '" stroke="#e2e8f0"/><text x="2" y="' + (yy + 3).toFixed(1) + '" font-size="9" fill="#94a3b8">' + g + '%</text>'; });
      var area = "M" + X(0).toFixed(1) + "," + Y(0).toFixed(1) + " " + pts.map(function (v, i) { return "L" + X(i).toFixed(1) + "," + Y(v).toFixed(1); }).join(" ") + " L" + X(nSem - 1).toFixed(1) + "," + Y(0).toFixed(1) + " Z";
      var line = pts.map(function (v, i) { return (i ? "L" : "M") + X(i).toFixed(1) + "," + Y(v).toFixed(1); }).join(" ");
      var dots = pts.map(function (v, i) { return '<circle cx="' + X(i).toFixed(1) + '" cy="' + Y(v).toFixed(1) + '" r="2.5" fill="#2563eb"><title>Semana ' + (i + 1) + ': ' + v.toFixed(1) + '% acumulado</title></circle>'; }).join("");
      var xlab = "", step = Math.max(1, Math.ceil(nSem / 10));
      for (var i3 = 0; i3 < nSem; i3 += step) xlab += '<text x="' + X(i3).toFixed(1) + '" y="' + (H - 6) + '" font-size="8" fill="#94a3b8">S' + (i3 + 1) + '</text>';
      return '<svg viewBox="0 0 ' + W + ' ' + H + '" style="width:100%">' + grid + '<path d="' + area + '" fill="#2563eb" opacity="0.08"/><path d="' + line + '" fill="none" stroke="#2563eb" stroke-width="2"/>' + dots + xlab + '</svg>' +
        '<div class="muted" style="font-size:11px">Custo distribuído ao longo das ' + nSem + ' semanas do cronograma (etapas em paralelo somam na semana). Total: ' + Util.fmtMoeda(totalCusto) + '.</div>';
    },

    /* v1.1.233 — respeita o MODO DE CUSTO. Item "só MO" fatura só a mão de
       obra: somar as três parcelas cruas fazia a pizza mostrar Material que o
       CLIENTE fornece como se fosse custo do orçamento — o gráfico contradizia
       a planilha da tela ao lado. */
    _mmeOrc: function (orc) {
      var mo = 0, mat = 0, eq = 0;
      (orc.etapas || []).forEach(function (e) { (e.itens || []).forEach(function (it) {
        var q = Util.num(it.quantidade);
        var m = it.modoCusto;
        if (m !== "matEq") mo += Util.num(it.custoMO) * q;
        if (m !== "mo") { mat += Util.num(it.custoMAT) * q; eq += Util.num(it.custoEQ) * q; }
      }); });
      return { mo: mo, mat: mat, eq: eq, total: mo + mat + eq };
    },
    /* ⚠ QUEM SABE A UNIDADE É QUEM CHAMA, não este desenho. A versão anterior
       escolhia pela MAGNITUDE — `valor >= 1000 ? fmtMoeda : fmtNum` — e isso
       dava dois erros de leitura ao mesmo tempo:

         · "Custo por m²" mostrava 698 pelado e R$ 1.975,31 com moeda, no mesmo
           cartão, só porque um passou de mil e o outro não;
         · "Prazo por categoria (dias)" ganharia "R$" no dia em que alguma
           categoria passasse de mil dias.

       Agora o formato vem por parâmetro. O padrão continua o de antes para não
       quebrar chamador que ainda não passa nada, mas os três que existem
       passam o seu.

       ⚠ E AS CORES SÃO TOKEN, não hexadecimal cravado. `#475569` sobre o
       cartão escuro dava contraste de 2,41:1 (a WCAG AA pede 4,5:1) e o trilho
       `#e2e8f0` era um retângulo quase branco no meio do tema escuro. */
    _barH: function (dados, fmt) {
      var max = dados.reduce(function (m, d) { return Math.max(m, d.valor); }, 0) || 1;
      var f = fmt || function (v) { return v >= 1000 ? Util.fmtMoeda(v) : Util.fmtNum(v, 0); };
      return '<div>' + dados.map(function (d) {
        var pct = (d.valor / max) * 100, cor = d.cor || "#2563eb";
        return '<div style="margin:5px 0"><div style="font-size:11px;color:var(--texto-fraco);display:flex;justify-content:space-between"><span>' + Util.esc(String(d.rotulo).slice(0, 34)) + '</span><span>' + f(d.valor) + '</span></div>' +
          '<div style="background:var(--linha);border-radius:4px;height:14px"><div style="width:' + pct.toFixed(1) + '%;background:' + cor + ';height:14px;border-radius:4px"></div></div></div>';
      }).join("") + '</div>';
    },
    _pareto: function (sint) {
      var ord = sint.slice().sort(function (a, b) { return b.custoDireto - a.custoDireto; });
      var tot = ord.reduce(function (s, x) { return s + x.custoDireto; }, 0) || 1, acc = 0;
      return '<table class="tbl" style="font-size:12px"><thead><tr><th>Etapa</th><th class="num">Custo</th><th class="num">%</th><th class="num">acum.</th><th>Cl.</th></tr></thead><tbody>' +
        ord.map(function (x) {
          var pc = x.custoDireto / tot * 100; acc += pc; var cl = acc <= 80 ? "A" : (acc <= 95 ? "B" : "C"), cor = cl === "A" ? "#dc2626" : (cl === "B" ? "#f59e0b" : "#16a34a");
          return '<tr><td>' + Util.esc((x.codigo + " " + x.nome).slice(0, 26)) + '</td><td class="num">' + Util.fmtMoeda(x.custoDireto) + '</td><td class="num">' + Util.fmtPct(pc, 1) + '</td><td class="num">' + Util.fmtPct(acc, 1) + '</td><td><b style="color:' + cor + '">' + cl + '</b></td></tr>';
        }).join("") + '</tbody></table>';
    },
    _donut: function (dados) {
      var tot = dados.reduce(function (s, d) { return s + d.valor; }, 0) || 1, ang = -Math.PI / 2, R = 60, cx = 80, cy = 80, parts = "";
      dados.forEach(function (d) {
        var frac = d.valor / tot, a0 = ang, a1 = ang + frac * 2 * Math.PI; ang = a1;
        /* fatia de ~100%: o arco com início = fim degenera e o SVG não desenha
           NADA — orçamento só de material aparecia como donut vazio (v1.1.233).
           Círculo cheio resolve o caso extremo sem tocar nos normais. */
        if (frac >= 0.999) {
          parts += '<circle cx="' + cx + '" cy="' + cy + '" r="' + R + '" fill="' + d.cor + '"><title>' + Util.esc(d.rotulo) + ': ' + Util.fmtPct(frac * 100, 1) + '</title></circle>';
          return;
        }
        var x0 = cx + R * Math.cos(a0), y0 = cy + R * Math.sin(a0), x1 = cx + R * Math.cos(a1), y1 = cy + R * Math.sin(a1), large = frac > 0.5 ? 1 : 0;
        parts += '<path d="M' + cx + ',' + cy + ' L' + x0.toFixed(1) + ',' + y0.toFixed(1) + ' A' + R + ',' + R + ' 0 ' + large + ',1 ' + x1.toFixed(1) + ',' + y1.toFixed(1) + ' Z" fill="' + d.cor + '"><title>' + Util.esc(d.rotulo) + ': ' + Util.fmtPct(frac * 100, 1) + '</title></path>';
      });
      var leg = dados.map(function (d) { return '<div style="font-size:12px;display:flex;align-items:center;gap:6px"><span style="width:11px;height:11px;background:' + d.cor + ';border-radius:2px;display:inline-block"></span>' + Util.esc(d.rotulo) + ' — <b>' + Util.fmtPct(d.valor / tot * 100, 1) + '</b></div>'; }).join("");
      return '<div style="display:flex;gap:14px;align-items:center"><svg viewBox="0 0 160 160" style="width:140px;flex:none">' + parts + '<circle cx="' + cx + '" cy="' + cy + '" r="32" fill="var(--card,#fff)"/></svg><div>' + leg + '</div></div>';
    },

    // ----- Aba Relatórios (Curva ABC + Cronograma) -----
    renderRelatorios: function (orc) {
      var abc = Orcamento.curvaABC(orc);
      var cron = Orcamento.cronograma(orc);
      if (!abc.linhas.length) return '<div class="vazio card">Adicione itens para ver Curva ABC e Cronograma.</div>';

      var corClasse = { A: "verde", B: "amarelo", C: "vermelho" };
      var html = '<h3 style="margin:4px 0 12px">Curva ABC de Itens</h3>';

      // Resumo A/B/C
      html += '<div class="kpis">';
      ["A", "B", "C"].forEach(function (k) {
        var r = abc.resumo[k];
        html += '<div class="kpi"><div class="rotulo">Classe ' + k + ' · ' + r.qtd + ' itens</div>' +
          '<div class="num" style="color:var(--' + corClasse[k] + ')">' + Util.fmtMoeda(r.valor) + '</div>' +
          '<div class="muted" style="font-size:12px">' + Util.fmtPct(r.pct, 1) + ' do custo</div></div>';
      });
      html += '</div>';

      // Tabela ABC
      html += '<table class="tbl"><thead><tr><th>Classe</th><th>Código</th><th>Descrição</th>' +
        '<th class="num">Custo</th><th class="num">% Indiv.</th><th class="num">% Acum.</th><th style="width:120px">Participação</th></tr></thead><tbody>';
      abc.linhas.forEach(function (x) {
        html += '<tr><td><span class="pill" style="background:var(--' + corClasse[x.classe] + ');color:#fff">' + x.classe + '</span></td>' +
          '<td>' + Util.esc(x.codigo) + '</td><td>' + Util.esc(x.descricao.slice(0, 50)) + '</td>' +
          '<td class="num">' + Util.fmtMoeda(x.custoTotal) + '</td>' +
          '<td class="num">' + Util.fmtPct(x.pct, 1) + '</td>' +
          '<td class="num">' + Util.fmtPct(x.acumPct, 1) + '</td>' +
          '<td><div style="background:var(--surface-2);border-radius:4px;height:10px;overflow:hidden">' +
          '<div style="background:var(--' + corClasse[x.classe] + ');height:100%;width:' + Math.max(2, x.pct) + '%"></div></div></td></tr>';
      });
      html += '</tbody></table>';

      // Cronograma
      html += '<div class="flex between" style="margin:26px 0 12px"><h3 style="margin:0">Cronograma Físico-Financeiro</h3>' +
        '<div class="flex"><label class="muted" style="font-size:12px">Prazo (meses):</label>' +
        '<input id="cron-meses" class="cell" style="width:70px;border:1px solid var(--linha)" value="' + cron.meses + '"></div></div>';
      /* ⚠ De onde vieram estes meses. A distribuição passou a seguir a DURAÇÃO
         de cada etapa no Gantt (antes era fatia por peso, e punha dinheiro em
         mês sem serviço). Quando o prazo digitado é MENOR que a obra, o que
         sobra se acumula na última coluna — e isso tem de estar escrito, senão
         o último mês parece um pico de desembolso que não existe. */
      if (cron.base === "gantt") {
        html += '<div class="muted" style="font-size:11.5px;margin:-6px 0 10px">' +
          (typeof Icones !== 'undefined' ? Icones.get('cronograma', 14) : '') +
          ' Desembolso distribuído pela duração de cada etapa no <b>cronograma</b> (aba Cronograma) — as colunas são meses do calendário.' +
          (cron.estouro ? ' <b style="color:#b45309">A obra dura ' + (cron.meses + cron.estouro) + ' meses:</b> os ' + cron.estouro +
            ' mês(es) que passam do prazo digitado estão somados na última coluna (' + Util.esc(cron.rotulos[cron.meses - 1]) + ').' : '') +
          '</div>';
      }
      html += '<div style="overflow:auto"><table class="tbl"><thead><tr><th>Etapa</th>';
      // mês/ano de verdade quando a distribuição segue o Gantt (ver Orcamento.cronograma)
      for (var m = 0; m < cron.meses; m++) html += '<th class="num">' + Util.esc((cron.rotulos && cron.rotulos[m]) || ('Mês ' + (m + 1))) + '</th>';
      html += '<th class="num">Total</th></tr></thead><tbody>';
      cron.etapas.forEach(function (e) {
        html += '<tr><td>' + Util.esc(e.codigo + " " + e.nome) + '</td>';
        e.meses.forEach(function (v) { html += '<td class="num">' + (v > 0.005 ? Util.fmtMoeda(v) : "—") + '</td>'; });
        html += '<td class="num"><b>' + Util.fmtMoeda(e.total) + '</b></td></tr>';
      });
      html += '</tbody><tfoot>';
      html += '<tr class="etapa-row"><td>Total mensal</td>';
      cron.totaisMes.forEach(function (v) { html += '<td class="num">' + Util.fmtMoeda(v) + '</td>'; });
      html += '<td class="num">' + Util.fmtMoeda(cron.total) + '</td></tr>';
      html += '<tr><td class="muted">Acumulado %</td>';
      cron.acumPct.forEach(function (p) { html += '<td class="num muted">' + Util.fmtPct(p, 1) + '</td>'; });
      html += '<td class="num muted">100%</td></tr>';
      html += '</tfoot></table></div>';
      html += '<p class="watermark-hint mt">Distribuição sequencial proporcional ao peso de cada etapa (valores com BDI). Ajuste o prazo para recalcular.</p>';
      return html;
    },

    // ----- Relatório completo (sintético + analítico) para impressão/PDF -----
    /* Linhas de metadados do orçamento que precisam sair NO documento: critério de
     * arredondamento (quem confere a planilha em licitação checa isso) e o bloco
     * de licitação quando o orçamento foi marcado como tal. */
    _dataBr: function (s) {
      var m = String(s || "").match(/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/);
      return m ? (m[3] + "/" + m[2] + "/" + m[1] + (m[4] ? " " + m[4] + ":" + m[5] : "")) : "";
    },
    _metaParametros: function (orc) {
      var cfg;
      try { cfg = Orcamento.garantirConfig(orc); } catch (e) { return ""; }
      var h = "";
      var crit = (typeof Arred !== "undefined")
        ? Arred.rotulo(cfg.arredondamento) + (Arred.ehPadraoTcu(cfg.arredondamento) ? " (padrão do TCU)" : "") +
          " · BDI " + (cfg.bdiIncidencia === "final" ? "no preço final" : "no preço unitário")
        : "";
      if (crit) h += '<div><span>Critério</span> ' + Util.esc(crit) + "</div>";
      var lic = cfg.licitacao || {};
      if (lic.ativo) {
        var partes = [lic.tipo || "", lic.processo ? "Processo " + lic.processo : "",
          this._dataBr(lic.abertura) ? "Abertura " + this._dataBr(lic.abertura) : ""].filter(function (x) { return !!x; });
        h += '<div><span>Licitação</span> ' + Util.esc(partes.join(" · ") || "sim") + "</div>";
      }
      if (cfg.categoria) h += '<div><span>Categoria</span> ' + Util.esc(cfg.categoria) + "</div>";
      return h;
    },

    renderRelatorioCompleto: function (orc, usuario) {
      var t = Orcamento.totais(orc);
      var sint = Orcamento.sintetico(orc);
      var pct = orc.bdi ? orc.bdi.percentual : 0;
      // White-label: cadastro completo da Empresa primeiro; nunca cai no fabricante.
      var empresa = ((typeof Empresa !== "undefined" && Empresa.nomeDoc) ? Empresa.nomeDoc() : "") || (usuario && usuario.empresa) || "Sua Empresa";
      var hoje = new Date().toLocaleDateString("pt-BR");

      var html = '<div class="rel-doc">';
      // marca d'água (mesmo padrão da Proposta/Laudo — configurável em ⚙ Empresa)
      var wmRel = (typeof Empresa !== "undefined" && Empresa.marcaDaguaTexto) ? Empresa.marcaDaguaTexto() : empresa;
      if (wmRel) html += '<div class="wm">' + Util.esc(wmRel) + '</div>';

      // Cabeçalho
      html += '<div class="rel-head">' +
        '<div><div class="rel-emp">' + Util.esc(empresa) + '</div><h1>Relatório de Orçamento</h1>' +
        '<div class="rel-sub">' + Util.esc(orc.nome) + '</div></div>' +
        '<div class="rel-meta">' +
          '<div><span>Nº</span> ' + Util.esc(orc.numero) + '</div>' +
          '<div><span>Cliente</span> ' + Util.esc(orc.cliente.nome || "—") + '</div>' +
          '<div><span>Obra</span> ' + Util.esc((orc.obra && orc.obra.nome) || "—") + '</div>' +
          '<div><span>' + (Orcamento.basesUsadas(orc).length > 1 ? "Bases" : "Base") + '</span> ' + Util.esc(Orcamento.basesUsadasTexto(orc)) + '</div>' +
          '<div><span>Data</span> ' + hoje + '</div>' +
          this._metaParametros(orc) +
        '</div></div>';

      // Resumo
      html += '<div class="rel-kpis">' +
        '<div><span>Custo Direto</span><b>' + Util.fmtMoeda(t.custoDireto) + '</b></div>' +
        '<div><span>BDI</span><b>' + Util.fmtPct(t.bdiPercentual) + '</b></div>' +
        '<div><span>Valor BDI</span><b>' + Util.fmtMoeda(t.bdiValor) + '</b></div>' +
        '<div class="dest"><span>Preço de Venda</span><b>' + Util.fmtMoeda(t.precoVenda) + '</b></div></div>';

      // 1) Planilha SINTÉTICA
      html += '<h2 class="rel-tit">1. Planilha Sintética (por etapa)</h2>';
      html += '<table class="prop-tbl"><thead><tr><th>Cód</th><th>Etapa</th>' +
        '<th class="r">Itens</th><th class="r">Custo Direto</th><th class="r">Preço Venda</th><th class="r">Peso</th></tr></thead><tbody>';
      sint.forEach(function (s) {
        html += '<tr><td>' + Util.esc(s.codigo) + '</td><td>' + Util.esc(s.nome) + '</td>' +
          '<td class="r">' + s.qtdItens + '</td><td class="r">' + Util.fmtMoeda(s.custoDireto) + '</td>' +
          '<td class="r">' + Util.fmtMoeda(s.precoVenda) + '</td><td class="r">' + Util.fmtPct(s.peso, 1) + '</td></tr>';
      });
      html += '</tbody><tfoot><tr><td colspan="3">TOTAL</td><td class="r">' + Util.fmtMoeda(t.custoDireto) +
        '</td><td class="r">' + Util.fmtMoeda(t.precoVenda) + '</td><td class="r">100%</td></tr></tfoot></table>';

      // 2) Planilha ANALÍTICA (detalhada, item a item, por etapa)
      /* as seções 3 e 4 são condicionais (a analítica pode não estar carregada,
         e o quadro só existe se houve alteração) — numerar por contador evita
         o relatório sair "1, 2, 4" quando uma delas não aparece */
      var _secRel = 2;
      html += '<h2 class="rel-tit">2. Planilha Analítica (detalhada)</h2>';
      html += '<table class="prop-tbl"><thead><tr><th>Item</th><th>Código</th><th>Descrição</th><th>Un</th>' +
        '<th class="r">Qtd</th><th class="r">Custo Unit.</th><th class="r">Custo Total</th><th class="r">Preço Venda</th></tr></thead><tbody>';
      // Linhas da FONTE ÚNICA: o documento assinado não pode divergir do Excel
      var calc = Orcamento.calcular(orc), porItem = {}, porEtapa = [];
      calc.linhas.forEach(function (L) {
        porItem[L.etapaIdx + "|" + L.itemIdx] = L;
        var s2 = porEtapa[L.etapaIdx] || (porEtapa[L.etapaIdx] = { custo: 0, venda: 0 });
        s2.custo += L.custoTotal; s2.venda += L.precoTotal;
      });
      var porSubRel = {};
      Util.arr(calc.grupos).forEach(function (g) { porSubRel[g.subEtapaId] = g; });
      Util.arr(orc.etapas).forEach(function (e, ei) {
        // subtotal = soma das linhas impressas (ver comentário em renderPlanilha)
        var sm2 = porEtapa[ei] || { custo: 0, venda: 0 };
        var se = { custoDireto: Arred.valor(sm2.custo, calc.modo), precoVenda: Arred.valor(sm2.venda, calc.modo) };
        html += '<tr class="grp"><td><b>' + (ei + 1) + '</b></td><td colspan="7">' + Util.esc(e.nome) + '</td></tr>';
        if (!e.itens.length) html += '<tr><td colspan="8" class="muted">(sem itens)</td></tr>';
        var _subRelAtual = null;
        e.itens.forEach(function (it, ii) {
          var L = porItem[ei + "|" + ii] || { custoTotal: 0, precoTotal: 0, custoUnitario: 0, numero: "" };
          // cabeçalho da sub etapa (1.1) quando o bloco muda
          if ((L.subEtapaId || "") !== _subRelAtual) {
            _subRelAtual = L.subEtapaId || "";
            if (_subRelAtual) {
              var gR = porSubRel[_subRelAtual] || { numero: "", nome: "", custoTotal: 0, precoTotal: 0 };
              html += '<tr class="grp subetapa"><td style="padding-left:14px"><b>' + Util.esc(gR.numero) + '</b></td>' +
                '<td colspan="5" style="padding-left:14px">' + Util.esc(gR.nome) + '</td>' +
                '<td class="r">' + Util.fmtMoeda(gR.custoTotal) + '</td><td class="r">' + Util.fmtMoeda(gR.precoTotal) + '</td></tr>';
            }
          }
          html += '<tr><td><b>' + (L.numero || Orcamento.itemNumero(ei, ii)) + '</b></td><td>' + Util.esc(it.codigo) + '</td><td>' + Util.esc(it.descricao) + '</td>' +
            '<td>' + Util.esc(Util.unidadeDe(it.unidade, orc)) + '</td>' +
            '<td class="r">' + Util.fmtNum(it.quantidade, 2) + '</td>' +
            '<td class="r">' + Util.fmtMoeda(L.custoUnitario) + '</td>' +
            '<td class="r">' + Util.fmtMoeda(L.custoTotal) + '</td>' +
            '<td class="r">' + Util.fmtMoeda(L.precoTotal) + '</td></tr>';
        });
        html += '<tr class="sub"><td colspan="6">Subtotal ' + (ei + 1) + " · " + Util.esc(e.nome) + '</td>' +
          '<td class="r">' + Util.fmtMoeda(se.custoDireto) + '</td><td class="r">' + Util.fmtMoeda(se.precoVenda) + '</td></tr>';
      });
      html += '</tbody><tfoot>';
      // BDI apartado (incidência "no preço final"): a coluna soma o CUSTO, então
      // o BDI precisa aparecer como linha própria para o rodapé fechar.
      if (!calc.bdiNoPU) {
        html += '<tr><td colspan="6">Custo direto</td><td class="r">' + Util.fmtMoeda(t.custoDireto) + '</td><td class="r">' + Util.fmtMoeda(t.custoDireto) + '</td></tr>' +
          '<tr><td colspan="7">BDI ' + Util.fmtPct(t.bdiPercentual) + ' (sobre o preço final)</td><td class="r">' + Util.fmtMoeda(t.bdiValor) + '</td></tr>';
      }
      html += '<tr><td colspan="6">TOTAL GERAL' + this._seloPrecisao(calc.modo) + '</td><td class="r">' + Util.fmtMoeda(t.custoDireto) +
        '</td><td class="r">' + Util.fmtMoeda(t.precoVenda) + '</td></tr></tfoot></table>';

      // 3) COMPOSIÇÕES E INSUMOS (analítico SINAPI) — cada composição detalhada em seus insumos
      if (typeof Analitico !== "undefined" && Analitico.carregado) {
        var vistos = {}, comps = [];
        Util.arr(orc.etapas).forEach(function (e) {
          Util.arr(e.itens).forEach(function (it) {
            if (it.origem === "SINAPI" && it.codigo && it.codigo !== "—" && !vistos[it.codigo]) {
              var a = Analitico.obter(it.codigo);
              if (a && Util.arr(a.insumos).length) { vistos[it.codigo] = 1; comps.push({ it: it, a: a }); }
            }
          });
        });
        if (comps.length) {
          _secRel++;
          html += '<h2 class="rel-tit">' + _secRel + '. Composições e Insumos (analítico SINAPI)</h2>';
          html += '<p class="muted" style="margin:-6px 0 10px;font-size:12px">' + comps.length +
            ' composição(ões) do orçamento, detalhada(s) em insumos, mão de obra e equipamentos — coeficientes da base SINAPI ' +
            Util.esc((Analitico.competencia || "") + (Analitico.uf ? " / " + Analitico.uf : "")) + '.</p>';
          comps.forEach(function (c) {
            var a = c.a;
            html += '<table class="prop-tbl" style="margin-bottom:12px"><thead>' +
              '<tr class="grp"><td colspan="6">' + Util.esc(c.it.codigo) + ' · ' +
              Util.esc(Util.fixEnc(a.descricao || c.it.descricao)) + ' — un. ' + Util.esc(a.unidade || c.it.unidade) + '</td></tr>' +
              '<tr><th>Tipo</th><th>Código</th><th>Insumo</th><th>Un</th><th class="r">Coef.</th><th class="r">Custo Unit.</th></tr></thead><tbody>';
            Util.arr(a.insumos).forEach(function (ins) {
              html += '<tr><td>' + (ins.tipo === "COMPOSICAO" ? "Sub-comp." : "Insumo") + '</td>' +
                '<td>' + Util.esc(ins.codigo) + '</td>' +
                '<td>' + Util.esc(Util.fixEnc(ins.descricao)) + '</td>' +
                '<td>' + Util.esc(ins.unidade) + '</td>' +
                '<td class="r">' + Util.fmtNum(ins.coeficiente, 4) + '</td>' +
                '<td class="r">' + Util.fmtMoeda(ins.custoUnitario) + '</td></tr>';
            });
            html += '<tr class="sub"><td colspan="4">Composição — MO ' + Util.fmtMoeda(a.custoMO) +
              ' · MAT ' + Util.fmtMoeda(a.custoMAT) + ' · EQ ' + Util.fmtMoeda(a.custoEQ) + '</td>' +
              '<td class="r">Custo unit.</td><td class="r">' + Util.fmtMoeda(a.custoUnitario) + '</td></tr>';
            html += '</tbody></table>';
          });
        }
      }

      /* o quadro de justificativa fecha o relatório: quem analisa lê a planilha
         primeiro e vem aqui conferir o que destoou da referência */
      var _qa = this.renderQuadroAjustes(orc, _secRel + 1);
      if (_qa) { _secRel++; html += _qa; }

      var credRel = (typeof Empresa !== "undefined" && Empresa.creditoTexto) ? Empresa.creditoTexto() : "";
      /* declaração factual de conformidade de preços: um analista precisa saber
         se "não tem quadro de justificativa" quer dizer "nada foi alterado" ou
         "o relatório não mostra isso". A frase responde, e é conferível. */
      var _rAj = (typeof Ajustes !== "undefined" && Ajustes.resumo) ? Ajustes.resumo(orc) : { n: 0 };
      var _totIt = Orcamento.totais(orc).qtdItens;
      html += '<div class="rel-rod">' + (credRel ? Util.esc(credRel) + " · " : "") + hoje +
        ' · Custos ref. ' + Util.esc(Orcamento.basesUsadasTexto(orc)) +
        ' com BDI ' + Util.fmtPct(pct) + ' incluso no preço de venda.' +
        (_rAj.n
          ? ' Preços: ' + (_totIt - _rAj.n) + ' de ' + _totIt + ' itens conforme a base; <b>' + _rAj.n +
            '</b> com preço próprio, detalhado(s) no quadro de justificativa.'
          : ' Todos os ' + _totIt + ' itens seguem o preço da base, sem alteração.') +
        '</div>';
      html += '</div>';
      return html;
    },

    // ----- Aba BDI -----
    renderBdi: function (orc) {
      /* BDI manual (só percentual, sem params) NÃO pode renderizar o preset
         padrão por baixo: os campos diziam 27,03 % sob um número grande de
         20 %, e "Aplicar BDI" sem editar nada trocava o BDI do orçamento.
         Deriva os params do percentual gravado — idempotente por construção. */
      var p = orc.bdi.params;
      if (!p && orc.bdi.percentual != null && isFinite(Util.num(orc.bdi.percentual))) {
        p = Bdi.paramsParaPercentual(orc.bdi.percentual);
      }
      p = p || Bdi.paramsDoModelo("padrao");
      var modSel = orc.bdi.modeloId;
      if (!CONFIG.bdiPresets[modSel] && modSel !== "dnit") modSel = "custom";
      var campos = [
        ["AC", "Administração Central"], ["S", "Seguro"], ["R", "Risco"],
        ["G", "Garantia"], ["DF", "Despesas Financeiras"], ["L", "Lucro"], ["I", "Impostos (PIS+COFINS+ISS)"]
      ];
      var html = '<div class="card" style="max-width:620px">' +
        '<div class="flex mb"><b>Modelo:</b>' +
        '<select id="bdi-modelo" class="btn sm">' +
          Object.keys(CONFIG.bdiPresets).map(function (k) {
            return '<option value="' + k + '"' + (modSel === k ? " selected" : "") + '>' + CONFIG.bdiPresets[k].nome + '</option>';
          }).join("") +
        '<option value="dnit"' + (modSel === "dnit" ? " selected" : "") + '>' + (typeof Icones !== 'undefined' ? Icones.get('pilar', 15) : '') + ' DNIT (Acórdão TCU 2.622/2013)</option>' +
        '<option value="custom"' + (modSel === "custom" ? " selected" : "") + '>Personalizado</option>' +
        '</select></div>' +
        (typeof DnitBdi !== "undefined" ? '<div class="muted mb" style="font-size:12px">🏛️ <b>DNIT · Acórdão 2.622/2013</b> — CPRB atualiza por ano (Lei 14.973/2024): ' +
          DnitBdi.cprbDoAno() + '% em ' + (new Date().getFullYear()) + ' · Selic ref. ' + Util.fmtNum(DnitBdi.selic, 2) + '% · ISS ' + Util.fmtNum(DnitBdi.tributos.iss, 2) + '%</div>' : '');
      html += '<div class="row">';
      campos.forEach(function (c) {
        html += '<div class="field"><label>' + c[1] + ' (%)</label>' +
          '<input id="bdi-' + c[0] + '" type="text" value="' + Util.fmtNum(p[c[0]], c[0] === "L" ? 4 : 2) + '"></div>';
      });
      html += '</div>';
      html += '<div class="flex between mt">' +
        '<div><div class="muted">BDI resultante</div>' +
        '<div style="font-size:32px;font-weight:800;color:var(--verde)" id="bdi-resultado">' + Util.fmtPct(orc.bdi.percentual) + '</div></div>' +
        '<button class="btn primary" data-acao="salvar-bdi">Aplicar BDI</button></div>';
      html += '<p class="watermark-hint mt">Fórmula Acórdão TCU 2.622/2013. Ajuste e clique em "Aplicar BDI".</p>';
      html += '</div>';
      return html;
    },

    // ---------- Importar base SINAPI ----------
    /* `temPropria`: existe base importada gravada para esta empresa. Ver o
       bloco no fim desta função — é a saída que faltava. */
    renderImportSinapi: function (resumo, temPropria) {
      return '' +
        '<p class="muted">Use a base SINAPI da sua região/competência. Aceita <b>JSON</b> (export do ' +
        'sinapi-fetcher) ou <b>CSV</b> com colunas Código, Descrição, Unidade e Custo.</p>' +
        '<div class="row"><div class="field"><label>Competência</label><input id="imp-comp" value="' + Util.esc(resumo.competencia || "") + '" placeholder="2026-05"></div>' +
        '<div class="field"><label>UF</label><input id="imp-uf" value="' + Util.esc(resumo.uf || "") + '" placeholder="MG"></div></div>' +
        '<div class="field"><label>Arquivo (.json / .csv)</label><input id="imp-file" type="file" accept=".json,.csv,.txt"></div>' +
        '<div class="field"><label>…ou cole o conteúdo aqui</label><textarea id="imp-text" rows="5" placeholder=\'{"mes":"2026-05","uf":"MG","dados":[...]}  ou  Codigo;Descricao;Unidade;Custo\'></textarea></div>' +
        '<div class="watermark-hint">A base fica salva por empresa e passa a ser usada na busca e no Escopo. Bases muito grandes podem ficar só na sessão atual (aviso na hora).</div>' +
        /* ⚠ A SAÍDA PRECISA EXISTIR AQUI.
           Quem importa uma base própria para de receber a atualização oficial, e
           isso é DE PROPÓSITO: o auto-update já destruiu tabela de preço
           negociada uma vez. Só que o aviso mandava "remova a base própria em
           ⬆ Importar" e esta tela não tinha como remover — `Store.apagarBaseSinapi`
           existia no store sem UMA chamada no app inteiro. O cliente ficava preso
           numa competência velha sem caminho de volta: no caso real, 8.380 itens
           contra 12.815 da oficial, ~4.400 serviços fora da busca e do Escopo. */
        (temPropria
          ? '<div class="card" style="margin-top:12px;padding:10px 12px;border-left:3px solid #c90">'
            + '<div style="font-size:13px;margin-bottom:8px">Você usa uma <b>base própria importada</b>. '
            + 'Enquanto ela estiver aqui, a atualização oficial da SINAPI não roda.</div>'
            + '<button class="btn sm" data-acao="base-oficial">' + (typeof Icones !== 'undefined' ? Icones.get('voltar', 15) : '') + ' Voltar para a SINAPI oficial</button>'
            + '<div class="muted" style="font-size:11px;margin-top:6px">Apaga só a tabela de preços importada. '
            + 'Suas <b>composições próprias</b>, orçamentos e obras não são tocados.</div></div>'
          : "");
    },

    // ---------- Agente Importador: preview + mapeamento de colunas ----------
    renderImportPreview: function (imp, semWrap) {
      var res = imp.res, mat = imp.matriz || [];
      // headerRow é índice do array SEM linhas vazias (o Importador filtra) — filtrar igual aqui,
      // senão o rótulo da coluna sai da linha errada quando há linha em branco no topo (comum no Excel).
      var matNV = mat.filter(function (r) { return r && r.some(function (c) { return String(Importador._txt(c)).trim() !== ""; }); });
      var nCols = 0; matNV.forEach(function (r) { if (r.length > nCols) nCols = r.length; });
      var hdr = (res.headerRow >= 0) ? (matNV[res.headerRow] || []) : [];
      function letra(i) { var s = ""; i++; while (i > 0) { var m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; }
      function colLabel(i) { var h = hdr[i] != null ? String(Importador._txt(hdr[i])).trim() : ""; return letra(i) + (h ? ": " + h : ""); }
      var roles = [["codigo", "Código"], ["descricao", "Descrição"], ["unidade", "Unidade"], ["quantidade", "Quantidade"], ["custoUnit", "Custo unit."], ["custoTotal", "Custo total"]];
      function selCol(role) {
        var cur = res.colunas ? res.colunas[role[0]] : null, opts = '<option value="">— nenhuma —</option>';
        for (var i = 0; i < nCols; i++) opts += '<option value="' + i + '"' + (cur === i ? " selected" : "") + ">" + Util.esc(colLabel(i)) + "</option>";
        return '<div class="field" style="margin:0"><label style="font-size:11px">' + role[1] + '</label><select id="imp-col-' + role[0] + '">' + opts + "</select></div>";
      }
      var conf = Math.round((res.confianca || 0) * 100), corConf = conf >= 80 ? "#16a34a" : conf >= 50 ? "#f59e0b" : "#dc2626";
      var html = '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px">' +
        '<span class="g-pill" style="background:' + corConf + '22;color:' + corConf + ';font-weight:700">' + (typeof Icones !== 'undefined' ? Icones.get('ia', 15) : '') + ' Confiança ' + conf + "%</span>" +
        '<span class="muted" style="font-size:13px">' + res.resumo.etapas + " etapas · " + res.resumo.itens + " itens" + (res.resumo.ignoradas ? " · " + res.resumo.ignoradas + " linhas ignoradas (totais/vazias)" : "") + "</span></div>";
      html += '<p class="muted" style="font-size:12.5px;margin:0 0 6px">O agente detectou o mapeamento abaixo. Se alguma coluna estiver errada, corrija e clique <b>' + (typeof Icones !== 'undefined' ? Icones.get('ciclo', 15) : '') + ' Reanalisar</b>.</p>';
      html += '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px;margin-bottom:10px">' + roles.map(selCol).join("") + "</div>";
      html += '<input id="imp-header" type="hidden" value="' + (res.headerRow != null ? res.headerRow : -1) + '">';
      if (res.avisos && res.avisos.length) html += '<div class="card" style="background:#fffbeb;border-color:#fde68a;padding:8px 12px;margin-bottom:12px;font-size:12.5px;color:#92400e">⚠️ ' + res.avisos.map(function (a) { return Util.esc(a); }).join("<br>⚠️ ") + "</div>";
      var prev = [], nP = 0, LIMP = 40, cortou = false;
      Util.arr(res.etapas).forEach(function (e) {
        if (nP >= LIMP) { cortou = true; return; }   // não empurra cabeçalho de etapa depois do limite (senão sobram etapas vazias)
        prev.push('<tr class="etapa-row"><td colspan="5"><b>' + Util.esc((e.codigo ? e.codigo + " · " : "") + e.nome) + "</b></td></tr>");
        Util.arr(e.itens).forEach(function (it) { if (nP >= LIMP) { cortou = true; return; } prev.push("<tr><td>" + Util.esc(it.codigo || "—") + "</td><td>" + Util.esc(it.descricao) + "</td><td>" + Util.esc(Util.unidadeExibir(it.unidade)) + '</td><td class="num">' + Util.fmtNum(it.quantidade, 2) + '</td><td class="num">' + Util.fmtMoeda(it.custoUnitario) + "</td></tr>"); nP++; });
      });
      if (cortou) prev.push('<tr><td colspan="5" class="muted" style="text-align:center">… e mais ' + Math.max(0, res.resumo.itens - nP) + ' item(ns) — mostrando os ' + nP + ' primeiros</td></tr>');
      html += '<div style="max-height:300px;overflow:auto;border:1px solid var(--linha);border-radius:8px"><table class="tbl"><thead><tr><th>Código</th><th>Descrição</th><th>Un</th><th class="num">Qtd</th><th class="num">Custo unit.</th></tr></thead><tbody>' + (prev.join("") || '<tr><td colspan="5" class="muted">Nada detectado — ajuste o mapeamento.</td></tr>') + "</tbody></table></div>";
      html += '<p class="muted" style="font-size:11px;margin:8px 0 0">Ao importar: itens com <b>código SINAPI válido</b> são casados na base (o preço oficial preenche o que estiver vazio na planilha); os demais entram como <b>itens próprios</b> com os valores da planilha. Nenhum código é inventado.</p>';
      return semWrap ? html : '<div id="imp-body">' + html + "</div>";
    },

    // ---------- Escopo Inteligente: entrada ----------
    renderEscopoEntrada: function () {
      return '' +
        '<p class="muted">Cole a <b>descrição da obra</b> (texto livre / trecho do laudo) ou itens linha a linha. ' +
        'O <b>' + (typeof Icones !== 'undefined' ? Icones.get('ia', 15) : '') + ' Estruturar com IA</b> quebra a obra em serviços, casa com as bases (SINAPI/SICRO/SUDECAP/SEINFRA/SETOP) e estima as quantidades. Nunca inventa código.</p>' +
        '<div class="field"><textarea id="esc-txt" rows="8" placeholder="Ex. (prosa livre): Reforma de banheiro 6m²: demolir revestimento antigo, novo contrapiso, assentar porcelanato no piso e paredes, instalar bacia e lavatório, impermeabilizar o box e pintar o forro...&#10;&#10;ou linha a linha:&#10;240 m2 alvenaria de bloco ceramico&#10;12 m3 concreto fck 25"></textarea></div>' +
        /* NÍVEL DE DETALHE (v1.1.219): com pouca informação, trazer o serviço
           inteiro é o certo — mas quem quer só o que escreveu tem de poder
           dizer isso. Padrão é "padrao": completo de saída viraria ruído. */
        '<div class="row" style="gap:8px;align-items:flex-end;margin-bottom:8px">' +
          '<div class="field" style="flex:1;min-width:0;margin:0"><label style="font-size:11px">Nível de detalhe</label>' +
            '<select id="esc-nivel" style="width:100%;box-sizing:border-box">' +
            Object.keys(Escopo.NIVEIS).map(function (k) {
              var N = Escopo.NIVEIS[k];
              return '<option value="' + k + '"' + (k === "padrao" ? " selected" : "") + ' title="' + Util.esc(N.ajuda) + '">' + Util.esc(N.rotulo) + '</option>';
            }).join("") + '</select></div>' +
          '<button class="btn" data-acao="escopo-planilha" title="Traz a planilha de quantitativos do arquiteto para cá — descrição, quantidade e unidade viram linhas do escopo">' +
            (typeof Icones !== 'undefined' ? Icones.get('excel', 15) : '') + ' Anexar planilha</button>' +
          '<button class="btn" data-acao="escopo-documento" title="Planta em DXF ou memorial em PDF: o sistema le as etiquetas de ambiente com area (SALA 12,50 m2) e traz para o escopo">' +
            (typeof Icones !== 'undefined' ? Icones.get('laudo', 15) : '') + ' Anexar planta/PDF</button>' +
        '</div>' +
        '<div id="esc-aux"></div>' +
        '<div class="flex" style="gap:8px;margin-bottom:6px"><button class="btn primary" data-acao="escopo-ia">' + (typeof Icones !== 'undefined' ? Icones.get('ia', 15) : '') + ' Estruturar com IA</button>' +
        '<button class="btn" data-acao="escopo-analisar">Analisar linha a linha (sem IA)</button>' +
        '<button class="btn ghost" data-acao="escopo-sugerir" title="Mostra os serviços auxiliares que a boa técnica exige para o que você escreveu">Sugerir complementos</button></div>' +
        '<div class="watermark-hint">Sem match, o item fica <b>Pendente</b> — nunca inventamos código. (A IA roda no servidor do OrçaPRO — precisa de internet e da licença ativa.)</div>';
    },

    // ---------- Escopo Inteligente: resultado ----------
    renderEscopoResultado: function (analise, etapas) {
      var totalOk = analise.filter(function (l) { return l.status === "ok"; }).length;
      var temIA = analise.some(function (l) { return l.etapaSugerida; });
      var html = '<div class="flex between mb"><div><b>' + analise.length + '</b> serviços · ' +
        '<span style="color:var(--verde)">' + totalOk + ' com sugestão</span> · ' +
        '<span style="color:var(--vermelho)">' + (analise.length - totalOk) + ' pendentes</span>' +
        (temIA ? ' <button class="btn sm primary" data-acao="escopo-casar" title="A IA escolhe o código exato entre os candidatos (em lotes)" style="margin-left:8px">' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + ' Refinar com IA</button>' : '') + '</div>' +
        '<div class="flex"><label class="muted" style="font-size:12px">Adicionar à etapa:</label>' +
        '<select id="esc-etapa" class="btn sm">' +
          (temIA ? '<option value="__por_ia__" selected>★ Criar etapas conforme a IA</option>' : '') +
          '<option value="__por_categoria__"' + (temIA ? '' : ' selected') + '>★ Criar etapas por tipo de serviço (auto)</option>' + // FASE 1.3
          etapas.map(function (e) { return '<option value="' + e.id + '">' + Util.esc(e.codigo + " " + e.nome) + '</option>'; }).join("") +
          '<option value="__nova__">+ Nova etapa "Escopo"</option>' +
        '</select></div></div>';

      html += '<table class="tbl"><thead><tr><th>Serviço detectado</th><th class="num">Qtd</th><th>Unid</th>' +
        '<th>Composição sugerida (base)</th><th>Confiança</th></tr></thead><tbody>';

      analise.forEach(function (l, idx) {
        var qtd = '<input class="cell" style="max-width:80px" data-esc-qtd="' + idx + '" value="' + Util.fmtNum(l.quantidade, 2) + '">' +
                  (l.qtdInferida ? '<div class="watermark-hint">inferida</div>' : '');
        var unid = Util.esc(l.unidade || "—");

        var sel = '<select class="btn sm" style="max-width:340px" data-esc-pick="' + idx + '">';
        if (l.candidatos.length) {
          l.candidatos.forEach(function (c, ci) {
            sel += '<option value="' + ci + '"' + (l.escolhido === ci ? " selected" : "") + '>' +
              '[' + Util.esc(c.fonte || "SINAPI") + '] ' + Util.esc(c.item.codigo + " · " + String(c.item.descricao || "").slice(0, 54)) + ' (' + c.confianca + '%)</option>';
          });
        }
        sel += '<option value="-1"' + (l.escolhido === -1 ? " selected" : "") + '>— Ignorar / pendente —</option></select>';

        var confHtml = "—";
        var marca = l.refinadoIA ? ' <span title="Código escolhido pela IA do ERP">' + (typeof Icones !== 'undefined' ? Icones.get('alvo', 15) : '') + '</span>' : '';
        if (l.escolhido > -1 && l.candidatos[l.escolhido]) {
          var c = l.candidatos[l.escolhido];
          var n = Escopo.nivel(c.confianca);
          confHtml = '<span class="pill" style="background:var(--' + n.cor + ');color:#fff">' + n.rotulo + ' ' + c.confianca + '%</span>' + marca;
        } else {
          /* ⚠ PENDENTE É ONDE O AGENTE MAIS VALE. O escopo já sabe exatamente
             o que não casou com base nenhuma — e é justamente aí que o
             orçamentista abandonava o sistema e ia para o Excel. */
          confHtml = '<span class="pill proprio">Pendente</span>' + marca +
            '<br><button class="btn sm success" data-acao="esc-elaborar" data-i="' + idx + '" ' +
            'style="margin-top:4px;font-size:11px" title="O agente monta uma composição própria a partir da composição oficial mais parecida — insumos e coeficientes reais, nunca inventados">' +
            (typeof Icones !== 'undefined' ? Icones.get('escopo', 14) : '') + ' Elaborar composição</button>';
        }

        html += '<tr><td>' + Util.esc(l.textoOriginal) + '</td>' +
          '<td class="num">' + qtd + '</td><td>' + unid + '</td>' +
          '<td data-esc-conf-cell="' + idx + '">' + sel + '</td>' +
          '<td data-esc-conf="' + idx + '">' + confHtml + '</td></tr>';
      });
      html += '</tbody></table>';
      return html;
    }
  };

  /* `extra` sai DENTRO do card, embaixo do número (v1.1.227.1). Nasceu porque
     o botão de fechar em um valor, solto entre os KPIs e a barra de abas,
     simplesmente não era encontrado — o Rogério não achou. Ali é ponto morto:
     abaixo de quatro cards grandes e acima das abas, que puxam o olho. A ação
     tem de morar no card do número que ela muda. */
  function kpi(rotulo, valor, cls, extra) {
    return '<div class="kpi ' + (cls || "") + '"><div class="rotulo">' + rotulo + '</div><div class="num">' + valor + '</div>' +
      (extra ? '<div style="margin-top:7px">' + extra + "</div>" : "") + "</div>";
  }

  /* ============================================================
   * CHÃO DE ESTILO DAS IMAGENS DO USUÁRIO
   *
   * POR QUE ISTO EXISTE — aconteceu num tablet do cliente: o logo da
   * empresa apareceu do tamanho ORIGINAL do arquivo (1200 px), cobrindo
   * meia tela, junto com a foto de perfil gigante.
   *
   * A causa NÃO foi CSS errado. Foi CSS que não CHEGOU: o nome do cache
   * do service worker ficou parado na v1.1.146 durante as v1.1.147 e
   * v1.1.148 — e a v1.1.148 é justamente a que criou `.conta-logo`,
   * `.conta-foto` e `.obra-capa`. O JS novo desenhava elementos que a
   * folha de estilo antiga não sabia dimensionar. Nenhum erro, em lugar
   * nenhum: só a tela quebrada.
   *
   * A regra que fica: imagem que vem do USUÁRIO tem tamanho desconhecido,
   * então o dimensionamento dela não pode morar SÓ no css/app.css.
   *
   * Aqui vai por <style> injetado, e NÃO por style inline em cada <img>,
   * porque inline vence media query — a primeira tentativa deste conserto
   * travou a capa da obra em 132px e comeu os 152px que ela tem no tablet
   * e no celular. Injetado, o responsivo continua funcionando.
   *
   * São as MESMAS regras do css/app.css (linhas ~1019-1040). Duplicadas de
   * propósito: se um dia mudarem lá, mude aqui junto — quem garante isso é
   * o tools/e2e-imagem-sem-css.js, que derruba as regras da folha de
   * estilo e exige que os tamanhos se mantenham.
   * ============================================================ */
  UI.chaoDeEstilo = function () {
    try {
      var d = global.document;
      if (!d || !d.head || d.getElementById("ui-chao-imagens")) return false;
      var st = d.createElement("style");
      st.id = "ui-chao-imagens";
      st.textContent = [
        ".conta-logo{height:22px;max-width:84px;width:auto;object-fit:contain;border-radius:4px;background:rgba(255,255,255,.92);padding:1px 3px;flex:none}",
        ".conta-foto{width:26px;height:26px;border-radius:50%;object-fit:cover;flex:none}",
        ".orc-card .obra-capa{margin:-24px -24px 14px;height:132px;overflow:hidden;background:var(--surface-2,#eef1f5)}",
        ".orc-card .obra-capa img{width:100%;height:100%;object-fit:cover;display:block}",
        "@media screen and (max-width:820px){.orc-card .obra-capa{height:152px}}",
        "@media screen and (max-width:620px){.conta-logo{display:none}}",
        "@media print{.orc-card .obra-capa,.conta-logo,.conta-foto{display:none!important}}"
      ].join("\n");
      d.head.appendChild(st);
      return true;
    } catch (e) { return false; }
  };
  UI.chaoDeEstilo();

  global.UI = UI;
})(window);
