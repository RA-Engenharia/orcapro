/* =====================================================================
 * desenho2d.js — PLANTA E CORTE COMO DESENHO TÉCNICO (07/10/2026)
 *
 * Pedido do Rogério: a planta baixa como desenho técnico — corte em linha,
 * alta qualidade, opção de linha mais fina ou mais grossa, cortes A,
 * B, C, D na lateral, cota com estilo de cota, opção de tirar a cota.
 *
 * Este arquivo é o MOTOR PURO (Node-testável, sem DOM e sem three.js):
 *   entra  → os DADOS do desenho, já em coordenadas de TELA em metros
 *            (X para a direita, Y para BAIXO), vindos de BIM.vista2d:
 *            { tipo:'planta'|'corte', cortes:[{pts:[[x,y]..], fechado}],
 *              linhas:[[x1,y1,x2,y2]..], niveis:[{nome, y, cota}],
 *              marcas:[{id, letra, a:[x,y], b:[x,y], olhar:[dx,dy]}] }
 *   sai    → as COTAS (lista de objetos) e o SVG pronto.
 *
 * PENAS: espessura de tela em pixels (vector-effect: non-scaling-stroke) —
 * a linha fica nítida e com a mesma espessura em qualquer zoom.
 * Três jogos: fina / média / grossa. O que é CORTADO sai na pena
 * grossa do jogo; o que é VISTO além do corte, na fina.
 * ANOTAÇÃO (cota, marca de corte, nível, título) tem tamanho de PAPEL: mm na
 * escala da vista (1:50 → 1 mm de papel = 0,05 m) — trocar a
 * escala da vista aumenta ou diminui a anotação, não o desenho.
 * Teste: node tools/test-desenho2d.js
 * ===================================================================== */
(function (global) {
  "use strict";

  var PENAS = {
    fina:   { rotulo: "Fina",   corte: 1.6, vista: 0.55, cota: 0.6, marca: 0.9 },
    media:  { rotulo: "Média",  corte: 2.4, vista: 0.9,  cota: 0.8, marca: 1.2 },
    grossa: { rotulo: "Grossa", corte: 3.4, vista: 1.3,  cota: 1.1, marca: 1.6 }
  };
  /* "Espessura das linhas" com os ESTILOS DE OBJETO (P6) ativos: um FATOR sobre a
     pena em mm de cada categoria — Média = o estilo exato. É a proporção do jogo
     de papel (js/prancha.js PENAS_PAPEL, corte 0,35 / 0,50 / 0,70 mm — a mesma do
     DXF e da folha; o teste confere), quase igual à de tela acima (1,6 / 2,4 / 3,4).
     Só muda a SAÍDA (px na tela e data-mm para a folha/PDF/DXF): o estilo de objeto
     gravado não muda. Antes, com P6 ativo, o controle só mexia em cota, marca e título. */
  var FATOR_PENA = { fina: 0.7, media: 1, grossa: 1.4 };
  function fatorPena(p) { return FATOR_PENA[p] || 1; }
  var PREENCHIMENTOS = {
    hachura: "Hachura 45°", solido: "Sólido escuro", cinza: "Cinza claro", vazio: "Sem preenchimento"
  };
  var MARCAS_COTA = { obliquo: "Traço oblíquo", seta: "Seta", ponto: "Ponto" };
  var UNIDADES = { m: "metros (3,45)", cm: "centímetros (345)", mm: "milímetros (3450)" };
  var ESCALAS = [20, 25, 50, 75, 100, 125, 200];
  /* P2-D (js/bimambienteui.js): "Esquema de cores" da vista */
  var ESQUEMAS = { nenhum: "Nenhum", nome: "Por nome", departamento: "Por departamento" };
  /* CONVENÇÃO DE REFORMA (19/10/2026): opção de ESTILO da vista; o padrão das outras plantas não muda.
     Cores e traços são os da convenção brasileira de projeto de reforma/ampliação (prefeitura):
       A CONSTRUIR  — vermelho, com hachura (e preenchimento claro);
       A DEMOLIR    — amarelo, tracejado;
       EXISTENTE A MANTER — preto / cinza.
     As pranchas de arquitetura (js/arqpranchas.js) usam esta MESMA tabela; o teste confere. */
  var CONVENCOES = { padrao: "Padrão (sem convenção de reforma)", reforma: "Reforma: construir, demolir, existente" };
  var CONV_REFORMA = {
    novo:      { rotulo: "A CONSTRUIR", cor: "#d00000", fill: "#f6c9c9", hachura: "#d00000", tracejado: null },
    demolido:  { rotulo: "A DEMOLIR", cor: "#f0a800", fill: "#fff2b8", hachura: null, tracejado: [1.5, 1] },
    existente: { rotulo: "EXISTENTE A MANTER", cor: "#1a1a1a", fill: "#bdbdbd", hachura: null, tracejado: null }
  };

  function estiloPadrao() {
    return { escala: 50, pena: "media", preenchimento: "hachura", cotas: true, marcaCota: "obliquo",
             textoCota: 2.5, unidade: "m", casas: 2, cotaParcial: true, niveis: true, marcasCorte: true, titulo: true,
             /* P2-D: ambientes na planta — identificador (nome; número · área) e esquema de cores */
             identAmbiente: true, esquemaCores: "nenhum",
             /* CONVENÇÃO DE REFORMA (19/10/2026): "reforma" = a construir em vermelho com hachura, a demolir em amarelo tracejado, existente em preto/cinza + legenda */
             convencao: "padrao" };
  }
  function normEstilo(e) {
    var p = estiloPadrao(), o = {};
    Object.keys(p).forEach(function (k) { o[k] = (e && e[k] != null) ? e[k] : p[k]; });
    if (!PENAS[o.pena]) o.pena = "media";
    if (!PREENCHIMENTOS[o.preenchimento]) o.preenchimento = "hachura";
    if (!MARCAS_COTA[o.marcaCota]) o.marcaCota = "obliquo";
    if (!UNIDADES[o.unidade]) o.unidade = "m";
    o.escala = Math.max(1, +o.escala || 50);
    o.textoCota = Math.max(1, Math.min(6, +o.textoCota || 2.5));
    o.casas = Math.max(0, Math.min(3, Math.round(+o.casas)));
    if (isNaN(o.casas)) o.casas = 2;
    o.cotas = !!o.cotas; o.cotaParcial = !!o.cotaParcial; o.niveis = !!o.niveis; o.marcasCorte = !!o.marcasCorte; o.titulo = !!o.titulo;
    o.identAmbiente = o.identAmbiente !== false && o.identAmbiente !== "false";
    if (!ESQUEMAS[o.esquemaCores]) o.esquemaCores = "nenhum";
    if (!CONVENCOES[o.convencao]) o.convencao = "padrao";
    /* ⚠ o padrão NÃO é gravado: estilo salvo antes da convenção (templates .optpl, vistas por obra) tem de
       normalizar igual a antes — com o campo sempre presente, os templates RA deixaram de bater consigo mesmos
       (test-bim-b6 [8], 20/10/2026). Quem lê usa `e.convencao === "reforma"` / `e.convencao || "padrao"`. */
    if (o.convencao === "padrao") delete o.convencao;
    return o;
  }

  /* ----------------------------------------------------------- números */
  function fmtNum(v, casas) {
    var s = (Math.round(v * Math.pow(10, casas)) / Math.pow(10, casas)).toFixed(casas);
    var neg = s.charAt(0) === "-"; if (neg) s = s.slice(1);
    var p = s.split("."), int = p[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return (neg ? "-" : "") + int + (p[1] ? "," + p[1] : "");
  }
  /* medida em metros → texto na unidade da cota */
  function fmtMedida(m, est) {
    var e = normEstilo(est);
    if (e.unidade === "cm") return fmtNum(m * 100, e.casas > 1 ? 0 : e.casas);
    if (e.unidade === "mm") return fmtNum(m * 1000, 0);
    return fmtNum(m, e.casas);
  }
  function fmtCota(y) { return (y > 0.0005 ? "+" : y < -0.0005 ? "" : "±") + fmtNum(Math.abs(y) < 0.0005 ? 0 : y, 2); }

  /* agrupa valores a menos de `tol` (média do grupo), ordenado */
  function agrupar(vals, tol) {
    var v = vals.slice().sort(function (a, b) { return a - b; }), out = [], grupo = [];
    v.forEach(function (x) {
      if (grupo.length && x - grupo[grupo.length - 1] > tol) { out.push(media(grupo)); grupo = []; }
      grupo.push(x);
    });
    if (grupo.length) out.push(media(grupo));
    return out;
  }
  function media(a) { var s = 0; a.forEach(function (x) { s += x; }); return s / a.length; }

  /* caixa de tudo o que foi desenhado */
  function caixa(d) {
    var b = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
    function p(x, y) { if (x < b.x0) b.x0 = x; if (x > b.x1) b.x1 = x; if (y < b.y0) b.y0 = y; if (y > b.y1) b.y1 = y; }
    (d.cortes || []).forEach(function (c) { (c.pts || []).forEach(function (q) { p(q[0], q[1]); }); });
    (d.linhas || []).forEach(function (l) { p(l[0], l[1]); p(l[2], l[3]); });
    /* PORTA (js/simboloporta.js): a folha aberta e o arco do giro também ocupam o papel */
    (d.portas || []).forEach(function (sp) { pontosPorta(sp).forEach(function (q) { p(q[0], q[1]); }); });
    /* ACIMA DO CORTE: a projeção da viga em balanço também ocupa o papel */
    (d.acima || []).forEach(function (it) {
      if (!it) return;
      (it.pts || []).forEach(function (q) { p(q[0], q[1]); });
      (it.segs || []).forEach(function (l) { p(l[0], l[1]); p(l[2], l[3]); });
    });
    if (b.x0 === Infinity) return null;
    return b;
  }

  /* ------------------------------------------------------------- cotas
   * As faces do que foi CORTADO viram cota em cadeia (cotar paredes) e a soma vira a cota total, na linha de fora. Na planta: em cima
   * (posições X das faces verticais) e à esquerda (posições Y das faces
   * horizontais). No corte: embaixo (largura) e à direita (alturas das faces
   * horizontais cortadas + níveis).
   * Cada cota = { eixo:'h'|'v', a, b (posições no eixo), base (onde a peça
   * está, do lado da cota), linha (onde a linha de cota passa), valor }. */
  /* `lado` (opcional) limita às peças cortadas que encostam naquele lado da
     caixa — 'cima'|'baixo'|'esq'|'dir' — até `faixa` metros para dentro: é a
     parede de FORA, a que a cota em cadeia de fachada mede (vão, pano, vão…). */
  function facesCortadas(d, eixo, lado, faixa) {
    var pos = [], cx = lado ? (caixa({ cortes: d.cortes }) || caixa(d)) : null, fx = faixa || 0.8;
    (d.cortes || []).forEach(function (c) {
      if (cx) {
        var by0 = Infinity, by1 = -Infinity, bx0 = Infinity, bx1 = -Infinity;
        (c.pts || []).forEach(function (q) { if (q[0] < bx0) bx0 = q[0]; if (q[0] > bx1) bx1 = q[0]; if (q[1] < by0) by0 = q[1]; if (q[1] > by1) by1 = q[1]; });
        if (lado === "cima" && by0 > cx.y0 + fx) return;
        if (lado === "baixo" && by1 < cx.y1 - fx) return;
        if (lado === "esq" && bx0 > cx.x0 + fx) return;
        if (lado === "dir" && bx1 < cx.x1 - fx) return;
      }
      var pts = c.pts || [], n = pts.length, lim = c.fechado ? n : n - 1;
      for (var i = 0; i < lim; i++) {
        var a = pts[i], b = pts[(i + 1) % n];
        var dx = Math.abs(b[0] - a[0]), dy = Math.abs(b[1] - a[1]), L = Math.sqrt(dx * dx + dy * dy);
        if (L < 0.05) continue;
        if (eixo === "x" && dx < 0.012) pos.push((a[0] + b[0]) / 2);   /* face vertical → posição X */
        if (eixo === "y" && dy < 0.012) pos.push((a[1] + b[1]) / 2);   /* face horizontal → posição Y */
      }
    });
    return agrupar(pos, 0.015);
  }
  /* as CONSTRUÇÕES do desenho: peças cortadas cujas caixas ficam a menos de GAP_CONSTRUCAO m uma da outra formam um grupo
     (a casa e a garagem a 3 m são uma; o exemplo 40 m ao lado é outra) */
  var GAP_CONSTRUCAO = 10;
  function construcoes(cortes) {
    var bs = cortes.map(function (c) {
      var b = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
      (c.pts || []).forEach(function (q) { if (q[0] < b.x0) b.x0 = q[0]; if (q[0] > b.x1) b.x1 = q[0]; if (q[1] < b.y0) b.y0 = q[1]; if (q[1] > b.y1) b.y1 = q[1]; });
      return b;
    }), pai = bs.map(function (b, i) { return i; });
    function raiz(i) { while (pai[i] !== i) { pai[i] = pai[pai[i]]; i = pai[i]; } return i; }
    /* varredura por x0 crescente: parou de sobrepor em x, os seguintes (x0 maior) também não sobrepõem */
    var ord = bs.map(function (b, i) { return i; }).filter(function (i) { return bs[i].x0 !== Infinity; }).sort(function (a, b) { return bs[a].x0 - bs[b].x0; });
    for (var oi = 0; oi < ord.length; oi++) {
      var i = ord[oi];
      for (var oj = oi + 1; oj < ord.length; oj++) {
        var j = ord[oj];
        if (bs[j].x0 - GAP_CONSTRUCAO > bs[i].x1) break;
        if (bs[i].y0 - GAP_CONSTRUCAO <= bs[j].y1 && bs[j].y0 - GAP_CONSTRUCAO <= bs[i].y1) pai[raiz(j)] = raiz(i);
      }
    }
    var mapa = {}, out = [];
    cortes.forEach(function (c, i) { if (bs[i].x0 === Infinity) return; var r = raiz(i); if (!mapa[r]) { mapa[r] = []; out.push(mapa[r]); } mapa[r].push(c); });
    return out;
  }
  /* REVISOR (21/10/2026): a caixa do que está desenhado EM VOLTA de uma construção (as paredes dela + linha, porta e o que
     está acima do corte cuja caixa encosta na dela, a até meia GAP_CONSTRUCAO). Com uma construção só, a cadeia fica "por
     fora de tudo" (a caixa do desenho); com várias, a linha ficava só por fora das paredes e cruzava o beiral desenhado. */
  function caixaEmVolta(d, cg) {
    var b = { x0: cg.x0, y0: cg.y0, x1: cg.x1, y1: cg.y1 }, m = GAP_CONSTRUCAO / 2;
    function item(pts) {
      var q = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
      pts.forEach(function (p) { if (p[0] < q.x0) q.x0 = p[0]; if (p[0] > q.x1) q.x1 = p[0]; if (p[1] < q.y0) q.y0 = p[1]; if (p[1] > q.y1) q.y1 = p[1]; });
      if (q.x0 === Infinity || q.x0 > cg.x1 + m || q.x1 < cg.x0 - m || q.y0 > cg.y1 + m || q.y1 < cg.y0 - m) return;
      if (q.x0 < b.x0) b.x0 = q.x0; if (q.x1 > b.x1) b.x1 = q.x1; if (q.y0 < b.y0) b.y0 = q.y0; if (q.y1 > b.y1) b.y1 = q.y1;
    }
    (d.linhas || []).forEach(function (l) { if (l) item([[l[0], l[1]], [l[2], l[3]]]); });
    (d.portas || []).forEach(function (sp) { item(pontosPorta(sp)); });
    (d.acima || []).forEach(function (it) {
      if (!it) return;
      var ps = (it.pts || []).slice(); (it.segs || []).forEach(function (l) { ps.push([l[0], l[1]], [l[2], l[3]]); });
      item(ps);
    });
    return b;
  }
  function cotasDe(d, est) {
    var e = normEstilo(est), cx = caixa(d), out = [];
    if (!cx || !e.cotas) return out;
    /* ⚠ a cota automática mede o que foi CORTADO da construção (parede, pilar): o polígono da INSTALAÇÃO (tubo, conexão,
       caixa — apresentação de prancha, js/biminstnivel.js) não entra, senão cada bolsa vira uma cota (17/10/2026) */
    var ehInstC = function (c) { return !!(c && (c.inst || (c.k && String(c.k).indexOf("|inst:") >= 0))); };
    if ((d.cortes || []).some(ehInstC)) { var d0 = d; d = {}; Object.keys(d0).forEach(function (kk) { d[kk] = d0[kk]; }); d.cortes = (d0.cortes || []).filter(function (c) { return !ehInstC(c); }); }
    var k = e.escala / 1000, passo = 7 * k, folga = 9 * k;   /* 7 mm do desenho à 1ª linha; 7 mm entre linhas */
    function cadeia(eixo, posicoes, base, sentido, fila, min, max, folgaPapel) {
      var linha = base + sentido * ((folgaPapel != null ? folgaPapel * k : folga) + passo * fila);
      if (posicoes.length >= 3 && e.cotaParcial && posicoes.length <= 80) {
        for (var i = 0; i + 1 < posicoes.length; i++) {
          var a = posicoes[i], b = posicoes[i + 1];
          if (b - a < 0.04) continue;
          out.push({ eixo: eixo, a: a, b: b, base: base, linha: linha, valor: b - a, parcial: true });
        }
        linha = base + sentido * (folga + passo * (fila + 1));
      }
      if (max - min > 0.02) out.push({ eixo: eixo, a: min, b: max, base: base, linha: linha, valor: max - min, parcial: false });
    }
    if (d.tipo === "corte") {
      /* COTA DE ARQUITETURA (27/10/2026): a cota do corte vai do PISO ACABADO MAIS BAIXO até o topo. O que está abaixo dele
         (estaca, bloco, baldrame, sapata, tubo enterrado) não entra na cota: a cadeia de baixo fica logo abaixo do piso
         (12 mm no papel) e a vertical termina no piso. Sem nível no desenho, vale a caixa inteira como antes. */
      var yPiso = null;
      (d.niveis || []).forEach(function (n) { if (n.y >= cx.y0 - 0.01 && n.y <= cx.y1 + 0.01 && (yPiso == null || n.y > yPiso)) yPiso = n.y; });
      var yb = yPiso != null ? yPiso : cx.y1;
      var xs = [cx.x0, cx.x1];
      cadeia("h", agrupar(xs, 0.015), yb, +1, 0, cx.x0, cx.x1, yPiso != null ? 12 : null);
      /* alturas: faces horizontais cortadas da faixa da direita (laje, piso, verga…) + os níveis */
      var ys = facesCortadas(d, "y", "dir", 1.5).filter(function (y) { return y <= yb + 0.01; });
      (d.niveis || []).forEach(function (n) { if (n.y >= cx.y0 - 0.01 && n.y <= yb + 0.01) ys.push(n.y); });
      ys = agrupar(ys.concat([cx.y0, yb]), 0.03);
      cadeia("v", ys, cx.x1, +1, 0, cx.y0, yb);
    } else {
      /* fachada de cima e lateral esquerda: a parede de fora, vão a vão */
      /* mede o que foi CORTADO (as paredes), com a linha de cota por fora de tudo.
         CONSTRUÇÕES SEPARADAS (21/10/2026): a cadeia e o total iam do canto de uma casa até outra construção 40 m ao
         lado (o contorno era o de TUDO o que está desenhado). Cada grupo de peças cortadas a menos de GAP_CONSTRUCAO
         umas das outras é uma construção e tem a cadeia no PRÓPRIO contorno; com uma só, nada muda. */
      var grupos = construcoes(d.cortes || []);
      if (grupos.length <= 1) {
        var cc = caixa({ cortes: d.cortes }) || cx;
        var px = agrupar(facesCortadas(d, "x", "cima", 0.8).concat([cc.x0, cc.x1]), 0.015);
        cadeia("h", px, cx.y0, -1, 0, cc.x0, cc.x1);
        var py = agrupar(facesCortadas(d, "y", "esq", 0.8).concat([cc.y0, cc.y1]), 0.015);
        cadeia("v", py, cx.x0, -1, 0, cc.y0, cc.y1);
      } else grupos.forEach(function (g) {
        var dg = { cortes: g }, cg = caixa(dg);
        if (!cg) return;
        var cf = caixaEmVolta(d, cg);   /* a linha por fora do que está desenhado em volta desta construção */
        /* PEÇA SOLTA (poste, pilar isolado, muro de divisa longe da casa) não é construção: a cadeia só sai no eixo em que o
           grupo tem ao menos 1 m — o muro mantém o comprimento, a espessura dele e o poste não viram cota total */
        if (cg.x1 - cg.x0 >= 1) {
          var pxg = agrupar(facesCortadas(dg, "x", "cima", 0.8).concat([cg.x0, cg.x1]), 0.015);
          cadeia("h", pxg, cf.y0, -1, 0, cg.x0, cg.x1);
        }
        if (cg.y1 - cg.y0 >= 1) {
          var pyg = agrupar(facesCortadas(dg, "y", "esq", 0.8).concat([cg.y0, cg.y1]), 0.015);
          cadeia("v", pyg, cf.x0, -1, 0, cg.y0, cg.y1);
        }
      });
    }
    return out;
  }

  /* ---------------------------------------------------------------- SVG */
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function n4(v) { return Math.round(v * 10000) / 10000; }
  function caminho(pts, fecha, arcos) {
    if (!pts || pts.length < 2) return "";
    var s = "M" + n4(pts[0][0]) + " " + n4(pts[0][1]);
    if (!arcos) { for (var i = 1; i < pts.length; i++) s += "L" + n4(pts[i][0]) + " " + n4(pts[i][1]); return s + (fecha ? "Z" : ""); }
    /* CURVA: arcos[k] = { r, grande, horario, n } — as n arestas a partir do ponto k são UM arco
       (js/bimcurva.js cortePlanta): sai o comando A do SVG até o ponto k + n; quem não lê `arcos`
       (recorte, cotas) vê as cordas de 2 mm nos pontos */
    var N = pts.length, lim = fecha ? N : N - 1, k = 0;
    while (k < lim) {
      var a = arcos[k], m = a && a.n > 0 ? a.n : 1, t = (k + m) % N, q = pts[t];
      if (a && a.r > 0) s += "A" + n4(a.r) + " " + n4(a.r) + " 0 " + (a.grande ? 1 : 0) + " " + (a.horario ? 1 : 0) + " " + n4(q[0]) + " " + n4(q[1]);
      else if (!(fecha && t === 0)) s += "L" + n4(q[0]) + " " + n4(q[1]);
      k += m;
    }
    return s + (fecha ? "Z" : "");
  }
  var NS = 'vector-effect="non-scaling-stroke"';
  /* TRACEJADO NA TELA × NO PAPEL (14/10/2026). ⚠ Com vector-effect="non-scaling-stroke" o navegador aplica o
     stroke-dasharray em PIXELS de tela: o traço medido em metros de desenho (a 1:50, o eixo de 8 mm de papel =
     0,40 m) virava 0,4 px — eixo, marca de corte, nível, instalação, linha oculta saíam como pontilhado quase
     contínuo. Na TELA o traço vai em px, proporcional ao tipo de linha em mm de papel (TRACO_PX_POR_MM); o
     traço de PAPEL de sempre (mm × escala, o mesmo texto de antes) vai em data-traco, e a folha/PDF
     (js/pranchaui.js viewportSvg) o põe de volta — o papel sai igual, byte a byte. O DXF lê só a
     QUANTIDADE de valores (tracejado × traço-ponto) e usa o LTYPE dele. */
  var TRACO_PX_POR_MM = 5 / 3;
  function tracoPx(mm) {
    return (mm || []).map(function (v) { var px = Math.abs(+v || 0) * TRACO_PX_POR_MM; return Math.round(Math.max(1, px) * 1000) / 1000; }).join(" ");
  }
  /* mm = o padrão em mm de papel; papel = o texto do traço no desenho (metros), o mesmo de antes */
  function tracoAttr(mm, papel) { return ' stroke-dasharray="' + tracoPx(mm) + '" data-traco="' + papel + '"'; }
  function tracoK(mm, k) { return tracoAttr(mm, mm.map(function (v) { return n4(v * k); }).join(" ")); }
  /* TEXTO: o desenho está em METROS, e a letra de uma cota mede 0,1 m. Com
     font-size < 1 o navegador arredonda o espaço entre letras e a cota sai
     "1 5 , 2 5". Por isso a letra é desenhada em corpo 100 e ENCOLHIDA por
     transform (scale) — mesmo tamanho final, espaçamento certo. */
  function txt(x, y, h, conteudo, cls, ancora, rot) {
    var s = h / 100;
    return '<text x="0" y="0" font-size="100"' + (ancora ? ' text-anchor="' + ancora + '"' : "") +
      ' transform="translate(' + n4(x) + " " + n4(y) + ")" + (rot ? " rotate(" + rot + ")" : "") + " scale(" + (Math.round(s * 1e7) / 1e7) + ')" class="' + cls + '">' + conteudo + "</text>";
  }

  function svgCota(c, e, pena, ocup) {
    var k = e.escala / 1000, h = e.textoCota * k, ext = 2 * k, gap = 1.5 * k, tk = 1.6 * k;
    var s = "", t = esc(fmtMedida(c.valor, e)), mid = (c.a + c.b) / 2, sent = c.linha >= c.base ? 1 : -1;
    /* COTAS (14/10/2026): o texto que não cabe entre as marcas (a laje de 0,12, o piso de 0,10) ficava em cima
       das marcas e do vizinho — sai para FORA, depois da maior ponta, e a linha de cota vai até ele */
    var wT = String(fmtMedida(c.valor, e)).length * h * 0.56, fora = wT + h * 0.5 > Math.abs(c.b - c.a), hi = Math.max(c.a, c.b), lo = Math.min(c.a, c.b);
    if (fora) mid = hi + ext + h * 0.4 + wT / 2;
    /* COTAS (17/10/2026, banheiro de exemplo: "0,0207" e "0,0072"): DUAS cotas curtas vizinhas punham o número para fora
       no MESMO lugar. A linha de cota guarda os trechos de texto já postos (ocup); o número que bate num deles vai para
       o outro lado (antes da menor ponta) e, se ainda bater, anda para fora até achar lugar. */
    var chaveL = c.eixo + "|" + Math.round(c.linha * 1e4), folgaT = h * 0.3;
    if (ocup) {
      var tomados = ocup[chaveL] || (ocup[chaveL] = []);
      var bate = function (m) { return tomados.some(function (q) { return m - wT / 2 - folgaT < q[1] && m + wT / 2 + folgaT > q[0]; }); };
      if (fora && bate(mid)) {
        var antes = lo - ext - h * 0.4 - wT / 2;
        if (!bate(antes)) mid = antes;
        else { var tent = mid; for (var gi = 0; gi < 40 && bate(tent); gi++) tent += wT * 0.5 + folgaT; mid = tent; }
      }
      tomados.push([mid - wT / 2, mid + wT / 2]);
    }
    function ln(x1, y1, x2, y2, w) { return '<line x1="' + n4(x1) + '" y1="' + n4(y1) + '" x2="' + n4(x2) + '" y2="' + n4(y2) + '" stroke-width="' + w + '" ' + NS + "/>"; }
    function marca(x, y, ang) {
      if (e.marcaCota === "ponto") return '<circle cx="' + n4(x) + '" cy="' + n4(y) + '" r="' + n4(0.7 * k) + '" class="d2-cota-pt"/>';
      if (e.marcaCota === "seta") {
        var L = 2.6 * k, W = 0.9 * k, ca = Math.cos(ang), sa = Math.sin(ang);
        var p1 = [x - ca * L - sa * W, y - sa * L + ca * W], p2 = [x - ca * L + sa * W, y - sa * L - ca * W];
        return '<path d="M' + n4(x) + " " + n4(y) + "L" + n4(p1[0]) + " " + n4(p1[1]) + "L" + n4(p2[0]) + " " + n4(p2[1]) + 'Z" class="d2-cota-pt"/>';
      }
      return ln(x - tk * 0.7071, y + tk * 0.7071, x + tk * 0.7071, y - tk * 0.7071, pena.marca);
    }
    if (c.eixo === "h") {
      var y = c.linha;
      s += ln(c.a, c.base + sent * gap, c.a, y + sent * ext, pena.cota) + ln(c.b, c.base + sent * gap, c.b, y + sent * ext, pena.cota);
      s += ln(c.a - (e.marcaCota === "obliquo" ? ext : 0), y, c.b + (e.marcaCota === "obliquo" ? ext : 0), y, pena.cota);
      if (fora) s += mid > hi ? ln(hi, y, mid + wT / 2, y, pena.cota) : ln(mid - wT / 2, y, lo, y, pena.cota);
      s += marca(c.a, y, Math.PI) + marca(c.b, y, 0);
      s += txt(mid, y - 0.8 * k, h, t, "d2-cota-tx", "middle");
    } else {
      var x = c.linha;
      s += ln(c.base + sent * gap, c.a, x + sent * ext, c.a, pena.cota) + ln(c.base + sent * gap, c.b, x + sent * ext, c.b, pena.cota);
      s += ln(x, c.a - (e.marcaCota === "obliquo" ? ext : 0), x, c.b + (e.marcaCota === "obliquo" ? ext : 0), pena.cota);
      if (fora) s += mid > hi ? ln(x, hi, x, mid + wT / 2, pena.cota) : ln(x, mid - wT / 2, x, lo, pena.cota);
      s += marca(x, c.a, -Math.PI / 2) + marca(x, c.b, Math.PI / 2);
      s += txt(x - 0.8 * k, mid, h, t, "d2-cota-tx", "middle", -90);
    }
    return '<g class="d2-cota' + (c.parcial ? " d2-parcial" : "") + '">' + s + "</g>";
  }

  /* COTA ALINHADA do modelador (B3): a cota permanente do editor, em qualquer
     direção. c = { a:[x,y], b:[x,y], off (m, lado esquerdo de A→B na planta), valor }.
     O mesmo traço da cota da planta: chamadas, linha, marca e texto. */
  function svgCotaAlinhada(c, e, pena) {
    var dx = c.b[0] - c.a[0], dy = c.b[1] - c.a[1], L = Math.sqrt(dx * dx + dy * dy); if (!(L > 1e-6)) return "";
    var k = e.escala / 1000, h = e.textoCota * k, ux = dx / L, uy = dy / L, nx = dy / L, ny = -dx / L, off = +c.off || 0, sg = off >= 0 ? 1 : -1, tk = 1.6 * k, gap = 1.5 * k, ext = 2 * k;
    var l1 = [c.a[0] + nx * off, c.a[1] + ny * off], l2 = [c.b[0] + nx * off, c.b[1] + ny * off];
    function ln(x1, y1, x2, y2, w) { return '<line x1="' + n4(x1) + '" y1="' + n4(y1) + '" x2="' + n4(x2) + '" y2="' + n4(y2) + '" stroke-width="' + w + '" ' + NS + "/>"; }
    var s = ln(c.a[0] + nx * gap * sg, c.a[1] + ny * gap * sg, l1[0] + nx * ext * sg, l1[1] + ny * ext * sg, pena.cota) +
            ln(c.b[0] + nx * gap * sg, c.b[1] + ny * gap * sg, l2[0] + nx * ext * sg, l2[1] + ny * ext * sg, pena.cota) +
            ln(l1[0] - ux * ext, l1[1] - uy * ext, l2[0] + ux * ext, l2[1] + uy * ext, pena.cota);
    [l1, l2].forEach(function (q) { s += ln(q[0] - (ux + nx) * tk * 0.5, q[1] - (uy + ny) * tk * 0.5, q[0] + (ux + nx) * tk * 0.5, q[1] + (uy + ny) * tk * 0.5, pena.marca); });
    var ang = Math.atan2(uy, ux) * 180 / Math.PI; if (ang > 90 || ang <= -90) ang += 180;   /* texto nunca de cabeça para baixo */
    var mx = (l1[0] + l2[0]) / 2 + nx * 0.8 * k * sg, my = (l1[1] + l2[1]) / 2 + ny * 0.8 * k * sg;
    s += txt(mx, my, h, esc(fmtMedida(c.valor != null ? c.valor : L, e)), "d2-cota-tx", "middle", n4(ang));
    return '<g class="d2-cota d2-cota-modelo">' + s + "</g>";
  }

  /* marca de corte na planta: traço-ponto além das pontas + cabeça (círculo
     com a letra) e seta para o lado que se olha, nas duas pontas */
  function svgMarcaCorte(m, e, pena) {
    var k = e.escala / 1000, R = 4 * k, a = m.a, b = m.b;
    var dx = b[0] - a[0], dy = b[1] - a[1], L = Math.sqrt(dx * dx + dy * dy) || 1, ux = dx / L, uy = dy / L;
    var ox = (m.olhar && m.olhar[0]) || -uy, oy = (m.olhar && m.olhar[1]) || ux;
    var s = '<line x1="' + n4(a[0]) + '" y1="' + n4(a[1]) + '" x2="' + n4(b[0]) + '" y2="' + n4(b[1]) + '" stroke-width="' + pena.marca + '" ' + NS + tracoK([8, 1.5, 1, 1.5], k) + ' class="d2-eixo"/>';
    [a, b].forEach(function (p, i) {
      var cx = p[0] - (i ? -1 : 1) * ux * R * 1.2, cy = p[1] - (i ? -1 : 1) * uy * R * 1.2;
      var tip = [cx + ox * R * 1.9, cy + oy * R * 1.9], l1 = [cx + ux * R * 0.9, cy + uy * R * 0.9], l2 = [cx - ux * R * 0.9, cy - uy * R * 0.9];
      s += '<path d="M' + n4(l1[0]) + " " + n4(l1[1]) + "L" + n4(tip[0]) + " " + n4(tip[1]) + "L" + n4(l2[0]) + " " + n4(l2[1]) + 'Z" class="d2-marca-seta"/>';
      s += '<circle cx="' + n4(cx) + '" cy="' + n4(cy) + '" r="' + n4(R) + '" stroke-width="' + pena.marca + '" ' + NS + ' class="d2-marca-circ"/>';
      s += txt(cx, cy + 1.1 * k, 3.2 * k, esc(m.letra), "d2-marca-tx", "middle");
    });
    return '<g class="d2-marca" data-d2-corte="' + esc(m.id) + '">' + s + "</g>";
  }

  /* EIXO da grade (B2, js/bimarq.js): traço-ponto de ponta a ponta e a bolinha
     com o nome além de cada ponta. Planta: { nome, a:[x,y], b:[x,y] }; corte:
     { nome, x } (linha vertical na altura do desenho, bolinha em cima). */
  function svgEixo(ex, cx, e, pena) {
    var k = e.escala / 1000, R = 4 * k, s = "", a = ex.a, b = ex.b, cent = [];
    if (!a) { a = [ex.x, cx.y1 + 4 * k]; b = [ex.x, cx.y0 - 4 * k]; }
    var dx = b[0] - a[0], dy = b[1] - a[1], L = Math.sqrt(dx * dx + dy * dy) || 1, ux = dx / L, uy = dy / L;
    s += '<line x1="' + n4(a[0]) + '" y1="' + n4(a[1]) + '" x2="' + n4(b[0]) + '" y2="' + n4(b[1]) + '" stroke-width="' + pena.marca + '" ' + NS + tracoK([8, 1.5, 1, 1.5], k) + ' class="d2-eixo"/>';
    if (ex.a) cent = [[a[0] - ux * R, a[1] - uy * R], [b[0] + ux * R, b[1] + uy * R]]; else cent = [[b[0], b[1] - R]];
    cent.forEach(function (c) {
      s += '<circle cx="' + n4(c[0]) + '" cy="' + n4(c[1]) + '" r="' + n4(R) + '" stroke-width="' + pena.marca + '" ' + NS + ' class="d2-marca-circ"/>';
      s += txt(c[0], c[1] + 1.1 * k, 3.2 * k, esc(ex.nome), "d2-marca-tx", "middle");
    });
    return '<g class="d2-eixo-g" data-d2-eixo="' + esc(ex.id || ex.nome) + '">' + s + "</g>";
  }

  function svgNivel(nv, cx, e, pena) {
    var k = e.escala / 1000, x = cx.x1 + 22 * k, s = "";
    s += '<line x1="' + n4(cx.x0 - 3 * k) + '" y1="' + n4(nv.y) + '" x2="' + n4(x + 12 * k) + '" y2="' + n4(nv.y) + '" stroke-width="' + pena.cota + '" ' + NS + tracoK([4, 1.5], k) + ' class="d2-nivel-l"/>';
    var t = 1.8 * k;
    s += '<path d="M' + n4(x) + " " + n4(nv.y) + "L" + n4(x - t) + " " + n4(nv.y - t * 1.4) + "L" + n4(x + t) + " " + n4(nv.y - t * 1.4) + 'Z" class="d2-nivel-tri"/>';
    s += txt(x + 2.6 * k, nv.y - 1.6 * k, 2.5 * k, esc(nv.nome) + " " + esc(fmtCota(nv.cota != null ? nv.cota : -nv.y)), "d2-nivel-tx");
    return '<g class="d2-nivel">' + s + "</g>";
  }

  /* desenho → SVG. `extra.titulo` = nome da vista. Devolve { svg, caixa, cotas } */
  function svg(d, est, extra) {
    var e = normEstilo(est), pena = PENAS[e.pena], k = e.escala / 1000;
    /* d.area: a folha em branco do projeto que ainda não tem peça (js/bim2dui.js `_vazio`, 20/10/2026) */
    var cx = caixa(d) || (d.area && d.area.x1 > d.area.x0 && d.area.y1 > d.area.y0 ? { x0: d.area.x0, y0: d.area.y0, x1: d.area.x1, y1: d.area.y1 } : null) || { x0: 0, y0: 0, x1: 1, y1: 1 };
    var cotas = cotasDe(d, e);
    var m = 32 * k;   /* margem de papel para cotas, níveis e marcas */
    var conv = e.convencao === "reforma" ? CONV_REFORMA : null;
    var vb = { x: cx.x0 - m, y: cx.y0 - m, w: Math.max((cx.x1 - cx.x0) + 2 * m + (d.tipo === "corte" && e.niveis ? 75 * k : 0), conv ? 118 * k : 0), h: (cx.y1 - cx.y0) + 2 * m + (e.titulo ? 10 * k : 0) + (conv ? 22 * k : 0) };
    /* vínculo CAD (DWG/DXF): fica FORA da caixa das cotas (cota mede o modelo),
       mas o papel cresce para ele caber inteiro */
    var cad = d.cad || [], cadPath = "", cadTx = "";
    if (cad.length) {
      var q = { x0: vb.x, y0: vb.y, x1: vb.x + vb.w, y1: vb.y + vb.h };
      cad.forEach(function (v) {
        var s = v.seg || [];
        for (var i = 0; i + 3 < s.length; i += 4) {
          cadPath += "M" + n4(s[i]) + " " + n4(s[i + 1]) + "L" + n4(s[i + 2]) + " " + n4(s[i + 3]);
          if (s[i] < q.x0) q.x0 = s[i]; if (s[i] > q.x1) q.x1 = s[i]; if (s[i + 2] < q.x0) q.x0 = s[i + 2]; if (s[i + 2] > q.x1) q.x1 = s[i + 2];
          if (s[i + 1] < q.y0) q.y0 = s[i + 1]; if (s[i + 1] > q.y1) q.y1 = s[i + 1]; if (s[i + 3] < q.y0) q.y0 = s[i + 3]; if (s[i + 3] > q.y1) q.y1 = s[i + 3];
        }
        (v.tx || []).forEach(function (t) { cadTx += txt(t[0], t[1], 2.2 * k, esc(t[2]), "d2-cad-tx"); });
      });
      vb = { x: q.x0, y: q.y0, w: q.x1 - q.x0, h: q.y1 - q.y0 };
    }
    /* eixos (B2): o papel cresce para as bolinhas caberem */
    var eixos = d.eixos || [];
    if (eixos.length) {
      var qe = { x0: vb.x, y0: vb.y, x1: vb.x + vb.w, y1: vb.y + vb.h }, Re = 9 * k;
      eixos.forEach(function (ex) {
        (ex.a ? [ex.a, ex.b] : [[ex.x, cx.y0 - 4 * k - 2 * Re]]).forEach(function (pp) {
          if (pp[0] - Re < qe.x0) qe.x0 = pp[0] - Re; if (pp[0] + Re > qe.x1) qe.x1 = pp[0] + Re;
          if (pp[1] - Re < qe.y0) qe.y0 = pp[1] - Re; if (pp[1] + Re > qe.y1) qe.y1 = pp[1] + Re;
        });
      });
      vb = { x: qe.x0, y: qe.y0, w: qe.x1 - qe.x0, h: qe.y1 - qe.y0 };
    }
    /* P2-D: a LEGENDA do esquema de cores fica à direita do desenho: o papel cresce */
    var amb = (d.tipo === "planta" && d.ambientes) ? d.ambientes : null, leg = amb && amb.legenda && (amb.legenda.itens || []).length ? amb.legenda : null, legX = 0;
    if (leg) {
      legX = cx.x1 + 14 * k;
      var nc = Math.max(String(leg.titulo || "").length, leg.itens.reduce(function (mx, it) { return Math.max(mx, String(it.rotulo || "").length + 6); }, 0));
      var lw = 2.6 * k * 0.62 * nc + 4 * k, lh = 9 * k + leg.itens.length * 6 * k;
      var qx = { x0: vb.x, y0: vb.y, x1: Math.max(vb.x + vb.w, legX + lw), y1: Math.max(vb.y + vb.h, cx.y0 + lh) };
      vb = { x: qx.x0, y: qx.y0, w: qx.x1 - qx.x0, h: qx.y1 - qx.y0 };
    }
    /* P7 (js/bimanot.js): a ANOTAÇÃO da vista (cotas por referência, texto, nuvem, linhas e regiões) — o papel cresce para ela */
    var A7 = d.anotP7 && global.BimAnotP7 ? global.BimAnotP7 : null, qa7 = A7 ? A7.caixa(d.anotP7, e) : null;
    if (qa7) { var x7 = Math.min(vb.x, qa7.x0), y7 = Math.min(vb.y, qa7.y0); vb = { x: x7, y: y7, w: Math.max(vb.x + vb.w, qa7.x1) - x7, h: Math.max(vb.y + vb.h, qa7.y1) - y7 }; }
    if (d.marcasP6 && d.marcasP6.length) vb = p6Caixa(d.marcasP6, vb, k);   /* P6: o papel cresce para as marcas de elevação */
    var p = [];
    /* P6 — GANCHO: com `extra.p6` (js/bimmodelovista.js) o corpo do desenho sai pelos
       ESTILOS DE OBJETO RA (pena em mm por categoria, padrão de linha, preenchimento por
       material, meio-tom); sem ele, o desenho de sempre */
    var p6 = extra && extra.p6 ? p6Corpo(d, e, extra.p6) : null;
    p.push('<svg xmlns="http://www.w3.org/2000/svg" class="d2-svg" data-d2-tipo="' + esc(d.tipo) + '" viewBox="' + n4(vb.x) + " " + n4(vb.y) + " " + n4(vb.w) + " " + n4(vb.h) + '" preserveAspectRatio="xMidYMid meet"' + (p6 ? ' data-d2-p6="1"' : "") + ">");
    p.push("<defs>" +
      '<pattern id="d2-hach" patternUnits="userSpaceOnUse" width="' + n4(1.6 * k) + '" height="' + n4(1.6 * k) + '" patternTransform="rotate(45)">' +
      '<line x1="0" y1="0" x2="0" y2="' + n4(1.6 * k) + '" stroke="#1a1a1a" stroke-width="' + n4(0.18 * k) + '"/></pattern>' +
      (conv ? '<pattern id="d2-hach-n" patternUnits="userSpaceOnUse" width="' + n4(1.6 * k) + '" height="' + n4(1.6 * k) + '" patternTransform="rotate(45)"><rect width="' + n4(1.6 * k) + '" height="' + n4(1.6 * k) + '" fill="' + conv.novo.fill + '"/><line x1="0" y1="0" x2="0" y2="' + n4(1.6 * k) + '" stroke="' + conv.novo.hachura + '" stroke-width="' + n4(0.22 * k) + '"/></pattern>' : "") +
      (p6 ? p6.defs : "") + "</defs>");
    p.push('<rect x="' + n4(vb.x) + '" y="' + n4(vb.y) + '" width="' + n4(vb.w) + '" height="' + n4(vb.h) + '" class="d2-papel"/>');
    /* 0) vínculo CAD — por baixo de tudo, em meio-tom */
    if (cadPath) p.push('<g class="d2-cad"><path d="' + cadPath + '" class="d2-cad-l" stroke-width="' + n4(pena.vista * 0.8) + '" ' + NS + "/>" + cadTx + "</g>");
    /* 0b) P2-D: a COR de cada ambiente (esquema de cores) — por baixo das linhas */
    if (amb) p.push(svgAmbCores(amb));
    /* 0b') PAGINAÇÃO NO MODELO (js/bimpaginacaoui.js): as peças do piso, os recortes
       destacados e o ponto de partida; a indicação do revestimento nas faces. Por baixo
       das paredes cortadas (o recorte encosta na face, nunca passa por cima dela) */
    if (amb && amb.paginacao) p.push(svgPaginacao(amb.paginacao, e, pena));
    /* 0c) ACIMA DO CORTE (14/10/2026): a projeção tracejada das peças acima do plano, por BAIXO do
       que é visto e do que é cortado (a parede cortada sob a viga ganha do tracejado) */
    if (d.tipo === "planta" && d.acima && d.acima.length) p.push(svgAcima(d.acima, e, pena, d.acimaRotulo, extra && extra.p6 ? extra.p6 : null));
    if (p6) p.push(p6.corpo); else {   /* P6: 1) e 2) pelos estilos de objeto RA */
    /* 1) o que se VÊ além do corte — pena fina, por baixo */
    var lin = "";
    (d.linhas || []).forEach(function (l) { lin += "M" + n4(l[0]) + " " + n4(l[1]) + "L" + n4(l[2]) + " " + n4(l[3]); });
    if (lin) p.push('<path d="' + lin + '" class="d2-vista" stroke-width="' + pena.vista + '" ' + NS + "/>");
    /* 2) o que é CORTADO — preenchimento + contorno na pena grossa */
    var fill = e.preenchimento === "hachura" ? "url(#d2-hach)" : e.preenchimento === "solido" ? "#3a3a3a" : e.preenchimento === "cinza" ? "#cfd3d8" : "none";
    var fechados = "", abertos = "", fase = {};
    (d.cortes || []).forEach(function (c) {
      if (c.fase) { var q = fase[c.fase] || (fase[c.fase] = { f: "", a: "" }); if (c.fechado) q.f += caminho(c.pts, true); else q.a += caminho(c.pts, false); return; }   /* P10 */
      if (c.fechado) fechados += caminho(c.pts, true, c.arcos); else abertos += caminho(c.pts, false, c.arcos);   /* CURVA: c.arcos */
    });
    /* CONVENÇÃO DE REFORMA: o que não tem fase marcada é a CONSTRUIR (a fase de agora) — vermelho com hachura; style inline vence a classe */
    var stN = conv ? ' style="stroke:' + conv.novo.cor + '"' : "";
    if (fechados) p.push('<path d="' + fechados + '" fill="' + (conv ? "url(#d2-hach-n)" : fill) + '" fill-rule="evenodd" class="d2-corte' + (conv ? " d2-corte-novo" : "") + '"' + stN + ' stroke-width="' + pena.corte + '" ' + NS + "/>");
    if (abertos) p.push('<path d="' + abertos + '" fill="none" class="d2-corte' + (conv ? " d2-corte-novo" : "") + '"' + stN + ' stroke-width="' + pena.corte + '" ' + NS + "/>");
    }
    /* CONVENÇÃO DE REFORMA com os estilos de objeto (P6): o que é a construir é repintado em vermelho com hachura por cima do corpo */
    if (conv && p6) {
      var fN = "", aN = "";
      (d.cortes || []).forEach(function (c) { if (c.fase) return; if (c.fechado) fN += caminho(c.pts, true, c.arcos); else aN += caminho(c.pts, false, c.arcos); });
      if (fN) p.push('<path d="' + fN + '" fill="url(#d2-hach-n)" fill-rule="evenodd" class="d2-corte d2-corte-novo" style="stroke:' + conv.novo.cor + '" stroke-width="' + pena.corte + '" ' + NS + "/>");
      if (aN) p.push('<path d="' + aN + '" fill="none" class="d2-corte d2-corte-novo" style="stroke:' + conv.novo.cor + '" stroke-width="' + pena.corte + '" ' + NS + "/>");
    }
    /* 2a) P10 (js/bimfases.js): GRÁFICOS DE FASE — o existente em meio-tom (cinza, preenchimento claro),
       o demolido TRACEJADO e sem preenchimento, o temporário em traço-ponto */
    p.push(svgFases(fase, d.linhasFase, pena, k, conv));
    if (conv) p.push(svgLegendaReforma(conv, vb, k, pena));
    /* 2a') PORTA (js/simboloporta.js): a folha aberta a 90° (pena média) e o arco do giro (pena fina) */
    if (d.portas && d.portas.length) p.push(svgPortas(d.portas, e, pena, extra && extra.p6 ? extra.p6 : null));
    /* 2b) INSTALAÇÕES (B5, js/biminst.js planta): o eixo de cada trecho na cor do
       sistema (acima do corte, tracejado), prumadas, conexões e peças, e o
       rótulo (sistema, DN, inclinação). Pena da vista; a cor é o que separa. */
    if (!p6 && d.instImagens) p.push(svgInstImagens(d.instImagens, d.instClip));   /* PARIDADE: a vista da cena (Alto) */
    if (d.inst) p.push(svgInst(d.inst, k, pena));
    if (A7) p.push(A7.svg(d.anotP7, e, pena, "fundo"));   /* P7: região preenchida e mascaramento, por cima do modelo */
    /* 3) anotação */
    if (d.tipo === "corte" && e.niveis) (d.niveis || []).forEach(function (nv) { p.push(svgNivel(nv, cx, e, pena)); });
    if (d.tipo === "planta" && e.marcasCorte) (d.marcas || []).forEach(function (mc) { p.push(svgMarcaCorte(mc, e, pena)); });
    if (d.marcasP6 && d.marcasP6.length) p.push(p6Marcas(d.marcasP6, e, pena));   /* P6: elevação, chamada de detalhe, recorte */
    eixos.forEach(function (ex) { p.push(svgEixo(ex, cx, e, pena)); });
    /* P8 (junção 18/10/2026): o lugar novo do número da cota curta só com a prévia ?previa=hidro (sem BimPrevia — Node,
       testes — vale o novo); sem a prévia, o SVG do master (null = svgCota sem ocupação) */
    var semPrevia = false; try { semPrevia = !!(global.BimPrevia && typeof global.BimPrevia.hidro === "function" && !global.BimPrevia.hidro()); } catch (eP8) { semPrevia = false; }
    var ocupCota = semPrevia ? null : {};   /* os números já postos em cada linha de cota (cota curta não põe número em cima de outro) */
    /* as compridas primeiro (o número delas fica dentro e ocupa o meio); as curtas procuram lugar depois */
    /* JUNÇÃO 18/10/2026: o LUGAR do número é decidido nessa ordem, mas o SVG sai na ordem de sempre — a folha sem colisão
       fica byte a byte igual à do master (tools/test-traco-tela.js) */
    var svgCotas = new Array(cotas.length);
    cotas.map(function (c, i) { return { c: c, i: i }; }).sort(function (x, y) { return Math.abs(y.c.b - y.c.a) - Math.abs(x.c.b - x.c.a) || x.i - y.i; })
      .forEach(function (o) { svgCotas[o.i] = svgCota(o.c, e, pena, ocupCota); });
    svgCotas.forEach(function (s) { p.push(s); });
    if (d.tipo === "planta" && e.cotas) (d.cotasModelo || []).forEach(function (c) { p.push(svgCotaAlinhada(c, e, pena)); });
    /* P2-D: identificador de ambiente (nome; número · área) e a legenda do esquema de cores */
    if (amb) p.push(svgAmbTags(amb, e, pena));
    if (leg) p.push(svgAmbLegenda(leg, legX, cx.y0, k, pena));
    if (A7) p.push(A7.svg(d.anotP7, e, pena, "frente"));   /* P7: cotas, textos, símbolos, nuvens, linhas, componentes, legenda */
    /* P5 (js/bimanot.js): identificadores e o que as próximas partes da anotação puserem (d.anotacao) */
    if (d.tipo === "planta" && d.anotacao) {
      var AN5 = global.BimAnot || (typeof require === "function" ? (function () { try { return require("./bimanot.js"); } catch (eR) { return null; } })() : null);
      if (AN5 && AN5.svgPlanta) p.push(AN5.svgPlanta(d.anotacao, e, pena));
    }
    if (e.titulo && extra && extra.titulo) {
      var ty = cx.y1 + m * 0.62 + (e.titulo ? 6 * k : 0);
      p.push('<g class="d2-titulo">' + txt(cx.x0, ty, 3.4 * k, esc(String(extra.titulo).toUpperCase()), "d2-tit-tx") +
        '<line x1="' + n4(cx.x0) + '" y1="' + n4(ty + 1.2 * k) + '" x2="' + n4(cx.x0 + Math.max(40 * k, (cx.x1 - cx.x0) * 0.4)) + '" y2="' + n4(ty + 1.2 * k) + '" stroke-width="' + pena.corte + '" ' + NS + ' class="d2-tit-l"/>' +
        txt(cx.x0, ty + 4.6 * k, 2.4 * k, "ESC 1:" + e.escala, "d2-tit-esc") + "</g>");
    }
    p.push("</svg>");
    return { svg: p.join(""), caixa: cx, vb: vb, cotas: cotas, estilo: e };
  }

  /* ---------------------------------------------------- FASES (P10)
   * cortes: { status: { f: caminhos fechados, a: abertos } }; linhas: { status: [[x1,y1,x2,y2]…] } */
  /* ⚠ 14/10/2026: o traço de TELA destes (6 4 / 9 3 2 3) já era em px e fica; o de PAPEL não existia — na
     folha/PDF o "6 4" virava 6 m de traço (o viewport tira o non-scaling) e a demolição saía quase contínua. Agora o
     papel vai em data-traco (tracoAttr), pelo tipo de linha em mm: DEMOLIDO = o "demolido" do Padrão RA
     (data/estilos-objeto-ra.json, 1,5 / 1 mm, tracejado curto); TEMPORÁRIO = o traço-ponto do desenho (8 / 1,5 / 1 /
     1,5 mm, o mesmo do eixo e do LTYPE TRACO-PONTO do DXF — o Padrão RA não tem um "temporário" próprio). */
  var FASE_SVG = {
    existente: { cor: "#8a8a8a", fill: "#e4e4e4", tr: "" },
    demolido: { cor: "#3a3a3a", fill: "none", px: "6 4", mm: [1.5, 1] },
    temporario: { cor: "#3a3a3a", fill: "none", px: "9 3 2 3", mm: [8, 1.5, 1, 1.5] }
  };
  function trFase(g, k) {
    if (g.tr != null) return g.tr;
    return ' stroke-dasharray="' + g.px + '" data-traco="' + g.mm.map(function (v) { return n4(v * (k > 0 ? k : 0.05)); }).join(" ") + '"';
  }
  function svgFases(cortesF, linhasF, pena, k, conv) {
    var s = "";
    /* convenção de reforma: existente preto/cinza, demolido amarelo TRACEJADO (1,5 / 1 mm de papel), temporário igual ao demolido */
    function gDe(st) {
      if (!conv) return FASE_SVG[st] || FASE_SVG.existente;
      var c = conv[st === "temporario" ? "demolido" : st] || conv.existente;
      return c.tracejado ? { cor: c.cor, fill: c.fill, px: "6 4", mm: c.tracejado } : { cor: c.cor, fill: c.fill, tr: "" };
    }
    Object.keys(linhasF || {}).forEach(function (st) {
      var g = gDe(st), l = "";
      (linhasF[st] || []).forEach(function (q) { l += "M" + n4(q[0]) + " " + n4(q[1]) + "L" + n4(q[2]) + " " + n4(q[3]); });
      if (l) s += '<path d="' + l + '" fill="none" class="d2-fase d2-fase-' + st + '" stroke="' + g.cor + '"' + (conv ? ' style="stroke:' + g.cor + '"' : "") + trFase(g, k) + ' stroke-width="' + pena.vista + '" ' + NS + "/>";
    });
    Object.keys(cortesF || {}).forEach(function (st) {
      var g = gDe(st), q = cortesF[st], sty = conv ? ' style="stroke:' + g.cor + '"' : "";
      if (q.f) s += '<path d="' + q.f + '" fill="' + g.fill + '" fill-rule="evenodd" class="d2-fase d2-fase-' + st + '" stroke="' + g.cor + '"' + sty + trFase(g, k) + ' stroke-width="' + pena.corte + '" ' + NS + "/>";
      if (q.a) s += '<path d="' + q.a + '" fill="none" class="d2-fase d2-fase-' + st + '" stroke="' + g.cor + '"' + sty + trFase(g, k) + ' stroke-width="' + pena.corte + '" ' + NS + "/>";
    });
    return s;
  }
  /* LEGENDA AUTOMÁTICA da convenção (embaixo do desenho, em mm de papel na escala da vista) */
  function svgLegendaReforma(conv, vb, k, pena) {
    var x0 = vb.x + 4 * k, y0 = vb.y + vb.h - 19 * k, g = '<g class="d2-legenda-reforma" data-d2-conv="reforma">';
    g += txt(x0, y0, 2.6 * k, "LEGENDA", "d2-leg-tit");
    [["novo", "A CONSTRUIR"], ["demolido", "A DEMOLIR"], ["existente", "EXISTENTE A MANTER"]].forEach(function (it, i) {
      var c = conv[it[0]], y = y0 + 3 * k + i * 5.4 * k, w = 14 * k, h = 3.6 * k;
      g += '<rect x="' + n4(x0) + '" y="' + n4(y) + '" width="' + n4(w) + '" height="' + n4(h) + '" fill="' + (it[0] === "novo" ? "url(#d2-hach-n)" : c.fill) + '" stroke="' + c.cor + '" style="stroke:' + c.cor + '"' +
        (c.tracejado ? tracoK(c.tracejado, k) : "") + ' stroke-width="' + pena.vista + '" ' + NS + ' data-d2-conv-item="' + it[0] + '"/>';
      g += txt(x0 + w + 3 * k, y + h * 0.75, 2.4 * k, esc(it[1]), "d2-leg-tx");
    });
    return g + "</g>";
  }

  /* ---------------------------------------------------- PORTAS
   * d.portas = [{ folhas:[[[x,y]×4]], arcos:[{ c, r, de, ate }], linhas:[[x1,y1,x2,y2]], k? }]
   * (BIM.vista2d, gerado pelo js/simboloporta.js). FOLHA na pena de marca
   * (média), ARCO e seta na pena de vista (fina, projeção) — NBR 8403. O
   * arco sai como o comando A do SVG; o sentido (sweep) vem do produto
   * vetorial (de − c) × (ate − c), então o desenho espelhado continua certo.
   * Com os estilos de objeto (P6): a pena de projeção da categoria no arco e
   * uma acima na folha. As classes levam d2-vista: o DXF (js/bimdxf.js) pula
   * este grupo e desenha a porta pelos DADOS (ARC de verdade). */
  function pontosPorta(sp) {
    var o = [];
    if (!sp) return o;
    (sp.folhas || []).forEach(function (f) { (f || []).forEach(function (q) { o.push(q); }); });
    (sp.arcos || []).forEach(function (a) {
      if (!a || !a.c || !a.de || !a.ate) return;
      o.push(a.de, a.ate);
      var mx = (a.de[0] + a.ate[0]) / 2 - a.c[0], my = (a.de[1] + a.ate[1]) / 2 - a.c[1], L = Math.sqrt(mx * mx + my * my) || 1;
      o.push([a.c[0] + mx / L * a.r, a.c[1] + my / L * a.r]);
    });
    (sp.linhas || []).forEach(function (l) { o.push([l[0], l[1]], [l[2], l[3]]); });
    return o;
  }
  function arcoPorta(a) {
    if (!a || !(a.r > 0) || !a.c || !a.de || !a.ate) return "";
    var cr = (a.de[0] - a.c[0]) * (a.ate[1] - a.c[1]) - (a.de[1] - a.c[1]) * (a.ate[0] - a.c[0]);
    return "M" + n4(a.de[0]) + " " + n4(a.de[1]) + "A" + n4(a.r) + " " + n4(a.r) + " 0 0 " + (cr > 0 ? 1 : 0) + " " + n4(a.ate[0]) + " " + n4(a.ate[1]);
  }
  function svgPortas(lista, e, pena, p6) {
    var gr = {}, s = "";
    lista.forEach(function (sp) {
      if (!sp) return;
      var key = p6 ? (sp.k || "_") : "_", q = gr[key] || (gr[key] = { f: "", g: "" });
      (sp.folhas || []).forEach(function (f) { q.f += caminho(f, true); });
      (sp.arcos || []).forEach(function (a) { q.g += arcoPorta(a); });
      (sp.linhas || []).forEach(function (l) { q.g += "M" + n4(l[0]) + " " + n4(l[1]) + "L" + n4(l[2]) + " " + n4(l[3]); });
    });
    Object.keys(gr).sort().forEach(function (key) {
      var q = gr[key], wf = pena.marca, wg = pena.vista, aF = "", aG = "";
      if (p6) {
        var est = p6.estilos || {}, st = est[key] || est._ || { proj: 2, cor: "#000000" };
        if (st.visivel === false) return;
        var pj = Math.max(1, Math.min(16, Math.round(+st.proj) || 2)), mmG = p6PenaEf(p6.penas, pj, e), mmF = p6PenaEf(p6.penas, Math.min(16, pj + 1), e);
        wg = p6Px(mmG, p6.penas); wf = p6Px(mmF, p6.penas);
        aG = ' data-cat="' + esc(key) + '" data-mm="' + mmG + '" style="stroke:' + p6Cor(st) + '"';
        aF = ' data-cat="' + esc(key) + '" data-mm="' + mmF + '" style="stroke:' + p6Cor(st) + '"';
      }
      if (q.f) s += '<path d="' + q.f + '" fill="none" class="d2-vista d2-porta-folha"' + aF + ' stroke-width="' + wf + '" ' + NS + "/>";
      if (q.g) s += '<path d="' + q.g + '" fill="none" class="d2-vista d2-porta-giro"' + aG + ' stroke-width="' + wg + '" ' + NS + "/>";
    });
    return s ? '<g class="d2-porta">' + s + "</g>" : "";
  }

  /* ---------------------------------------------------- AMBIENTES (P2-D)
   * d.ambientes = { itens: [{ id, pts:[[x,y]], furos:[[[x,y]]], cor, token,
   *   linha1, linha2, aviso, x, y, sel }], legenda: { titulo, itens:[{rotulo, cor, token}] } }
   * (montado por js/bimambienteui.js). A cor vai em hex e, por cima, o token
   * do tema (--d2-amb-N): no papel escuro do tema escuro vale o tom escuro. */
  function fillCor(it) {
    var h = corOk(it.cor);
    return 'fill="' + h + '"' + (/^--[\w-]+$/.test(String(it.token || "")) ? ' style="fill:var(' + it.token + "," + h + ')"' : "");
  }
  function caminhoAmb(it) { var dd = caminho(it.pts, true); (it.furos || []).forEach(function (f) { dd += caminho(f, true); }); return dd; }
  function svgAmbCores(amb) {
    var s = "";
    (amb.itens || []).forEach(function (it) {
      if (!it.cor || !it.pts || it.pts.length < 3) return;
      s += '<path d="' + caminhoAmb(it) + '" ' + fillCor(it) + ' fill-rule="evenodd" class="d2-amb-cor" data-d2-amb-cor="' + esc(it.id) + '"/>';
    });
    return s ? '<g class="d2-amb-cores">' + s + "</g>" : "";
  }
  /* o identificador de ambiente: o NOME em cima e "número · área" embaixo, no
     ponto do ambiente; ambiente não delimitado/redundante leva o aviso no
     lugar da área. O retângulo transparente é o alvo do clique (seleciona). */
  function svgAmbTags(amb, e, pena) {
    var k = e.escala / 1000, s = "", sp = "";
    /* as linhas de separação de ambiente: finas */
    (amb.separadores || []).forEach(function (l) { sp += "M" + n4(l[0]) + " " + n4(l[1]) + "L" + n4(l[2]) + " " + n4(l[3]); });
    if (sp) s += '<path d="' + sp + '" class="d2-amb-sep" fill="none" stroke-width="' + pena.vista + '" ' + NS + "/>";
    (amb.itens || []).forEach(function (it) {
      if (it.sel && it.pts && it.pts.length >= 3)
        s += '<path d="' + caminhoAmb(it) + '" fill="none" class="d2-amb-sel-l" stroke-width="' + n4(pena.marca * 1.6) + '" ' + NS + tracoK([3, 1.5], k) + "/>";
      if (!e.identAmbiente || !isFinite(it.x) || !isFinite(it.y)) return;
      var h1 = 3 * k, h2 = 2.5 * k, l1 = String(it.linha1 || ""), l2 = String(it.linha2 || "");
      var w = Math.max(l1.length * h1 * 0.6, l2.length * h2 * 0.58, 8 * k);
      s += '<g class="d2-amb-tag' + (it.sel ? " d2-amb-sel" : "") + (it.aviso ? " d2-amb-aviso" : "") + '" data-d2-amb="' + esc(it.id) + '">' +
        '<rect x="' + n4(it.x - w / 2 - k) + '" y="' + n4(it.y - h1 - 1.2 * k) + '" width="' + n4(w + 2 * k) + '" height="' + n4(h1 + h2 + 3.4 * k) + '" class="d2-amb-alvo"/>' +
        txt(it.x, it.y - 0.4 * k, h1, esc(l1), "d2-amb-tx d2-amb-nome", "middle") +
        txt(it.x, it.y + h2 + 0.6 * k, h2, esc(l2), "d2-amb-tx d2-amb-num" + (it.aviso ? " d2-amb-av" : ""), "middle") + "</g>";
    });
    return s ? '<g class="d2-ambientes">' + s + "</g>" : "";
  }
  /* ---------------------------------------------------- PAGINAÇÃO (no ambiente)
   * d.ambientes.paginacao = {
   *   pisos:   [{ id, pecas:[{pts:[[x,y]], t:"i"|"r"|"b"}], partida:[x,y], velha, aviso:[x,y] }],
   *   paredes: [{ id, a:[x,y], b:[x,y], marcas:[[x0,y0,x1,y1]], velha }] }
   * (montado por js/bimpaginacaoui.js). Peça inteira: só a junta; recorte: o tom
   * claro; recorte fino (bolacha): o tom de alerta. Desatualizada: junta tracejada
   * na cor de alerta e o recado no ambiente — nunca peça fora do contorno (as peças
   * já vêm recortadas pelo contorno de agora). */
  function svgPaginacao(pg, e, pena) {
    var k = e.escala / 1000, s = "", lj = n4(pena.vista * 0.7);
    (pg.pisos || []).forEach(function (P) {
      var dI = "", dR = "", dB = "";
      (P.pecas || []).forEach(function (q) {
        if (!q || !q.pts || q.pts.length < 3) return;
        var dd = caminho(q.pts, true);
        if (q.t === "b") dB += dd; else if (q.t === "r") dR += dd; else dI += dd;
      });
      var g = '<g class="d2-pag' + (P.velha ? " d2-pag-velha" : "") + '" data-d2-pag="' + esc(P.id) + '" data-d2-pag-n="' + (P.pecas || []).length + '">';
      if (dR) g += '<path d="' + dR + '" class="d2-pag-rec"/>';
      if (dB) g += '<path d="' + dB + '" class="d2-pag-bol"/>';
      if (dI + dR + dB) g += '<path d="' + dI + dR + dB + '" fill="none" class="d2-pag-pc" stroke-width="' + lj + '" ' + NS + (P.velha ? tracoK([1.2, 0.8], k) : "") + "/>";
      if (P.partida && isFinite(P.partida[0]) && isFinite(P.partida[1])) {
        var x = P.partida[0], y = P.partida[1], r = 1.4 * k;
        g += '<g class="d2-pag-part" data-d2-pag-part="1"><circle cx="' + n4(x) + '" cy="' + n4(y) + '" r="' + n4(r) + '" fill="none" stroke-width="' + n4(pena.marca || pena.vista) + '" ' + NS + "/>" +
             '<path d="M' + n4(x - 2 * r) + " " + n4(y) + "L" + n4(x + 2 * r) + " " + n4(y) + "M" + n4(x) + " " + n4(y - 2 * r) + "L" + n4(x) + " " + n4(y + 2 * r) + '" fill="none" stroke-width="' + n4(pena.vista) + '" ' + NS + "/></g>";
      }
      /* em duas linhas: numa só o recado passava por cima da parede no cômodo estreito */
      if (P.velha && P.aviso && isFinite(P.aviso[0]) && isFinite(P.aviso[1]))
        g += txt(P.aviso[0], P.aviso[1] + 7.5 * k, 2.2 * k, esc("PAGINAÇÃO DESATUALIZADA"), "d2-pag-aviso", "middle") +
             txt(P.aviso[0], P.aviso[1] + 10.5 * k, 2.2 * k, esc("— REPAGINAR"), "d2-pag-aviso", "middle");
      s += g + "</g>";
    });
    (pg.paredes || []).forEach(function (W) {
      if (!W || !W.a || !W.b) return;
      var dd = "M" + n4(W.a[0]) + " " + n4(W.a[1]) + "L" + n4(W.b[0]) + " " + n4(W.b[1]);
      (W.marcas || []).forEach(function (m) { dd += "M" + n4(m[0]) + " " + n4(m[1]) + "L" + n4(m[2]) + " " + n4(m[3]); });
      s += '<g class="d2-pag-par' + (W.velha ? " d2-pag-velha" : "") + '" data-d2-pag-par="' + esc(W.id) + '"><path d="' + dd + '" fill="none" class="d2-pag-rev" stroke-width="' + n4(pena.vista) + '" ' + NS + (W.velha ? tracoK([1.2, 0.8], k) : "") + "/></g>";
    });
    return s ? '<g class="d2-paginacao">' + s + "</g>" : "";
  }
  function svgAmbLegenda(leg, x, y, k, pena) {
    var s = txt(x, y + 3 * k, 2.8 * k, esc(String(leg.titulo || "").toUpperCase()), "d2-amb-leg-tit");
    leg.itens.forEach(function (it, i) {
      var yy = y + 7 * k + i * 6 * k;
      s += '<rect x="' + n4(x) + '" y="' + n4(yy) + '" width="' + n4(8 * k) + '" height="' + n4(4.2 * k) + '" ' + fillCor(it) + ' stroke-width="' + pena.cota + '" ' + NS + ' class="d2-amb-leg-cor"/>';
      s += txt(x + 10 * k, yy + 3.3 * k, 2.4 * k, esc(it.rotulo), "d2-amb-leg-tx");
    });
    return '<g class="d2-amb-legenda">' + s + "</g>";
  }

  function corOk(c) { return /^#[0-9a-fA-F]{3,8}$/.test(String(c || "")) ? c : "#333333"; }
  /* PARIDADE (18/10/2026): a planta ALTO das instalações é a vista ortográfica da própria cena 3D (js/biminstsombra.js):
     uma imagem sombreada por elemento, na moldura do eixo dele (rotate), por baixo das arestas em vetor. O PDF/DXF
     levam as arestas (vetor); a imagem é da tela e da folha impressa por imagem. */
  function svgInstImagens(lista, clip) {
    var s = "";
    (lista || []).forEach(function (im) {
      if (!im || !im.href) return;
      s += '<image href="' + esc(im.href) + '" x="' + n4(im.x) + '" y="' + n4(im.y) + '" width="' + n4(im.w) + '" height="' + n4(im.h) + '" preserveAspectRatio="none"' +
        (Math.abs(+im.ang || 0) > 1e-6 ? ' transform="rotate(' + n4(+im.ang) + ')"' : "") + (im.u ? ' data-d2-inst-img="' + esc(im.u) + '"' : "") + "/>";
    });
    if (!s) return "";
    if (clip) {   /* o recorte da vista corta a imagem na borda (como corta o vetor) */
      var cid = "d2ic" + (++svgInstImagens.n);
      return '<defs><clipPath id="' + cid + '"><rect x="' + n4(clip[0]) + '" y="' + n4(clip[1]) + '" width="' + n4(clip[2] - clip[0]) + '" height="' + n4(clip[3] - clip[1]) + '"/></clipPath></defs>' +
        '<g class="d2-inst-img" clip-path="url(#' + cid + ')">' + s + "</g>";
    }
    return '<g class="d2-inst-img">' + s + "</g>";
  }
  svgInstImagens.n = 0;
  function svgInst(ins, k, pena) {
    var s = '<g class="d2-inst">';
    (ins.linhas || []).forEach(function (l) {
      var q = l.seg || [];
      s += '<line x1="' + n4(q[0]) + '" y1="' + n4(q[1]) + '" x2="' + n4(q[2]) + '" y2="' + n4(q[3]) + '" stroke="' + corOk(l.cor) + '" stroke-width="' + n4(l.chamada ? pena.vista * 0.7 : pena.corte * 0.8) + '" ' + NS +   /* linha de chamada de rótulo: fina */
        (l.tracejado ? tracoK([3, 1.5], k) : "") + (l.chamada ? ' data-d2-chamada="1"' : "") + ' data-d2-inst="' + esc(l.id) + '"/>';   /* JUNÇÃO 18/10/2026: a chamada se distingue do traço de instalação */
    });
    (ins.simbolos || []).forEach(function (m) {
      var cor = corOk(m.cor), r = Math.max(+m.r || 0, 0.6 * k);
      if (m.tipo === "caixa") s += '<rect x="' + n4(m.x - r) + '" y="' + n4(m.y - r) + '" width="' + n4(2 * r) + '" height="' + n4(2 * r) + '" fill="none" stroke="' + cor + '" stroke-width="' + pena.vista + '" ' + NS + ' data-d2-inst="' + esc(m.id) + '"/>';
      else s += '<circle cx="' + n4(m.x) + '" cy="' + n4(m.y) + '" r="' + n4(r) + '" fill="' + (m.tipo === "conexao" ? cor : "none") + '" stroke="' + cor + '" stroke-width="' + pena.vista + '" ' + NS + ' data-d2-inst="' + esc(m.id) + '"/>';
    });
    (ins.textos || []).forEach(function (t) {
      var h = 1.8 * k, sc = h / 100;
      s += '<text x="0" y="0" font-size="100" text-anchor="middle" fill="' + corOk(t.cor) + '" class="d2-inst-tx" transform="translate(' + n4(t.x) + " " + n4(t.y - 0.6 * k) + ") rotate(" + n4(+t.rot || 0) + ") scale(" + n4(sc) + ')">' + esc(t.t) + "</text>";
    });
    return s + "</g>";
  }

  /* escala que cabe numa folha A1 (≈ 800 × 560 mm úteis), nunca maior que 1:50 */
  function escalaQueCabe(larguraM, alturaM) {
    var precisa = Math.max(larguraM * 1000 / 800, alturaM * 1000 / 560);
    for (var i = 0; i < ESCALAS.length; i++) if (ESCALAS[i] >= 50 && ESCALAS[i] >= precisa) return ESCALAS[i];
    return ESCALAS[ESCALAS.length - 1];
  }

  /* letra do próximo corte: A, B, … Z, AA, AB … (pula as já usadas) */
  function proximaLetra(usadas) {
    var u = {}; (usadas || []).forEach(function (x) { u[String(x).toUpperCase()] = 1; });
    for (var i = 0; i < 702; i++) {
      var s = i < 26 ? String.fromCharCode(65 + i) : String.fromCharCode(64 + Math.floor(i / 26)) + String.fromCharCode(65 + (i % 26));
      if (!u[s]) return s;
    }
    return "?";
  }

  /* =====================================================================
   * P6 — ESTILOS DE OBJETO, PENAS E PADRÕES RA (Frente A do plano do
   * BIM, seção 3.3). Só DESENHA: quem decide a categoria de
   * cada contorno/aresta, o V/G e o meio-tom é o js/bimmodelovista.js, que
   * entrega `extra.p6` = { escala, nivelDetalhe, penas (data/penas-ra.json),
   * padroes (padroesLinha), preenchimentos, estilos: { chave: { proj, corte
   * (índice da pena 1–16), cor, padrao, preench, meioTom, visivel } } } e o
   * desenho com `cortes[i].k` e `linhasK[i]` (a chave de estilo).
   * PENA: mm de PAPEL pela tabela da escala; na tela, px = mm × 96/25,4
   * (vector-effect: a linha não engorda com o zoom) e o mm vai em `data-mm`
   * para o PDF/DXF. PADRÃO de linha e PREENCHIMENTO em mm de papel → metros
   * do desenho (× escala/1000): trocar a escala muda o traço, como no papel.
   * ===================================================================== */
  var P6_PX_MM = 96 / 25.4;
  function p6ColunaEscala(penas, escala) {
    var ks = (penas && penas.escalas) || [], best = null, bd = Infinity;
    ks.forEach(function (s) { var dd = Math.abs(Math.log(s) - Math.log(escala)); if (dd < bd - 1e-12) { bd = dd; best = s; } });
    return best;
  }
  function p6PenaMm(penas, n, escala) {
    var col = p6ColunaEscala(penas, escala), t = penas && penas.tabela && penas.tabela[String(col)];
    n = Math.max(1, Math.min(16, Math.round(+n) || 1));
    return t && t[n - 1] != null ? t[n - 1] : 0.25;
  }
  /* a pena EFETIVA da vista: a do estilo de objeto × o fator de "Espessura das linhas" */
  function p6PenaEf(penas, n, e) {
    var mm = p6PenaMm(penas, n, e.escala), f = fatorPena(e.pena);
    return f === 1 ? mm : Math.round(mm * f * 10000) / 10000;
  }
  function p6Px(mm, penas) {
    var px = mm * ((penas && penas.pxPorMm) || P6_PX_MM), min = (penas && penas.pxMinimo) || 0.5;
    return Math.round(Math.max(min, px) * 1000) / 1000;
  }
  function p6Traco(padroes, id, escala) {
    var pd = padroes && padroes[id]; if (!pd || !pd.mm || !pd.mm.length) return "";
    var k = escala / 1000;
    return pd.mm.map(function (v) { return n4(Math.max(0.0001, Math.abs(+v) * k)); }).join(" ");
  }
  var P6_TINTA = "var(--d2-tinta,#111111)", P6_MEIO = "var(--d2-meiotom,#9aa0a6)";
  function p6Cor(s) { return s.meioTom ? P6_MEIO : (s.cor && String(s.cor).toLowerCase() !== "#000000" ? corOk(s.cor) : P6_TINTA); }
  function p6Padrao(id, pr, k, mt, corMat) {
    if (!pr || pr.tipo !== "padrao" || !(pr.w > 0) || !(pr.h > 0)) return "";
    var cor = mt ? P6_MEIO : (corMat ? corOk(corMat) : P6_TINTA), okD = /^[MmLlHhVvCcSsQqTtAaZz0-9.,\s-]*$/;   /* MATERIAIS: a cor do padrão do material do projeto */
    var tr = okD.test(pr.traco || "") ? pr.traco : "", ch = okD.test(pr.cheio || "") ? pr.cheio : "";
    return '<pattern id="d2p6-' + esc(id) + (mt ? "-mt" : "") + (corMat && !mt ? "-c" + esc(String(corMat).replace("#", "")) : "") + '" patternUnits="userSpaceOnUse" width="' + n4(pr.w * k) + '" height="' + n4(pr.h * k) + '"' +
      (pr.rot ? ' patternTransform="rotate(' + (+pr.rot || 0) + ')"' : "") + '><g transform="scale(' + (Math.round(k * 1e7) / 1e7) + ')">' +
      (tr ? '<path d="' + tr + '" fill="none" stroke-width="' + (+pr.espessura || 0.09) + '" style="stroke:' + cor + '"/>' : "") +
      (ch ? '<path d="' + ch + '" style="fill:' + cor + '"/>' : "") + "</g></pattern>";
  }
  /* o corpo do desenho (o que se VÊ e o que é CORTADO) agrupado por chave de estilo */
  function p6Corpo(d, e, p6) {
    var k = e.escala / 1000, est = p6.estilos || {}, penas = p6.penas, gL = {}, gF = {}, gA = {}, usados = {}, defs = "";
    function st(key) { return est[key] || est._ || { proj: 2, corte: 3, cor: "#000000", padrao: "continua", preench: "vazio" }; }
    (d.linhas || []).forEach(function (l, i) {
      var key = (d.linhasK && d.linhasK[i]) || "_";
      gL[key] = (gL[key] || "") + "M" + n4(l[0]) + " " + n4(l[1]) + "L" + n4(l[2]) + " " + n4(l[3]);
    });
    (d.cortes || []).forEach(function (c) {
      var key = c.k || "_";
      if (c.fechado) gF[key] = (gF[key] || "") + caminho(c.pts, true, c.arcos); else gA[key] = (gA[key] || "") + caminho(c.pts, false, c.arcos);   /* CURVA: c.arcos */
    });
    var corpo = "";
    function linhaP6(key) {
      var s = st(key); if (s.visivel === false || !gL[key]) return;
      var mm = p6PenaEf(penas, s.proj, e), tr = p6Traco(p6.padroes, s.padrao, e.escala), pdT = p6.padroes && p6.padroes[s.padrao];
      corpo += '<path d="' + gL[key] + '" class="d2-vista d2-p6-l" data-cat="' + esc(key) + '" data-mm="' + mm + '" stroke-width="' + p6Px(mm, penas) + '" ' + NS +
        (tr ? tracoAttr(pdT.mm, tr) : "") + ' style="stroke:' + p6Cor(s) + '"/>';
    }
    /* NÍVEL DE DETALHE (js/biminstnivel.js): a linha UNIFILAR das instalações (chave "|inst:") sai DEPOIS do corte —
       o tubo embutido na parede aparece por cima da hachura, como na prancha hidrossanitária */
    var ehInst = function (key) { return key.indexOf("|inst:") >= 0; };
    Object.keys(gL).sort().forEach(function (key) { if (!ehInst(key)) linhaP6(key); });
    var chC = {}, imgFeita = !(d.instImagens && d.instImagens.length); Object.keys(gF).concat(Object.keys(gA)).forEach(function (x) { chC[x] = 1; });
    /* o corte da instalação depois do da arquitetura (o tubo embutido não some debaixo da hachura da parede) */
    /* entre os de instalação, a ORDEM da apresentação vai depois de "|inst:" (p1 tubo, p2 conexão/caixa, p3 prumada) — o
       branco da conexão cobre a ponta do tubo e a prumada fica por cima da junção */
    var sufI = function (x) { var i = x.indexOf("|inst:"); return i >= 0 ? x.slice(i + 6) : x; };
    Object.keys(chC).sort(function (a, b) { var ia = ehInst(a) ? 1 : 0, ib = ehInst(b) ? 1 : 0; if (ia !== ib) return ia - ib; var sa = sufI(a), sb = sufI(b); return sa < sb ? -1 : sa > sb ? 1 : (a < b ? -1 : a > b ? 1 : 0); }).forEach(function (key) {
      if (!imgFeita && ehInst(key)) { imgFeita = true; corpo += svgInstImagens(d.instImagens, d.instClip); }   /* PARIDADE: a vista da cena por baixo do vetor */
      var s = st(key); if (s.visivel === false) return;
      if (s.oculto) {   /* PARIDADE: a forma 2D antiga fica só como ALVO DO CLIQUE no Alto (a cena desenha) */
        if (gF[key]) corpo += '<path d="' + gF[key] + '" fill="#000" fill-opacity="0" stroke="none" class="d2-p6-alvo" data-cat="' + esc(key) + '"/>';
        return;
      }
      var mm = p6PenaEf(penas, s.corte, e), w = p6Px(mm, penas), cor = p6Cor(s);
      var pr = (p6.preenchimentos || {})[s.preench], fill = "none";
      /* CORES POR CATEGORIA: o preenchimento da categoria (corCat) aparece também no nível de detalhe baixo — é o que a pessoa pediu para ver */
      if ((p6.nivelDetalhe !== "baixo" || s.corCat) && pr) {
        if (pr.tipo === "solido") fill = s.meioTom ? "#cfd3d8" : corOk(s.corPreench || pr.cor);   /* MATERIAIS: corPreench = a cor do padrão do material do projeto */
        else if (pr.tipo === "padrao") {
          var pid = String(s.preench) + (s.meioTom ? "-mt" : (s.corPreench ? "-c" + String(s.corPreench).replace("#", "") : ""));
          if (!usados[pid]) { usados[pid] = 1; defs += p6Padrao(s.preench, pr, k, !!s.meioTom, s.corPreench); }
          fill = "url(#d2p6-" + esc(pid) + ")";
        }
      }
      if (gF[key]) corpo += '<path d="' + gF[key] + '" fill="' + fill + '" fill-rule="evenodd" class="d2-corte d2-p6-c" data-cat="' + esc(key) + '" data-mm="' + mm + '" stroke-width="' + w + '" ' + NS + ' style="stroke:' + cor + '"/>';
      if (gA[key]) corpo += '<path d="' + gA[key] + '" fill="none" class="d2-corte d2-p6-c" data-cat="' + esc(key) + '" data-mm="' + mm + '" stroke-width="' + w + '" ' + NS + ' style="stroke:' + cor + '"/>';
    });
    if (!imgFeita) { imgFeita = true; corpo += svgInstImagens(d.instImagens, d.instClip); }
    Object.keys(gL).sort(function (a, b) { var sa = sufI(a), sb = sufI(b); return sa < sb ? -1 : sa > sb ? 1 : 0; }).forEach(function (key) { if (ehInst(key)) linhaP6(key); });
    return { defs: defs, corpo: '<g class="d2-p6">' + corpo + "</g>" };
  }
  /* marcas das vistas P6 na vista-mãe: ELEVAÇÃO (círculo + seta para onde se olha),
     CHAMADA DE DETALHE (retângulo de cantos redondos + bolha com o número), CORTE
     (a marca de sempre) e a REGIÃO DE RECORTE visível. Clicar abre a vista. */
  function p6MarcaElev(m, k, pena) {
    var R = 4 * k, cx = +m.x, cy = +m.y, dx = +(m.dir && m.dir[0]) || 0, dy = +(m.dir && m.dir[1]) || 1, L = Math.sqrt(dx * dx + dy * dy) || 1; dx /= L; dy /= L;
    var px = -dy, py = dx, tip = [cx + dx * R * 1.75, cy + dy * R * 1.75], b1 = [cx + px * R * 0.98 + dx * R * 0.2, cy + py * R * 0.98 + dy * R * 0.2], b2 = [cx - px * R * 0.98 + dx * R * 0.2, cy - py * R * 0.98 + dy * R * 0.2];
    return '<g class="d2-p6-elev" data-d2-vista="' + esc(m.id) + '">' +
      '<path d="M' + n4(b1[0]) + " " + n4(b1[1]) + "L" + n4(tip[0]) + " " + n4(tip[1]) + "L" + n4(b2[0]) + " " + n4(b2[1]) + 'Z" class="d2-marca-seta"/>' +
      '<circle cx="' + n4(cx) + '" cy="' + n4(cy) + '" r="' + n4(R) + '" stroke-width="' + pena.marca + '" ' + NS + ' class="d2-marca-circ"/>' +
      txt(cx, cy + 1.1 * k, 3 * k, esc(m.rotulo || ""), "d2-marca-tx", "middle") + "</g>";
  }
  function p6MarcaChamada(m, k, pena) {
    var x0 = Math.min(m.x0, m.x1), x1 = Math.max(m.x0, m.x1), y0 = Math.min(m.y0, m.y1), y1 = Math.max(m.y0, m.y1), r = Math.min(2.5 * k, (x1 - x0) / 4, (y1 - y0) / 4), R = 3.5 * k;
    var bx = x1 + 7 * k, by = y0 - 7 * k;
    return '<g class="d2-p6-chamada" data-d2-vista="' + esc(m.id) + '">' +
      '<rect x="' + n4(x0) + '" y="' + n4(y0) + '" width="' + n4(x1 - x0) + '" height="' + n4(y1 - y0) + '" rx="' + n4(r) + '" ry="' + n4(r) + '" fill="none" stroke-width="' + pena.marca + '" ' + NS + ' class="d2-p6-chamada-l"/>' +
      '<line x1="' + n4(x1) + '" y1="' + n4(y0) + '" x2="' + n4(bx - R * 0.7071) + '" y2="' + n4(by + R * 0.7071) + '" stroke-width="' + pena.cota + '" ' + NS + ' class="d2-p6-chamada-l"/>' +
      '<circle cx="' + n4(bx) + '" cy="' + n4(by) + '" r="' + n4(R) + '" stroke-width="' + pena.marca + '" ' + NS + ' class="d2-marca-circ"/>' +
      txt(bx, by + 1.0 * k, 2.8 * k, esc(m.rotulo || ""), "d2-marca-tx", "middle") + "</g>";
  }
  function p6Marcas(lista, e, pena) {
    var k = e.escala / 1000, s = "";
    (lista || []).forEach(function (m) {
      if (!m) return;
      if (m.tipo === "elevacao") s += p6MarcaElev(m, k, pena);
      else if (m.tipo === "chamada") s += p6MarcaChamada(m, k, pena);
      else if (m.tipo === "corte" && m.a && m.b) s += svgMarcaCorte(m, e, pena).replace('data-d2-corte="', 'data-d2-vista="');
      else if (m.tipo === "recorte") s += '<rect x="' + n4(Math.min(m.x0, m.x1)) + '" y="' + n4(Math.min(m.y0, m.y1)) + '" width="' + n4(Math.abs(m.x1 - m.x0)) + '" height="' + n4(Math.abs(m.y1 - m.y0)) +
        '" fill="none" stroke-width="' + pena.cota + '" ' + NS + tracoK([4, 1.5], k) + ' class="d2-p6-recorte"/>';
    });
    return '<g class="d2-p6-marcas">' + s + "</g>";
  }
  function p6Caixa(lista, vb, k) {
    var q = { x0: vb.x, y0: vb.y, x1: vb.x + vb.w, y1: vb.y + vb.h }, M = 9 * k;
    function pt(x, y, m) { if (!isFinite(x) || !isFinite(y)) return; if (x - m < q.x0) q.x0 = x - m; if (x + m > q.x1) q.x1 = x + m; if (y - m < q.y0) q.y0 = y - m; if (y + m > q.y1) q.y1 = y + m; }
    (lista || []).forEach(function (m) {
      if (!m) return;
      if (m.tipo === "elevacao") pt(+m.x, +m.y, M);
      else if (m.tipo === "chamada") { pt(Math.max(m.x0, m.x1) + 7 * k, Math.min(m.y0, m.y1) - 7 * k, 5 * k); pt(m.x0, m.y0, 0); pt(m.x1, m.y1, 0); }
      else if (m.tipo === "corte" && m.a && m.b) { pt(m.a[0], m.a[1], M); pt(m.b[0], m.b[1], M); }
      else if (m.tipo === "recorte") { pt(m.x0, m.y0, k); pt(m.x1, m.y1, k); }
    });
    return { x: q.x0, y: q.y0, w: q.x1 - q.x0, h: q.y1 - q.y0 };
  }

  /* =====================================================================
   * ACIMA DO PLANO DE CORTE (14/10/2026) — pedido do Rogério: "quando eu
   * criar uma viga na planta baixa e ela estiver ACIMA do corte, mostra ela
   * com alguma visibilidade diferente, para a gente não ter que ficar subindo
   * para uma outra referência de nível".
   *
   * A planta é um corte horizontal: o que o plano atravessa sai CORTADO (pena
   * grossa), o que está abaixo sai VISTO (pena fina) e o que está ACIMA do
   * corte, até o topo da faixa (por padrão o nível de cima), sai em PROJEÇÃO:
   * contorno tracejado longo na pena fina, em cinza, com um rótulo discreto
   * ("V12 · fundo +2,60"). Representação:
   *   · traço: o padrão "projecao" de data/estilos-objeto-ra.json (6 / 1,5 mm
   *     de papel — a variação da linha tracejada E/F da NBR 8403 para o que
   *     está acima do corte; o traço maior que o da oculta, 3 / 1,5, é decisão
   *     RA para não confundir as duas);
   *   · pena: a de VISTA do jogo (0,18 mm no jogo médio = EST-OCULTA do Padrão
   *     RA de detalhamento, "arestas ocultas, projeções, vigas invertidas");
   *   · só PEÇA LINEAR (viga, perfil, pilar, escada, rampa, guarda-corpo; chapa
   *     e genérico só quando compridos): laje, forro e telhado do pavimento de
   *     cima não entram — a planta viraria um emaranhado tracejado;
   *   · o que atravessa o corte continua CORTADO (o pilar do pavimento).
   * Motor PURO: quem extrai a geometria é o BIM.vista2d (js/bim.js), quem
   * guarda a opção da vista é o js/bim2dui.js.
   * ===================================================================== */
  var ACIMA_TIPOS = { IFCBEAM: 1, IFCMEMBER: 1, IFCCOLUMN: 1, IFCSTAIR: 1, IFCSTAIRFLIGHT: 1, IFCRAMP: 1, IFCRAMPFLIGHT: 1, IFCRAILING: 1 };
  var ACIMA_COMPRIDOS = { IFCPLATE: 1, IFCBUILDINGELEMENTPROXY: 1, IFCELEMENTASSEMBLY: 1, "": 1 };
  var ACIMA_MODOS = { nivel: "Até o nível de cima", altura: "Até uma altura do piso" };
  var ACIMA_ROTULOS = { fundo: "Marca · fundo", topo: "Marca · topo", ambos: "Marca · fundo e topo", nenhum: "Sem rótulo" };
  var ACIMA_TRACO_MM = [6, 1.5], ACIMA_TEXTO_MM = 2, ACIMA_COR = "#6b7480", ACIMA_PENA_RA = 3;   /* pena 3 da tabela RA = 0,18 mm a 1:50 */
  /* na TELA o traço vai em px (tracoK: 6 / 1,5 mm → 10 / 2,5 px); no papel, 6 / 1,5 mm na escala (data-traco) */
  var ACIMA_TRACO_PX = [10, 2.5];
  var ACIMA_PADRAO_ALTURA = 3;   /* último nível (sem nível de cima): 3 m acima do piso */
  function acimaCfg(c) {
    c = c || {};
    var alt = +c.altura;
    return { on: c.on !== false && c.on !== "false" && c.on !== 0,
             modo: ACIMA_MODOS[c.modo] ? c.modo : "nivel",
             altura: isFinite(alt) && alt > 0 ? Math.max(0.2, Math.min(50, Math.round(alt * 1000) / 1000)) : ACIMA_PADRAO_ALTURA,
             rotulo: ACIMA_ROTULOS[c.rotulo] ? c.rotulo : "fundo" };
  }
  /* o TOPO da faixa acima do corte, em cota de MUNDO; null = não mostra.
     niveis = [{ y }] (cota do piso de cada nível) */
  function acimaTopo(cfg, nivelY, yCorte, niveis) {
    var c = acimaCfg(cfg), t = null; if (!c.on) return null;
    nivelY = +nivelY || 0;
    if (c.modo === "altura") t = nivelY + c.altura;
    else {
      (niveis || []).forEach(function (n) { var y = n ? +n.y : NaN; if (isFinite(y) && y > nivelY + 0.05 && (t == null || y < t)) t = y; });
      if (t == null) t = nivelY + ACIMA_PADRAO_ALTURA;
    }
    return t > yCorte + 0.01 ? Math.round(t * 10000) / 10000 : null;
  }
  /* COMO a peça entra na planta (fundo/topo = cota de mundo): o mesmo critério do js/niveis.js —
     "cortado" (o plano atravessa), "abaixo" (visto), "acima" (projeção, até o topo da faixa), "fora" */
  function acimaClassificar(fundo, topo, yCorte, yTopo) {
    var tol = 0.005;
    if (fundo <= yCorte + tol && topo >= yCorte - tol) return "cortado";
    if (topo < yCorte) return "abaixo";
    if (yTopo != null && fundo < yTopo - tol) return "acima";
    return "fora";
  }
  /* entra no tracejado? tipo IFC da peça e o tamanho dela na planta (L × W, retângulo mínimo) */
  function acimaElegivel(tipo, L, W) {
    var t = String(tipo || "").toUpperCase();
    L = +L || 0; W = +W || 0;
    if (Math.max(L, W) < 0.05) return false;
    if (ACIMA_TIPOS[t]) return true;
    if (ACIMA_COMPRIDOS[t]) return t === "IFCPLATE" ? L >= 1.0 : (L >= 1.0 && L >= 3 * W);   /* chapa de ligação não; passarela sim */
    return false;
  }
  /* o TIPO pode entrar? (filtro barato antes de projetar a malha: mobiliário, luminária, laje… nem são lidos) */
  function acimaTipoPode(tipo) { var t = String(tipo || "").toUpperCase(); return !!(ACIMA_TIPOS[t] || ACIMA_COMPRIDOS[t]); }
  /* casco convexo (cadeia monótona); pontos [x, y] */
  function casco(pts) {
    var P = (pts || []).filter(function (q) { return q && isFinite(q[0]) && isFinite(q[1]); }).map(function (q) { return [q[0], q[1]]; });
    P.sort(function (a, b) { return a[0] - b[0] || a[1] - b[1]; });
    var U = [];
    P.forEach(function (q) { if (!U.length || Math.abs(U[U.length - 1][0] - q[0]) > 1e-9 || Math.abs(U[U.length - 1][1] - q[1]) > 1e-9) U.push(q); });
    if (U.length < 3) return U;
    function cr(o, a, b) { return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]); }
    var lo = [], hi = [];
    U.forEach(function (q) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], q) <= 1e-12) lo.pop(); lo.push(q); });
    for (var i = U.length - 1; i >= 0; i--) { var q = U[i]; while (hi.length >= 2 && cr(hi[hi.length - 2], hi[hi.length - 1], q) <= 1e-12) hi.pop(); hi.push(q); }
    lo.pop(); hi.pop();
    return lo.concat(hi);
  }
  function areaPol(pts) { var s = 0, n = (pts || []).length; for (var i = 0, j = n - 1; i < n; j = i++) s += (pts[j][0] + pts[i][0]) * (pts[j][1] - pts[i][1]); return Math.abs(s / 2); }
  /* o retângulo de menor área em volta do casco: eixo da peça (u ao longo do lado MAIOR), L, W e o centro */
  function retMin(h) {
    if (!h || !h.length) return null;
    if (h.length < 3) {
      var a0 = h[0], b0 = h[h.length - 1], dx = b0[0] - a0[0], dy = b0[1] - a0[1], L0 = Math.sqrt(dx * dx + dy * dy);
      return { cx: (a0[0] + b0[0]) / 2, cy: (a0[1] + b0[1]) / 2, ux: L0 > 1e-9 ? dx / L0 : 1, uy: L0 > 1e-9 ? dy / L0 : 0, L: L0, W: 0 };
    }
    var best = null;
    for (var i = 0; i < h.length; i++) {
      var p = h[i], q = h[(i + 1) % h.length], ex = q[0] - p[0], ey = q[1] - p[1], le = Math.sqrt(ex * ex + ey * ey);
      if (le < 1e-9) continue;
      var ux = ex / le, uy = ey / le, a = Infinity, b = -Infinity, c = Infinity, d = -Infinity;
      h.forEach(function (r) { var s = r[0] * ux + r[1] * uy, t = -r[0] * uy + r[1] * ux; if (s < a) a = s; if (s > b) b = s; if (t < c) c = t; if (t > d) d = t; });
      var A = (b - a) * (d - c);
      if (!best || A < best.A - 1e-12) best = { A: A, ux: ux, uy: uy, s: (a + b) / 2, t: (c + d) / 2, Ls: b - a, Lt: d - c };
    }
    if (!best) return null;
    var cx = best.s * best.ux - best.t * best.uy, cy = best.s * best.uy + best.t * best.ux;
    if (best.Lt > best.Ls) return { cx: cx, cy: cy, ux: -best.uy, uy: best.ux, L: best.Lt, W: best.Ls };
    return { cx: cx, cy: cy, ux: best.ux, uy: best.uy, L: best.Ls, W: best.Lt };
  }
  /* a PEÇA acima do corte para o desenho. o = { u, t (tipo IFC), pts (vértices projetados na planta),
     segs? (arestas projetadas [x1,y1,x2,y2] — contorno de peça NÃO convexa: viga curva, escada em L),
     areaBaixo? (área projetada das faces de baixo — compara com o casco), fundo, topo, marca }.
     → { u, t, pts (casco, fechado) | segs, eixo:{cx,cy,ux,uy,L,W}, fundo, topo, marca } ou null */
  function acimaPeca(o) {
    if (!o) return null;
    var h = casco(o.pts), ret = retMin(h); if (!ret) return null;
    /* o.forcar: a peça declarou que entra (a telha da cobertura do galpão — a projeção da cobertura, js/acovedacao.js) */
    if (o.forcar ? Math.max(ret.L, ret.W) < 0.05 : !acimaElegivel(o.t, ret.L, ret.W)) return null;
    var it = { u: String(o.u || ""), t: String(o.t || ""), eixo: { cx: n4(ret.cx), cy: n4(ret.cy), ux: n4(ret.ux), uy: n4(ret.uy), L: n4(ret.L), W: n4(ret.W) },
               fundo: Math.round((+o.fundo || 0) * 1000) / 1000, topo: Math.round((+o.topo || 0) * 1000) / 1000, marca: String(o.marca || "").slice(0, 24) };
    var aC = areaPol(h), aB = +o.areaBaixo || 0;
    /* casco muito maior que a peça (curva, L, U): vale o contorno pelas arestas */
    if (o.segs && o.segs.length && aB > 1e-6 && aC > aB * 1.15) it.segs = o.segs.map(function (s) { return [n4(s[0]), n4(s[1]), n4(s[2]), n4(s[3])]; });
    else it.pts = h.map(function (q) { return [n4(q[0]), n4(q[1])]; });
    return it;
  }
  function acimaTexto(it, modo) {
    var m = ACIMA_ROTULOS[modo] ? modo : "fundo"; if (m === "nenhum") return "";
    var p = [];
    if (it.marca) p.push(it.marca);
    if (m === "fundo" || m === "ambos") p.push("fundo " + fmtCota(+it.fundo || 0));
    if (m === "topo" || m === "ambos") p.push("topo " + fmtCota(+it.topo || 0));
    return p.join(" · ");
  }
  /* o tracejado de projeção + o rótulo; `p6` = os estilos de objeto (pena em mm no data-mm, para a folha) */
  /* a pena de PAPEL de vista de cada jogo (a mesma do js/prancha.js PENAS_PAPEL e do DXF): vai no data-mm, e a
     tela pode engrossar um pouco o cinza (o cinza fino a 0,9 px sumia na tela) sem mudar o papel */
  var ACIMA_PAPEL_MM = { fina: 0.13, media: 0.18, grossa: 0.25 };
  function svgAcima(lista, e, pena, modo, p6) {
    var k = e.escala / 1000, tr = tracoK(ACIMA_TRACO_MM, k), w = Math.round(pena.vista * 1.25 * 1000) / 1000, mm = ' data-mm="' + (ACIMA_PAPEL_MM[e.pena] || 0.18) + '"';
    if (p6 && p6.penas) { var mmP = p6PenaEf(p6.penas, ACIMA_PENA_RA, e); w = Math.max(p6Px(mmP, p6.penas), w); mm = ' data-mm="' + mmP + '"'; }
    var s = "", tx = "", h = ACIMA_TEXTO_MM * k;
    (lista || []).forEach(function (it) {
      if (!it) return;
      var dd = "";
      if (it.segs && it.segs.length) it.segs.forEach(function (q) { dd += "M" + n4(q[0]) + " " + n4(q[1]) + "L" + n4(q[2]) + " " + n4(q[3]); });
      else if (it.pts && it.pts.length >= 2) dd = caminho(it.pts, it.pts.length > 2);
      if (!dd) return;
      s += '<path d="' + dd + '" fill="none" stroke="' + (it.cor && /^#[0-9a-fA-F]{6}$/.test(it.cor) ? it.cor : ACIMA_COR) + '" class="d2-acima-l" data-d2-acima="' + esc(it.u) + '"' + mm + ' stroke-width="' + w + '" ' + NS + tr + (it.cor && /^#[0-9a-fA-F]{6}$/.test(it.cor) ? ' style="stroke:' + it.cor + '"' : "") + "/>";   /* CORES POR CATEGORIA: style inline, porque a classe do css vence o atributo stroke */
      var t = acimaTexto(it, modo), ex = it.eixo; if (!t || !ex) return;
      /* ao longo da peça, por baixo dela (nunca de cabeça para baixo) */
      var ang = Math.atan2(ex.uy, ex.ux) * 180 / Math.PI; if (ang > 90.001) ang -= 180; if (ang <= -89.999) ang += 180;
      var ra = ang * Math.PI / 180, ux = Math.cos(ra), uy = Math.sin(ra), nx = -uy, ny = ux, off = (+ex.W || 0) / 2 + 1.0 * k + h * 0.8;
      tx += txt(ex.cx + nx * off, ex.cy + ny * off, h, esc(t), "d2-acima-tx", "middle", Math.abs(ang) > 1e-6 ? n4(ang) : 0);
    });
    if (!s) return "";
    return '<g class="d2-acima">' + s + (tx ? '<g class="d2-acima-rot" fill="' + ACIMA_COR + '">' + tx + "</g>" : "") + "</g>";
  }
  var Acima = { TIPOS: ACIMA_TIPOS, MODOS: ACIMA_MODOS, ROTULOS: ACIMA_ROTULOS, TRACO_MM: ACIMA_TRACO_MM, TRACO_PX: ACIMA_TRACO_PX, TEXTO_MM: ACIMA_TEXTO_MM, PENA_RA: ACIMA_PENA_RA, COR: ACIMA_COR, PAPEL_MM: ACIMA_PAPEL_MM,
    cfg: acimaCfg, topo: acimaTopo, classificar: acimaClassificar, elegivel: acimaElegivel, tipoPode: acimaTipoPode, casco: casco, area: areaPol, retMin: retMin, peca: acimaPeca, texto: acimaTexto, svg: svgAcima };

  var Desenho2D = {
    FASE_SVG: FASE_SVG, Acima: Acima, TRACO_PX_POR_MM: TRACO_PX_POR_MM, tracoPx: tracoPx, tracoAttr: tracoAttr, tracoK: tracoK,
    PENAS: PENAS, FATOR_PENA: FATOR_PENA, fatorPena: fatorPena, CONVENCOES: CONVENCOES, CONV_REFORMA: CONV_REFORMA, PREENCHIMENTOS: PREENCHIMENTOS, MARCAS_COTA: MARCAS_COTA, UNIDADES: UNIDADES, ESCALAS: ESCALAS, ESQUEMAS: ESQUEMAS,
    estiloPadrao: estiloPadrao, normEstilo: normEstilo,
    fmtNum: fmtNum, fmtMedida: fmtMedida, fmtCota: fmtCota, agrupar: agrupar,
    caixa: caixa, cotas: cotasDe, svg: svg, pontosPorta: pontosPorta, arcoPorta: arcoPorta, proximaLetra: proximaLetra, escalaQueCabe: escalaQueCabe, cotaAlinhada: svgCotaAlinhada,
    /* P6 */
    P6: { colunaEscala: p6ColunaEscala, penaMm: p6PenaMm, penaEf: p6PenaEf, px: p6Px, traco: p6Traco, corpo: p6Corpo, marcas: p6Marcas, caixa: p6Caixa, padrao: p6Padrao }
  };
  global.Desenho2D = Desenho2D;
  if (typeof module !== "undefined" && module.exports) module.exports = Desenho2D;
})(typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this));
