﻿; =====================================================================
;  OrcaPRO BIM - instalador do PROGRAMA do BIM (Inno Setup 6), 14/11/2026
;
;  Compilar:
;    "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" /O<saida> OrcaPRO-BIM.iss
;
;  POR QUE E SEPARADO DO INSTALADOR DO ORCAPRO
;  Quem ja tem o OrcaPRO instalado so precisa do atalho do programa BIM:
;  baixar de novo os ~110 MB do pacote completo para ganhar um atalho nao
;  faz sentido. Este instalador poe o OrcaPRO-BIM.vbs e o icone NA PASTA DO
;  ORCAPRO JA INSTALADO e cria "OrcaPRO BIM" no Iniciar e na Area de
;  Trabalho. O BIM abre numa janela/processo proprio do navegador, direto
;  no 3D, sem disputar memoria com o resto do sistema.
;
;  ⚠ NAO desinstala nem toca no OrcaPRO: o desinstalador daqui remove so os
;  dois arquivos e os atalhos que ele mesmo criou.
; =====================================================================

#define NomeExib  "OrçaPRO BIM"
#define Publisher "RA Engenharia Especial"
#define Versao    "1.0.0"

[Setup]
AppId={{5C1E7A93-2F4B-4B8E-9D61-7A0B3C2E4F18}
AppName={#NomeExib}
AppVersion={#Versao}
AppPublisher={#Publisher}
DefaultDirName={code:PastaOrcaPRO}
DirExistsWarning=no
DisableProgramGroupPage=yes
UsePreviousAppDir=no
PrivilegesRequired=lowest
SetupIconFile=assets\orcapro-bim.ico
UninstallDisplayIcon={app}\assets\orcapro-bim.ico
UninstallDisplayName={#NomeExib}
OutputBaseFilename=OrcaPRO-BIM-Setup-{#Versao}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
WizardImageFile=assets\wizard-grande.bmp
WizardSmallImageFile=assets\wizard-pequeno.bmp

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Messages]
brazilianportuguese.SelectDirLabel3=O OrçaPRO BIM é instalado NA PASTA DO ORÇAPRO (onde fica o Iniciar-OrcaPRO.bat). Confira a pasta abaixo.

[Tasks]
Name: "desktopicon"; Description: "Criar um atalho na Área de Trabalho"; GroupDescription: "Atalhos:"

[Files]
Source: "..\OrcaPRO-BIM.vbs";      DestDir: "{app}";        Flags: ignoreversion
Source: "assets\orcapro-bim.ico";  DestDir: "{app}\assets"; Flags: ignoreversion

[Icons]
Name: "{userprograms}\{#NomeExib}"; Filename: "{sys}\wscript.exe"; Parameters: """{app}\OrcaPRO-BIM.vbs"""; WorkingDir: "{app}"; IconFilename: "{app}\assets\orcapro-bim.ico"
Name: "{autodesktop}\{#NomeExib}";  Filename: "{sys}\wscript.exe"; Parameters: """{app}\OrcaPRO-BIM.vbs"""; WorkingDir: "{app}"; IconFilename: "{app}\assets\orcapro-bim.ico"; Tasks: desktopicon

[Run]
Filename: "{sys}\wscript.exe"; Parameters: """{app}\OrcaPRO-BIM.vbs"""; WorkingDir: "{app}"; Description: "Abrir o {#NomeExib} agora"; Flags: nowait postinstall skipifsilent

[Code]
{ a pasta do OrcaPRO ja instalado: o instalador principal grava em HKCU }
function PastaOrcaPRO(Param: String): String;
var P: String;
begin
  if RegQueryStringValue(HKCU, 'Software\RA Engenharia Especial\OrcaPRO', 'Pasta', P) and (P <> '') then
    Result := P
  else
    Result := ExpandConstant('{localappdata}\Programs\OrcaPRO');
end;

{ sem o OrcaPRO na pasta escolhida o atalho abriria um servidor inexistente }
function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;
  if (CurPageID = wpSelectDir) and not FileExists(AddBackslash(WizardDirValue) + 'index.html') then
  begin
    MsgBox('Esta pasta não tem o OrçaPRO instalado (falta o index.html).' + #13#10 +
           'Escolha a pasta do OrçaPRO, onde fica o Iniciar-OrcaPRO.bat, ou instale o OrçaPRO primeiro.', mbError, MB_OK);
    Result := False;
  end;
end;
