/* =====================================================================
 * folhasemanal.js — Folha de Pagamento SEMANAL de diaristas, por obra
 * (caso real: operário com FAVORECIDO + CHAVE PIX, valor dia a dia
 * SEG→DOM, "x" = falta, hora extra, empreitas/fretes/reembolsos e
 * fechamento por obra). Motor PURO, Node-testável — a view fica no
 * gestao.js. Inclui parser da planilha semanal (1 obra por aba).
 * ===================================================================== */
(function (global) {
  "use strict";

  var DIAS = ["seg", "ter", "qua", "qui", "sex", "sab", "dom"];
  var ROT = { seg: "Segunda", ter: "Terça", qua: "Quarta", qui: "Quinta", sex: "Sexta", sab: "Sábado", dom: "Domingo" };
  var HDR = { "SEGUNDA": "seg", "TERCA": "ter", "TERÇA": "ter", "QUARTA": "qua", "QUINTA": "qui", "SEXTA": "sex", "SABADO": "sab", "SÁBADO": "sab", "DOMINGO": "dom" };

  /* célula do ExcelJS pode vir objeto (richText/fórmula/hyperlink) ou Date — reduz ao valor cru */
  function bruto(v) {
    if (v == null) return "";
    if (typeof v === "object") {
      if (v instanceof Date || typeof v.getFullYear === "function") return v;
      if (v.richText) return v.richText.map(function (t) { return t.text || ""; }).join("");
      if (v.result != null) return bruto(v.result);
      if (v.text != null) return v.text;
      if (v.hyperlink) return v.text || "";
      if (v.error) return "";
      return "";
    }
    return v;
  }
  function up(s) { return String(s == null ? "" : s).toUpperCase(); }
  function limpo(s) { return String(s == null ? "" : s).replace(/\s+/g, " ").trim(); }
  function ehFalta(v) { return /^x+$/i.test(limpo(v)); }

  /* número dual: aceita BR (1.234,56 / 166,00) e US da planilha dela (R$ 1,050.00 / 166.00) */
  function num(v) {
    if (typeof v === "number") return isFinite(v) ? v : 0;
    var s = limpo(v).replace(/r\$\s*/i, "");
    if (!s || ehFalta(s) || !/\d/.test(s)) return 0;
    s = s.replace(/[^\d.,-]/g, "");
    var pv = s.lastIndexOf(","), pd = s.lastIndexOf(".");
    if (pv !== -1 && pd !== -1) s = (pd > pv) ? s.replace(/,/g, "") : s.replace(/\./g, "").replace(",", ".");
    else if (pv !== -1) s = (s.length - pv - 1 === 3 && s.indexOf(",") !== pv) ? s.replace(/,/g, "") : s.replace(",", ".");
    var n = parseFloat(s);
    return isFinite(n) ? n : 0;
  }

  /* segunda-feira da semana de d (chave AAAA-MM-DD) */
  function chaveSemana(d) {
    var x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    var dow = (x.getDay() + 6) % 7; x.setDate(x.getDate() - dow);
    var m = x.getMonth() + 1, dd = x.getDate();
    return x.getFullYear() + "-" + (m < 10 ? "0" : "") + m + "-" + (dd < 10 ? "0" : "") + dd;
  }
  function semanaVizinha(ch, delta) {
    var p = String(ch).split("-"), d = new Date(+p[0], +p[1] - 1, +p[2] + (delta * 7));
    return chaveSemana(d);
  }
  function periodoDaChave(ch) {
    var p = String(ch).split("-"), ini = new Date(+p[0], +p[1] - 1, +p[2]), fim = new Date(+p[0], +p[1] - 1, +p[2] + 6);
    function f(d) { return (d.getDate() < 10 ? "0" : "") + d.getDate() + "/" + (d.getMonth() < 9 ? "0" : "") + (d.getMonth() + 1); }
    return f(ini) + " a " + f(fim) + "/" + fim.getFullYear();
  }

  /* Total de uma linha. UMA fonte só — quem quiser o valor da linha chama daqui.
   *
   * ⚠ O QUE ESTAVA ERRADO (bug de dinheiro, corrigido em 07/08/2026):
   * a mesma pessoa pode ter, na MESMA semana, dias trabalhados (diária
   * combinada) E um valor fechado de produção/empreita. O cálculo antigo
   * escolhia UM dos dois e jogava o outro fora em silêncio:
   *   - tipo "diaria"  → somava os dias e IGNORAVA o valor fechado;
   *   - outros tipos   → pegava o valor fechado e IGNORAVA dias e hora extra.
   * Quem preenchia os dias e o "Valor fechado" via o total sair só com as
   * diárias. O dinheiro da produção não aparecia em lugar nenhum — nem na
   * tela, nem na lista PIX, nem no Excel.
   *
   * REGRA AGORA: dias + hora extra + valor fechado, SOMADOS, para qualquer tipo.
   * O tipo é a CATEGORIA do custo (para o relatório por tipo), não uma chave
   * que decide qual campo conta.
   *
   * A ÚNICA exceção é `usarValor`: linha importada em que o total da planilha
   * divergiu do calculado e a planilha mandou. Ali `valor` JÁ É o total
   * fechado da linha — somar os dias de novo pagaria a semana duas vezes. */
  function totalLinha(l) {
    if (!l) return 0;
    if (l.usarValor) return num(l.valor);
    var t = 0; DIAS.forEach(function (d) { t += num(l.dias && l.dias[d]); });
    return t + num(l.he) + num(l.valor);
  }

  /* quanto veio de cada parte — a tela precisa disso para o total FECHAR à vista */
  function partesLinha(l) {
    if (!l) return { dias: 0, he: 0, fechado: 0, total: 0, planilha: false };
    if (l.usarValor) return { dias: 0, he: 0, fechado: num(l.valor), total: num(l.valor), planilha: true };
    var d = 0; DIAS.forEach(function (k) { d += num(l.dias && l.dias[k]); });
    var he = num(l.he), f = num(l.valor);
    return { dias: d, he: he, fechado: f, total: d + he + f, planilha: false };
  }

  /* fechamento: totais por obra + geral */
  function fechamento(lancs) {
    var porObra = {}, total = 0;
    (lancs || []).forEach(function (l) {
      var t = totalLinha(l), k = l.obraId || l.obra || "—";
      if (!porObra[k]) porObra[k] = { total: 0, linhas: [] };
      porObra[k].total += t; porObra[k].linhas.push(l); total += t;
    });
    /* Ordem das pessoas dentro de cada obra: hierarquia de função primeiro
       (mestre → pedreiro → ajudante → limpeza → eletricista → pintor) e
       alfabética dentro dela. Pedido do cliente, e vale para a folha na
       tela, no fechamento assinado e no Excel — os três saem da mesma
       lista, então a ordem não diverge entre o papel e a planilha.
       Sem o motor carregado (Node puro, teste antigo), fica como estava. */
    if (typeof Ordem !== "undefined" && Ordem.pessoas) {
      Object.keys(porObra).forEach(function (k) {
        porObra[k].linhas = Ordem.pessoas(porObra[k].linhas, { modo: "hierarquia" });
      });
    }
    return { porObra: porObra, total: total };
  }

  /* lista de pagamento PIX: agrupa por favorecido+chave (a dor real da semana) */
  function listaPix(lancs) {
    var m = {}, out = [];
    (lancs || []).forEach(function (l) {
      var t = totalLinha(l); if (t <= 0) return;
      var fav = limpo(l.favorecido) || limpo(l.nome) || "—";
      var k = up(fav) + "|" + limpo(l.chavePix);
      if (!m[k]) { m[k] = { favKey: k, favorecido: fav, chavePix: limpo(l.chavePix), total: 0, itens: [] }; out.push(m[k]); }
      m[k].total += t; m[k].itens.push({ nome: l.nome, obraId: l.obraId || l.obra, valor: t });
    });
    out.sort(function (a, b) { return b.total - a.total; });
    return out;
  }

  /* chave PIX que é CELULAR BR vira link de WhatsApp. Regra dura: 11 dígitos com
     "9" na 3ª posição (DDD + 9xxxx). CPF tem 11 dígitos mas sem esse 9 → nunca vira link
     (mesmo digitado com espaços/pontos). E-mail e chave aleatória ficam de fora. */
  function foneDaChave(chave) {
    var s = limpo(chave); if (!s || /@/.test(s)) return null;
    var d = s.replace(/\D/g, "");
    if (d.length === 13 && d.slice(0, 2) === "55") d = d.slice(2);
    if (d.length !== 11 || d.charAt(2) !== "9") return null;
    if (+d.slice(0, 2) < 11) return null; // DDD válido começa em 11
    return "55" + d;
  }

  /* mesmo operário com valor lançado em 2+ obras no MESMO dia da semana */
  function conflitos(lancs) {
    var mapa = {}, out = [];
    (lancs || []).forEach(function (l) {
      if (l.tipo !== "diaria" || !l.dias) return;
      DIAS.forEach(function (d) {
        if (!num(l.dias[d])) return;
        var k = up(limpo(l.nome)) + "|" + d;
        if (!mapa[k]) mapa[k] = [];
        mapa[k].push(l.obraId || l.obra || "—");
      });
    });
    Object.keys(mapa).forEach(function (k) {
      var obras = mapa[k]; if (obras.length < 2) return;
      var p = k.split("|");
      out.push({ nome: p[0], dia: p[1], rotDia: ROT[p[1]], obras: obras });
    });
    return out;
  }

  /* rótulos dos tipos de lançamento (a "categoria" do custo) */
  var ROT_TIPO = { diaria: "Mão de obra (diárias)", empreita: "Empreita", producao: "Produtividade medida", frete: "Frete", reembolso: "Reembolso", fornecedor: "Material / Fornecedor", outro: "Outros" };

  /* total por tipo (MO, empreita, frete, material…) */
  function porTipo(lancs) {
    var m = {};
    (lancs || []).forEach(function (l) { var k = l.tipo || "outro"; m[k] = (m[k] || 0) + totalFinal(l); });
    return m;
  }

  /* semanas cujo início (segunda) cai no mês AAAA-MM, rotuladas Semana 01.. */
  function semanasDoMes(mesChave) {
    var p = String(mesChave).split("-"), ano = +p[0], mes = +p[1] - 1;
    var d = new Date(ano, mes, 1), out = [], n = 1;
    var dow = (d.getDay() + 6) % 7; if (dow) d.setDate(d.getDate() + (7 - dow)); // 1ª segunda do mês
    while (d.getMonth() === mes) {
      out.push({ chave: chaveSemana(d), rotulo: "Semana " + (n < 10 ? "0" : "") + n, periodo: periodoDaChave(chaveSemana(d)) });
      n++; d.setDate(d.getDate() + 7);
    }
    return out;
  }

  /* medição do período: anterior (tudo antes), atual (período), acumulado — por chave de grupo */
  function medicao(todos, semanasPeriodo, chaveDe) {
    var noPer = {}, antes = {}, setPer = {};
    (semanasPeriodo || []).forEach(function (s) { setPer[s] = 1; });
    var ini = (semanasPeriodo && semanasPeriodo.length) ? semanasPeriodo.slice().sort()[0] : "";
    (todos || []).forEach(function (l) {
      var k = chaveDe(l), t = totalFinal(l); if (!k || !t) return;
      if (setPer[l.semana]) noPer[k] = (noPer[k] || 0) + t;
      else if (l.semana < ini) antes[k] = (antes[k] || 0) + t;
    });
    var out = {};
    Object.keys(noPer).concat(Object.keys(antes)).forEach(function (k) {
      if (out[k]) return;
      var a = antes[k] || 0, c = noPer[k] || 0;
      out[k] = { anterior: a, atual: c, acumulado: a + c };
    });
    return out;
  }

  /* resumo do mês: semanas cujo início cai no mês (AAAA-MM) → por obra e por pessoa */
  function resumoMensal(lancs, mesChave) {
    var porObra = {}, porPessoa = {}, semanas = {}, total = 0;
    (lancs || []).forEach(function (l) {
      if (!l.semana || l.semana.slice(0, 7) !== mesChave) return;
      var t = totalFinal(l); if (!t) return;
      semanas[l.semana] = 1; total += t;
      var ob = l.obraId || l.obra || "—";
      porObra[ob] = (porObra[ob] || 0) + t;
      var quem = limpo(l.favorecido) || limpo(l.nome) || "—";
      porPessoa[quem] = (porPessoa[quem] || 0) + t;
    });
    return { mes: mesChave, semanas: Object.keys(semanas).sort(), porObra: porObra, porPessoa: porPessoa, total: total };
  }

  /* ---- parser da célula "Nome (Função) FAVORECIDO: ... CHAVE PIX: ..." ---- */
  var FUNCOES = [["MESTRE DE OBRAS", "Mestre de Obras"], ["PEDREIRO", "Pedreiro"], ["AJUDANTE", "Ajudante"], ["LIMPEZA", "Limpeza"], ["PINTURA", "Pintor"], ["PINTOR", "Pintor"], ["ELETRICISTA", "Eletricista"], ["ELETRICA", "Eletricista"], ["ELÉTRICA", "Eletricista"], ["CARPINTEIRO", "Carpinteiro"], ["FERREIRO", "Ferreiro"], ["SERRALHEIRO", "Serralheiro"], ["ENTULHO", "Entulho"], ["EMPREITA", "Empreiteiro"], ["FRETE", "Frete"], ["FORNECEDOR", "Fornecedor"], ["REEMBOLSO", "Reembolso"]];
  function parseOperario(txt) {
    var t = limpo(txt), U = up(t);
    var iFav = U.search(/FAVORECIDO\s*:?/), iPix = U.search(/(CHAVE\s*PIX|PIX|CPF)\s*:/);
    var cab = t.slice(0, iFav !== -1 ? iFav : (iPix !== -1 ? iPix : t.length));
    var favorecido = "", chave = "";
    if (iFav !== -1) {
      var resto = t.slice(iFav).replace(/^[^:]*:\s*/, "");
      var iPix2 = up(resto).search(/(CHAVE\s*PIX|PIX|CPF)\s*:/);
      favorecido = limpo(iPix2 !== -1 ? resto.slice(0, iPix2) : resto).replace(/[.,;]$/, "");
      if (iPix2 !== -1) chave = limpo(resto.slice(iPix2).replace(/^[^:]*:\s*/, ""));
    } else if (iPix !== -1) chave = limpo(t.slice(iPix).replace(/^[^:]*:\s*/, ""));
    chave = chave.replace(/\((CELULAR|CPF|E-?MAIL)\)\.?$/i, "").replace(/[.,;]\s*$/, "").trim();
    var funcao = "";
    for (var i = 0; i < FUNCOES.length; i++) if (up(cab).indexOf(FUNCOES[i][0]) !== -1) { funcao = FUNCOES[i][1]; break; }
    var nome = limpo(cab.replace(/[\(\)\-–]/g, " ").replace(new RegExp(funcao ? funcao.normalize("NFD").replace(/[̀-ͯ]/g, "") : "$nunca$", "i"), " "));
    // remove a função escrita de outros jeitos (acentos) e sobras
    FUNCOES.forEach(function (f) { nome = nome.replace(new RegExp(f[0].replace(/[ÉÊ]/g, "[EÉÊ]").replace(/Ç/g, "[CÇ]"), "ig"), " "); });
    nome = limpo(nome).replace(/\s{2,}/g, " ");
    return { nome: nome || limpo(cab), funcao: funcao, favorecido: favorecido, chavePix: chave };
  }

  function tipoAvulso(texto) {
    var U = up(texto);
    if (U.indexOf("REEMBOLSO") !== -1) return "reembolso";
    if (U.indexOf("FRETE") !== -1) return "frete";
    if (U.indexOf("FORNECEDOR") !== -1) return "fornecedor";
    if (U.indexOf("EMPREITA") !== -1) return "empreita";
    return "outro";
  }

  /* ---- parser da PLANILHA SEMANAL dela: {abas:[{nome,dados:[][]}]} (mesma
     estrutura que o app já extrai de .xlsx/.xls/.csv) ---- */
  /* ⚠ `opcoes.formatoPadrao` É O FORMATO QUE A EMPRESA JÁ USOU ANTES.
   * Sem ele, todo período cujas DUAS pontas caem nos dias 1–12 é ambíguo — e
   * isso é ~1 semana em cada 5. A cliente que sempre manda planilha em mês/dia
   * levava um aviso vermelho em 20% das importações, mesmo com a leitura
   * certa. Aviso que aparece quando não há problema é aviso que a pessoa
   * aprende a ignorar, e aí ele não serve para o dia em que houver problema.
   * A tela guarda o formato assim que uma importação o revela sem dúvida
   * (`formatoDetectado`) e o devolve aqui na próxima. */
  function parsePlanilha(abas, opcoes) {
    var o = opcoes || {};
    var formatoPadrao = (o.formatoPadrao === "md" || o.formatoPadrao === "dm") ? o.formatoPadrao : "";
    var formatoDetectado = "";
    var obras = [], lancs = [], avisos = [], ambiguas = [], semData = false;
    (abas || []).forEach(function (aba) {
      var m = (aba.dados || aba.matriz || []).map(function (r) { return (r || []).map(bruto); });
      var hi = -1, mapa = null, obraNome = null, chave = null;
      for (var r = 0; r < m.length; r++) {
        var row = m[r] || [], c0 = limpo(row[0]), U0 = up(c0);
        // cabeçalho de bloco: "OBRA X ... PERÍODO data ... data" (pode repetir na MESMA aba)
        var ehHdrDias = row.some(function (c) { return HDR[up(limpo(c))]; }) && /OPER/i.test(U0);
        if (ehHdrDias) {
          hi = r; mapa = { dias: {}, he: -1, total: -1 };
          row.forEach(function (c, i) {
            var h = up(limpo(c));
            if (HDR[h]) mapa.dias[i] = HDR[h];
            else if (/HORA\s*EXTRA/.test(h)) mapa.he = i;
            else if (h === "TOTAL") mapa.total = i;
          });
          if (mapa.total === -1) mapa.total = row.length - 1;
          continue;
        }
        if (!c0) continue;
        if (/PER[ÍI]ODO/i.test(row.join(" ")) && !mapa) { // linha-título do bloco
          obraNome = limpo(c0.replace(/^OBRA\s+/i, ""));
          if (obras.indexOf(obraNome) === -1) obras.push(obraNome);
          /* ===== A DATA DO BLOCO "PERÍODO" =====
           * ⚠ ESTA DESAMBIGUAÇÃO ERA DE MÃO ÚNICA E ERRAVA O MÊS.
           *   Ela assumia M/D/AA (o formato da planilha da primeira cliente) e
           *   só corrigia quando M/D era IMPOSSÍVEL (`mm > 12`). Numa planilha
           *   brasileira, "10/08/26" (10 de agosto) não é impossível: virava
           *   mês 10, dia 8, e a semana era gravada como 2026-10-05.
           *   O dinheiro anda em cima dessa chave: o resumo mensal filtra por
           *   `semana.slice(0,7)`, então a folha de agosto some da competência
           *   de agosto e aparece em outubro; a despesa de mão de obra nasce
           *   carimbada na segunda-feira errada; e a tela ainda PULA para a
           *   semana adivinhada, com o toast comemorando "N lançamentos".
           *   Acertava só quando o dia era ≥ 13 — falha às vezes e acerta o
           *   resto, que é o pior padrão para alguém perceber.
           *
           * ⚠ E INVERTER O PADRÃO PARA BR NÃO SERVE: quebraria a cliente real
           *   num período inteiro dentro dos dias 1–12. Por isso a regra é:
           *   decidir quando dá para decidir, e quando NÃO dá, avisar em vez
           *   de escolher calado. */
          /* ⚠ A LINHA TEM DUAS DATAS — "PERÍODO 10/08/26 a 16/08/26" — E A
             SEGUNDA COSTUMA RESOLVER A PRIMEIRA. Num período de uma semana,
             quase sempre uma das pontas cai num dia > 12, e isso prova o
             formato das duas. Olhar só a primeira data era jogar fora a
             evidência que estava na mesma linha. Com isso "10/08 a 16/08"
             passa a ser lido como agosto (o 16 denuncia d/m) e "6/22 a 6/28"
             continua sendo junho (o 22 denuncia m/d). Sobra ambíguo só o
             período em que as DUAS pontas cabem nos dois papéis. */
          var fmtDaLinha = "";
          for (var cf = 1; cf < row.length && !fmtDaLinha; cf++) {
            var mf = limpo(row[cf]).match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
            if (!mf) continue;
            if (+mf[1] > 12) fmtDaLinha = "dm";
            else if (+mf[2] > 12) fmtDaLinha = "md";
          }
          /* o que esta planilha revelou sem dúvida vira o padrão da empresa */
          if (fmtDaLinha) formatoDetectado = fmtDaLinha;
          /* e, não revelando, vale o que a empresa já usou antes */
          if (!fmtDaLinha && formatoPadrao) fmtDaLinha = formatoPadrao;
          var achouData = false;
          for (var ci = 1; ci < row.length; ci++) {
            if (row[ci] && typeof row[ci] === "object" && typeof row[ci].getFullYear === "function") {
              var dU = row[ci];
              chave = chaveSemana(new Date(dU.getUTCFullYear(), dU.getUTCMonth(), dU.getUTCDate()));
              achouData = true; break;
            }
            var dv = limpo(row[ci]);
            /* ⚠ SERIAL DO EXCEL. O modal aceita .xls, e a leitura do .xls
               entrega a célula de data como NÚMERO (46194.99 = 10/08/2026),
               não como Date nem como texto — então nada casava, a semana saía
               `null`, o lançamento era gravado sem semana e envenenava o
               seletor da tela inteira. Fechar o formato aqui evita o problema
               na origem, em vez de tratá-lo cinco telas adiante. */
            var serial = (typeof row[ci] === "number") ? row[ci] : (/^\d{4,5}(\.\d+)?$/.test(dv) ? +dv : NaN);
            if (serial > 20000 && serial < 60000) {
              /* época do Excel: dia 1 = 01/01/1900, com o bug do 29/02/1900 */
              var ms = Math.round((serial - 25569) * 86400000);
              var dS = new Date(ms);
              chave = chaveSemana(new Date(dS.getUTCFullYear(), dS.getUTCMonth(), dS.getUTCDate()));
              achouData = true; break;
            }
            var md = dv.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
            if (!md) continue;
            var a = +md[3] < 100 ? 2000 + (+md[3]) : +md[3];
            var p1 = +md[1], p2 = +md[2], mm, dd;
            if (p1 > 12) { mm = p2; dd = p1; }            // 1º passa de 12 → é DIA (d/m)
            else if (p2 > 12) { mm = p1; dd = p2; }       // 2º passa de 12 → é DIA (m/d)
            else if (fmtDaLinha === "dm") { mm = p2; dd = p1; }   // a OUTRA data da linha decidiu
            else if (fmtDaLinha === "md") { mm = p1; dd = p2; }
            else {
              /* as DUAS pontas do período cabem nos dois papéis. Antes o
                 parser escolhia m/d sem dizer nada; a escolha continua sendo
                 m/d — inverter para BR quebraria a planilha da cliente que já
                 funciona, num período todo dentro dos dias 1–12 — mas agora
                 fica REGISTRADA, e a tela avisa em vez de decidir calada. */
              mm = p1; dd = p2;
              ambiguas.push(dv);
            }
            chave = chaveSemana(new Date(a, mm - 1, dd));
            achouData = true; break;
          }
          if (!achouData) semData = true;
          hi = -1; mapa = null; continue;
        }
        if (/FECHAMENTO/i.test(U0)) { mapa = null; continue; }
        if (!mapa || hi === -1) continue;
        // linha de gente/avulso
        var op = parseOperario(c0), dias = {}, faltas = [], temDia = false, obs = [];
        Object.keys(mapa.dias).forEach(function (ci2) {
          var v = row[ci2], d = mapa.dias[ci2], s = limpo(v);
          if (ehFalta(s)) { faltas.push(d); return; }
          // só vira valor-dia se a célula for numérica de verdade ("2ª COMPRA" é observação, não R$ 2)
          if (/^(r\$)?\s*[\d.,]+$/i.test(s)) { var n = num(s); if (n > 0) { dias[d] = n; temDia = true; return; } }
          if (s) obs.push(s);
        });
        var he = mapa.he !== -1 ? num(row[mapa.he]) : 0;
        var totPl = num(row[mapa.total]);
        var l = { obra: obraNome || aba.nome, semana: chave, nome: op.nome, funcao: op.funcao, favorecido: op.favorecido, chavePix: op.chavePix, obs: obs.join(" · ") };
        if (temDia) { l.tipo = "diaria"; l.dias = dias; l.faltas = faltas; l.he = he; }
        else { l.tipo = tipoAvulso(c0 + " " + obs.join(" ")); l.valor = totPl; }
        if (totPl > 0 || temDia) {
          var calc = totalLinha(l);
          if (totPl > 0 && Math.abs(calc - totPl) > 0.01) {
            // total da planilha manda (pode ter semana anterior embutida) — mas avisa
            avisos.push(l.obra + " · " + l.nome + ": calculado R$ " + calc.toFixed(2) + " ≠ planilha R$ " + totPl.toFixed(2) + " (mantive o da planilha)");
            if (l.tipo === "diaria") { l.tipo = "diaria"; l.ajuste = totPl - (calc - num(l.he)) - num(l.he); l.valor = totPl; l.usarValor = true; }
          }
          lancs.push(l);
        }
      }
    });
    /* ⚠ O QUE SAIU SEM SEMANA NÃO PODE SER GRAVADO CALADO.
     * Lançamento com `semana: null` envenena a tela inteira da Folha: o
     * seletor de semanas faz `.sort()` e a string "null" fica em ÚLTIMO,
     * então `_fsSemana` vira null; daí o rótulo do período sai
     * "NaN/NaN a NaN/NaN/NaN" e os botões de resumo e de relatório estouram
     * `null.slice(0,7)` — morrem mudos, porque não há captura global de erro.
     * E pior de explicar ao cliente: a opção do <select> nasce com
     * `value="null"` (string), então depois de trocar de semana o usuário não
     * consegue mais VOLTAR para os órfãos.
     * Das três portas que gravam `fs_lancamentos`, as outras duas já garantem
     * a semana com um fallback. Só a importação não garantia. */
    var semSemana = lancs.filter(function (l) { return !l.semana; }).length;
    if (semSemana) {
      avisos.push(semSemana + " lançamento(s) vieram sem período reconhecível na planilha. "
        + "Escolha a semana na tela antes de importar — lançamento sem semana some da Folha e não volta.");
    }
    if (ambiguas.length) {
      avisos.push("Data do período ambígua (" + ambiguas.slice(0, 3).join(", ")
        + "): li como MÊS/DIA. Se a planilha for dia/mês, a folha vai para a competência errada — confira a semana antes de confirmar.");
    }
    return { obras: obras, lancamentos: lancs, avisos: avisos,
      /* a tela usa estes dois para perguntar em vez de adivinhar */
      formatoAmbiguo: ambiguas.length > 0, datasAmbiguas: ambiguas,
      /* e este para PARAR de perguntar: guardado, a próxima importação
         ambígua da mesma empresa resolve calada */
      formatoDetectado: formatoDetectado, formatoUsado: formatoPadrao,
      semSemana: semSemana, semData: semData };
  }

  /* Mantido pelo nome porque meia dúzia de telas já chamam assim. O `usarValor`
     hoje é tratado DENTRO do totalLinha — havia duas contas diferentes para a
     mesma linha (o fechamento interno usava totalLinha e ignorava a planilha;
     o exportado usava totalFinal e respeitava), e elas divergiam. */
  function totalFinal(l) { return totalLinha(l); }

  var FolhaSemanal = {
    DIAS: DIAS, ROT: ROT,
    num: num, ehFalta: ehFalta,
    chaveSemana: chaveSemana, periodoDaChave: periodoDaChave, semanaVizinha: semanaVizinha,
    foneDaChave: foneDaChave, conflitos: conflitos, resumoMensal: resumoMensal,
    ROT_TIPO: ROT_TIPO, porTipo: porTipo, semanasDoMes: semanasDoMes, medicao: medicao,
    totalLinha: totalLinha, totalFinal: totalFinal, partesLinha: partesLinha,
    /* Eram dois embrulhos que refaziam a conta por fora porque o totalLinha
       antigo não sabia de `usarValor`. Agora sabe, então quem soma é ele —
       e a lista PIX parou de precisar fingir que a linha era de outro tipo. */
    fechamento: fechamento,
    listaPix: listaPix,
    parseOperario: parseOperario, parsePlanilha: parsePlanilha
  };

  global.FolhaSemanal = FolhaSemanal;
  if (typeof module !== "undefined" && module.exports) module.exports = FolhaSemanal;
})(typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this));
